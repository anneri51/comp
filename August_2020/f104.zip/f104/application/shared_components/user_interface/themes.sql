prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 104
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>19526726201355085
,p_default_application_id=>115
,p_default_id_offset=>3610862431961051
,p_default_owner=>'FLUGZEUGVERMIETUNG_DEV'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(38735350487296273)
,p_theme_id=>51
,p_theme_name=>'Mobile'
,p_theme_internal_name=>'MOBILE'
,p_ui_type_name=>'JQM_SMARTPHONE'
,p_navigation_type=>'L'
,p_nav_bar_type=>'NAVBAR'
,p_reference_id=>3773947624214896911
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(38727319388296262)
,p_default_dialog_template=>wwv_flow_api.id(38727272407296261)
,p_error_template=>wwv_flow_api.id(38727319388296262)
,p_printer_friendly_template=>wwv_flow_api.id(38727319388296262)
,p_login_template=>wwv_flow_api.id(38727319388296262)
,p_default_button_template=>wwv_flow_api.id(38734396607296270)
,p_default_region_template=>wwv_flow_api.id(38729077719296265)
,p_default_chart_template=>wwv_flow_api.id(38729077719296265)
,p_default_form_template=>wwv_flow_api.id(38729077719296265)
,p_default_reportr_template=>wwv_flow_api.id(38729250324296265)
,p_default_tabform_template=>wwv_flow_api.id(38729077719296265)
,p_default_wizard_template=>wwv_flow_api.id(38729077719296265)
,p_default_irr_template=>wwv_flow_api.id(38729077719296265)
,p_default_report_template=>wwv_flow_api.id(38729364188296265)
,p_default_label_template=>wwv_flow_api.id(38730023916296267)
,p_default_calendar_template=>wwv_flow_api.id(38734779230296270)
,p_default_list_template=>wwv_flow_api.id(38729662295296266)
,p_default_nav_list_template=>wwv_flow_api.id(38729511624296266)
,p_default_top_nav_list_temp=>wwv_flow_api.id(38729511624296266)
,p_default_side_nav_list_temp=>wwv_flow_api.id(38729804786296266)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(38727934828296263)
,p_default_dialogr_template=>wwv_flow_api.id(38729077719296265)
,p_default_option_label=>wwv_flow_api.id(38730023916296267)
,p_default_header_template=>wwv_flow_api.id(38728790038296264)
,p_default_footer_template=>wwv_flow_api.id(38728510932296264)
,p_default_required_label=>wwv_flow_api.id(38730121716296267)
,p_default_page_transition=>'SLIDE'
,p_default_popup_transition=>'POP'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(51),'#IMAGE_PREFIX#themes/theme_51/')
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/5_0.css',
'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css'))
);
wwv_flow_api.component_end;
end;
/
