prompt --application/pages/page_00181
begin
--   Manifest
--     PAGE: 00181
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>181
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>unistr('STEU_\00DCbersicht_steuer_Zusammenhang_Bearbeitungsstatus')
,p_alias=>unistr('\00DCBERSICHT_STEUER__ZUSAMMEN_181')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('STEU_\00DCbersicht_steuer_Zusammenhang_Bearbeitungsstatus')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42881936682393325)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201025061410'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42090919460104580)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(124518731581688157)
,p_plug_name=>'relation'
,p_parent_plug_id=>wwv_flow_api.id(42090919460104580)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select src, ok_nok,  cnt cnt, jahr',
'from (',
'select ''ll'' src, case when datum_ok is not null then 1 else 0 end ok_nok, count(*) cnt, jahr',
'from t_lex_long',
'group by case when datum_ok is not null then 1 else 0 end, jahr',
'union',
'select ''zus'', case when datum_lex_buchung_ok is not null then 1 else 0 end, count(*), bucht_jahr',
'from v_kto_konten_zus zus',
'  --   join t_rel_konto_auszug_gir ktogir on ktogir.fk_main_key = zus.fk_main_key',
'group by case when datum_lex_buchung_ok is not null then 1 else 0 end,  bucht_jahr',
'union',
'select ''inp'', case when datum_buchung_ok is not null then 1 else 0 end, count(*), ord.jahr',
'',
'from t_inp_belege_all inp',
'  left join t_abl_ordner_page ord_pg on inp.fk_abl_ordner_page = ord_pg.pk_abl_ordner_page',
'  left join t_abl_ordner ord on ord.pk_abl_ordner = ord_pg.fk_abl_ordner',
'  ',
'',
'group by case when datum_buchung_ok is not null then 1 else 0 end,  ord.jahr',
')',
'where jahr = :P181_jahr or :P181_jahr is null or :P181_jahr = 0',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(124518766076688158)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:RP:P386_PK_REL_KTO_BEL_LEX,P386_PK_INP_BELEGE_ALL,P386_FK_MAIN_KEY,P386_RELATION,P386_PK_INP_BELEGE_ALL_1,P386_FK_MAIN_KEY_1,P386_RELATION_1:#PK_REL_LEX_KTO_BEL#,#FK_INP_BELEGE_ALL#,#FK_MAIN_KEY#,#FK_RELATION#,&P38'
||'6_PK_INP_BELEGE_ALL_1.,&P386_FK_MAIN_KEY_1.,&P386_RELATION_1.'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>124518766076688158
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39816321458344109)
,p_db_column_name=>'SRC'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39816679464344122)
,p_db_column_name=>'OK_NOK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ok Nok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39817038716344123)
,p_db_column_name=>'JAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39817406398344123)
,p_db_column_name=>'CNT'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(124673971218745742)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'398178'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SRC:OK_NOK:JAHR'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(124682736653843400)
,p_report_id=>wwv_flow_api.id(124673971218745742)
,p_pivot_columns=>'JAHR:SRC'
,p_row_columns=>'OK_NOK'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(39818503598344135)
,p_pivot_id=>wwv_flow_api.id(124682736653843400)
,p_display_seq=>1
,p_function_name=>'MAX'
,p_column_name=>'CNT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_sum=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39819243542346470)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(42090919460104580)
,p_button_name=>'Crreate_Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Crreate Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.::P252_PK_REL_LEX_KTO_BEL,P252_FK_INP_BELEGE_ALL:,&P181_PK_INP_BELEGE_ALL.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39819621631346475)
,p_name=>'P181_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(42090919460104580)
,p_item_default=>'2019'
,p_prompt=>'JAHR'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JAHR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value d, std_value r',
'from t_std ',
'where fk_std_group = 221'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39820076327346488)
,p_name=>'P181_PK_INP_BELEGE_ALL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(42090919460104580)
,p_prompt=>'Pk Inp Belege All'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
