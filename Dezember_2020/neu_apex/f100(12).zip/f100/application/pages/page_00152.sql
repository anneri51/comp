prompt --application/pages/page_00152
begin
--   Manifest
--     PAGE: 00152
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>152
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'ADR_ADRESSE_SCHNELL'
,p_alias=>'ADR_ADRESSE_SCHNELL_152'
,p_step_title=>'ADR_ADRESSE_SCHNELL'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42862188611255483)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201012093039'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25361181344221102)
,p_plug_name=>'Adresse_schnell'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_ADR_ADRESSE_SCHNELL,',
'       STRASSE,',
'       HAUSNUMMER,',
'       PLZ,',
'       ORT,',
'       PLZ_ORT,',
'       COMM,',
'       ADRESSE,',
'       CREATED_AT,',
'       FK_ADR_ADRESSE,',
'       FK_LOC_LOCATION,',
'       case when PK_ADR_ADRESSE_SCHNELL = :P152_PK_ADR_ADRESSE_SCHNELL then 1 else 0 end sel',
'  from T_ADR_ADRESSE_SCHNELL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Adresse_schnell'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(25361272685221103)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:154:P154_PK_ADR_ADRESSE_SCHNELL:#PK_ADR_ADRESSE_SCHNELL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>25361272685221103
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361320039221104)
,p_db_column_name=>'PK_ADR_ADRESSE_SCHNELL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Adr Adresse Schnell'
,p_column_link=>'f?p=&APP_ID.:152:&SESSION.::&DEBUG.::P152_NEW_LOCATION_FOR_ADRESSE:#PK_ADR_ADRESSE_SCHNELL#'
,p_column_linktext=>'#PK_ADR_ADRESSE_SCHNELL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361484168221105)
,p_db_column_name=>'STRASSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361521516221106)
,p_db_column_name=>'HAUSNUMMER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hausnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361651271221107)
,p_db_column_name=>'PLZ'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361765963221108)
,p_db_column_name=>'ORT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361814663221109)
,p_db_column_name=>'PLZ_ORT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Plz Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25361931907221110)
,p_db_column_name=>'COMM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25362008371221111)
,p_db_column_name=>'ADRESSE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Adresse'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25362110590221112)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25362270883221113)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25362362151221114)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25774730242333037)
,p_db_column_name=>'SEL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(25702070339339605)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'257021'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_ADR_ADRESSE_SCHNELL:STRASSE:HAUSNUMMER:PLZ:ORT:PLZ_ORT:COMM:ADRESSE:CREATED_AT:FK_ADR_ADRESSE:FK_LOC_LOCATION:SEL:'
,p_sort_column_1=>'FK_LOC_LOCATION'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'FK_LOC_LOCATION'
,p_break_enabled_on=>'FK_LOC_LOCATION'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27725293963264415)
,p_report_id=>wwv_flow_api.id(25702070339339605)
,p_name=>'ok_adr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_ADR_ADRESSE'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_ADR_ADRESSE" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>5
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27725664191264415)
,p_report_id=>wwv_flow_api.id(25702070339339605)
,p_name=>'ok_loc'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LOC_LOCATION'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_LOC_LOCATION" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#7DC773'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(25717566205407007)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(25361181344221102)
,p_button_name=>'New_Location'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Location'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:268:&SESSION.::&DEBUG.::P268_PK_ADR_ADRESSE_SCHNELL:&P152_NEW_LOCATION_FOR_ADRESSE.'
,p_grid_column_attributes=>'style="margin-top:12px"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8618300736483581)
,p_branch_name=>'Go To Page 153'
,p_branch_action=>'f?p=&APP_ID.:153:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8617666548483581)
,p_branch_name=>'Go To Page 151'
,p_branch_action=>'f?p=&APP_ID.:151:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25774694574333036)
,p_name=>'P152_NEW_LOCATION_FOR_ADRESSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(25361181344221102)
,p_prompt=>'New Location For Adresse'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
