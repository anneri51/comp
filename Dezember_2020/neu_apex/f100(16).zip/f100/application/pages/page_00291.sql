prompt --application/pages/page_00291
begin
--   Manifest
--     PAGE: 00291
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>291
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'projekt_plan'
,p_alias=>'PROJEKT_PLAN99'
,p_step_title=>'projekt_plan'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42863836018282035)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011161151'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4722458994506050)
,p_plug_name=>'projekt_plan'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cal_ as (select rownum rnr, to_date(''01.01.1900'',''DD.MM.YYYY'')+ rownum-1 dt from all_objects),',
'pr_ as (',
'        select ',
'                cal_.dt, ',
'                pk_proj_projekt, ',
'                projekt , ',
'                pa.std_name projekt_art, ',
'                fa.std_name proj_art_col, ',
'                row_number() over (partition by dt order by pa.sort, pk_proj_projekt) rnr1, ',
'                pk_proj_projekt || ''/'' || pa.sort || '': '' || ''<b>'' || projekt ||''</b>'' || ''  ('' || to_char(von, ''DD.MM.YYYY'') || '' - '' || to_char(bis,''DD.MM.YYYY'') ||'')'' pr1, ',
'',
'                to_char(cal_.dt,''IW'') kw,',
'                to_char(cal_.dt,''WD'') wd,',
'                substr(cal_.dt,4,2) mn, ',
'                substr(cal_.dt,7,4) yr,',
'                pa.sort  proj_art_sort',
'   from cal_',
'    left join t_proj_projekt pr on cal_.dt between pr.von and pr.bis',
'    left join  (select * from t_std where fk_std_group = 523) pa on pa.std_value = pr.fk_std_proj_projekt_art',
'    left join  (select * from t_std where fk_std_group = 522) fa on fa.std_value = pa.fk_std_farbe',
'       ),     ',
'       ',
' pr1_ as (',
'           select distinct rnr1, pk_proj_projekt, yr, proj_art_sort',
'           from pr_',
'-- where substr(dt,7,4)  between 1974 and 2019',
' ),',
' pr2_ as  (',
'             select pr1_.*,  row_number() over (partition by pk_proj_projekt, yr order by yr, pk_proj_projekt) rnr2',
'             from pr1_',
' )',
',',
' pr3_ as (',
' select rnr1, pk_proj_projekt, yr, rnr2, row_number() over (Partition by yr order by  proj_art_sort, pk_proj_projekt) rnr3',
' from pr2_',
'',
'   ',
' where rnr2 = 1',
'       ',
'       ),',
'     ',
'       ',
'       ',
'       ',
'pr4_ as (',
'select dt, ',
' kw,',
' wd,',
' mn, ',
' pr_.yr, ',
'case when rnr3 = 1 then ''<span style = "background-color:'' || proj_art_col || ''">'' ||  pr1  || ''</span>'' else null end pr1_1,',
'case when rnr3 = 2 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_2,',
'case when rnr3 = 3 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_3,',
'case when rnr3 = 4 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_4,',
'case when rnr3 = 5 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_5,',
'case when rnr3 = 6 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_6,',
'case when rnr3 = 7 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_7,',
'case when rnr3 = 8 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_8,',
'case when rnr3 = 9 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_9,',
'case when rnr3 = 10 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_10,',
'--',
'case when rnr3 = 11 then ''<span style = "background-color:'' || proj_art_col || ''">'' ||  pr1  || ''</span>'' else null end pr1_11,',
'case when rnr3 = 12 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_12,',
'case when rnr3 = 13 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_13,',
'case when rnr3 = 14 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_14,',
'case when rnr3 = 15 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_15,',
'case when rnr3 = 16 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_16,',
'case when rnr3 = 17 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_17,',
'case when rnr3 = 18 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_18,',
'case when rnr3 = 19 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_19,',
'case when rnr3 = 20 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_20,',
'--',
'case when rnr3 = 21 then ''<span style = "background-color:'' || proj_art_col || ''">'' ||  pr1  || ''</span>'' else null end pr1_21,',
'case when rnr3 = 22 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_22,',
'case when rnr3 = 23 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_23,',
'case when rnr3 = 24 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_24,',
'case when rnr3 = 25 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_25,',
'case when rnr3 = 26 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_26,',
'case when rnr3 = 27 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_27,',
'case when rnr3 = 28 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_28,',
'case when rnr3 = 29 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_29,',
'case when rnr3 = 30 then  ''<span style = "background-color:'' || proj_art_col || ''">'' || pr1 || ''</span>'' else null end pr1_30',
'from pr_',
'  left join pr3_ on pr3_.yr = pr_.yr and pr3_.pk_proj_projekt = pr_.pk_proj_projekt',
'',
')',
'',
'select dt, kw, mn, yr, wd,',
'--',
'max(pr1_1) pr1_1, ',
'max(pr1_2) pr1_2,',
'max(pr1_3) pr1_3,',
'max(pr1_4) pr1_4,',
'max(pr1_5) pr1_5,',
'max(pr1_6) pr1_6,',
'max(pr1_7) pr1_7,',
'max(pr1_8) pr1_8,',
'max(pr1_9) pr1_9,',
'max(pr1_10) pr1_10,',
'--',
'max(pr1_11) pr1_11, ',
'max(pr1_12) pr1_12,',
'max(pr1_13) pr1_13,',
'max(pr1_14) pr1_14,',
'max(pr1_15) pr1_15,',
'max(pr1_16) pr1_16,',
'max(pr1_17) pr1_17,',
'max(pr1_18) pr1_18,',
'max(pr1_19) pr1_19,',
'max(pr1_20) pr1_20,',
'--',
'max(pr1_21) pr1_21, ',
'max(pr1_22) pr1_22,',
'max(pr1_23) pr1_23,',
'max(pr1_24) pr1_24,',
'max(pr1_25) pr1_25,',
'max(pr1_26) pr1_26,',
'max(pr1_27) pr1_27,',
'max(pr1_28) pr1_28,',
'max(pr1_29) pr1_29,',
'max(pr1_30) pr1_30,',
'to_char(dt,''IYYY'') iyr',
'from pr4_',
'group by dt, kw, mn, yr,wd',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4722516327506050)
,p_name=>'projekt_plan'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>6162835602897590
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4722958401506063)
,p_db_column_name=>'DT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Dt'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4723292426506063)
,p_db_column_name=>'MN'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Mn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4723770403506064)
,p_db_column_name=>'YR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Yr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4724091444506064)
,p_db_column_name=>'PR1_1'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Pr1 1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4724569944506064)
,p_db_column_name=>'PR1_2'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Pr1 2'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675389736425883)
,p_db_column_name=>'KW'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Kw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675506316425884)
,p_db_column_name=>'PR1_3'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Pr1 3'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675587216425885)
,p_db_column_name=>'PR1_4'
,p_display_order=>43
,p_column_identifier=>'P'
,p_column_label=>'Pr1 4'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675722503425886)
,p_db_column_name=>'PR1_5'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Pr1 5'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675848433425887)
,p_db_column_name=>'PR1_6'
,p_display_order=>63
,p_column_identifier=>'R'
,p_column_label=>'Pr1 6'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675929897425888)
,p_db_column_name=>'PR1_7'
,p_display_order=>73
,p_column_identifier=>'S'
,p_column_label=>'Pr1 7'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4675989021425889)
,p_db_column_name=>'PR1_8'
,p_display_order=>83
,p_column_identifier=>'T'
,p_column_label=>'Pr1 8'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676081948425890)
,p_db_column_name=>'PR1_9'
,p_display_order=>93
,p_column_identifier=>'U'
,p_column_label=>'Pr1 9'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676244115425891)
,p_db_column_name=>'PR1_10'
,p_display_order=>103
,p_column_identifier=>'V'
,p_column_label=>'Pr1 10'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676457064425893)
,p_db_column_name=>'WD'
,p_display_order=>113
,p_column_identifier=>'W'
,p_column_label=>'Wd'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676554452425894)
,p_db_column_name=>'PR1_11'
,p_display_order=>123
,p_column_identifier=>'X'
,p_column_label=>'Pr1 11'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676589431425895)
,p_db_column_name=>'PR1_12'
,p_display_order=>133
,p_column_identifier=>'Y'
,p_column_label=>'Pr1 12'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676778251425896)
,p_db_column_name=>'PR1_13'
,p_display_order=>143
,p_column_identifier=>'Z'
,p_column_label=>'Pr1 13'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676837789425897)
,p_db_column_name=>'PR1_14'
,p_display_order=>153
,p_column_identifier=>'AA'
,p_column_label=>'Pr1 14'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4676885908425898)
,p_db_column_name=>'PR1_15'
,p_display_order=>163
,p_column_identifier=>'AB'
,p_column_label=>'Pr1 15'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677031361425899)
,p_db_column_name=>'PR1_16'
,p_display_order=>173
,p_column_identifier=>'AC'
,p_column_label=>'Pr1 16'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677177262425900)
,p_db_column_name=>'PR1_17'
,p_display_order=>183
,p_column_identifier=>'AD'
,p_column_label=>'Pr1 17'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677182216425901)
,p_db_column_name=>'PR1_18'
,p_display_order=>193
,p_column_identifier=>'AE'
,p_column_label=>'Pr1 18'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677350269425902)
,p_db_column_name=>'PR1_19'
,p_display_order=>203
,p_column_identifier=>'AF'
,p_column_label=>'Pr1 19'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677423007425903)
,p_db_column_name=>'PR1_20'
,p_display_order=>213
,p_column_identifier=>'AG'
,p_column_label=>'Pr1 20'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677534162425904)
,p_db_column_name=>'PR1_21'
,p_display_order=>223
,p_column_identifier=>'AH'
,p_column_label=>'Pr1 21'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677582073425905)
,p_db_column_name=>'PR1_22'
,p_display_order=>233
,p_column_identifier=>'AI'
,p_column_label=>'Pr1 22'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677766703425906)
,p_db_column_name=>'PR1_23'
,p_display_order=>243
,p_column_identifier=>'AJ'
,p_column_label=>'Pr1 23'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677807022425907)
,p_db_column_name=>'PR1_24'
,p_display_order=>253
,p_column_identifier=>'AK'
,p_column_label=>'Pr1 24'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4677907550425908)
,p_db_column_name=>'PR1_25'
,p_display_order=>263
,p_column_identifier=>'AL'
,p_column_label=>'Pr1 25'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4678050012425909)
,p_db_column_name=>'PR1_26'
,p_display_order=>273
,p_column_identifier=>'AM'
,p_column_label=>'Pr1 26'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4678114293425910)
,p_db_column_name=>'PR1_27'
,p_display_order=>283
,p_column_identifier=>'AN'
,p_column_label=>'Pr1 27'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4747899449070761)
,p_db_column_name=>'PR1_28'
,p_display_order=>293
,p_column_identifier=>'AO'
,p_column_label=>'Pr1 28'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4747987205070762)
,p_db_column_name=>'PR1_29'
,p_display_order=>303
,p_column_identifier=>'AP'
,p_column_label=>'Pr1 29'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4748108536070763)
,p_db_column_name=>'PR1_30'
,p_display_order=>313
,p_column_identifier=>'AQ'
,p_column_label=>'Pr1 30'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4748181038070764)
,p_db_column_name=>'IYR'
,p_display_order=>323
,p_column_identifier=>'AR'
,p_column_label=>'Iyr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4728174062509805)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'61685'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DT:MN:YR:PR1_1:PR1_2:KW:PR1_3:PR1_4:PR1_5:PR1_6:PR1_7:PR1_8:PR1_9:PR1_10:WD:PR1_11:PR1_12:PR1_13:PR1_14:PR1_15:PR1_16:PR1_17:PR1_18:PR1_19:PR1_20:PR1_21:PR1_22:PR1_23:PR1_24:PR1_25:PR1_26:PR1_27:PR1_28:PR1_29:PR1_30:IYR'
);
wwv_flow_api.component_end;
end;
/
