prompt --application/shared_components/data_loading/tables/t_imp_kto_gir_kto
begin
--   Manifest
--     T_IMP_KTO_GIR_KTO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_load_table(
 p_id=>wwv_flow_api.id(21947493270403279)
,p_name=>'dt'
,p_owner=>'#OWNER#'
,p_table_name=>'T_IMP_KTO_GIR_KTO'
,p_unique_column_1=>'BUCHUNGSTAG'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_api.component_end;
end;
/
