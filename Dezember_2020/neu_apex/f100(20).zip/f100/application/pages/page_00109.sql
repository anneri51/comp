prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>109
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Inp_belege_all_zusammenfassung_brutto_betrag_109'
,p_alias=>'INP-BELEGE-ALL-ZUSAMMENFASSUNG-BRUTTO-BETRAG-109'
,p_step_title=>'Inp_belege_all_zusammenfassung_brutto_betrag_109'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201012070500'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(21781629790730820)
,p_plug_name=>'Inp_belege_all_zusammenfassung_brutto_betrag_109'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  v_inp.ktokat_kategorie,',
' v_inp.abl_ord_jahr,',
'sum(v_inp.brutto_betrag) sum_betr',
'/*apex_item.checkbox2(1,v_inp.pk_inp_belege_all) sel,',
'',
'      inp.datum_buchung_ok, ',
'      inp.fk_real_beleg_exist,',
'      inp.dummy,',
'       v_inp.PK_INP_BELEGE_ALL,',
'        v_inp.fk_bas_std_status,',
'        v_inp.FK_LEX_BUCHUNG,',
'        v_inp.FK_bas_kat_KATEGORIE,',
'        v_inp.FK_bas_kal_ARBEITSTAG,',
'        v_inp.FK_kto_BUCHUNG,',
'        v_inp.FK_std_kto_ZAHLUNGSART,',
'        v_inp.FK_std_verw_VERWENDUNGSZWECK,',
'        v_inp.FK_inv_INVENTAR,',
'       v_inp.FK_proj_PROJEKT,',
'        nvl(v_inp.BELEGNUMMER,0) belegnummer,',
'        v_inp.BEZEICHNUNG,',
'        v_inp.FK_adr_LAND,',
'        v_inp.FK_adr_CITY,',
'        v_inp.BEL_DATUM,',
'        v_inp.beleg_uhrzeit,',
'        v_inp.VON,',
'        v_inp.BIS,',
'        v_inp.NETTO_BETRAG,',
'        v_inp.FK_bas_steu_STEUER_SATZ,',
'        v_inp.MWST_BETRAG,',
'        v_inp.BRUTTO_BETRAG,',
'        v_inp.FK_bas_mon_WAEHRUNG,',
'        v_inp.STEUERNUMMER,',
'        v_inp.FK_bas_mon_UMRECHNUNGSKURS,',
'        v_inp.COMM_REST_BELEG,',
'        v_inp.COMM_TEL_BELEG,',
'        v_inp.COMM_PRODUKTE,',
'        v_inp."COMM_BEGRUENDUNG",',
'        v_inp.COMM_SONSTIGES,',
'        v_inp.BELEG,',
'        v_inp.ZAHLUNGSBELEG,',
'        v_inp.LITER,',
'        v_inp."ZAPFSAEULE",',
'        v_inp.FK_loc_LOCATION,',
'        v_inp."PERSOENLICH_VOR_ORT",',
'       inp_bel_all_jahr,',
'       inp.fk_la_wdh,',
'       nvl(ll.habenkto,0) habenkto,',
'       ll.sollkto,',
'       v_inp.ort,',
'       v_inp.abl_ord_jahr,',
'       v_inp.ktokat_kategorie,',
'       v_inp.ABL_ORD_PK_ABL_ORDNER_PAGE,',
'       v_inp.ABL_ORD_PAGE_NUMBER,',
'       case when ll.status is not null then ''<span style="color:red">'' || ''<b>''  || nvl(rellex.pk_rel_lex_kto_bel,0) || ''</b>''|| ''</span>'' else '''' || nvl(rellex.pk_rel_lex_kto_bel,0)  end  pk_rel_lex_kto_bel,',
'        pk_rel_lex_kto_bel  pk_rel_lex_kto_bel_1,',
'       ll.belegnr ,',
'       arb.jahr,',
'       arb.monat,',
'       arb.tag,',
'       case when datum_ort_ok is not null or datum_addresse_ok is not null or datum_bussgeld_ok is not null or datum_beleg_pos_ok is not null or datum_buchung_ok is not null  or datum_verpfl_bel_ok is not null then 1 else 0 end flg_kontr_bel_ok',
'       , belart.std_name belegart',
'       ,stj.jahr steuer_jahr',
'       ,stm.monat steuer_monat',
'       ,sterk.std_name steuererklaerung_anlage',
'       */',
' from V_INP_BELEGE_ALL v_inp',
'   --left join t_rel_lex_kto_bel rellex on v_inp.pk_inp_belege_all = rellex.fk_inp_belege_all',
'   left join t_inp_belege_all inp on v_inp.pk_inp_belege_all = inp.pk_inp_belege_all',
'   --left join t_lex_long ll on ll.relation = rellex.fk_lex_relation',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag',
'  -- left join (select std_name, std_value',
' --             from t_std',
' --            where fk_std_group = 963) belart on belart.std_value= inp.FK_STD_INP_BELEGART ',
'--     left join t_steu_steuer_jahr stj on stj.pk_steu_steuer_jahr = inp.fk_steu_steuer_jahr',
'--    left join t_steu_steuer_monat stm on stm.pk_steu_steuer_monat = inp.fk_steu_steuer_monat',
'--    left join (select * from t_std where fk_std_group = 983) sterk on sterk.std_value = inp.fk_std_steu_steuererklaerung_anlage',
'group by  v_inp.ktokat_kategorie,',
' v_inp.abl_ord_jahr',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Inp_belege_all_zusammenfassung_brutto_betrag_109'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(21781719762730820)
,p_name=>'Inp_belege_all_zusammenfassung_brutto_betrag_109'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>21781719762730820
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21782166099730831)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21782558776730842)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21782936153730843)
,p_db_column_name=>'SUM_BETR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Sum Betr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(21783337326732684)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'217834'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KTOKAT_KATEGORIE:ABL_ORD_JAHR:SUM_BETR'
);
wwv_flow_api.component_end;
end;
/
