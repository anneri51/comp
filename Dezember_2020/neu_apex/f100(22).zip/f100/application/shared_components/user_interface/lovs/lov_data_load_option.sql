prompt --application/shared_components/user_interface/lovs/lov_data_load_option
begin
--   Manifest
--     LOV_DATA_LOAD_OPTION
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(21922479033202356)
,p_lov_name=>'LOV_DATA_LOAD_OPTION'
,p_lov_query=>'.'||wwv_flow_api.id(21922479033202356)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(21922707001202359)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Upload file, comma separated (*.csv) or tab delimited'
,p_lov_return_value=>'UPLOAD'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(21923185664202361)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Copy and Paste'
,p_lov_return_value=>'PASTE'
);
wwv_flow_api.component_end;
end;
/
