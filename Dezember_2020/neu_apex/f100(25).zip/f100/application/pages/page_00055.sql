prompt --application/pages/page_00055
begin
--   Manifest
--     PAGE: 00055
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>55
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Belegart'
,p_alias=>'BELEGART_55'
,p_step_title=>'Belegart'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011110744'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6960739590567303)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_BAS_BEL_BELEGART", ',
'"BELEGART",',
'"CREATED_BY",',
'"CREATED_AT",',
'"MODIFIED_BY",',
'"MODIFIED_AT"',
'from "#OWNER#"."T_BAS_BEL_BELEGART" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6961116114567304)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:56:&APP_SESSION.::::P56_PK_BELEGART:#PK_BELEGART#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6961116114567304
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6961645407567307)
,p_db_column_name=>'BELEGART'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Belegart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6962071866567311)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6962412493567313)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6962845977567315)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6963288607567316)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47598168199004899)
,p_db_column_name=>'PK_BAS_BEL_BELEGART'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Pk Bas Bel Belegart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6964112593568451)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'69642'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGART:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PK_BAS_BEL_BELEGART'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6963670200567317)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6960739590567303)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:56'
);
wwv_flow_api.component_end;
end;
/
