prompt --application/pages/page_00182
begin
--   Manifest
--     PAGE: 00182
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>182
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'IMP_TEL_O2'
,p_alias=>'IMP_TEL_O2_182'
,p_step_title=>'IMP_TEL_O2'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42892366292466303)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011150228'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5811786168831091)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2,fk_main_key) sel,',
'',
'fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'from v_kto_konten_zus',
'where FK_bas_kat_Kategorie = 19'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5811938995831092)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15122074236252013
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5811972715831093)
,p_db_column_name=>'D'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'D'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5812127886831094)
,p_db_column_name=>'R'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'R'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5812305921831096)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5857426673072799)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'151676'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'D:R:SEL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5858994325086797)
,p_report_id=>wwv_flow_api.id(5857426673072799)
,p_name=>'Row text contains ''Telefonica'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Telefonica'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5846909246027529)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'apex_item.checkbox2(1, pk_IMP_TEL_O2) sel,',
'"PK_IMP_TEL_O2", ',
'"BANKVERBINDUNG",',
'"JAHR",',
'"RECHNUNGSNUMMER",',
'"RECHNUNGSDATUM",',
'"VON",',
'"TR",',
'"BIS",',
'"FAELLIG_AM",',
'"BETRAG",',
'"WAEHRUNG",',
'"OFFENER_BETRAG",',
'"WAEHRUNG1",',
'"BEGLICHEN_AM",',
'"FK_KTO_BUCHUNG"',
'from "#OWNER#"."T_IMP_TEL_O2" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5847294686027530)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:183:&APP_SESSION.::::P183_PK:#PK#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>15157429926448451
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5847857454027548)
,p_db_column_name=>'BANKVERBINDUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bankverbindung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5848254667027550)
,p_db_column_name=>'JAHR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5848571117027553)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5848979493027554)
,p_db_column_name=>'RECHNUNGSDATUM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Rechnungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5849375400027555)
,p_db_column_name=>'VON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Von'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5849768272027557)
,p_db_column_name=>'TR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Tr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5850211610027559)
,p_db_column_name=>'BIS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Bis'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5850588008027560)
,p_db_column_name=>'FAELLIG_AM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Faellig Am'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5850966526027562)
,p_db_column_name=>'BETRAG'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5851423031027564)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5851798584027565)
,p_db_column_name=>'OFFENER_BETRAG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Offener Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5852241688027567)
,p_db_column_name=>'WAEHRUNG1'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Waehrung1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5852519826027568)
,p_db_column_name=>'BEGLICHEN_AM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Beglichen Am'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5812186588831095)
,p_db_column_name=>'SEL'
,p_display_order=>25
,p_column_identifier=>'P'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109214659262174)
,p_db_column_name=>'PK_IMP_TEL_O2'
,p_display_order=>35
,p_column_identifier=>'Q'
,p_column_label=>'Pk Imp Tel O2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109310275262175)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>45
,p_column_identifier=>'R'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5853991898029321)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'151642'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BANKVERBINDUNG:JAHR:RECHNUNGSNUMMER:RECHNUNGSDATUM:VON:TR:BIS:FAELLIG_AM:BETRAG:WAEHRUNG:OFFENER_BETRAG:WAEHRUNG1:BEGLICHEN_AM:SEL:PK_IMP_TEL_O2:FK_KTO_BUCHUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5866392232271002)
,p_report_id=>wwv_flow_api.id(5853991898029321)
,p_name=>'zuordnen'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5812386127831097)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(5846909246027529)
,p_button_name=>'UPdste'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Updste'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5853279031027570)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5846909246027529)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:183:&SESSION.::&DEBUG.:183'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5812509633831098)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if (apex_application.g_f01(i) is not null) then',
'      for j in 1..apex_application.g_f02.count loop',
'      ',
'        if (apex_application.g_f02(j) is not null) then',
'          update imp_tel_o2 set fk_buchung = apex_application.g_f02(j) where pk = apex_application.g_f01(i);',
'          commit;',
'        end if;',
'      end loop;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
