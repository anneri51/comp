prompt --application/pages/page_00315
begin
--   Manifest
--     PAGE: 00315
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>315
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kasse'
,p_alias=>'KASSE_315'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kasse'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201229212421'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10212971311300424)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10205770767300392)
,p_plug_name=>'Kasse'
,p_parent_plug_id=>wwv_flow_api.id(10212971311300424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_KTO_KAS_KASSE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666175041565718)
,p_plug_name=>'tab'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666227986565719)
,p_plug_name=>'Betrag'
,p_parent_plug_id=>wwv_flow_api.id(4666175041565718)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666422985565721)
,p_plug_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_parent_plug_id=>wwv_flow_api.id(4666175041565718)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666370546565720)
,p_plug_name=>'Grunddaten'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666573904565722)
,p_plug_name=>'Zahlungsinformationen'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666642232565723)
,p_plug_name=>'Kommentare'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666750675565724)
,p_plug_name=>'Kategorisierung'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4666855778565725)
,p_plug_name=>unistr('\00DCberpr\00FCfung')
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4667059420565727)
,p_plug_name=>'Steuer'
,p_parent_plug_id=>wwv_flow_api.id(10205770767300392)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13557366911839679)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'Create_Automatic_on_lex'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create Automatic On Lex'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40458407374191690)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'add_fk_arbeitstag'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Add Fk Arbeitstag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10213345125300424)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10214889946300435)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P315_PK_KTO_KAS_KASSE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10215336579300435)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P315_PK_KTO_KAS_KASSE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10215752105300435)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10212971311300424)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P315_PK_KTO_KAS_KASSE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4665688049565713)
,p_name=>'P315_FK_STD_CONTR_STATUS_KAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4666855778565725)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Std Contr Status Kat'
,p_source=>'FK_STD_CONTR_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4665755551565714)
,p_name=>'P315_FK_STD_CONTR_STATUS_VERW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4666855778565725)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Std Contr Status Verw'
,p_source=>'FK_STD_CONTR_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4665884247565715)
,p_name=>'P315_DATUM_STATUS_VERW'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Datum Status Verw'
,p_source=>'DATUM_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4665960511565716)
,p_name=>'P315_DATUM_STATUS_KAT'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Datum Status Kat'
,p_source=>'DATUM_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4666014810565717)
,p_name=>'P315_KONTOSTAND_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Kontostand Eur'
,p_source=>'KONTOSTAND_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10172567090960001)
,p_name=>'P315_FREMDWAEHRUNGSBETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666422985565721)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fremdwaehrungsbetrag'
,p_source=>'FREMDWAEHRUNGSBETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10206735857300414)
,p_name=>'P315_FK_EIN_AUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Ein Aus'
,p_source=>'FK_EIN_AUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Keine Angabe;0,Einnahme;1,Ausgabe;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10207100306300414)
,p_name=>'P315_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Datum'
,p_source=>'DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10207509430300416)
,p_name=>'P315_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_item_default=>'P315_BETRAG_BER'
,p_item_default_type=>'ITEM'
,p_prompt=>'<b>Betrag</b>'
,p_source=>'BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10207900924300416)
,p_name=>'P315_BUCHUNGSTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_item_default=>'P315_BUCHUNGSTEXT_BER'
,p_item_default_type=>'ITEM'
,p_prompt=>'Buchungstext'
,p_source=>'BUCHUNGSTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10208303270300416)
,p_name=>'P315_COMM'
,p_source_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666642232565723)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10208684833300417)
,p_name=>'P315_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Jahr</b>'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10209144733300417)
,p_name=>'P315_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10209579728300417)
,p_name=>'P315_FK_MAIN_KEY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Kontobuchung</b>'
,p_source=>'FK_MAIN_KEY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_MAIN_KEY_BUCHUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  zus.fk_main_key  || '' '' || Buchungstag || '' '' || round(Betrag,2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum ||  '' '' ||   mark_buchung   d',
'    ,',
'    zus.FK_MAIN_KEY r',
'from v_kto_konten_zus zus',
' left join (',
' ',
' ',
' select  distinct fk_main_key, listagg(buchung, '' / '') over (partition by fk_main_key) mark_buchung',
' from (',
' select fk_main_key,  case when lex_buchung = ''Buchung'' then ''Buchung'' when inpBel_status = ''vorbereitet'' then ''vorbereitet'' else ''nix!!!'' end buchung',
' from (',
' select fk_main_key, case when fk_std_inp_status = 11 then ''vorbereitet'' else null end inpbel_status , case when fk_lex_relation is not null then ''Buchung'' else null end lex_buchung, row_number() over (partition by fk_main_key order by fk_main_key) r'
||'nr',
' from t_rel_lex_kto_bel relbel',
'   left join t_inp_belege_all inp on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
' ',
' ) a',
' where rnr <=10',
' )b',
' ) mark_buch on mark_buch.fk_main_key = zus.fk_main_key'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10348318705308576)
,p_name=>'P315_FK_MAIN_KEY_BANKKONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Main Key Bankkonto'
,p_source=>'FK_MAIN_KEY_BANKKONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'  from v_kto_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10570402670317608)
,p_name=>'P315_FK_PROJ_PROJECT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_prompt=>'Fk Proj Project'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_PROJ_PROJEKT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || von || '' - '' || bis || '')'' d  ,Pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11716222855412467)
,p_name=>'P315_BETRAG_BER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_item_default=>'select replace(:P315_Betrag_ueb,''%2C'','','') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11716307698412468)
,p_name=>'P315_BETRAG_UEB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11716439778412469)
,p_name=>'P315_BUCHUNGSTEXT_UEB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_prompt=>'Buchungstext'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11716529014412470)
,p_name=>'P315_BUCHUNGSTEXT_BER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_default=>'select replace(:P315_buchungstext_ueb,''%2C'','','') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Buchungstext'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13557203671839678)
,p_name=>'P315_FK_RELATION_DISPLAY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_prompt=>'Fk Relation Display'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select relation || ''  '' || Buchungstext || '' '' || Belegdat || '' '' || Betrageur, relation',
'from t_lex_long'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36609530010519071)
,p_name=>'P315_DATUM_DUPL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666855778565725)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Datum Dupl Ok</b>'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36609640808519072)
,p_name=>'P315_DUPL_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666855778565725)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(36610203118519078)
,p_name=>'P315_GESAMT_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Gesamt Betrag</b>'
,p_source=>'GESAMT_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40457894663191685)
,p_name=>'P315_AUSWAHL_SRC_LEX'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_prompt=>'Auswahl Src Lex'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'', 0 from dual',
'union',
'select ''Kontenblatt'' || '' ('' || count(*) || '')'' , 1 from t_lex_kontenblatt where fk_lex_relation = :P315_FK_lex_RELation_display',
'union',
'select ''T_LEX_LONG'' || '' ('' || count(*) || '' / '' || sum(case when status is null then 1 else 0 end) ||'') - '' || max(relation) , 2 from t_lex_long  where relation = :P315_FK_lex_RELation_display '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40458003600191686)
,p_name=>'P315_DATUM_VAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Var'
,p_source=>'DATUM_VAR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46553593968578106)
,p_name=>'P315_PK_KTO_KAS_KASSE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_source=>'PK_KTO_KAS_KASSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46553763932578107)
,p_name=>'P315_FK_STD_KTO_KONTOTYP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Kontotyp</b>'
,p_source=>'FK_STD_KTO_KONTOTYP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_KTO_KONTOTYP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 24'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46553843467578108)
,p_name=>'P315_FK_KTO_BANKKONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4666573904565722)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Konto</b>'
,p_source=>'FK_KTO_BANKKONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_KTO_BANKKONTO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select iban || '' ('' || kreditkartennr || '')''|| '' '' || nachname || '', '' || vorname || '' '' || bank d , pk_kto_bankkonto',
'from t_kto_bankkonto kto',
' left join t_kto_bank bk on kto.fk_kto_bank = bk.pk_kto_bank',
' left join t_kon_person per on per.pk_kon_person = kto.fk_kon_owner1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46553909108578109)
,p_name=>'P315_FK_BAS_MON_FREMDWAEHRUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666422985565721)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Bas Mon Fremdwaehrung'
,p_source=>'FK_BAS_MON_FREMDWAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_MON_WAEHRUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select waehrung, pk_bas_mon_waehrung',
'from t_bas_mon_waehrung'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46554064544578110)
,p_name=>'P315_FK_BAS_KAL_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(4666370546565720)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_source=>'FK_BAS_KAL_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAL_ARBEITSTAGE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum || '' ('' || pk_BAS_KAL_ARBEITSTAGE || '')'' d, pk_BAS_KAL_ARBEITSTAGE',
'from t_BAS_KAL_ARBEITSTAGE'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46620934825847961)
,p_name=>'P315_FK_BAS_KAT_KATEGORIE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Kategorie</b>'
,p_source=>'FK_BAS_KAT_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAT_KATEGORIE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46620985436847962)
,p_name=>'P315_FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Verwendungszweck</b>'
,p_source=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_STD_VERW_VERWENDUNGSZWECK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std where fk_std_group = 9'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621143912847963)
,p_name=>'P315_FK_INV_INVENTAR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Inv Inventar'
,p_source=>'FK_INV_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_INV_INVENTAR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr d, pk_inv_inventar',
'from t_inv_inventare'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621262716847964)
,p_name=>'P315_FK_LOC_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(4666750675565724)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Loc Location'
,p_source=>'FK_LOC_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_LOC_LOCATION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'LOCATION || '' '' ||',
'LOCATION_TYPE  || '' '' ||',
'',
'STRASSE  || '' '' ||',
'HSNR  || '' '' ||',
'POSTFACH  || '' '' ||',
'PLZ  || '' '' ||',
'ORT  || '' '' ||',
'LAND  || '' '' ||',
'',
'',
'',
'BESCHREIBUNG  || '' '' ||',
'COMM',
'd',
'',
'',
', pk_loc_location',
'',
'from v_loc_location'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621339542847965)
,p_name=>'P315_FK_CONTR_DUPL_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4666855778565725)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Fk Contr Dupl Status'
,p_source=>'FK_CONTR_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621455696847966)
,p_name=>'P315_FK_STEU_STEUER_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4667059420565727)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Steuer Monat</b>'
,p_source=>'FK_STEU_STEUER_MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621546695847967)
,p_name=>'P315_FK_STEU_STEUER_VORANMELDG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4667059420565727)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Steuer Voranmeldg</b>'
,p_source=>'FK_STEU_STEUER_VORANMELDG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621613876847968)
,p_name=>'P315_DATUM_STEUERB_UEBERG'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4667059420565727)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Datum Steuerb Ueberg'
,p_source=>'DATUM_STEUERB_UEBERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621744917847969)
,p_name=>'P315_DATUM_FINANZAMT_UEBERG'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4667059420565727)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'Datum Finanzamt Ueberg'
,p_source=>'DATUM_FINANZAMT_UEBERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621871385847970)
,p_name=>'P315_GEBUEHREN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4666227986565719)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b><i>Gebuehren</i></b>'
,p_source=>'GEBUEHREN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46621890452847971)
,p_name=>'P315_DATUM_LEX_BUCHUNG_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4667059420565727)
,p_item_source_plug_id=>wwv_flow_api.id(10205770767300392)
,p_prompt=>'<b>Datum Lex Buchung</b> Ok'
,p_source=>'DATUM_LEX_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10213448032300424)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10213345125300424)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10214236421300430)
,p_event_id=>wwv_flow_api.id(10213448032300424)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10216533193300438)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(10205770767300392)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Kasse'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10216969262300438)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13557453646839680)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_on_Lex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare ',
'  v_seq_kas number;',
'  v_fk_main_key_kas number;',
'  v_lex_relation varchar(4000 char);',
' begin',
' ',
' --v_relation selektieren',
'    v_lex_relation:= :P315_fk_lex_relation_display;',
' ',
' --neue Kassenbuchung erzeugen - aus Lex_Buchung',
'   select t_kto_KAS_KASSE_SEQ.nextval',
'   into v_seq_kas',
'   from dual;',
' ',
' ',
'-- insert into kas_kasse (pk_kas_kasse,datum, buchungstext, betrag, jahr, comm) ',
' --select v_seq_kas,belegdatum, buchungstext,nvl(sollbetrag_eur,0) - nvl(habenbetrag_eur,0) , jahr, fk_relation from imp_kontenblatt_2018 where fk_relation = 	v_relation ;',
'--commit;',
'',
'',
'insert into t_kto_kas_kasse (pk_kto_kas_kasse,datum,datum_var, buchungstext, betrag,gesamt_betrag, jahr, comm) ',
' select v_seq_kas,null, belegdat, buchungstext,nvl(betrageur,0),nvl(betrageur,0)  , jahr, relation from t_lex_long where relation = 	v_lex_relation and status is null ;',
'commit;',
'',
'',
'--Kassenbuchung updaten (Arbeitstag, Kontonummer, kontotyp, fk_main_key)',
'update t_kto_Kas_Kasse set FK_MAIN_KEY = KTO_KONTO_SEQ.nextval where fk_main_key is null;',
'   ',
'merge into t_kto_kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from t_kto_kas_kasse kas',
' left join v_kto_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'    ',
'merge into t_kto_kas_kasse t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'       pk_kto_kas_kasse',
'',
'        from (select * from t_kto_kas_kasse where datum is not null and fk_bas_kal_arbeitstag is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kto_kas_kasse = t2.pk_kto_kas_kasse)',
'        when matched then',
'        update set t1.fk_bas_kal_arbeitstag= t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update t_kto_kas_kasse set fk_kto_bankkonto = 61 where fk_kto_bankkonto is null;',
'   update t_kto_kas_kasse set fk_bas_kto_kontotyp = 6 where fk_bas_kto_kontotyp is null;',
'   update t_kto_kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'   ',
'  --Kassenbuchung - Lexwarebuchung zuordnen ',
'   select fk_main_key',
'   into  v_fk_main_key_kas',
'   from t_kto_kas_kasse',
'   where instr(comm, v_lex_relation)>0;',
'   ',
'   insert into t_rel_lex_kto_bel (fk_main_key, fk_lex_relation)',
'   select v_fk_main_key_kas, v_lex_relation',
'   from dual;',
'   commit;',
'   ',
'   :P315_PK_kto_KAS_KASSE :=  v_seq_kas;',
'end;',
'',
'',
'',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13557366911839679)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40458349524191689)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_fk_arbeitstag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'merge into t_kto_kas_kasse t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'       pk_kto_kas_kasse',
'',
'        from (select * from t_kto_kas_kasse where datum is not null and fk_bas_kal_arbeitstag is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kto_kas_kasse = t2.pk_kto_kas_kasse)',
'        when matched then',
'        update set t1.fk_bas_kal_arbeitstag= t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(40458407374191690)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10216115588300436)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(10205770767300392)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Kasse'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
