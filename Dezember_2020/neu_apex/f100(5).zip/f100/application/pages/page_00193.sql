prompt --application/pages/page_00193
begin
--   Manifest
--     PAGE: 00193
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>193
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>unistr('\00D6ffentliche_Tickets_Bild')
,p_alias=>unistr('\00D6FFENTLICHE_TICKETS_BILD_193')
,p_step_title=>unistr('\00D6ffentliche_Tickets_Bild')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42886188592433667)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011151038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6408190039215308)
,p_plug_name=>'oeffentl_Tickets'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6426424584001702)
,p_plug_name=>unistr('\00D6ffentliche_Tickets_Bild')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_imp_ba_oeffentl_tickets,',
'length(Bild) Bild',
'from imp_ba_oeffentl_tickets',
'where PK_IMP_BA_OEFFENTL_TICKETS = :P193_PK_IMP_OEFFI'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6426487543001702)
,p_name=>unistr('\00D6ffentliche_Tickets_Bild')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15736622783422623
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6426939238001706)
,p_db_column_name=>'PK_IMP_BA_OEFFENTL_TICKETS'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Imp Ba Oeffentl Tickets'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6427171859001707)
,p_db_column_name=>'BILD'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:IMP_BA_OEFFENTL_TICKETS:BILD:PK_IMP_BA_OEFFENTL_TICKETS::::::::'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6431977371124648)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'157422'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_IMP_BA_OEFFENTL_TICKETS:BILD'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6408265808215309)
,p_name=>'P193_PK_IMP_OEFFI'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6408190039215308)
,p_prompt=>'Pk imp oeffi'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
