prompt --application/pages/page_00329
begin
--   Manifest
--     PAGE: 00329
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>329
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Verpflegungsmehraufwand_Detail'
,p_alias=>'VERPFLEGUNGSMEHRAUFWAND_DETAI1'
,p_step_title=>'Verpflegungsmehraufwand_Detail'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011155750'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11869911510074988)
,p_plug_name=>'Verpflegungsmehraufwand_Detail'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12054407909567907)
,p_plug_name=>'Ort'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_Steu_STeuer_VERPFL_BELEG_ORT,',
'       FK_Steu_STeuer_VERPFL_MEHRAUFWD_DET,',
'       FK_adr_ORT,',
'       FK_STD_STEU_AUSWAERTS,',
'       CREATION_DATE,',
'       ort,',
'       land,',
'       FK_STD_RK_REISETAETIGKEIT',
'  from T_REL_Steu_steuer_VERPFL_BELEG_ORT bel',
'    left join t_adr_ort ort on ort.pk_adr_ort = bel.fk_adr_ort',
'    left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land',
' where fk_steu_steuer_verpfl_mehraufwd_det = :P329_pK_steu_steuer_VERPFL_MEHRAUFWD_DET'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12054648905567909)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:RP,:P340_PK_REL_STEU_STEUER_VERPFL_BELEG_ORT,P340_FK_BAS_KAL_ARBEITSTAG:#PK_REL_STEU_STEUER_VERPFL_BELEG_ORT#,&P329_FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD.'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13494968180959449
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12142038717878863)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12143080186878873)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12143148061878874)
,p_db_column_name=>'LAND'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662605704795080)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_ORT'
,p_display_order=>120
,p_column_identifier=>'I'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662773677795081)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>130
,p_column_identifier=>'J'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662848211795082)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662929286795083)
,p_db_column_name=>'FK_STD_STEU_AUSWAERTS'
,p_display_order=>150
,p_column_identifier=>'L'
,p_column_label=>'Fk Std Steu Auswaerts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14072809562269736)
,p_db_column_name=>'FK_STD_RK_REISETAETIGKEIT'
,p_display_order=>160
,p_column_identifier=>'M'
,p_column_label=>'Fk Std Rk Reisetaetigkeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12150737862903469)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135911'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CREATION_DATE:ORT:LAND:PK_REL_STEU_STEUER_VERPFL_BELEG_ORT:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_ADR_ORT:FK_STD_STEU_AUSWAERTS:FK_STD_RK_REISETAETIGKEIT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14137943294709505)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(7149260507999280)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7266704574999328)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16261778011776395)
,p_plug_name=>'Input Belge + Lex Buchungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16258983653776368)
,p_plug_name=>'Input Belge + Lex Buchungen'
,p_parent_plug_id=>wwv_flow_api.id(16261778011776395)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_steu_steuer_VERPFL_BELEG_SRC,',
'       bel.FK_steu_steuer_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_proj_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_std_steu_STATUS,',
'      bel.creation_date,',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P329_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      ll.habenkto,',
'      ll.sollkto,',
'      ll.ust_kto',
'   ',
'from T_REL_steu_steuer_VERPFL_BEleG_SRC bel',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_rel_lex_kto_bel relbel on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation  = relbel.fk_lex_relation ',
' where FK_steu_steuer_VERPFL_MEHRAUFWD_DET = :P329_PK_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16259181509776370)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>17699500785167910
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259478568776372)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259557155776373)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259581524776374)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260076648776378)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260122828776379)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260226591776380)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260359985776381)
,p_db_column_name=>'INP_BEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260452747776382)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261383360776392)
,p_db_column_name=>'HABENKTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261544600776393)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261653879776394)
,p_db_column_name=>'UST_KTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664627077795100)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664697654795101)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664857424795102)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664929544795103)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16342480948514217)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'177829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:FK_INP_BELEGE_ALL:CREATION_DATE:PK_INP_BELEGE_ALL:BEL_DATUM:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:HABENKTO:SOLLKTO:UST_KTO:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16355256698670602)
,p_plug_name=>'Stundenzettel'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_steu_steuer_VERPFL_BELEG_SRC,',
'       bel.FK_steu_steuer_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_proj_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_std_steu_STATUS,',
'      bel.creation_date,',
'      ',
'   std.*,',
'   projekt',
'from T_REL_steu_steuer_VERPFL_BEleG_SRC bel',
' left join t_inp_belege_all std on bel.fk_proj_stundenzettel = std.pk_inp_belege_all',
'  left join t_proj_projekt proj on std.fk_proj_projekt  = proj.pk_proj_projekt',
'',
' where FK_steu_steuer_VERPFL_MEHRAUFWD_DET = :P329_PK_steu_steuer_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16355423936670604)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>17795743212062144
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355668114670606)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355748800670607)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355851683670608)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501512181907478)
,p_db_column_name=>'MONAT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501628233907479)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502039689907483)
,p_db_column_name=>'ERSTELLT_AM'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Erstellt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502146919907484)
,p_db_column_name=>'GEZEICHNET_AM'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Gezeichnet Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502453508907487)
,p_db_column_name=>'GENEHMIGT_AM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Genehmigt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502566518907488)
,p_db_column_name=>'EINGEREICHT_AM_PP_1'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Eingereicht Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503471559907497)
,p_db_column_name=>'PROJEKT'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663654296795090)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663770242795091)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663875123795092)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663957797795093)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664119902795095)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664268516795096)
,p_db_column_name=>'FK_KON_GEZEICHNET_VON'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kon Gezeichnet Von'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664341351795097)
,p_db_column_name=>'EINGEREICHT_AM_PP_2'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Eingereicht Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664456809795098)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_1'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Bestaetigung Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664555814795099)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_2'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Bestaetigung Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13493877248014424)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13493934884014425)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494002537014426)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494107569014427)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494282425014428)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494303802014429)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494445400014430)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494584197014431)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494667129014432)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494761566014433)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494805868014434)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13494970631014435)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495023172014436)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495159538014437)
,p_db_column_name=>'VON'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495204667014438)
,p_db_column_name=>'BIS'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495377476014439)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495462280014440)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495507619014441)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495666305014442)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495755605014443)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495852970014444)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13495931347014445)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13496095269014446)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13496166902014447)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13496204168014448)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13496385697014449)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13496436002014450)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537499578332001)
,p_db_column_name=>'BELEG'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537512270332002)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537610398332003)
,p_db_column_name=>'LITER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537712795332004)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537837554332005)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13537902936332006)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538060472332007)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538122023332008)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538214280332009)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538349054332010)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538423587332011)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538560876332012)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538606687332013)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538783649332014)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538805963332015)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13538918723332016)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539064744332017)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539134028332018)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539284159332019)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539373226332020)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539457947332021)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539572796332022)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539644705332023)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539723537332024)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539858200332025)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13539972340332026)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540043867332027)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540191666332028)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540264920332029)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540332290332030)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540410515332031)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540592775332032)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540634850332033)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540792958332034)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540899610332035)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13540978556332036)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541008933332037)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541132067332038)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541244241332039)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541399922332040)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541442211332041)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541585042332042)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541642869332043)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541763189332044)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541831509332045)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13541946004332046)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542069680332047)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542181511332048)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542245527332049)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542399627332050)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542460421332001)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542538011332002)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542611169332003)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542765849332004)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542896164332005)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13542984285332006)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543046772332007)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543100932332008)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543244152332009)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Modify At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543303630332010)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Modify By'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543405854332011)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543524331332012)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543693167332013)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543737157332014)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543894627332015)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13543906580332016)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544084960332017)
,p_db_column_name=>'FK_INT_INTERNET_APP'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Fk Int Internet App'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544190321332018)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544293897332019)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544375502332020)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544465728332021)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544584046332022)
,p_db_column_name=>'DUMMY'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544669629332023)
,p_db_column_name=>'STORNIERT'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Storniert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544774468332024)
,p_db_column_name=>'FK_ADR_ADRESSE_SCHNELL'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Fk Adr Adresse Schnell'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544827169332025)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544969723332026)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545012182332027)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545149733332028)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545252430332029)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545395708332030)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545455046332031)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545586840332032)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545646890332033)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545788618332034)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545811420332035)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545915399332036)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546092090332037)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546188817332038)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546208239332039)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546398214332040)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546491835332041)
,p_db_column_name=>'AZ_FAHRZEIT'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Az Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546529122332042)
,p_db_column_name=>'FK_STD_REISE_FAHRZEIT_EINHEIT'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Fk Std Reise Fahrzeit Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546654432332043)
,p_db_column_name=>'FK_WORK_STUNDENSATZ'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Fk Work Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546749930332044)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_UEBERSTUNDEN'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Fk Work Stundensatz Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546899656332045)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_WOCHENENDE'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Fk Work Stundensatz Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13546965464332046)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547042715332047)
,p_db_column_name=>'FK_WF_WORKFLOW_STEP'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Fk Wf Workflow Step'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547151889332048)
,p_db_column_name=>'FK_WF_WORKFLOW'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Fk Wf Workflow'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547205734332049)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_FAHRZEIT'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Fk Work Stundensatz Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547341689332050)
,p_db_column_name=>'SOLL_NETTO_BETRAG'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Soll Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547425408332001)
,p_db_column_name=>'SOLL_MWST_BETRAG'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Soll Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547578456332002)
,p_db_column_name=>'SOLL_BRUTTO_BETRAG'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Soll Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547648047332003)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ_SOLL'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Fk Bas Steu Steuer Satz Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547752017332004)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG_SOLL'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Fk Bas Mon Waehrung Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547879428332005)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS_SOLL'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Fk Bas Mon Umrechnungskurs Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13547907221332006)
,p_db_column_name=>'MENGE'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548064944332007)
,p_db_column_name=>'FK_STD_INP_MENGE_EINHEIT'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Fk Std Inp Menge Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548167125332008)
,p_db_column_name=>'ANZAHL_ZUGEHOERIGE_REAL_BELEGE'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Anzahl Zugehoerige Real Belege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16514537966918600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179549'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:FK_INP_BELEGE_ALL:CREATION_DATE:MONAT:JAHR:ZEITRAUM_ZEITRAUM_ERSTELLT_AM:GEZEICHNET_AM:GENEHMIGT_AM:EINGEREICHT_AM_PP_1:PROJEKT:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS:FK_P'
||'ROJ_PROJEKT:FK_KON_GEZEICHNET_EINGEREICHT_AM_PP_2:BESTAETIGUNG_AM_PP_1:BESTAETIGUNG_AM_PP_2:PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR'
||'NUMMER:BEZEICHNUNG:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_WAEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_COMM_TEL_COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:B'
||'ELEG:ZAHLUNGSBELEG:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG'
||':FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_ZA'
||'HLUNGSSTATUS:COMM_VERGEHEN:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:V'
||'ERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STD_INP_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_B'
||'Y:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_INT_INTERNET_APP:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_KON_GESCHAEFTSPARTNER:DUMMY:STORNIERT:FK_ADR_ADRESSE_SCHNELL:FK_LEX_RE'
||'LATION_SRC:FK_MAIN_KEY_SRC:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZEICHEN:VERG_TATBESTANDSNUMMER:FK_VER_VERTRAG:AZ_STUNDENZAHL:FK_KON_P'
||'ERSON:AZ_UEBERSTUNDEN:AZ_SOLLSTUNDEN:AZ_FAHRZEIT:FK_STD_REISE_FAHRZEIT_EINHEIT:FK_WORK_STUNDENSATZ:FK_WORK_STUNDENSATZ_UEBERSTUNDEN:FK_WORK_STUNDENSATZ_WOCHENENDE:FK_MDT_MANDANT_STEP:FK_WF_WORKFLOW:FK_WORK_STUNDENSATZ_FAHRZEIT:SOLL_NETTO_BETRAG:SOLL_'
||'MWST_BETRAG:SOLL_BRUTTO_BETRAG:FK_BAS_STEU_STEUER_SATZ_SOLL:FK_BAS_MON_WAEHRUNG_SOLL:FK_BAS_MON_UMRECHNUNGSKURS_SOLL:MENGE:FK_STD_INP_MENGE_EINHEIT:ANZAHL_ZUGEHOERIGE_REAL_BELEGE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25204718034521223)
,p_plug_name=>'Hotelbelege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_STEU_STEUER_VERPFL_BELEG_SRC,',
'       bel.FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_PROJ_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_STD_STEU_STATUS,',
'      bel.creation_date,',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P329_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      --kat',
'      kat.Kategorie kategorie,',
'      inp.FK_bas_kat_Kategorie,',
'      kat.FK_bas_kat_Oberkategorie  fk_oberkategorie,',
'      --katpos',
'      katpos.Kategorie pos_kategorie,',
'      katposob.Kategorie posob_Kategorie,',
'      inppos.fk_bas_kat_kategorie pos_fk_bas_kat_kategorie,',
'      katpos.FK_bas_kat_Oberkategorie  pos_fk_oberkategorie,',
unistr('      case when inp.fk_bas_kat_kategorie = 314 or inppos.fk_bas_kat_kategorie = 314 then 1 else 0 end fr\00FCh,'),
'      case when  kat.FK_bas_kat_Oberkategorie = 694 and  katpos.FK_bas_kat_Oberkategorie  = 694 then 1 else 0 end hotel,',
'      tinp.fk_kon_person,',
'      bel.fk_mdt_mandant',
'   ',
'from T_REL_STEU_STEUER_VERPFL_BEleG_SRC bel',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'      left join t_inp_belege_all tinp on bel.fk_inp_belege_all = tinp.pk_inp_belege_all',
'   left join t_inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_bas_kat_kategorie katpos on katpos.pk_bas_kat_kategorie = inppos.fk_bas_kat_kategorie',
'   left join t_bas_kat_kategorie katposob on katposob.pk_bas_kat_kategorie = katpos.FK_bas_kat_Oberkategorie',
'   left join t_bas_kat_kategorie kat on kat.pk_bas_kat_kategorie = inp.fk_bas_kat_kategorie',
' where FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET = :P329_PK_STEU_STEUER_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(25205013897521223)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP,:P330_PK_REL_STEU_STEUER_VERPFL_BELEG_SRC,P330_FK_BAS_KAL_ARBEITSTAG:#PK_REL_STEU_STEUER_VERPFL_BELEG_SRC#,&P329_FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD.'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>26645333172912763
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11903827023155536)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11904224137155536)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11904676464155536)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054137698567904)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054184886567905)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054365981567906)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>67
,p_column_identifier=>'M'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081770189103385)
,p_db_column_name=>'INP_BEL'
,p_display_order=>77
,p_column_identifier=>'N'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081860256103386)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>87
,p_column_identifier=>'O'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081890174103387)
,p_db_column_name=>'POS_KATEGORIE'
,p_display_order=>97
,p_column_identifier=>'P'
,p_column_label=>'Pos Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082122011103389)
,p_db_column_name=>'POSOB_KATEGORIE'
,p_display_order=>117
,p_column_identifier=>'R'
,p_column_label=>'Posob Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082217393103390)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>127
,p_column_identifier=>'S'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082364482103391)
,p_db_column_name=>'POS_FK_OBERKATEGORIE'
,p_display_order=>137
,p_column_identifier=>'T'
,p_column_label=>'Pos Fk Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082522190103393)
,p_db_column_name=>'FK_OBERKATEGORIE'
,p_display_order=>157
,p_column_identifier=>'V'
,p_column_label=>'Fk Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082770473103395)
,p_db_column_name=>unistr('FR\00DCH')
,p_display_order=>177
,p_column_identifier=>'X'
,p_column_label=>unistr('Fr\00FCh')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082862423103396)
,p_db_column_name=>'HOTEL'
,p_display_order=>187
,p_column_identifier=>'Y'
,p_column_label=>'Hotel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663027492795084)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>197
,p_column_identifier=>'Z'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663174950795085)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>207
,p_column_identifier=>'AA'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663203280795086)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>217
,p_column_identifier=>'AB'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663314240795087)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>227
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663433978795088)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>237
,p_column_identifier=>'AD'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663505388795089)
,p_db_column_name=>'POS_FK_BAS_KAT_KATEGORIE'
,p_display_order=>247
,p_column_identifier=>'AE'
,p_column_label=>'Pos Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14138210452709508)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>257
,p_column_identifier=>'AF'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14138355324709509)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>267
,p_column_identifier=>'AG'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12120631627147322)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135610'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('COMM:FK_INP_BELEGE_ALL:CREATION_DATE:PK_INP_BELEGE_ALL:BEL_DATUM:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:POSOB_KATEGORIE:KATEGORIE:POS_KATEGORIE:FK_OBERKATEGORIE:POS_FK_OBERKATEGORIE::FR\00DCH:HOTEL:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_M')
||'EHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS:FK_BAS_KAT_KATEGORIE:POS_FK_BAS_KAT_KATEGORIE:FK_KON_PERSON:FK_MDT_MANDANT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117542464787992)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>'Hotel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HOTEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("HOTEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117903146787994)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>'Beleg'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'INP_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("INP_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#8D9DA1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117151910787992)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>unistr('fr\00FCh')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('FR\00DCH')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("FR\00DCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12054503340567908)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(12054407909567907)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:330:P340_FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,P340_FK_BAS_KAL_ARBEITSTAG,P340_FK_MDT_MANDANT:&P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET.,&P329_FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD.,&P329_FK_MDT_MANDANT.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16259113924776369)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16258983653776368)
,p_button_name=>'CREATE_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_BAS_KAL_ARBEITSTAG,P330_FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:&P329_FK_DATUM_VERPFMWED.,&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16355328762670603)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16355256698670602)
,p_button_name=>'CREATE_3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_BAS_KAL_ARBEITSTAG,P330_FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,P330_FK_MDT_MANDANT:&P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD.,&P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET.,&P329_FK_MDT_MANDANT.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12145869949878901)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>unistr('\00DCbersicht')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('\00DCbersicht')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:339:&SESSION.::&DEBUG.:RP:P339_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12401052914668930)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(16261778011776395)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11884690086075024)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11883519949075019)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:328:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11885133727075024)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11884367889075024)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11905025022155539)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(25204718034521223)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_BAS_KAL_ARBEITSTAG,P330_FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,P330_FK_MDT_MANDANT:&P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD.,&P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET.,&P329_FK_MDT_MANDANT.'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(11885446191075024)
,p_branch_name=>'Go To Page 328'
,p_branch_action=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.::P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD:&P329_FK_VERPFLEGUNGSMEHRAUFWAND.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11871817921075002)
,p_name=>'P329_DESCR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Descr'
,p_source=>'DESCR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11872203301075002)
,p_name=>'P329_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12516184842141588)
,p_name=>'P329_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12517065524141588)
,p_name=>'P329_FK_BAS_KAL_ARBEITSTAG'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag || '' '' || monat || '' '' || jahr arb_tag, pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604002864709593)
,p_name=>'P329_HINT_VP_VOLL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 24 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604175789709594)
,p_name=>'P329_HINT_VP_TEIL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 12 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604255905709595)
,p_name=>unistr('P329_HINT_VP_K\00DCRZ')
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('Abzug bei Rechnung mit Hotelfr\00FChst\00FCck')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604312059709596)
,p_name=>unistr('P329_HINT_VP_\00DCBERNACHTUNG')
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('\00DCbernachtung ausw\00E4rts (bei Angestellten)')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13081612304103384)
,p_name=>'P329_FK_INP_BELEGE_ALL'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Inp Belege All'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all || '' '' || bezeichnung, pk_inp_belege_all',
'from t_inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13550316181332030)
,p_name=>'P329_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant, pk_mdt_mandant',
'from t_mdt_mandant'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072328769269731)
,p_name=>'P329_MODIFY_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Modify Date'
,p_source=>'MODIFY_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072541608269733)
,p_name=>'P329_FK_STD_RK_ANZAHL_STUNDEN_AUSWAERTS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Rk Anzahl Stunden Auswaerts'
,p_source=>'FK_STD_RK_ANZAHL_STUNDEN_AUSWAERTS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 943'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072614718269734)
,p_name=>'P329_FK_STD_LOHN_TAGEGELD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Lohn Tagegeld'
,p_source=>'FK_STD_LOHN_TAGEGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 945'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14072744149269735)
,p_name=>'P329_FK_BAS_MON_CURRENCY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>'1'
,p_prompt=>'Fk Bas Mon Currency'
,p_source=>'FK_BAS_MON_CURRENCY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_MON_WAEHRUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select waehrung, pk_bas_mon_waehrung',
'from t_bas_mon_waehrung'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52660897813795063)
,p_name=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Pk Steu Steuer Verpfl Mehraufwd Det'
,p_source=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661067557795064)
,p_name=>'P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Steu Steuer Verpfl Mehraufwd'
,p_source=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_STEU_STEUER_VERPFL_MEHRAUFWD || '' '' ||',
'MONAT || '' '' ||',
'JAHR || '' '' ||',
'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS || '' '' || fk_kon_person ||  '' '' || fk_mdt_mandant d,',
'PK_STEU_STEUER_VERPFL_MEHRAUFWD ',
'from t_STEU_STEUER_VERPFL_MEHRAUFWD '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661111944795065)
,p_name=>'P329_DATUM_VERPFL_MEHRAUFWD'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Datum Verpfl Mehraufwd'
,p_source=>'DATUM_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661267413795066)
,p_name=>'P329_FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Bas Kal Datum Verpfl Mehraufwd'
,p_source=>'FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag || '' '' || monat || '' '' || jahr arb_tag, pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661327136795067)
,p_name=>'P329_FK_ADR_ORT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Adr Ort'
,p_source=>'FK_ADR_ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ('' || land || '')'' d, pk_adr_ort',
'from t_adr_ort ort',
' left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661424350795068)
,p_name=>'P329_FK_STD_VERPFL_FRUEHSTUECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Fruehstueck'
,p_source=>'FK_STD_VERPFL_FRUEHSTUECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:keine Angabe;0,ja;1,nein;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661573582795069)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Verpflegungspauschale Voll'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 242',
'order by sort'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661661422795070)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Verpflegungspauschale Teil'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 242',
'order by sort'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661761487795071)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Verpflegunspauschale Kuerz'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 242',
'order by sort'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661806362795072)
,p_name=>'P329_FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Uebernachtungspauschale'
,p_source=>'FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 242',
'order by sort'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661887745795073)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Status Vp Voll'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662026741795074)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Status Vp Teil'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662135705795075)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Status Vp Kuerz'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662230189795076)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_UEP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Status Uep'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_UEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662306581795077)
,p_name=>'P329_FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_source=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11886358939075027)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(11869911510074988)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Verpflegungsmehraufwand_Detail'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11885969391075027)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11869911510074988)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Verpflegungsmehraufwand_Detail'
);
wwv_flow_api.component_end;
end;
/
