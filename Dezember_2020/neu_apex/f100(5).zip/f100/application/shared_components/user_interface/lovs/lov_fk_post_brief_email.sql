prompt --application/shared_components/user_interface/lovs/lov_fk_post_brief_email
begin
--   Manifest
--     LOV_FK_POST_BRIEF_EMAIL
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(43935493699368964)
,p_lov_name=>'LOV_FK_POST_BRIEF_EMAIL'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select header || '' '' || fk_mdt_mandant || '' '' || created_at || '' '' || eingangsdatum_email || '' '' || eingangsdatum_brief || '' '' || inhaltsbeschreibung || '' '' || fk_std_post_type || '' '' || fk_std_post_status || '' '' || datum_erledigt d,  pk_post_brief_e'
||'mail',
'from t_post_brief_email'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PK_POST_BRIEF_EMAIL'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
