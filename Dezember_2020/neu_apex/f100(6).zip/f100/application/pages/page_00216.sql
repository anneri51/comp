prompt --application/pages/page_00216
begin
--   Manifest
--     PAGE: 00216
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>216
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Tree Page'
,p_alias=>'TREEPAGE'
,p_step_title=>'Tree Page'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42871455341341817)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011153838'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8290712664126326)
,p_plug_name=>'Tree'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as status, ',
'       level, ',
'       konten_nr_ext || '' '' || kto."BEZEICHNUNG" as title, ',
'       null as icon, ',
'       "PK_LEX_KONTENPLAN_KONTEN" as value, ',
'       null as tooltip, ',
'       null as link ',
'from "#OWNER#"."T_LEX_KONTENPLAN_KONTEN" kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
'start with fk_lex_kontenplan_konten_grp2 is null',
'connect by nocycle  ktogrp.kontennr_ext = prior kto.konten_nr_ext',
'order siblings by kto.konten_nr_ext'))
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'S'
,p_attribute_04=>'N'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_15=>'STATUS'
,p_attribute_23=>'LEVEL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8291123515126329)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8290712664126326)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8292382441126340)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8290712664126326)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8291544915126333)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8291123515126329)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8291975063126338)
,p_event_id=>wwv_flow_api.id(8291544915126333)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8290712664126326)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8292843760126340)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8292382441126340)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8293317020126340)
,p_event_id=>wwv_flow_api.id(8292843760126340)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8290712664126326)
);
wwv_flow_api.component_end;
end;
/
