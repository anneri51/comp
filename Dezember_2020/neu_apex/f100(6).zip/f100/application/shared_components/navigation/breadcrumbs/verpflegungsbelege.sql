prompt --application/shared_components/navigation/breadcrumbs/verpflegungsbelege
begin
--   Manifest
--     MENU: Verpflegungsbelege
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(7149260507999280)
,p_name=>'Verpflegungsbelege'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(7149493258999280)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(14146890892739749)
,p_parent_id=>0
,p_short_name=>'Verpflegungsmehraufwand'
,p_link=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:::'
,p_page_id=>326
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(14151336321905601)
,p_parent_id=>0
,p_short_name=>'Verpflegungsmehraufwand'
,p_link=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:::'
,p_page_id=>327
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(14201994600033947)
,p_parent_id=>wwv_flow_api.id(14147292362747088)
,p_short_name=>'Verpflegungsmehraufwand Ort'
,p_link=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:::'
,p_page_id=>340
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(14147000760743328)
,p_parent_id=>wwv_flow_api.id(14146890892739749)
,p_option_sequence=>15
,p_short_name=>'Verpflegungsmehraufwand Detail'
,p_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:::'
,p_page_id=>329
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(14147292362747088)
,p_parent_id=>wwv_flow_api.id(14147000760743328)
,p_option_sequence=>25
,p_short_name=>'Verpflegungsmehraufwand Belege (Src)'
,p_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:::'
,p_page_id=>330
);
wwv_flow_api.component_end;
end;
/
