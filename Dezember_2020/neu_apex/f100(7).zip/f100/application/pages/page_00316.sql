prompt --application/pages/page_00316
begin
--   Manifest
--     PAGE: 00316
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>316
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Buchungszuordnung'
,p_alias=>'BUCHUNGSZUORDNUNG_316'
,p_step_title=>'Buchungszuordnung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011160148'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10411414753867350)
,p_plug_name=>'Buchungszuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct relkto.*, ',
'',
'zus1.fk_main_key fk_main_key1,',
'zus1.Kontotyp kontotyp1,',
'zus1.fk_KTO_BANKkonto fk_KTO_BANKkonto1,',
'zus1."Betrag" betrag1,',
'bel1.fk_LEX_relation fk_LEX_relation1,',
'zus1.bucht_tag bucht_tag1,',
'zus1.bucht_monat bucht_monat1,',
'zus1.bucht_jahr bucht_jahr1,',
'll1.habenkto hbkto1,',
'll1.sollkto slkto1,',
'll1.buchdat buchdat1,',
'll1.betrag lexbetrag1,',
'',
'',
'zus2.fk_main_key fk_main_key2,',
'zus2.Kontotyp kontotyp2,',
'zus2.fk_KTO_BANKkonto fk_KTO_BANKkonto2,',
'zus2."Betrag" betrag2,',
'bel2.fk_LEX_relation fk_LEX_relation2,',
'zus2.bucht_tag bucht_tag2,',
'zus2.bucht_monat bucht_monat2,',
'zus2.bucht_jahr bucht_jahr2,',
'll2.habenkto hbkto2,',
'll2.sollkto slkto2,',
'll2.buchdat buchdat2,',
'll2.betrag lexbetrag2,',
'',
'case when zus1."Betrag"= -zus2."Betrag" then 1 else 0 end vgl',
'',
'from ( select distinct *',
'       from (',
'       select fk_KTO_konto_buch1, fk_KTO_konto_buch2, fk_STD_type from t_rel_KTO_kont_buch_kont_buch where fk_STD_type = 1',
'        union',
'            select  fk_KTO_konto_buch2, fk_KTO_konto_buch1, fk_STD_type from t_rel_KTO_kont_buch_kont_buch where fk_STD_type = 1',
'         )) relkto',
'         ',
' left join v_kto_konten_zus zus1 on relkto.fk_kto_konto_buch1 = zus1.fk_main_key',
' left join v_kto_konten_zus zus2 on relkto.fk_kto_konto_buch2 = zus2.fk_main_key',
' left join t_rel_lex_kto_bel bel1 on bel1.fk_main_key = zus1.fk_main_key',
' left join t_rel_lex_kto_bel bel2 on bel2.fk_main_key = zus2.fk_main_key',
' left join t_lex_long ll1 on ll1.relation = bel1.fk_lex_relation',
' left join t_lex_long ll2 on ll2.relation = bel2.fk_LEX_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10411490356867350)
,p_name=>'Buchungszuordnung'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11851809632258890
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10415554395867363)
,p_db_column_name=>'FK_MAIN_KEY1'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Main Key1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10415917187867364)
,p_db_column_name=>'KONTOTYP1'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kontotyp1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10416775554867364)
,p_db_column_name=>'BETRAG1'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Betrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10417520619867364)
,p_db_column_name=>'BUCHT_TAG1'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Bucht Tag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10417952657867364)
,p_db_column_name=>'BUCHT_MONAT1'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Monat1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10418376328867366)
,p_db_column_name=>'BUCHT_JAHR1'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Jahr1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10418704557867366)
,p_db_column_name=>'HBKTO1'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Hbkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10419100106867366)
,p_db_column_name=>'SLKTO1'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Slkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10419540531867366)
,p_db_column_name=>'BUCHDAT1'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Buchdat1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10419933398867366)
,p_db_column_name=>'LEXBETRAG1'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Lexbetrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10420321136867366)
,p_db_column_name=>'FK_MAIN_KEY2'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Main Key2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10420689530867367)
,p_db_column_name=>'KONTOTYP2'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Kontotyp2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10421497348867367)
,p_db_column_name=>'BETRAG2'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Betrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10422361137867367)
,p_db_column_name=>'BUCHT_TAG2'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Bucht Tag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10422772537867367)
,p_db_column_name=>'BUCHT_MONAT2'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Bucht Monat2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10423129376867367)
,p_db_column_name=>'BUCHT_JAHR2'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Bucht Jahr2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10423529719867369)
,p_db_column_name=>'HBKTO2'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Hbkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10423949652867369)
,p_db_column_name=>'SLKTO2'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Slkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10424360922867369)
,p_db_column_name=>'BUCHDAT2'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Buchdat2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10424745061867369)
,p_db_column_name=>'LEXBETRAG2'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Lexbetrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348204853308575)
,p_db_column_name=>'VGL'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'Vgl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041210922655016)
,p_db_column_name=>'FK_KTO_KONTO_BUCH1'
,p_display_order=>53
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kto Konto Buch1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041354265655017)
,p_db_column_name=>'FK_KTO_KONTO_BUCH2'
,p_display_order=>63
,p_column_identifier=>'AK'
,p_column_label=>'Fk Kto Konto Buch2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041493154655018)
,p_db_column_name=>'FK_STD_TYPE'
,p_display_order=>73
,p_column_identifier=>'AL'
,p_column_label=>'Fk Std Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041524813655019)
,p_db_column_name=>'FK_KTO_BANKKONTO1'
,p_display_order=>83
,p_column_identifier=>'AM'
,p_column_label=>'Fk Kto Bankkonto1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041607413655020)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>93
,p_column_identifier=>'AN'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041778827655021)
,p_db_column_name=>'FK_KTO_BANKKONTO2'
,p_display_order=>103
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Bankkonto2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23041806465655022)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>113
,p_column_identifier=>'AP'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10425086864870360)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MAIN_KEY1:KONTOTYP1:BETRAG1:BUCHT_TAG1:BUCHT_MONAT1:BUCHT_JAHR1:HBKTO1:SLKTO1:BUCHDAT1:LEXBETRAG1:FK_MAIN_KEY2:KONTOTYP2:BETRAG2:BUCHT_TAG2:BUCHT_MONAT2:BUCHT_JAHR2:HBKTO2:SLKTO2:BUCHDAT2:LEXBETRAG2:VGL:FK_KTO_KONTO_BUCH1:FK_KTO_KONTO_BUCH2:FK_STD'
||'_TYPE:FK_KTO_BANKKONTO1:FK_LEX_RELATION1:FK_KTO_BANKKONTO2:FK_LEX_RELATION2'
,p_break_on=>'FK_KONTO_BUCH1'
,p_break_enabled_on=>'FK_KONTO_BUCH1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10434297767972891)
,p_report_id=>wwv_flow_api.id(10425086864870360)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VGL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VGL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10433497924972889)
,p_report_id=>wwv_flow_api.id(10425086864870360)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR1'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR1" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10433954620972891)
,p_report_id=>wwv_flow_api.id(10425086864870360)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP1'
,p_operator=>'='
,p_expr=>'Tagesgeldkonto'
,p_condition_sql=>'"KONTOTYP1" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Tagesgeldkonto''  '
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
