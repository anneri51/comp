prompt --application/pages/page_00347
begin
--   Manifest
--     PAGE: 00347
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>347
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'kontenabgleich'
,p_alias=>'KONTENABGLEICH_347'
,p_step_title=>'kontenabgleich'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011155053'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13662460485299972)
,p_plug_name=>'kontenabgleich'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
', kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_bas_kal_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from t_imp_lex_kontenblatt_2018_2 kto2',
' left join t_lex_kontenblatt kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2018 and kto2.kontonummer = kto.kontonummer ',
' left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage= kto.fk_bas_kal_belegdatum',
'  left join t_bas_kal_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13662495446299972)
,p_name=>'kontenabgleich'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15102814721691512
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13662936597299985)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13663296038299992)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13663701406299992)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13664168141299994)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13664481428299994)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13664881203299994)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13665374864299994)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13665748606299995)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13666137432299995)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13557686178839683)
,p_db_column_name=>'JAHR'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13557863328839684)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13557941175839685)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13557990986839686)
,p_db_column_name=>'MISS'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558152207839687)
,p_db_column_name=>'KTO2_HABENBETR'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Kto2 Habenbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558240174839688)
,p_db_column_name=>'KTO2_SOLLBETR'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Kto2 Sollbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558296219839689)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>79
,p_column_identifier=>'P'
,p_column_label=>'Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558399062839690)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>89
,p_column_identifier=>'Q'
,p_column_label=>'Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558507868839691)
,p_db_column_name=>'DIFF_HABEN'
,p_display_order=>99
,p_column_identifier=>'R'
,p_column_label=>'Diff Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558656544839692)
,p_db_column_name=>'DIFF_SOLL'
,p_display_order=>109
,p_column_identifier=>'S'
,p_column_label=>'Diff Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558692352839693)
,p_db_column_name=>'RNR'
,p_display_order=>119
,p_column_identifier=>'T'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286989031362599)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>129
,p_column_identifier=>'U'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14287131910362600)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>139
,p_column_identifier=>'V'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14287209713362601)
,p_db_column_name=>'RNR1'
,p_display_order=>149
,p_column_identifier=>'W'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14287342123362602)
,p_db_column_name=>'ID'
,p_display_order=>159
,p_column_identifier=>'X'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14287551972362604)
,p_db_column_name=>'DATUM'
,p_display_order=>179
,p_column_identifier=>'Z'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14287669443362605)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>189
,p_column_identifier=>'AA'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23186997557290749)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>199
,p_column_identifier=>'AB'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13666694575303764)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'151071'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KTO2_BUCH:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGKTO2_MISS:KTO2_HABENBETR:KTO2_SOLLBETR:HABENBETRAG_EUR:SOLLBETRAG_EUR:DIFF_HABEN:DIFF_SOLL:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:DATUM:JAH'
||'R_IST:PK_BAS_KAL_ARBEITSTAGE'
,p_break_on=>'KTO2_BUCH'
,p_break_enabled_on=>'KTO2_BUCH'
,p_count_columns_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14536709081247278)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_name=>'diff_jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF_JAHR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DIFF_JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14537096729247278)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_name=>'dupl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RNR1'
,p_operator=>'>'
,p_expr=>'1'
,p_condition_sql=>' (case when ("RNR1" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F2D9F2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14536295638247278)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_name=>'missing'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("BUCHUNGSNUMMER" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>25
,p_row_bg_color=>'#F0D9D3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14535110276247277)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>'"BUCHUNGSNUMMER" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14535492987247277)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KTO2_KONTO'
,p_operator=>'contains'
,p_expr=>'1600'
,p_condition_sql=>'upper("KTO2_KONTO") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1600  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14535934458247277)
,p_report_id=>wwv_flow_api.id(13666694575303764)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MISS'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"MISS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.component_end;
end;
/
