prompt --application/pages/page_00210
begin
--   Manifest
--     PAGE: 00210
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>210
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Inventare_bild'
,p_alias=>'INVENTARE_BILD_210'
,p_step_title=>'Inventare_bild'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42870062622330169)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011153307'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(72727053849428122)
,p_plug_name=>'Inventar_Bild'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_inv_Inventar,',
'       length(BILD) bild',
'from t_inv_inventare',
'where PK_inv_inventar =:P210_PK_Inventar'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(72727065685428122)
,p_name=>'Kontoauszug_Bild'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>82037200925849043
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7778424920774930)
,p_db_column_name=>'BILD'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_INVENTARE:BILD:PK_INVENTAR::::::inline::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50727740099514970)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(72731396888496808)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'170889'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>':PK_IMP_BA_SOFTWARE1:BILD:PK_INV_INVENTAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7779231236774947)
,p_name=>'P210_PK_INV_INVENTAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(72727053849428122)
,p_prompt=>'Pk inventar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
