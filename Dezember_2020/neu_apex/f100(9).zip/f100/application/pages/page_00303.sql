prompt --application/pages/page_00303
begin
--   Manifest
--     PAGE: 00303
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>303
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'vorsteuerabzug'
,p_alias=>'VORSTEUERABZUG_303'
,p_step_title=>'vorsteuerabzug'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42881936682393325)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011160558'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7002169654079575)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26519936145361645)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7461572791258600)
,p_plug_name=>'vorsteuerabzug'
,p_parent_plug_id=>wwv_flow_api.id(26519936145361645)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zus.FK_MAIN_KEY,',
'       ID,',
'       "Buchungstag",',
'       "Betrag",',
'       Waehrung,',
'       Fremdwaehrungsbetrag,',
'       Fremdwaehrung,',
'       nvl(BUCHUNGSTEXT,''-'') BUCHUNGSTEXT,',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       FK_std_kto_Kontotyp,',
'       FK_bas_kal_BUCHUNGSTAG,',
'       FK_bas_kal_WERTSTELLUNG,',
'       VERWENDUNGSZWECK,',
'       KATEGORIE,',
'       BUCHT_TAG,',
'       BUCHT_MONAT,',
'       BUCHT_JAHR,',
'       BUCHT_DATUM,',
'       WERTT_TAG,',
'       WERTT_MONAT,',
'       WERTT_JAHR,',
'       WERTT_DATUM,',
'       Kontotyp,',
'       FK_kto_VORGANG,',
'       WIEDERHOLUNG,',
'       NAECHSTE_ZAHLUNG,',
'       FK_BUCHUNG_STEUER,',
'       FK_kto_bankKONTO,',
'       KTO_BEZEICHNUNG,',
'       IBAN,',
'       BANK,',
'       case when fk_lex_relation is not null then 1 else 0 end exist_fk_lex_relation,',
'       fk_lex_relation,',
'       datum_lex_buchung_ok',
'  from V_kto_KONTEN_ZUS zus',
'   left join (select listagg(fk_lex_relation || '' ('' || status || '')'' || '' '' || betrag,'','') within group (order by fk_main_key) fk_lex_relation, fk_main_key from t_rel_lex_kto_bel bel left join t_lex_long ll on bel.fk_lex_relation = ll.relation   whe'
||'re fk_main_key is not null group by fk_main_key  ) kto on kto.fk_main_key = zus.fk_main_key',
' where bucht_jahr = :P303_Jahr and bucht_monat = :P303_Monat'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7461665737258600)
,p_name=>'vorsteuerabzug'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>8901985012650140
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462036281258620)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462404162258627)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462873799258627)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7463200432258627)
,p_db_column_name=>'Betrag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7464835382258628)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_FK_MAIN_KEY,P319_PK_INP_BELEGE_ALL:#FK_MAIN_KEY#,'
,p_column_linktext=>'#BUCHUNGSTEXT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467192972258631)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467676672258631)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467991778258631)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7468440502258633)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7468784991258633)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7469235265258633)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7469614002258633)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470046968258633)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470430260258633)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470783225258635)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7472041093258635)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7472846314258636)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7473261285258636)
,p_db_column_name=>'IBAN'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003685791079591)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>59
,p_column_identifier=>'AF'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003787054079592)
,p_db_column_name=>'BANK'
,p_display_order=>69
,p_column_identifier=>'AG'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003971882079593)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>79
,p_column_identifier=>'AH'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975167240293512)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>89
,p_column_identifier=>'AK'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975244666293513)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>99
,p_column_identifier=>'AL'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975361139293514)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>109
,p_column_identifier=>'AM'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975422238293515)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>119
,p_column_identifier=>'AN'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975541448293516)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>129
,p_column_identifier=>'AO'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975620549293517)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>139
,p_column_identifier=>'AP'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975764336293518)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>149
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975893740293519)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>159
,p_column_identifier=>'AR'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22975963758293520)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>169
,p_column_identifier=>'AS'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22976088931293521)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>179
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22976166873293522)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>189
,p_column_identifier=>'AU'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22976226624293523)
,p_db_column_name=>'EXIST_FK_LEX_RELATION'
,p_display_order=>199
,p_column_identifier=>'AV'
,p_column_label=>'Exist Fk Lex Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22976378786293524)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>209
,p_column_identifier=>'AW'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26111756125471439)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>219
,p_column_identifier=>'AX'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7473869422260153)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'89142'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KTO_BEZEICHNUNG:BANK:KATEGORIE:VERWENDUNGSZWECK:FK_MAIN_KEY:ID:Buchungstag:Betrag:BUCHUNGSTEXT:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:WIEDERHOLUNG:FK_BUCHUNG_STEUER:IBAN:NAECHSTE_ZAHLUNG::WAEHRUNGSBE'
||'TRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:FK_KTO_BANKKONTO:EXIST_FK_LEX_RELATION:FK_LEX_RELATION:DATUM_LEX_BUCHUNG_OK'
,p_sort_column_1=>'DATUM_LEX_BUCHUNG_OK'
,p_sort_direction_1=>'DESC NULLS FIRST'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'DATUM_LEX_BUCHUNG_OK:0:WIEDERHOLUNG:0:0:0'
,p_break_enabled_on=>'DATUM_LEX_BUCHUNG_OK:0:WIEDERHOLUNG:0:0:0'
,p_sum_columns_on_break=>'Betrag'
,p_count_columns_on_break=>'FK_MAIN_KEY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26923877152651893)
,p_report_id=>wwv_flow_api.id(7473869422260153)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_LEX_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26520005726361646)
,p_plug_name=>'Belege nach Monat'
,p_parent_plug_id=>wwv_flow_api.id(26519936145361645)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select arb.jahr, arb.monat,vinp.*,',
'DATUM_ORT_OK,',
'DATUM_ADDRESSE_OK,',
'DATUM_BUSSGELD_OK,',
'DATUM_BELEG_POS_OK,',
'DATUM_BUCHUNG_OK,',
'DATUM_VERPFL_BEL_OK',
'from v_inp_belegE_all vinp ',
' join t_inp_belege_all inp on vinp.pk_inp_belege_all = inp.pk_inp_belege_all',
' left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.FK_BAS_KAL_ARBEITSTAG',
' where (arb.jahr = :P303_jahr and arb.monat = :P303_monat) ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Belege nach Monat'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26520267957361648)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.::P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>26520267957361648
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26520376607361649)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26520496676361650)
,p_db_column_name=>'MONAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26671640944103502)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26671749037103503)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26671813299103504)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26671989612103505)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672080563103506)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672190661103507)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672200700103508)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672323635103509)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672409731103510)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672547975103511)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672682321103512)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672791185103513)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672893030103514)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26672945303103515)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673044117103516)
,p_db_column_name=>'VON'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673145909103517)
,p_db_column_name=>'BIS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673289418103518)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673306044103519)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673480539103520)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673595200103521)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673633302103522)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673702545103523)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673825908103524)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26673972138103525)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674086905103526)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674135388103527)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674279170103528)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674329665103529)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674419110103530)
,p_db_column_name=>'BELEG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674560322103531)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674619360103532)
,p_db_column_name=>'LITER'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674799780103533)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674860886103534)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26674950890103535)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675042619103536)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675178830103537)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675297200103538)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675353082103539)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675418942103540)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675535502103541)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675648417103542)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675769117103543)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675801014103544)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26675980060103545)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676026770103546)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676159211103547)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676240302103548)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676393237103549)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676475529103550)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676540985115201)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676631354115202)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676718275115203)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676854560115204)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26676976819115205)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677066510115206)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677147935115207)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677289166115208)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677362098115209)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677425474115210)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677575017115211)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677635786115212)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677717164115213)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677872680115214)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26677990321115215)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678038724115216)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678152094115217)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678244021115218)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678387062115219)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678411403115220)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678501349115221)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678682017115222)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678755801115223)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678831124115224)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26678955957115225)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679013991115226)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679194084115227)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679210340115228)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679332046115229)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679407130115230)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679527163115231)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679674873115232)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679797213115233)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679861523115234)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26679909042115235)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680063879115236)
,p_db_column_name=>'ZAHL_ART_VAL'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Zahl Art Val'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680172137115237)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680296689115238)
,p_db_column_name=>'LA_WDH_VALUE'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'La Wdh Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680348230115239)
,p_db_column_name=>'LA_WDH_NAME'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'La Wdh Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680403555115240)
,p_db_column_name=>'STA_VALUE'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Sta Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680500348115241)
,p_db_column_name=>'STA_NAME'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Sta Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680640687115242)
,p_db_column_name=>'BEL_EX_VALUE'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Bel Ex Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680744124115243)
,p_db_column_name=>'BEL_EX_NAME'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Bel Ex Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680817672115244)
,p_db_column_name=>'PROJ_PK_PROJ_PROJEKT'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Proj Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26680951822115245)
,p_db_column_name=>'PROJ_FK_KON_AUFTRAGGEBER'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Proj Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681071195115246)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_1'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Proj Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681196165115247)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_2'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Proj Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681239277115248)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681357747115249)
,p_db_column_name=>'PROJ_VON'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Proj Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681426390115250)
,p_db_column_name=>'PROJ_BIS'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Proj Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681501055115201)
,p_db_column_name=>'PROJ_AKTUELLER_STUNDENSATZ'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Proj Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681678263115202)
,p_db_column_name=>'PROJ_PSP_ELEMENT'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Proj Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681713201115203)
,p_db_column_name=>'PROJ_CREATED_BY'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Proj Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681881631115204)
,p_db_column_name=>'PROJ_CREATED_AT'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Proj Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26681925273115205)
,p_db_column_name=>'PROJ_MODIFIED_BY'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Proj Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682005166115206)
,p_db_column_name=>'PROJ_MODIFIED_AT'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Proj Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682112263115207)
,p_db_column_name=>'PROJ_RECHNUNG_GESTELLT'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Proj Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682246907115208)
,p_db_column_name=>'PROJ_ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Proj Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682312617115209)
,p_db_column_name=>'PROJ_BELEGE_ZUGEORDNET'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Proj Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682489202115210)
,p_db_column_name=>'PROJ_KM_GERECHNET'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Proj Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682589411115211)
,p_db_column_name=>'PROJ_PROJEKT_ABGESCHLOSSEN'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Proj Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682633696115212)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682709095115213)
,p_db_column_name=>'PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Proj Auft Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682830449115214)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNER'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Proj Auft Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26682942765115215)
,p_db_column_name=>'PROJ_AUFT_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Proj Auft Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683006545115216)
,p_db_column_name=>'PROJ_AUFT_PK_ADR_ADRESSE'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Proj Auft Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683168106115217)
,p_db_column_name=>'PROJ_AUFT_STRASSE'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Proj Auft Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683255154115218)
,p_db_column_name=>'PROJ_AUFT_HSNR'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Proj Auft Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683393035115219)
,p_db_column_name=>'PROJ_AUFT_PLZ'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Proj Auft Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683409359115220)
,p_db_column_name=>'PROJ_AUFT_ORT'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Proj Auft Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683577269115221)
,p_db_column_name=>'PROJ_AUFT_LAND'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Proj Auft Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683603219115222)
,p_db_column_name=>'PROJ_AUFT_BESCHREIBUNG'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Proj Auft Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683750504115223)
,p_db_column_name=>'PROJ_AUFT_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Proj Auft Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683878710115224)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNERTYP'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Proj Auft Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26683953121115225)
,p_db_column_name=>'PROJ_PP1_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Proj Pp1 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684027756115226)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNER'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Proj Pp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684182263115227)
,p_db_column_name=>'PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Proj Pp1 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684228483115228)
,p_db_column_name=>'PROJ_PP1_PK_ADR_ADRESSE'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Proj Pp1 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684311866115229)
,p_db_column_name=>'PROJ_PP1_STRASSE'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Proj Pp1 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684432853115230)
,p_db_column_name=>'PROJ_PP1_HSNR'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Proj Pp1 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684525834115231)
,p_db_column_name=>'PROJ_PP1_PLZ'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Proj Pp1 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684674206115232)
,p_db_column_name=>'PROJ_PP1_ORT'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Proj Pp1 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684720020115233)
,p_db_column_name=>'PROJ_PP1_LAND'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Proj Pp1 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684855369115234)
,p_db_column_name=>'PROJ_PP1_BESCHREIBUNG'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Proj Pp1 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26684998616115235)
,p_db_column_name=>'PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Proj Pp1 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685053143115236)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNERTYP'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Proj Pp1 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685105959115237)
,p_db_column_name=>'PROJ_PP2_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Proj Pp2 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685286683115238)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNER'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Proj Pp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685316147115239)
,p_db_column_name=>'PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Proj Pp2 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685419567115240)
,p_db_column_name=>'PROJ_PP2_PK_ADR_ADRESSE'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Proj Pp2 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685518564115241)
,p_db_column_name=>'PROJ_PP2_STRASSE'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Proj Pp2 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685607529115242)
,p_db_column_name=>'PROJ_PP2_HSNR'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Proj Pp2 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685767457115243)
,p_db_column_name=>'PROJ_PP2_PLZ'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Proj Pp2 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685878052115244)
,p_db_column_name=>'PROJ_PP2_ORT'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Proj Pp2 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26685941997115245)
,p_db_column_name=>'PROJ_PP2_LAND'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Proj Pp2 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686078796115246)
,p_db_column_name=>'PROJ_PP2_BESCHREIBUNG'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Proj Pp2 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686195932115247)
,p_db_column_name=>'PROJ_PP2_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Proj Pp2 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686286260115248)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNERTYP'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Proj Pp2 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686337545115249)
,p_db_column_name=>'PK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Pk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686470979115250)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686594305115301)
,p_db_column_name=>'PK_BAS_KAT_KATEGORIE'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Pk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686616853115302)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686786865115303)
,p_db_column_name=>'KTOKAT_NEU_ALT'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Ktokat Neu Alt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686864373115304)
,p_db_column_name=>'KTOKAT_FK_BAS_KAT_OBERKATEGORIE'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Ktokat Fk Bas Kat Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26686978423115305)
,p_db_column_name=>'KTOKAT_VALID'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Ktokat Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687096100115306)
,p_db_column_name=>'ARB_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Arb Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687190264115307)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687204286115308)
,p_db_column_name=>'ARB_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Arb Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687376202115309)
,p_db_column_name=>'ARB_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Arb Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687421371115310)
,p_db_column_name=>'ARB_FK_STD_KAL_FEIERTAG'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Arb Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687569176115311)
,p_db_column_name=>'ARB_FEIERTAG'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Arb Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687639722115312)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687707195115313)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687871309115314)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26687927433115315)
,p_db_column_name=>'ARB_VON_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Arb Von Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688005942115316)
,p_db_column_name=>'ARB_VON_DATUM'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Arb Von Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688117983115317)
,p_db_column_name=>'ARB_VON_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Arb Von Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688238916115318)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Arb Von Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688395378115319)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_FEIERTAG'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Arb Von Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688460106115320)
,p_db_column_name=>'ARB_VON_FEIERTAG'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Arb Von Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688569357115321)
,p_db_column_name=>'ARB_VON_TAG'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Arb Von Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688675995115322)
,p_db_column_name=>'ARB_VON_MONAT'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Arb Von Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688771290115323)
,p_db_column_name=>'ARB_VON_JAHR'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Arb Von Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688892222115324)
,p_db_column_name=>'ARB_BIS_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1750
,p_column_identifier=>'FS'
,p_column_label=>'Arb Bis Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26688968629115325)
,p_db_column_name=>'ARB_BIS_DATUM'
,p_display_order=>1760
,p_column_identifier=>'FT'
,p_column_label=>'Arb Bis Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689042824115326)
,p_db_column_name=>'ARB_BIS_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1770
,p_column_identifier=>'FU'
,p_column_label=>'Arb Bis Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689171501115327)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1780
,p_column_identifier=>'FV'
,p_column_label=>'Arb Bis Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689265893115328)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_FEIERTAG'
,p_display_order=>1790
,p_column_identifier=>'FW'
,p_column_label=>'Arb Bis Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689389525115329)
,p_db_column_name=>'ARB_BIS_FEIERTAG'
,p_display_order=>1800
,p_column_identifier=>'FX'
,p_column_label=>'Arb Bis Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689451392115330)
,p_db_column_name=>'ARB_BIS_TAG'
,p_display_order=>1810
,p_column_identifier=>'FY'
,p_column_label=>'Arb Bis Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689551821115331)
,p_db_column_name=>'ARB_BIS_MONAT'
,p_display_order=>1820
,p_column_identifier=>'FZ'
,p_column_label=>'Arb Bis Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689655208115332)
,p_db_column_name=>'ARB_BIS_JAHR'
,p_display_order=>1830
,p_column_identifier=>'GA'
,p_column_label=>'Arb Bis Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689758569115333)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>1840
,p_column_identifier=>'GB'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689860352115334)
,p_db_column_name=>'LAND'
,p_display_order=>1850
,p_column_identifier=>'GC'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26689928234115335)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>1860
,p_column_identifier=>'GD'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690078962115336)
,p_db_column_name=>'ORT'
,p_display_order=>1870
,p_column_identifier=>'GE'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690140315115337)
,p_db_column_name=>'CI_PK_ADR_LAND'
,p_display_order=>1880
,p_column_identifier=>'GF'
,p_column_label=>'Ci Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690282764115338)
,p_db_column_name=>'CI_LAND'
,p_display_order=>1890
,p_column_identifier=>'GG'
,p_column_label=>'Ci Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690319497115339)
,p_db_column_name=>'STEU_STEUERSATZ'
,p_display_order=>1900
,p_column_identifier=>'GH'
,p_column_label=>'Steu Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690402724115340)
,p_db_column_name=>'STEU_LAND'
,p_display_order=>1910
,p_column_identifier=>'GI'
,p_column_label=>'Steu Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690570749115341)
,p_db_column_name=>'STEU_PK_ADR_LAND'
,p_display_order=>1920
,p_column_identifier=>'GJ'
,p_column_label=>'Steu Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690627429115342)
,p_db_column_name=>'STEU_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1930
,p_column_identifier=>'GK'
,p_column_label=>'Steu Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690779349115343)
,p_db_column_name=>'STEU_ZUS_ST'
,p_display_order=>1940
,p_column_identifier=>'GL'
,p_column_label=>'Steu Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690819215115344)
,p_db_column_name=>'STEU_FRMD_STEUERSATZ'
,p_display_order=>1950
,p_column_identifier=>'GM'
,p_column_label=>'Steu Frmd Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26690972855115345)
,p_db_column_name=>'STEU_FRMD_LAND'
,p_display_order=>1960
,p_column_identifier=>'GN'
,p_column_label=>'Steu Frmd Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691036918115346)
,p_db_column_name=>'STEU_FRMD_PK_ADR_LAND'
,p_display_order=>1970
,p_column_identifier=>'GO'
,p_column_label=>'Steu Frmd Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691166625115347)
,p_db_column_name=>'STEU_FRMD_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1980
,p_column_identifier=>'GP'
,p_column_label=>'Steu Frmd Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691271145115348)
,p_db_column_name=>'STEU_FRMD_ZUS_ST'
,p_display_order=>1990
,p_column_identifier=>'GQ'
,p_column_label=>'Steu Frmd Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691380118115349)
,p_db_column_name=>'PK_BAS_MON_WAEHRUNG'
,p_display_order=>2000
,p_column_identifier=>'GR'
,p_column_label=>'Pk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691413480115350)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>2010
,p_column_identifier=>'GS'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691547358115301)
,p_db_column_name=>'WAEHRUNG_LANG'
,p_display_order=>2020
,p_column_identifier=>'GT'
,p_column_label=>'Waehrung Lang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691666403115302)
,p_db_column_name=>'COMM'
,p_display_order=>2030
,p_column_identifier=>'GU'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691734337115303)
,p_db_column_name=>'ABL_ORD_J_PAGE_NUMBER'
,p_display_order=>2040
,p_column_identifier=>'GV'
,p_column_label=>'Abl Ord J Page Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691807854115304)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>2050
,p_column_identifier=>'GW'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26691930082115305)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>2060
,p_column_identifier=>'GX'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692099139115306)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>2070
,p_column_identifier=>'GY'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692194525115307)
,p_db_column_name=>'ABL_ORD_ORDNER_NAME'
,p_display_order=>2080
,p_column_identifier=>'GZ'
,p_column_label=>'Abl Ord Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692247304115308)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER'
,p_display_order=>2090
,p_column_identifier=>'HA'
,p_column_label=>'Abl Ord Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692381276115309)
,p_db_column_name=>'VBEL_ART'
,p_display_order=>2100
,p_column_identifier=>'HB'
,p_column_label=>'Vbel Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692446775115310)
,p_db_column_name=>'VBEL_FK_IMP_BA_BEL'
,p_display_order=>2110
,p_column_identifier=>'HC'
,p_column_label=>'Vbel Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692540907115311)
,p_db_column_name=>'VBEL_PK_IMP_BA_ALLG_BEL'
,p_display_order=>2120
,p_column_identifier=>'HD'
,p_column_label=>'Vbel Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692635245115312)
,p_db_column_name=>'VBEL_BEZEICHNUNG'
,p_display_order=>2130
,p_column_identifier=>'HE'
,p_column_label=>'Vbel Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692755247115313)
,p_db_column_name=>'VBEL_KENNZEICHEN'
,p_display_order=>2140
,p_column_identifier=>'HF'
,p_column_label=>'Vbel Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692805830115314)
,p_db_column_name=>'VBEL_DATUM'
,p_display_order=>2150
,p_column_identifier=>'HG'
,p_column_label=>'Vbel Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26692980022115315)
,p_db_column_name=>'VBEL_DATUM_VERGEHEN'
,p_display_order=>2160
,p_column_identifier=>'HH'
,p_column_label=>'Vbel Datum Vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693058266115316)
,p_db_column_name=>'VBEL_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>2170
,p_column_identifier=>'HI'
,p_column_label=>'Vbel Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693196551115317)
,p_db_column_name=>'VBEL_FK_KTO_BUCHUNG'
,p_display_order=>2180
,p_column_identifier=>'HJ'
,p_column_label=>'Vbel Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693268687115318)
,p_db_column_name=>'VBEL_BETRAG'
,p_display_order=>2190
,p_column_identifier=>'HK'
,p_column_label=>'Vbel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693324410115319)
,p_db_column_name=>'VBEL_WAEHRUNG'
,p_display_order=>2200
,p_column_identifier=>'HL'
,p_column_label=>'Vbel Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693495129115320)
,p_db_column_name=>'VBEL_STEUERSATZ'
,p_display_order=>2210
,p_column_identifier=>'HM'
,p_column_label=>'Vbel Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693558735115321)
,p_db_column_name=>'VBEL_MWST_BETRAG'
,p_display_order=>2220
,p_column_identifier=>'HN'
,p_column_label=>'Vbel Mwst Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693625712115322)
,p_db_column_name=>'VBEL_NETTO'
,p_display_order=>2230
,p_column_identifier=>'HO'
,p_column_label=>'Vbel Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693705942115323)
,p_db_column_name=>'VBEL_ZAHLUNGSART'
,p_display_order=>2240
,p_column_identifier=>'HP'
,p_column_label=>'Vbel Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693869368115324)
,p_db_column_name=>'VBEL_BILD'
,p_display_order=>2250
,p_column_identifier=>'HQ'
,p_column_label=>'Vbel Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26693924835115325)
,p_db_column_name=>'VBEL_BILD1'
,p_display_order=>2260
,p_column_identifier=>'HR'
,p_column_label=>'Vbel Bild1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694020447115326)
,p_db_column_name=>'VBEL_VERWENDUNGSZWECK'
,p_display_order=>2270
,p_column_identifier=>'HS'
,p_column_label=>'Vbel Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694112344115327)
,p_db_column_name=>'VBEL_FK_INV_INVENTAR'
,p_display_order=>2280
,p_column_identifier=>'HT'
,p_column_label=>'Vbel Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694255428115328)
,p_db_column_name=>'VBEL_FK_PROJ_PROJEKT'
,p_display_order=>2290
,p_column_identifier=>'HU'
,p_column_label=>'Vbel Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694385053115329)
,p_db_column_name=>'VBEL_WAEHRUNG_BETRAG'
,p_display_order=>2300
,p_column_identifier=>'HV'
,p_column_label=>'Vbel Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694416306115330)
,p_db_column_name=>'VBEL_FK_BAS_KAT_KATEGORIE'
,p_display_order=>2310
,p_column_identifier=>'HW'
,p_column_label=>'Vbel Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694528992115331)
,p_db_column_name=>'VBEL_KATEGORIE'
,p_display_order=>2320
,p_column_identifier=>'HX'
,p_column_label=>'Vbel Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694694132115332)
,p_db_column_name=>'VBEL_PROJEKT'
,p_display_order=>2330
,p_column_identifier=>'HY'
,p_column_label=>'Vbel Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694715035115333)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>2340
,p_column_identifier=>'HZ'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694820972115334)
,p_db_column_name=>'VBEL_FK_BEL_BELEG_ABLAGE'
,p_display_order=>2350
,p_column_identifier=>'IA'
,p_column_label=>'Vbel Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26694901583115335)
,p_db_column_name=>'IBAN'
,p_display_order=>2360
,p_column_identifier=>'IB'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695018339115336)
,p_db_column_name=>'PK_KTO_BANKKONTO'
,p_display_order=>2370
,p_column_identifier=>'IC'
,p_column_label=>'Pk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695184147115337)
,p_db_column_name=>'BANK'
,p_display_order=>2380
,p_column_identifier=>'ID'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695268684115338)
,p_db_column_name=>'PK_KTO_BANK'
,p_display_order=>2390
,p_column_identifier=>'IE'
,p_column_label=>'Pk Kto Bank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695324910115339)
,p_db_column_name=>'VLOC_PK_LOC_LOCATION'
,p_display_order=>2400
,p_column_identifier=>'IF'
,p_column_label=>'Vloc Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695494978115340)
,p_db_column_name=>'VLOC_LOCATION'
,p_display_order=>2410
,p_column_identifier=>'IG'
,p_column_label=>'Vloc Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695594617115341)
,p_db_column_name=>'VLOC_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2420
,p_column_identifier=>'IH'
,p_column_label=>'Vloc Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695672704115342)
,p_db_column_name=>'VLOC_FK_ADR_ADRESSE'
,p_display_order=>2430
,p_column_identifier=>'II'
,p_column_label=>'Vloc Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695749902115343)
,p_db_column_name=>'VLOC_CREATED_BY'
,p_display_order=>2440
,p_column_identifier=>'IJ'
,p_column_label=>'Vloc Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695805005115344)
,p_db_column_name=>'VLOC_CREATED_AT'
,p_display_order=>2450
,p_column_identifier=>'IK'
,p_column_label=>'Vloc Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26695996844115345)
,p_db_column_name=>'VLOC_MODIFIED_BY'
,p_display_order=>2460
,p_column_identifier=>'IL'
,p_column_label=>'Vloc Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696054533115346)
,p_db_column_name=>'VLOC_MODIFIED_AT'
,p_display_order=>2470
,p_column_identifier=>'IM'
,p_column_label=>'Vloc Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696187830115347)
,p_db_column_name=>'VLOC_LOCATION_TYPE'
,p_display_order=>2480
,p_column_identifier=>'IO'
,p_column_label=>'Vloc Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696298070115348)
,p_db_column_name=>'VLOC_STRASSE'
,p_display_order=>2490
,p_column_identifier=>'IP'
,p_column_label=>'Vloc Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696349453115349)
,p_db_column_name=>'VLOC_HSNR'
,p_display_order=>2500
,p_column_identifier=>'IQ'
,p_column_label=>'Vloc Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696463190115350)
,p_db_column_name=>'VLOC_BESCHREIBUNG'
,p_display_order=>2510
,p_column_identifier=>'IR'
,p_column_label=>'Vloc Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696557542115301)
,p_db_column_name=>'VLOC_COMM'
,p_display_order=>2520
,p_column_identifier=>'IT'
,p_column_label=>'Vloc Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696668165115302)
,p_db_column_name=>'VLOC_POSTFACH'
,p_display_order=>2530
,p_column_identifier=>'IU'
,p_column_label=>'Vloc Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696701025115303)
,p_db_column_name=>'VLOC_PLZ'
,p_display_order=>2540
,p_column_identifier=>'IV'
,p_column_label=>'Vloc Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696805412115304)
,p_db_column_name=>'VLOC_ORT'
,p_display_order=>2550
,p_column_identifier=>'IW'
,p_column_label=>'Vloc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26696941680115305)
,p_db_column_name=>'VLOC_LAND'
,p_display_order=>2560
,p_column_identifier=>'IX'
,p_column_label=>'Vloc Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697096478115306)
,p_db_column_name=>'VLOC_ADR'
,p_display_order=>2570
,p_column_identifier=>'IY'
,p_column_label=>'Vloc Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697196375115307)
,p_db_column_name=>'VLOC_VERG_PK_LOC_LOCATION'
,p_display_order=>2580
,p_column_identifier=>'IZ'
,p_column_label=>'Vloc Verg Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697251261115308)
,p_db_column_name=>'VLOC_VERG_LOCATION'
,p_display_order=>2590
,p_column_identifier=>'JA'
,p_column_label=>'Vloc Verg Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697322400115309)
,p_db_column_name=>'VLOC_VERG_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2600
,p_column_identifier=>'JB'
,p_column_label=>'Vloc Verg Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697419214115310)
,p_db_column_name=>'VLOC_VERG_FK_ADR_ADRESSE'
,p_display_order=>2610
,p_column_identifier=>'JC'
,p_column_label=>'Vloc Verg Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697579685115311)
,p_db_column_name=>'VLOC_VERG_CREATED_BY'
,p_display_order=>2620
,p_column_identifier=>'JD'
,p_column_label=>'Vloc Verg Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697613655115312)
,p_db_column_name=>'VLOC_VERG_CREATED_AT'
,p_display_order=>2630
,p_column_identifier=>'JE'
,p_column_label=>'Vloc Verg Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697760492115313)
,p_db_column_name=>'VLOC_VERG_MODIFIED_BY'
,p_display_order=>2640
,p_column_identifier=>'JF'
,p_column_label=>'Vloc Verg Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697810052115314)
,p_db_column_name=>'VLOC_VERG_MODIFIED_AT'
,p_display_order=>2650
,p_column_identifier=>'JG'
,p_column_label=>'Vloc Verg Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26697916502115315)
,p_db_column_name=>'VLOC_VERG_LOCATION_TYPE'
,p_display_order=>2660
,p_column_identifier=>'JH'
,p_column_label=>'Vloc Verg Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698086055115316)
,p_db_column_name=>'VLOC_VERG_STRASSE'
,p_display_order=>2670
,p_column_identifier=>'JI'
,p_column_label=>'Vloc Verg Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698119606115317)
,p_db_column_name=>'VLOC_VERG_HSNR'
,p_display_order=>2680
,p_column_identifier=>'JJ'
,p_column_label=>'Vloc Verg Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698261408115318)
,p_db_column_name=>'VLOC_VERG_BESCHREIBUNG'
,p_display_order=>2690
,p_column_identifier=>'JK'
,p_column_label=>'Vloc Verg Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698375223115319)
,p_db_column_name=>'VLOC_VERG_COMM'
,p_display_order=>2700
,p_column_identifier=>'JL'
,p_column_label=>'Vloc Verg Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698464128115320)
,p_db_column_name=>'VLOC_VERG_POSTFACH'
,p_display_order=>2710
,p_column_identifier=>'JM'
,p_column_label=>'Vloc Verg Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698583274115321)
,p_db_column_name=>'VLOC_VERG_PLZ'
,p_display_order=>2720
,p_column_identifier=>'JN'
,p_column_label=>'Vloc Verg Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698603705115322)
,p_db_column_name=>'VLOC_VERG_ORT'
,p_display_order=>2730
,p_column_identifier=>'JO'
,p_column_label=>'Vloc Verg Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698748850115323)
,p_db_column_name=>'VLOC_VERG_LAND'
,p_display_order=>2740
,p_column_identifier=>'JP'
,p_column_label=>'Vloc Verg Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698860506115324)
,p_db_column_name=>'VLOC_VERG_ADR'
,p_display_order=>2750
,p_column_identifier=>'JQ'
,p_column_label=>'Vloc Verg Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26698970067115325)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>2760
,p_column_identifier=>'JR'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699031445115326)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>2770
,p_column_identifier=>'JS'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699103468115327)
,p_db_column_name=>'BELEG_STATUS'
,p_display_order=>2780
,p_column_identifier=>'JT'
,p_column_label=>'Beleg Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813099084131908)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>2790
,p_column_identifier=>'JU'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813157350131909)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>2800
,p_column_identifier=>'JV'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813213186131910)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>2810
,p_column_identifier=>'JW'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813349752131911)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>2820
,p_column_identifier=>'JX'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813409583131912)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>2830
,p_column_identifier=>'JY'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813561813131913)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>2840
,p_column_identifier=>'JZ'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26786543167118115)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'267866'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_BUCHUNG_OK:JAHR:MONAT:DATUM_ADDRESSE_OK:DATUM_BELEG_POS_OK:DATUM_BUSSGELD_OK:DATUM_ORT_OK:DATUM_VERPFL_BEL_OK:PK_INP_BELEGE_ALL:BELEGNUMMER:BEZEICHNUNG:FK_LEX_BUCHUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGS'
||'ART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_WAEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM'
||'_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BR'
||'UTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_'
||'MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_STATUS:COMM_VERGEHEN:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:'
||'VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AK'
||'TENZEICHEN:VERG_TATBESTANDSNUMMER:ZAHL_ART_VAL:ZAHL_ART_NAME:LA_WDH_VALUE:LA_WDH_NAME:STA_VALUE:STA_NAME:BEL_EX_VALUE:BEL_EX_NAME:PROJ_PK_PROJ_PROJEKT:PROJ_FK_KON_AUFTRAGGEBER:PROJ_FK_KON_PROJEKTPARTNER_1:PROJ_FK_KON_PROJEKTPARTNER_2:PROJ_PROJEKT:PRO'
||'J_VON:PROJ_BIS:PROJ_AKTUELLER_STUNDENSATZ:PROJ_PSP_ELEMENT:PROJ_CREATED_BY:PROJ_CREATED_AT:PROJ_MODIFIED_BY:PROJ_MODIFIED_AT:PROJ_RECHNUNG_GESTELLT:PROJ_ZAHLUNG_ABGESCHLOSSEN:PROJ_BELEGE_ZUGEORDNET:PROJ_KM_GERECHNET:PROJ_PROJEKT_ABGESCHLOSSEN:PROJ_PR'
||'OJEKT_ART:PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER:PROJ_AUFT_GESCHAEFTSPARTNER:PROJ_AUFT_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_AUFT_PK_ADR_ADRESSE:PROJ_AUFT_STRASSE:PROJ_AUFT_HSNR:PROJ_AUFT_PLZ:PROJ_AUFT_ORT:PROJ_AUFT_LAND:PROJ_AUFT_BESCHREIBUNG:PROJ_AUFT_P'
||'K_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_AUFT_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_KON_GESCHAEFTSPARTNER:PROJ_PP1_GESCHAEFTSPARTNER:PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_ADR_ADRESSE:PROJ_PP1_STRASSE:PROJ_PP1_HSNR:PROJ_PP1_PLZ:PROJ_PP1_ORT:'
||'PROJ_PP1_LAND:PROJ_PP1_BESCHREIBUNG:PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_PP1_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_KON_GESCHAEFTSPARTNER:PROJ_PP2_GESCHAEFTSPARTNER:PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_ADR_ADRESSE:PROJ_PP2_STR'
||'ASSE:PROJ_PP2_HSNR:PROJ_PP2_PLZ:PROJ_PP2_ORT:PROJ_PP2_LAND:PROJ_PP2_BESCHREIBUNG:PROJ_PP2_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_PP2_GESCHAEFTSPARTNERTYP:PK_STD_VERW_VERWENDUNGSZWECK:VERWENDUNGSZWECK:PK_BAS_KAT_KATEGORIE:KTOKAT_KATEGORIE:KTOKAT_NE'
||'U_ALT:KTOKAT_FK_BAS_KAT_OBERKATEGORIE:KTOKAT_VALID:ARB_PK_BAS_KAL_ARBEITSTAGE:ARB_DATUM:ARB_FK_BAS_KAL_ARBEITSTAG:ARB_FK_STD_KAL_WOCHENENDE:ARB_FK_STD_KAL_FEIERTAG:ARB_FEIERTAG:ARB_TAG:ARB_MONAT:ARB_JAHR:ARB_VON_PK_BAS_KAL_ARBEITSTAGE:ARB_VON_DATUM:A'
||'RB_VON_FK_BAS_KAL_ARBEITSTAG:ARB_VON_FK_STD_KAL_WOCHENENDE:ARB_VON_FK_STD_KAL_FEIERTAG:ARB_VON_FEIERTAG:ARB_VON_TAG:ARB_VON_MONAT:ARB_VON_JAHR:ARB_BIS_PK_BAS_KAL_ARBEITSTAGE:ARB_BIS_DATUM:ARB_BIS_FK_BAS_KAL_ARBEITSTAG:ARB_BIS_FK_STD_KAL_WOCHENENDE:AR'
||'B_BIS_FK_STD_KAL_FEIERTAG:ARB_BIS_FEIERTAG:ARB_BIS_TAG:ARB_BIS_MONAT:ARB_BIS_JAHR:PK_ADR_LAND:LAND:PK_ADR_ORT:ORT:CI_PK_ADR_LAND:CI_LAND:STEU_STEUERSATZ:STEU_LAND:STEU_PK_ADR_LAND:STEU_PK_BAS_STEU_STEUER_SATZ:STEU_ZUS_ST:STEU_FRMD_STEUERSATZ:STEU_FRM'
||'D_LAND:STEU_FRMD_PK_ADR_LAND:STEU_FRMD_PK_BAS_STEU_STEUER_SATZ:STEU_FRMD_ZUS_ST:PK_BAS_MON_WAEHRUNG:WAEHRUNG:WAEHRUNG_LANG:COMM:'
,p_break_on=>'DATUM_BUCHUNG_OK'
,p_break_enabled_on=>'DATUM_BUCHUNG_OK'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26913022069309467)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'nok_adresse'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_ADDRESSE_OK'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DATUM_ADDRESSE_OK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26913421021309468)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'nok_beleg_pos'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BELEG_POS_OK'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DATUM_BELEG_POS_OK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26913831334309468)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'ok_buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#59C44B'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26914239905309468)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'nok_bussgeld'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUSSGELD_OK'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DATUM_BUSSGELD_OK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26914606094309468)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'nok_ort'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_ORT_OK'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DATUM_ORT_OK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26915028565309469)
,p_report_id=>wwv_flow_api.id(26786543167118115)
,p_name=>'nok_verpfl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_VERPFL_BEL_OK'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DATUM_VERPFL_BEL_OK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26699252116115328)
,p_plug_name=>'Belege nach Monat ohne Angabe'
,p_parent_plug_id=>wwv_flow_api.id(26519936145361645)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select arb.jahr, arb.monat,vinp.*',
'from v_inp_belegE_all vinp ',
' join t_inp_belege_all inp on vinp.pk_inp_belege_all = inp.pk_inp_belege_all',
' left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.FK_BAS_KAL_ARBEITSTAG',
' where (arb.jahr is null  or arb.monat is null) ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Belege nach Monat ohne Angabe'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26699367016115329)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.::P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>26699367016115329
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699424464115330)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699542318115331)
,p_db_column_name=>'MONAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699683315115332)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699743343115333)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699804538115334)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26699947166115335)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700006942115336)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700175578115337)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700279361115338)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700302944115339)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700439588115340)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700514105115341)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700653244115342)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700703450115343)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700879130115344)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26700996734115345)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26701087776115346)
,p_db_column_name=>'VON'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26701162004115347)
,p_db_column_name=>'BIS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26701277029115348)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26701327996115349)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26701491442115350)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787363092131801)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787402057131802)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787573599131803)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787612106131804)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787761497131805)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787847163131806)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26787964340131807)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788068539131808)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788106012131809)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788233085131810)
,p_db_column_name=>'BELEG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788383443131811)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788448001131812)
,p_db_column_name=>'LITER'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788546538131813)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788625341131814)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788784806131815)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788821014131816)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26788942303131817)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789061345131818)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789128482131819)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789216996131820)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789356970131821)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789427958131822)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789533224131823)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789643716131824)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789749422131825)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789859921131826)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26789909644131827)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790001678131828)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790118769131829)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790283048131830)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790393994131831)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790409345131832)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790516899131833)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790652046131834)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790792271131835)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790852902131836)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26790949303131837)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791021389131838)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791189984131839)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791205315131840)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791397947131841)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791431027131842)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791525136131843)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791656630131844)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791712713131845)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791846280131846)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26791998715131847)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792077061131848)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792171821131849)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792255309131850)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792349996131801)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792465878131802)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792500106131803)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792671271131804)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792758527131805)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792882468131806)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26792902976131807)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793067313131808)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793172442131809)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793284524131810)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793337607131811)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793437556131812)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793569023131813)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793642321131814)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793725849131815)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793858368131816)
,p_db_column_name=>'ZAHL_ART_VAL'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Zahl Art Val'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26793947954131817)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794037565131818)
,p_db_column_name=>'LA_WDH_VALUE'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'La Wdh Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794118593131819)
,p_db_column_name=>'LA_WDH_NAME'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'La Wdh Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794274519131820)
,p_db_column_name=>'STA_VALUE'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Sta Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794303115131821)
,p_db_column_name=>'STA_NAME'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Sta Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794476968131822)
,p_db_column_name=>'BEL_EX_VALUE'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Bel Ex Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794583203131823)
,p_db_column_name=>'BEL_EX_NAME'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Bel Ex Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794693423131824)
,p_db_column_name=>'PROJ_PK_PROJ_PROJEKT'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Proj Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794771392131825)
,p_db_column_name=>'PROJ_FK_KON_AUFTRAGGEBER'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Proj Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794810256131826)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_1'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Proj Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26794968703131827)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_2'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Proj Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795088220131828)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795187414131829)
,p_db_column_name=>'PROJ_VON'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Proj Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795272795131830)
,p_db_column_name=>'PROJ_BIS'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Proj Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795305317131831)
,p_db_column_name=>'PROJ_AKTUELLER_STUNDENSATZ'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Proj Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795433557131832)
,p_db_column_name=>'PROJ_PSP_ELEMENT'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Proj Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795576071131833)
,p_db_column_name=>'PROJ_CREATED_BY'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Proj Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795667483131834)
,p_db_column_name=>'PROJ_CREATED_AT'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Proj Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795723573131835)
,p_db_column_name=>'PROJ_MODIFIED_BY'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Proj Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795820869131836)
,p_db_column_name=>'PROJ_MODIFIED_AT'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Proj Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26795923527131837)
,p_db_column_name=>'PROJ_RECHNUNG_GESTELLT'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Proj Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796094562131838)
,p_db_column_name=>'PROJ_ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Proj Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796165601131839)
,p_db_column_name=>'PROJ_BELEGE_ZUGEORDNET'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Proj Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796290361131840)
,p_db_column_name=>'PROJ_KM_GERECHNET'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Proj Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796302101131841)
,p_db_column_name=>'PROJ_PROJEKT_ABGESCHLOSSEN'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Proj Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796485912131842)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796504733131843)
,p_db_column_name=>'PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Proj Auft Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796691499131844)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNER'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Proj Auft Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796711027131845)
,p_db_column_name=>'PROJ_AUFT_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Proj Auft Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796818511131846)
,p_db_column_name=>'PROJ_AUFT_PK_ADR_ADRESSE'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Proj Auft Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26796981263131847)
,p_db_column_name=>'PROJ_AUFT_STRASSE'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Proj Auft Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797090047131848)
,p_db_column_name=>'PROJ_AUFT_HSNR'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Proj Auft Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797121322131849)
,p_db_column_name=>'PROJ_AUFT_PLZ'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Proj Auft Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797266380131850)
,p_db_column_name=>'PROJ_AUFT_ORT'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Proj Auft Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797306700131801)
,p_db_column_name=>'PROJ_AUFT_LAND'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Proj Auft Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797469452131802)
,p_db_column_name=>'PROJ_AUFT_BESCHREIBUNG'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Proj Auft Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797557431131803)
,p_db_column_name=>'PROJ_AUFT_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Proj Auft Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797630146131804)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNERTYP'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Proj Auft Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797749925131805)
,p_db_column_name=>'PROJ_PP1_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Proj Pp1 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797855114131806)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNER'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Proj Pp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26797951343131807)
,p_db_column_name=>'PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Proj Pp1 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798015977131808)
,p_db_column_name=>'PROJ_PP1_PK_ADR_ADRESSE'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Proj Pp1 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798184142131809)
,p_db_column_name=>'PROJ_PP1_STRASSE'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Proj Pp1 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798294178131810)
,p_db_column_name=>'PROJ_PP1_HSNR'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Proj Pp1 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798308397131811)
,p_db_column_name=>'PROJ_PP1_PLZ'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Proj Pp1 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798491978131812)
,p_db_column_name=>'PROJ_PP1_ORT'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Proj Pp1 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798519642131813)
,p_db_column_name=>'PROJ_PP1_LAND'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Proj Pp1 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798642624131814)
,p_db_column_name=>'PROJ_PP1_BESCHREIBUNG'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Proj Pp1 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798787990131815)
,p_db_column_name=>'PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Proj Pp1 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798846996131816)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNERTYP'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Proj Pp1 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26798973350131817)
,p_db_column_name=>'PROJ_PP2_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Proj Pp2 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799042639131818)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNER'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Proj Pp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799125210131819)
,p_db_column_name=>'PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Proj Pp2 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799260954131820)
,p_db_column_name=>'PROJ_PP2_PK_ADR_ADRESSE'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Proj Pp2 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799336826131821)
,p_db_column_name=>'PROJ_PP2_STRASSE'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Proj Pp2 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799495828131822)
,p_db_column_name=>'PROJ_PP2_HSNR'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Proj Pp2 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799520195131823)
,p_db_column_name=>'PROJ_PP2_PLZ'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Proj Pp2 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799644973131824)
,p_db_column_name=>'PROJ_PP2_ORT'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Proj Pp2 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799776252131825)
,p_db_column_name=>'PROJ_PP2_LAND'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Proj Pp2 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799844545131826)
,p_db_column_name=>'PROJ_PP2_BESCHREIBUNG'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Proj Pp2 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26799934504131827)
,p_db_column_name=>'PROJ_PP2_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Proj Pp2 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800033904131828)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNERTYP'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Proj Pp2 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800121450131829)
,p_db_column_name=>'PK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Pk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800247742131830)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800348841131831)
,p_db_column_name=>'PK_BAS_KAT_KATEGORIE'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Pk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800483405131832)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800530891131833)
,p_db_column_name=>'KTOKAT_NEU_ALT'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Ktokat Neu Alt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800652740131834)
,p_db_column_name=>'KTOKAT_FK_BAS_KAT_OBERKATEGORIE'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Ktokat Fk Bas Kat Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800713721131835)
,p_db_column_name=>'KTOKAT_VALID'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Ktokat Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800897466131836)
,p_db_column_name=>'ARB_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Arb Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26800913443131837)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801045510131838)
,p_db_column_name=>'ARB_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Arb Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801187913131839)
,p_db_column_name=>'ARB_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Arb Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801206752131840)
,p_db_column_name=>'ARB_FK_STD_KAL_FEIERTAG'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Arb Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801377924131841)
,p_db_column_name=>'ARB_FEIERTAG'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Arb Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801464797131842)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801583281131843)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801677897131844)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801743108131845)
,p_db_column_name=>'ARB_VON_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Arb Von Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801886276131846)
,p_db_column_name=>'ARB_VON_DATUM'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Arb Von Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26801931289131847)
,p_db_column_name=>'ARB_VON_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Arb Von Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802000594131848)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Arb Von Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802114938131849)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_FEIERTAG'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Arb Von Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802241404131850)
,p_db_column_name=>'ARB_VON_FEIERTAG'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Arb Von Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802337877131801)
,p_db_column_name=>'ARB_VON_TAG'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Arb Von Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802455184131802)
,p_db_column_name=>'ARB_VON_MONAT'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Arb Von Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802599179131803)
,p_db_column_name=>'ARB_VON_JAHR'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Arb Von Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802695120131804)
,p_db_column_name=>'ARB_BIS_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1750
,p_column_identifier=>'FS'
,p_column_label=>'Arb Bis Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802792168131805)
,p_db_column_name=>'ARB_BIS_DATUM'
,p_display_order=>1760
,p_column_identifier=>'FT'
,p_column_label=>'Arb Bis Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802871184131806)
,p_db_column_name=>'ARB_BIS_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1770
,p_column_identifier=>'FU'
,p_column_label=>'Arb Bis Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26802966950131807)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1780
,p_column_identifier=>'FV'
,p_column_label=>'Arb Bis Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803003373131808)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_FEIERTAG'
,p_display_order=>1790
,p_column_identifier=>'FW'
,p_column_label=>'Arb Bis Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803135521131809)
,p_db_column_name=>'ARB_BIS_FEIERTAG'
,p_display_order=>1800
,p_column_identifier=>'FX'
,p_column_label=>'Arb Bis Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803248684131810)
,p_db_column_name=>'ARB_BIS_TAG'
,p_display_order=>1810
,p_column_identifier=>'FY'
,p_column_label=>'Arb Bis Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803383061131811)
,p_db_column_name=>'ARB_BIS_MONAT'
,p_display_order=>1820
,p_column_identifier=>'FZ'
,p_column_label=>'Arb Bis Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803443067131812)
,p_db_column_name=>'ARB_BIS_JAHR'
,p_display_order=>1830
,p_column_identifier=>'GA'
,p_column_label=>'Arb Bis Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803518653131813)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>1840
,p_column_identifier=>'GB'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803616180131814)
,p_db_column_name=>'LAND'
,p_display_order=>1850
,p_column_identifier=>'GC'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803715253131815)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>1860
,p_column_identifier=>'GD'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803848947131816)
,p_db_column_name=>'ORT'
,p_display_order=>1870
,p_column_identifier=>'GE'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26803952192131817)
,p_db_column_name=>'CI_PK_ADR_LAND'
,p_display_order=>1880
,p_column_identifier=>'GF'
,p_column_label=>'Ci Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804012597131818)
,p_db_column_name=>'CI_LAND'
,p_display_order=>1890
,p_column_identifier=>'GG'
,p_column_label=>'Ci Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804167687131819)
,p_db_column_name=>'STEU_STEUERSATZ'
,p_display_order=>1900
,p_column_identifier=>'GH'
,p_column_label=>'Steu Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804232071131820)
,p_db_column_name=>'STEU_LAND'
,p_display_order=>1910
,p_column_identifier=>'GI'
,p_column_label=>'Steu Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804384718131821)
,p_db_column_name=>'STEU_PK_ADR_LAND'
,p_display_order=>1920
,p_column_identifier=>'GJ'
,p_column_label=>'Steu Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804453251131822)
,p_db_column_name=>'STEU_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1930
,p_column_identifier=>'GK'
,p_column_label=>'Steu Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804549777131823)
,p_db_column_name=>'STEU_ZUS_ST'
,p_display_order=>1940
,p_column_identifier=>'GL'
,p_column_label=>'Steu Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804696433131824)
,p_db_column_name=>'STEU_FRMD_STEUERSATZ'
,p_display_order=>1950
,p_column_identifier=>'GM'
,p_column_label=>'Steu Frmd Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804736844131825)
,p_db_column_name=>'STEU_FRMD_LAND'
,p_display_order=>1960
,p_column_identifier=>'GN'
,p_column_label=>'Steu Frmd Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804896910131826)
,p_db_column_name=>'STEU_FRMD_PK_ADR_LAND'
,p_display_order=>1970
,p_column_identifier=>'GO'
,p_column_label=>'Steu Frmd Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26804917540131827)
,p_db_column_name=>'STEU_FRMD_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1980
,p_column_identifier=>'GP'
,p_column_label=>'Steu Frmd Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805045756131828)
,p_db_column_name=>'STEU_FRMD_ZUS_ST'
,p_display_order=>1990
,p_column_identifier=>'GQ'
,p_column_label=>'Steu Frmd Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805168647131829)
,p_db_column_name=>'PK_BAS_MON_WAEHRUNG'
,p_display_order=>2000
,p_column_identifier=>'GR'
,p_column_label=>'Pk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805208462131830)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>2010
,p_column_identifier=>'GS'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805342795131831)
,p_db_column_name=>'WAEHRUNG_LANG'
,p_display_order=>2020
,p_column_identifier=>'GT'
,p_column_label=>'Waehrung Lang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805475196131832)
,p_db_column_name=>'COMM'
,p_display_order=>2030
,p_column_identifier=>'GU'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805539124131833)
,p_db_column_name=>'ABL_ORD_J_PAGE_NUMBER'
,p_display_order=>2040
,p_column_identifier=>'GV'
,p_column_label=>'Abl Ord J Page Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805647033131834)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>2050
,p_column_identifier=>'GW'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805788947131835)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>2060
,p_column_identifier=>'GX'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805828600131836)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>2070
,p_column_identifier=>'GY'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26805917228131837)
,p_db_column_name=>'ABL_ORD_ORDNER_NAME'
,p_display_order=>2080
,p_column_identifier=>'GZ'
,p_column_label=>'Abl Ord Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806042294131838)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER'
,p_display_order=>2090
,p_column_identifier=>'HA'
,p_column_label=>'Abl Ord Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806186875131839)
,p_db_column_name=>'VBEL_ART'
,p_display_order=>2100
,p_column_identifier=>'HB'
,p_column_label=>'Vbel Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806272961131840)
,p_db_column_name=>'VBEL_FK_IMP_BA_BEL'
,p_display_order=>2110
,p_column_identifier=>'HC'
,p_column_label=>'Vbel Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806397093131841)
,p_db_column_name=>'VBEL_PK_IMP_BA_ALLG_BEL'
,p_display_order=>2120
,p_column_identifier=>'HD'
,p_column_label=>'Vbel Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806450493131842)
,p_db_column_name=>'VBEL_BEZEICHNUNG'
,p_display_order=>2130
,p_column_identifier=>'HE'
,p_column_label=>'Vbel Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806505895131843)
,p_db_column_name=>'VBEL_KENNZEICHEN'
,p_display_order=>2140
,p_column_identifier=>'HF'
,p_column_label=>'Vbel Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806636125131844)
,p_db_column_name=>'VBEL_DATUM'
,p_display_order=>2150
,p_column_identifier=>'HG'
,p_column_label=>'Vbel Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806727086131845)
,p_db_column_name=>'VBEL_DATUM_VERGEHEN'
,p_display_order=>2160
,p_column_identifier=>'HH'
,p_column_label=>'Vbel Datum Vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806867821131846)
,p_db_column_name=>'VBEL_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>2170
,p_column_identifier=>'HI'
,p_column_label=>'Vbel Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26806929232131847)
,p_db_column_name=>'VBEL_FK_KTO_BUCHUNG'
,p_display_order=>2180
,p_column_identifier=>'HJ'
,p_column_label=>'Vbel Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807081289131848)
,p_db_column_name=>'VBEL_BETRAG'
,p_display_order=>2190
,p_column_identifier=>'HK'
,p_column_label=>'Vbel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807137001131849)
,p_db_column_name=>'VBEL_WAEHRUNG'
,p_display_order=>2200
,p_column_identifier=>'HL'
,p_column_label=>'Vbel Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807288449131850)
,p_db_column_name=>'VBEL_STEUERSATZ'
,p_display_order=>2210
,p_column_identifier=>'HM'
,p_column_label=>'Vbel Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807371412131901)
,p_db_column_name=>'VBEL_MWST_BETRAG'
,p_display_order=>2220
,p_column_identifier=>'HN'
,p_column_label=>'Vbel Mwst Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807457042131902)
,p_db_column_name=>'VBEL_NETTO'
,p_display_order=>2230
,p_column_identifier=>'HO'
,p_column_label=>'Vbel Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807532147131903)
,p_db_column_name=>'VBEL_ZAHLUNGSART'
,p_display_order=>2240
,p_column_identifier=>'HP'
,p_column_label=>'Vbel Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807630415131904)
,p_db_column_name=>'VBEL_BILD'
,p_display_order=>2250
,p_column_identifier=>'HQ'
,p_column_label=>'Vbel Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807724412131905)
,p_db_column_name=>'VBEL_BILD1'
,p_display_order=>2260
,p_column_identifier=>'HR'
,p_column_label=>'Vbel Bild1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807840549131906)
,p_db_column_name=>'VBEL_VERWENDUNGSZWECK'
,p_display_order=>2270
,p_column_identifier=>'HS'
,p_column_label=>'Vbel Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26807977160131907)
,p_db_column_name=>'VBEL_FK_INV_INVENTAR'
,p_display_order=>2280
,p_column_identifier=>'HT'
,p_column_label=>'Vbel Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808000014131908)
,p_db_column_name=>'VBEL_FK_PROJ_PROJEKT'
,p_display_order=>2290
,p_column_identifier=>'HU'
,p_column_label=>'Vbel Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808141948131909)
,p_db_column_name=>'VBEL_WAEHRUNG_BETRAG'
,p_display_order=>2300
,p_column_identifier=>'HV'
,p_column_label=>'Vbel Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808216353131910)
,p_db_column_name=>'VBEL_FK_BAS_KAT_KATEGORIE'
,p_display_order=>2310
,p_column_identifier=>'HW'
,p_column_label=>'Vbel Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808356677131911)
,p_db_column_name=>'VBEL_KATEGORIE'
,p_display_order=>2320
,p_column_identifier=>'HX'
,p_column_label=>'Vbel Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808474211131912)
,p_db_column_name=>'VBEL_PROJEKT'
,p_display_order=>2330
,p_column_identifier=>'HY'
,p_column_label=>'Vbel Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808504798131913)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>2340
,p_column_identifier=>'HZ'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808627051131914)
,p_db_column_name=>'VBEL_FK_BEL_BELEG_ABLAGE'
,p_display_order=>2350
,p_column_identifier=>'IA'
,p_column_label=>'Vbel Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808715949131915)
,p_db_column_name=>'IBAN'
,p_display_order=>2360
,p_column_identifier=>'IB'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808855153131916)
,p_db_column_name=>'PK_KTO_BANKKONTO'
,p_display_order=>2370
,p_column_identifier=>'IC'
,p_column_label=>'Pk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26808909070131917)
,p_db_column_name=>'BANK'
,p_display_order=>2380
,p_column_identifier=>'ID'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809061480131918)
,p_db_column_name=>'PK_KTO_BANK'
,p_display_order=>2390
,p_column_identifier=>'IE'
,p_column_label=>'Pk Kto Bank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809185285131919)
,p_db_column_name=>'VLOC_PK_LOC_LOCATION'
,p_display_order=>2400
,p_column_identifier=>'IF'
,p_column_label=>'Vloc Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809263720131920)
,p_db_column_name=>'VLOC_LOCATION'
,p_display_order=>2410
,p_column_identifier=>'IG'
,p_column_label=>'Vloc Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809385984131921)
,p_db_column_name=>'VLOC_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2420
,p_column_identifier=>'IH'
,p_column_label=>'Vloc Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809408722131922)
,p_db_column_name=>'VLOC_FK_ADR_ADRESSE'
,p_display_order=>2430
,p_column_identifier=>'II'
,p_column_label=>'Vloc Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809544688131923)
,p_db_column_name=>'VLOC_CREATED_BY'
,p_display_order=>2440
,p_column_identifier=>'IJ'
,p_column_label=>'Vloc Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809676834131924)
,p_db_column_name=>'VLOC_CREATED_AT'
,p_display_order=>2450
,p_column_identifier=>'IK'
,p_column_label=>'Vloc Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809726395131925)
,p_db_column_name=>'VLOC_MODIFIED_BY'
,p_display_order=>2460
,p_column_identifier=>'IL'
,p_column_label=>'Vloc Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809844972131926)
,p_db_column_name=>'VLOC_MODIFIED_AT'
,p_display_order=>2470
,p_column_identifier=>'IM'
,p_column_label=>'Vloc Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26809953378131927)
,p_db_column_name=>'VLOC_LOCATION_TYPE'
,p_display_order=>2480
,p_column_identifier=>'IO'
,p_column_label=>'Vloc Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810095917131928)
,p_db_column_name=>'VLOC_STRASSE'
,p_display_order=>2490
,p_column_identifier=>'IP'
,p_column_label=>'Vloc Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810178279131929)
,p_db_column_name=>'VLOC_HSNR'
,p_display_order=>2500
,p_column_identifier=>'IQ'
,p_column_label=>'Vloc Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810249401131930)
,p_db_column_name=>'VLOC_BESCHREIBUNG'
,p_display_order=>2510
,p_column_identifier=>'IR'
,p_column_label=>'Vloc Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810350412131931)
,p_db_column_name=>'VLOC_COMM'
,p_display_order=>2520
,p_column_identifier=>'IT'
,p_column_label=>'Vloc Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810470892131932)
,p_db_column_name=>'VLOC_POSTFACH'
,p_display_order=>2530
,p_column_identifier=>'IU'
,p_column_label=>'Vloc Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810519305131933)
,p_db_column_name=>'VLOC_PLZ'
,p_display_order=>2540
,p_column_identifier=>'IV'
,p_column_label=>'Vloc Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810670537131934)
,p_db_column_name=>'VLOC_ORT'
,p_display_order=>2550
,p_column_identifier=>'IW'
,p_column_label=>'Vloc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810707071131935)
,p_db_column_name=>'VLOC_LAND'
,p_display_order=>2560
,p_column_identifier=>'IX'
,p_column_label=>'Vloc Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810839675131936)
,p_db_column_name=>'VLOC_ADR'
,p_display_order=>2570
,p_column_identifier=>'IY'
,p_column_label=>'Vloc Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26810952346131937)
,p_db_column_name=>'VLOC_VERG_PK_LOC_LOCATION'
,p_display_order=>2580
,p_column_identifier=>'IZ'
,p_column_label=>'Vloc Verg Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811020044131938)
,p_db_column_name=>'VLOC_VERG_LOCATION'
,p_display_order=>2590
,p_column_identifier=>'JA'
,p_column_label=>'Vloc Verg Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811195131131939)
,p_db_column_name=>'VLOC_VERG_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2600
,p_column_identifier=>'JB'
,p_column_label=>'Vloc Verg Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811246788131940)
,p_db_column_name=>'VLOC_VERG_FK_ADR_ADRESSE'
,p_display_order=>2610
,p_column_identifier=>'JC'
,p_column_label=>'Vloc Verg Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811353732131941)
,p_db_column_name=>'VLOC_VERG_CREATED_BY'
,p_display_order=>2620
,p_column_identifier=>'JD'
,p_column_label=>'Vloc Verg Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811427081131942)
,p_db_column_name=>'VLOC_VERG_CREATED_AT'
,p_display_order=>2630
,p_column_identifier=>'JE'
,p_column_label=>'Vloc Verg Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811587043131943)
,p_db_column_name=>'VLOC_VERG_MODIFIED_BY'
,p_display_order=>2640
,p_column_identifier=>'JF'
,p_column_label=>'Vloc Verg Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811682410131944)
,p_db_column_name=>'VLOC_VERG_MODIFIED_AT'
,p_display_order=>2650
,p_column_identifier=>'JG'
,p_column_label=>'Vloc Verg Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811771222131945)
,p_db_column_name=>'VLOC_VERG_LOCATION_TYPE'
,p_display_order=>2660
,p_column_identifier=>'JH'
,p_column_label=>'Vloc Verg Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811803611131946)
,p_db_column_name=>'VLOC_VERG_STRASSE'
,p_display_order=>2670
,p_column_identifier=>'JI'
,p_column_label=>'Vloc Verg Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26811944399131947)
,p_db_column_name=>'VLOC_VERG_HSNR'
,p_display_order=>2680
,p_column_identifier=>'JJ'
,p_column_label=>'Vloc Verg Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812017300131948)
,p_db_column_name=>'VLOC_VERG_BESCHREIBUNG'
,p_display_order=>2690
,p_column_identifier=>'JK'
,p_column_label=>'Vloc Verg Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812102202131949)
,p_db_column_name=>'VLOC_VERG_COMM'
,p_display_order=>2700
,p_column_identifier=>'JL'
,p_column_label=>'Vloc Verg Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812231829131950)
,p_db_column_name=>'VLOC_VERG_POSTFACH'
,p_display_order=>2710
,p_column_identifier=>'JM'
,p_column_label=>'Vloc Verg Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812323610131901)
,p_db_column_name=>'VLOC_VERG_PLZ'
,p_display_order=>2720
,p_column_identifier=>'JN'
,p_column_label=>'Vloc Verg Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812461550131902)
,p_db_column_name=>'VLOC_VERG_ORT'
,p_display_order=>2730
,p_column_identifier=>'JO'
,p_column_label=>'Vloc Verg Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812573905131903)
,p_db_column_name=>'VLOC_VERG_LAND'
,p_display_order=>2740
,p_column_identifier=>'JP'
,p_column_label=>'Vloc Verg Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812645632131904)
,p_db_column_name=>'VLOC_VERG_ADR'
,p_display_order=>2750
,p_column_identifier=>'JQ'
,p_column_label=>'Vloc Verg Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812794716131905)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>2760
,p_column_identifier=>'JR'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812894379131906)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>2770
,p_column_identifier=>'JS'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26812933009131907)
,p_db_column_name=>'BELEG_STATUS'
,p_display_order=>2780
,p_column_identifier=>'JT'
,p_column_label=>'Beleg Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26902183721140960)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'269022'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:MONAT:BEL_DATUM:BEZEICHNUNG:PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUMMER:FK_ADR_LAND:FK_ADR_CITY:VON:BI'
||'S:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_WAEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFSAEULE:FK_LOC_LOCA'
||'TION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FR'
||'MDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_STATUS:COMM_VERGEHEN:VERG_BEHOERDE:VERG_CNT'
||'_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSS'
||'GELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZEICHEN:VERG_TATBESTANDSNUMMER:ZAHL_ART_VAL:ZAHL_ART_NAME:LA_WDH_VALUE:LA_WDH_NAME:STA_VALUE:STA_NAME:'
||'BEL_EX_VALUE:BEL_EX_NAME:PROJ_PK_PROJ_PROJEKT:PROJ_FK_KON_AUFTRAGGEBER:PROJ_FK_KON_PROJEKTPARTNER_1:PROJ_FK_KON_PROJEKTPARTNER_2:PROJ_PROJEKT:PROJ_VON:PROJ_BIS:PROJ_AKTUELLER_STUNDENSATZ:PROJ_PSP_ELEMENT:PROJ_CREATED_BY:PROJ_CREATED_AT:PROJ_MODIFIED_'
||'BY:PROJ_MODIFIED_AT:PROJ_RECHNUNG_GESTELLT:PROJ_ZAHLUNG_ABGESCHLOSSEN:PROJ_BELEGE_ZUGEORDNET:PROJ_KM_GERECHNET:PROJ_PROJEKT_ABGESCHLOSSEN:PROJ_PROJEKT_ART:PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER:PROJ_AUFT_GESCHAEFTSPARTNER:PROJ_AUFT_FK_BAS_KON_GESCHAEFTSP'
||'ARTNERTYP:PROJ_AUFT_PK_ADR_ADRESSE:PROJ_AUFT_STRASSE:PROJ_AUFT_HSNR:PROJ_AUFT_PLZ:PROJ_AUFT_ORT:PROJ_AUFT_LAND:PROJ_AUFT_BESCHREIBUNG:PROJ_AUFT_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_AUFT_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_KON_GESCHAEFTSPARTNER:PROJ'
||'_PP1_GESCHAEFTSPARTNER:PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_ADR_ADRESSE:PROJ_PP1_STRASSE:PROJ_PP1_HSNR:PROJ_PP1_PLZ:PROJ_PP1_ORT:PROJ_PP1_LAND:PROJ_PP1_BESCHREIBUNG:PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_PP1_GESCHAEFTSPART'
||'NERTYP:PROJ_PP2_PK_KON_GESCHAEFTSPARTNER:PROJ_PP2_GESCHAEFTSPARTNER:PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_ADR_ADRESSE:PROJ_PP2_STRASSE:PROJ_PP2_HSNR:PROJ_PP2_PLZ:PROJ_PP2_ORT:PROJ_PP2_LAND:PROJ_PP2_BESCHREIBUNG:PROJ_PP2_PK_REL_KON_GESC'
||'HAEFTSPARTNER_KONTAKT:PROJ_PP2_GESCHAEFTSPARTNERTYP:PK_STD_VERW_VERWENDUNGSZWECK:VERWENDUNGSZWECK:PK_BAS_KAT_KATEGORIE:KTOKAT_KATEGORIE:KTOKAT_NEU_ALT:KTOKAT_FK_BAS_KAT_OBERKATEGORIE:KTOKAT_VALID:ARB_PK_BAS_KAL_ARBEITSTAGE:ARB_DATUM:ARB_FK_BAS_KAL_AR'
||'BEITSTAG:ARB_FK_STD_KAL_WOCHENENDE:ARB_FK_STD_KAL_FEIERTAG:ARB_FEIERTAG:ARB_TAG:ARB_MONAT:ARB_JAHR:ARB_VON_PK_BAS_KAL_ARBEITSTAGE:ARB_VON_DATUM:ARB_VON_FK_BAS_KAL_ARBEITSTAG:ARB_VON_FK_STD_KAL_WOCHENENDE:ARB_VON_FK_STD_KAL_FEIERTAG:ARB_VON_FEIERTAG:A'
||'RB_VON_TAG:ARB_VON_MONAT:ARB_VON_JAHR:ARB_BIS_PK_BAS_KAL_ARBEITSTAGE:ARB_BIS_DATUM:ARB_BIS_FK_BAS_KAL_ARBEITSTAG:ARB_BIS_FK_STD_KAL_WOCHENENDE:ARB_BIS_FK_STD_KAL_FEIERTAG:ARB_BIS_FEIERTAG:ARB_BIS_TAG:ARB_BIS_MONAT:ARB_BIS_JAHR:PK_ADR_LAND:LAND:PK_ADR'
||'_ORT:ORT:CI_PK_ADR_LAND:CI_LAND:STEU_STEUERSATZ:STEU_LAND:STEU_PK_ADR_LAND:STEU_PK_BAS_STEU_STEUER_SATZ:STEU_ZUS_ST:STEU_FRMD_STEUERSATZ:STEU_FRMD_LAND:STEU_FRMD_PK_ADR_LAND:STEU_FRMD_PK_BAS_STEU_STEUER_SATZ:STEU_FRMD_ZUS_ST:PK_BAS_MON_WAEHRUNG:WAEHR'
||'UNG:WAEHRUNG_LANG:COMM:ABL_ORD_J_PAGE_NUMBER:ABL_ORD_PK_ABL_ORDNER_PAGE:ABL_ORD_PAGE_NUMBER:ABL_ORD_JAHR:ABL_ORD_ORDNER_NAME:ABL_ORD_PK_ABL_ORDNER:VBEL_ART:VBEL_FK_IMP_BA_BEL:VBEL_PK_IMP_BA_ALLG_BEL:VBEL_BEZEICHNUNG:VBEL_KENNZEICHEN:VBEL_DATUM:'
,p_sort_column_1=>'PK_INP_BELEGE_ALL'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26814311569131921)
,p_plug_name=>'lex_buchungen'
,p_parent_plug_id=>wwv_flow_api.id(26519936145361645)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ll.*, arb.monat arb_monat,arb.jahr arb_jahr, arb.tag arb_tag, pk_bas_kal_arbeitstage',
'from t_lex_long ll',
' left join t_bas_kal_arbeitstage arb on ll.FK_LEX_BELEGDAT =arb.pk_bas_kal_arbeitstage',
'where (arb.monat = :P303_monat and arb.Jahr = :P303_jahr) or pk_bas_kal_arbeitstage is null',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'lex_buchungen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26814461245131922)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>26814461245131922
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814569448131923)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814639599131924)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814736499131925)
,p_db_column_name=>'BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814841568131926)
,p_db_column_name=>'BENUTZER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814912239131927)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815021223131928)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815152762131929)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815258095131930)
,p_db_column_name=>'NR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815390942131931)
,p_db_column_name=>'HABENDM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815485855131932)
,p_db_column_name=>'HABENEUR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815530340131933)
,p_db_column_name=>'HABEN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815679124131934)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815712236131935)
,p_db_column_name=>'RELATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815826586131936)
,p_db_column_name=>'SOLLDM'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26815966939131937)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816086551131938)
,p_db_column_name=>'SOLL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816105492131939)
,p_db_column_name=>'SPERRE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816229793131940)
,p_db_column_name=>'STAPEL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816358493131941)
,p_db_column_name=>'STATUS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816419975131942)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816547519131943)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816607954131944)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816756782131945)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816800564131946)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26816994583131947)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26817006375131948)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26817115236131949)
,p_db_column_name=>'UST_DM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26817250168131950)
,p_db_column_name=>'UST_EUR'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001485141970301)
,p_db_column_name=>'UST'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001564452970302)
,p_db_column_name=>'UST_KTO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001689891970303)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001784141970304)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001866024970305)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27001926380970306)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002089083970307)
,p_db_column_name=>'PERIODE'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002102774970308)
,p_db_column_name=>'BELEGNR'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002243170970309)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_FK_LEX_RELATION,P319_PK_INP_BELEGE_ALL:#RELATION#,'
,p_column_linktext=>'#BUCHUNGSTEXT#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002343980970310)
,p_db_column_name=>'BETRAG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002484604970311)
,p_db_column_name=>'WHRG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002524021970312)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002628248970313)
,p_db_column_name=>'HABENKTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002721557970314)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002873915970315)
,p_db_column_name=>'NOTIZ'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27002973232970316)
,p_db_column_name=>'KST'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003095400970317)
,p_db_column_name=>'KTR'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003121824970318)
,p_db_column_name=>'JAHR'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003283003970319)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003345588970320)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003426102970321)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003537607970322)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003612671970323)
,p_db_column_name=>'FK_STD_OK_STATE'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Ok State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003725053970324)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003840695970325)
,p_db_column_name=>'SEL_LEX_RELATION'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Sel Lex Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27003969899970326)
,p_db_column_name=>'FK_LEX_RELATION_MAIN'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fk Lex Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004019978970327)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004193925970328)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004225039970329)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004325653970330)
,p_db_column_name=>'FK_STD_LEX_STORNO'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Std Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004425064970331)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004580623970332)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004621901970333)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004744161970334)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004836183970335)
,p_db_column_name=>'FK_STEU_STEUER_VORANMLDG'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27004995198970336)
,p_db_column_name=>'DATUM_STEUERB_UEBERGABE'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Datum Steuerb Uebergabe'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005026715970337)
,p_db_column_name=>'DATUM_FINANZAMT_UEBERGABE'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Datum Finanzamt Uebergabe'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005108703970338)
,p_db_column_name=>'FK_LEX_BELEGDAT'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Lex Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005204227970339)
,p_db_column_name=>'FK_LEX_JOURDAT'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Fk Lex Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005333452970340)
,p_db_column_name=>'OK_ALL'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Ok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005476731970341)
,p_db_column_name=>'NOK_ALL'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Nok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005525927970342)
,p_db_column_name=>'BEMERKUNG_ALL'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Bemerkung All'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005636501970343)
,p_db_column_name=>'DATUM_ALL_OK'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Datum All Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005781385970344)
,p_db_column_name=>'DATUM_ALL_NOK'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Datum All Nok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005833240970345)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27005972505970346)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27006081259970347)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27006197958970348)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27033024075145601)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(27029949283971488)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'270300'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SOLLKTO:HABENKTO:UST_KTO:FK_LEX_RELATION_MAIN:STATUS:RELATION:BELEGDAT:FK_LEX_BELEGDAT:ARB_MONAT:ARB_JAHR:ARB_TAG:PK_BAS_KAL_ARBEITSTAGE:ABSCHLUSS:BELEG:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:SOLLDM:SOLLEUR:SOLL:SPERRE'
||':STAPEL:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_O'
||'K:FK_STD_OK_STATE:FK_LEX_LONG_ZUS_RELATION:SEL_LEX_RELATION:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_STD_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_CONTR_DUPL_STATUS:FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMLDG:DATUM_STEUERB_UEBERGABE:DATUM_FINANZ'
||'AMT_UEBERGABE:FK_LEX_JOURDAT:OK_ALL:NOK_ALL:BEMERKUNG_ALL:DATUM_ALL_OK:DATUM_ALL_NOK:STEUERSCHLUESSEL:'
,p_break_on=>'FK_LEX_RELATION_MAIN'
,p_break_enabled_on=>'FK_LEX_RELATION_MAIN'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27062213946599851)
,p_report_id=>wwv_flow_api.id(27029949283971488)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27062688704599851)
,p_report_id=>wwv_flow_api.id(27029949283971488)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STATUS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFF5CE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41495337680208480)
,p_plug_name=>'Belege nach Monat gruppiert'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select arb.jahr, arb.monat, count(*) cnt,',
'case when DATUM_ORT_OK is null then ''nein'' else ''ja'' end datum_ort_ok,',
'case when DATUM_ADDRESSE_OK is null then ''nein'' else ''ja'' end DATUM_ADDRESSE_OK,',
'case when DATUM_BUSSGELD_OK is null then ''nein'' else ''ja'' end DATUM_BUSSGELD_OK,',
'case when DATUM_BELEG_POS_OK is null then ''nein'' else ''ja'' end DATUM_BELEG_POS_OK,',
'case when DATUM_BUCHUNG_OK is null then ''nein'' else ''ja'' end DATUM_BUCHUNG_OK,',
'case when DATUM_VERPFL_BEL_OK is null then ''nein'' else ''ja'' end DATUM_VERPFL_BEL_OK',
'from t_inp_belege_all inp',
' left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.FK_BAS_KAL_ARBEITSTAG',
' where (arb.jahr = :P303_jahr and arb.monat = :P303_monat) or arb.monat is null or arb.jahr is null',
' group by arb.jahr, arb.monat,',
' case when DATUM_ORT_OK is null then ''nein'' else ''ja'' end ,',
'case when DATUM_ADDRESSE_OK is null then ''nein'' else ''ja'' end ,',
'case when DATUM_BUSSGELD_OK is null then ''nein'' else ''ja'' end,',
'case when DATUM_BELEG_POS_OK is null then ''nein'' else ''ja'' end ,',
'case when DATUM_BUCHUNG_OK is null then ''nein'' else ''ja'' end ,',
'case when DATUM_VERPFL_BEL_OK is null then ''nein'' else ''ja'' end'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Belege nach Monat gruppiert'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41495484732208481)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:228:&SESSION.::&DEBUG.::P228_JAHR,P228_MONAT,P228_PK_ABL_ORDNER,P228_PK_ABL_ORDNER_PAGE_TO,P228_PK_ABL_ORDNER_PAGE,P228_ANZAHL_KOPIEN:#JAHR#,#MONAT#,,,,'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>41495484732208481
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26661219604986060)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26661623294986060)
,p_db_column_name=>'MONAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813600154131914)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813730031131915)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813864665131916)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26813918557131917)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814032665131918)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814195898131919)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26814247515131920)
,p_db_column_name=>'CNT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41978688150291735)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'266624'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:MONAT:CNT:DATUM_BUCHUNG_OK:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_VERPFL_BEL_OK:'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'MONAT'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR:MONAT'
,p_break_enabled_on=>'JAHR:MONAT'
,p_sum_columns_on_break=>'CNT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26921503328355872)
,p_report_id=>wwv_flow_api.id(41978688150291735)
,p_name=>'ok_buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(144448973449820851)
,p_plug_name=>unistr('Vorsteuererkl\00E4rung')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7969438609734085)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(144449096971820851)
,p_plug_name=>'Rechnungen'
,p_parent_plug_id=>wwv_flow_api.id(144448973449820851)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27033468517145605)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(26814311569131921)
,p_button_name=>'1_Update_relation_main'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Relation Main'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27033689132145607)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(26814311569131921)
,p_button_name=>'2_Update_belegdatum_splitbuchung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Belegdatum Splitbuchung'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26668454969038176)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(26814311569131921)
,p_button_name=>'3_Update_Belegdatum'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Belegdatum'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27328790700302692)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(144448973449820851)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27329172736302693)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(144448973449820851)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27329578589302693)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(144448973449820851)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9203974114769553)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204271880772061)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontenblatt'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204506509773364)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204825598774877)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Kontenauswahl'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontenauswahl'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9254070852912699)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7002253801079576)
,p_name=>'P303_MONAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7002169654079575)
,p_prompt=>'Monat'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC2:Januar;1,Februar;2,M\00E4rz;3,April;4,Mai;5,Juni;6,Juli;7,August;8,September;9,Oktober;10,November;11,Dezember;12')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7002331353079577)
,p_name=>'P303_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7002169654079575)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JAHR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value d, std_value r',
'from t_std ',
'where fk_std_group = 221'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27330291885302693)
,p_name=>'P303_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(144449096971820851)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27056716941441725)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_update_rel_main'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' update t_lex_long set fk_lex_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_lex_relation_main is null;',
' commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(27033468517145605)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27033589757145606)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Update_belegdatum_Splitbuchung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' merge into t_lex_long t1',
' using (',
'select wod.relation, wd.belegdat, wd.jahr_beleg, wd.belegnr',
'from (',
'select * from t_lex_long where belegnr is not null ) wd',
'join (select * from t_lex_long where belegnr is null) wod on wd.fk_lex_relation_main = wod.fk_lex_relation_main',
') t2 on (t1.relation = t2.relation)',
'when  matched then',
' update set t1.belegdat = t2.belegdat,',
' t1.jahr_beleg = t2.jahr_beleg,',
' t1.belegnr = t2.belegnr;',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(26668778002041910)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_Update_Belegdatum'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'        merge into t_inp_belege_all t1',
'      using (',
'            select pk_bas_kal_arbeitstage, ',
'            pk_inp_belege_all',
'',
'            from (select * from t_inp_belege_all where bel_datum is not null and fk_bas_kal_arbeitstag is null) bel,',
'              t_bas_kal_arbeitstage arb',
'            where  to_date(substr(bel.bel_datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'             ) t2 on (t1.pk_inp_belege_all = t2.pk_inp_belege_all)',
'            when matched then',
'            update set t1.fk_bas_kal_ARBEITSTAG= t2.pk_bas_kal_arbeitstage;',
'            commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(26668454969038176)
);
wwv_flow_api.component_end;
end;
/
