prompt --application/pages/page_00065
begin
--   Manifest
--     PAGE: 00065
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>65
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'1_5_DBOV_Backup'
,p_alias=>'BACKUP'
,p_step_title=>'DOV Backup'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201023105311'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27667041737099827)
,p_plug_name=>'Backups'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bck.*, application_name, application_number',
'from t_db_app_backup bck',
' left join t_db_app_application app on bck.fk_db_app_application = app.pk_db_app_application'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Backups'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(27667164606099828)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.::P65_PK_DB_APP_BACKUP:#PK_DB_APP_BACKUP#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>27667164606099828
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667202381099829)
,p_db_column_name=>'PK_DB_APP_BACKUP'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Db App Backup'
,p_column_link=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.::P65_PK_DB_APP_BACKUP:#PK_DB_APP_BACKUP#'
,p_column_linktext=>'#PK_DB_APP_BACKUP#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667312035099830)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667438046099831)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667530943099832)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667659023099833)
,p_db_column_name=>'FK_BAS_KAL_DOWNLOAD_DATE_LOKAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Bas Kal Download Date Lokal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667704488099834)
,p_db_column_name=>'FK_BAS_KAL_UPLOAD_DATE_GITHUB'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Bas Kal Upload Date Github'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667865061099835)
,p_db_column_name=>'FK_DB_APP_APPLICATION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Db App Application'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27667990282099836)
,p_db_column_name=>'FK_DB_CONNECTION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Db Connection'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668013051099837)
,p_db_column_name=>'FK_DB_SCHEMA_NAME'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Db Schema Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668190146099838)
,p_db_column_name=>'FK_BAS_KAL_SCHEMA_BACKUP_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Bas Kal Schema Backup Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668248757099839)
,p_db_column_name=>'FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Bas Kal Schema Data Backup Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668324230099840)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668471144099841)
,p_db_column_name=>'APPLICATION_NUMBER'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Application Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(28294584951595702)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'282946'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_DB_APP_BACKUP:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_BAS_KAL_DOWNLOAD_DATE_LOKAL:FK_BAS_KAL_UPLOAD_DATE_GITHUB:FK_DB_APP_APPLICATION:FK_DB_CONNECTION:FK_DB_SCHEMA_NAME:FK_BAS_KAL_SCHEMA_BACKUP_DATE:FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE:APPLICATION_'
||'NAME:APPLICATION_NUMBER'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27668761596099844)
,p_plug_name=>'Applicationen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apps.application_id, apps.application_name apex_application_name, bck.*, app.application_name, application_number , pk_db_datenbank, wsp.workspace_name, wsp.workspace_id, arb1.datum lokal_datum, arb1.pk_bas_kal_arbeitstage lokal_pk_bas_kal_arb'
||'eittage,',
'arb2.datum GitHub_datum, arb2.pk_bas_kal_arbeitstage github_pk_bas_kal_arbeittage, m_FK_BAS_KAL_DOWNLOAD_DATE_LOKAL,  m_FK_BAS_KAL_UPLOAD_DATE_GITHUB,',
'case when m_FK_BAS_KAL_DOWNLOAD_DATE_LOKAL = FK_BAS_KAL_DOWNLOAD_DATE_LOKAL then 1 else 0 end lokal, case when  m_FK_BAS_KAL_UPLOAD_DATE_GITHUB =  FK_BAS_KAL_UPLOAD_DATE_GITHUB then 1 else 0 end github',
'from  apex_applications apps',
' left join t_db_app_application app on app.application_number = apps.application_id',
' left join  t_db_app_backup bck on bck.fk_db_app_application = app.pk_db_app_application',
' left join t_db_app_workspace wsp on wsp.pk_db_app_workspace = app.fk_db_app_workspace',
' left join t_db_datenbank db on db.pk_db_datenbank = wsp.fk_db_datenbank',
' left join t_bas_kal_arbeitstage arb1 on arb1.pk_bas_kal_arbeitstage = bck.FK_BAS_KAL_DOWNLOAD_DATE_LOKAL ',
' left join t_bas_kal_arbeitstage arb2 on arb2.pk_bas_kal_arbeitstage = bck.FK_BAS_KAL_UPLOAD_DATE_GITHUB',
' left join (select max(FK_BAS_KAL_DOWNLOAD_DATE_LOKAL) m_FK_BAS_KAL_DOWNLOAD_DATE_LOKAL, ',
'mAX(',
'FK_BAS_KAL_UPLOAD_DATE_GITHUB) m_FK_BAS_KAL_UPLOAD_DATE_GITHUB, fk_db_app_application from t_db_app_backup group by fk_db_app_application) m_bckp_app on app.PK_DB_APP_APPLICATION = m_bckp_app.fk_db_app_application',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Applicationen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(27668810595099845)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>27668810595099845
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27668977760099846)
,p_db_column_name=>'PK_DB_APP_BACKUP'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Db App Backup'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27669079174099847)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27669111461099848)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27669244555099849)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27669363916099850)
,p_db_column_name=>'FK_BAS_KAL_DOWNLOAD_DATE_LOKAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Bas Kal Download Date Lokal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356324454365201)
,p_db_column_name=>'FK_BAS_KAL_UPLOAD_DATE_GITHUB'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Bas Kal Upload Date Github'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356425077365202)
,p_db_column_name=>'FK_DB_APP_APPLICATION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Db App Application'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356520568365203)
,p_db_column_name=>'FK_DB_CONNECTION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Db Connection'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356618245365204)
,p_db_column_name=>'FK_DB_SCHEMA_NAME'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Db Schema Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356798564365205)
,p_db_column_name=>'FK_BAS_KAL_SCHEMA_BACKUP_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Bas Kal Schema Backup Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356890405365206)
,p_db_column_name=>'FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Bas Kal Schema Data Backup Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28356946604365207)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357032996365208)
,p_db_column_name=>'APPLICATION_NUMBER'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Application Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357172496365209)
,p_db_column_name=>'PK_DB_DATENBANK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Pk Db Datenbank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357279241365210)
,p_db_column_name=>'WORKSPACE_NAME'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Workspace Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357326267365211)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357477512365212)
,p_db_column_name=>'LOKAL_DATUM'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Lokal Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357578403365213)
,p_db_column_name=>'LOKAL_PK_BAS_KAL_ARBEITTAGE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Lokal Pk Bas Kal Arbeittage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357639661365214)
,p_db_column_name=>'GITHUB_DATUM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Github Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357742485365215)
,p_db_column_name=>'GITHUB_PK_BAS_KAL_ARBEITTAGE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Github Pk Bas Kal Arbeittage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357816703365216)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28357903452365217)
,p_db_column_name=>'APEX_APPLICATION_NAME'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Apex Application Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358241573365220)
,p_db_column_name=>'M_FK_BAS_KAL_DOWNLOAD_DATE_LOKAL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'M Fk Bas Kal Download Date Lokal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358311630365221)
,p_db_column_name=>'M_FK_BAS_KAL_UPLOAD_DATE_GITHUB'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'M Fk Bas Kal Upload Date Github'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358455386365222)
,p_db_column_name=>'LOKAL'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Lokal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358572398365223)
,p_db_column_name=>'GITHUB'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Github'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(28365812133368536)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'283659'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'PK_DB_APP_BACKUP:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_BAS_KAL_DOWNLOAD_DATE_FK_BAS_KAL_UPLOAD_DATE_FK_DB_APP_APPLICATION:FK_DB_CONNECTION:FK_DB_SCHEMA_NAME:FK_BAS_KAL_SCHEMA_BACKUP_DATE:FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE:APPLICATION_NAME:APPLICAT'
||'ION_NUMBER:PK_DB_DATENBANK:WORKSPACE_NAME:WORKSPACE_ID_DATUM_PK_BAS_KAL_ARBEITTAGE_DATUM_PK_BAS_KAL_ARBEITTAGE:APPLICATION_ID:APEX_APPLICATION_NAME:M_FK_BAS_KAL_DOWNLOAD_DATE_M_FK_BAS_KAL_UPLOAD_DATE_LOKAL:GITHUB'
,p_sort_column_1=>'GITHUB_DATUM'
,p_sort_direction_1=>'DESC'
,p_break_on=>'APPLICATION_ID:APEX_APPLICATION_NAME'
,p_break_enabled_on=>'APPLICATION_ID:APEX_APPLICATION_NAME'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(28376469029772341)
,p_report_id=>wwv_flow_api.id(28365812133368536)
,p_name=>'github'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'GITHUB_DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("GITHUB_DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(28376830245772341)
,p_report_id=>wwv_flow_api.id(28365812133368536)
,p_name=>'lokal_datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LOKAL_DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LOKAL_DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(28377256598772342)
,p_report_id=>wwv_flow_api.id(28365812133368536)
,p_name=>'Company'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WORKSPACE_NAME'
,p_operator=>'='
,p_expr=>'COMPANY'
,p_condition_sql=>' (case when ("WORKSPACE_NAME" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''COMPANY''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28201094657451658)
,p_plug_name=>'Backup'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_DB_APP_BACKUP'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27666754258099824)
,p_plug_name=>'Datenbank Backup'
,p_parent_plug_id=>wwv_flow_api.id(28201094657451658)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27666815879099825)
,p_plug_name=>'Application Backup'
,p_parent_plug_id=>wwv_flow_api.id(28201094657451658)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27666967239099826)
,p_plug_name=>'Github'
,p_parent_plug_id=>wwv_flow_api.id(28201094657451658)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28358133669365219)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(28201094657451658)
,p_button_name=>'Add_automatic'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Add Automatic'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28210334920451687)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(28201094657451658)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P65_PK_DB_APP_BACKUP'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28209140781451683)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(28201094657451658)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28210784377451688)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(28201094657451658)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P65_PK_DB_APP_BACKUP'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28209975027451687)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(28201094657451658)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P65_PK_DB_APP_BACKUP'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(28211046366451688)
,p_branch_action=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28201476113451663)
,p_name=>'P65_PK_DB_APP_BACKUP'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28201094657451658)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pk Db App Backup'
,p_source=>'PK_DB_APP_BACKUP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28201818943451671)
,p_name=>'P65_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28201094657451658)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28202224626451675)
,p_name=>'P65_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(28201094657451658)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28202687111451675)
,p_name=>'P65_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(28201094657451658)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28203012149451675)
,p_name=>'P65_FK_BAS_KAL_DOWNLOAD_DATE_LOKAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27666815879099825)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Bas Kal Download Date Lokal'
,p_source=>'FK_BAS_KAL_DOWNLOAD_DATE_LOKAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAL_ARBEITSTAG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum || '' ('' || pk_bas_kal_arbeitstage || '')'' d,  pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28203412786451677)
,p_name=>'P65_FK_BAS_KAL_UPLOAD_DATE_GITHUB'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27666967239099826)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Bas Kal Upload Date Github'
,p_source=>'FK_BAS_KAL_UPLOAD_DATE_GITHUB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAL_ARBEITSTAG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum || '' ('' || pk_bas_kal_arbeitstage || '')'' d,  pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28203837315451678)
,p_name=>'P65_FK_DB_APP_APPLICATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27666815879099825)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Db App Application'
,p_source=>'FK_DB_APP_APPLICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<b>'' || application_number || ''  '' || application_name || ''</b>'' || '' ''  || ''<i>'' || wsp.workspace_name || wsp.workspace_id || ''</i>'' || '' ('' || connection_string || '')'' d, pk_db_app_application',
'from t_db_app_application app',
' left join t_db_app_workspace wsp on wsp.pk_db_app_workspace = app.fk_db_app_workspace',
' left join t_db_datenbank db on wsp.fk_db_datenbank = db.pk_db_datenbank'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28204205412451678)
,p_name=>'P65_FK_DB_CONNECTION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(27666754258099824)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Db Connection'
,p_source=>'FK_DB_CONNECTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select connection_string, pk_db_datenbank',
'from t_db_datenbank'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28204625850451678)
,p_name=>'P65_FK_DB_SCHEMA_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(27666754258099824)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Db Schema Name'
,p_source=>'FK_DB_SCHEMA_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28205082553451678)
,p_name=>'P65_FK_BAS_KAL_SCHEMA_BACKUP_DATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(27666754258099824)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Bas Kal Schema Backup Date'
,p_source=>'FK_BAS_KAL_SCHEMA_BACKUP_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAL_ARBEITSTAG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum || '' ('' || pk_bas_kal_arbeitstage || '')'' d,  pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28205429344451680)
,p_name=>'P65_FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27666754258099824)
,p_item_source_plug_id=>wwv_flow_api.id(28201094657451658)
,p_prompt=>'Fk Bas Kal Schema Data Backup Date'
,p_source=>'FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAL_ARBEITSTAG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum || '' ('' || pk_bas_kal_arbeitstage || '')'' d,  pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28211976629451691)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(28201094657451658)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Backup'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28358091190365218)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_automatic_date'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_sysdate number;',
'begin',
'',
'',
'select pk_bas_kal_arbeitstage',
'into v_sysdate',
'from t_bas_kal_arbeitstage',
'where datum = to_char(sysdate, ''DD.MM.YYYY'');',
'',
'',
' insert into t_db_app_backup (',
' ',
'',
'FK_MDT_MANDANT,',
'CREATED_AT,',
'MODIFIED_AT,',
'FK_BAS_KAL_DOWNLOAD_DATE_LOKAL,',
'FK_BAS_KAL_UPLOAD_DATE_GITHUB,',
'FK_DB_APP_APPLICATION,',
'FK_DB_CONNECTION,',
'FK_DB_SCHEMA_NAME,',
'FK_BAS_KAL_SCHEMA_BACKUP_DATE,',
'FK_BAS_KAL_SCHEMA_DATA_BACKUP_DATE',
' )',
' values (',
'1,',
'sysdate ,',
'sysdate ,',
'v_sysdate ,',
'v_sysdate ,',
':P65_FK_DB_APP_APPLICATION,',
':P65_FK_DB_CONNECTION,',
':P65_FK_DB_SCHEMA_NAME,',
'v_sysdate ,',
'v_sysdate ',
' ',
' ',
' );',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(28358133669365219)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28211580351451690)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(28201094657451658)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Backup'
);
wwv_flow_api.component_end;
end;
/
