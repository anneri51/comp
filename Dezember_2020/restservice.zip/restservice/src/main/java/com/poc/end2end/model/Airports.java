package com.poc.end2end.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(exclude= {""}	)
@Entity
@Table(name="AIRPORTS")

public class Airports implements Serializable{
//	@GenericGenerator(
//			name="Airport_name",
//			strategy="",
//			parameters= {
//					@Parameter(name="sequence_name",)
//			}
//
//		)
//@GeneratedValue(generator="Airport_Name")
	@Id
    @Column(name="IATA", nullable=false)
	private String iata;				
    @Column(name="ICAO", nullable=false)
	private String icao;				
    @Column(name="FLUGHAFEN", nullable=false)
	private String flughafen;	
    @Column(name="ORT", nullable=false)
	private String ort;				
    @Column(name="REGION", nullable=false)
	private String region;				
    @Column(name="LAND", nullable=false)
	private String land;
    @Column(name="BUCHSTABEN", nullable=false)
	private String buchstaben;				



}
