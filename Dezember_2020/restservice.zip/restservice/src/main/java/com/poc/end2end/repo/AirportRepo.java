package com.poc.end2end.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.poc.end2end.model.Airports;
import com.poc.end2end.valueobject.AirportObject;

@Repository
public interface AirportRepo extends JpaRepository<Airports , String> {
//@Transactional
@Query(
	"select new com.poc.end2end.valueobject.AirportObject( " +
       " arp.iata, "+
       " arp.icao,"+
       " arp.flughafen," +
       " arp.ort," +
       " arp.region," +
       " arp.land," +
       " arp.buchstaben " + 
       " ) from Airports arp ")
List<AirportObject> fetchAirports();

//List<AirportObject> findTop5();

//List<AirportObject> findTop5ByIata(String iata);
}
