package com.poc.end2end.valueobject;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AirportObject {
private String	IATA;
private String	ICAO;
private String	FLUGHAFEN;
private String	ORT;
private String	REGION;
private String	LAND;
private String	BUCHSTABEN;

}
