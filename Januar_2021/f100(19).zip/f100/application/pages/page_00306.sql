prompt --application/pages/page_00306
begin
--   Manifest
--     PAGE: 00306
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>306
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kontoblatt_IR'
,p_alias=>'KONTOBLATT_IR_306'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kontoblatt'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210117094648'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8190015197173467)
,p_plug_name=>unistr('\00DCberblick')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum rnr,',
' a.*',
' from (',
'select   ',
'    ',
'       BUCHUNGSNUMMER,',
'',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'',
'',
'       OK,',
'       sum(habenbetrag_eur) sum_habenbetrag_eur,',
'       sum(sollbetrag_eur) sum_sollbetrag_eur,',
'              sum(habenbetrag_eur) -',
'       sum(sollbetrag_eur) diff,',
'',
'buchungsstatus,',
'count(*),',
'     fk_lex_relation1,',
'     fk_lex_relation2,',
'     std_name storno,',
'     rellex.bemerkung ,',
'     pk_rel_lex_lex',
'  from (select * from  t_lex_kontenblatt  where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                      jahr, nr, fk_lex_relation,',
'                      listagg(relkto.fk_main_key || '' '' || substr(zus.Buchungstag,1,10) || '' '' || zus.Betrag || '' '' || zus.buchungstext || '' '' || Kontotyp || '' '' || kto.iban,'','') within group (order by relkto.fk_main_key) lg,',
'                      listagg(relkto.fk_main_key || case when zus.fk_main_key is null then '''' else '' ('' ||  zus.fk_kto_bankkonto || '')'' end,'','') within group (order by relkto.fk_main_key) lex_bkkto',
'                  from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto',
'                      left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                      left join (select * from t_kto_bankkonto where valid = 1) kto on zus.fk_kto_bankkonto = kto.pk_kto_bankkonto and trunc(zus.Buchungstag) between valid_from and valid_to',
'                      join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   where relkto.fk_lex_relation is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relkto on to_char(relkto.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'    left join (',
'                   select nr, jahr, fk_lex_relation,',
'                   listagg(inp.pk_inp_belege_all || '' '' || brutto_betrag || '' '' || zahl_art_name || '' '' || bezeichnung || '' '' || bel_datum || '' '' || case when fk_inv_inventar is not null then ''Inventar: '' || fk_inv_inventar end ,'','') within group (or'
||'der by inp.pk_inp_belege_all) lb,',
'                   listagg(inp.pk_inp_belege_all || case when fk_std_kto_zahlungsart = 3 then '' (01600)'' else '''' end )  within group (order by inp.pk_inp_belege_all) lex_kto',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_inp_belege_all inp on inp.pk_inp_belege_all = relkto.fk_inp_belege_all',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                  where pk_inp_belege_all is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relbel on to_char(relbel.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'             ',
'    left join (',
'                select  pk_rel_lex_lex, id, bemerkung, std_name, fk_lex_relation1, fk_lex_relation2',
'                    from t_rel_lex_lex lex ',
'                        join t_lex_kontenblatt kto1 on ( lex.fk_lex_relation1 = kto1.fk_lex_relation_sub or  lex.fk_lex_relation2 = kto1.fk_lex_relation_sub )',
'                        join (select * from t_std where fk_std_group = 281 and std_value = 2) std on std.std_value = lex.fk_rel_type_lex_lex',
'                        ) rellex on rellex.id = kto.id',
'                    ',
'   group by   ',
'       BUCHUNGSNUMMER,',
'',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'',
'       OK,',
'',
'buchungsstatus,',
'     ',
'     fk_lex_relation1,',
'     fk_lex_relation2,',
'     std_name ,',
'     rellex.bemerkung ,',
'     pk_rel_lex_lex',
'     order by buchungsnummer',
'     ) a'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8190165196173467)
,p_name=>'Kontoblatt_IR'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>9630484471565007
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8190561229173488)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8191598444173503)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8192011484173503)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8192474908173503)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8195242776173506)
,p_db_column_name=>'OK'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8300896516210167)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286505833362594)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>83
,p_column_identifier=>'AI'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286621641362595)
,p_db_column_name=>'SUM_HABENBETRAG_EUR'
,p_display_order=>93
,p_column_identifier=>'AJ'
,p_column_label=>'Sum Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286778665362596)
,p_db_column_name=>'SUM_SOLLBETRAG_EUR'
,p_display_order=>103
,p_column_identifier=>'AK'
,p_column_label=>'Sum Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286796837362597)
,p_db_column_name=>'DIFF'
,p_display_order=>113
,p_column_identifier=>'AL'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286934693362598)
,p_db_column_name=>'RNR'
,p_display_order=>123
,p_column_identifier=>'AM'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721837920796279)
,p_db_column_name=>'STORNO'
,p_display_order=>153
,p_column_identifier=>'AP'
,p_column_label=>'Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721962433796280)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>163
,p_column_identifier=>'AQ'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722558557796286)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>173
,p_column_identifier=>'AR'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_column_linktext=>'#PK_REL_LEX_LEX#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790607936417984)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>183
,p_column_identifier=>'AS'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790752366417985)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>193
,p_column_identifier=>'AT'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8203008156231860)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'96434'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSNUMMER:BUCHUNGSSTATUS:BELEGDATUM:BELEGNUMMER:BUCHUNGSTEXT:OK:COUNT(*):SUM_SOLLBETRAG_EUR:SUM_HABENBETRAG_EUR:DIFF:RNR:STORNO:BEMERKUNG:PK_REL_LEX_LEX:FK_LEX_RELATION1:FK_LEX_RELATION2:'
,p_break_on=>'BUCHUNGSNUMMER'
,p_break_enabled_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR1:HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20215697767033788)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20216014479033788)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C0CCC0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20216423365033788)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20215295618033787)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_row_bg_color=>'#79B827'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11596756221840288)
,p_application_user=>'ANNE'
,p_name=>unistr('Buchungs\00FCbersicht')
,p_report_seq=>10
,p_report_columns=>'BUCHUNGSNUMMER:BUCHUNGSSTATUS:BELEGDATUM:BELEGNUMMER:BUCHUNGSTEXT:OK'
,p_break_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR1:HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597224947840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597337617840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597093833840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'ok1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_row_bg_color=>'#79B827'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11596850705840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11596914703840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597063599840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTONUMMER'
,p_operator=>'contains'
,p_expr=>'6680'
,p_condition_sql=>'upper("KONTONUMMER") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''6680''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8300702862210165)
,p_plug_name=>'<b>Status_Bearbeitung</b>'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14283207104362561)
,p_plug_name=>'Kontoblatt_Buchungsdetails'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select    case when buchungsstatus is null and ok is null   then  apex_item.checkbox2(1,kto.id,''CHECKED'')  else  apex_item.checkbox2(1,kto.id) end sel,',
'      apex_item.checkbox(2, ''j'' || kto.jahr || ''bu'' || kto.buchungsnummer || ''be'' || kto.belegnummer) sel_book ,',
'       kto.id,',
'       BUCHUNGSNUMMER,',
'       KONTONUMMER,',
'       KONTOBEZEICHNUNG,',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'       GEGENKONTO,',
'       SOLLBETRAG_EUR,',
'       HABENBETRAG_EUR,',
'       USTKONTO,',
'       UST,',
'       DATUM_OK,',
'       OK,',
'       SOLLBETRAG_EUR1,',
'buchungsstatus,',
'lg,',
'lb,',
'abs(nvl(SOLLBETRAG_EUR,0))+abs(nvl(HABENBETRAG_EUR,0)) SEARCH_EUR,',
'kto.jahr,',
'',
'       kto.kst kst_ktbl,',
'       kto.ktr ktr_ktbl,',
'      nvl(lex_bkkto, lex_kto) lex_bkkto,',
'      datum_steuer_ok,',
'      kto.split_nr,',
'      kto.fk_lex_relation kto_fk_lex_relation,',
'      fk_lex_relation_sub,',
'      split_nr_man,',
'      flg_split_buch,',
'      rellex.fk_lex_relation1,',
'      rellex.fk_lex_relation2,',
'      rellex.bemerkung rellex_bemerkung,',
'      rellex.std_name storno,',
'      pk_rel_lex_lex,',
'      kto.fk_lex_relation,',
'     ',
'        row_number() over (partition by kto.buchungsnummer, kto.belegnummer, kto.jahr, kto.kontonummer order by kto.id ) rnr,',
'        fk_bas_kal_belegdatum',
'  from (select * from t_lex_kontenblatt where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                      jahr, nr, fk_lex_relation,',
'                      listagg(relkto.fk_main_key || '' '' || substr(zus.Buchungstag,1,10) || '' '' || zus.Betrag || '' '' || zus.buchungstext || '' '' || Kontotyp || '' '' || kto.iban,'','') within group (order by relkto.fk_main_key) lg,',
'                      listagg(relkto.fk_main_key || case when zus.fk_main_key is null then '''' else '' ('' ||  fk_kto_bankkonto || '')'' end,'','') within group (order by relkto.fk_main_key) lex_bkkto',
'                  from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                      left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                      left join (select * from t_kto_bankkonto where valid = 1) kto on zus.fk_kto_bankkonto = kto.pk_kto_bankkonto and trunc(zus.Buchungstag) between valid_from and valid_to',
'                      join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   where relkto.fk_lex_relation is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relkto on to_char(relkto.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'    left join (',
'                   select nr, jahr, fk_lex_relation,',
'                   listagg(inp.pk_inp_belege_all || '' '' || brutto_betrag || '' '' || zahl_art_name || '' '' || bezeichnung || '' '' || bel_datum || '' '' || case when fk_inv_inventar is not null then ''Inventar: '' || fk_inv_inventar end ,'','') within group (or'
||'der by inp.pk_inp_belege_all) lb,',
'                   listagg(inp.pk_inp_belege_all || case when fk_std_kto_zahlungsart = 3 then '' (01600)'' else '''' end )  within group (order by inp.pk_inp_belege_all) lex_kto',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_inp_belege_all inp on inp.pk_inp_belege_all = relkto.fk_inp_belege_all',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                  where pk_inp_belege_all is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relbel on to_char(relbel.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'                         ',
'    left join (',
'                select  pk_rel_lex_lex, id, bemerkung, std_name, fk_lex_relation1, fk_lex_relation2',
'                    from t_rel_lex_lex lex ',
'                        join t_lex_kontenblatt kto1 on ( lex.fk_lex_relation1 = kto1.fk_lex_relation_sub or  lex.fk_lex_relation2 = kto1.fk_lex_relation_sub )',
'                        join (select * from t_std where fk_std_group = 281 and std_value = 2) std on std.std_value = lex.fk_rel_type_lex_lex',
'                        ) rellex on rellex.id = kto.id',
'   '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14283401875362563)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15723721150754103
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283499950362564)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283593874362565)
,p_db_column_name=>'LEX_BKKTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Lex Bkkto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283726624362566)
,p_db_column_name=>'DATUM_STEUER_OK'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Datum Steuer Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283804776362567)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284034597362569)
,p_db_column_name=>'SPLIT_NR_MAN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Split Nr Man'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284082452362570)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284279898362571)
,p_db_column_name=>'SEL_BOOK'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sel Book'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284350914362572)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284388157362573)
,p_db_column_name=>'KONTOBEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Kontobezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284565616362574)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284652045362575)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284740340362576)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284807560362577)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284913928362578)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Habenbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#HABENBETRAG_EUR#'
,p_column_linktext=>'#HABENBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285075052362579)
,p_db_column_name=>'USTKONTO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ustkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285145181362580)
,p_db_column_name=>'UST'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285202331362581)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285351225362582)
,p_db_column_name=>'OK'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285398390362583)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Sollbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#SOLLBETRAG_EUR#'
,p_column_linktext=>'#SOLLBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285570931362584)
,p_db_column_name=>'SOLLBETRAG_EUR1'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Sollbetrag Eur1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285599565362585)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285704284362586)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285793527362587)
,p_db_column_name=>'LG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285901331362588)
,p_db_column_name=>'SEARCH_EUR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Search Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286074545362589)
,p_db_column_name=>'LB'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Lb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286170604362590)
,p_db_column_name=>'JAHR'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286258763362591)
,p_db_column_name=>'ID'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286345787362592)
,p_db_column_name=>'KST_KTBL'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Kst Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286416361362593)
,p_db_column_name=>'KTR_KTBL'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ktr Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722190893796283)
,p_db_column_name=>'RELLEX_BEMERKUNG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Rellex Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722293141796284)
,p_db_column_name=>'STORNO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722613508796287)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_column_linktext=>'#PK_REL_LEX_LEX#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15056462148097995)
,p_db_column_name=>'RNR'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790803154417986)
,p_db_column_name=>'FK_LEX_RELATION_SUB'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Fk Lex Relation Sub'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790946997417987)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791036513417988)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791132548417989)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791206012417990)
,p_db_column_name=>'FK_BAS_KAL_BELEGDATUM'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Belegdatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6149075724089632)
,p_db_column_name=>'KTO_FK_LEX_RELATION'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'Kto Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14312495770383147)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'157529'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSNUMMER:SEL_BOOK:SEL:KONTONUMMER:KONTOBEZEICHNUNG:BELEGNUMMER:BUCHUNGSTEXT:KST_KTBL:KTR_KTBL:GEGENKONTO:SOLLBETRAG_EUR:HABENBETRAG_EUR:SEARCH_EUR:USTKONTO:UST:BUCHUNGSSTATUS:OK:LEX_BKKTO:LG:LB:JAHR:ID:SOLLBETRAG_EUR1:DATUM_OK:SPLIT_NR:DATUM_ST'
||'EUER_OK:SPLIT_NR_MAN:FLG_SPLIT_BUCH:RELLEX_BEMERKUNG:STORNO:PK_REL_LEX_LEX:BELEGDATUM:RNR:FK_LEX_RELATION:FK_BAS_KAL_BELEGDATUM:FK_LEX_RELATION_SUB:FK_LEX_RELATION1:FK_LEX_RELATION2:KTO_FK_LEX_RELATION:'
,p_break_on=>'BUCHUNGSNUMMER'
,p_break_enabled_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20240867034364023)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20240477500364023)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#D1EBAB'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20241217149364024)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'ok2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20241635994364024)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'sel_book'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_BOOK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL_BOOK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_column_bg_color=>'#EDC2ED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20240075413364023)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'RNR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"RNR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19167077351729038)
,p_plug_name=>'<h3><b>Kontenblatt Auszug (Sachkontenliste)</b></h3>'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19437759360800411)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19167175780729039)
,p_plug_name=>'Tab'
,p_parent_plug_id=>wwv_flow_api.id(19437759360800411)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7976405739962305)
,p_plug_name=>'Auswahl'
,p_parent_plug_id=>wwv_flow_api.id(19167175780729039)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17873807237845746)
,p_plug_name=>'Lexwarebuchung'
,p_parent_plug_id=>wwv_flow_api.id(19167175780729039)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct pk_rel_lex_kto_bel,kto.jahr || ''/'' || to_char(kto.buchungsnummer || ''/'') suchstring,kto.belegnummer,buchungsnummer,',
'll.*, ll2.relation lex_relation, ll2.status lex_status, case when inp.datum_buchung_ok is not null then ''<span style="color:green;font-weight:bold">'' || fk_inp_belege_all || ''</span>'' else '' ''|| fk_inp_belege_all end fk_inp_belege_all, relkto.fk_main'
||'_key',
' ,nvl(ll.belegdat, ll2.belegdat) ll_belegdat',
' from (select * from t_lex_kontenblatt where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                    *',
'                  from (select * from t_rel_lex_kto_bel ) relkto ',
'                    ',
'                 ) relkto on instr(to_char(relkto.fk_lex_relation), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0',
'    left join  t_lex_long ll on ll.relation = relkto.fk_lex_relation',
'    left join t_lex_long ll2 on instr(to_char(trim(ll2.relation)), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0',
'    left join t_inp_belege_all inp on inp.pK_inp_belege_all = relkto.fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(17874052480845748)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17874052480845748
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17874256611845750)
,p_db_column_name=>'JAHR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19164801220729016)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19165073296729018)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19165664110729024)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19166012516729028)
,p_db_column_name=>'UST'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19166107526729029)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191227483812331)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>320
,p_column_identifier=>'AN'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191356136812332)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>330
,p_column_identifier=>'AO'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191461413812333)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>340
,p_column_identifier=>'AP'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191571935812334)
,p_db_column_name=>'BELEG'
,p_display_order=>350
,p_column_identifier=>'AQ'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191682987812335)
,p_db_column_name=>'BENUTZER'
,p_display_order=>360
,p_column_identifier=>'AR'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191732615812336)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>370
,p_column_identifier=>'AS'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191855099812337)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>380
,p_column_identifier=>'AT'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19191948327812338)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>390
,p_column_identifier=>'AU'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192010816812339)
,p_db_column_name=>'NR'
,p_display_order=>400
,p_column_identifier=>'AV'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192172198812340)
,p_db_column_name=>'HABENDM'
,p_display_order=>410
,p_column_identifier=>'AW'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192299870812341)
,p_db_column_name=>'HABENEUR'
,p_display_order=>420
,p_column_identifier=>'AX'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192388455812342)
,p_db_column_name=>'HABEN'
,p_display_order=>430
,p_column_identifier=>'AY'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192410632812343)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>440
,p_column_identifier=>'AZ'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192550493812344)
,p_db_column_name=>'RELATION'
,p_display_order=>450
,p_column_identifier=>'BA'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192672320812345)
,p_db_column_name=>'SOLLDM'
,p_display_order=>460
,p_column_identifier=>'BB'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192797424812346)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>470
,p_column_identifier=>'BC'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192872616812347)
,p_db_column_name=>'SOLL'
,p_display_order=>480
,p_column_identifier=>'BD'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19192933963812348)
,p_db_column_name=>'SPERRE'
,p_display_order=>490
,p_column_identifier=>'BE'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19193073469812349)
,p_db_column_name=>'STAPEL'
,p_display_order=>500
,p_column_identifier=>'BF'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19193135597812350)
,p_db_column_name=>'STATUS'
,p_display_order=>510
,p_column_identifier=>'BG'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19205675256838801)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>520
,p_column_identifier=>'BH'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19205799928838802)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>530
,p_column_identifier=>'BI'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19205822276838803)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>540
,p_column_identifier=>'BJ'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19205950846838804)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>550
,p_column_identifier=>'BK'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206049258838805)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>560
,p_column_identifier=>'BL'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206147370838806)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>570
,p_column_identifier=>'BM'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206291606838807)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>580
,p_column_identifier=>'BN'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206347357838808)
,p_db_column_name=>'UST_DM'
,p_display_order=>590
,p_column_identifier=>'BO'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206470266838809)
,p_db_column_name=>'UST_EUR'
,p_display_order=>600
,p_column_identifier=>'BP'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206597367838810)
,p_db_column_name=>'UST_KTO'
,p_display_order=>610
,p_column_identifier=>'BQ'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206641456838811)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>620
,p_column_identifier=>'BR'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206742692838812)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>630
,p_column_identifier=>'BS'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206836459838813)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>640
,p_column_identifier=>'BT'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19206992459838814)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>650
,p_column_identifier=>'BU'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207007437838815)
,p_db_column_name=>'PERIODE'
,p_display_order=>660
,p_column_identifier=>'BV'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207178320838816)
,p_db_column_name=>'BELEGNR'
,p_display_order=>670
,p_column_identifier=>'BW'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207219056838817)
,p_db_column_name=>'BETRAG'
,p_display_order=>680
,p_column_identifier=>'BX'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207386304838818)
,p_db_column_name=>'WHRG'
,p_display_order=>690
,p_column_identifier=>'BY'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207444758838819)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>700
,p_column_identifier=>'BZ'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207599829838820)
,p_db_column_name=>'HABENKTO'
,p_display_order=>710
,p_column_identifier=>'CA'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207607055838821)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>720
,p_column_identifier=>'CB'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207720585838822)
,p_db_column_name=>'NOTIZ'
,p_display_order=>730
,p_column_identifier=>'CC'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207844345838823)
,p_db_column_name=>'KST'
,p_display_order=>740
,p_column_identifier=>'CD'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19207966947838824)
,p_db_column_name=>'KTR'
,p_display_order=>750
,p_column_identifier=>'CE'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208036041838825)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>760
,p_column_identifier=>'CF'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208111362838826)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>770
,p_column_identifier=>'CG'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208257792838827)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>780
,p_column_identifier=>'CH'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208396862838828)
,p_db_column_name=>'FK_STD_OK_STATE'
,p_display_order=>790
,p_column_identifier=>'CI'
,p_column_label=>'Fk Std Ok State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208484937838829)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>800
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208541518838830)
,p_db_column_name=>'SEL_LEX_RELATION'
,p_display_order=>810
,p_column_identifier=>'CK'
,p_column_label=>'Sel Lex Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208687406838831)
,p_db_column_name=>'FK_LEX_RELATION_MAIN'
,p_display_order=>820
,p_column_identifier=>'CL'
,p_column_label=>'Fk Lex Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208757228838832)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>830
,p_column_identifier=>'CM'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208884733838833)
,p_db_column_name=>'FK_STD_LEX_STORNO'
,p_display_order=>840
,p_column_identifier=>'CN'
,p_column_label=>'Fk Std Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19208916030838834)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>850
,p_column_identifier=>'CO'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209024852838835)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>860
,p_column_identifier=>'CP'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209177540838836)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>870
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209222894838837)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>880
,p_column_identifier=>'CR'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209371045838838)
,p_db_column_name=>'FK_STEU_STEUER_VORANMLDG'
,p_display_order=>890
,p_column_identifier=>'CS'
,p_column_label=>'Fk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209404429838839)
,p_db_column_name=>'DATUM_STEUERB_UEBERGABE'
,p_display_order=>900
,p_column_identifier=>'CT'
,p_column_label=>'Datum Steuerb Uebergabe'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209562841838840)
,p_db_column_name=>'DATUM_FINANZAMT_UEBERGABE'
,p_display_order=>910
,p_column_identifier=>'CU'
,p_column_label=>'Datum Finanzamt Uebergabe'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209600063838841)
,p_db_column_name=>'FK_LEX_BELEGDAT'
,p_display_order=>920
,p_column_identifier=>'CV'
,p_column_label=>'Fk Lex Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209716246838842)
,p_db_column_name=>'FK_LEX_JOURDAT'
,p_display_order=>930
,p_column_identifier=>'CW'
,p_column_label=>'Fk Lex Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209894292838843)
,p_db_column_name=>'OK_ALL'
,p_display_order=>940
,p_column_identifier=>'CX'
,p_column_label=>'Ok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19209980950838844)
,p_db_column_name=>'NOK_ALL'
,p_display_order=>950
,p_column_identifier=>'CY'
,p_column_label=>'Nok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210003715838845)
,p_db_column_name=>'BEMERKUNG_ALL'
,p_display_order=>960
,p_column_identifier=>'CZ'
,p_column_label=>'Bemerkung All'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210159010838846)
,p_db_column_name=>'DATUM_ALL_OK'
,p_display_order=>970
,p_column_identifier=>'DA'
,p_column_label=>'Datum All Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210289636838847)
,p_db_column_name=>'DATUM_ALL_NOK'
,p_display_order=>980
,p_column_identifier=>'DB'
,p_column_label=>'Datum All Nok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210347160838848)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>990
,p_column_identifier=>'DC'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210457568838849)
,p_db_column_name=>'SUCHSTRING'
,p_display_order=>1000
,p_column_identifier=>'DD'
,p_column_label=>'Suchstring'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279241431960009)
,p_db_column_name=>'LEX_RELATION'
,p_display_order=>1010
,p_column_identifier=>'DE'
,p_column_label=>'Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279347311960010)
,p_db_column_name=>'LEX_STATUS'
,p_display_order=>1020
,p_column_identifier=>'DF'
,p_column_label=>'Lex Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279535288960012)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1040
,p_column_identifier=>'DH'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279675885960013)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>1050
,p_column_identifier=>'DI'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279796464960014)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>1060
,p_column_identifier=>'DJ'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437831918800412)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>1070
,p_column_identifier=>'DK'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21206401239831028)
,p_db_column_name=>'LL_BELEGDAT'
,p_display_order=>1080
,p_column_identifier=>'DL'
,p_column_label=>'Ll Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19183466034738197)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'191835'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSNUMMER:PK_REL_LEX_KTO_BEL:LL_BELEGDAT:RELATION:LEX_RELATION:LEX_STATUS:FK_MAIN_KEY:SUCHSTRING:FK_LEX_RELATION_MAIN:SEL_LEX_RELATION:JAHR:FLG_SPLIT_BUCH:BUCHUNGSTEXT:UST:DATUM_OK:ABSCHLUSS:BELEG:BUCHDAT:HABEN:JOUR_DAT:SOLL:SPERRE:STAPEL:STATUS'
||':STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:FK_STD_OK_S'
||'TATE:FK_LEX_LONG_ZUS_RELATION:STEUER_DATUM_OK:FK_STD_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_CONTR_DUPL_STATUS:FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMLDG:DATUM_STEUERB_UEBERGABE:DATUM_FINANZAMT_UEBERGABE:FK_LEX_BELEGDAT:FK_LEX_JOURDAT:OK_ALL:NO'
||'K_ALL:BEMERKUNG_ALL:DATUM_ALL_OK:DATUM_ALL_NOK:STEUERSCHLUESSEL:BENUTZER:BETRAGDM:BETRAGEUR:HABENDM:HABENEUR:NR:SOLLDM:SOLLEUR:SPLIT_NR:BELEGNUMMER:BELEGDAT:'
,p_break_on=>'BUCHUNGSNUMMER:SUCHSTRING:0:0:0:0'
,p_break_enabled_on=>'BUCHUNGSNUMMER:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21320119464712774)
,p_report_id=>wwv_flow_api.id(19183466034738197)
,p_name=>'lex_buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_INP_BELEGE_ALL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_INP_BELEGE_ALL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21320575094712774)
,p_report_id=>wwv_flow_api.id(19183466034738197)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21320906333712774)
,p_report_id=>wwv_flow_api.id(19183466034738197)
,p_name=>'lex_Buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LEX_RELATION'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LEX_RELATION" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21321353879712775)
,p_report_id=>wwv_flow_api.id(19183466034738197)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LEX_STATUS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LEX_STATUS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19167213401729040)
,p_plug_name=>'Inp_Belege_all'
,p_parent_plug_id=>wwv_flow_api.id(19167175780729039)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct pk_rel_lex_kto_bel,kto.jahr || ''/'' || to_char(kto.buchungsnummer || ''/'') suchstring,',
'vinp.pk_inp_belege_all,',
'vinp.belegnummer,',
'vinp.bezeichnung,',
'vinp.ort,',
'',
'vinp.inventar,',
'vinp.persoenlich_vor_ort,',
'vinp.brutto_betrag',
'',
'  from (select * from t_lex_kontenblatt where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                    *',
'                  from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                    ',
'                 ) relkto on instr(to_char(relkto.fk_lex_relation), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0',
'    left join  v_inp_belege_all vinp on vinp.pk_inp_belege_all = relkto.fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19167363923729041)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19167363923729041
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19210565974838850)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>10
,p_column_identifier=>'AN'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278447768960001)
,p_db_column_name=>'SUCHSTRING'
,p_display_order=>20
,p_column_identifier=>'AO'
,p_column_label=>'Suchstring'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278588348960002)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'AP'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278601735960003)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>40
,p_column_identifier=>'AQ'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278736939960004)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>50
,p_column_identifier=>'AR'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278876547960005)
,p_db_column_name=>'ORT'
,p_display_order=>60
,p_column_identifier=>'AS'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19278986822960006)
,p_db_column_name=>'INVENTAR'
,p_display_order=>70
,p_column_identifier=>'AT'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279021479960007)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>80
,p_column_identifier=>'AU'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19279195230960008)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>90
,p_column_identifier=>'AV'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19271971619840141)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'192720'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KONTOBELEGDATUM:PK_REL_LEX_KTO_BEL:SUCHSTRING:PK_INP_BELEGE_ALL:BEZEICHNUNG:ORT:INVENTAR:PERSOENLICH_VOR_ORT:BRUTTO_BETRAG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19279871234960015)
,p_plug_name=>unistr('Lexwarebuchungszusammenh\00E4nge')
,p_parent_plug_id=>wwv_flow_api.id(19437759360800411)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  distinct kto.jahr || ''/'' || to_char(kto.buchungsnummer || ''/'') suchstring,belegnummer,buchungsnummer,',
'relll.*',
'  from (select * from t_lex_kontenblatt where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'  /*',
'       left join (select ',
'                    *',
'                  from (select * from t_rel_lex_kto_bel ) relkto ',
'                    ',
'                 ) relkto on instr(to_char(relkto.fk_lex_relation), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0',
'    left join  t_lex_long ll on ll.relation = relkto.fk_lex_relation',
'  ',
'    left join t_lex_long ll2 on instr(to_char(trim(ll2.relation)), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0',
'      */',
'    left join t_rel_lex_lex relll on (instr(to_char(trim(relll.fk_lex_relation1)), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0) or (instr(to_char(trim(relll.fk_lex_relation2)), kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/'') >0)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19279942408960016)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19279942408960016
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19280198306960018)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19410132114772338)
,p_db_column_name=>'SUCHSTRING'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Suchstring'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19410953400772346)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19411031172772347)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19411193285772348)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19411249583772349)
,p_db_column_name=>'FK_BEL_BELEGNR1'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bel Belegnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19411317917772350)
,p_db_column_name=>'FK_BEL_BELEGNR2'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Fk Bel Belegnr2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19436794755800401)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19436898515800402)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19436936539800403)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437064436800404)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437194258800405)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437250181800406)
,p_db_column_name=>'JAHR1'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Jahr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437311935800407)
,p_db_column_name=>'JAHR2'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Jahr2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437401294800408)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437514649800409)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19437601596800410)
,p_db_column_name=>'FK_REL_TYPE_LEX_LEX'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Fk Rel Type Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19469217821801231)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'194693'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_OK:SUCHSTRING:BELEGNUMMER:BUCHUNGSNUMMER:PK_REL_LEX_LEX:FK_BEL_BELEGNR1:FK_BEL_BELEGNR2:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:BEMERKUNG:JAHR1:JAHR2:FK_LEX_RELATION1:FK_LEX_RELATION2:FK_REL_TYPE_LEX_LEX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7973905370962280)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'<b>Remove</b>'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14283379732362562)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14283207104362561)
,p_button_name=>'Relation1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'View Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8300544945210163)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Set_Buchungsstatus'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Buchungsstatus'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8212509211291208)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Set_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14759824331132506)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Steuer_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Steuer Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14760085286134308)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Steuer_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Steuer Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15172798645332647)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11577058016419164)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7976405739962305)
,p_button_name=>'Reset_Belegnr'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Reset Belegnr'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP,306:P306_BUCHUNGSSTATUS,P306_JAHR,P306_BELEGNR:&P306_BUCHUNGSSTATUS.,&P306_JAHR.,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9254295501929160)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'View Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7976054899962301)
,p_name=>'P306_BELEGNR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7976405739962305)
,p_prompt=>'Belegnr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8300813179210166)
,p_name=>'P306_BUCHUNGSSTATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8300702862210165)
,p_prompt=>'Buchungsstatus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 201'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10833056431140964)
,p_name=>'P306_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7976405739962305)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15056373923097994)
,p_name=>'P306_DATUM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8300702862210165)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Datum'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8212453297291207)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'begin',
'',
'  --sel 1 -- single line',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_kontenblatt set ok = 2, datum_ok = sysdate, buchungsstatus = nvl(buchungsstatus, 1) where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'    ',
'       ',
'   -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        update  t_lex_kontenblatt set ok = 2, datum_ok = sysdate, buchungsstatus = nvl(buchungsstatus, 1) where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8212509211291208)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8300609864210164)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_Buchungsstatus'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'',
'begin',
' ',
' ',
' --sel 1 -- single line',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'        update  t_lex_kontenblatt set buchungsstatus = :P306_Buchungsstatus where id  = apex_application.g_f01(i);',
'        commit;',
'    end if;',
'    end loop;',
'    ',
'   -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        update  t_lex_kontenblatt set buchungsstatus = :P306_Buchungsstatus where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8300544945210163)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7974078165962281)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'begin',
'  --sel 1 - each line',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     delete from  t_lex_kontenblatt  where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'    ',
'  -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        delete from  t_lex_kontenblatt  where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7973905370962280)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14760333682138960)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Steuer_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      ',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = sysdate where id = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14759824331132506)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14760636066139900)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Steuer_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'   ',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = null where id= apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14760085286134308)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15176361527702097)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15172798645332647)
);
wwv_flow_api.component_end;
end;
/
