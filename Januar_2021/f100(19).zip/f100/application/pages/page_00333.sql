prompt --application/pages/page_00333
begin
--   Manifest
--     PAGE: 00333
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>333
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Vorsteueranmeldung'
,p_alias=>'VORSTEUERANMELDUNG_333'
,p_step_title=>'Vorsteueranmeldung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42881936682393325)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210104051401'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11950512354481847)
,p_plug_name=>unistr('Vorsteuererkl\00E4rung \00DCbermittlungen')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select stva.PK_steu_STEUER_VORANMLDG,',
'stva."MELDEMONAT",',
'stva."BERICHTIGTE_ANMLDG_NR",',
'stva."BELEG_NR",',
'stva."STEUERPFL_UMSAETZE",',
'stva."ABZIEHBARE_VORSTEUERBETR",',
'stva."UMSATZSTVORAUSZLG_UEBERSCHUSS",',
'stva."SENDEDATUM",',
'stva."TRANSAKTIONSNUMMER",',
'stva."CREATED_BY",',
'stva."CREATED_AT",',
'stva."MODIFIED_BY",',
'stva."MODIFIED_AT",',
'stva.FK_steu_STEUER_MONAT,',
'sys.dbms_lob.getlength(stva."FILE1")"FILE1",',
'sys.dbms_lob.getlength(stva."FILE2")"FILE2"',
'',
', stm.monat',
', stm.jahr',
', std.std_name status_vorsteueranmeldg',
', std1.std_name type',
', std1.std_value FK_STD_STEU_TYPE_STEUERVORANMELDG',
',ll_stm.cnt_stm',
',ll_stva.cnt_vor',
', ll_ust.ust_aus_buchung',
', inp.brutto_betrag',
', round(zus.Betrag,2) Betrag',
', ll.BETRAGEUR',
'from T_steu_STEUER_VORANMLDG stva',
'  left join t_steu_steuer_monat stm on stva.fk_steu_steuer_monat = stm.pk_steu_steuer_monat',
'  left join (select * from t_std where fk_std_group = 342) std on std.std_value = stva.fk_std_steu_status',
'  left join (select * from t_std where fk_std_group = 343) std1 on std1.std_value = stva.FK_STD_STEU_TYPE_STEUERVORANMELDG',
'  left join (select fk_steu_steuer_monat, count(*) cnt_stm from t_lex_long  group by fk_steu_steuer_monat ) ll_stm on ll_stm.fk_steu_steuer_monat = stm.pk_steu_steuer_monat',
'  left join (select fk_steu_steuer_voranmldg, count(*) cnt_vor from t_lex_long  group by fk_steu_steuer_voranmldg ) ll_stva on ll_stva.fk_steu_steuer_voranmldg = stva.pk_steu_steuer_voranmldg',
'  left join (select fk_steu_steuer_voranmldg, sum(ust_eur) ust_aus_buchung from t_lex_long group by fk_steu_steuer_voranmldg) ll_ust on ll_ust.fk_steu_steuer_voranmldg = stva.pk_steu_steuer_voranmldg',
'  left join T_REL_STEU_STEUER_VORANMLDG_REL_LEX_KTO_BEL relvorrel on relvorrel.fk_steu_steuer_voranmeldg = stva.pk_steu_steuer_voranmldg',
'  left join t_rel_lex_kto_bel relbel on relbel.pk_rel_lex_kto_bel = relvorRel.fk_rel_lex_kto_bel',
'  left join t_inp_belege_all inp on inp.pk_inp_belege_all = relbel.fk_inp_belege_all',
'  left join t_lex_long ll on ll.relation = relbel.fk_lex_relation',
'  left Join v_kto_konten_zus zus on zus.fk_main_key = relbel.fk_main_key'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11950960644481849)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:334:&SESSION.::&DEBUG.:RP,:P334_PK_STEU_STEUER_VORANMLDG:#PK_STEU_STEUER_VORANMLDG#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13391279919873389
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11951433295481852)
,p_db_column_name=>'MELDEMONAT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Meldemonat'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11951825790481852)
,p_db_column_name=>'BERICHTIGTE_ANMLDG_NR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Berichtigte Anmldg Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11952259136481852)
,p_db_column_name=>'BELEG_NR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Beleg Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11952673580481853)
,p_db_column_name=>'STEUERPFL_UMSAETZE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Steuerpfl Umsaetze'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953007277481853)
,p_db_column_name=>'ABZIEHBARE_VORSTEUERBETR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Abziehbare Vorsteuerbetr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953474824481853)
,p_db_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Umsatzstvorauszlg Ueberschuss'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953854587481853)
,p_db_column_name=>'SENDEDATUM'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sendedatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11954232682481853)
,p_db_column_name=>'TRANSAKTIONSNUMMER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Transaktionsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11954642238481853)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955054781481853)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955412962481855)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955849177481855)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11956621260481855)
,p_db_column_name=>'FILE1'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'File1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:T_STEUER_VORANMLDG:FILE1:PK_STEUER_VORANMLDG'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11957077669481855)
,p_db_column_name=>'FILE2'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'File2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:T_STEUER_VORANMLDG:FILE2:PK_STEUER_VORANMLDG'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18026973239728087)
,p_db_column_name=>'MONAT'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027016291728088)
,p_db_column_name=>'JAHR'
,p_display_order=>36
,p_column_identifier=>'R'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027180381728089)
,p_db_column_name=>'STATUS_VORSTEUERANMELDG'
,p_display_order=>46
,p_column_identifier=>'S'
,p_column_label=>'Status Vorsteueranmeldg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027565448728093)
,p_db_column_name=>'TYPE'
,p_display_order=>56
,p_column_identifier=>'T'
,p_column_label=>'Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23127962539093430)
,p_db_column_name=>'PK_STEU_STEUER_VORANMLDG'
,p_display_order=>66
,p_column_identifier=>'V'
,p_column_label=>'Pk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23128053198093431)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>76
,p_column_identifier=>'W'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(23128167406093432)
,p_db_column_name=>'FK_STD_STEU_TYPE_STEUERVORANMELDG'
,p_display_order=>86
,p_column_identifier=>'X'
,p_column_label=>'Fk Std Steu Type Steuervoranmeldg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46745318284591925)
,p_db_column_name=>'CNT_STM'
,p_display_order=>96
,p_column_identifier=>'Y'
,p_column_label=>'Cnt Stm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46745427362591926)
,p_db_column_name=>'CNT_VOR'
,p_display_order=>106
,p_column_identifier=>'Z'
,p_column_label=>'Cnt Vor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47063749295679949)
,p_db_column_name=>'UST_AUS_BUCHUNG'
,p_display_order=>116
,p_column_identifier=>'AA'
,p_column_label=>'Ust Aus Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47063843090679950)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>126
,p_column_identifier=>'AB'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47140973522673201)
,p_db_column_name=>'BETRAG'
,p_display_order=>136
,p_column_identifier=>'AC'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47141029986673202)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>146
,p_column_identifier=>'AD'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11969555858677836)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134099'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:PK_STEU_STEUER_VORANMLDG:BELEG_NR:STEUERPFL_UMSAETZE:ABZIEHBARE_VORSTEUERBETR:UST_AUS_BUCHUNG:UMSATZSTVORAUSZLG_UEBERSCHUSS:SENDEDATUM:TRANSAKTIONSNUMMER:MONAT:STATUS_VORSTEUERANMELDG:TYPE:BERICHTIGTE_ANMLDG_NR:MELDEMONAT:FK_STEU_STEUER_MONAT:FK'
||'_STD_STEU_TYPE_STEUERVORANMELDG:CNT_STM:CNT_VOR:BRUTTO_BETRAG:BETRAG:BETRAGEUR:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:'
,p_sort_column_1=>'SENDEDATUM'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'JAHR'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'MONAT'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'FK_TYPE'
,p_sort_direction_4=>'DESC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
,p_count_columns_on_break=>'PK_STEUER_VORANMLDG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47151217047695184)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>unistr('abziehbarhe Vorsteuerbetr\00E4ge')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABZIEHBARE_VORSTEUERBETR'
,p_operator=>'is not null'
,p_expr=>'0'
,p_condition_sql=>' (case when ("ABZIEHBARE_VORSTEUERBETR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFF5CE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47151642185695185)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'zahlung_kto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'<'
,p_expr=>'0'
,p_condition_sql=>' (case when ("BETRAG" < to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# < #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47152044972695185)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'zahlungseingang'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("BETRAG" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47152412967695185)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>unistr('steuerpfl_Ums\00E4tze')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STEUERPFL_UMSAETZE'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STEUERPFL_UMSAETZE" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47152856067695186)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'Gutschrift'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_operator=>'<'
,p_expr=>'0'
,p_condition_sql=>' (case when ("UMSATZSTVORAUSZLG_UEBERSCHUSS" < to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# < #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47153288531695186)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'zahlung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("UMSATZSTVORAUSZLG_UEBERSCHUSS" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(89799302438312920)
,p_plug_name=>unistr('Vorsteuererkl\00E4rung')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7969438609734085)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(89799425960312920)
,p_plug_name=>'Rechnungen'
,p_parent_plug_id=>wwv_flow_api.id(89799302438312920)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27316271237129203)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(89799302438312920)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27316677602129203)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(89799302438312920)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27317070711129203)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(89799302438312920)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11958248704481856)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11950512354481847)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:334:&SESSION.::&DEBUG.:334'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27317734475129204)
,p_name=>'P333_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(89799425960312920)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
