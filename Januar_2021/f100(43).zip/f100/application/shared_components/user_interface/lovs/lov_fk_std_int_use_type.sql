prompt --application/shared_components/user_interface/lovs/lov_fk_std_int_use_type
begin
--   Manifest
--     LOV_FK_STD_INT_USE_TYPE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(28303430299362760)
,p_lov_name=>'LOV_FK_STD_INT_USE_TYPE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT D.STD_NAME,D.PK_STD',
'FROM T_STD D',
'JOIN T_STD_GROUP M ON M.PK_STD_GROUP = D.FK_STD_GROUP',
'WHERE M.STD_GROUP_NAME = ''FK_STD_INT_USE_TYPE'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PK_STD'
,p_display_column_name=>'STD_NAME'
,p_default_sort_column_name=>'STD_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
