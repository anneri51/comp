prompt --application/pages/page_00143
begin
--   Manifest
--     PAGE: 00143
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>143
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Krankenkasse'
,p_alias=>'KRANKENKASSE_143'
,p_step_title=>'Krankenkasse'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42886027507430877)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210130164233'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3411489751949372)
,p_plug_name=>unistr('Krankenkassenbeitr\00E4ge')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'kk.pk_bei_kk_krankenkasse_det,',
'kk."DATUM",',
'kk."BUCHUNGSTEXT",',
'kk."VON",',
'kk."BIS",',
'betrag1 Betrag,',
'kk."GEZAHLTER_BETRAG",',
'kk."KRANKENKASSE",',
'kk."BEMERKUNG",',
'round(kk."SUMME",2) summe,',
'kk."PROJEKTBEMERKUNG",',
'kk.fk_kto_buchung,',
'arb.tag,',
'arb.monat,',
'kk.verwendungszweck,',
'kk.iban,',
'kk.betrag1,',
'arb.jahr,',
'length(kk.bild) bild,',
'length(kk.bild1) bild1,',
'round(zus.Betrag,2) Betrag_ueb,',
'kk.Betrag kk_Betrag,',
'sum(round(kk.betrag1,2)) over (order by arb.jahr,',
'arb.monat, arb.tag, kk.pk_bei_kk_krankenkasse_det) lfd_summe,',
'pk_bas_kal_arbeitstage',
'from T_bei_kk_KRANKENKASSE_det  kk',
'  left join t_bas_kal_arbeitstage arb on kk.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
'  left join v_kto_konten_zus zus on zus.fk_main_key = kk.fk_kto_buchung',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3411930679949372)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.:144:P144_PK_BEI_KK_KRANKENKASSE_DET:#PK_BEI_KK_KRANKENKASSE_DET##PK_IMP_BA_KRANKENKASSE##ROWID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12722065920370293
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3412394251949373)
,p_db_column_name=>'DATUM'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Datum'
,p_column_link=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::P144_PK_BEI_KK_KRANKENKASSE_DET:#PK_BEI_KK_KRANKENKASSE_DET#'
,p_column_linktext=>'#DATUM#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3412862056949374)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413186498949375)
,p_db_column_name=>'VON'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Von'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413612891949376)
,p_db_column_name=>'BIS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Bis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3414367008949377)
,p_db_column_name=>'GEZAHLTER_BETRAG'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Gezahlter Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3414826004949378)
,p_db_column_name=>'KRANKENKASSE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Krankenkasse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3415219576949379)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3415605695949379)
,p_db_column_name=>'SUMME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Summe'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3416038983949380)
,p_db_column_name=>'PROJEKTBEMERKUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Projektbemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4306300695853305)
,p_db_column_name=>'TAG'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4306427507853306)
,p_db_column_name=>'MONAT'
,p_display_order=>41
,p_column_identifier=>'N'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4306529195853307)
,p_db_column_name=>'JAHR'
,p_display_order=>51
,p_column_identifier=>'O'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4307161864853313)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>81
,p_column_identifier=>'R'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4307183260853314)
,p_db_column_name=>'IBAN'
,p_display_order=>91
,p_column_identifier=>'S'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8304184457059321)
,p_db_column_name=>'BETRAG'
,p_display_order=>101
,p_column_identifier=>'U'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8304331923059322)
,p_db_column_name=>'BILD'
,p_display_order=>111
,p_column_identifier=>'V'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:IMP_BA_KRANKENKASSE:BILD:PK_IMP_BA_KRANKENKASSE::::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8304426333059323)
,p_db_column_name=>'BILD1'
,p_display_order=>121
,p_column_identifier=>'W'
,p_column_label=>'Bild1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:IMP_BA_KRANKENKASSE:BILD1:PK_IMP_BA_KRANKENKASSE::::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10465116715145128)
,p_db_column_name=>'BETRAG_UEB'
,p_display_order=>131
,p_column_identifier=>'X'
,p_column_label=>'Betrag ueb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2153906582145999)
,p_db_column_name=>'BETRAG1'
,p_display_order=>141
,p_column_identifier=>'Y'
,p_column_label=>'Betrag1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2154079904146000)
,p_db_column_name=>'KK_BETRAG'
,p_display_order=>151
,p_column_identifier=>'Z'
,p_column_label=>'Kk Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49536900625973683)
,p_db_column_name=>'PK_BEI_KK_KRANKENKASSE_DET'
,p_display_order=>161
,p_column_identifier=>'AA'
,p_column_label=>'Pk Bei Kk Krankenkasse Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537007987973684)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>171
,p_column_identifier=>'AB'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50546467119944518)
,p_db_column_name=>'LFD_SUMME'
,p_display_order=>181
,p_column_identifier=>'AC'
,p_column_label=>'Lfd Summe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50546599847944519)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>191
,p_column_identifier=>'AD'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3416957475949902)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'127271'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'DATUM:BUCHUNGSTEXT:KRANKENKASSE:BEMERKUNG:LFD_SUMME:BETRAG:BETRAG_UEB:PK_BEI_KK_KRANKENKASSE_DET::PK_BAS_KAL_ARBEITSTAGE'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'MONAT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'TAG'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'GEZAHLTER_BETRAG:BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(50595077495583104)
,p_report_id=>wwv_flow_api.id(3416957475949902)
,p_name=>unistr('\00DCberweisung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KTO_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_KTO_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5967845099354056)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'erledigt'
,p_report_seq=>10
,p_report_alias=>'152780'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM:BUCHUNGSTEXT:VON:BIS:BEMERKUNG:SUMME:PROJEKTBEMERKUNG:TAG:MONAT:JAHR:GEZAHLTER_KRANKENKASSE::VERWENDUNGSZWECK:IBAN:BILD:BILD1:BETRAG_UEB'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'MONAT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PK_IMP_BA_KRANKENKASSE'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR:MONAT'
,p_break_enabled_on=>'JAHR:MONAT'
,p_sum_columns_on_break=>'GEZAHLTER_BETRAG:BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5968640649354065)
,p_report_id=>wwv_flow_api.id(5967845099354056)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5968203516354063)
,p_report_id=>wwv_flow_api.id(5967845099354056)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSTEXT'
,p_operator=>'='
,p_expr=>unistr('\2020berweisung')
,p_condition_sql=>'"BUCHUNGSTEXT" = #APXWS_EXPR#'
,p_condition_display=>unistr('#APXWS_COL_NAME# = ''\2020berweisung''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4251910915682326)
,p_plug_name=>unistr('Konto Buchungen Krankenkassenbeitr\00E4ge')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto_zus.*, round(kto_zus.Betrag,2) wert, apex_item.checkbox2(1, kto_zus.fk_main_key) sel, kk.fk_kto_buchung, kk.pk_bei_kk_krankenkasse_det, relbel.fk_lex_relation, betrageur, fk_inp_belege_all,',
'case when datum_buchung_ok is not null then  1 else 0 end dat_buch, pk_rel_lex_kto_bel',
'from v_kto_konten_zus kto_zus',
' left join t_bei_kk_krankenkasse_det kk on kk.fk_kto_buchung = kto_zus.fk_main_key',
' left join t_rel_lex_kto_bel relbel on kto_zus.fk_main_key = relbel.fk_main_key',
' left join t_lex_long ll on ll.relation  = relbel.fk_lex_relation',
' left join t_inp_belege_all inp on inp.pk_inp_belege_all  = relbel.fk_inp_belege_all',
'where instr(kto_zus.buchungstext, ''Kranken'')>0 ',
'  or kto_zus.FK_bas_kat_Kategorie = 28'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4252020079682327)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::P144_PK_BEI_KK_KRANKENKASSE_DET:#PK_BEI_KK_KRANKENKASSE_DET#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13562155320103248
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4252121736682328)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4252211763682329)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4304293134853285)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4304914673853291)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305061455853292)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305138865853293)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bucht tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305232506853294)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Bucht monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305292801853295)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305370616853296)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Bucht datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305518585853297)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Wertt tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305603354853298)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Wertt monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305711989853299)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Wertt jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305792385853300)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Wertt datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4305972500853302)
,p_db_column_name=>'WERT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4306142257853303)
,p_db_column_name=>'SEL'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537155762973685)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>270
,p_column_identifier=>'AB'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537243022973686)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>280
,p_column_identifier=>'AC'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537327236973687)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>290
,p_column_identifier=>'AD'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537404318973688)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537523614973689)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537617419973690)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537725262973691)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537826525973692)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49537880878973693)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538079728973694)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538089114973695)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538189526973696)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538298896973697)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538427789973698)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538560366973699)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538630309973700)
,p_db_column_name=>'IBAN'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538772441973701)
,p_db_column_name=>'BANK'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538792409973702)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>440
,p_column_identifier=>'AS'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49538936627973703)
,p_db_column_name=>'TBL'
,p_display_order=>450
,p_column_identifier=>'AT'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49539053891973704)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>460
,p_column_identifier=>'AU'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2193907749868382)
,p_db_column_name=>'PK_BEI_KK_KRANKENKASSE_DET'
,p_display_order=>470
,p_column_identifier=>'AV'
,p_column_label=>'Pk Bei Kk Krankenkasse Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643347696796024)
,p_db_column_name=>'UMSATZART'
,p_display_order=>480
,p_column_identifier=>'AW'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643462381796025)
,p_db_column_name=>'SALDO'
,p_display_order=>490
,p_column_identifier=>'AX'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643567249796026)
,p_db_column_name=>'AUFTRAGGEBERKONTO'
,p_display_order=>500
,p_column_identifier=>'AY'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643603094796027)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>510
,p_column_identifier=>'AZ'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643799305796028)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>520
,p_column_identifier=>'BA'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643891285796029)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>530
,p_column_identifier=>'BB'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49643999587796030)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>540
,p_column_identifier=>'BC'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49644009131796031)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>550
,p_column_identifier=>'BD'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49644128594796032)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>560
,p_column_identifier=>'BE'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49644249154796033)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>570
,p_column_identifier=>'BF'
,p_column_label=>'Fk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.::P229_PK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49644379535796034)
,p_db_column_name=>'DAT_BUCH'
,p_display_order=>580
,p_column_identifier=>'BG'
,p_column_label=>'Dat Buch'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_PK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#DAT_BUCH#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49644407173796035)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>590
,p_column_identifier=>'BH'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.::P252_FK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(24827626361572413)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>600
,p_column_identifier=>'BI'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(24827787088572414)
,p_db_column_name=>'BETRAG'
,p_display_order=>610
,p_column_identifier=>'BJ'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(24827856159572415)
,p_db_column_name=>'KONTOSTAND_EUR'
,p_display_order=>620
,p_column_identifier=>'BK'
,p_column_label=>'Kontostand Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(24827912017572416)
,p_db_column_name=>'FK_KTO_KONTO_AUSZUG'
,p_display_order=>630
,p_column_identifier=>'BL'
,p_column_label=>'Fk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4316166934858507)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'136264'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_BEI_KK_KRANKENKASSE_DET:BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:FK_MAIN_KEY:BANK:PK_REL_LEX_KTO_BEL:DAT_BUCH:FK_INP_BELEGE_ALL:FK_LEX_RELATIONEUR:WERT:SEL:ID:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_DATUM:WERTT_DATUM:WERTT_JAHR:WERTT_MONAT:WERTT_TAG'
||':FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BANKKONTO:KTO_BEZEICHNUNG:IBAN:DATUM_LEX_BUCHUNG_OK:TBL:FK_KTO_BUCHUNG:UMSATZART:A'
||'UFTRAGGEBER:EMPFAENGER:FLG_KREDITKARTENBUCHUNG:FK_EIN_AUS::BUCHUNGSTAG:BETRAG:KONTOSTAND_EUR:FK_KTO_KONTO_AUSZUG'
,p_sort_column_1=>'BUCHT_JAHR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'BUCHT_MONAT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'BUCHT_TAG'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'BUCHT_TAG'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:FK_MAIN_KEY:BANK'
,p_break_enabled_on=>'0:BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:FK_MAIN_KEY:BANK'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(50593532450553186)
,p_report_id=>wwv_flow_api.id(4316166934858507)
,p_name=>'ok_inp_beleg'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DAT_BUCH'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DAT_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(50593950954553186)
,p_report_id=>wwv_flow_api.id(4316166934858507)
,p_name=>'buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_RELATION'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_LEX_RELATION" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(50594394916553187)
,p_report_id=>wwv_flow_api.id(4316166934858507)
,p_name=>'Beitrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_BEI_KK_KRANKENKASSE_DET'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_BEI_KK_KRANKENKASSE_DET" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#47C936'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2436275166501628)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3411489751949372)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2153563881145995)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(3411489751949372)
,p_button_name=>unistr('ADD_\00DCberweisung')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Add \00DCberweisung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2153438092145994)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(3411489751949372)
,p_button_name=>'ADD_Arbeitstag'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Add Arbeitstag'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3416431549949380)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3411489751949372)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.:144'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2448707328004667)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(3411489751949372)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8581498315477705)
,p_branch_name=>'Go To Page 144'
,p_branch_action=>'f?p=&APP_ID.:144:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8580726950477705)
,p_branch_name=>'Go To Page 142'
,p_branch_action=>'f?p=&APP_ID.:142:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2153677172145996)
,p_name=>'P143_FK_MAIN_KEY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3411489751949372)
,p_prompt=>'Fk Main Key'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_MAIN_KEY_BUCHUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  zus.fk_main_key  || '' '' || Buchungstag || '' '' || round(Betrag,2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum ||  '' '' ||   mark_buchung   d',
'    ,',
'    zus.FK_MAIN_KEY r',
'from v_kto_konten_zus zus',
' left join (',
' ',
' ',
' select  distinct fk_main_key, listagg(buchung, '' / '') over (partition by fk_main_key) mark_buchung',
' from (',
' select fk_main_key,  case when lex_buchung = ''Buchung'' then ''Buchung'' when inpBel_status = ''vorbereitet'' then ''vorbereitet'' else ''nix!!!'' end buchung',
' from (',
' select fk_main_key, case when fk_std_inp_status = 11 then ''vorbereitet'' else null end inpbel_status , case when fk_lex_relation is not null then ''Buchung'' else null end lex_buchung, row_number() over (partition by fk_main_key order by fk_main_key) r'
||'nr',
' from t_rel_lex_kto_bel relbel',
'   left join t_inp_belege_all inp on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
' ',
' ) a',
' where rnr <=10',
' )b',
' ) mark_buch on mark_buch.fk_main_key = zus.fk_main_key'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2153735661145997)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('add_\00FCberweisung')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    "PKG_IMP_BA".p_imp_ba_krankk_add_\00FCb (:P143_FK_MAIN_KEY);'),
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2153563881145995)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2153834599145998)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_arbeitstage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'   "PKG_IMP_BA".p_imp_ba_krankk_add_arb;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2153438092145994)
);
wwv_flow_api.component_end;
end;
/
