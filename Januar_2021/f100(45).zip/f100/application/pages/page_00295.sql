prompt --application/pages/page_00295
begin
--   Manifest
--     PAGE: 00295
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>295
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'check_kto_buch_lex'
,p_alias=>'CHECK_KTO_BUCH_LEX_295'
,p_step_title=>'check_kto_buch_lex'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42901582232549956)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210205202452'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6182104679135497)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27609843614294925)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6415276574431645)
,p_plug_name=>unistr('Pr\00FCfung Zuordnung zur Kontobuchung')
,p_parent_plug_id=>wwv_flow_api.id(27609843614294925)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1, kto_zus.fk_main_key) chk, kto_zus.*, pk_rel_lex_kto_bel, case when pk_rel_lex_kto_bel is null then 0 else 1 end zuord, ',
'rel_lex.habenkto, rel_lex.sollkto, rel_lex.relation, rel_lex.betrageur lex_betragEur, rel_lex.fk_inp_belege_all, fk_std_lex_storno',
'from (',
'       select * from v_kto_konten_zus where bucht_jahr = :P295_new and (Kontotyp is null or Kontotyp <> ''Paypal'') and fk_kto_konto_auszug is not null',
') kto_zus',
' left join v_rel_lex rel_lex on kto_zus.fk_main_key = rel_lex.fk_main_key',
' left join t_lex_long ll on rel_lex.fk_lex_relation = ll.relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6415376954431645)
,p_name=>'check_kto_buch_lex'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252:P252_PK_REL_LEX_KTO_BEL,P252_FK_MAIN_KEY:#PK_REL_LEX_KTO_BEL#,#FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>7855696229823185
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6415726598431658)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6416123928431663)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6418549448431664)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6420919185431667)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6421314788431667)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6421767491431669)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6422139921431669)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6422547006431669)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6422927830431669)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6423351152431670)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6423738994431670)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6424164546431670)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6424546170431672)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6425720026431674)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6426120548431674)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6426578343431675)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6426945689431675)
,p_db_column_name=>'IBAN'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6427331160431675)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6427685560431675)
,p_db_column_name=>'ZUORD'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Zuord'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6182406927135500)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AF'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6182493532135501)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>51
,p_column_identifier=>'AG'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6182655673135502)
,p_db_column_name=>'RELATION'
,p_display_order=>61
,p_column_identifier=>'AH'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.::P253_FK_LEX_RELATION_MAIN:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3639517686291375)
,p_db_column_name=>'CHK'
,p_display_order=>71
,p_column_identifier=>'AI'
,p_column_label=>'Chk'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15381548366545404)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>81
,p_column_identifier=>'AJ'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15381673078545405)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>91
,p_column_identifier=>'AK'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15381755492545406)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>101
,p_column_identifier=>'AL'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15381806170545407)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>111
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15381957869545408)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>121
,p_column_identifier=>'AN'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382028587545409)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>131
,p_column_identifier=>'AO'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382115381545410)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>141
,p_column_identifier=>'AP'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382230107545411)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>151
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382318232545412)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>161
,p_column_identifier=>'AR'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382417971545413)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>171
,p_column_identifier=>'AS'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382511625545414)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>181
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382618477545415)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>191
,p_column_identifier=>'AU'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382710238545416)
,p_db_column_name=>'BANK'
,p_display_order=>201
,p_column_identifier=>'AV'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382868573545417)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>211
,p_column_identifier=>'AW'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15382965913545418)
,p_db_column_name=>'TBL'
,p_display_order=>221
,p_column_identifier=>'AX'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467029362642545)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>231
,p_column_identifier=>'AY'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467164303642546)
,p_db_column_name=>'BETRAG'
,p_display_order=>241
,p_column_identifier=>'AZ'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467258874642547)
,p_db_column_name=>'UMSATZART'
,p_display_order=>251
,p_column_identifier=>'BA'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467315055642548)
,p_db_column_name=>'SALDO'
,p_display_order=>261
,p_column_identifier=>'BB'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467485507642549)
,p_db_column_name=>'AUFTRAGGEBERKONTO'
,p_display_order=>271
,p_column_identifier=>'BC'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27467511239642550)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>281
,p_column_identifier=>'BD'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541256994690501)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>291
,p_column_identifier=>'BE'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541380946690502)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>301
,p_column_identifier=>'BF'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541441527690503)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>311
,p_column_identifier=>'BG'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541526816690504)
,p_db_column_name=>'KONTOSTAND_EUR'
,p_display_order=>321
,p_column_identifier=>'BH'
,p_column_label=>'Kontostand Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541672140690505)
,p_db_column_name=>'FK_KTO_KONTO_AUSZUG'
,p_display_order=>331
,p_column_identifier=>'BI'
,p_column_label=>'Fk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27541836050690507)
,p_db_column_name=>'LEX_BETRAGEUR'
,p_display_order=>341
,p_column_identifier=>'BK'
,p_column_label=>'Lex Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27609509168294922)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>351
,p_column_identifier=>'BL'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27610126884294928)
,p_db_column_name=>'FK_STD_LEX_STORNO'
,p_display_order=>361
,p_column_identifier=>'BM'
,p_column_label=>'Fk Std Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6428082345433419)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'78685'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:FK_MAIN_KEY:FK_INP_BELEGE_ALL:KATEGORIE:FK_BUCHUNG_STEUER:FK_KTO_KONTO_AUSZUG:PK_REL_LEX_KTO_BEL:CHK:ID:BETRAG:LEX_BETRAGEUR:FK_STD_LEX_STORNO:HABENKTO:SOLLKTO:BUCHUNGSTEXT:VERWENDUNGSZWECK:RELATION:BUCHT_DATUM:WERTT_'
||'TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:IBAN:ZUORD:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:KONTOTYP:FK_KTO_VORGANG:FK_KTO_BANKKONTO:KTO_BEZEICHNUNG:BANK:DATUM_LEX_BUCHUNG_OK:TBL:BUCHUNGSTAG:UMSATZART:AUFTRAGGEBE'
||'R:EMPFAENGER:FLG_KREDITKARTENBUCHUNG:FK_EIN_AUS:KONTOSTAND_EUR:AUFTRAGGEBERKONTO:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_STD_KTO_KONTOTYP:FREMDWAEHRUNG:FREMDWAEHRUNGSBETRAG:SALDO:WAEHRUNG:'
,p_sort_column_1=>'BUCHT_TAG'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'BUCHT_MONAT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'KATEGORIE:BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:FK_MAIN_KEY:0'
,p_break_enabled_on=>'BUCHT_JAHR:0'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27760220962701201)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_name=>'kto_betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BETRAG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27760617446701201)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_LEX_STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_STD_LEX_STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D64C40'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27761056391701202)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_name=>'lex_betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LEX_BETRAGEUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LEX_BETRAGEUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27761437787701202)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_name=>'booked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27758614509701200)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2017'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27759077034701200)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_MONAT'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"BUCHT_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27759402552701201)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'IBAN'
,p_operator=>'='
,p_expr=>'DE07430400360393191200'
,p_condition_sql=>'"IBAN" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''DE07430400360393191200''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27759863843701201)
,p_report_id=>wwv_flow_api.id(6428082345433419)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"ZUORD" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27541995915690508)
,p_plug_name=>'Summe pro Monat'
,p_parent_plug_id=>wwv_flow_api.id(27609843614294925)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bucht_jahr, bucht_monat, min(buchungstag) min_buchungstag, max(buchungstag) max_buchungstag, sum(betrag) sum_brutto_betrag, iban, count(*) cnt, max(case when fk_std_gir_monatsanfang_monatsende = 1 then saldo else 0 end) first_saldo, max(case w'
||'hen fk_std_gir_monatsanfang_monatsende =  2 then saldo else 0 end) last_saldo,',
' max(case when fk_std_gir_monatsanfang_monatsende = 2 then saldo else 0 end)-max(case when fk_std_gir_monatsanfang_monatsende = 1 then saldo else 0 end) diff_saldo',
'from (',
'       select zus.*, gir.fk_std_gir_monatsanfang_monatsende,',
'        row_number() over (partition by zus.bucht_jahr, zus.bucht_monat,zus.iban order by zus.bucht_jahr, zus.bucht_monat, zus.bucht_tag, zus.fk_main_key) first_day_of_month,',
'        row_number() over (partition by zus.bucht_jahr, zus.bucht_monat,zus.iban order by zus.bucht_jahr, zus.bucht_monat, zus.bucht_tag desc, zus.fk_main_key) last_day_of_month ',
'        from v_kto_konten_zus zus ',
'            left join t_kto_girokonto gir on gir.fk_main_key = zus.fk_main_key',
'        where bucht_jahr = :P295_new and (Kontotyp is null or Kontotyp <> ''Paypal'')',
') kto_zus',
'group by iban, bucht_jahr, bucht_monat'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(27542072250690509)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252:P252_PK_REL_LEX_KTO_BEL,P252_FK_MAIN_KEY:#PK_REL_LEX_KTO_BEL#,#FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>27542072250690509
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27542444172690513)
,p_db_column_name=>'IBAN'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27607589207294902)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>430
,p_column_identifier=>'B'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27607650287294903)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>440
,p_column_identifier=>'C'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27608562369294912)
,p_db_column_name=>'SUM_BRUTTO_BETRAG'
,p_display_order=>470
,p_column_identifier=>'F'
,p_column_label=>'Sum Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27608782963294914)
,p_db_column_name=>'MIN_BUCHUNGSTAG'
,p_display_order=>490
,p_column_identifier=>'H'
,p_column_label=>'Min Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27608869580294915)
,p_db_column_name=>'MAX_BUCHUNGSTAG'
,p_display_order=>500
,p_column_identifier=>'I'
,p_column_label=>'Max Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27608980160294916)
,p_db_column_name=>'CNT'
,p_display_order=>510
,p_column_identifier=>'J'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27609096923294917)
,p_db_column_name=>'FIRST_SALDO'
,p_display_order=>520
,p_column_identifier=>'K'
,p_column_label=>'First Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27609189637294918)
,p_db_column_name=>'LAST_SALDO'
,p_display_order=>530
,p_column_identifier=>'L'
,p_column_label=>'Last Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27609232633294919)
,p_db_column_name=>'DIFF_SALDO'
,p_display_order=>540
,p_column_identifier=>'M'
,p_column_label=>'Diff Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(27615177363316648)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'276152'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IBAN:BUCHT_MONAT:BUCHT_JAHR:SUM_BRUTTO_BETRAG:MIN_BUCHUNGSTAG:MAX_BUCHUNGSTAG:CNT:FIRST_SALDO:LAST_SALDO:DIFF_SALDO'
,p_sort_column_1=>'BUCHT_MONAT'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27634836686279755)
,p_report_id=>wwv_flow_api.id(27615177363316648)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'IBAN'
,p_operator=>'='
,p_expr=>'DE07430400360393191200'
,p_condition_sql=>'"IBAN" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''DE07430400360393191200''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6430600672639122)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Lexware'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lexware'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:243:&SESSION.::&DEBUG.:RP,243::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6435504946894227)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6435790581895900)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Lex_Kontenplan'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lex Kontenplan'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:257:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6182259533135498)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Refresh'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Refresh'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3639732158291377)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Add_new_inp_bel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Add New Inp Bel'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6963036630006842)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(6182104679135497)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6182364961135499)
,p_name=>'P295_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6182104679135497)
,p_item_default=>'2018'
,p_prompt=>'New'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2016;2016,2017;2017,2018;2018,2019;2019'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6530968338878399)
,p_name=>'P295_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6182104679135497)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3639839274291378)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'for i in 1..apex_application.g_f01.count loop',
'',
' if apex_application.g_f01(i) is not null    then',
'',
'  p_add_new_inp_bel_kto (apex_application.g_f01(i),:P295_PK_ABL_ORDNER_PAGE);',
' end if;',
' end loop;',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3639732158291377)
);
wwv_flow_api.component_end;
end;
/
