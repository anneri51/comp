prompt --application/shared_components/navigation/lists/list_kto_paypal
begin
--   Manifest
--     LIST: List - KTO - Paypal
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(8010393263486757)
,p_name=>'List - KTO - Paypal'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8011374111486769)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Paypal Vorgang\00FCbersicht')
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8019013868486776)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Paypal Buchung'
,p_list_item_link_target=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8014806730486774)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Paypal Zuordnung - Kontobuchung'
,p_list_item_link_target=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
