prompt --application/pages/page_00164
begin
--   Manifest
--     PAGE: 00164
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>164
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>unistr('\00DCberweisung eigenes Konto Zuordnen')
,p_step_title=>unistr('\00DCberweisung eigenes Konto Zuordnen')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42875355428359647)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200620152241'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5327424350655017)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5371404723337615)
,p_plug_name=>unistr('\00DCberweisung eigenes Konto Zuordnen')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   distinct',
'apex_item.checkbox(1, kred.fk_main_key || '','' || ktoz.fk_main_key) sel,',
'              kred.id,',
'              kred.fk_main_key,',
'              kred."Buchungstag",',
'              kred."Betrag",',
'              kred."Beleg",',
'              kred."Unternehmen",',
'              kred."Belastete Kreditkarte",',
'              kred.FK_bas_kat_Kategorie,',
'              kred.FK_std_verw_Verwendungszweck,',
'              kred.fk_bas_kal_buchungstag,',
'              kred.FK_Std_kto_Kontotyp,',
'              --',
'              ktoz.id ktoz_id,',
'              ktoz.fk_main_key ktoz_fk_main_key,',
'              ktoz."Buchungstag" ktoz_Buchungstag,',
'              ktoz."Betrag" ktoz_Betrag,',
'              ktoz.Buchungstext ktoz_Buchungstext,',
'              ktoz.FK_bas_kat_Kategorie ktoz_FK_Kategorie,',
'              ktoz.FK_std_verw_Verwendungszweck ktoz_FK_Verwendungszweck,',
'              ktoz.FK_std_kto_Kontotyp ktoz_FK_Kontotyp,',
'              ktoz.fk_bas_kal_buchungstag ktoz_fk_bas_kal_buchungstag,',
'              ktoz.kategorie,',
'              ktoz.bucht_tag,',
'              ktoz.bucht_monat,',
'              ktoz.bucht_jahr,',
'              ktoz.bucht_datum,',
'              ktoz.wertt_tag,',
'              ktoz.wertt_monat,',
'              ktoz.wertt_jahr,',
'              ktoz.wertt_datum,',
'              ktoz.Kontotyp,',
'              --',
'              case when kred.fk_kto_konto_buch1 = ktoz.fk_main_key or kred.fk_kto_konto_buch2 = ktoz.fk_main_key  then 1 else 0 end zugeord',
'    from (',
'                select * ',
'                from t_KTO_Kreditkarte kred',
'                  left join t_rel_kto_kont_buch_kont_buch ktob on ktob.fk_kto_konto_buch1 = kred.fk_main_key or ktob.fk_kto_konto_buch2 = kred.fk_main_key',
'                where FK_bas_kat_Kategorie in(74)',
'          ) kred',
'     -- left Join t_rel_kto_kont_buch_kont_BUCH KTOB ON (KTOB.fk_kto_konto_buch2 = kred.fk_main_key or  KTOB.fk_kto_konto_buch1 = kred.fk_main_key)',
'      , v_kto_konten_zus ktoz ',
'      ',
'    where  (kred.FK_std_kto_Kontotyp <> ktoz.FK_std_kto_Kontotyp and abs(round(kred."Betrag",2)) = abs(round(ktoz."Betrag",2))) and ktoz.fK_bas_kat_Kategorie = 75'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5371530437337615)
,p_name=>unistr('\00DCberweisung eigenes Konto Zuordnen')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>14681665677758536
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5371952792337629)
,p_db_column_name=>'SEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5372607955337630)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5373055806337631)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5373435699337631)
,p_db_column_name=>'Buchungstag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5374177191337632)
,p_db_column_name=>'Beleg'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5374624135337632)
,p_db_column_name=>'Unternehmen'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5377311173337635)
,p_db_column_name=>'KTOZ_ID'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Ktoz Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5377752075337636)
,p_db_column_name=>'KTOZ_FK_MAIN_KEY'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Ktoz Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5378069884337636)
,p_db_column_name=>'KTOZ_BUCHUNGSTAG'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Ktoz Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5378888119337637)
,p_db_column_name=>'KTOZ_BUCHUNGSTEXT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Ktoz Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5379660933337638)
,p_db_column_name=>'KTOZ_FK_KATEGORIE'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Ktoz Fk Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5380022547337638)
,p_db_column_name=>'KTOZ_FK_VERWENDUNGSZWECK'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Ktoz Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5380369489337639)
,p_db_column_name=>'KTOZ_FK_KONTOTYP'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Ktoz Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5381232813337639)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5381626750337640)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5381985491337641)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5382713402337642)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5383142932337642)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5383534394337642)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5383934081337643)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5384291442337643)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5384703425337644)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5385839011337645)
,p_db_column_name=>'ZUGEORD'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Zugeord'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5327797436655021)
,p_db_column_name=>'Betrag'
,p_display_order=>42
,p_column_identifier=>'AG'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5327872137655022)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>52
,p_column_identifier=>'AH'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5327968253655023)
,p_db_column_name=>'KTOZ_BETRAG'
,p_display_order=>62
,p_column_identifier=>'AI'
,p_column_label=>'Ktoz betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49800981108952168)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>72
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49801150779952169)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>82
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49801254192952170)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>92
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49801351073952171)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>102
,p_column_identifier=>'AM'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49801463029952172)
,p_db_column_name=>'KTOZ_FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>112
,p_column_identifier=>'AN'
,p_column_label=>'Ktoz Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49801578016952173)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>122
,p_column_identifier=>'AO'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5386208067340192)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'146964'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:ID:FK_MAIN_KEY:Buchungstag:Beleg:Unternehmen:KTOZ_ID:KTOZ_FK_MAIN_KEY:KTOZ_BUCHUNGSTAG:KTOZ_BUCHUNGSTEXT:KTOZ_FK_KATEGORIE:KTOZ_FK_VERWENDUNGSZWECK:KTOZ_FK_KTOZ_FK_BUCHUNGSTAG:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT'
||'_MONAT:WERTT_JAHR:WERTT_DATUM:ZUGEORD:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_BUCHUNGSTAG:FK_STD_KTO_KTOZ_FK_BAS_KAL_BUCHUNGSTAG:KONTOTYP'
,p_break_on=>'FK_MAIN_KEY'
,p_break_enabled_on=>'FK_MAIN_KEY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5387477010363083)
,p_report_id=>wwv_flow_api.id(5386208067340192)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUGEORD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUGEORD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5327662110655019)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5327424350655017)
,p_button_name=>'Zuordnung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Zuordnung'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5327665785655020)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'     insert into t_rel_kont_buch_kont_buch (',
'      fk_konto_buch1,',
'         fk_konto_buch2,',
'         created_at',
'     )',
'     values (substr(apex_application.g_f01(i),1,instr(apex_application.g_f01(i),'','')-1),',
'             substr(apex_application.g_f01(i),instr(apex_application.g_f01(i),'','')+1,(length(apex_application.g_f01(i))-instr(apex_application.g_f01(i),'',''))),',
'             sysdate',
'     );',
'    commit;',
'   end if;',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
