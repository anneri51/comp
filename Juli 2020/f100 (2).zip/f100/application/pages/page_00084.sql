prompt --application/pages/page_00084
begin
--   Manifest
--     PAGE: 00084
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>84
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Route_zoom'
,p_step_title=>'Route_zoom'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42860129893221480)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <meta name="viewport" content="initial-scale=1.0, width=device-width" />',
'<link rel="stylesheet" type="text/css" href="https://js.api.here.com/v3/3.0/mapsjs-ui.css?dp-version=1533195059" />',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-core.js" type="text/javascript" charset="utf-8"></script>',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-service.js" type="text/javascript" charset="utf-8"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-ui.js"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-mapevents.js"></script>'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function addDraggableMarker(map, behavior){',
'',
'  var marker = new H.map.Marker({lat:42.35805, lng:-71.0636});',
'  // Ensure that the marker can receive drag events',
'  marker.draggable = true;',
'  map.addObject(marker);',
'',
'  // disable the default draggability of the underlying map',
'  // when starting to drag a marker object:',
'  map.addEventListener(''dragstart'', function(ev) {',
'    var target = ev.target;',
'    if (target instanceof H.map.Marker) {',
'      behavior.disable();',
'    }',
'  }, false);',
'',
'',
'  // re-enable the default draggability of the underlying map',
'  // when dragging has completed',
'  map.addEventListener(''dragend'', function(ev) {',
'    var target = ev.target;',
'    if (target instanceof mapsjs.map.Marker) {',
'      behavior.enable();',
'    }',
'  }, false);',
'',
'  // Listen to the drag event and move the position of the marker',
'  // as necessary',
'   map.addEventListener(''drag'', function(ev) {',
'    var target = ev.target,',
'        pointer = ev.currentPointer;',
'    if (target instanceof mapsjs.map.Marker) {',
'      target.setPosition(map.screenToGeo(pointer.viewportX, pointer.viewportY));',
'    }',
'  }, false);',
'}',
'',
'/**',
' * Boilerplate map initialization code starts below:',
' */',
'',
'//Step 1: initialize communication with the platform',
'var platform = new H.service.Platform({',
'  app_id: ''devportal-demo-20180625'',',
'  app_code: ''9v2BkviRwi9Ot26kp2IysQ'',',
'  useHTTPS: true',
'});',
'var pixelRatio = window.devicePixelRatio || 1;',
'var defaultLayers = platform.createDefaultLayers({',
'  tileSize: pixelRatio === 1 ? 256 : 512,',
'  ppi: pixelRatio === 1 ? undefined : 320',
'});',
'',
'//Step 2: initialize a map - this map is centered over Boston',
'var map = new H.Map(document.getElementById(''mapContainer''),',
'  defaultLayers.normal.map,{',
'  center: {lat:42.35805, lng:-71.0636},',
'  zoom: 12,',
'  pixelRatio: pixelRatio',
'});',
'',
'//Step 3: make the map interactive',
'// MapEvents enables the event system',
'// Behavior implements default interactions for pan/zoom (also on mobile touch environments)',
'var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));',
'',
'// Step 4: Create the default UI:',
'var ui = H.ui.UI.createDefault(map, defaultLayers, ''en-US'');',
'',
'// Add the click event listener.',
'addDraggableMarker(map, behavior);'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524081715'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33954420278251136)
,p_plug_name=>'Route'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'width="50"'
,p_plug_display_point=>'BODY'
,p_plug_source=>' <div style="width: 640px; height: 480px" id="mapContainer">Monteursroute</div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'font-size:24px;'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1751109579394400)
,p_name=>'P84_CTR_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33954420278251136)
,p_prompt=>'Ctr lat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1751505182394401)
,p_name=>'P84_CTR_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33954420278251136)
,p_prompt=>'Ctr lng'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1751871563394401)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :P84_CTR_LAT := 54.13;',
'  :P84_CTR_LNG := 10.13;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
