prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>113
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Allgemeine Belege'
,p_step_title=>'Allgemeine Belege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619173103'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3061207560828095)
,p_plug_name=>'Allgemeine Belege'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'    nvl(allg_bel."BEZEICHNUNG", ''<<Keine Angabe>>'') Bezeichnung,',
'    allg_bel."LAND",',
'    allg_bel."S1",',
'    allg_bel."S2",',
'    allg_bel."BETRAG",',
'    allg_bel.Waehrung, ',
'    allg_bel."S4",',
'    allg_bel.Steuersatz,',
'    allg_bel."S6",',
'    allg_bel."STEUERNUMMER",',
'    allg_bel."DATUM",',
'    allg_bel."UHRZEIT",',
'    allg_bel."BELEGNUMMER",',
'    allg_bel."ZAHLUNGSART",',
'    allg_bel."BELEG",',
'    allg_bel.Verwendungszweck,',
'    allg_bel."SONSTIGES2",',
'    allg_bel."S7",',
'    allg_bel."S8",',
'    allg_bel."S9",',
'    allg_bel."S10",',
'    allg_bel.fk_bas_kal_arbeitstag,',
'    allg_bel.pk_imp_ba_allg_bel,',
'    allg_bel.fk_kto_buchung,',
'    arb.monat || '' '' || arb.jahr monat_jahr,',
'    arb.jahr,',
'    case when   allg_bel.pk_imp_ba_allg_bel = :P113_PK_IMP_BA_ALLG_BEL then 1 else 0 end abgl_bel,',
'    allg_bel.WERT,',
'    replace(replace(allg_bel."BEZEICHNUNG",chr(10),''''),chr(13),'''') bez',
'  from IMP_BA_ALLG_BEL  allg_bel',
'  left join t_bas_kal_arbeitstage  arb on allg_bel.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3061568391828096)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::P113_PK_IMP_BA_ALLG_BEL,P113_MONAT_JAHR,P113_DATUM,P113_BETRAG,P113_TEXT:#PK_IMP_BA_ALLG_BEL#,#MONAT_JAHR#,#DATUM#,#WERT#,#BEZ#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12371703632249017
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3062148501828098)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_html_expression=>'<a href=''f?p=&APP_ID.:118:&SESSION.::NO:RP:P118_PK_IMP_BA_ALLG_BEL:#PK_IMP_BA_ALLG_BEL#''>#BEZEICHNUNG#</a>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3062510275828099)
,p_db_column_name=>'LAND'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3062945545828099)
,p_db_column_name=>'S1'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'S1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3063329184828100)
,p_db_column_name=>'S2'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'S2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3063695448828101)
,p_db_column_name=>'BETRAG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3064557259828103)
,p_db_column_name=>'S4'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'S4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3065293428828104)
,p_db_column_name=>'S6'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'S6'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3065741262828105)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3066154411828106)
,p_db_column_name=>'DATUM'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3066471593828107)
,p_db_column_name=>'UHRZEIT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Uhrzeit'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3066936119828108)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3067279414828109)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3067722918828110)
,p_db_column_name=>'BELEG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3068537801828111)
,p_db_column_name=>'SONSTIGES2'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Sonstiges2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3068870714828112)
,p_db_column_name=>'S7'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'S7'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3069316448828113)
,p_db_column_name=>'S8'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'S8'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3069758578828114)
,p_db_column_name=>'S9'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'S9'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3070103932828114)
,p_db_column_name=>'S10'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'S10'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4053268178584621)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>42
,p_column_identifier=>'X'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4053508738584623)
,p_db_column_name=>'MONAT_JAHR'
,p_display_order=>62
,p_column_identifier=>'Z'
,p_column_label=>'Monat jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4053907286584627)
,p_db_column_name=>'ABGL_BEL'
,p_display_order=>72
,p_column_identifier=>'AA'
,p_column_label=>'Abgl bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4308463084853326)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>82
,p_column_identifier=>'AB'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4376392225623617)
,p_db_column_name=>'WERT'
,p_display_order=>92
,p_column_identifier=>'AC'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4377577812623629)
,p_db_column_name=>'BEZ'
,p_display_order=>102
,p_column_identifier=>'AD'
,p_column_label=>'Bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4932897529635804)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>122
,p_column_identifier=>'AF'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5931977416874584)
,p_db_column_name=>'JAHR'
,p_display_order=>132
,p_column_identifier=>'AG'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029100804099991)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>142
,p_column_identifier=>'AH'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029265173099992)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>152
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029329619099993)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>162
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3070989707828758)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123812'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'BEZEICHNUNG:PK_IMP_BA_ALLG_BEL:LAND:S1:S2:BETRAG:ZAHLUNGSART:S4:S6:STEUERNUMMER:DATUM:UHRZEIT:BELEGNUMMER:BELEG:SONSTIGES2:S7:S8:S9:S10:MONAT_ABGL_BEL:STEUERSATZ:WERT:BEZ:VERWENDUNGSZWECK:JAHR:WAEHRUNG:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG'
,p_sort_column_1=>'BEZEICHNUNG'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4635063297953788)
,p_report_id=>wwv_flow_api.id(3070989707828758)
,p_name=>'ausgew'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4635786007953789)
,p_report_id=>wwv_flow_api.id(3070989707828758)
,p_name=>'fk_buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4635464731953788)
,p_report_id=>wwv_flow_api.id(3070989707828758)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4636174631953790)
,p_report_id=>wwv_flow_api.id(3070989707828758)
,p_name=>unistr('W\00E4hrung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'S3'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("S3" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>25
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4051843016584606)
,p_plug_name=>'Selected'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4376538950623618)
,p_plug_name=>'Girokonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:red"'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4001214733759509)
,p_plug_name=>'Girokonto'
,p_parent_plug_id=>wwv_flow_api.id(4376538950623618)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gir.*,',
' apex_item.checkbox2(1, gir.fk_main_key ) sel,',
' case when gir."Wertstellung" = to_date(:P113_Datum,''DD.MM.YYYY'') or gir."Buchungstag" = to_date(:P113_Datum,''DD.MM.YYYY'') then 1 else 0 end abgl_datum,',
' case when abs(round(gir."Betrag",0)) = :P113_Betrag then 1 else 0 end abgl_betrag,',
'  round(gir."Betrag",2) wert,',
'    round(gir."Betrag",0) wert_1,',
'    bel.pk_imp_ba_allg_bel,',
'    substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) next_month',
'',
'from t_KTO_Girokonto gir',
' left join t_bas_kal_arbeitstage arb on gir.fk_bas_kal_buchungstag = arb.pk_bas_kal_arbeitstage',
' left join imp_ba_allg_bel bel on bel.fk_kto_buchung  = gir.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
' or arb.monat   || '' '' || arb.jahr =   substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
' or arb.monat || '' '' || arb.jahr =   substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'',
' or   abs(round(gir."Betrag",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4001306589759510)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13311441830180431
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4001445271759511)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4001538722759512)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4001591531759513)
,p_db_column_name=>'Wertstellung'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4001752716759514)
,p_db_column_name=>'Umsatzart'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4001868370759516)
,p_db_column_name=>'Betrag'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4002507539759522)
,p_db_column_name=>'F12'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'F12'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4002628851759523)
,p_db_column_name=>'F13'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'F13'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4002698557759524)
,p_db_column_name=>'alt_ID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Alt id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4003101114759528)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4003173629759529)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4049446839584582)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052727375584615)
,p_db_column_name=>'SEL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052840726584616)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052933495584617)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4053851563584626)
,p_db_column_name=>'WERT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4054137593584629)
,p_db_column_name=>'WERT_1'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Wert 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110822698257385)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4111090630257388)
,p_db_column_name=>'NEXT_MONTH'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Next month'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029480133099994)
,p_db_column_name=>'Buchungstext'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029568448099995)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029580930099996)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029716021099997)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029788113099998)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029920191099999)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49029984118100000)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030100365100001)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030212669100002)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030354670100003)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030381475100004)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030530178100005)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030608705100006)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030685770100007)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030832123100008)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49030956394100009)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49031067315100010)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49075901256182861)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076017644182862)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076155012182863)
,p_db_column_name=>'SALDO'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076215994182864)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076286760182865)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076443809182866)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076522191182867)
,p_db_column_name=>'FK_KON_EMPFAENGER'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Kon Empfaenger'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076598941182868)
,p_db_column_name=>'BUCHUNGSTAG_DT'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Buchungstag Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076771354182869)
,p_db_column_name=>'WERTSTELLUNG_DT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Wertstellung Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076870777182870)
,p_db_column_name=>'BUCHUNGSTAG_VAR'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Buchungstag Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49076892282182871)
,p_db_column_name=>'WERTSTELLUNG_VAR'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Wertstellung Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077007259182872)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077161804182873)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077233598182874)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077302986182875)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077426210182876)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077536608182877)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077661997182878)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077754848182879)
,p_db_column_name=>'BEGUENSTIGTER'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Beguenstigter'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077878831182880)
,p_db_column_name=>'IBAN_ZUSATZ'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Iban Zusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077893202182881)
,p_db_column_name=>'BIC'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Bic'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49077992858182882)
,p_db_column_name=>'MANDATSREFERENZ'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Mandatsreferenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078106340182883)
,p_db_column_name=>'GLAEUBIGER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Glaeubiger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078208342182884)
,p_db_column_name=>'FREMDGEBUEHREN'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fremdgebuehren'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078354228182885)
,p_db_column_name=>'ABWEICHENDEREMPFAENGER'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Abweichenderempfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078467970182886)
,p_db_column_name=>'ANZAHLAUFTRAEGE'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Anzahlauftraege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078483804182887)
,p_db_column_name=>'ANZAHLSCHECKS'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Anzahlschecks'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4076206176962373)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'133865'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'NEXT_MONTH:SEL:ID:WERT:FK_MAIN_KEY:Buchungstag:Wertstellung:Umsatzart:Betrag:Bankleitzahl IBAN Kategorie:F12:F13:alt_ID:Bemerkungen:BUCHUNGSTEXT:ABGL_DATUM:ABGL_BETRAG:WERT_1:PK_IMP_BA_ALLG_BEL::WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:KATEGORIE:FK_BAS_KAT_KA'
||'TEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_LOC_LOCATION:EMPFAENGER:SALDO:KONTONUMMER:AUFTRAGGEB'
||'ER:FK_KON_AUFTRAGGEBER:FK_KON_EMPFAENGER:BUCHUNGSTAG_DT:WERTSTELLUNG_DT:BUCHUNGSTAG_VAR:WERTSTELLUNG_VAR:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FLG_KREDITKARTENBUCHUNG:LOAD_DATE:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:BEGUENSTIGTER:IBAN_ZUSATZ:BIC'
||':MANDATSREFERENZ:GLAEUBIGER:FREMDGEBUEHREN:ABWEICHENDEREMPFAENGER:ANZAHLAUFTRAEGE:ANZAHLSCHECKS'
,p_break_on=>'Buchungstag'
,p_break_enabled_on=>'Buchungstag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4632111710864717)
,p_report_id=>wwv_flow_api.id(4076206176962373)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4631689100864717)
,p_report_id=>wwv_flow_api.id(4076206176962373)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4632492400864718)
,p_report_id=>wwv_flow_api.id(4076206176962373)
,p_name=>'bel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4632938394864718)
,p_report_id=>wwv_flow_api.id(4076206176962373)
,p_name=>'Row text contains ''MIetwagen'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'MIetwagen'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4376618355623619)
,p_plug_name=>'Kreditkarte'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:blue"'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4049485835584583)
,p_plug_name=>'Kreditkarte'
,p_parent_plug_id=>wwv_flow_api.id(4376618355623619)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
' kred.* , ',
' apex_item.checkbox2(2, kred.fk_main_key ) sel,',
' case when kred."Beleg" =  to_date(:P113_Datum,''DD.MM.YYYY'') or kred."Buchungstag" =  to_date(:P113_Datum,''DD.MM.YYYY'')   then 1 else 0 end abgl_datum,',
' case when abs(round(kred."Betrag",0)) = :P113_Betrag or abs(round(kred."Betrag Ursprung",0)) = :P113_Betrag  then 1 else 0 end abgl_betrag,',
' round(kred."Betrag",2) wert,',
'  round(kred."Betrag Ursprung",2) wert_urspr,',
'  bel.pk_imp_ba_allg_bel',
'from t_KTO_Kreditkarte kred',
' left join t_bas_kal_arbeitstage arb on kred.fk_bas_Kal_buchungstag = arb.pk_bas_kal_arbeitstage',
' left join imp_ba_allg_bel bel on bel.fk_kto_buchung = kred.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
'or arb.monat  || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or arb.monat || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or   abs(round(kred."Betrag",0)) = abs(:P113_Betrag) ',
'or   abs(round(kred."Betrag Ursprung",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4049589103584584)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP:P114_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13359724344005505
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4049748393584585)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4049819332584586)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4049901139584587)
,p_db_column_name=>'Beleg'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4049995904584588)
,p_db_column_name=>'Unternehmen'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4050131426584589)
,p_db_column_name=>'Betrag'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4050266643584591)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Betrag ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4050510362584593)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4050757166584595)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4051146861584599)
,p_db_column_name=>'Dummy'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4051182613584600)
,p_db_column_name=>'Referenz'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Referenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4051342601584601)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk main beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4051394781584602)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052376062584612)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052478879584613)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4052587112584614)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4053674111584625)
,p_db_column_name=>'WERT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4054035657584628)
,p_db_column_name=>'WERT_URSPR'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wert urspr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110913361257386)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5690559177356196)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078616366182888)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>290
,p_column_identifier=>'AD'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078739368182889)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078871241182890)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49078959304182891)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079020943182892)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079113975182893)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079262255182894)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079325630182895)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079468713182896)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079544235182897)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079597592182898)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079777881182899)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079823871182900)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079960896182901)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49079985437182902)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080083682182903)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>440
,p_column_identifier=>'AS'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080235105182904)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>450
,p_column_identifier=>'AT'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080320153182905)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>460
,p_column_identifier=>'AU'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080387282182906)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>470
,p_column_identifier=>'AV'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4077000508962423)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'133872'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:ID:Buchungstag:WERT:WERT_URSPR:Beleg:Unternehmen:Betrag:Betrag Ursprung:Belastete Kreditkarte:FK_MAIN_KEY:Wertstellungsmonat:Dummy:Referenz:FK_MAIN_BELEG:ABGL_DATUM:ABGL_BETRAG:PK_IMP_BA_ALLG_BEL::BEMERKUNG:WAEHRUNG:WAEHRUNG_URSPRUNG:KATEGORIE:FK'
||'_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BEL_BELEG:FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BEMERKUNG:DATUM'
||'_LEX_BUCHUNG_OK:FK_EIN_AUS'
,p_break_on=>'Buchungstag'
,p_break_enabled_on=>'Buchungstag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5136875132649740)
,p_report_id=>wwv_flow_api.id(4077000508962423)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5136553156649739)
,p_report_id=>wwv_flow_api.id(4077000508962423)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5137325343649740)
,p_report_id=>wwv_flow_api.id(4077000508962423)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5137716760649741)
,p_report_id=>wwv_flow_api.id(4077000508962423)
,p_name=>'Row text contains ''store'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'store'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4376678043623620)
,p_plug_name=>'Paypal'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:green"'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4105360291233980)
,p_plug_name=>'Paypal'
,p_parent_plug_id=>wwv_flow_api.id(4376678043623620)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pay.*,',
' apex_item.checkbox2(3, pay.fk_main_key ) sel,',
' case when pay."Datum" = to_date(:P113_Datum,''DD.MM.YYYY'') then 1 else 0 end abgl_datum,',
' case when abs(round(pay."Brutto",0)) = :P113_Betrag then 1 else 0 end abgl_betrag,',
'  round(pay."Brutto",2) wert,',
'  bel.pk_imp_ba_allg_bel',
'from t_KTO_Paypal pay',
' left join t_bas_kal_arbeitstage arb on pay.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
'  left join imp_ba_allg_bel bel on bel.fk_kto_buchung = pay.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
'or arb.monat  || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or arb.monat  || '' '' || arb.jahr =  substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
' or   abs(round(pay."Brutto",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4105414289233981)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13415549529654902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4105488526233982)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4105647288233983)
,p_db_column_name=>'Datum'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4105763063233984)
,p_db_column_name=>'Uhrzeit'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4105823610233985)
,p_db_column_name=>'Zeitzone'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Zeitzone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4105919092233986)
,p_db_column_name=>'Name'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106038869233987)
,p_db_column_name=>'Typ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106140700233988)
,p_db_column_name=>'Status'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106306258233990)
,p_db_column_name=>'Brutto'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106480848233992)
,p_db_column_name=>'Netto'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106569332233993)
,p_db_column_name=>'Absender_Email'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Absender email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106768139233995)
,p_db_column_name=>'Transaktionscode'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4106875145233996)
,p_db_column_name=>'Lieferadresse'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Lieferadresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107028715233997)
,p_db_column_name=>'Adress-Status'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Adress-status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107095207233998)
,p_db_column_name=>'Artikelbezeichnung'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107178356233999)
,p_db_column_name=>'Artikelnummer'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Artikelnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107280535234000)
,p_db_column_name=>'Versand_Bearbeitungsgeb'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Versand bearbeitungsgeb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107422195234001)
,p_db_column_name=>'Versicherungsbetrag'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Versicherungsbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107558542234002)
,p_db_column_name=>'Umsatzsteuer'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107607010234003)
,p_db_column_name=>'Option 1 Name'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Option 1 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107753968234004)
,p_db_column_name=>'Option 1 Wert'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Option 1 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107775701234005)
,p_db_column_name=>'Option 2 Name'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Option 2 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4107894756234006)
,p_db_column_name=>'Option 2 Wert'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Option 2 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108107054234008)
,p_db_column_name=>'Rechnungsnummer'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108262445234009)
,p_db_column_name=>'Zollnummer'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Zollnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108271316234010)
,p_db_column_name=>'Anzahl'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Anzahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108418764234011)
,p_db_column_name=>'Empfangsnummer'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Empfangsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108647597234013)
,p_db_column_name=>'Adresszeile 1'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Adresszeile 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108683983234014)
,p_db_column_name=>'Adresszusatz'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Adresszusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108854417234015)
,p_db_column_name=>'Ort'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4108929016234016)
,p_db_column_name=>'Bundesland'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Bundesland'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109006886234017)
,p_db_column_name=>'PLZ'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109087400234018)
,p_db_column_name=>'Land'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109229146234019)
,p_db_column_name=>'Telefon'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109265540234020)
,p_db_column_name=>'Betreff'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Betreff'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109406277234021)
,p_db_column_name=>'Hinweis'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Hinweis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4109618153234023)
,p_db_column_name=>'Auswirkung_Guthaben'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Auswirkung guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110119109234028)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110269307257380)
,p_db_column_name=>'FK_ZUORD_ERL'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk zuord erl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110455691257381)
,p_db_column_name=>'SEL'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110521293257382)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110616870257383)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4110671360257384)
,p_db_column_name=>'WERT'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4111009763257387)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080566591182907)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080584400182908)
,p_db_column_name=>'GEBUEHR'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Gebuehr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080713230182909)
,p_db_column_name=>'EMPFAENGER_EMAIL'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Empfaenger Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49080783990182910)
,p_db_column_name=>'ZUGEHOERIGER_TRANSAKTIONSCODE'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Zugehoeriger Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131121081195761)
,p_db_column_name=>'Guthaben'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131194839195762)
,p_db_column_name=>'LAENDERVORWAHL'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Laendervorwahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131318637195763)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131404924195764)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131508291195765)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131665236195766)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131751538195767)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131863185195768)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49131889078195769)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132060629195770)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132117346195771)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132243054195772)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132355264195773)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132405897195774)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132549987195775)
,p_db_column_name=>'DUPL_BERMERKUNG'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Dupl Bermerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132619373195776)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49132740435195777)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4132199592269544)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:ID:Datum:WERT:Uhrzeit:Zeitzone:Name:Typ:Status:Brutto:Netto:Absender_Email:Transaktionscode:Lieferadresse:Adress-Status:Artikelbezeichnung:Artikelnummer:Versand_Bearbeitungsgeb:Versicherungsbetrag:Umsatzsteuer:Option 1 Name:Option 1 Wert:Option 2'
||' Name:Option 2 Wert:Rechnungsnummer:Zollnummer:Anzahl:Empfangsnummer:Adresszeile 1:Adresszusatz:Ort:Bundesland:PLZ:Land:Telefon:Betreff:Hinweis:Auswirkung_FK_Kategorie:FK_MAIN_KEY:FK_ZUORD_ERL:ABGL_DATUM:ABGL_BETRAG:PK_IMP_BA_ALLG_BEL::WAEHRUNG:GEBUE'
||'HR:EMPFAENGER_EMAIL:ZUGEHOERIGER_TRANSAKTIONSCODE:LAENDERVORWAHL:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_KTO_VORGANG:FK_BAS_KAL_ARBEITSTAG:FK_BEL_BELEG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BANKKONTO:'
||'FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BERMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4152827076421445)
,p_report_id=>wwv_flow_api.id(4132199592269544)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4152460939421444)
,p_report_id=>wwv_flow_api.id(4132199592269544)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4153224042421445)
,p_report_id=>wwv_flow_api.id(4132199592269544)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4052247134584610)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(4051843016584606)
,p_button_name=>'Zuord'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zuord'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4053642757584624)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(4051843016584606)
,p_button_name=>'Zuord_rem'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Zuord rem'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3070522157828115)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3061207560828095)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.:118'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4051924324584607)
,p_name=>'P113_PK_IMP_BA_ALLG_BEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4051843016584606)
,p_prompt=>'Pk imp ba allg bel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4052001172584608)
,p_name=>'P113_DATUM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4051843016584606)
,p_prompt=>'Datum'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4052082670584609)
,p_name=>'P113_BETRAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4051843016584606)
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4052994126584618)
,p_name=>'P113_MONAT_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4051843016584606)
,p_prompt=>'Monat jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4377501782623628)
,p_name=>'P113_TEXT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(4051843016584606)
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4088975627865989)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f01.count loop',
'           if apex_application.g_f01(j) is not null then',
'           ',
' ',
'             update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f01(j) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f02.count loop',
'        if apex_application.g_f02(k) is not null then',
'        ',
'',
'              update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f02(k) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f03.count loop',
'           if apex_application.g_f03(j) is not null then',
'           ',
' ',
'             update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f03(j) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'',
'          end if;',
'         ',
'         end loop;',
'      ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4052247134584610)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4089304204868966)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen_rem'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'  ',
'    select count(*)',
'    into v_cnt',
'    from "KTO_Paypal"',
'    where id =:P171_SEL_ID;',
'    ',
'    select fk_main_key',
'    into v_fk_main_key',
'    from "KTO_Paypal"',
'    where id = :P171_SEL_ID;',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f02.count loop',
'           if apex_application.g_f02(j) is not null then',
'           ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 =  :P171_PK_IMP_BA_BEL and FK_KONTO_BUCH2 = apex_application.g_f02(j)',
'              ;',
'             commit;',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f03.count loop',
'        if apex_application.g_f03(k) is not null then',
'        ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 =  :P171_PK_IMP_BA_BEL and FK_KONTO_BUCH2 = apex_application.g_f03(k)',
'              ;',
'             commit;',
'           ',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'     --end if;',
'',
'',
'--  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4053642757584624)
);
wwv_flow_api.component_end;
end;
/
