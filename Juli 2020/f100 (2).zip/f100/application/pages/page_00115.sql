prompt --application/pages/page_00115
begin
--   Manifest
--     PAGE: 00115
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>115
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Vorgang'
,p_step_title=>'Vorgang'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619175714'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2637618002043143)
,p_plug_name=>'Vorgang'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       "Bezeichnung",',
unistr('       "Gesch\00E4ftspartner",'),
'       "Betrag",',
unistr('       "Betrag_Fremdw\00E4hrung",'),
unistr('       "Fremdw\00E4hrung",'),
'       "Rechnungsnummer",',
'       "Abschlusstyp",',
'       "Abschlussstatus",',
'       "Abschlussdatum",',
'       "Abschlusszeit",',
'       OK',
'  from t_kto_PP_Vorgang'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2637702404043143)
,p_name=>'Vorgang'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:77:&SESSION.::&DEBUG.:RP:P77_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>11947837644464064
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638460768043151)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638780239043151)
,p_db_column_name=>'Bezeichnung'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639213466043152)
,p_db_column_name=>unistr('Gesch\00E4ftspartner')
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('Gesch\00E4ftspartner')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640450321043153)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640818431043154)
,p_db_column_name=>'Rechnungsnummer'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641249083043154)
,p_db_column_name=>'Abschlusstyp'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Abschlusstyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641597879043154)
,p_db_column_name=>'Abschlussstatus'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Abschlussstatus'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641981942043155)
,p_db_column_name=>'Abschlussdatum'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Abschlussdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642457139043155)
,p_db_column_name=>'Abschlusszeit'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Abschlusszeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2830779161303319)
,p_db_column_name=>'OK'
,p_display_order=>41
,p_column_identifier=>'N'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49165256863268890)
,p_db_column_name=>'Betrag'
,p_display_order=>51
,p_column_identifier=>'O'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49165309204268891)
,p_db_column_name=>unistr('Betrag_Fremdw\00E4hrung')
,p_display_order=>61
,p_column_identifier=>'P'
,p_column_label=>unistr('Betrag Fremdw\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2651502632047777)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'119617'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID:Bezeichnung:Gesch\00E4ftspartner_Fremdw\00E4hrung:Fremdw\00E4hrung:Rechnungsnummer:Abschlusstyp:Abschlussstatus:Abschlussdatum:Abschlusszeit:OK')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2830510780303316)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(6267651341136083)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
