prompt --application/pages/page_00329
begin
--   Manifest
--     PAGE: 00329
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>329
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Verpflegungsmehraufwand_Detail'
,p_step_title=>'Verpflegungsmehraufwand_Detail'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200627134407'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11869911510074988)
,p_plug_name=>'Verpflegungsmehraufwand_Detail'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12054407909567907)
,p_plug_name=>'Ort'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_Steu_STeuer_VERPFL_BELEG_ORT,',
'       FK_Steu_STeuer_VERPFL_MEHRAUFWD_DET,',
'       FK_adr_ORT,',
'       FK_STD_STEU_AUSWAERTS,',
'       CREATION_DATE,',
'       ort,',
'       land',
'  from T_REL_Steu_steuer_VERPFL_BELEG_ORT bel',
'    left join t_adr_ort ort on ort.pk_adr_ort = bel.fk_adr_ort',
'    left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land',
' where fk_steu_steuer_verpfl_mehraufwd_det = :P329_pK_steu_steuer_VERPFL_MEHRAUFWD_DET'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12054648905567909)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13494968180959449
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12142038717878863)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12143080186878873)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12143148061878874)
,p_db_column_name=>'LAND'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662605704795080)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_ORT'
,p_display_order=>120
,p_column_identifier=>'I'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662773677795081)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>130
,p_column_identifier=>'J'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662848211795082)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52662929286795083)
,p_db_column_name=>'FK_STD_STEU_AUSWAERTS'
,p_display_order=>150
,p_column_identifier=>'L'
,p_column_label=>'Fk Std Steu Auswaerts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12150737862903469)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135911'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CREATION_DATE:ORT:LAND:PK_REL_STEU_STEUER_VERPFL_BELEG_ORT:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_ADR_ORT:FK_STD_STEU_AUSWAERTS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16261778011776395)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6227434921135996)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16258983653776368)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(16261778011776395)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_steu_steuer_VERPFL_BELEG_SRC,',
'       bel.FK_steu_steuer_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_proj_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_std_steu_STATUS,',
'      bel.creation_date,',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P329_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      ll.habenkto,',
'      ll.sollkto,',
'      ll.ust_kto',
'   ',
'from T_REL_steu_steuer_VERPFL_BEleG_SRC bel',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_rel_lex_kto_bel relbel on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation  = relbel.fk_lex_relation ',
' where FK_steu_steuer_VERPFL_MEHRAUFWD_DET = :P329_PK_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16259181509776370)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>17699500785167910
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259478568776372)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259557155776373)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16259581524776374)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260076648776378)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260122828776379)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260226591776380)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260359985776381)
,p_db_column_name=>'INP_BEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16260452747776382)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261383360776392)
,p_db_column_name=>'HABENKTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261544600776393)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16261653879776394)
,p_db_column_name=>'UST_KTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664627077795100)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664697654795101)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664857424795102)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664929544795103)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16342480948514217)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'177829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:FK_INP_BELEGE_ALL:CREATION_DATE:PK_INP_BELEGE_ALL:BEL_DATUM:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:HABENKTO:SOLLKTO:UST_KTO:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16355256698670602)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_steu_steuer_VERPFL_BELEG_SRC,',
'       bel.FK_steu_steuer_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_proj_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_std_steu_STATUS,',
'      bel.creation_date,',
'      ',
'   std.*,',
'   projekt',
'from T_REL_steu_steuer_VERPFL_BEleG_SRC bel',
' left join t_proj_stundenzettel std on bel.fk_proj_stundenzettel = std.pk_proj_stundenzettel',
'  left join t_proj_projekt proj on std.fk_proj_projekt  = proj.pk_proj_projekt',
'',
' where FK_steu_steuer_VERPFL_MEHRAUFWD_DET = :P329_PK_steu_steuer_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16355423936670604)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>17795743212062144
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355668114670606)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355748800670607)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355851683670608)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501440902907477)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501512181907478)
,p_db_column_name=>'MONAT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501628233907479)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501850628907481)
,p_db_column_name=>'ZEITRAUM_VON'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Zeitraum Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16501946820907482)
,p_db_column_name=>'ZEITRAUM_BIS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Zeitraum Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502039689907483)
,p_db_column_name=>'ERSTELLT_AM'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Erstellt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502146919907484)
,p_db_column_name=>'GEZEICHNET_AM'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Gezeichnet Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502307081907486)
,p_db_column_name=>'STUNDENZAHL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502453508907487)
,p_db_column_name=>'GENEHMIGT_AM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Genehmigt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502566518907488)
,p_db_column_name=>'EINGEREICHT_AM_PP_1'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Eingereicht Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16502883345907492)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503016781907493)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503176753907494)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503208614907495)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503303504907496)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16503471559907497)
,p_db_column_name=>'PROJEKT'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663654296795090)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663770242795091)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663875123795092)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663957797795093)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664076725795094)
,p_db_column_name=>'PK_PROJ_STUNDENZETTEL'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Pk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664119902795095)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664268516795096)
,p_db_column_name=>'FK_KON_GEZEICHNET_VON'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kon Gezeichnet Von'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664341351795097)
,p_db_column_name=>'EINGEREICHT_AM_PP_2'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Eingereicht Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664456809795098)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_1'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Bestaetigung Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52664555814795099)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_2'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Bestaetigung Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16514537966918600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179549'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:FK_INP_BELEGE_ALL:CREATION_DATE:BESCHREIBUNG:MONAT:JAHR:ZEITRAUM_VON:ZEITRAUM_BIS:ERSTELLT_AM:GEZEICHNET_AM:STUNDENZAHL:GENEHMIGT_AM:EINGEREICHT_AM_PP_1:KOMMENTAR:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PROJEKT:PK_REL_STEU_STEUER_VERPFL_BE'
||'LEG_SRC:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS:PK_PROJ_STUNDENZETTEL:FK_PROJ_PROJEKT:FK_KON_GEZEICHNET_VON:EINGEREICHT_AM_PP_2:BESTAETIGUNG_AM_PP_1:BESTAETIGUNG_AM_PP_2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25204718034521223)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bel.PK_REL_STEU_STEUER_VERPFL_BELEG_SRC,',
'       bel.FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_PROJ_STUNDENZETTEL,',
'      bel.COMM,',
'       bel.FK_STD_STEU_STATUS,',
'      bel.creation_date,',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P329_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      --kat',
'      kat.Kategorie kategorie,',
'      inp.FK_bas_kat_Kategorie,',
'      kat.FK_bas_kat_Oberkategorie  fk_oberkategorie,',
'      --katpos',
'      katpos.Kategorie pos_kategorie,',
'      katposob.Kategorie posob_Kategorie,',
'      inppos.fk_bas_kat_kategorie pos_fk_bas_kat_kategorie,',
'      katpos.FK_bas_kat_Oberkategorie  pos_fk_oberkategorie,',
unistr('      case when inp.fk_bas_kat_kategorie = 314 or inppos.fk_bas_kat_kategorie = 314 then 1 else 0 end fr\00FCh,'),
'      case when  kat.FK_bas_kat_Oberkategorie = 694 and  katpos.FK_bas_kat_Oberkategorie  = 694 then 1 else 0 end hotel',
'   ',
'from T_REL_STEU_STEUER_VERPFL_BEleG_SRC bel',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_bas_kat_konto_buch katpos on katpos.pk_bas_kat_konto_buch = inppos.fk_bas_kat_kategorie',
'   left join t_bas_kat_konto_buch katposob on katposob.pk_bas_kat_konto_buch = katpos.FK_bas_kat_Oberkategorie',
'   left join t_bas_kat_konto_buch kat on kat.pk_bas_kat_konto_buch = inp.fk_bas_kat_kategorie',
' where FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET = :P329_PK_STEU_STEUER_Verpfl_mehraufwd_det'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(25205013897521223)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>26645333172912763
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11903827023155536)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11904224137155536)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11904676464155536)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054137698567904)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054184886567905)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12054365981567906)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>67
,p_column_identifier=>'M'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081770189103385)
,p_db_column_name=>'INP_BEL'
,p_display_order=>77
,p_column_identifier=>'N'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081860256103386)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>87
,p_column_identifier=>'O'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13081890174103387)
,p_db_column_name=>'POS_KATEGORIE'
,p_display_order=>97
,p_column_identifier=>'P'
,p_column_label=>'Pos Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082122011103389)
,p_db_column_name=>'POSOB_KATEGORIE'
,p_display_order=>117
,p_column_identifier=>'R'
,p_column_label=>'Posob Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082217393103390)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>127
,p_column_identifier=>'S'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082364482103391)
,p_db_column_name=>'POS_FK_OBERKATEGORIE'
,p_display_order=>137
,p_column_identifier=>'T'
,p_column_label=>'Pos Fk Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082522190103393)
,p_db_column_name=>'FK_OBERKATEGORIE'
,p_display_order=>157
,p_column_identifier=>'V'
,p_column_label=>'Fk Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082770473103395)
,p_db_column_name=>unistr('FR\00DCH')
,p_display_order=>177
,p_column_identifier=>'X'
,p_column_label=>unistr('Fr\00FCh')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13082862423103396)
,p_db_column_name=>'HOTEL'
,p_display_order=>187
,p_column_identifier=>'Y'
,p_column_label=>'Hotel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663027492795084)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>197
,p_column_identifier=>'Z'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663174950795085)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>207
,p_column_identifier=>'AA'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663203280795086)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>217
,p_column_identifier=>'AB'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663314240795087)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>227
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663433978795088)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>237
,p_column_identifier=>'AD'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52663505388795089)
,p_db_column_name=>'POS_FK_BAS_KAT_KATEGORIE'
,p_display_order=>247
,p_column_identifier=>'AE'
,p_column_label=>'Pos Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12120631627147322)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135610'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('COMM:FK_INP_BELEGE_ALL:CREATION_DATE:PK_INP_BELEGE_ALL:BEL_DATUM:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:POSOB_KATEGORIE:KATEGORIE:POS_KATEGORIE:FK_OBERKATEGORIE:POS_FK_OBERKATEGORIE::FR\00DCH:HOTEL:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_M')
||'EHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS:FK_BAS_KAT_KATEGORIE:POS_FK_BAS_KAT_KATEGORIE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117542464787992)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>'Hotel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HOTEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("HOTEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117903146787994)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>'Beleg'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'INP_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("INP_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#8D9DA1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13117151910787992)
,p_report_id=>wwv_flow_api.id(12120631627147322)
,p_name=>unistr('fr\00FCh')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('FR\00DCH')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("FR\00DCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25755284813827941)
,p_plug_name=>'Verpflegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(12168562252523035)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12054503340567908)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(12054407909567907)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:330:P340_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16259113924776369)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16258983653776368)
,p_button_name=>'CREATE_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_AREITSTAG,P330_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_FK_DATUM_VERPFMWED.,&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16355328762670603)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16355256698670602)
,p_button_name=>'CREATE_3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_AREITSTAG,P330_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_FK_DATUM_VERPFMWED.,&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12145869949878901)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>unistr('\00DCbersicht')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>unistr('\00DCbersicht')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:339:&SESSION.::&DEBUG.:RP:P339_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12401052914668930)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(25755284813827941)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11884690086075024)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11883519949075019)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:328:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11885133727075024)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11884367889075024)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11869911510074988)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11905025022155539)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(25204718034521223)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:330:P330_FK_AREITSTAG,P330_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P329_FK_DATUM_VERPFMWED.,&P329_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(11885446191075024)
,p_branch_name=>'Go To Page 328'
,p_branch_action=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.::P327_PK_VERPFLEGUNGSMEHRAUFWAND:&P329_FK_VERPFLEGUNGSMEHRAUFWAND.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11871817921075002)
,p_name=>'P329_DESCR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Descr'
,p_source=>'DESCR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11872203301075002)
,p_name=>'P329_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12516184842141588)
,p_name=>'P329_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12517065524141588)
,p_name=>'P329_FK_BAS_KAL_ARBEITSTAG'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag || '' '' || monat || '' '' || jahr arb_tag, pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604002864709593)
,p_name=>'P329_HINT_VP_VOLL'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 24 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604175789709594)
,p_name=>'P329_HINT_VP_TEIL'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 24 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604255905709595)
,p_name=>unistr('P329_HINT_VP_K\00DCRZ')
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 24 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12604312059709596)
,p_name=>unistr('P329_HINT_VP_\00DCBERNACHTUNG')
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_default=>unistr('mehr als 24 Stunden ausw\00E4rts')
,p_prompt=>'Hint Vp Voll'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13081612304103384)
,p_name=>'P329_FK_INP_BELEGE_ALL'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Inp Belege All'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52660897813795063)
,p_name=>'P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Pk Steu Steuer Verpfl Mehraufwd Det'
,p_source=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661067557795064)
,p_name=>'P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Steu Steuer Verpfl Mehraufwd'
,p_source=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661111944795065)
,p_name=>'P329_DATUM_VERPFL_MEHRAUFWD'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Datum Verpfl Mehraufwd'
,p_source=>'DATUM_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661267413795066)
,p_name=>'P329_FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Bas Kal Datum Verpfl Mehraufwd'
,p_source=>'FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661327136795067)
,p_name=>'P329_FK_ADR_ORT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Adr Ort'
,p_source=>'FK_ADR_ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661424350795068)
,p_name=>'P329_FK_STD_VERPFL_FRUEHSTUECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Fruehstueck'
,p_source=>'FK_STD_VERPFL_FRUEHSTUECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661573582795069)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Verpflegungspauschale Voll'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661661422795070)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Verpflegungspauschale Teil'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661761487795071)
,p_name=>'P329_FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Verpflegunspauschale Kuerz'
,p_source=>'FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661806362795072)
,p_name=>'P329_FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Verpfl Uebernachtungspauschale'
,p_source=>'FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52661887745795073)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Status Vp Voll'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662026741795074)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Status Vp Teil'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662135705795075)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Status Vp Kuerz'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662230189795076)
,p_name=>'P329_FK_STD_STEU_VERPFL_STATUS_UEP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Status Uep'
,p_source=>'FK_STD_STEU_VERPFL_STATUS_UEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(52662306581795077)
,p_name=>'P329_FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(11869911510074988)
,p_item_source_plug_id=>wwv_flow_api.id(11869911510074988)
,p_prompt=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_source=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11886358939075027)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(11869911510074988)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Verpflegungsmehraufwand_Detail'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11885969391075027)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11869911510074988)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Verpflegungsmehraufwand_Detail'
);
wwv_flow_api.component_end;
end;
/
