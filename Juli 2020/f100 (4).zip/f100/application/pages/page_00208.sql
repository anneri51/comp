prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>208
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Elektronik_Bild'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Elektronik_Bild'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42870062622330169)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622140922'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(55639615214232335)
,p_plug_name=>'Elektronik_Bild'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INV_SUB_Elektronik,',
'       length(BILD) bild',
'from t_INV_SUB_Elektronik',
'where PK_INV_SUB_elektronik =:P208_PK_INV_SUB_elektronik'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(55639627050232335)
,p_name=>'Kontoauszug_Bild'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>64949762290653256
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7362897382690547)
,p_db_column_name=>'BILD'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:IMP_BA_ELEKTRONIK:BILD:PK_IMP_BA_ELEKTRONIK::::::inline::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50563845554164001)
,p_db_column_name=>'PK_INV_SUB_ELEKTRONIK'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Pk Inv Sub Elektronik'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(55643958253301021)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'166734'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>':PK_IMP_BA_SOFTWARE1:BILD:PK_INV_SUB_ELEKTRONIK'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7363705738690549)
,p_name=>'P208_PK_INV_SUB_ELEKTRONIK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(55639615214232335)
,p_prompt=>'Pk imp ba elektronik'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
