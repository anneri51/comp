prompt --application/pages/page_00312
begin
--   Manifest
--     PAGE: 00312
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>312
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'lex_susa'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'lex_susa'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200718141445'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9783270969980656)
,p_plug_name=>'lex_susa'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select susa.*, sum_soll, sum_haben, summe_wj_soll - sum_soll diff_soll, summe_wj_haben - sum_haben diff_haben, kto.cnt',
'from t_lex_susa susa',
' left join (select kontonummer, sum(sollbetrag_eur) sum_soll,  sum(habenbetrag_eur) sum_haben, jahr, count(*) cnt from t_lex_kontenblatt group by kontonummer, jahr) kto on kto.kontonummer = susa.konto and kto.jahr = susa.jahr',
'   left join t_steu_steuer_monat stm on susa.fk_steu_steuer_monat = stm.pk_steu_steuer_monat',
'  left join t_steu_steuer_voranmldg stva on stva.pk_steu_steuer_voranmldg = susa.fk_steu_steuer_voranmeldg',
'  left join t_imp_log_load logl on logl.pk_imp_log_load = susa.fk_imp_log_load'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9783296496980656)
,p_name=>'lex_susa'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11223615772372196
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9783756686980664)
,p_db_column_name=>'KONTO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9784116097980670)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9784480960980672)
,p_db_column_name=>'LETZTE_BUCHUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Letzte Buchung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9784949740980672)
,p_db_column_name=>'EB_WERT_SOLL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Eb Wert Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9785346331980672)
,p_db_column_name=>'EB_WERT_HABEN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Eb Wert Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9785753286980672)
,p_db_column_name=>'SUMME_WJ_SOLL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Summe Wj Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9786133868980672)
,p_db_column_name=>'SUMME_WJ_HABEN'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Summe Wj Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9786571257980674)
,p_db_column_name=>'SUMME_PER_WJ_SOLL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Summe Per Wj Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9786923714980674)
,p_db_column_name=>'SUMME_PER_WJ_HABEN'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Summe Per Wj Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9787307763980674)
,p_db_column_name=>'SALDO_PER_WJ_SOLL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Saldo Per Wj Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9787743184980674)
,p_db_column_name=>'SALDO_PER_WJ_HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Saldo Per Wj Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9788090600980674)
,p_db_column_name=>'ID'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9788487544980675)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9788923791980675)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9789350873980675)
,p_db_column_name=>'OK'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9789698063980675)
,p_db_column_name=>'JAHR'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9688733100820278)
,p_db_column_name=>'SUM_SOLL'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>'Sum Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9688860031820279)
,p_db_column_name=>'SUM_HABEN'
,p_display_order=>36
,p_column_identifier=>'R'
,p_column_label=>'Sum Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9688913981820280)
,p_db_column_name=>'DIFF_SOLL'
,p_display_order=>46
,p_column_identifier=>'S'
,p_column_label=>'Diff Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9689015188820281)
,p_db_column_name=>'DIFF_HABEN'
,p_display_order=>56
,p_column_identifier=>'T'
,p_column_label=>'Diff Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36311887207367103)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>86
,p_column_identifier=>'W'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36312036129367104)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>96
,p_column_identifier=>'X'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36312587040367110)
,p_db_column_name=>'FK_IMP_LOG_LOAD'
,p_display_order=>156
,p_column_identifier=>'AD'
,p_column_label=>'Fk Imp Log Load'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36608514817519061)
,p_db_column_name=>'CALC_DIFF_BETRAG'
,p_display_order=>166
,p_column_identifier=>'AE'
,p_column_label=>'Calc Diff Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36608653837519062)
,p_db_column_name=>'BUCH_BETRAG_VORPERIODE'
,p_display_order=>176
,p_column_identifier=>'AF'
,p_column_label=>'Buch Betrag Vorperiode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36608772676519063)
,p_db_column_name=>'BUCH_BETRAG_AKT_PERIODE'
,p_display_order=>186
,p_column_identifier=>'AG'
,p_column_label=>'Buch Betrag Akt Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36608802690519064)
,p_db_column_name=>'CALC_BUCH_BETRAG_DIFF'
,p_display_order=>196
,p_column_identifier=>'AH'
,p_column_label=>'Calc Buch Betrag Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36608885989519065)
,p_db_column_name=>'DATUM_BUCH_BETRAG_OK'
,p_display_order=>206
,p_column_identifier=>'AI'
,p_column_label=>'Datum Buch Betrag Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36609058288519066)
,p_db_column_name=>'EB_WERT_RELEVANT'
,p_display_order=>216
,p_column_identifier=>'AJ'
,p_column_label=>'Eb Wert Relevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36609082393519067)
,p_db_column_name=>'CNT'
,p_display_order=>226
,p_column_identifier=>'AK'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(308807667487585)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>236
,p_column_identifier=>'AL'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1897643172371766)
,p_db_column_name=>'FK_STEU_STEUER_VORANMELDG'
,p_display_order=>246
,p_column_identifier=>'AM'
,p_column_label=>'Fk Steu Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1897780034371767)
,p_db_column_name=>'FK_LEX_ABSCHLUSS_VORANMELDG'
,p_display_order=>256
,p_column_identifier=>'AN'
,p_column_label=>'Fk Lex Abschluss Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1897804468371768)
,p_db_column_name=>'FK_STEU_JAHRES_ABSCHLUSSS'
,p_display_order=>266
,p_column_identifier=>'AO'
,p_column_label=>'Fk Steu Jahres Abschlusss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1897934039371769)
,p_db_column_name=>'FK_LEX_BUCH_CNT'
,p_display_order=>276
,p_column_identifier=>'AP'
,p_column_label=>'Fk Lex Buch Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1898023199371770)
,p_db_column_name=>'KAS_KASSE_MONAT_CNT'
,p_display_order=>286
,p_column_identifier=>'AQ'
,p_column_label=>'Kas Kasse Monat Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1898142874371771)
,p_db_column_name=>'KAS_KASSE_JAHR_CNT'
,p_display_order=>296
,p_column_identifier=>'AR'
,p_column_label=>'Kas Kasse Jahr Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9801591986054350)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112420'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('KONTO:NAME:LETZTE_BUCHUNG:EB_WERT_SOLL:EB_WERT_HABEN:SUMME_WJ_SOLL:SUMME_WJ_HABEN:SUMME_PER_WJ_SOLL:SUMME_PER_WJ_HABEN:SALDO_PER_WJ_SOLL:SALDO_PER_WJ_HABEN:ID:LOAD_DATE:DATUM_OK:OK:JAHR:SUM_SOLL:SUM_HABEN:DIFF_SOLL:DIFF_HABEN:DATUM_STEUERB_\00DCBERG:DATU')
||unistr('M_FINANZAMT_\00DCBERG:FK_IMP_LOG_LOAD:CALC_DIFF_BETRAG:BUCH_BETRAG_VORPERIODE:BUCH_BETRAG_AKT_PERIODE:CALC_BUCH_BETRAG_DIFF:DATUM_BUCH_BETRAG_OK:EB_WERT_RELEVANT:CNT::FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMELDG:FK_LEX_ABSCHLUSS_VORANMELDG:FK_STEU_JAHR')
||'ES_ABSCHLUSSS:FK_LEX_BUCH_CNT:KAS_KASSE_MONAT_CNT:KAS_KASSE_JAHR_CNT'
,p_break_on=>'KONTO'
,p_break_enabled_on=>'KONTO'
,p_sum_columns_on_break=>'FK_BUCH_CNT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36624963330631799)
,p_report_id=>wwv_flow_api.id(9801591986054350)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_IMP_LOG_LOAD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_IMP_LOG_LOAD" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36625355482631799)
,p_report_id=>wwv_flow_api.id(9801591986054350)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_IMP_LOG_LOAD'
,p_operator=>'in'
,p_expr=>'122,121'
,p_condition_sql=>'"FK_IMP_LOG_LOAD" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 122, 121  '
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
