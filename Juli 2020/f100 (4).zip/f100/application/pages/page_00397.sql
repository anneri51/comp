prompt --application/pages/page_00397
begin
--   Manifest
--     PAGE: 00397
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>397
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>unistr('\00FCbersicht_datum_kontenblatt')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('\00FCbersicht_datum_kontenblatt')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091621'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39103145669019241)
,p_plug_name=>unistr('\00FCbersicht_datum_kontenblatt')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*), substr(belegdatum, 7,4) beldat, ktbl.jahr ktbl_jahr, arb.jahr arb_jahr ',
'from imp_kontenblatt_2018 ktbl',
' left join t_arbeitstage arb on ktbl.fk_belegdatum = arb.pk_arbeitstage',
' group by substr(belegdatum, 7,4), ktbl.jahr , arb.jahr'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39103198059019241)
,p_name=>unistr('\00FCbersicht_datum_kontenblatt')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40543517334410781
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39103595619019249)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39104023418019250)
,p_db_column_name=>'BELDAT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Beldat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39104402976019250)
,p_db_column_name=>'KTBL_JAHR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Ktbl Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39104800420019250)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39105549626036013)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'405459'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COUNT(*):BELDAT:KTBL_JAHR:ARB_JAHR'
,p_sum_columns_on_break=>'COUNT(*)'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(39106908100045003)
,p_report_id=>wwv_flow_api.id(39105549626036013)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'is null'
,p_condition_sql=>'"ARB_JAHR" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
