prompt --application/pages/page_00184
begin
--   Manifest
--     PAGE: 00184
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>184
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Allgemeine Belege'
,p_step_title=>'Allgemeine Belege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200621120218'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5909198441930199)
,p_plug_name=>'Allgemeine Belege'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BEZEICHNUNG,',
'       LAND,',
'       S1,',
'       S2,',
'       BETRAG,',
'       WaeHRUNG,',
'       S4,',
'       STEUERSATZ,',
'       S6,',
'       STEUERNUMMER,',
'       DATUM,',
'       UHRZEIT,',
'       BELEGNUMMER,',
'       ZAHLUNGSART,',
'       BELEG,',
'       VERWENDUNGSZWECK,',
'       SONSTIGES2,',
'       S7,',
'       S8,',
'       S9,',
'       S10,',
'       FK_bas_kal_ARBEITSTAG,',
'       FK_kto_BUCHUNG,',
'       PK_IMP_BA_ALLG_BEL,',
'       FK_IMP_BA_BEL,',
'       MERK,',
'       WERT,',
'       FK_IMP_BA_ALLG_BEL1,',
'       ORT,',
'       SONSTIGES3,',
'       SONSTIGES4,',
'       SONSTIGES5,',
'       SONSTIGES6,',
'       UMRECHNUNGSKURS,',
'       MWST,',
'       DOK,',
'       length(bild) Bild',
'  from IMP_BA_ALLG_BEL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5909301095930199)
,p_name=>'Allgemeine Belege'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.:RP:P118_PK_IMP_BA_ALLG_BEL:#PK_IMP_BA_ALLG_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15219436336351120
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5909685965930252)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5909987044930265)
,p_db_column_name=>'LAND'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5910425985930268)
,p_db_column_name=>'S1'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'S1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5910794191930269)
,p_db_column_name=>'S2'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'S2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5911233247930270)
,p_db_column_name=>'BETRAG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5912036960930272)
,p_db_column_name=>'S4'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'S4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5912435114930273)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5912831461930274)
,p_db_column_name=>'S6'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'S6'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5913179740930275)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5913594421930276)
,p_db_column_name=>'DATUM'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5914029559930278)
,p_db_column_name=>'UHRZEIT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Uhrzeit'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5914391456930279)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5914785600930280)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5915253238930281)
,p_db_column_name=>'BELEG'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5915641111930282)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5916013398930283)
,p_db_column_name=>'SONSTIGES2'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sonstiges2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5916377639930283)
,p_db_column_name=>'S7'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'S7'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5916836764930285)
,p_db_column_name=>'S8'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'S8'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5917211333930285)
,p_db_column_name=>'S9'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'S9'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5917604470930286)
,p_db_column_name=>'S10'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'S10'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5918860773930290)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5919195336930291)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5919608262930292)
,p_db_column_name=>'MERK'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Merk'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5920049968930293)
,p_db_column_name=>'WERT'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5920375480930294)
,p_db_column_name=>'FK_IMP_BA_ALLG_BEL1'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Imp Ba Allg Bel1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5920842170930295)
,p_db_column_name=>'ORT'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5921174724930296)
,p_db_column_name=>'SONSTIGES3'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Sonstiges3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5921574915930297)
,p_db_column_name=>'SONSTIGES4'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Sonstiges4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5921982989930298)
,p_db_column_name=>'SONSTIGES5'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Sonstiges5'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5922406277930299)
,p_db_column_name=>'SONSTIGES6'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Sonstiges6'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5922780955930300)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5923181084930300)
,p_db_column_name=>'MWST'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5923612612930301)
,p_db_column_name=>'DOK'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Dok'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6069559585111919)
,p_db_column_name=>'BILD'
,p_display_order=>46
,p_column_identifier=>'AK'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:IMP_BA_ALLG_BEL:BILD:PK_IMP_BA_ALLG_BEL::::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109418077262176)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>56
,p_column_identifier=>'AL'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109523724262177)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>66
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109598688262178)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>76
,p_column_identifier=>'AN'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5924210075936682)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'152344'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BEZEICHNUNG:LAND:S1:S2:BETRAG:S4:STEUERSATZ:S6:STEUERNUMMER:DATUM:UHRZEIT:BELEGNUMMER:ZAHLUNGSART:BELEG:VERWENDUNGSZWECK:SONSTIGES2:S7:S8:S9:S10:PK_IMP_BA_ALLG_BEL:FK_IMP_BA_BEL:MERK:WERT:FK_IMP_BA_ALLG_BEL1:ORT:SONSTIGES3:SONSTIGES4:SONSTIGES5:SONST'
||'IGES6:UMRECHNUNGSKURS:MWST:DOK:BILD:WAEHRUNG:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6069700341111921)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_region_image=>'#APP_IMAGES#meer.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6069806485111922)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_region_image=>'#APP_IMAGES#stadt.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
