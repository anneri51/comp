prompt --application/pages/page_00068
begin
--   Manifest
--     PAGE: 00068
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>68
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Umsatzsteuervoranmeldung'
,p_step_title=>'Umsatzsteuervoranmeldung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42881936682393325)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200614075435'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1152523016238036)
,p_plug_name=>'Umsatzsteuervoranmeldung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_BEL_BELEG,',
'       FK_BAS_STEU_STEUER_SATZ,',
'       FK_bas_BEL_BELEGART,',
'       FK_BAS_STD_VERWENDUNGSZWECK,',
'       FK_BAS_KAL_ARBEITSTAG,',
'       FK_PROJ_PROJEKT,',
'       FK_LEHR_LEHRGANG,',
'       FK_WH_WAREN_BEWEGUNG,',
'       BELEG,',
'       BETRAG_BRUTTO,',
'       DATUM,',
'       VON,',
'       BIS,',
'       AZ_O_PAUSE,',
'       AZ_M_PAUSE,',
'       ANWESENHEITSZEIT,',
'       PARKZEIT,',
'       AZ_MANUELL_GEPFLEGT,',
'       KOMMENTAR,',
'       BETRAG_NETTO,',
'       FK_IMP_BEL_NR,',
'       FK_IMP_NO,',
'       EXT_RENR,',
'       EXT_AUFTRAGSNR,',
'       EXT_LIEFERSCHEINNR,',
'       EXT_LEISTUNGSDATUM,',
'       EXT_RECHNUNGSDATUM,',
'       EXT_AUFTRAGSDATUM,',
'       FK_STD_re_OFFEN,',
'       FK_std_STEU_VORSTEUERRELEVANT,',
'       FK_std_STEU_VORSTEUERPFLEGE,',
'       FK_std_RE_RECHNUNGSERSTELLUNG,',
'       FK_std_RE_RECHNUNG_ERSTELLT,',
'       FK_std_kto_BANKBELEG,',
'       CREATED_BY,',
'       CREATED_AT,',
'       MODIFIED_BY,',
'       MODIFIED_AT,',
'       MWST,',
'       FK_std_KON_LIEFERART,',
'       FK_STD_STEU_EINKOMMENSTEUERRELEVANT,',
'       FK_STD_STEU_UNTERNEHMENSSTEUERRELEVANT,',
'       FK_WH_Waren_BESTELLNR,',
'       FK_std_WH_BESTELLTYP,',
'       FK_bas_kal_ABRECHNUNGSZEITRAUM,',
'       FK_BAS_MON_FREMDWAEHRUNG,',
'       FRMDW_BETRAG_NETTO,',
'       FRMDW_STSATZ,',
'       FRMDW_MWST,',
'       FRMDW_BETRAG_BRUTTO,',
'       BUCHUNGSTAG,',
'       FK_kto_bankKONTO,',
'       KUMULIERTER_BETRAG_NEG,',
'       KUMULIERTER_BETRAG,',
'       ENDBETRAG,',
'       STARTBETRAG,',
'       BETRAG_NEG,',
'       FK_bas_mon_BELEGWAEHRUNG,',
'       FK_std_mon_UMSATZART,',
'       EINZELBETRAG_NEG,',
'       FK_MAIN_BELEG',
'  from T_BEL_BELEG',
'Where fk_bas_bel_belegart =61'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1152643945238036)
,p_name=>'Umsatzsteuervoranmeldung'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP:P23_PK_BEL_BELEG:#PK_BEL_BELEG##PK_BELEG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>10462779185658957
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1156499850238048)
,p_db_column_name=>'BELEG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1156931791238048)
,p_db_column_name=>'BETRAG_BRUTTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Betrag Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1157337030238050)
,p_db_column_name=>'DATUM'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1157703054238050)
,p_db_column_name=>'VON'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1158124208238050)
,p_db_column_name=>'BIS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1158543663238050)
,p_db_column_name=>'AZ_O_PAUSE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Az O Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1158911670238051)
,p_db_column_name=>'AZ_M_PAUSE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Az M Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1159357077238051)
,p_db_column_name=>'ANWESENHEITSZEIT'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Anwesenheitszeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1160061131238051)
,p_db_column_name=>'PARKZEIT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Parkzeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1160396948238052)
,p_db_column_name=>'AZ_MANUELL_GEPFLEGT'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Az Manuell Gepflegt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1160813768238052)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1161191725238052)
,p_db_column_name=>'BETRAG_NETTO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Betrag Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1161640963238053)
,p_db_column_name=>'FK_IMP_BEL_NR'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Fk Imp Bel Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1162002502238053)
,p_db_column_name=>'FK_IMP_NO'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Imp No'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1162422440238053)
,p_db_column_name=>'EXT_RENR'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ext Renr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1162827336238054)
,p_db_column_name=>'EXT_AUFTRAGSNR'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ext Auftragsnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1163560122238054)
,p_db_column_name=>'EXT_LIEFERSCHEINNR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ext Lieferscheinnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1163898906238054)
,p_db_column_name=>'EXT_LEISTUNGSDATUM'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ext Leistungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1164299283238054)
,p_db_column_name=>'EXT_RECHNUNGSDATUM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ext Rechnungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1164736230238055)
,p_db_column_name=>'EXT_AUFTRAGSDATUM'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ext Auftragsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1167806819238056)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1168221487238057)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1168911268238057)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1169292395238057)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1169704071238058)
,p_db_column_name=>'MWST'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1172875107238060)
,p_db_column_name=>'FRMDW_BETRAG_NETTO'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Betrag Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1173281365238060)
,p_db_column_name=>'FRMDW_STSATZ'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Frmdw Stsatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1173685788238060)
,p_db_column_name=>'FRMDW_MWST'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Frmdw Mwst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1174124037238060)
,p_db_column_name=>'FRMDW_BETRAG_BRUTTO'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Frmdw Betrag Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1174813828238061)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1175603641238061)
,p_db_column_name=>'KUMULIERTER_BETRAG_NEG'
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>'Kumulierter Betrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1175990697238061)
,p_db_column_name=>'KUMULIERTER_BETRAG'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Kumulierter Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1176415509238061)
,p_db_column_name=>'ENDBETRAG'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Endbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1176814211238062)
,p_db_column_name=>'STARTBETRAG'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Startbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1177231105238062)
,p_db_column_name=>'BETRAG_NEG'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Betrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1178752059238063)
,p_db_column_name=>'EINZELBETRAG_NEG'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Einzelbetrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1179070618238063)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Fk Main Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721517042098182)
,p_db_column_name=>'PK_BEL_BELEG'
,p_display_order=>71
,p_column_identifier=>'BJ'
,p_column_label=>'Pk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721606267098183)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>81
,p_column_identifier=>'BK'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721731059098184)
,p_db_column_name=>'FK_BAS_BEL_BELEGART'
,p_display_order=>91
,p_column_identifier=>'BL'
,p_column_label=>'Fk Bas Bel Belegart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721825329098185)
,p_db_column_name=>'FK_BAS_STD_VERWENDUNGSZWECK'
,p_display_order=>101
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bas Std Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721939213098186)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>111
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722015257098187)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>121
,p_column_identifier=>'BO'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722128026098188)
,p_db_column_name=>'FK_LEHR_LEHRGANG'
,p_display_order=>131
,p_column_identifier=>'BP'
,p_column_label=>'Fk Lehr Lehrgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722230356098189)
,p_db_column_name=>'FK_WH_WAREN_BEWEGUNG'
,p_display_order=>141
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Wh Waren Bewegung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722291480098190)
,p_db_column_name=>'FK_STD_RE_OFFEN'
,p_display_order=>151
,p_column_identifier=>'BR'
,p_column_label=>'Fk Std Re Offen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722467032098191)
,p_db_column_name=>'FK_STD_STEU_VORSTEUERRELEVANT'
,p_display_order=>161
,p_column_identifier=>'BS'
,p_column_label=>'Fk Std Steu Vorsteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722506306098192)
,p_db_column_name=>'FK_STD_STEU_VORSTEUERPFLEGE'
,p_display_order=>171
,p_column_identifier=>'BT'
,p_column_label=>'Fk Std Steu Vorsteuerpflege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722613066098193)
,p_db_column_name=>'FK_STD_RE_RECHNUNGSERSTELLUNG'
,p_display_order=>181
,p_column_identifier=>'BU'
,p_column_label=>'Fk Std Re Rechnungserstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722764872098194)
,p_db_column_name=>'FK_STD_RE_RECHNUNG_ERSTELLT'
,p_display_order=>191
,p_column_identifier=>'BV'
,p_column_label=>'Fk Std Re Rechnung Erstellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722878258098195)
,p_db_column_name=>'FK_STD_KTO_BANKBELEG'
,p_display_order=>201
,p_column_identifier=>'BW'
,p_column_label=>'Fk Std Kto Bankbeleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47722914323098196)
,p_db_column_name=>'FK_STD_KON_LIEFERART'
,p_display_order=>211
,p_column_identifier=>'BX'
,p_column_label=>'Fk Std Kon Lieferart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723049791098197)
,p_db_column_name=>'FK_STD_STEU_EINKOMMENSTEUERRELEVANT'
,p_display_order=>221
,p_column_identifier=>'BY'
,p_column_label=>'Fk Std Steu Einkommensteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723141804098198)
,p_db_column_name=>'FK_STD_STEU_UNTERNEHMENSSTEUERRELEVANT'
,p_display_order=>231
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Std Steu Unternehmenssteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723197234098199)
,p_db_column_name=>'FK_WH_WAREN_BESTELLNR'
,p_display_order=>241
,p_column_identifier=>'CA'
,p_column_label=>'Fk Wh Waren Bestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723374975098200)
,p_db_column_name=>'FK_STD_WH_BESTELLTYP'
,p_display_order=>251
,p_column_identifier=>'CB'
,p_column_label=>'Fk Std Wh Bestelltyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723475578098201)
,p_db_column_name=>'FK_BAS_KAL_ABRECHNUNGSZEITRAUM'
,p_display_order=>261
,p_column_identifier=>'CC'
,p_column_label=>'Fk Bas Kal Abrechnungszeitraum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723557515098202)
,p_db_column_name=>'FK_BAS_MON_FREMDWAEHRUNG'
,p_display_order=>271
,p_column_identifier=>'CD'
,p_column_label=>'Fk Bas Mon Fremdwaehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723621041098203)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>281
,p_column_identifier=>'CE'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723706129098204)
,p_db_column_name=>'FK_BAS_MON_BELEGWAEHRUNG'
,p_display_order=>291
,p_column_identifier=>'CF'
,p_column_label=>'Fk Bas Mon Belegwaehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47723857531098205)
,p_db_column_name=>'FK_STD_MON_UMSATZART'
,p_display_order=>301
,p_column_identifier=>'CG'
,p_column_label=>'Fk Std Mon Umsatzart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1181464685261667)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104916'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEG:BETRAG_BRUTTO:DATUM:VON:BIS:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:PARKZEIT:AZ_MANUELL_GEPFLEGT:KOMMENTAR:BETRAG_NETTO:FK_IMP_BEL_NR:FK_IMP_NO:EXT_RENR:EXT_AUFTRAGSNR:EXT_LIEFERSCHEINNR:EXT_LEISTUNGSDATUM:EXT_RECHNUNGSDATUM:EXT_AUFTRAGSDATUM:CR'
||'EATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:MWST:FRMDW_BETRAG_NETTO:FRMDW_STSATZ:FRMDW_MWST:FRMDW_BETRAG_BRUTTO:BUCHUNGSTAG:KUMULIERTER_BETRAG_NEG:KUMULIERTER_BETRAG:ENDBETRAG:STARTBETRAG:BETRAG_NEG:EINZELBETRAG_NEG:FK_MAIN_BELEG:PK_BEL_BELEG:FK_BAS_'
||'STEU_STEUER_SATZ:FK_BAS_BEL_BELEGART:FK_BAS_STD_VERWENDUNGSZWECK:FK_BAS_KAL_ARBEITSTAG:FK_PROJ_PROJEKT:FK_LEHR_LEHRGANG:FK_WH_WAREN_BEWEGUNG:FK_STD_RE_OFFEN:FK_STD_STEU_VORSTEUERRELEVANT:FK_STD_STEU_VORSTEUERPFLEGE:FK_STD_RE_RECHNUNGSERSTELLUNG:FK_ST'
||'D_RE_RECHNUNG_ERSTELLT:FK_STD_KTO_BANKBELEG:FK_STD_KON_LIEFERART:FK_STD_STEU_EINKOMMENSTEUERRELEVANT:FK_STD_STEU_UNTERNEHMENSSTEUERRELEVANT:FK_WH_WAREN_BESTELLNR:FK_STD_WH_BESTELLTYP:FK_BAS_KAL_ABRECHNUNGSZEITRAUM:FK_BAS_MON_FREMDWAEHRUNG:FK_KTO_BANK'
||'KONTO:FK_BAS_MON_BELEGWAEHRUNG:FK_STD_MON_UMSATZART'
,p_sort_column_1=>'DATUM'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PK_BELEG'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1203903404547882)
,p_report_id=>wwv_flow_api.id(1181464685261667)
,p_name=>'abgerechnet'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OFFEN'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("FK_OFFEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B2FFC0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1204274303547883)
,p_report_id=>wwv_flow_api.id(1181464685261667)
,p_name=>'Vorbereitung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OFFEN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_OFFEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E683B9'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1203559843547882)
,p_report_id=>wwv_flow_api.id(1181464685261667)
,p_name=>'nicht steuerrelevant'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_BELEG'
,p_operator=>'='
,p_expr=>'4976'
,p_condition_sql=>' (case when ("PK_BELEG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#E6DDE6'
);
wwv_flow_api.component_end;
end;
/
