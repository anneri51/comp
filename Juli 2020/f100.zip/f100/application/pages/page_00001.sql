prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Home'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44301322069624425)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619145904'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7708501676527629)
,p_plug_name=>'Breadcrumbs'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7677428860527541)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(7707970616527623)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7696346451527574)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8050867143464521)
,p_plug_name=>'Schnellzugriff'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_api.id(8048992676452464)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7690615272527558)
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(42528624472619943)
,p_plug_name=>'Inventare'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inv.*, datum_next, case when substr(datum_next, 7,4) = substr(sysdate, 7,4) then 1 else 0 end this_year,    case when arb1.pk_bas_kal_arbeitstage is not null then 1 else 0 end sel_date  ',
'from t_inv_inventare inv  ',
' left join t_kal_termine ter on ter.fk_inv_inventar = inv.pk_inv_inventar',
' left join t_bas_kal_arbeitstage arb on arb.datum = substr(ter.datum_next, 1, 10)',
' left join   (select * from t_bas_kal_arbeitstage where datum = :P1_sel_date)  arb1 on (arb.monat = arb1.monat or arb.monat = arb1.monat+1) and arb.jahr = arb1.jahr',
'where datum_next >= sysdate'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(42528755374619944)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>42528755374619944
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236180310613027)
,p_db_column_name=>'INVENTAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236251131613028)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236332069613029)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236445342613030)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236526767613031)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236623208613032)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236718005613033)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236838729613034)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43236950282613035)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237005481613036)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Preis Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237197751613037)
,p_db_column_name=>'MWST'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237348670613039)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Preis Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237499680613040)
,p_db_column_name=>'COMM'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237564204613041)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237661434613042)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237877743613044)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Kfz Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43237913168613045)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238065022613046)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238107169613047)
,p_db_column_name=>'BILD'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Bild'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238240320613048)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238357727613049)
,p_db_column_name=>'ABGANGSDATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238447723613050)
,p_db_column_name=>'ABGANGSWERT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Abgangswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238644809616302)
,p_db_column_name=>'GWG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Gwg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238753798616303)
,p_db_column_name=>'RESTBUCHWERT_2017'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Restbuchwert 2017'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238800430616304)
,p_db_column_name=>'ABGANGSGRUND'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Abgangsgrund'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43238977241616305)
,p_db_column_name=>'MAC_ADRESSE'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Mac Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239041701616306)
,p_db_column_name=>'SERIENNUMMER'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Seriennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239292390616308)
,p_db_column_name=>'OK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239311137616309)
,p_db_column_name=>'OK_BEMERKUNGEN'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ok Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239416070616310)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239540653616311)
,p_db_column_name=>'INV_BILD'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Inv Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43239648355616312)
,p_db_column_name=>'ANSCHAFFUNGSWERT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Anschaffungswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242842704616344)
,p_db_column_name=>'DATUM_NEXT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Datum Next'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242945458616345)
,p_db_column_name=>'THIS_YEAR'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'This Year'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43243078315616346)
,p_db_column_name=>'SEL_DATE'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sel Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45850379341563511)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122583396988326)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>430
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122797352988328)
,p_db_column_name=>'GERAETENAME'
,p_display_order=>450
,p_column_identifier=>'AV'
,p_column_label=>'Geraetename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47779050988146746)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>470
,p_column_identifier=>'AX'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47779113231146747)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>480
,p_column_identifier=>'AY'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250564389933722)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>490
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(43256027985619270)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'432561'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_NEXT:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:RESTBUCHWERT_2018:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PREIS_NETTO:MWST:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHRGESTELLNR:BEMERKUNGEN:BILD:'
||'ABGANGSJAHR:ABGANGSDATUM:ABGANGSWERT:GWG:RESTBUCHWERT_2017:ABGANGSGRUND:MAC_ADRESSE:SERIENNUMMER:OK:OK_BEMERKUNGEN:RESTBUCHWERT_2019:INV_BILD:ANSCHAFFUNGSWERT::THIS_YEAR:SEL_DATE:PK_INV_INVENTAR:FK_BAS_INV_INVENTARTYP:GERAETENAME:FK_BAS_STEU_STEUER_S'
||'ATZ:RESTBUCHWERT_2020:FK_STD_VERW_VERWENDUNGSZWECK'
,p_sort_column_1=>'DATUM_NEXT'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43393041807087639)
,p_report_id=>wwv_flow_api.id(43256027985619270)
,p_name=>'this_next_month'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_DATE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_DATE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43393447096087639)
,p_report_id=>wwv_flow_api.id(43256027985619270)
,p_name=>'this_year'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'THIS_YEAR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("THIS_YEAR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0EACE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43239722202616313)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(95065552382476716)
,p_plug_name=>unistr('n\00E4chste_Zahlung')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FK_MAIN_KEY,',
'       ID,',
'       "Buchungstag",',
'       "Betrag",',
'       Waehrung,',
'       Fremdwaehrungsbetrag,',
'       Fremdwaehrung,',
'       BUCHUNGSTEXT,',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       FK_std_kto_Kontotyp,',
'       FK_bas_kal_BUCHUNGSTAG,',
'       FK_bas_kal_WERTSTELLUNG,',
'       VERWENDUNGSZWECK,',
'       KATEGORIE,',
'       BUCHT_TAG,',
'       BUCHT_MONAT,',
'       BUCHT_JAHR,',
'       BUCHT_DATUM,',
'       WERTT_TAG,',
'       WERTT_MONAT,',
'       WERTT_JAHR,',
'       WERTT_DATUM,',
'       Kontotyp,',
'       FK_kto_VORGANG,',
'       WIEDERHOLUNG,',
'       NAECHSTE_ZAHLUNG,',
'       substr(naechste_Zahlung,7,4) jahr,',
'       arb.tag arb_tag,',
'       arb.monat arb_monat,',
'       arb.jahr arb_jahr,',
'       case when arb1.pk_bas_kal_arbeitstage is not null then 1 else 0 end sel_date',
'  from V_kto_KONTEN_ZUS zus',
'   left join  t_bas_kal_arbeitstage  arb on zus.naechste_zahlung = arb.datum',
'   left join   (select * from t_bas_kal_arbeitstage where datum = :P1_sel_date)  arb1 on (arb.monat = arb1.monat or arb.monat = arb1.monat+1) and arb.jahr = arb1.jahr',
'  where  trunc(naechste_Zahlung) >= trunc(sysdate)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(95065646329476716)
,p_name=>unistr('n\00E4chste_Zahlung')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL:'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>95065646329476716
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43211651966605087)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43212076040605087)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43212488718605087)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43213639016605087)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43216082004605089)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43216436980605089)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43216820472605089)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43217268043605090)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43217641452605090)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43218097023605090)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43218451786605090)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43218800474605090)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43219296682605090)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43219604277605090)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43220801529605092)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43221211270605092)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43210497132605076)
,p_db_column_name=>'Betrag'
,p_display_order=>37
,p_column_identifier=>'AB'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43211221204605085)
,p_db_column_name=>'JAHR'
,p_display_order=>57
,p_column_identifier=>'AD'
,p_column_label=>'Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43221649723605092)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>67
,p_column_identifier=>'AE'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43222016017605093)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>77
,p_column_identifier=>'AF'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43222487695605093)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>87
,p_column_identifier=>'AG'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240477439616320)
,p_db_column_name=>'SEL_DATE'
,p_display_order=>97
,p_column_identifier=>'AH'
,p_column_label=>'Sel Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45851272294563520)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>157
,p_column_identifier=>'AN'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45851344403563521)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>167
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122165235988322)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>177
,p_column_identifier=>'AP'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122237563988323)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>187
,p_column_identifier=>'AQ'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122309826988324)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>197
,p_column_identifier=>'AR'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46122833064988329)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>207
,p_column_identifier=>'AS'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46123180565988332)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>237
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46123201118988333)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>247
,p_column_identifier=>'AW'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250418350933721)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>257
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50227431999457343)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>267
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(95078205215498103)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'432228'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:ARB_JAHR:ARB_MONAT:NAECHSTE_ZAHLUNG:FK_MAIN_KEY:ID:Buchungstag:Betrag:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:WERTT_TAG:WERTT_MONAT:WIEDERHOLUNG:ARB_TAG:SEL_DATE::FK_BAS_FK_BAS_BUCHUNGSTAG:KONTOTYP:FK_KTO_VORGANG:WAEHRUNGSB'
||'ETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP'
,p_break_on=>'JAHR:ARB_JAHR:ARB_MONAT'
,p_break_enabled_on=>'JAHR:ARB_JAHR:ARB_MONAT'
,p_sum_columns_on_break=>'Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43294103909978362)
,p_report_id=>wwv_flow_api.id(95078205215498103)
,p_name=>unistr('N\00E4chste Zahlung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'NAECHSTE_ZAHLUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("NAECHSTE_ZAHLUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43294526795978364)
,p_report_id=>wwv_flow_api.id(95078205215498103)
,p_name=>'this_month'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_DATE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_DATE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43293329187978362)
,p_report_id=>wwv_flow_api.id(95078205215498103)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43293799321978362)
,p_report_id=>wwv_flow_api.id(95078205215498103)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'20 0'
,p_condition_sql=>'"JAHR" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''20 0''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43239860026616314)
,p_name=>'P1_SEL_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(43239722202616313)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43239926115616315)
,p_name=>'P1_DAY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(43239722202616313)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43240047330616316)
,p_name=>'P1_MONTH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(43239722202616313)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43240153369616317)
,p_name=>'P1_YEAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(43239722202616313)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(43240212905616318)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_SEL_DATE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(43240380347616319)
,p_event_id=>wwv_flow_api.id(43240212905616318)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
