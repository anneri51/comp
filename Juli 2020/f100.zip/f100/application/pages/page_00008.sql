prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Location'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Location'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44302507886647023)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200628195817'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7728155965756538)
,p_plug_name=>'LOCATION'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7740952579756629)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7677428860527541)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(7707970616527623)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7696346451527574)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9560335504312227)
,p_plug_name=>'Neue Adresse'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12407740424122467)
,p_plug_name=>'Vorgabe'
,p_parent_plug_id=>wwv_flow_api.id(9560335504312227)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12407828749122468)
,p_plug_name=>'Erfassung'
,p_parent_plug_id=>wwv_flow_api.id(9560335504312227)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12575478828928045)
,p_plug_name=>'Search_Location'
,p_region_name=>'dlSearchLoc'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7671568622527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12575566554928046)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION,P8_FK_ADRESSE,P8_NEW_ADDRESS,P8_NEW_LOCATION_NAME,P8_SRC_PAGE,P8_SRC_PK:#PK_LOCATION#,#FK_ADRESSE#,&P8_NEW_ADDRESS.,&P8_NEW_LOCATION_NAME.,&P8_SRC_PAGE.,&P8_SRC_PK.'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20445382519957427
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12575713330928048)
,p_db_column_name=>'LOCATION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12575989372928051)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576117463928052)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576217196928053)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576343194928054)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576430398928055)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576557041928056)
,p_db_column_name=>'STRASSE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576655671928057)
,p_db_column_name=>'HSNR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576770289928058)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576867523928059)
,p_db_column_name=>'COMM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12576954831928060)
,p_db_column_name=>'POSTFACH'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12577071357928061)
,p_db_column_name=>'PLZ'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12577127461928062)
,p_db_column_name=>'ORT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12577217524928063)
,p_db_column_name=>'LAND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12577306986928064)
,p_db_column_name=>'ADR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724458584899927)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724554337899928)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724665288899929)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724788495899930)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724860685899931)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724969505899932)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725012105899933)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12600653837086761)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'204705'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCATION:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ORT:LAND:ADR:PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12606359884138045)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7676299225527541)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1556846636766533)
,p_plug_name=>'Location / Adresse'
,p_parent_plug_id=>wwv_flow_api.id(12606359884138045)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location',
'where pk_loc_location = :P8_PK_loc_LOCATION',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1556965475766534)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>9426781440795915
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557166095766536)
,p_db_column_name=>'STRASSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557201967766537)
,p_db_column_name=>'HSNR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557350080766538)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557549145766540)
,p_db_column_name=>'POSTFACH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557647176766541)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557723330766542)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557813854766543)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1557975539766544)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1558021356766545)
,p_db_column_name=>'COMM'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12406833078122458)
,p_db_column_name=>'LOCATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12407095903122461)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12407218720122462)
,p_db_column_name=>'PLZ'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12407335600122463)
,p_db_column_name=>'ORT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12407483909122464)
,p_db_column_name=>'LAND'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12407518367122465)
,p_db_column_name=>'ADR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723260381899915)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723388531899916)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723409811899917)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723555177899918)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723672160899919)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723786443899920)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723824232899921)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1592049844560387)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94619'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCATION:LOCATION_TYPE:ADR:STRASSE:HSNR:POSTFACH:PLZ:ORT:LAND:BESCHREIBUNG:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:COMM::PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12606472695138046)
,p_plug_name=>'Adresse'
,p_parent_plug_id=>wwv_flow_api.id(12606359884138045)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_adr_adresse',
'where pk_adr_adresse = :P8_FK_adr_Adresse'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12606497076138047)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20476313041167428
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12606713421138049)
,p_db_column_name=>'STRASSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12606847953138050)
,p_db_column_name=>'HSNR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12606962159138051)
,p_db_column_name=>'PLZ'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12606999370138052)
,p_db_column_name=>'ORT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12607143180138053)
,p_db_column_name=>'LAND'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12607222578138054)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12607309853138055)
,p_db_column_name=>'ADR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46723940243899922)
,p_db_column_name=>'PK_ADR_ADRESSE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724005572899923)
,p_db_column_name=>'OT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ot'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724194138899924)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724218931899925)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46724380796899926)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12688391881086756)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'205583'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STRASSE:HSNR:PLZ:ORT:LAND:BESCHREIBUNG:ADR:PK_ADR_ADRESSE:OT:PK_ADR_ORT:PK_ADR_LAND:PK_ADR_PLZ_ORT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12826007800042865)
,p_plug_name=>'All Locations'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12826117279042866)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'15'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20695933244072247
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12826230309042867)
,p_db_column_name=>'STRASSE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12826343147042868)
,p_db_column_name=>'HSNR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12826427952042869)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968220732159420)
,p_db_column_name=>'POSTFACH'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968342969159421)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968447528159422)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968576779159423)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968640011159424)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968688021159425)
,p_db_column_name=>'COMM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968888263159427)
,p_db_column_name=>'LOCATION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969216236159430)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969341716159431)
,p_db_column_name=>'PLZ'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969442958159432)
,p_db_column_name=>'ORT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969497596159433)
,p_db_column_name=>'LAND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969584502159434)
,p_db_column_name=>'ADR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725138448899934)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725219140899935)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725318359899936)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725479659899937)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725501693899938)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725610118899939)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46725789361899940)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12979372669162707)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'208492'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STRASSE:HSNR:BESCHREIBUNG:POSTFACH:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:COMM:LOCATION:LOCATION_TYPE:PLZ:ORT:LAND:ADR:PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9562438091312248)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9560335504312227)
,p_button_name=>'create_adress_new'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Create adress new'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9561330839312237)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(12407828749122468)
,p_button_name=>'CREATE_ADRESS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Create adress'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12577417309928065)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'Search_Location'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Search location'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>8
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12577768156928068)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'Reset_Location'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION,P8_FK_ADRESSE,P8_NEW_LOCATION_NAME,P8_NEW_ADDRESS,P8_SRC_PK,P8_SRC_PAGE:,,&P8_NEW_LOCATION_NAME.,&P8_NEW_ADDRESS.,&P8_SRC_PK.,&P8_SRC_PAGE.'
,p_grid_new_row=>'N'
,p_grid_column=>10
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12822808450042833)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'Location_Type'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Location type'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:234:&SESSION.::&DEBUG.:RP,234:P234_PK_LOCATION_TYPE:&P8_FK_LOCATION_TYPE.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9561662771312240)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(12407828749122468)
,p_button_name=>'Add_Adr_PLZ_ORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add plz ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9560939546312233)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(12407828749122468)
,p_button_name=>'Add_ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9560671552312230)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(12407828749122468)
,p_button_name=>'Add_Land'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add land'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7729016619756601)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7729144988756602)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7728916978756601)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7729103890756601)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7728155965756538)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(9561997043312244)
,p_branch_name=>'Go To Page 8'
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION:&P8_PK_LOCATION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(9561662771312240)
,p_branch_sequence=>31
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7730744764756609)
,p_branch_name=>'Go To Page 7'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>61
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7731601085756613)
,p_name=>'P8_PK_LOC_LOCATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_use_cache_before_default=>'NO'
,p_source=>'PK_LOC_LOCATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7731978105756613)
,p_name=>'P8_LOCATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Location'
,p_source=>'LOCATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7732341187756613)
,p_name=>'P8_FK_BAS_LOC_LOCATION_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Typ'
,p_source=>'FK_BAS_LOC_LOCATION_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Location_type, pk_bas_loc_location_type',
'from t_bas_loc_location_type',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7732725885756614)
,p_name=>'P8_FK_ADR_ADRESSE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_use_cache_before_default=>'NO'
,p_prompt=>'zugeh. Adresse'
,p_source=>'FK_ADR_ADRESSE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select strasse || '' '' || hsnr || '' '' || plz || '' '' || ort || '' - '' || ot || '' ('' || pk_adr_adresse || '')'', pk_adr_adresse',
'from t_adr_Adresse ta',
' left join t_adr_plz_ort tpo on tpo.pk_adr_plz_ort = ta.fk_adr_plz_ort',
' left join t_adr_ort tor on tor.pk_adr_ort = tpo.fk_adr_ort',
'order by strasse, plz, ort'))
,p_lov_display_null=>'YES'
,p_cSize=>60
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9560479757312228)
,p_name=>'P8_LAND'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land',
'from t_adr_land',
'order by land'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9560530969312229)
,p_name=>'P8_ORT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Ort'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort',
'from t_adr_ort',
'order by ort'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9560701815312231)
,p_name=>'P8_FK_ADR_LAND'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Fk land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land, pk_land',
'from t_land'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9560784215312232)
,p_name=>'P8_FK_ADR_ORT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Fk ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ('' || land || '')'', pk_adr_ort',
'from t_adr_ort ort ',
'  left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land',
'order by ort'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9561010549312234)
,p_name=>'P8_STRASSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Strasse'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9561139986312235)
,p_name=>'P8_HSNR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'HSNR'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9561202837312236)
,p_name=>'P8_PLZ'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Plz'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9561442602312238)
,p_name=>'P8_FK_ADR_PLZ_ORT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(12407828749122468)
,p_prompt=>'Fk plz ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select plz || '' '' || ort || '' - '' || ot ||  '' ('' || land || '')'', pk_adr_plz_ort',
'from t_adr_plz_ort plzort',
'  left join t_adr_ort ort on plzort.fk_adr_ort = ort.pk_adr_ort',
'  left join t_ADR_land la on la.pk_ADR_land = ort.fk_adr_land',
'order by ort'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cattributes_element=>'style="margin-right:8px"'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12406562613122455)
,p_name=>'P8_NEW_ADDRESS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12407740424122467)
,p_prompt=>'Neue Adresse'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12572952655928020)
,p_name=>'P8_NEW_LOCATION_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12407740424122467)
,p_prompt=>'Neue Locationsbezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12577871578928069)
,p_name=>'P8_SRC_PAGE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603871383138020)
,p_name=>'P8_SRC_PK'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(7728155965756538)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9562697732312251)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_FK_ADR_PLZ_ORT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9562816715312252)
,p_event_id=>wwv_flow_api.id(9562697732312251)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P8_FK_ADR_ORT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_adr_ort',
'from t_adr_plz_ort',
'where pk_adr_plz_ort = :P8_FK_adr_PLZ_ORT'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9562951656312253)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_FK_ADR_ORT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9563073085312254)
,p_event_id=>wwv_flow_api.id(9562951656312253)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' if :P118_fk_adr_ort is not null then',
'select fk_adr_land',
'into :P118_fk_adr_land',
'from t_adr_ort',
'where pk_adr_ort = :P118_fk_adr_ort;',
'end if;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(12577549389928066)
,p_name=>'Search_Location'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(12577417309928065)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(12577584293928067)
,p_event_id=>wwv_flow_api.id(12577549389928066)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''dlSearchLoc'');'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7734793654756617)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_LOC_LOCATION'
,p_attribute_02=>'T_LOC_LOCATION'
,p_attribute_03=>'P8_PK_LOC_LOCATION'
,p_attribute_04=>'PK_LOC_LOCATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7735170476756619)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_LOCATION'
,p_attribute_02=>'T_LOCATION'
,p_attribute_03=>'P8_PK_LOC_LOCATION'
,p_attribute_04=>'PK_LOCATION'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7735607335756619)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7729103890756601)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9561511902312239)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_ort ',
'  (',
'    fk_land,',
'     ort',
'  )',
'  values (',
'       :P8_FK_LAnd,',
'       :P8_ort',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9560939546312233)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9561756245312241)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_plz_ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_plz_ort ',
'  (',
'    fk_ort,',
'     plz',
'  )',
'  values (',
'       :P8_FK_ort,',
'       :P8_plz',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9561662771312240)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9562167586312245)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_adress'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into T_ADRESSE',
'  (',
'    fk_plz_ort,',
'    strasse,',
'      hsnr',
'  )',
'  values (',
'       :P8_FK_plz_ort,',
'       :P8_strasse,',
'      :P8_hsnr',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9561330839312237)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9562537394312249)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create_adr_new'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_pk_plz_ort   NUMBER;',
'    v_pk_ort       NUMBER;',
'    v_pk_land      NUMBER;',
'BEGIN',
'',
unistr('  --Land hinzuf\00FCgen'),
'    IF :p8_fk_land IS NULL THEN',
'        v_pk_land := t_land_seq.nextval;',
'        INSERT INTO t_land (',
'            pk_land,',
'            land',
'        ) VALUES (',
'            v_pk_land,',
'            :p8_land',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_land :=:p8_fk_land;',
'    END IF;',
'  ',
unistr('  --Ort hinzuf\00FCgen'),
'',
'    IF :p8_fk_ort IS NULL THEN',
'        v_pk_ort := seq_ort.nextval;',
'        INSERT INTO t_ort (',
'            pk_ort,',
'            fk_land,',
'            ort',
'        ) VALUES (',
'            v_pk_ort,',
'            v_pk_land,',
'            :P8_ORT',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_ort :=:p8_fk_ort;',
'    END IF;',
'  ',
unistr('  --PLZ Ort hinzuf\00FCgen'),
'    IF :p8_fk_plz_ort IS NULL THEN',
'        v_pk_plz_ort := seq_plz_ort.nextval;',
'        INSERT INTO t_plz_ort (',
'            pk_plz_ort,',
'            fk_ort,',
'            plz',
'        ) VALUES (',
'            v_pk_plz_ort,',
'            v_pk_ort,',
'            :p8_plz',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_plz_ort := :p8_fk_plz_ort;',
'    END IF;',
'  ',
unistr('  --Adresse hinzuf\00FCgen'),
'    INSERT INTO t_adresse (',
'        fk_plz_ort,',
'        strasse,',
'        hsnr',
'    ) VALUES (',
'        v_pk_plz_ort,',
'        :p8_strasse,',
'        :p8_hsnr',
'    );',
'',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9562438091312248)
);
wwv_flow_api.component_end;
end;
/
