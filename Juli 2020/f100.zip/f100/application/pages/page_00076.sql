prompt --application/pages/page_00076
begin
--   Manifest
--     PAGE: 00076
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>76
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Bankbelege'
,p_step_title=>'Bankbelege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309931308713843)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200614115813'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2696708538114179)
,p_plug_name=>'Bankbelege'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_BEL_BELEG,',
'       FK_BAS_STEU_STEUER_SATZ,',
'       FK_BAS_BEL_BELEGART,',
'       FK_STD_VERW_VERWENDUNGSZWECK,',
'       FK_BAS_KAL_ARBEITSTAG,',
'       FK_PROJ_PROJEKT,',
'       FK_LEHR_LEHRGANG,',
'       FK_WH_WAREN_BEWEGUNG,',
'       BELEG,',
'       BETRAG_BRUTTO,',
'       DATUM,',
'       VON,',
'       BIS,',
'       AZ_O_PAUSE,',
'       AZ_M_PAUSE,',
'       ANWESENHEITSZEIT,',
'       PARKZEIT,',
'       AZ_MANUELL_GEPFLEGT,',
'       KOMMENTAR,',
'       BETRAG_NETTO,',
'       FK_IMP_BEL_NR,',
'       FK_IMP_NO,',
'       EXT_RENR,',
'       EXT_AUFTRAGSNR,',
'       EXT_LIEFERSCHEINNR,',
'       EXT_LEISTUNGSDATUM,',
'       EXT_RECHNUNGSDATUM,',
'       EXT_AUFTRAGSDATUM,',
'       FK_STD_RE_OFFEN,',
'       FK_STD_STEU_VORSTEUERRELEVANT,',
'       FK_STD_STEU_VORSTEUERPFLEGE,',
'       FK_STD_RE_RECHNUNGSERSTELLUNG,',
'       FK_STD_RE_RECHNUNG_ERSTELLT,',
'       FK_std_kto_BANKBELEG,',
'       CREATED_BY,',
'       CREATED_AT,',
'       MODIFIED_BY,',
'       MODIFIED_AT,',
'       MWST,',
'       FK_STD_WH_LIEFERART,',
'       FK_std_STEU_EINKOMMENSTEUERRELEVANT,',
'       FK_std_STEU_UNTERNEHMENSSTEUERRELEVANT,',
'       FK_WH_waren_BESTELLNR,',
'       FK_std_WH_BESTELLTYP,',
'       FK_STD_abr_ABRECHNUNGSZEITRAUM,',
'       FK_BAS_MON_FREMDWAEHRUNG,',
'       FRMDW_BETRAG_NETTO,',
'       FRMDW_STSATZ,',
'       FRMDW_MWST,',
'       FRMDW_BETRAG_BRUTTO,',
'       BUCHUNGSTAG,',
'       FK_Kto_bankKONTO,',
'       KUMULIERTER_BETRAG_NEG,',
'       KUMULIERTER_BETRAG,',
'       ENDBETRAG,',
'       STARTBETRAG,',
'       BETRAG_NEG,',
'       FK_BAS_MON_BELEGWAEHRUNG,',
'       FK_STD_MON_UMSATZART,',
'       EINZELBETRAG_NEG,',
'       FK_MAIN_BELEG,',
'       FK_std_BEL_FEHLEND',
'  from T_BEL_BELEG',
'where fk_std_kto_bankbeleg = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2696859880114179)
,p_name=>'Bankbelege'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP:P23_PK_BELEG:#PK_BELEG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>10566675845143560
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2700470028114192)
,p_db_column_name=>'BELEG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2700821595114193)
,p_db_column_name=>'BETRAG_BRUTTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Betrag Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2701254419114193)
,p_db_column_name=>'DATUM'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2701595895114193)
,p_db_column_name=>'VON'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2702020450114193)
,p_db_column_name=>'BIS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2702465922114193)
,p_db_column_name=>'AZ_O_PAUSE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Az O Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2702861263114194)
,p_db_column_name=>'AZ_M_PAUSE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Az M Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2703228777114194)
,p_db_column_name=>'ANWESENHEITSZEIT'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Anwesenheitszeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2703592257114194)
,p_db_column_name=>'PARKZEIT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Parkzeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2704043176114194)
,p_db_column_name=>'AZ_MANUELL_GEPFLEGT'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Az Manuell Gepflegt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2704478708114195)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2704804917114195)
,p_db_column_name=>'BETRAG_NETTO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Betrag Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2705234156114195)
,p_db_column_name=>'FK_IMP_BEL_NR'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Fk Imp Bel Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2705683084114195)
,p_db_column_name=>'FK_IMP_NO'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Imp No'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2706006687114196)
,p_db_column_name=>'EXT_RENR'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ext Renr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2706471705114196)
,p_db_column_name=>'EXT_AUFTRAGSNR'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ext Auftragsnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2706789652114196)
,p_db_column_name=>'EXT_LIEFERSCHEINNR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ext Lieferscheinnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2707227055114196)
,p_db_column_name=>'EXT_LEISTUNGSDATUM'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ext Leistungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2707884094114197)
,p_db_column_name=>'EXT_RECHNUNGSDATUM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ext Rechnungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2708289495114197)
,p_db_column_name=>'EXT_AUFTRAGSDATUM'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ext Auftragsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2711087718114199)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2711532990114199)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2711888573114200)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2712354075114200)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2712773725114200)
,p_db_column_name=>'MWST'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2715917505114202)
,p_db_column_name=>'FRMDW_BETRAG_NETTO'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Betrag Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2716316481114203)
,p_db_column_name=>'FRMDW_STSATZ'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Frmdw Stsatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2716737995114203)
,p_db_column_name=>'FRMDW_MWST'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Frmdw Mwst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2717095463114203)
,p_db_column_name=>'FRMDW_BETRAG_BRUTTO'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Frmdw Betrag Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2717494741114203)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2718372705114204)
,p_db_column_name=>'KUMULIERTER_BETRAG_NEG'
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>'Kumulierter Betrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2718735490114205)
,p_db_column_name=>'KUMULIERTER_BETRAG'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Kumulierter Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2719132222114205)
,p_db_column_name=>'ENDBETRAG'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Endbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2719572632114205)
,p_db_column_name=>'STARTBETRAG'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Startbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2719919024114205)
,p_db_column_name=>'BETRAG_NEG'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Betrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2721149645114206)
,p_db_column_name=>'EINZELBETRAG_NEG'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Einzelbetrag Neg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2721502963114206)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Fk Main Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250693046933723)
,p_db_column_name=>'PK_BEL_BELEG'
,p_display_order=>71
,p_column_identifier=>'BK'
,p_column_label=>'Pk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250755934933724)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>81
,p_column_identifier=>'BL'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250876469933725)
,p_db_column_name=>'FK_BAS_BEL_BELEGART'
,p_display_order=>91
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bas Bel Belegart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49250930261933726)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>101
,p_column_identifier=>'BN'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251037598933727)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>111
,p_column_identifier=>'BO'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251154423933728)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>121
,p_column_identifier=>'BP'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251213234933729)
,p_db_column_name=>'FK_LEHR_LEHRGANG'
,p_display_order=>131
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Lehr Lehrgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251300299933730)
,p_db_column_name=>'FK_WH_WAREN_BEWEGUNG'
,p_display_order=>141
,p_column_identifier=>'BR'
,p_column_label=>'Fk Wh Waren Bewegung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251463971933731)
,p_db_column_name=>'FK_STD_RE_OFFEN'
,p_display_order=>151
,p_column_identifier=>'BS'
,p_column_label=>'Fk Std Re Offen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251515815933732)
,p_db_column_name=>'FK_STD_STEU_VORSTEUERRELEVANT'
,p_display_order=>161
,p_column_identifier=>'BT'
,p_column_label=>'Fk Std Steu Vorsteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251639129933733)
,p_db_column_name=>'FK_STD_STEU_VORSTEUERPFLEGE'
,p_display_order=>171
,p_column_identifier=>'BU'
,p_column_label=>'Fk Std Steu Vorsteuerpflege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251717590933734)
,p_db_column_name=>'FK_STD_RE_RECHNUNGSERSTELLUNG'
,p_display_order=>181
,p_column_identifier=>'BV'
,p_column_label=>'Fk Std Re Rechnungserstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251812926933735)
,p_db_column_name=>'FK_STD_RE_RECHNUNG_ERSTELLT'
,p_display_order=>191
,p_column_identifier=>'BW'
,p_column_label=>'Fk Std Re Rechnung Erstellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49251997490933736)
,p_db_column_name=>'FK_STD_KTO_BANKBELEG'
,p_display_order=>201
,p_column_identifier=>'BX'
,p_column_label=>'Fk Std Kto Bankbeleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252098587933737)
,p_db_column_name=>'FK_STD_WH_LIEFERART'
,p_display_order=>211
,p_column_identifier=>'BY'
,p_column_label=>'Fk Std Wh Lieferart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252124548933738)
,p_db_column_name=>'FK_STD_STEU_EINKOMMENSTEUERRELEVANT'
,p_display_order=>221
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Std Steu Einkommensteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252236283933739)
,p_db_column_name=>'FK_STD_STEU_UNTERNEHMENSSTEUERRELEVANT'
,p_display_order=>231
,p_column_identifier=>'CA'
,p_column_label=>'Fk Std Steu Unternehmenssteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252319643933740)
,p_db_column_name=>'FK_WH_WAREN_BESTELLNR'
,p_display_order=>241
,p_column_identifier=>'CB'
,p_column_label=>'Fk Wh Waren Bestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252414374933741)
,p_db_column_name=>'FK_STD_WH_BESTELLTYP'
,p_display_order=>251
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Wh Bestelltyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252535716933742)
,p_db_column_name=>'FK_STD_ABR_ABRECHNUNGSZEITRAUM'
,p_display_order=>261
,p_column_identifier=>'CD'
,p_column_label=>'Fk Std Abr Abrechnungszeitraum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252658015933743)
,p_db_column_name=>'FK_BAS_MON_FREMDWAEHRUNG'
,p_display_order=>271
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Mon Fremdwaehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252719245933744)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>281
,p_column_identifier=>'CF'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252808941933745)
,p_db_column_name=>'FK_BAS_MON_BELEGWAEHRUNG'
,p_display_order=>291
,p_column_identifier=>'CG'
,p_column_label=>'Fk Bas Mon Belegwaehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49252974555933746)
,p_db_column_name=>'FK_STD_MON_UMSATZART'
,p_display_order=>301
,p_column_identifier=>'CH'
,p_column_label=>'Fk Std Mon Umsatzart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49253048983933747)
,p_db_column_name=>'FK_STD_BEL_FEHLEND'
,p_display_order=>311
,p_column_identifier=>'CI'
,p_column_label=>'Fk Std Bel Fehlend'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2722494775117737)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'105924'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'BELEG:BETRAG_BRUTTO:DATUM:VON:BIS:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:PARKZEIT:AZ_MANUELL_GEPFLEGT:KOMMENTAR:BETRAG_NETTO:FK_IMP_BEL_NR:FK_IMP_NO:EXT_RENR:EXT_AUFTRAGSNR:EXT_LIEFERSCHEINNR:EXT_LEISTUNGSDATUM:EXT_RECHNUNGSDATUM:EXT_AUFTRAGSDATUM:CR'
||'EATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:MWST:FRMDW_BETRAG_NETTO:FRMDW_STSATZ:FRMDW_MWST:FRMDW_BETRAG_BRUTTO:BUCHUNGSTAG:KUMULIERTER_BETRAG_NEG:KUMULIERTER_BETRAG:ENDBETRAG:STARTBETRAG:BETRAG_NEG:EINZELBETRAG_NEG:FK_MAIN_BELEG:PK_BEL_BELEG:FK_BAS_'
||'STEU_STEUER_SATZ:FK_BAS_BEL_BELEGART:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_ARBEITSTAG:FK_PROJ_PROJEKT:FK_LEHR_LEHRGANG:FK_WH_WAREN_BEWEGUNG:FK_STD_RE_OFFEN:FK_STD_STEU_VORSTEUERRELEVANT:FK_STD_STEU_VORSTEUERPFLEGE:FK_STD_RE_RECHNUNGSERSTELLUNG:FK_S'
||'TD_RE_RECHNUNG_ERSTELLT:FK_STD_KTO_BANKBELEG:FK_STD_WH_LIEFERART:FK_STD_STEU_EINKOMMENSTEUERRELEVANT:FK_STD_STEU_UNTERNEHMENSSTEUERRELEVANT:FK_WH_WAREN_BESTELLNR:FK_STD_WH_BESTELLTYP:FK_STD_ABR_ABRECHNUNGSZEITRAUM:FK_BAS_MON_FREMDWAEHRUNG:FK_KTO_BANK'
||'KONTO:FK_BAS_MON_BELEGWAEHRUNG:FK_STD_MON_UMSATZART:FK_STD_BEL_FEHLEND'
,p_sort_column_1=>'DATUM'
,p_sort_direction_1=>'ASC'
,p_break_on=>'DATUM'
,p_break_enabled_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2727555284247598)
,p_report_id=>wwv_flow_api.id(2722494775117737)
,p_name=>'unzugeordnet'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_BELEG'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("FK_MAIN_BELEG" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F26666'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2727950724247598)
,p_report_id=>wwv_flow_api.id(2722494775117737)
,p_name=>'zugeordnet'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_BELEG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_BELEG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#9AE3B2'
);
wwv_flow_api.component_end;
end;
/
