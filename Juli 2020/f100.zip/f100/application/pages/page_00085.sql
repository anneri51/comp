prompt --application/pages/page_00085
begin
--   Manifest
--     PAGE: 00085
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>85
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Route_zoom_neu'
,p_step_title=>'Route_zoom_neu'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44300449168613020)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <meta name="viewport" content="initial-scale=1.0, width=device-width" />',
'<link rel="stylesheet" type="text/css" href="https://js.api.here.com/v3/3.0/mapsjs-ui.css?dp-version=1533195059" />',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-core.js"',
'  type="text/javascript" charset="utf-8"></script>',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-service.js"',
'  type="text/javascript" charset="utf-8"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-ui.js"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-mapevents.js"></script>'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var v_ctr_lat = document.getElementById(''P85_CTR_LAT'').value;',
'var v_ctr_lng = document.getElementById(''P85_CTR_LNG'').value;',
'',
'var v_wp_str = new Array();',
'var v_wp_str_parts = new Array();',
'',
'v_wp_str[0] = [''55.1120423728813,8.68340740740811'',''Verbr1: 0 km - Hausstr. 0, Bremen''];',
'v_wp_str[1] = [''56.5309916298853,13.3846220493377'', ''Verbr2: 2 km - Hausstr. 10, Bremen''];',
'v_wp_str[2] = [''58.5309916298853,13.3846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'v_wp_str[3] = [''59.5309916298853,13.3846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'v_wp_str[4] = [''59.5309916298853,13.8846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'//v_wp_str[5] = [''59.5309916298853,13.9846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'//v_wp_str[6] = [''58.5309916298853,14.5846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'//v_wp_str[7] = [''58.0309916298853,14.5846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'//v_wp_str[8] = [''58.0309916298853,15.5846220493377'', ''Verbr 3: 5 km - Hausstr. 1, Bremen''];',
'//v_wp_str[9] = [''58.0309916298853,15.9846220493377'', ''Verbr 3: 5 km - Hausstr. 9, Bremen''];',
'//v_wp_str[10] = [''56.0309916298853,15.9846220493377'', ''Verbr 3: 5 km - Hausstr. 9, Bremen''];',
'//v_wp_str[11] = [''54.0309916298853,15.9846220493377'', ''Verbr 3: 5 km - Hausstr. 9, Bremen''];',
'//v_wp_str[12] = [''54.0309916298853,15.3846220493377'', ''Verbr 3: 5 km - Hausstr. 9, Bremen''];',
'',
'var v_lat1 = 57.0309916298853;',
'var v_lng1 = 13.384622049337;',
'',
'alert(v_wp_str.length);',
'',
'',
'',
'var p_route_cnt = v_wp_str.length-1; ',
'',
'',
'for (i=0; i<= p_route_cnt; i++) {',
'v_wp_str_parts[i] = v_wp_str[i][0].split('','');',
'}                                 ',
'',
'',
'',
'// Instantiate a map and platform object:',
'var platform = new H.service.Platform({',
'  ''app_id'': ''hU8C4hi5HZZAA29CN1h5'',',
'  ''app_code'': ''no8qak0DOkDF8O_oi1xqaw''',
'});',
'',
'',
'',
'',
'// Retrieve the target element for the map:',
'var targetElement = document.getElementById(''mapContainer'');',
'',
'var pixelRatio = window.devicePixelRatio || 1;',
'var defaultLayers = platform.createDefaultLayers({',
'  tileSize: pixelRatio === 1 ? 256 : 512,',
'  ppi: pixelRatio === 1 ? undefined : 320',
'});',
'',
'// Instantiate the map:',
'var map = new H.Map(',
'  document.getElementById(''mapContainer''),',
'  defaultLayers.normal.map,',
'  {',
'  zoom: 8,',
'  center: { lat:  v_ctr_lat, lng: v_ctr_lng }',
'  });',
'',
'',
'//Step 3: make the map interactive',
'// MapEvents enables the event system',
'// Behavior implements default interactions for pan/zoom (also on mobile touch environments)',
'var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));',
'',
'// Step 4: Create the default UI:',
'var ui = H.ui.UI.createDefault(map, defaultLayers, ''en-US'');',
'',
'// Add the click event listener.',
'addDraggableMarker(map, behavior);',
'',
'function addDraggableMarker(map, behavior){',
'',
'  var marker = new H.map.Marker({ lat:  v_wp_str_parts[2][0], lng: v_wp_str_parts[2][1]});',
'  // Ensure that the marker can receive drag events',
'  marker.draggable = true;',
'  map.addObject(marker);',
'',
'  // disable the default draggability of the underlying map',
'  // when starting to drag a marker object:',
'  map.addEventListener(''dragstart'', function(ev) {',
'    var target = ev.target;',
'    if (target instanceof H.map.Marker) {',
'      behavior.disable();',
'    }',
'  }, false);',
'',
'',
'  // re-enable the default draggability of the underlying map',
'  // when dragging has completed',
'  map.addEventListener(''dragend'', function(ev) {',
'    var target = ev.target;',
'    if (target instanceof mapsjs.map.Marker) {',
'      behavior.enable();',
'    }',
'  }, false);',
'',
'  // Listen to the drag event and move the position of the marker',
'  // as necessary',
'   map.addEventListener(''drag'', function(ev) {',
'    var target = ev.target,',
'        pointer = ev.currentPointer;',
'    if (target instanceof mapsjs.map.Marker) {',
'      target.setPosition(map.screenToGeo(pointer.viewportX, pointer.viewportY));',
'    }',
'  }, false);',
'}',
'',
'',
'',
'',
'',
'// Define a callback function to process the routing response:',
'var onResult = function(result) {',
'  var route,',
'    routeShape,',
'    startPoint,',
'    endPoint,',
'    linestring;',
'  if(result.response.route) {',
'  // Pick the first route from the response:',
'  route = result.response.route[0];',
'  // Pick the route''s shape:',
'  routeShape = route.shape;',
'      ',
'',
'',
'  // Create a linestring to use as a point source for the route line',
'  linestring = new H.geo.LineString();',
'',
'',
'  // Push all the points in the shape into the linestring:',
'  routeShape.forEach(function(point) {',
'    var parts = point.split('','');',
'    linestring.pushLatLngAlt(parts[0], parts[1]);',
'  });',
'',
'      ',
'    ',
'      ',
'  // Retrieve the mapped positions of the requested waypoints:',
'  startPoint = route.waypoint[0].mappedPosition;',
'  endPoint = route.waypoint[1].mappedPosition;',
'',
'      ',
'',
'',
'  // Create a polyline to display the route:',
'  var routeLine = new H.map.Polyline(linestring, {',
'    style: { strokeColor: ''blue'', lineWidth: 10 }',
'  });',
'',
'  // Create a marker for the start point:',
'  var startMarker = new H.map.Marker({',
'    lat: startPoint.latitude,',
'    lng: startPoint.longitude',
'  });',
'',
'  // Create a marker for the end point:',
'  var endMarker = new H.map.Marker({',
'    lat: endPoint.latitude,',
'    lng: endPoint.longitude',
'  });',
'      ',
'',
'',
'',
'',
'  // Add the route polyline and the two markers to the map:',
'  map.addObjects([routeLine, startMarker, endMarker]);',
'',
'',
'  }',
'};',
'',
'',
'// Get an instance of the routing service:',
'var router = platform.getRoutingService();',
'',
'var routingParameters = new Array();',
'',
'for (i=1;i<= p_route_cnt; i++) {',
' ',
'// Create the parameters for the routing request:',
' routingParameters[i-1] = {',
'  // The routing mode:',
'  ''mode'': ''fastest;car'',',
'  // The start point of the route:',
'   ''waypoint0'': ''geo!'' +v_wp_str[i-1][0],',
'  // The end point of the route:',
'  ''waypoint1'':  ''geo!'' + v_wp_str[i][0],',
'      ',
'  // To retrieve the shape of the route we choose the route',
'  // representation mode ''display''',
'  ''representation'': ''display''',
'};',
'    ',
'    ',
'',
'',
'// Call calculateRoute() with the routing parameters,',
'// the callback and an error callback function (called if a',
'// communication error occurs):',
'',
'',
'router.calculateRoute(routingParameters[i-1], onResult,',
' function(error) {',
'   alert(error.message);',
'  });',
'  ',
'    ',
'}',
'',
'',
'//var today = Date(Date.now()).getDate();',
' test = show_marker(v_lat1+0.25, v_lng1, ''Monteur'', ''green'');',
' test = show_marker(v_lat1+0.5, v_lng1,  Date(Date.now()).toString(),''green'');',
'// Date(Date.now()).toString()',
'',
'',
'function show_marker(v_lat, v_lng, v_text, v_fill) {',
'var svgMarkup = ''<svg width="250" height="22" '' +',
'  ''xmlns="http://www.w3.org/2000/svg">'' +',
'  ''<rect stroke="white" fill="'' + v_fill + ''" x="1" y="1" width="500" '' +',
'  ''height="22" /><text x="12" y="18" font-size="8pt" '' +',
'  ''font-family="Arial" font-weight="bold" text-anchor="left" '' +',
'  ''fill="white">'' + v_text + ''</text></svg>'';',
'',
' ',
'',
'// Create an icon, an object holding the latitude and longitude, and a marker:',
'var icon = new H.map.Icon(svgMarkup),',
'  coords = {lat: v_lat , lng: v_lng},',
'  marker = new H.map.Marker(coords, {icon: icon});',
'',
'// Add the marker to the map and center the map at the location of the marker:',
'map.addObject(marker);',
'};',
'',
'',
'',
'var Marker = new Array();',
'',
'var group = new H.map.Group();',
'',
'var marker_all = [];',
'',
'',
'for (i=0;i<= p_route_cnt;i++){',
'  var pos_ns =  parseFloat(v_wp_str_parts[i][0],10);',
'  var pos_ew = parseFloat(v_wp_str_parts[i][1],10);',
'    ',
'   Marker[i+1] = new H.map.Marker({lat:  pos_ns, lng: pos_ew});',
'  ',
'   map.addObject(Marker[i+1]);',
'   marker_all.push(Marker[i+1]);',
'  ',
'  ',
'       test1 =  show_marker(pos_ns+0.25, pos_ew+0.25, i + '': '' +v_wp_str[i][1] , ''#1b468d'');               ',
'      test2 =  show_marker(pos_ns+0.10, pos_ew+0.25,  ''('' +v_wp_str[i][0] +'')'' , ''#1b468d'');  ',
'}',
' ',
' ',
' group.addObjects(marker_all);',
' map.setViewBounds(group.getBounds());',
'    ',
'',
'',
'  // Set the map''s viewport to make the whole route visible:',
'  var line =  new H.geo.LineString();',
'  line.pushLatLngAlt(v_wp_str_parts[0][0], v_wp_str_parts[0][1]);',
'  line.pushLatLngAlt(v_wp_str_parts[ p_route_cnt][0], v_wp_str_parts[ p_route_cnt][1]);',
' // map.setViewBounds(line.getBounds());',
'',
'',
'',
'',
'',
'                                 ',
'                                 ',
'',
'',
'',
'',
'  ',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524081715'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(46171374064910173)
,p_plug_name=>'Route'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'width="50"'
,p_plug_display_point=>'BODY'
,p_plug_source=>' <div style="width: 640px; height: 480px" id="mapContainer">Monteursroute</div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'font-size:24px;'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3196073163791428)
,p_name=>'P85_CTR_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(46171374064910173)
,p_prompt=>'Ctr lat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3196405481791428)
,p_name=>'P85_CTR_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(46171374064910173)
,p_prompt=>'Ctr lng'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3196790504791429)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :P85_CTR_LAT := 54.13;',
'  :P85_CTR_LNG := 10.13;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
