prompt --application/pages/page_00089
begin
--   Manifest
--     PAGE: 00089
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>89
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Auswertung_Location'
,p_step_title=>'Auswertung_Location'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44302507886647023)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200625164325'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14084222939075276)
,p_plug_name=>'Auswertung_Location'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select T_loc_LOCATION.PK_loc_LOCATION,',
'       T_loc_LOCATION.LOCATION,',
'       T_loc_LOCATION.FK_bas_loc_LOCATION_TYPE,',
'       T_loc_LOCATION.FK_adr_ADRESSE,',
'       T_loc_LOCATION.CREATED_BY,',
'       T_loc_LOCATION.CREATED_AT,',
'       T_loc_LOCATION.MODIFIED_BY,',
'       T_loc_LOCATION.MODIFIED_AT,',
'       t_bel_beleg.datum,',
'       t_bel_beleg.fk_bas_kal_arbeitstag,',
'       t_bel_beleg.pk_bel_beleg,',
'       t_bel_beleg.beleg,',
'       t_adr_adresse.STRASSE, ',
'       t_adr_adresse.HSNR, ',
'       t_adr_adresse.BESCHREIBUNG, ',
'       t_adr_adresse.FK_adr_PLZ_ORT, ',
'       t_adr_adresse.POSTFACH,',
'       t_bas_loc_location_type.location_type,',
'       t_adr_ort.ort,',
'       t_adr_land.land',
'  from T_loc_LOCATION',
'    left join T_REL_bel_BELEG_LOCATION trelbelloc on trelbelloc.fk_loc_location = t_loc_location.pk_loc_location',
'    left join t_bel_beleg on t_bel_beleg.pk_bel_beleg = trelbelloc.fk_bel_beleg',
'    left join t_adr_adresse on t_adr_adresse.pk_adr_adresse = t_loc_location.fk_adr_adresse',
'    left join t_bas_loc_location_type on t_loc_location.fk_bas_loc_location_type = t_bas_loc_location_type.pk_bas_loc_location_type',
'    left join t_adr_plz_ort on t_adr_plz_ort.pk_adr_plz_ort = t_adr_adresse.fk_adr_plz_ort',
'    left join t_adr_ort on t_adr_ort.pk_adr_ort = t_adr_plz_ort.FK_adr_ORT',
'    left join t_adr_land on t_adr_land.pk_adr_land = t_adr_ort.fk_adr_land'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14084361967075276)
,p_name=>'Auswertung_Location'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>21954177932104657
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3231261065876360)
,p_db_column_name=>'LOCATION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Location'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3232438648876361)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3232882516876361)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3233283795876362)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3233630370876362)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3230459004876360)
,p_db_column_name=>'DATUM'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3234858600876363)
,p_db_column_name=>'BELEG'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3235255567876363)
,p_db_column_name=>'STRASSE'
,p_display_order=>58
,p_column_identifier=>'M'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3235670822876363)
,p_db_column_name=>'HSNR'
,p_display_order=>68
,p_column_identifier=>'N'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3236046555876364)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>78
,p_column_identifier=>'O'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3236882088876364)
,p_db_column_name=>'POSTFACH'
,p_display_order=>98
,p_column_identifier=>'Q'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3237212269876364)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>108
,p_column_identifier=>'R'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3237667105876365)
,p_db_column_name=>'ORT'
,p_display_order=>118
,p_column_identifier=>'S'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3238082494876365)
,p_db_column_name=>'LAND'
,p_display_order=>128
,p_column_identifier=>'T'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522388898809730)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>138
,p_column_identifier=>'U'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522436988809731)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>148
,p_column_identifier=>'V'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522569992809732)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>158
,p_column_identifier=>'W'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522661748809733)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>168
,p_column_identifier=>'X'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522766863809734)
,p_db_column_name=>'PK_BEL_BELEG'
,p_display_order=>178
,p_column_identifier=>'Y'
,p_column_label=>'Pk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49522849438809735)
,p_db_column_name=>'FK_ADR_PLZ_ORT'
,p_display_order=>188
,p_column_identifier=>'Z'
,p_column_label=>'Fk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14087877911075669)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111082'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCATION:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:DATUM:BELEG:STRASSE:HSNR:BESCHREIBUNG:LOCATION_TYPE:ORT:LAND:POSTFACH::PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:FK_BAS_KAL_ARBEITSTAG:PK_BEL_BELEG:FK_ADR_PLZ_ORT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(52908952591684907)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(52909095134684908)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(52908952591684907)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'New'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:234:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.component_end;
end;
/
