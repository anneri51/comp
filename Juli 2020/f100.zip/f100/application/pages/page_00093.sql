prompt --application/pages/page_00093
begin
--   Manifest
--     PAGE: 00093
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>93
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Kategorie'
,p_step_title=>'Kategorie'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44303311777660193)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200614191459'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6747215222535977)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_BAS_KAT_KONTO_BUCH", ',
'Kategorie KATEGORIE,',
'neu_alt NEU_ALT,',
'FK_BAS_KAT_Oberkategorie FK_BAS_KAT_OBERKATEGORIE,',
'"VALID",',
'"VALID_FROM",',
'"VALID_TO",',
'"CREATION_DATE",',
'"MODIFY_DATE",',
'"CREATED_BY",',
'"MODIFIED_BY"',
'from "#OWNER#"."T_BAS_KAT_KONTO_BUCH" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6747650785535977)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:162:&APP_SESSION.::::P162_PK_KONTO_BUCH_KAT:#PK_KONTO_BUCH_KAT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>14617466750565358
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6748183489535981)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6748522668535982)
,p_db_column_name=>'NEU_ALT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Neu Alt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6749370816535984)
,p_db_column_name=>'VALID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Valid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6749687565535984)
,p_db_column_name=>'VALID_FROM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Valid From'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6750157935535985)
,p_db_column_name=>'VALID_TO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Valid To'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6750497449535986)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6750915979535987)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6751382485535987)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6751757472535988)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49523679633809743)
,p_db_column_name=>'PK_BAS_KAT_KONTO_BUCH'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Pk Bas Kat Konto Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49523743094809744)
,p_db_column_name=>'FK_BAS_KAT_OBERKATEGORIE'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Fk Bas Kat Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6752592967536696)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'146225'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KATEGORIE:NEU_ALT:VALID:VALID_FROM:VALID_TO:CREATION_DATE:MODIFY_DATE:CREATED_BY:MODIFIED_BY:PK_BAS_KAT_KONTO_BUCH:FK_BAS_KAT_OBERKATEGORIE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6752126849535988)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6747215222535977)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:162'
);
wwv_flow_api.component_end;
end;
/
