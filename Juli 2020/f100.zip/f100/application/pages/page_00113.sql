prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>113
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Allgemeine Belege'
,p_step_title=>'Allgemeine Belege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309772283708404)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619173103'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4501526836219635)
,p_plug_name=>'Allgemeine Belege'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'    nvl(allg_bel."BEZEICHNUNG", ''<<Keine Angabe>>'') Bezeichnung,',
'    allg_bel."LAND",',
'    allg_bel."S1",',
'    allg_bel."S2",',
'    allg_bel."BETRAG",',
'    allg_bel.Waehrung, ',
'    allg_bel."S4",',
'    allg_bel.Steuersatz,',
'    allg_bel."S6",',
'    allg_bel."STEUERNUMMER",',
'    allg_bel."DATUM",',
'    allg_bel."UHRZEIT",',
'    allg_bel."BELEGNUMMER",',
'    allg_bel."ZAHLUNGSART",',
'    allg_bel."BELEG",',
'    allg_bel.Verwendungszweck,',
'    allg_bel."SONSTIGES2",',
'    allg_bel."S7",',
'    allg_bel."S8",',
'    allg_bel."S9",',
'    allg_bel."S10",',
'    allg_bel.fk_bas_kal_arbeitstag,',
'    allg_bel.pk_imp_ba_allg_bel,',
'    allg_bel.fk_kto_buchung,',
'    arb.monat || '' '' || arb.jahr monat_jahr,',
'    arb.jahr,',
'    case when   allg_bel.pk_imp_ba_allg_bel = :P113_PK_IMP_BA_ALLG_BEL then 1 else 0 end abgl_bel,',
'    allg_bel.WERT,',
'    replace(replace(allg_bel."BEZEICHNUNG",chr(10),''''),chr(13),'''') bez',
'  from IMP_BA_ALLG_BEL  allg_bel',
'  left join t_bas_kal_arbeitstage  arb on allg_bel.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4501887667219636)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::P113_PK_IMP_BA_ALLG_BEL,P113_MONAT_JAHR,P113_DATUM,P113_BETRAG,P113_TEXT:#PK_IMP_BA_ALLG_BEL#,#MONAT_JAHR#,#DATUM#,#WERT#,#BEZ#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12371703632249017
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4502467777219638)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_html_expression=>'<a href=''f?p=&APP_ID.:118:&SESSION.::NO:RP:P118_PK_IMP_BA_ALLG_BEL:#PK_IMP_BA_ALLG_BEL#''>#BEZEICHNUNG#</a>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4502829551219639)
,p_db_column_name=>'LAND'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4503264821219639)
,p_db_column_name=>'S1'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'S1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4503648460219640)
,p_db_column_name=>'S2'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'S2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4504014724219641)
,p_db_column_name=>'BETRAG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4504876535219643)
,p_db_column_name=>'S4'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'S4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4505612704219644)
,p_db_column_name=>'S6'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'S6'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4506060538219645)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4506473687219646)
,p_db_column_name=>'DATUM'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4506790869219647)
,p_db_column_name=>'UHRZEIT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Uhrzeit'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4507255395219648)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4507598690219649)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4508042194219650)
,p_db_column_name=>'BELEG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4508857077219651)
,p_db_column_name=>'SONSTIGES2'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Sonstiges2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4509189990219652)
,p_db_column_name=>'S7'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'S7'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4509635724219653)
,p_db_column_name=>'S8'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'S8'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4510077854219654)
,p_db_column_name=>'S9'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'S9'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4510423208219654)
,p_db_column_name=>'S10'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'S10'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493587453976161)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>42
,p_column_identifier=>'X'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493828013976163)
,p_db_column_name=>'MONAT_JAHR'
,p_display_order=>62
,p_column_identifier=>'Z'
,p_column_label=>'Monat jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5494226561976167)
,p_db_column_name=>'ABGL_BEL'
,p_display_order=>72
,p_column_identifier=>'AA'
,p_column_label=>'Abgl bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5748782360244866)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>82
,p_column_identifier=>'AB'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5816711501015157)
,p_db_column_name=>'WERT'
,p_display_order=>92
,p_column_identifier=>'AC'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5817897088015169)
,p_db_column_name=>'BEZ'
,p_display_order=>102
,p_column_identifier=>'AD'
,p_column_label=>'Bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6373216805027344)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>122
,p_column_identifier=>'AF'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7372296692266124)
,p_db_column_name=>'JAHR'
,p_display_order=>132
,p_column_identifier=>'AG'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469420079491531)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>142
,p_column_identifier=>'AH'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469584448491532)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>152
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469648894491533)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>162
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4511308983220298)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123812'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'BEZEICHNUNG:PK_IMP_BA_ALLG_BEL:LAND:S1:S2:BETRAG:ZAHLUNGSART:S4:S6:STEUERNUMMER:DATUM:UHRZEIT:BELEGNUMMER:BELEG:SONSTIGES2:S7:S8:S9:S10:MONAT_ABGL_BEL:STEUERSATZ:WERT:BEZ:VERWENDUNGSZWECK:JAHR:WAEHRUNG:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG'
,p_sort_column_1=>'BEZEICHNUNG'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6075382573345328)
,p_report_id=>wwv_flow_api.id(4511308983220298)
,p_name=>'ausgew'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6076105283345329)
,p_report_id=>wwv_flow_api.id(4511308983220298)
,p_name=>'fk_buchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6075784007345328)
,p_report_id=>wwv_flow_api.id(4511308983220298)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6076493907345330)
,p_report_id=>wwv_flow_api.id(4511308983220298)
,p_name=>unistr('W\00E4hrung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'S3'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("S3" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>25
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5492162291976146)
,p_plug_name=>'Selected'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5816858226015158)
,p_plug_name=>'Girokonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:red"'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5441534009151049)
,p_plug_name=>'Girokonto'
,p_parent_plug_id=>wwv_flow_api.id(5816858226015158)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gir.*,',
' apex_item.checkbox2(1, gir.fk_main_key ) sel,',
' case when gir."Wertstellung" = to_date(:P113_Datum,''DD.MM.YYYY'') or gir."Buchungstag" = to_date(:P113_Datum,''DD.MM.YYYY'') then 1 else 0 end abgl_datum,',
' case when abs(round(gir."Betrag",0)) = :P113_Betrag then 1 else 0 end abgl_betrag,',
'  round(gir."Betrag",2) wert,',
'    round(gir."Betrag",0) wert_1,',
'    bel.pk_imp_ba_allg_bel,',
'    substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) next_month',
'',
'from t_KTO_Girokonto gir',
' left join t_bas_kal_arbeitstage arb on gir.fk_bas_kal_buchungstag = arb.pk_bas_kal_arbeitstage',
' left join imp_ba_allg_bel bel on bel.fk_kto_buchung  = gir.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
' or arb.monat   || '' '' || arb.jahr =   substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
' or arb.monat || '' '' || arb.jahr =   substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'',
' or   abs(round(gir."Betrag",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5441625865151050)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13311441830180431
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5441764547151051)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5441857998151052)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5441910807151053)
,p_db_column_name=>'Wertstellung'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5442071992151054)
,p_db_column_name=>'Umsatzart'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5442187646151056)
,p_db_column_name=>'Betrag'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5442826815151062)
,p_db_column_name=>'F12'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'F12'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5442948127151063)
,p_db_column_name=>'F13'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'F13'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5443017833151064)
,p_db_column_name=>'alt_ID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Alt id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5443420390151068)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5443492905151069)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5489766114976122)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493046650976155)
,p_db_column_name=>'SEL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493160001976156)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493252770976157)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5494170838976166)
,p_db_column_name=>'WERT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5494456868976169)
,p_db_column_name=>'WERT_1'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Wert 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5551141973648925)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5551409905648928)
,p_db_column_name=>'NEXT_MONTH'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Next month'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469799408491534)
,p_db_column_name=>'Buchungstext'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469887723491535)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50469900205491536)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470035296491537)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470107388491538)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470239466491539)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470303393491540)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470419640491541)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470531944491542)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470673945491543)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470700750491544)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470849453491545)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50470927980491546)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50471005045491547)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50471151398491548)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50471275669491549)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50471386590491550)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516220531574401)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516336919574402)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516474287574403)
,p_db_column_name=>'SALDO'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516535269574404)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516606035574405)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516763084574406)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516841466574407)
,p_db_column_name=>'FK_KON_EMPFAENGER'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Kon Empfaenger'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50516918216574408)
,p_db_column_name=>'BUCHUNGSTAG_DT'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Buchungstag Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517090629574409)
,p_db_column_name=>'WERTSTELLUNG_DT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Wertstellung Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517190052574410)
,p_db_column_name=>'BUCHUNGSTAG_VAR'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Buchungstag Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517211557574411)
,p_db_column_name=>'WERTSTELLUNG_VAR'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Wertstellung Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517326534574412)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517481079574413)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517552873574414)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517622261574415)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517745485574416)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517855883574417)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50517981272574418)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518074123574419)
,p_db_column_name=>'BEGUENSTIGTER'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Beguenstigter'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518198106574420)
,p_db_column_name=>'IBAN_ZUSATZ'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Iban Zusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518212477574421)
,p_db_column_name=>'BIC'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Bic'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518312133574422)
,p_db_column_name=>'MANDATSREFERENZ'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Mandatsreferenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518425615574423)
,p_db_column_name=>'GLAEUBIGER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Glaeubiger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518527617574424)
,p_db_column_name=>'FREMDGEBUEHREN'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fremdgebuehren'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518673503574425)
,p_db_column_name=>'ABWEICHENDEREMPFAENGER'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Abweichenderempfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518787245574426)
,p_db_column_name=>'ANZAHLAUFTRAEGE'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Anzahlauftraege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518803079574427)
,p_db_column_name=>'ANZAHLSCHECKS'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Anzahlschecks'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5516525452353913)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'133865'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'NEXT_MONTH:SEL:ID:WERT:FK_MAIN_KEY:Buchungstag:Wertstellung:Umsatzart:Betrag:Bankleitzahl IBAN Kategorie:F12:F13:alt_ID:Bemerkungen:BUCHUNGSTEXT:ABGL_DATUM:ABGL_BETRAG:WERT_1:PK_IMP_BA_ALLG_BEL::WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:KATEGORIE:FK_BAS_KAT_KA'
||'TEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_LOC_LOCATION:EMPFAENGER:SALDO:KONTONUMMER:AUFTRAGGEB'
||'ER:FK_KON_AUFTRAGGEBER:FK_KON_EMPFAENGER:BUCHUNGSTAG_DT:WERTSTELLUNG_DT:BUCHUNGSTAG_VAR:WERTSTELLUNG_VAR:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FLG_KREDITKARTENBUCHUNG:LOAD_DATE:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:BEGUENSTIGTER:IBAN_ZUSATZ:BIC'
||':MANDATSREFERENZ:GLAEUBIGER:FREMDGEBUEHREN:ABWEICHENDEREMPFAENGER:ANZAHLAUFTRAEGE:ANZAHLSCHECKS'
,p_break_on=>'Buchungstag'
,p_break_enabled_on=>'Buchungstag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6072430986256257)
,p_report_id=>wwv_flow_api.id(5516525452353913)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6072008376256257)
,p_report_id=>wwv_flow_api.id(5516525452353913)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6072811676256258)
,p_report_id=>wwv_flow_api.id(5516525452353913)
,p_name=>'bel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6073257670256258)
,p_report_id=>wwv_flow_api.id(5516525452353913)
,p_name=>'Row text contains ''MIetwagen'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'MIetwagen'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5816937631015159)
,p_plug_name=>'Kreditkarte'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:blue"'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5489805110976123)
,p_plug_name=>'Kreditkarte'
,p_parent_plug_id=>wwv_flow_api.id(5816937631015159)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
' kred.* , ',
' apex_item.checkbox2(2, kred.fk_main_key ) sel,',
' case when kred."Beleg" =  to_date(:P113_Datum,''DD.MM.YYYY'') or kred."Buchungstag" =  to_date(:P113_Datum,''DD.MM.YYYY'')   then 1 else 0 end abgl_datum,',
' case when abs(round(kred."Betrag",0)) = :P113_Betrag or abs(round(kred."Betrag Ursprung",0)) = :P113_Betrag  then 1 else 0 end abgl_betrag,',
' round(kred."Betrag",2) wert,',
'  round(kred."Betrag Ursprung",2) wert_urspr,',
'  bel.pk_imp_ba_allg_bel',
'from t_KTO_Kreditkarte kred',
' left join t_bas_kal_arbeitstage arb on kred.fk_bas_Kal_buchungstag = arb.pk_bas_kal_arbeitstage',
' left join imp_ba_allg_bel bel on bel.fk_kto_buchung = kred.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
'or arb.monat  || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or arb.monat || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or   abs(round(kred."Betrag",0)) = abs(:P113_Betrag) ',
'or   abs(round(kred."Betrag Ursprung",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5489908378976124)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP:P114_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13359724344005505
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490067668976125)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490138607976126)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490220414976127)
,p_db_column_name=>'Beleg'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490315179976128)
,p_db_column_name=>'Unternehmen'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490450701976129)
,p_db_column_name=>'Betrag'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490585918976131)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Betrag ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5490829637976133)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5491076441976135)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5491466136976139)
,p_db_column_name=>'Dummy'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5491501888976140)
,p_db_column_name=>'Referenz'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Referenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5491661876976141)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk main beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5491714056976142)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5492695337976152)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5492798154976153)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5492906387976154)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5493993386976165)
,p_db_column_name=>'WERT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5494354932976168)
,p_db_column_name=>'WERT_URSPR'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wert urspr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5551232636648926)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7130878452747736)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50518935641574428)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>290
,p_column_identifier=>'AD'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519058643574429)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519190516574430)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519278579574431)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519340218574432)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519433250574433)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519581530574434)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519644905574435)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519787988574436)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519863510574437)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50519916867574438)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520097156574439)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520143146574440)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520280171574441)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520304712574442)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520402957574443)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>440
,p_column_identifier=>'AS'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520554380574444)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>450
,p_column_identifier=>'AT'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520639428574445)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>460
,p_column_identifier=>'AU'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520706557574446)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>470
,p_column_identifier=>'AV'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5517319784353963)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'133872'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:ID:Buchungstag:WERT:WERT_URSPR:Beleg:Unternehmen:Betrag:Betrag Ursprung:Belastete Kreditkarte:FK_MAIN_KEY:Wertstellungsmonat:Dummy:Referenz:FK_MAIN_BELEG:ABGL_DATUM:ABGL_BETRAG:PK_IMP_BA_ALLG_BEL::BEMERKUNG:WAEHRUNG:WAEHRUNG_URSPRUNG:KATEGORIE:FK'
||'_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BEL_BELEG:FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BEMERKUNG:DATUM'
||'_LEX_BUCHUNG_OK:FK_EIN_AUS'
,p_break_on=>'Buchungstag'
,p_break_enabled_on=>'Buchungstag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6577194408041280)
,p_report_id=>wwv_flow_api.id(5517319784353963)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6576872432041279)
,p_report_id=>wwv_flow_api.id(5517319784353963)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6577644619041280)
,p_report_id=>wwv_flow_api.id(5517319784353963)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6578036036041281)
,p_report_id=>wwv_flow_api.id(5517319784353963)
,p_name=>'Row text contains ''store'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'store'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5816997319015160)
,p_plug_name=>'Paypal'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:green"'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5545679566625520)
,p_plug_name=>'Paypal'
,p_parent_plug_id=>wwv_flow_api.id(5816997319015160)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pay.*,',
' apex_item.checkbox2(3, pay.fk_main_key ) sel,',
' case when pay."Datum" = to_date(:P113_Datum,''DD.MM.YYYY'') then 1 else 0 end abgl_datum,',
' case when abs(round(pay."Brutto",0)) = :P113_Betrag then 1 else 0 end abgl_betrag,',
'  round(pay."Brutto",2) wert,',
'  bel.pk_imp_ba_allg_bel',
'from t_KTO_Paypal pay',
' left join t_bas_kal_arbeitstage arb on pay.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
'  left join imp_ba_allg_bel bel on bel.fk_kto_buchung = pay.fk_main_key',
'where arb.monat || '' '' || arb.jahr = :P113_Monat_jahr',
'or arb.monat  || '' '' || arb.jahr = substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) +1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
'or arb.monat  || '' '' || arb.jahr =  substr(:P113_Monat_jahr, 1,instr(:P113_Monat_jahr,'' '')) -1 || '' '' || substr(:P113_Monat_jahr, instr(:P113_Monat_jahr,'' '')+1, length(:P113_Monat_jahr) -(instr(:P113_Monat_jahr,'' ''))) ',
' or   abs(round(pay."Brutto",0)) = abs(:P113_Betrag) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5545733564625521)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13415549529654902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5545807801625522)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5545966563625523)
,p_db_column_name=>'Datum'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546082338625524)
,p_db_column_name=>'Uhrzeit'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546142885625525)
,p_db_column_name=>'Zeitzone'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Zeitzone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546238367625526)
,p_db_column_name=>'Name'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546358144625527)
,p_db_column_name=>'Typ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546459975625528)
,p_db_column_name=>'Status'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546625533625530)
,p_db_column_name=>'Brutto'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546800123625532)
,p_db_column_name=>'Netto'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5546888607625533)
,p_db_column_name=>'Absender_Email'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Absender email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547087414625535)
,p_db_column_name=>'Transaktionscode'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547194420625536)
,p_db_column_name=>'Lieferadresse'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Lieferadresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547347990625537)
,p_db_column_name=>'Adress-Status'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Adress-status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547414482625538)
,p_db_column_name=>'Artikelbezeichnung'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547497631625539)
,p_db_column_name=>'Artikelnummer'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Artikelnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547599810625540)
,p_db_column_name=>'Versand_Bearbeitungsgeb'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Versand bearbeitungsgeb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547741470625541)
,p_db_column_name=>'Versicherungsbetrag'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Versicherungsbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547877817625542)
,p_db_column_name=>'Umsatzsteuer'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5547926285625543)
,p_db_column_name=>'Option 1 Name'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Option 1 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548073243625544)
,p_db_column_name=>'Option 1 Wert'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Option 1 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548094976625545)
,p_db_column_name=>'Option 2 Name'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Option 2 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548214031625546)
,p_db_column_name=>'Option 2 Wert'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Option 2 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548426329625548)
,p_db_column_name=>'Rechnungsnummer'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548581720625549)
,p_db_column_name=>'Zollnummer'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Zollnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548590591625550)
,p_db_column_name=>'Anzahl'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Anzahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548738039625551)
,p_db_column_name=>'Empfangsnummer'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Empfangsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548966872625553)
,p_db_column_name=>'Adresszeile 1'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Adresszeile 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549003258625554)
,p_db_column_name=>'Adresszusatz'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Adresszusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549173692625555)
,p_db_column_name=>'Ort'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549248291625556)
,p_db_column_name=>'Bundesland'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Bundesland'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549326161625557)
,p_db_column_name=>'PLZ'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549406675625558)
,p_db_column_name=>'Land'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549548421625559)
,p_db_column_name=>'Telefon'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549584815625560)
,p_db_column_name=>'Betreff'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Betreff'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549725552625561)
,p_db_column_name=>'Hinweis'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Hinweis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549937428625563)
,p_db_column_name=>'Auswirkung_Guthaben'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Auswirkung guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550438384625568)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550588582648920)
,p_db_column_name=>'FK_ZUORD_ERL'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk zuord erl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550774966648921)
,p_db_column_name=>'SEL'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550840568648922)
,p_db_column_name=>'ABGL_DATUM'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Abgl datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550936145648923)
,p_db_column_name=>'ABGL_BETRAG'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Abgl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5550990635648924)
,p_db_column_name=>'WERT'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5551329038648927)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520885866574447)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50520903675574448)
,p_db_column_name=>'GEBUEHR'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Gebuehr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50521032505574449)
,p_db_column_name=>'EMPFAENGER_EMAIL'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Empfaenger Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50521103265574450)
,p_db_column_name=>'ZUGEHOERIGER_TRANSAKTIONSCODE'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Zugehoeriger Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571440356587301)
,p_db_column_name=>'Guthaben'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571514114587302)
,p_db_column_name=>'LAENDERVORWAHL'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Laendervorwahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571637912587303)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571724199587304)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571827566587305)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50571984511587306)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572070813587307)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572182460587308)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572208353587309)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572379904587310)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572436621587311)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572562329587312)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572674539587313)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572725172587314)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572869262587315)
,p_db_column_name=>'DUPL_BERMERKUNG'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Dupl Bermerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50572938648587316)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50573059710587317)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5572518867661084)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:ID:Datum:WERT:Uhrzeit:Zeitzone:Name:Typ:Status:Brutto:Netto:Absender_Email:Transaktionscode:Lieferadresse:Adress-Status:Artikelbezeichnung:Artikelnummer:Versand_Bearbeitungsgeb:Versicherungsbetrag:Umsatzsteuer:Option 1 Name:Option 1 Wert:Option 2'
||' Name:Option 2 Wert:Rechnungsnummer:Zollnummer:Anzahl:Empfangsnummer:Adresszeile 1:Adresszusatz:Ort:Bundesland:PLZ:Land:Telefon:Betreff:Hinweis:Auswirkung_FK_Kategorie:FK_MAIN_KEY:FK_ZUORD_ERL:ABGL_DATUM:ABGL_BETRAG:PK_IMP_BA_ALLG_BEL::WAEHRUNG:GEBUE'
||'HR:EMPFAENGER_EMAIL:ZUGEHOERIGER_TRANSAKTIONSCODE:LAENDERVORWAHL:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_KTO_VORGANG:FK_BAS_KAL_ARBEITSTAG:FK_BEL_BELEG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BANKKONTO:'
||'FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BERMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5593146351812985)
,p_report_id=>wwv_flow_api.id(5572518867661084)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_DATUM'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_DATUM" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5592780214812984)
,p_report_id=>wwv_flow_api.id(5572518867661084)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGL_BETRAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ABGL_BETRAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5593543317812985)
,p_report_id=>wwv_flow_api.id(5572518867661084)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_IMP_BA_ALLG_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>17
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5492566409976150)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(5492162291976146)
,p_button_name=>'Zuord'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zuord'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5493962032976164)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(5492162291976146)
,p_button_name=>'Zuord_rem'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Zuord rem'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4510841433219655)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(4501526836219635)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.:118'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5492243599976147)
,p_name=>'P113_PK_IMP_BA_ALLG_BEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5492162291976146)
,p_prompt=>'Pk imp ba allg bel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5492320447976148)
,p_name=>'P113_DATUM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5492162291976146)
,p_prompt=>'Datum'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5492401945976149)
,p_name=>'P113_BETRAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(5492162291976146)
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5493313401976158)
,p_name=>'P113_MONAT_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5492162291976146)
,p_prompt=>'Monat jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5817821058015168)
,p_name=>'P113_TEXT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(5492162291976146)
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5529294903257529)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f01.count loop',
'           if apex_application.g_f01(j) is not null then',
'           ',
' ',
'             update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f01(j) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f02.count loop',
'        if apex_application.g_f02(k) is not null then',
'        ',
'',
'              update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f02(k) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f03.count loop',
'           if apex_application.g_f03(j) is not null then',
'           ',
' ',
'             update IMP_BA_ALLG_BEL set fk_buchung =   apex_application.g_f03(j) where pk_imp_ba_allg_bel = :P113_PK_IMP_BA_allg_bel;',
'             commit;',
'',
'          end if;',
'         ',
'         end loop;',
'      ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5492566409976150)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5529623480260506)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen_rem'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'  ',
'    select count(*)',
'    into v_cnt',
'    from "KTO_Paypal"',
'    where id =:P171_SEL_ID;',
'    ',
'    select fk_main_key',
'    into v_fk_main_key',
'    from "KTO_Paypal"',
'    where id = :P171_SEL_ID;',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f02.count loop',
'           if apex_application.g_f02(j) is not null then',
'           ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 =  :P171_PK_IMP_BA_BEL and FK_KONTO_BUCH2 = apex_application.g_f02(j)',
'              ;',
'             commit;',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f03.count loop',
'        if apex_application.g_f03(k) is not null then',
'        ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 =  :P171_PK_IMP_BA_BEL and FK_KONTO_BUCH2 = apex_application.g_f03(k)',
'              ;',
'             commit;',
'           ',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'     --end if;',
'',
'',
'--  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5493962032976164)
);
wwv_flow_api.component_end;
end;
/
