prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>117
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Girokonto_modal'
,p_page_mode=>'MODAL'
,p_step_title=>'Girokonto_modal'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309514809704076)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619181253'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4201289275852725)
,p_plug_name=>'Girokonto_modal'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       "Buchungstag",',
'       "Wertstellung",',
'       "Umsatzart",',
'       "Buchungstext",',
'       "Betrag",',
'       Waehrung,',
'       "Auftraggeberkonto",',
'       "Bankleitzahl Auftraggeberkonto",',
'       IBAN_Auftraggeberkonto,',
'       Kategorie,',
'       F12,',
'       F13,',
'       "alt_ID",',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       FK_std_kto_Kontotyp,',
'       "Bemerkungen",',
'       FK_MAIN_KEY',
'  from t_KTO_Girokonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4201419135852725)
,p_name=>'Girokonto_modal'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>12071235100882106
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4202194420852738)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4202661551852739)
,p_db_column_name=>'Wertstellung'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4202987572852739)
,p_db_column_name=>'Umsatzart'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4206236895852742)
,p_db_column_name=>'F12'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'F12'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4206591896852742)
,p_db_column_name=>'F13'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'F13'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4206993973852743)
,p_db_column_name=>'alt_ID'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Alt Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4208587813852744)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4209082522852744)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50735750423763437)
,p_db_column_name=>'ID'
,p_display_order=>29
,p_column_identifier=>'T'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50735854506763438)
,p_db_column_name=>'Buchungstext'
,p_display_order=>39
,p_column_identifier=>'U'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50735919294763439)
,p_db_column_name=>'Betrag'
,p_display_order=>49
,p_column_identifier=>'V'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736046885763440)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>59
,p_column_identifier=>'W'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736133566763441)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>69
,p_column_identifier=>'X'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736251546763442)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>79
,p_column_identifier=>'Y'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736305630763443)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>89
,p_column_identifier=>'Z'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736493875763444)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>99
,p_column_identifier=>'AA'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736574825763445)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>109
,p_column_identifier=>'AB'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736620812763446)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>119
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50736702043763447)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>129
,p_column_identifier=>'AD'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4209742837865696)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120796'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MAIN_KEY:Buchungstag:Wertstellung:Umsatzart:Bankleitzahl IBAN Kategorie:F12:F13:alt_FK_Kategorie:Bemerkungen::WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4217255263050982)
,p_report_id=>wwv_flow_api.id(4209742837865696)
,p_name=>'Row text contains ''Steuer'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Steuer'
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
