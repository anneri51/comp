prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>120
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Vorsteuer'
,p_alias=>'VORSTEUER'
,p_step_title=>'Vorsteuer'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200716173930'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1333207123938743)
,p_plug_name=>'Vorsteuer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ll.*,  abziehbare_vorsteuerbetr,sendedatum, vor.meldemonat, vor.transaktionsnummer, vor1.sendedatum1, vor1.anzahl_belege, vor1.abziehbare_vorsteuerbetr1, steuerpflichtige_umsaetze, UMSATZSTVORAUSZLG_UEBERSCHUSS, UMSATZSTVORAUSZLG_UEBERSCHUSS1',
'--anzahl_belege, ',
'from (',
'select sum(betrag) betrag, sum(case when habenkto= 4400 then habeneur else 0 end) einnahmen_netto, sum(case when habenkto= 4400 then betrag else 0 end) einnahmen_brutto, ',
'sum(case when habenkto= 4400 then 1 else 0 end) anzahl_rechnungen, sum(case when ust_kto = 3806 then -Ust_eur else Ust_eur end) Umsatzsteuer, Ust_kto Umsatzsteuer_kto, max(UST_PROZ) proz,  periode, jahr',
', sum(case when ll.status is  null then betrag else 0 end  ) sum_betrag_valid',
'   , sum(case when ll.status is not null then betrag else 0 end) sum_betrag_storno',
'    , sum(case when ll.status is null then ust_eur else 0 end) sum_ust_eur_valid',
'   , sum(case when ll.status is not null then ust_eur else 0 end ) sum_ust_eur_storno',
'    , fk_steu_steuer_voranmldg',
' , sum_steuer_voranmldg',
'    , sum(ust_s_eur) sum_ust_s_eur',
'    , sum(ust_h_eur) sum_ust_h_eur',
'    , nvl(sum(ust_s_eur),0) - nvl(sum(ust_h_eur),0) diff_ust_s_h',
'from (',
'      select ll.*, ',
'           nvl(sum(ust_S_EUR ) over (partition by fk_steu_steuer_voranmldg order by  fk_steu_steuer_voranmldg  ),0) -nvl(sum(ust_H_EUR ) over (partition by fk_steu_steuer_voranmldg order by  fk_steu_steuer_voranmldg  ),0)',
'          sum_steuer_voranmldg ',
'      from t_lex_long ll  ) ll',
'   ',
'',
'--where status is  null ',
'group by ll.Ust_kto, ll.periode, ll.jahr, fk_steu_steuer_voranmldg, sum_steuer_voranmldg) ll',
'  left join (',
'              select meldemonat, abziehbare_vorsteuerbetr,  sendedatum, pk_steu_steuer_voranmldg,  transaktionsnummer, UMSATZSTVORAUSZLG_UEBERSCHUSS',
'                 -- count(*) anzahl_belege, max(sendedatum) sendedatum ',
'                  from  t_steu_steuer_voranmldg ',
'               -- group by meldemonat',
'          ) vor on  ll.fk_steu_steuer_voranmldg = vor.pk_steu_steuer_voranmldg',
'    left join (',
'              select substr(meldemonat,4,2) monat, substr(meldemonat,7,4) jahr,sum(abziehbare_vorsteuerbetr) abziehbare_vorsteuerbetr1 ,sum(STEUERPFL_UMSAETZE) steuerpflichtige_umsaetze,sum(UMSATZSTVORAUSZLG_UEBERSCHUSS) UMSATZSTVORAUSZLG_UEBERSCHUSS'
||'1,',
'                 count(*) anzahl_belege, max(sendedatum) sendedatum1 ',
'                  from  t_steu_steuer_voranmldg ',
'                group by meldemonat, substr(meldemonat,7,4), substr(meldemonat,4,2)',
'          ) vor1 on  ll.periode = to_number(vor1.monat) and ll.jahr = vor1.jahr',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Vorsteuer'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1333317811938743)
,p_name=>'Vorsteuer'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.::P253_JAHR,P253_MONAT:#JAHR#,#PERIODE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>5948736817137378
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1333777425938750)
,p_db_column_name=>'BETRAG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1334164692938757)
,p_db_column_name=>'EINNAHMEN_NETTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Einnahmen Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1334573398938757)
,p_db_column_name=>'EINNAHMEN_BRUTTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Einnahmen Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1334919663938757)
,p_db_column_name=>'ANZAHL_RECHNUNGEN'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Anzahl Rechnungen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1335348479938758)
,p_db_column_name=>'UMSATZSTEUER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1336098605938758)
,p_db_column_name=>'PROZ'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1336554888938758)
,p_db_column_name=>'PERIODE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1336897576938759)
,p_db_column_name=>'JAHR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1337301297938759)
,p_db_column_name=>'ABZIEHBARE_VORSTEUERBETR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Abziehbare Vorsteuerbetr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1338106039938759)
,p_db_column_name=>'SENDEDATUM'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Sendedatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690317170069219)
,p_db_column_name=>'UMSATZSTEUER_KTO'
,p_display_order=>22
,p_column_identifier=>'M'
,p_column_label=>'Umsatzsteuer Kto'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.::P253_JAHR,P253_MONAT,P253_UST_KTO:#JAHR#,#PERIODE#,#UMSATZSTEUER_KTO#'
,p_column_linktext=>'#UMSATZSTEUER_KTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690171361069218)
,p_db_column_name=>'SUM_BETRAG_VALID'
,p_display_order=>32
,p_column_identifier=>'N'
,p_column_label=>'Sum Betrag Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690106143069217)
,p_db_column_name=>'SUM_BETRAG_STORNO'
,p_display_order=>42
,p_column_identifier=>'O'
,p_column_label=>'Sum Betrag Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689965701069216)
,p_db_column_name=>'SUM_UST_EUR_VALID'
,p_display_order=>52
,p_column_identifier=>'P'
,p_column_label=>'Sum Ust Eur Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689885437069215)
,p_db_column_name=>'SUM_UST_EUR_STORNO'
,p_display_order=>62
,p_column_identifier=>'Q'
,p_column_label=>'Sum Ust Eur Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689818305069214)
,p_db_column_name=>'FK_STEU_STEUER_VORANMLDG'
,p_display_order=>72
,p_column_identifier=>'R'
,p_column_label=>'Fk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689658415069213)
,p_db_column_name=>'MELDEMONAT'
,p_display_order=>82
,p_column_identifier=>'S'
,p_column_label=>'Meldemonat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689578325069212)
,p_db_column_name=>'TRANSAKTIONSNUMMER'
,p_display_order=>92
,p_column_identifier=>'T'
,p_column_label=>'Transaktionsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689423280069211)
,p_db_column_name=>'SUM_STEUER_VORANMLDG'
,p_display_order=>102
,p_column_identifier=>'U'
,p_column_label=>'Sum Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689201957069208)
,p_db_column_name=>'SENDEDATUM1'
,p_display_order=>112
,p_column_identifier=>'V'
,p_column_label=>'Sendedatum1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689023843069207)
,p_db_column_name=>'ANZAHL_BELEGE'
,p_display_order=>122
,p_column_identifier=>'W'
,p_column_label=>'Anzahl Belege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688975897069206)
,p_db_column_name=>'ABZIEHBARE_VORSTEUERBETR1'
,p_display_order=>132
,p_column_identifier=>'X'
,p_column_label=>'Abziehbare Vorsteuerbetr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688830645069205)
,p_db_column_name=>'STEUERPFLICHTIGE_UMSAETZE'
,p_display_order=>142
,p_column_identifier=>'Y'
,p_column_label=>'Steuerpflichtige Umsaetze'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688803404069204)
,p_db_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_display_order=>152
,p_column_identifier=>'Z'
,p_column_label=>'Umsatzstvorauszlg Ueberschuss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688663358069203)
,p_db_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS1'
,p_display_order=>162
,p_column_identifier=>'AA'
,p_column_label=>'Umsatzstvorauszlg Ueberschuss1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688529730069202)
,p_db_column_name=>'SUM_UST_S_EUR'
,p_display_order=>172
,p_column_identifier=>'AB'
,p_column_label=>'Sum Ust S Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688433706069201)
,p_db_column_name=>'SUM_UST_H_EUR'
,p_display_order=>182
,p_column_identifier=>'AC'
,p_column_label=>'Sum Ust H Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(688345488069200)
,p_db_column_name=>'DIFF_UST_S_H'
,p_display_order=>192
,p_column_identifier=>'AD'
,p_column_label=>'Diff Ust S H'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1338765707942134)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'59542'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:PERIODE:BETRAG:EINNAHMEN_NETTO:EINNAHMEN_BRUTTO:ANZAHL_RECHNUNGEN:ABZIEHBARE_VORSTEUERBETR:UMSATZSTEUER:PROZ:SENDEDATUM::UMSATZSTEUER_KTO:SUM_BETRAG_VALID:SUM_BETRAG_STORNO:SUM_UST_EUR_VALID:SUM_UST_EUR_STORNO:FK_STEU_STEUER_VORANMLDG:MELDEMONAT'
||':TRANSAKTIONSNUMMER:SUM_STEUER_VORANMLDG:SENDEDATUM1:ANZAHL_BELEGE:ABZIEHBARE_VORSTEUERBETR1:STEUERPFLICHTIGE_UMSAETZE:UMSATZSTVORAUSZLG_UEBERSCHUSS:UMSATZSTVORAUSZLG_UEBERSCHUSS1:SUM_UST_S_EUR:SUM_UST_H_EUR:DIFF_UST_S_H'
,p_break_on=>'JAHR:PERIODE'
,p_break_enabled_on=>'JAHR:PERIODE'
,p_sum_columns_on_break=>'ABZIEHBARE_VORSTEUERBETR:UMSATZSTEUER:SUM_UST_EUR_VALID:SUM_UST_EUR_STORNO:EINNAHMEN_BRUTTO:SUM_UST_S_EUR:SUM_UST_H_EUR:DIFF_UST_S_H'
,p_max_columns_on_break=>'ABZIEHBARE_VORSTEUERBETR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1513857956320860)
,p_report_id=>wwv_flow_api.id(1338765707942134)
,p_name=>'sum_voranmeldung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SUM_STEUER_VORANMLDG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SUM_STEUER_VORANMLDG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1514263371320860)
,p_report_id=>wwv_flow_api.id(1338765707942134)
,p_name=>'umssteuerzahlung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("UMSATZSTVORAUSZLG_UEBERSCHUSS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1513383537320860)
,p_report_id=>wwv_flow_api.id(1338765707942134)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
