prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>121
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Vertrag_Finanzierung'
,p_step_title=>'Vertrag_Finanzierung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44326124317819076)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200619185154'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4428979132248165)
,p_plug_name=>'Positionen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pos.*, "Buchungstag", "Betrag", fk_lex_relation, sum_betrag',
'from "T_VER_VERTRAG_AUDI_FIN_POS" pos',
' left join v_kto_konten_zus zus on pos.fk_kto_buchung = zus.fk_main_key',
' left join t_rel_lex_kto_bel rellex on rellex.fk_main_key = pos.fk_kto_buchung',
' left join (select sum(betrag) sum_betrag, relation from t_lex_long group by relation) lex on lex.relation = rellex.fk_lex_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4429133939248167)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:173:&SESSION.::&DEBUG.:RP:P173_PK_AUDI_FIN_VERTRAG_POS:#PK_AUDI_FIN_VERTRAG_POS#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>12298949904277548
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4429265773248168)
,p_db_column_name=>'RATE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Rate'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4560059062258121)
,p_db_column_name=>'ZINSANTEIL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Zinsanteil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4560135079258122)
,p_db_column_name=>'TILGUNGSANTEIL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tilgungsanteil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4560207771258123)
,p_db_column_name=>'RKG_ANTEILIG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Rkg anteilig'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9416069200353838)
,p_db_column_name=>'Buchungstag'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9416181635353839)
,p_db_column_name=>'Betrag'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11787492777700104)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sum Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809430326922118)
,p_db_column_name=>'FAELLIGKEIT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Faelligkeit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809535301922119)
,p_db_column_name=>'RATENHOEHE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ratenhoehe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809635560922120)
,p_db_column_name=>'PK_VER_VERTRAG_AUDI_FIN_POS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Pk Ver Vertrag Audi Fin Pos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809793619922121)
,p_db_column_name=>'FK_VER_VERTRAG_AUDI_FIN'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Ver Vertrag Audi Fin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809872031922122)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50809902850922123)
,p_db_column_name=>'FK_STD_POS_TYPE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Std Pos Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50810072459922124)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4567565495258412)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124374'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'RATE:ZINSANTEIL:TILGUNGSANTEIL:RKG_ANTEILIG:Buchungstag:Betrag:SUM_BETRAG:FAELLIGKEIT:RATENHOEHE:PK_VER_VERTRAG_AUDI_FIN_POS:FK_VER_VERTRAG_AUDI_FIN:FK_KTO_BUCHUNG:FK_STD_POS_TYPE:FK_LEX_RELATION'
,p_sort_column_1=>'RATE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>unistr('F\0160LLIGKEIT')
,p_sort_direction_2=>'ASC'
,p_sum_columns_on_break=>'TILGUNGSANTEIL:Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10910538320658667)
,p_report_id=>wwv_flow_api.id(4567565495258412)
,p_name=>'gezahlt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4555039551247457)
,p_plug_name=>'Vertrag'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from "#OWNER#"."T_VER_VERTRAG_AUDI_FIN_HAUPT_MERK" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4555411340247457)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:122:&APP_SESSION.::::P122_ROWID:#ROWID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12425227305276838
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552364896648937)
,p_db_column_name=>'HAUPT_MERKMAL1'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'Haupt merkmal1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552476574648938)
,p_db_column_name=>'HAUPT_MERKMAL1_WERT'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'Haupt merkmal1 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552581423648939)
,p_db_column_name=>'HAUPT_MERKMAL2'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Haupt merkmal2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552642120648940)
,p_db_column_name=>'HAUPT_MERKMAL2_WERT'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Haupt merkmal2 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552685573648941)
,p_db_column_name=>'HAUPT_MERKMAL3'
,p_display_order=>50
,p_column_identifier=>'L'
,p_column_label=>'Haupt merkmal3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552869130648942)
,p_db_column_name=>'HAUPT_MERKMAL3_WERT'
,p_display_order=>60
,p_column_identifier=>'M'
,p_column_label=>'Haupt merkmal3 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5552933966648943)
,p_db_column_name=>'PK_AUDI_FIN_VERTRAG_HAUPT_MERK'
,p_display_order=>70
,p_column_identifier=>'N'
,p_column_label=>'Pk audi fin vertrag haupt merk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5553016889648944)
,p_db_column_name=>'FK_FIN_VERTRAG'
,p_display_order=>80
,p_column_identifier=>'O'
,p_column_label=>'Fk fin vertrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4558836639247912)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124287'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HAUPT_MERKMAL1:HAUPT_MERKMAL1_WERT:HAUPT_MERKMAL2:HAUPT_MERKMAL2_WERT:HAUPT_MERKMAL3:HAUPT_MERKMAL3_WERT:PK_AUDI_FIN_VERTRAG_HAUPT_MERK:FK_FIN_VERTRAG'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4558356888247465)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(4555039551247457)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122'
);
wwv_flow_api.component_end;
end;
/
