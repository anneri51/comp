prompt --application/pages/page_00155
begin
--   Manifest
--     PAGE: 00155
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>155
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Tankstelle'
,p_step_title=>'Tankstelle'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44326124317819076)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200620043605'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4984461308392954)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tank."TANKSTELLE",',
'tank."ORT" tank_ort,',
'tank."LAND" tank_land,',
'tank."TANKSTELLEN_NR",',
'tank."BELEG_NR",',
'tank."DATUM",',
'tank."ZAPFSAEULE",',
'tank."LITER",',
'tank."PREIS_PRO_LITER",',
'case when tank."EUR" is not null then to_number(trim(tank."EUR")) else 0 end  "EUR",',
'tank."KARTENZAHLUNG",',
'tank."MWST",',
'tank."MWST_BETRAG",',
'tank."NETTO",',
'tank."STEUERNR",',
'tank."BEMERKUNGEN",',
'tank."VERWENDUNGSZWECK",',
'tank."KENNZEICHEN",',
'tank."BEMERKUNGEN2",',
'tank.PK_IMP_BA_Tankstelle,',
'tank.fk_kto_buchung,',
'tank.fk_bas_kal_arbeitstag,',
'tank.preis_pro_menge,',
'tank.waehrung,',
'tank.fk_imp_ba_bel,',
'apex_item.checkbox(1,tank.pk_imp_ba_tankstelle) sel,',
'tank.checked,',
'tank.wert,',
'arb.jahr,',
'arb.monat,',
'arb.tag,',
'loc.*,',
'fk_bel_beleg_ablage',
'from "IMP_BA_TANKSTELLE" tank',
' left join t_bas_kal_arbeitstage arb on tank.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
' left join v_loc_location loc on loc.pk_loc_location = tank.fk_loc_location',
'',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4984881740392955)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:156:&SESSION.::&DEBUG.::P156_PK_IMP_BA_TANKSTELLE:#PK_IMP_BA_TANKSTELLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12854697705422336
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4985316596392957)
,p_db_column_name=>'TANKSTELLE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Tankstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4985755318392958)
,p_db_column_name=>'ORT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4986149673392959)
,p_db_column_name=>'LAND'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4986486070392960)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4986893670392960)
,p_db_column_name=>'BELEG_NR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Beleg Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4987347392392961)
,p_db_column_name=>'DATUM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4988173229392963)
,p_db_column_name=>'LITER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Liter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4988531430392963)
,p_db_column_name=>'PREIS_PRO_LITER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Preis Pro Liter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4989307399392965)
,p_db_column_name=>'KARTENZAHLUNG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Kartenzahlung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4989741198392966)
,p_db_column_name=>'MWST'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4990116555392966)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4990568848392967)
,p_db_column_name=>'NETTO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4990929995392968)
,p_db_column_name=>'STEUERNR'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Steuernr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4991317196392969)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4991686103392969)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4992171557392970)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4992494696392971)
,p_db_column_name=>'BEMERKUNGEN2'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Bemerkungen2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5813123955015121)
,p_db_column_name=>'PK_IMP_BA_TANKSTELLE'
,p_display_order=>30
,p_column_identifier=>'U'
,p_column_label=>'Pk imp ba tankstelle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5813414650015124)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>60
,p_column_identifier=>'X'
,p_column_label=>'Preis pro menge'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5813682579015126)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5814987537015140)
,p_db_column_name=>'SEL'
,p_display_order=>90
,p_column_identifier=>'AA'
,p_column_label=>'Sel  <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5815305597015143)
,p_db_column_name=>'CHECKED'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Checked'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5815879608015148)
,p_db_column_name=>'EUR'
,p_display_order=>110
,p_column_identifier=>'AE'
,p_column_label=>'Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5815903704015149)
,p_db_column_name=>'WERT'
,p_display_order=>120
,p_column_identifier=>'AF'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7372052172266121)
,p_db_column_name=>'JAHR'
,p_display_order=>130
,p_column_identifier=>'AG'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7372139306266122)
,p_db_column_name=>'MONAT'
,p_display_order=>140
,p_column_identifier=>'AH'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7372227330266123)
,p_db_column_name=>'TAG'
,p_display_order=>150
,p_column_identifier=>'AI'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9383731520854655)
,p_db_column_name=>'TANK_ORT'
,p_display_order=>160
,p_column_identifier=>'AJ'
,p_column_label=>'Tank ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9383858610854656)
,p_db_column_name=>'TANK_LAND'
,p_display_order=>170
,p_column_identifier=>'AK'
,p_column_label=>'Tank land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384058351854658)
,p_db_column_name=>'LOCATION'
,p_display_order=>190
,p_column_identifier=>'AM'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384293574854661)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>220
,p_column_identifier=>'AP'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384384701854662)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>230
,p_column_identifier=>'AQ'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384521913854663)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>240
,p_column_identifier=>'AR'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384658557854664)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>250
,p_column_identifier=>'AS'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384782264854665)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>260
,p_column_identifier=>'AT'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384785306854666)
,p_db_column_name=>'STRASSE'
,p_display_order=>270
,p_column_identifier=>'AU'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9384930387854667)
,p_db_column_name=>'HSNR'
,p_display_order=>280
,p_column_identifier=>'AV'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9385005551854668)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>290
,p_column_identifier=>'AW'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9385181235854669)
,p_db_column_name=>'COMM'
,p_display_order=>300
,p_column_identifier=>'AX'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9559590442312220)
,p_db_column_name=>'POSTFACH'
,p_display_order=>310
,p_column_identifier=>'AY'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9559701273312221)
,p_db_column_name=>'PLZ'
,p_display_order=>320
,p_column_identifier=>'AZ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13037576466408052)
,p_db_column_name=>'ADR'
,p_display_order=>330
,p_column_identifier=>'BA'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078359927587202)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>340
,p_column_identifier=>'BC'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078425899587203)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>350
,p_column_identifier=>'BD'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078586804587204)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>360
,p_column_identifier=>'BE'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078657643587205)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>370
,p_column_identifier=>'BF'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078709624587206)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>380
,p_column_identifier=>'BG'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078894751587207)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>390
,p_column_identifier=>'BH'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51078914937587208)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>400
,p_column_identifier=>'BI'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51079045194587209)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>410
,p_column_identifier=>'BJ'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51079191106587210)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>420
,p_column_identifier=>'BK'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51079214617587211)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>430
,p_column_identifier=>'BL'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51079325930587212)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>440
,p_column_identifier=>'BM'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51079490435587213)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>450
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4993481892393428)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'128633'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL::CHECKED:WERT'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR:ZAPFSAEULE:FK_KTO_BUCHUNG:FK_BAS_KAL_ARBEITSTAG:WAEHRUNG:PK_LOC_LOCATION:FK_BAS_LOC_'
||'LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE:FK_BEL_BELEG_ABLAGE'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE'
,p_break_enabled_on=>'TANKSTELLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5942827738159648)
,p_report_id=>wwv_flow_api.id(4993481892393428)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5943216522159649)
,p_report_id=>wwv_flow_api.id(4993481892393428)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("EUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5943593931159649)
,p_report_id=>wwv_flow_api.id(4993481892393428)
,p_name=>'Row text contains ''shell'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'shell'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5943985045163741)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'datum'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'138139'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7389865471439169)
,p_report_id=>wwv_flow_api.id(5943985045163741)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7390188252439170)
,p_report_id=>wwv_flow_api.id(5943985045163741)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7389005264439165)
,p_report_id=>wwv_flow_api.id(5943985045163741)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7389462807439167)
,p_report_id=>wwv_flow_api.id(5943985045163741)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(7390627250439183)
,p_report_id=>wwv_flow_api.id(5943985045163741)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'KARTENZAHLUNG'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(7390995796439184)
,p_pivot_id=>wwv_flow_api.id(7390627250439183)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'WERT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5945035469167174)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'tankstelle'
,p_report_seq=>10
,p_report_alias=>'138149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE'
,p_break_enabled_on=>'TANKSTELLE'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5988042380564626)
,p_report_id=>wwv_flow_api.id(5945035469167174)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5988442584564628)
,p_report_id=>wwv_flow_api.id(5945035469167174)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5988864783564629)
,p_report_id=>wwv_flow_api.id(5945035469167174)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5956029041270355)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'tankstelle_checked'
,p_report_seq=>10
,p_report_alias=>'138259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:WERT:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'CHECKED:0:0:0:0'
,p_break_enabled_on=>'CHECKED:0:0:0:0'
,p_sum_columns_on_break=>'WERT'
,p_count_columns_on_break=>'TANKSTELLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5991589527666457)
,p_report_id=>wwv_flow_api.id(5956029041270355)
,p_name=>'checked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5992002527666458)
,p_report_id=>wwv_flow_api.id(5956029041270355)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5992471319666458)
,p_report_id=>wwv_flow_api.id(5956029041270355)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5991204698666457)
,p_report_id=>wwv_flow_api.id(5956029041270355)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"CHECKED" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7391659312502545)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'pivot'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'152615'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7392815174502549)
,p_report_id=>wwv_flow_api.id(7391659312502545)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7393184664502549)
,p_report_id=>wwv_flow_api.id(7391659312502545)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7392048023502548)
,p_report_id=>wwv_flow_api.id(7391659312502545)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7392472134502548)
,p_report_id=>wwv_flow_api.id(7391659312502545)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(7393587074502550)
,p_report_id=>wwv_flow_api.id(7391659312502545)
,p_pivot_columns=>'JAHR'
,p_row_columns=>unistr('KARTENZAHLUNG:W\00C4HRUNG')
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(7394066914502551)
,p_pivot_id=>wwv_flow_api.id(7393587074502550)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'WERT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7396398183592944)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'erledigt'
,p_report_seq=>10
,p_report_alias=>'152663'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE:JAHR:PK_LOCATION'
,p_break_enabled_on=>'PK_LOCATION'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9606307604549603)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9606775944549603)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9607171895549604)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9607541995549604)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9605103209549601)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9605577129549602)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9605981283549603)
,p_report_id=>wwv_flow_api.id(7396398183592944)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'LOCATION'
,p_operator=>'='
,p_expr=>'Tankstelle - Schwarzenberg Q1'
,p_condition_sql=>'"LOCATION" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Tankstelle - Schwarzenberg Q1''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9607955618553737)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Location'
,p_report_seq=>10
,p_report_alias=>'174778'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE:JAHR:PK_LOCATION:LOCATION'
,p_break_enabled_on=>'PK_LOCATION:LOCATION'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9616732623574271)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9617120081574271)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9617573030574271)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9617962385574272)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9615507887574269)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9615906633574270)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9616337097574270)
,p_report_id=>wwv_flow_api.id(9607955618553737)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PK_LOCATION'
,p_operator=>'is null'
,p_condition_sql=>'"PK_LOCATION" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9559955807312223)
,p_plug_name=>'Bearbeitung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9562278914312246)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9559955807312223)
,p_button_name=>'Open_Location'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Open location'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9559859029312222)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(9559955807312223)
,p_button_name=>'ADD_Location'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add location'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4992893443392971)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(4984461308392954)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:156:&SESSION.::&DEBUG.:156'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5815113272015141)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(4984461308392954)
,p_button_name=>'checked'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Checked'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9560125034312225)
,p_name=>'P155_FK_LOCATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(9559955807312223)
,p_prompt=>'Fk location'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'LOCATION || '' '' ||',
'LOCATION_TYPE  || '' '' ||',
'',
'STRASSE  || '' '' ||',
'HSNR  || '' '' ||',
'POSTFACH  || '' '' ||',
'PLZ  || '' '' ||',
'ORT  || '' '' ||',
'LAND  || '' '' ||',
'',
'',
'',
'BESCHREIBUNG  || '' '' ||',
'COMM',
'',
'',
'',
', pk_location',
'',
'from v_location'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5815215815015142)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'checked'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      update IMP_BA_TANKSTELLE set checked = 1 where pk_imp_ba_tankstelle = apex_application.g_f01(i);',
'      commit;',
'    ',
'    end if;',
'  ',
'  end loop;',
'end;',
'  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5815113272015141)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9560207459312226)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_Locaiton'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      update IMP_BA_TANKSTELLE set fk_location = :P155_FK_LOCATION where pk_imp_ba_tankstelle = apex_application.g_f01(i);',
'      commit;',
'    ',
'    end if;',
'  ',
'  end loop;',
'end;',
'  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9559859029312222)
);
wwv_flow_api.component_end;
end;
/
