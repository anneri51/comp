prompt --application/pages/page_00175
begin
--   Manifest
--     PAGE: 00175
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>175
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Employees'
,p_step_title=>'Employees'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42896149436500086)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524083801'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6130959972614578)
,p_plug_name=>'doREST'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(6132864400614603)
,p_name=>'Results'
,p_template=>wwv_flow_api.id(6232786070135999)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c001 "Employees Id"',
' from apex_collections ',
'where collection_name = ''P175_DOREST_RESULTS'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(6242748845136006)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6133392692614642)
,p_query_column_id=>1
,p_column_alias=>'Employees Id'
,p_column_display_sequence=>1
,p_column_heading=>'Employees Id'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6131328917614589)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6130959972614578)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Submit'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(6131710307614594)
,p_branch_action=>'f?p=&APP_ID.:175:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6132105473614596)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WEB_SERVICE'
,p_process_name=>'Web Service Request'
,p_attribute_01=>wwv_flow_api.id(6127940682576328)
,p_attribute_02=>'COLLECTION'
,p_attribute_03=>'P175_DOREST_RESULTS'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
