prompt --application/pages/page_00180
begin
--   Manifest
--     PAGE: 00180
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>180
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'V_Belege_Zus'
,p_step_title=>'V_Belege_Zus'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44315674703751187)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200621112512'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7601583768513931)
,p_plug_name=>'V_Belege_Zus'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  bel.ART, ',
'        bel.FK_IMP_BA_BEL,',
'        bel.PK_IMP_BA_ALLG_BEL,',
'        bel.BEZEICHNUNG,',
'        bel.KENNZEICHEN,',
'        bel.DATUM,',
'        bel.DATUM_VERGEHEN,',
'        bel.FK_bas_kal_ARBEITSTAG,',
'        bel.FK_kto_BUCHUNG,',
'        bel.BETRAG,',
'        bel.waehrung_betrag,',
'        bel.WaEHRUNG,',
'        bel.STEUERSATZ,',
'        bel.MWST_BETRAG,',
'        bel.NETTO,',
'        bel.ZAHLUNGSART,',
'        bel.fk_inv_inventar,',
'        bel.fk_proj_projekt,',
'        inv.pk_inv_inventar,',
'        inv.inventar,',
'        inv.anschaffungsjahr,',
'        inv.abgangsjahr,',
'        pr.pk_proj_projekt,',
'        pr.projekt,',
'        pr.von,',
'        pr.bis,',
'        bel.fk_bel_beleg_ablage',
'from V_IMP_BEL_ZUS bel',
'   left join t_proj_projekt pr on bel.fk_proj_projekt = pr.pk_proj_projekt',
'   left join t_inv_inventare inv on bel.fk_inv_inventar = inv.pk_Inv_inventar'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7601614508513931)
,p_name=>'V_Belege_Zus'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15471430473543312
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7602054833513941)
,p_db_column_name=>'ART'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Art'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7602384974513943)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7602883906513943)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7603252642513943)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7603606329513944)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7604002432513944)
,p_db_column_name=>'DATUM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7604411754513944)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8168467601548249)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8168541943548250)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>58
,p_column_identifier=>'M'
,p_column_label=>'Mwst betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8168639442548251)
,p_db_column_name=>'NETTO'
,p_display_order=>68
,p_column_identifier=>'N'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8168697588548252)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>78
,p_column_identifier=>'O'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325692906937264)
,p_db_column_name=>'INVENTAR'
,p_display_order=>118
,p_column_identifier=>'S'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325839935937265)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>128
,p_column_identifier=>'T'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325948415937266)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>138
,p_column_identifier=>'U'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9326180879937268)
,p_db_column_name=>'PROJEKT'
,p_display_order=>158
,p_column_identifier=>'W'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9326207706937269)
,p_db_column_name=>'VON'
,p_display_order=>168
,p_column_identifier=>'X'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9380236614854620)
,p_db_column_name=>'BIS'
,p_display_order=>178
,p_column_identifier=>'Y'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12825892333042864)
,p_db_column_name=>'BETRAG'
,p_display_order=>208
,p_column_identifier=>'AJ'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51548647431653705)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>218
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51548754144653706)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>228
,p_column_identifier=>'AM'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51548827224653707)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>238
,p_column_identifier=>'AN'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51548900547653708)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>248
,p_column_identifier=>'AO'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51549084925653709)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>258
,p_column_identifier=>'AP'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51549148573653710)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>268
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51549256698653711)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>278
,p_column_identifier=>'AR'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51549341629653712)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>288
,p_column_identifier=>'AS'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51549405964653713)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>298
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7605426284516613)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'154753'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ART:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BEZEICHNUNG:KENNZEICHEN:DATUM:DATUM_VERGEHEN:STEUERSATZ:ZAHLUNGSART:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PROJEKT:VON:BIS:MWST_NETTO:W\00C4HRUNG_:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG_BETRAG:WAEHRUNG:FK_INV_INVENTAR:FK')
||'_PROJ_PROJEKT:PK_INV_INVENTAR:PK_PROJ_PROJEKT:FK_BEL_BELEG_ABLAGE'
,p_break_on=>'PK_PROJEKT:PROJEKT:0:0:0:0:ART'
,p_break_enabled_on=>'PK_PROJEKT:PROJEKT:0:0:0:0:ART'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.component_end;
end;
/
