prompt --application/pages/page_00195
begin
--   Manifest
--     PAGE: 00195
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>195
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Buchung Verwendungszweck'
,p_step_title=>'Buchung Verwendungszweck'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44310049295715590)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622120900'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24511904197903615)
,p_plug_name=>'Buchung_Verwendungszweck'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct',
'      apex_item.checkbox2(1, kto.fk_main_key) sel,',
'      apex_item.checkbox2(2, kto.fk_main_key || '','' || kto.FK_std_kto_kontotyp) sel2,',
'      ''<b>'' || kto.Verwendungszweck || ''</b>'' || '' <i>''|| kto.Kategorie || ''</i> '' || kto."BUCHUNGSTEXT" as title, ',
'      kto.fk_main_Key,',
'      ckz.fk_std_contr_status verw_fk_std_contr_status,',
'      ckz1.fk_std_contr_status kat_fk_std_contr_status,',
'      auslgeb.jkey,',
'      auslgeb.fk_main_key auslgeb_fk_main_key,',
'      auslgeb.Verwendungszweck auslgeb_Verw,',
'      auslgeb.Kategorie auslgeb_kat,',
'      auslgeb.buchungstext auslgeb_Buchungstext,',
'      case when ckz.fk_std_contr_status =1 then ''OK'' else ''NOK'' end contr_verw,',
'      case when ckz1.fk_std_contr_status =1 then ''OK'' else ''NOK'' end contr_kat,',
'      kto.Kontotyp,',
'      round(kto."Betrag",2) Wert,',
'      kto."Buchungstag",',
'      case when kto.FK_std_kto_kontotyp = 1 then ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_ID:'' || kto.ID || chr(39) || ''> '' || nvl(kto.Buchungstext ,''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 2 then ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_ID:'' || kto.ID || chr(39) || ''>'' || nvl(kto.Buchungstext,''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 4 then ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_ID:'' || kto.ID || chr(39) ||  ''>'' || nvl(kto.Buchungstext , ''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 3 then ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_ID:'' || kto.fk_kto_vorgang || chr(39) || ''>'' || nvl(kto.Buchungstext, ''<<--keine Angabe-->>'') || ''</a>''',
'  end link_Buchung,',
'  kto.wiederholung,',
'  kto.naechste_Zahlung,',
'  kto.naechste_zahlung - kto."Buchungstag" diff,',
'  kto.Waehrung,',
'  kto.Fremdwaehrung,',
'  kto.Fremdwaehrungsbetrag,',
'  kto.bucht_jahr,',
'  inv.pk_inv_inventar,',
'  inv.inventar,',
'  inv.anschaffungsjahr,',
'  inv.abgangsjahr,',
'  inv.preis_brutto,',
'  pr.pk_proj_projekt,',
'  pr.projekt,',
'  pr.von,',
'  pr.bis,',
'  kto.fk_kto_vorgang,',
'  belgr.cnt_bel,',
'  lex.belegnummer,',
'  lex.pk_lex,',
'  lex.buchungstext buchtxt,',
'  lex.sollkonto,',
'  lex.habenkonto,',
'  lex.ok,',
'  lex.datum_ok,',
'  lex.storno,',
'  kto.bucht_monat,',
'  kto.fk_bas_kat_kategorie,',
'  kto.fk_std_verw_verwendungszweck',
'from v_kto_konten_zus kto',
' left join (select * from t_contr_Kategorie_zahlung where Kontrollzweck = ''Verwendungszweck'') ckz on kto.fk_main_key = ckz.fk_main_key',
' left join (select * from t_contr_Kategorie_zahlung where Kontrollzweck = ''Kategorie'') ckz1 on kto.fk_main_key = ckz1.fk_main_key',
' left join (',
'             select kto1.*,  round(kto1."Betrag",2) wert, kto2.fk_main_key jkey',
'             from v_kto_konten_zus kto1',
'                join t_rel_kto_kont_buch_kont_buch relkto on kto1.fk_main_key = relkto.fk_kto_konto_buch1 or kto1.fk_main_key = relkto.fk_kto_konto_buch2',
'                join v_kto_konten_zus kto2 on  kto2.fk_main_key = relkto.fk_kto_konto_buch1 or kto2.fk_main_key = relkto.fk_kto_konto_buch2',
unistr('             where instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0 '),
'             union',
'             select kto2.*,   round(kto2."Betrag",2) wert, kto1.fk_main_key jkey',
'             from v_kto_konten_zus kto1',
'               join t_rel_kto_kont_buch_kont_buch relkto on kto1.fk_main_key = relkto.fk_kto_konto_buch1 or kto1.fk_main_key = relkto.fk_kto_konto_buch2',
'               join v_kto_konten_zus kto2 on  kto2.fk_main_key = relkto.fk_kto_konto_buch1 or kto2.fk_main_key = relkto.fk_kto_konto_buch2',
unistr('             where instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0  '),
'           ) auslgeb on auslgeb.jkey = kto.fk_main_key and auslgeb.fk_main_key <> kto.fk_main_key',
'left join t_rel_inv_inventar_zahlung invzahl on kto.fk_main_key = invzahl.fk_main_key',
'left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar',
'left join t_rel_proj_project_payment przahl on przahl.fk_main_key = kto.fk_main_key',
'left join t_proj_projekt pr on pr.pk_proj_projekt = przahl.fk_proj_projekt',
'left join (select count(*) cnt_bel, fk_kto_buchung from v_imp_bel_zus group by fk_kto_buchung) belgr on belgr.fk_kto_buchung = kto.fk_main_key',
'left join (select * from t_lex where ok = 1 and storno =0) lex on lex.fk_main_key = kto.fk_main_key',
'order by 1',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(24476765677963383)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:RP:P203_FK_BUCHUNG:#FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>32346581642992764
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8537644326722707)
,p_db_column_name=>'TITLE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8538074600722710)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8538462219722712)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'fk_main_key <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8540014380722716)
,p_db_column_name=>'WERT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8540444725722717)
,p_db_column_name=>'Buchungstag'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8540815230722717)
,p_db_column_name=>'SEL2'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'fk_main_key, konto_typ  <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488120690910061)
,p_db_column_name=>'CONTR_VERW'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Contr verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488190742910062)
,p_db_column_name=>'CONTR_KAT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Contr kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488312215910063)
,p_db_column_name=>'JKEY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Jkey'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488430868910064)
,p_db_column_name=>'AUSLGEB_FK_MAIN_KEY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Auslgeb fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488485594910065)
,p_db_column_name=>'AUSLGEB_VERW'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Auslgeb verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488601072910066)
,p_db_column_name=>'AUSLGEB_KAT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Auslgeb kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8488685024910067)
,p_db_column_name=>'AUSLGEB_BUCHUNGSTEXT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Auslgeb buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8622372549780720)
,p_db_column_name=>'LINK_BUCHUNG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Link buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8622517686780722)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8622589463780723)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9324609768937253)
,p_db_column_name=>'INVENTAR'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9324723415937254)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9324813145937255)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9324896639937256)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325129868937258)
,p_db_column_name=>'PROJEKT'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325224498937259)
,p_db_column_name=>'VON'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9325374581937260)
,p_db_column_name=>'BIS'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9382513755854643)
,p_db_column_name=>'CNT_BEL'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Cnt bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289077565418531)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289091629418532)
,p_db_column_name=>'PK_LEX'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289249914418533)
,p_db_column_name=>'BUCHTXT'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Buchtxt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289368385418534)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289467493418535)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289566808418536)
,p_db_column_name=>'OK'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289657813418537)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Datum ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10289774131418538)
,p_db_column_name=>'STORNO'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11763063457213320)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8443225627471123)
,p_db_column_name=>'DIFF'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Diff'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8443346776471124)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720677568099506)
,p_db_column_name=>'VERW_FK_STD_CONTR_STATUS'
,p_display_order=>480
,p_column_identifier=>'AX'
,p_column_label=>'Verw Fk Std Contr Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720720932099507)
,p_db_column_name=>'KAT_FK_STD_CONTR_STATUS'
,p_display_order=>490
,p_column_identifier=>'AY'
,p_column_label=>'Kat Fk Std Contr Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720833647099508)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>500
,p_column_identifier=>'AZ'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720911465099509)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>510
,p_column_identifier=>'BA'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721020641099510)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>520
,p_column_identifier=>'BB'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721199814099511)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>530
,p_column_identifier=>'BC'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721240766099512)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>540
,p_column_identifier=>'BD'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721362847099513)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>550
,p_column_identifier=>'BE'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721430936099514)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>560
,p_column_identifier=>'BF'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721577308099515)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>570
,p_column_identifier=>'BG'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51721660553099516)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>580
,p_column_identifier=>'BH'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9375205872802473)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Inventar'
,p_report_seq=>10
,p_report_alias=>'172451'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:TITLE:FK_MAIN_KEY:WERT:Buchungstag::CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:PROJEKT:VON:BIS:CNT'
||'_BEL:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO:BUCHT_JAHR'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
,p_break_on=>'PK_INVENTAR:INVENTAR:PREIS_BRUTTO:0:0:0'
,p_break_enabled_on=>'PK_INVENTAR:INVENTAR:PREIS_BRUTTO:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9375984774802475)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9376416134802475)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9376839442802476)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9375589652802474)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9377218526802477)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_name=>'Row text contains ''149'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'149'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9377625315802477)
,p_report_id=>wwv_flow_api.id(9375205872802473)
,p_name=>'Row text contains ''privat'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'privat'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9417984922588615)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Projekt'
,p_report_seq=>10
,p_report_alias=>'172879'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:BUCHT_JAHR:TITLE:FK_MAIN_KEY:CNT_BEL:WERT:Buchungstag:CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:P'
||'ROJEKT:VON:BIS:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
,p_break_on=>'PK_PROJEKT:PROJEKT:0:0:0:0'
,p_break_enabled_on=>'PK_PROJEKT:PROJEKT:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11771267888231994)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_name=>'anzahl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CNT_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D4CDD4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11771613271231996)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11772000954231999)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11772480266232001)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11769628267231986)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'='
,p_expr=>'379'
,p_condition_sql=>'"FK_MAIN_KEY" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11770075722231987)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_VORGANG'
,p_operator=>'='
,p_expr=>'31'
,p_condition_sql=>'"FK_VORGANG" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11770412012231990)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PK_PROJEKT'
,p_operator=>'is null'
,p_condition_sql=>'"PK_PROJEKT" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11770833224231992)
,p_report_id=>wwv_flow_api.id(9417984922588615)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(24517276512967082)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'164110'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:TITLE:FK_MAIN_KEY:WERT:Buchungstag::CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:PROJEKT:VON:BIS:CNT'
||'_BEL:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO:BUCHT_JAHR:BUCHT_MONAT:VERW_FK_STD_CONTR_STATUS:KAT_FK_STD_CONTR_STATUS:KONTOTYP:WAEHRUNG:FREMDWAEHRUNG:FREMDWAEHRUNGSBETRAG:PK_INV_INVENTAR:PK_PROJ_PROJEKT:FK_KTO_VORGANG:FK_BAS'
||'_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42294632941773123)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42295079199773126)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42295404896773128)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42293456235773120)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42293875189773120)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'is null'
,p_condition_sql=>'"FK_Kategorie" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42294272490773121)
,p_report_id=>wwv_flow_api.id(24517276512967082)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24893587786662011)
,p_plug_name=>unistr('Kategorie \00E4ndern')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8544714404722743)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(24511904197903615)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8734155159162124)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'Update_Kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9171055037575158)
,p_button_image_alt=>'Update kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8545413616722774)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'Update_Verwendungszweck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9171055037575158)
,p_button_image_alt=>'Update verwendungszweck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8623159646780728)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'Update_Wiederholung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9171055037575158)
,p_button_image_alt=>'Update wiederholung'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8623257525780729)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9171055037575158)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8623764984780734)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung_1')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9171055037575158)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9119249454394837)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'Insert_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'Insert inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11000089077679626)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'remove_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'remove inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9381674249854634)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'Insert_Projekt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'Insert Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11763305344213323)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(24893587786662011)
,p_button_name=>'remove_Projekt_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'Remove Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8543988121722737)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24511904197903615)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8544306774722743)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24511904197903615)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8487759644910057)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(24511904197903615)
,p_button_name=>'OK_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(9172750041608519)
,p_button_image_alt=>'Ok'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8545833303722775)
,p_name=>'P195_FK_STD_VERW_VERWENDUNGSZWECK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'Fk verwendungszweck'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value ',
'from t_std',
'where fk_std_group = 9'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8622981465780726)
,p_name=>'P195_WIEDERHOLUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'Wiederholung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC:',
unistr('"j\00E4hrlich";"j\00E4hrlich",'),
unistr('"halbj\00E4hrlich";"halbj\00E4hrlich",'),
unistr('"viertelj\00E4hrlich";"viertelj\00E4hrlich",'),
'"monatlich";"monatlich",',
'einmalig;einmalig'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8623062234780727)
,p_name=>'P195_NAECHSTE_ZAHLUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>unistr('N\00E4chste zahlung')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8733882428159878)
,p_name=>'P195_FK_BAS_KAT_KATEGORIE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "Kategorie", pk_konto_buch_kat',
'from t_konto_buch_kat',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119143796394836)
,p_name=>'P195_FK_INV_INVENTAR'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr, pk_inv_inventar',
'from t_inv_inventare'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119478911394839)
,p_name=>'P195_DESCR1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'fk_main_key, konrotsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119553380394840)
,p_name=>'P195_DESCR1_1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119641607394841)
,p_name=>'P195_DESCR1_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119772072394842)
,p_name=>'P195_DESCR1_3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9119795250394843)
,p_name=>'P195_DESCR1_4'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'fk_main_key'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightgreen"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9381504192854633)
,p_name=>'P195_FK_PROJ_PROJEKT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(24893587786662011)
,p_prompt=>'Fk projekt'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || von || '' - '' || bis || '')''  ,Pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8547007915722831)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8105784419151658)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8547539166722838)
,p_event_id=>wwv_flow_api.id(8547007915722831)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(24511904197903615)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8547801252722839)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8544306774722743)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8548291772722839)
,p_event_id=>wwv_flow_api.id(8547801252722839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(24511904197903615)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8546230024722828)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select apex_application.g_f01(i),',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8544714404722743)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8487877051910058)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select apex_application.g_f01(i),',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8487759644910057)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8546672266722830)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Verwendungszweck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
'       update KTO_Paypal  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
'       update KTO_Tagesgeldkonto  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8545413616722774)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8622752088780724)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Wiederholung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
'       update KTO_Paypal  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
'       update KTO_Tagesgeldkonto  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8623159646780728)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8622792503780725)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_naechste_Zahlung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
unistr('       update "KTO_Girokonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
unistr('       update "KTO_Kreditkarte"  set N\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
unistr('       update "KTO_Paypal"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
unistr('       update "KTO_Tagesgeldkonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8623257525780729)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8623668255780733)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_naechste_Zahlung_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'       p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8623764984780734)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8734304805164562)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set "FK_Kategorie" = :P195_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set "FK_Kategorie" = :P195_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8734155159162124)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9119340927394838)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'   insert into t_rel_inventar_zahlung',
'   (',
'     fk_inventar,',
'     fk_main_key',
'   )',
'   select to_number(:P195_fk_inventar),',
'    apex_application.g_f01(i)',
'   from dual;',
'   commit;',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9119249454394837)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11000330521679628)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_inventar_zahlung where fk_inventar = to_number(:P195_fk_inventar) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11000089077679626)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9381701302854635)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'   insert into t_rel_Projekt_zahlung',
'   (',
'     fk_projekt,',
'     fk_main_key',
'   )',
'   select to_number(:P195_fk_projekt),',
'    apex_application.g_f01(i)',
'   from dual;',
'   commit;',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9381674249854634)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11763232379213322)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_projekt_zahlung where fk_projekt = to_number(:P195_fk_projekt) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11763305344213323)
);
wwv_flow_api.component_end;
end;
/
