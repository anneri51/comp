prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>200
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Parkticket_Bild'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Parkticket_Bild'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44326124317819076)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524084145'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23747707241311883)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23753724439480762)
,p_plug_name=>'Parktickets_Bild'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_IMP_BA_PARKTICKETS,',
'       length(BILD) bild',
'  from IMP_BA_PARKTICKETS',
'where PK_IMP_BA_PARKTICKETS =524',
'--= :P200_PK_IMP_BA_PARKTICKETS'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(23753736275480762)
,p_name=>'Kontoauszug_Bild'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>31623552240510143
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8193775951523130)
,p_db_column_name=>'BILD'
,p_display_order=>13
,p_column_identifier=>'E'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:T_REL_KONTO_AUSZUG_BILD:BILD:PK_KONTO_AUSZUG_BILD::::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8167901260548244)
,p_db_column_name=>'PK_IMP_BA_PARKTICKETS'
,p_display_order=>23
,p_column_identifier=>'F'
,p_column_label=>'Pk imp ba parktickets'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:IMP_BA_PARKTICKETS:BILD:PK_IMP_BA_PARKTICKETS::::::::'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(23758067478549448)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'160651'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>'PK_IMP_BA_PARKTICKETS:'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8192999348523107)
,p_name=>'P200_PK_IMP_BA_PARKTICKETS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23747707241311883)
,p_prompt=>'Pk imp ba parktickets'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
