prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>208
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Elektronik_Bild'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Elektronik_Bild'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44310381897721709)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622140922'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(57079934489623875)
,p_plug_name=>'Elektronik_Bild'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INV_SUB_Elektronik,',
'       length(BILD) bild',
'from t_INV_SUB_Elektronik',
'where PK_INV_SUB_elektronik =:P208_PK_INV_SUB_elektronik'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(57079946325623875)
,p_name=>'Kontoauszug_Bild'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>64949762290653256
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8803216658082087)
,p_db_column_name=>'BILD'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:IMP_BA_ELEKTRONIK:BILD:PK_IMP_BA_ELEKTRONIK::::::inline::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52004164829555541)
,p_db_column_name=>'PK_INV_SUB_ELEKTRONIK'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Pk Inv Sub Elektronik'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(57084277528692561)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'166734'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>':PK_IMP_BA_SOFTWARE1:BILD:PK_INV_SUB_ELEKTRONIK'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8804025014082089)
,p_name=>'P208_PK_INV_SUB_ELEKTRONIK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(57079934489623875)
,p_prompt=>'Pk imp ba elektronik'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
