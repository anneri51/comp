prompt --application/pages/page_00214
begin
--   Manifest
--     PAGE: 00214
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>214
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Konten'
,p_step_title=>'Konten'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869320059313897)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622170600'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8275224831021524)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_LEX_KONTENPLAN_KONTEN", ',
'"KONTEN_NR_EXT",',
'kto."BEZEICHNUNG" KTO_BEZ,',
'FK_LEX_KONTENPLAN,',
'FK_LEX_KONTENPLAN_KONTEN_GRP,',
'ktogrp.bezeichnung ktogrp_bez,',
'ktogrp.kontennr_ext nr_ext2,',
'ktogrp.KONTENNR_EXT,',
'ktogrp.bezeichnung ktogrp_bez2',
'from "#OWNER#"."T_LEX_KONTENPLAN_KONTEN" kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8275518943021525)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:215:&APP_SESSION.::::P215_PK_KONTENPLAN_KONTEN:#PK_KONTENPLAN_KONTEN#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>17585654183442446
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8276012785021537)
,p_db_column_name=>'KONTEN_NR_EXT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Konten Nr Ext'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8123324714920720)
,p_db_column_name=>'KTO_BEZ'
,p_display_order=>14
,p_column_identifier=>'F'
,p_column_label=>'Kto bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8123477504920722)
,p_db_column_name=>'KTOGRP_BEZ'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Ktogrp bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8123611242920723)
,p_db_column_name=>'KONTENNR_EXT'
,p_display_order=>44
,p_column_identifier=>'I'
,p_column_label=>'Kontennr ext'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8123713245920724)
,p_db_column_name=>'KTOGRP_BEZ2'
,p_display_order=>54
,p_column_identifier=>'J'
,p_column_label=>'Ktogrp bez2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8123943380920726)
,p_db_column_name=>'NR_EXT2'
,p_display_order=>64
,p_column_identifier=>'L'
,p_column_label=>'Nr ext2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730140386514994)
,p_db_column_name=>'PK_LEX_KONTENPLAN_KONTEN'
,p_display_order=>74
,p_column_identifier=>'M'
,p_column_label=>'Pk Lex Kontenplan Konten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730239691514995)
,p_db_column_name=>'FK_LEX_KONTENPLAN'
,p_display_order=>84
,p_column_identifier=>'N'
,p_column_label=>'Fk Lex Kontenplan'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730377592514996)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_GRP'
,p_display_order=>94
,p_column_identifier=>'O'
,p_column_label=>'Fk Lex Kontenplan Konten Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8278320690023350)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'175885'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KONTEN_NR_EXT:KTO_BEZ:KTOGRP_BEZ::KONTENNR_EXT:KTOGRP_BEZ2:NR_EXT2:PK_LEX_KONTENPLAN_KONTEN:FK_LEX_KONTENPLAN:FK_LEX_KONTENPLAN_KONTEN_GRP'
,p_break_on=>'KTOGRP_BEZ'
,p_break_enabled_on=>'KTOGRP_BEZ'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8283490824217230)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Konten_grp'
,p_report_seq=>10
,p_report_alias=>'175937'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NR_EXT2:KTOGRP_BEZ2:KONTEN_NR_EXT:KTO_BEZ:KTOGRP_BEZ:KONTENNR_EXT'
,p_sort_column_1=>'KONTEN_NR_EXT'
,p_sort_direction_1=>'ASC'
,p_break_on=>'KONTENNR_EXT:KTOGRP_BEZ:0:0:0:0'
,p_break_enabled_on=>'KONTENNR_EXT:KTOGRP_BEZ:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8297100383314453)
,p_report_id=>wwv_flow_api.id(8283490824217230)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KTO_BEZ'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("KTO_BEZ" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8277645321021545)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8275224831021524)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:215:&SESSION.::&DEBUG.:215'
);
wwv_flow_api.component_end;
end;
/
