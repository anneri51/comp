prompt --application/pages/page_00217
begin
--   Manifest
--     PAGE: 00217
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>217
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Kontenkategorien'
,p_step_title=>'Kontenkategorien'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309639334705437)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622171857'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9738575765434281)
,p_plug_name=>'Kontenkategorien'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ktokatgrp.PK_LEX_KONTENPLAN_KONTEN_KAT_GRP,',
'       ktokatgrp.BEZEICHNUNG bez,',
'       ktokatgrp.FK_LEX_KONTENPLAN ktopl,',
'       ktokat.*',
'  from T_LEX_KONTENPLAN_KONTEN_KAT_GRP ktokatgrp',
'   join t_lex_kontenplan_konten_kat ktokat on ktokatgrp.pk_lex_kontenplan_konten_kat_grp = ktokat.fk_lex_kontenplan_konten_kat_grp',
'   '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9738647525434281)
,p_name=>'Kontenkategorien'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17608463490463662
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9739403114434300)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9564375225312267)
,p_db_column_name=>'BEZ'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9564405368312268)
,p_db_column_name=>'KTOPL'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Ktopl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52170711536906537)
,p_db_column_name=>'PK_LEX_KONTENPLAN_KONTEN_KAT_GRP'
,p_display_order=>33
,p_column_identifier=>'H'
,p_column_label=>'Pk Lex Kontenplan Konten Kat Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52170844098906538)
,p_db_column_name=>'PK_LEX_KONTENPLAN_KONTEN_KAT'
,p_display_order=>43
,p_column_identifier=>'I'
,p_column_label=>'Pk Lex Kontenplan Konten Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52170970619906539)
,p_db_column_name=>'FK_LEX_KONTENPLANLEX_'
,p_display_order=>53
,p_column_identifier=>'J'
,p_column_label=>'Fk Lex Kontenplanlex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52171084974906540)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_KAT_GRP'
,p_display_order=>63
,p_column_identifier=>'K'
,p_column_label=>'Fk Lex Kontenplan Konten Kat Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9747130052454320)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'176170'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BEZEICHNUNG:BEZ:KTOPL:FK_KONTENPLAN_KONTEN_KAT_GRP_GRP:PK_LEX_KONTENPLAN_KONTEN_KAT:FK_LEX_KONTENPLANLEX_:FK_LEX_KONTENPLAN_KONTEN_KAT_GRP'
,p_break_on=>'BEZ'
,p_break_enabled_on=>'BEZ'
);
wwv_flow_api.component_end;
end;
/
