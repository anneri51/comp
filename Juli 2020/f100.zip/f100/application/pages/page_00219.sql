prompt --application/pages/page_00219
begin
--   Manifest
--     PAGE: 00219
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>219
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'lex'
,p_step_title=>'lex'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44310049295715590)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622174625'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10288341840418524)
,p_plug_name=>'Buchungszuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10589705508786750)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_lex, ok, storno, 1 idx',
'from t_lex',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10590147269786754)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18459963234816135
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10590363688786756)
,p_db_column_name=>'OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10590459643786757)
,p_db_column_name=>'STORNO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10590529510786758)
,p_db_column_name=>'PK_LEX'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10590655951786759)
,p_db_column_name=>'IDX'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Idx'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10668620318434140)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'185385'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:STORNO:PK_LEX:IDX'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10681940515914230)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Pivot'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'185518'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:STORNO:PK_LEX:IDX'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(10682339109914235)
,p_report_id=>wwv_flow_api.id(10681940515914230)
,p_pivot_columns=>'IDX'
,p_row_columns=>'OK:STORNO'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(10682767133914236)
,p_pivot_id=>wwv_flow_api.id(10682339109914235)
,p_display_seq=>1
,p_function_name=>'COUNT'
,p_column_name=>'PK_LEX'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10705213999580521)
,p_plug_name=>'Buchungstext'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10705357306580522)
,p_plug_name=>'Buchungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10262963858811485)
,p_plug_name=>'lex'
,p_parent_plug_id=>wwv_flow_api.id(10705357306580522)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'      apex_item.checkbox2(1,pk_lex) sel_pk,',
'      apex_item.checkbox2(2,Belegnummer) sel_bel,',
'      apex_item.checkbox2(3,fk_Main_key) sel_fk_main_key,',
'      BELEGDATUM,',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLueSSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRaeGER,',
'       BUCHUNGSBETRAG_EURO,',
'       WaeHRUNG,',
'       ZUSATZANGABEN,',
'       OK,',
'       STORNO,',
'       PK_LEX,',
'       BEMERKUNGEN,',
'       datum_ok,',
'       fk_main_key,',
'       fk_imp_ba_bel,',
'       bezeichnung',
'  from T_LEX lex',
'    left join t_lex_kontenplan_konten kto on kto.konten_nr_ext = lex.sollkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10263005520811485)
,p_name=>'lex'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18132821485840866
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10263473737811503)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10263696523811508)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10264102622811508)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10264551305811509)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10264895719811510)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10265374333811511)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10265729706811511)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10266131746811512)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10266573524811512)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10267366398811513)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10268084207811515)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10268909354811515)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10269313515811516)
,p_db_column_name=>'OK'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10269685625811516)
,p_db_column_name=>'STORNO'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10270144563811516)
,p_db_column_name=>'PK_LEX'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Pk Lex'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10270572048811517)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10288776298418528)
,p_db_column_name=>'SEL_PK'
,p_display_order=>29
,p_column_identifier=>'U'
,p_column_label=>'Sel pk <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10288832807418529)
,p_db_column_name=>'SEL_BEL'
,p_display_order=>39
,p_column_identifier=>'V'
,p_column_label=>'Sel bel <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10288942592418530)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>49
,p_column_identifier=>'W'
,p_column_label=>'Datum ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10531227134994323)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>59
,p_column_identifier=>'X'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10531366331994324)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>69
,p_column_identifier=>'Y'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10531829733994329)
,p_db_column_name=>'SEL_FK_MAIN_KEY'
,p_display_order=>79
,p_column_identifier=>'Z'
,p_column_label=>'Sel fk main key <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f03]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11000744646679632)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>89
,p_column_identifier=>'AA'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52171946757906549)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>99
,p_column_identifier=>'AB'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52172036399906550)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>109
,p_column_identifier=>'AC'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52242511530941601)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>119
,p_column_identifier=>'AD'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10271158278813315)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'181410'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('BELEGDATUM:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BELEGNUMMER:BUCHUNGSTEXT:BUCHUNGSBETRAG:SOLLKONTO:HABENKONTO:STEUERSCHL\00DCSKOSTENSTELLE:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:OK:STORNO:PK_LEX:BEMERKUNGEN:SEL_PK:SEL_BEL:DATUM_OK:FK_MAIN_KEY:FK_IMP')
||'_BA_BEL:SEL_FK_MAIN_KEY:BEZEICHNUNG:STEUERSCHLUESSEL:KOSTENTRAEGER:WAEHRUNG'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10560397461318348)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Belegnummer'
,p_report_seq=>10
,p_report_alias=>'184303'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_PK:SEL_BEL:SEL_FK_MAIN_KEY:BELEGDATUM:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BELEGNUMMER:BUCHUNGSTEXT:BUCHUNGSBETRAG:SOLLKONTO:HABENKONTO:KOSTENSTELLE:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:OK:DATUM_OK:STORNO:PK_LEX:BEMERKUNGEN:FK_IMP_BA_BEL:'
||'FK_MAIN_KEY::BEZEICHNUNG'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_break_on=>'SOLLKONTO'
,p_break_enabled_on=>'SOLLKONTO'
,p_sum_columns_on_break=>'BUCHUNGSBETRAG'
,p_count_columns_on_break=>'PK_LEX'
,p_count_distnt_col_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11014784228694079)
,p_report_id=>wwv_flow_api.id(10560397461318348)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11015194049694080)
,p_report_id=>wwv_flow_api.id(10560397461318348)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#DBA89B'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11013643736694078)
,p_report_id=>wwv_flow_api.id(10560397461318348)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEGNUMMER'
,p_operator=>'='
,p_expr=>'281'
,p_condition_sql=>'"BELEGNUMMER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11014043792694079)
,p_report_id=>wwv_flow_api.id(10560397461318348)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11014418388694079)
,p_report_id=>wwv_flow_api.id(10560397461318348)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"STORNO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10705387338580523)
,p_plug_name=>'Belegzuordnungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10705586312580525)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10705387338580523)
,p_button_name=>'Belegzuordnung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Belegzuordnung'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10288497670418526)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10288341840418524)
,p_button_name=>'Add_Buchung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add buchung'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10591089981786764)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10705213999580521)
,p_button_name=>'Get_Buchungstext'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Get buchungstext'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10591375212786766)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10705213999580521)
,p_button_name=>'Reset_Buchungstext'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Reset buchungstext'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10999813873679623)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(10705213999580521)
,p_button_name=>'get_pk_lex'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Get pk lex'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10530947254994320)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(10288341840418524)
,p_button_name=>'get_fk_main_key'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Get fk main key'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10290837997418549)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(10288341840418524)
,p_button_name=>'Goto_221'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Goto 221'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.::P221_BELEGNUMMER,P221_PK_LEX:&P219_BELEGNUMMER.,&P219_PK_LEX.'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10112330194646569)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10262963858811485)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Ok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10288084324418522)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10262963858811485)
,p_button_name=>'storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Storno'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10292541709418566)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10262963858811485)
,p_button_name=>'no_storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'No storno'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(10531107452994322)
,p_branch_name=>'Go To Page 221'
,p_branch_action=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.:RP:P221_BELEGNUMMER,P221_PK_LEX,P221_FK_MAIN_KEY:&P219_BELEGNUMMER.,&P219_PK_LEX.,&P219_FK_MAIN_KEY.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(10530947254994320)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(11000051694679625)
,p_branch_name=>'Go To Page 221'
,p_branch_action=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.:RP:P221_BELEGNUMMER,P221_PK_LEX,P221_FK_MAIN_KEY:&P219_BELEGNUMMER.,&P219_PK_LEX.,&P219_FK_MAIN_KEY.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(10999813873679623)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10288396939418525)
,p_name=>'P219_FK_KTO_BUCHUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10288341840418524)
,p_prompt=>'Fk buchung'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_main_key || '' '' || "Buchungstag" || '' '' || Buchungstext || '' '' || round("Betrag",2) || '' '' || Kontotyp d, fk_main_key',
'',
'from v_kto_konten_zus',
'where instr(Buchungstext, :P219_Buchungstext) >0 or :P219_Buchungstext is null'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10290520165418546)
,p_name=>'P219_PK_LEX'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(10288341840418524)
,p_prompt=>'Pk lex'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10290682572418547)
,p_name=>'P219_BELEGNUMMER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(10288341840418524)
,p_prompt=>'Belegnummer'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select belegnummer d',
'from t_lex'))
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
,p_attribute_06=>'N'
,p_attribute_07=>'Y'
,p_attribute_08=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10531659939994327)
,p_name=>'P219_FK_MAIN_KEY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(10288341840418524)
,p_prompt=>'Fk main key'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10590993855786763)
,p_name=>'P219_BUCHUNGSTEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10705213999580521)
,p_prompt=>'Buchungstext'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10705581116580524)
,p_name=>'P219_FK_IMP_BA_BEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10705387338580523)
,p_prompt=>'Fk imp ba bel'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select art || '' '' || fk_imp_ba_bel || '' '' || datum || '' '' || bezeichnung || '' '' || betrag, fk_imp_ba_bel',
'from v_imp_bel_zus',
'where instr(bezeichnung, :P219_Buchungstext)>0 or :P219_Buchungstext is null'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10291245143418553)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P219_BELEGNUMMER'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10292690921418568)
,p_event_id=>wwv_flow_api.id(10291245143418553)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10591504153786768)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10591375212786766)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10591602781786769)
,p_event_id=>wwv_flow_api.id(10591504153786768)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P219_BUCHUNGSTEXT := null;'
,p_attribute_02=>'P219_BUCHUNGSTEXT'
,p_attribute_03=>'P219_BUCHUNGSTEXT'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10705143786580520)
,p_event_id=>wwv_flow_api.id(10591504153786768)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10287966899418520)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ',
'   for i in 1..apex_application.g_f01.count loop',
'   ',
'     if apex_application.g_f01(i) is not null then',
'       update t_lex set ok = 1 , datum_ok = sysdate where pk_lex = apex_application.g_f01(i);',
'       commit;',
'     ',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10112330194646569)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10531042763994321)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_fk_main_key'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ',
'   for i in 1..apex_application.g_f03.count loop',
'   ',
'     if apex_application.g_f03(i) is not null then',
'      :P219_fk_main_key := apex_application.g_f03(i);',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10530947254994320)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10999690574679622)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_pk_lex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ',
'   for i in 1..apex_application.g_f01.count loop',
'   ',
'     if apex_application.g_f01(i) is not null then',
'      :P219_pk_lex:= apex_application.g_f01(i);',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10999813873679623)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10591439519786767)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_buchungstext'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_cnt number;',
' v_buchungstext varchar2(400 char);',
'begin',
'',
'',
'  --Auswahl nach PK_LEX',
'   for i in 1..apex_application.g_f01.count loop',
'   ',
'',
'   ',
'     if apex_application.g_f01(i) is not null then',
'     ',
'        select count(*) ',
'   into v_cnt',
'   from t_lex',
'   where pk_lex =  apex_application.g_f01(i);',
'   ',
'   if v_cnt > 0 then',
'      select buchungstext',
'   into :P219_buchungstext',
'   from t_lex',
'   where pk_lex = apex_application.g_f01(i);',
'   end if;',
'   ',
'     end if;',
'   ',
'   ',
'   end loop;',
'   ',
'   --Auswahl nach Belegnummer   ',
'   for i in 1..apex_application.g_f02.count loop',
'   ',
'',
'   ',
'     if apex_application.g_f02(i) is not null then',
'     ',
'        select count(*) ',
'   into v_cnt',
'   from t_lex',
'   where belegnummer = apex_application.g_f02(i);',
'   ',
'   if v_cnt >0 then',
'      select max(buchungstext)',
'   into :P219_buchungstext',
'   from t_lex',
'   where belegnummer =  apex_application.g_f02(i);',
'   end if;',
'   ',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10591089981786764)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10288206466418523)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'storno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ',
'   for i in 1..apex_application.g_f01.count loop',
'   ',
'     if apex_application.g_f01(i) is not null then',
'       update t_lex set storno = 1 where pk_lex = apex_application.g_f01(i);',
'       commit;',
'     ',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10288084324418522)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10292668552418567)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'storno_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ',
'   for i in 1..apex_application.g_f01.count loop',
'   ',
'     if apex_application.g_f01(i) is not null then',
'       update t_lex set storno = 0 where pk_lex = apex_application.g_f01(i);',
'       commit;',
'     ',
'     end if;',
'   ',
'   ',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10292541709418566)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10288648225418527)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_buchung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_kontotyp varchar2(400 char);',
' v_cnt number;',
'begin',
'  ',
'',
'',
'   for i in 1..apex_application.g_f02.count loop',
'   ',
'     if apex_application.g_f02(i) is not null then',
'     ',
'     --   insert into test select 1, apex_application.g_f02(i),1 from dual; commit;',
'     ',
'         select count(*) ',
'         into v_cnt',
'         from v_kto_konten_zus',
'          where fk_main_key =  :P219_fk_buchung;',
'          ',
'          if v_cnt >0 then',
'              select Kontotyp',
'         into v_kto_kontotyp',
'         from v_kto_konten_zus',
'          where fk_main_key = :P219_fk_Kto_buchung;',
'          ',
'          if v_kontotyp = ''Girokonto'' then',
'          ',
'           update t_KTO_Girokonto set fk_buchung_steuer = apex_application.g_f02(i) where fk_main_key = :P219_fk_kto_buchung;',
'           commit;',
'          ',
'           commit;',
'          ',
'          end if;          ',
'',
'     if v_kontotyp = ''Kreditkarte'' then',
'          ',
'           update t_KTO_Kreditkarte set fk_buchung_steuer = apex_application.g_f02(i) where fk_main_key = :P219_fk_kto_buchung;',
'           commit;',
'          ',
'           commit;',
'          ',
'          end if;       ',
'          ',
'          ',
'          end if;',
'     ',
'     ',
'     end if;',
'     ',
'          --  insert into test select i, apex_application.g_f02(i), :P219_fk_buchung from dual; commit;',
'   ',
'     update t_lex set fk_Main_key =  :P219_fk_kto_buchung where belegnummer  = apex_application.g_f02(i) ;',
'           commit;',
'   ',
'   ',
'   end loop;',
'   ',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10288497670418526)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10705741291580526)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_kontotyp varchar2(400 char);',
' v_cnt number;',
'begin',
'  ',
'',
'',
'   for i in 1..apex_application.g_f02.count loop',
'   ',
'     if apex_application.g_f02(i) is not null then',
'     ',
'      --  insert into test select 1, apex_application.g_f02(i),1 from dual; commit;',
'     ',
'        ',
'      --      insert into test select i, apex_application.g_f02(i), :P219_fk_buchung from dual; commit;',
'   ',
'            update t_lex set fk_imp_ba_bel =  :P219_fk_imp_ba_bel where belegnummer  = apex_application.g_f02(i) ;',
'           commit;',
'     ',
'     end if;',
'   ',
'   end loop;',
'   ',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10705586312580525)
);
wwv_flow_api.component_end;
end;
/
