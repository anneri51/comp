prompt --application/pages/page_00220
begin
--   Manifest
--     PAGE: 00220
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>220
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Tree Page'
,p_step_title=>'Tree Page'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44311774616733357)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622185017'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9745200207450868)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as status, ',
'       level, ',
'       title,',
'       icon,',
'       value,',
'       null tooltip,',
'       null link',
'from ',
'(select fk_lex_kontenplan_konten_grp2 ,',
'       kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG"  as title, ',
'       null as icon, ',
'       PK_lex_KONTENPLAN_KONTEN as value, ',
'',
'  ktogrp.kontennr_ext || ''A'' kontennr_ext ,',
'  kto.konten_nr_ext || ''B'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
' union',
' select fk_lex_kontenplan_konten_grp2 ,',
'       kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG"  as title, ',
'       null as icon, ',
'       PK_lex_KONTENPLAN_KONTEN as value, ',
'',
'   kto.konten_nr_ext || ''B'' kontennr_ext ,',
'  kto.konten_nr_ext || ''B'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
' union',
' select fk_lex_kontenplan_konten_grp2 ,',
'       kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG"  as title, ',
'       null as icon, ',
'       PK_lex_KONTENPLAN_KONTEN as value, ',
'',
'    ktogrp.kontennr_ext  || ''B'' kontennr_ext ,',
'  kto.konten_nr_ext || ''B'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
'',
'',
'union',
'select fk_lex_kontenplan_konten_grp2 ,',
'        kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG" || '' '' || bez as title, ',
'       null as icon, ',
'       PK_lex_KONTENPLAN_KONTEN as value, ',
'    kto.konten_nr_ext || ''B'' kontennr_ext ,',
'  kto.konten_nr_ext || ''C'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
' left join (',
'      ',
' select ',
'  kto.konten_nr_ext,',
'',
' ktozus.verwendungszweck  || '' | '' ||',
' ktozus.kategorie  || '' | '' || ',
'  ktozus.buchungstext  || '' | '' ||',
' ''<b>'' || ktozus.fk_main_key  || ''</b> | '' ||',
'  ktozus.Kontotyp || '' | '' ||',
'  ''<b>'' || ktozus."Buchungstag"  || ''</b> | '' ||',
' ktozus."Betrag"  || '' | '' ||',
' lex.sollkonto  || '' | '' ||',
' lex.habenkonto || '' | '' ||',
'',
'',
' ktozus.wiederholung || '' | '' ||',
' ktozus.Naechste_Zahlung ||  '' | '' ||',
'',
'  ',
' kto.fk_lex_kontenplan_konten_grp || '' | '' ||',
' ktokat.bezeichnung || '' | '' || ',
'ktokatgrp.bezeichnung bez',
'',
'',
'',
' from v_kto_konten_zus ktozus',
'   join t_rel_kto_kont_buch_lex_buch  lex on ktozus.fk_buchung_steuer = lex.fk_lex_buch',
'   join t_lex_kontenplan_konten kto on kto.konten_nr_ext = lex.sollkonto or kto.konten_nr_ext = lex.habenkonto',
'   join T_REL_lex_KONTENPLAN_KTO_kto_kat ktoktokat on ktoktokat.fk_lex_kontenplan_konten = kto.pk_lex_kontenplan_konten',
' join t_lex_kontenplan_konten_kat ktokat on ktokat.pk_lex_kontenplan_konten_kat = ktoktokat.fk_lex_kontenplan_konten_kat',
'  join t_lex_kontenplan_konten_kat_grp ktokatgrp on ktokatgrp.pk_lex_kontenplan_konten_kat_grp = ktokat.fk_lex_kontenplan_konten_kat_grp',
' ) ktobuch on ktobuch.konten_nr_ext = kto.konten_nr_ext',
' ) t1',
' ',
'start with fk_lex_kontenplan_konten_grp2 is null',
'connect by nocycle  t1.kontennr_ext = prior t1.konten_nr_ext'))
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'S'
,p_attribute_04=>'N'
,p_attribute_08=>'a-Icon'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_15=>'STATUS'
,p_attribute_23=>'LEVEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9956933890301704)
,p_plug_name=>'Tree'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as status, ',
'       level, ',
'       title,',
'       icon,',
'       value,',
'       null tooltip,',
'      null link',
'from ',
'(select fk_lex_kontenplan_konten_grp2 ,',
'       kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG"  as title, ',
'       null as icon, ',
'       PK_lex_KONTENPLAN_KONTEN as value, ',
'',
'  ktogrp.kontennr_ext || ''A'' kontennr_ext ,',
'  kto.konten_nr_ext || ''B'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
'',
'',
'',
'union',
'select fk_Lex_kontenplan_konten_grp2 ,',
'        kto.konten_nr_ext || '' '' || kto."BEZEICHNUNG" || '' '' || bez as title, ',
'       null as icon, ',
'      PK_lex_KONTENPLAN_KONTEN as value, ',
'    kto.konten_nr_ext || ''B'' kontennr_ext ,',
'  kto.konten_nr_ext || ''C'' konten_nr_ext',
'from T_lex_KONTENPLAN_KONTEN kto',
' left join t_lex_kontenplan_konten_grp ktogrp on kto.fk_lex_kontenplan_konten_grp = ktogrp.pk_lex_kontenplan_konten_grp',
' left join (',
'      ',
' select ',
'  kto.konten_nr_ext,',
'',
' ktozus.verwendungszweck  || '' | '' ||',
' ktozus.kategorie  || '' | '' || ',
'  ktozus.buchungstext  || '' | '' ||',
' ''<b>'' || ktozus.fk_main_key  || ''</b> | '' ||',
'  ktozus.Kontotyp || '' | '' ||',
'  ''<b>'' || ktozus."Buchungstag"  || ''</b> | '' ||',
' ktozus."Betrag"  || '' | '' ||',
' lex.sollkonto  || '' | '' ||',
' lex.habenkonto || '' | '' ||',
'',
'',
' ktozus.wiederholung || '' | '' ||',
' ktozus.Naechste_Zahlung ||  '' | '' ||',
'',
'  ',
' kto.fk_lex_kontenplan_konten_grp || '' | '' ||',
' ktokat.bezeichnung || '' | '' || ',
'ktokatgrp.bezeichnung bez',
'',
'',
'',
' from v_kto_konten_zus ktozus',
'   join t_rel_kto_kont_buch_lex_buch  lex on ktozus.fk_buchung_steuer = lex.fk_lex_buch',
'   join t_lex_kontenplan_konten kto on kto.konten_nr_ext = lex.sollkonto or kto.konten_nr_ext = lex.habenkonto',
'   left join T_REL_lex_KONTENPLAN_KTO_kto_kat ktoktokat on ktoktokat.fk_lex_kontenplan_konten = kto.pk_lex_kontenplan_konten',
'   left join t_lex_kontenplan_konten_kat ktokat on ktokat.pk_lex_kontenplan_konten_kat = ktoktokat.fk_lex_kontenplan_konten_kat',
'   left join t_lex_kontenplan_konten_kat_grp ktokatgrp on ktokatgrp.pk_lex_kontenplan_konten_kat_grp = ktokat.fk_lex_kontenplan_konten_kat_grp',
' ) ktobuch on ktobuch.konten_nr_ext = kto.konten_nr_ext',
' ) t1',
' ',
'--start with fk_kontenplan_konten_grp2 is null',
'connect by nocycle  t1.kontennr_ext = prior t1.konten_nr_ext'))
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'S'
,p_attribute_04=>'N'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_15=>'STATUS'
,p_attribute_23=>'LEVEL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9957353779301708)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9956933890301704)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9958520375301733)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9956933890301704)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9957691356301719)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9957353779301708)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9958217281301730)
,p_event_id=>wwv_flow_api.id(9957691356301719)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(9956933890301704)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9958953815301734)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9958520375301733)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9959431997301735)
,p_event_id=>wwv_flow_api.id(9958953815301734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(9956933890301704)
);
wwv_flow_api.component_end;
end;
/
