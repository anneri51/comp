prompt --application/pages/page_00221
begin
--   Manifest
--     PAGE: 00221
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>221
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'lexware'
,p_step_title=>'lexware'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44310049295715590)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622190746'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10001688587063589)
,p_plug_name=>'lexware_kto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct BELEGDATUM,',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       lex.BUCHUNGSTEXT buchtext,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLUESSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRAEGER,',
'       BUCHUNGSBETRAG_EURO,',
'       kto.WAEHRUNG kto_waehrung,',
'       lex.ZUSATZANGABEN,',
'       lex.ok,',
'       kto.*,',
'       round(kto."Betrag",2) wert,',
'       apex_item.checkbox2(1, pk_lex,''CHECKED'') sel_ok,',
'       case when    STEUERSCHLUESSEL= 8 then ''7'' ',
'            when    STEUERSCHLUESSEL = 9 then ''19''',
'            else null',
'       end mwst,',
'       inv.pk_inv_inventar,',
'       inv.inventar,',
'       pr.pk_proj_projekt,',
'       pr.projekt,',
'       storno,',
'       pk_lex,',
'       lex_sum.sum_betrag - abs(round(kto."Betrag",2)) diff,',
'       lex.bemerkungen,',
'       konten.bezeichnung,',
'       lex.fk_imp_ba_bel ,',
'       lex_sum.sum_betrag',
'  from T_LEX lex',
'        left join v_kto_konten_zus kto on kto.fk_main_key= lex.fk_main_key',
'        left join t_rel_inv_inventar_zahlung invzahl on kto.fk_main_key = invzahl.fk_main_key',
'        left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar',
'        left join t_rel_proj_project_payment przahl on przahl.fk_main_key = kto.fk_main_key',
'        left join t_proj_projekt pr on pr.pk_proj_projekt = przahl.fk_proj_projekt',
'        left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'        left join (select sum(buchungsbetrag) sum_betrag, fk_main_key from t_lex where storno is null or storno = 0 group by fk_main_key ) lex_sum on lex_sum.fk_main_key = kto.fk_main_key',
'where (pk_lex =nvl(:P221_PK_LEX,0) or :P221_PK_LEX is null) and (belegnummer = nvl(:P221_Belegnummer,0) or :P221_Belegnummer is null) and (lex.fk_main_key = nvl(:P221_fk_main_key,0) or :P221_fk_main_key is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10001859202063589)
,p_name=>'lexware'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17871675167092970
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002120694063608)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002521196063612)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002983705063613)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003379208063614)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003684763063615)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004148494063615)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004506690063616)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004949462063617)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10005356799063618)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10006137111063619)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10006959789063619)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10007744503063620)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9745290849450869)
,p_db_column_name=>'BUCHTEXT'
,p_display_order=>25
,p_column_identifier=>'P'
,p_column_label=>'Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10008976003108520)
,p_db_column_name=>'OK'
,p_display_order=>35
,p_column_identifier=>'Q'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10009002661108521)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>45
,p_column_identifier=>'R'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10009094198108522)
,p_db_column_name=>'ID'
,p_display_order=>55
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10009188281108523)
,p_db_column_name=>'Buchungstag'
,p_display_order=>65
,p_column_identifier=>'T'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10009343255108524)
,p_db_column_name=>'Betrag'
,p_display_order=>75
,p_column_identifier=>'U'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010241243108533)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>165
,p_column_identifier=>'AD'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010300889108534)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>175
,p_column_identifier=>'AE'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010432648108535)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>185
,p_column_identifier=>'AF'
,p_column_label=>'Bucht tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010557812108536)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>195
,p_column_identifier=>'AG'
,p_column_label=>'Bucht monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010628797108537)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>205
,p_column_identifier=>'AH'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010747258108538)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>215
,p_column_identifier=>'AI'
,p_column_label=>'Bucht datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010846772108539)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>225
,p_column_identifier=>'AJ'
,p_column_label=>'Wertt tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010958037108540)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>235
,p_column_identifier=>'AK'
,p_column_label=>'Wertt monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10010985957108541)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>245
,p_column_identifier=>'AL'
,p_column_label=>'Wertt jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10011153163108542)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>255
,p_column_identifier=>'AM'
,p_column_label=>'Wertt datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10011481673108545)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>285
,p_column_identifier=>'AP'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10011559539108546)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>295
,p_column_identifier=>'AQ'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10011594057108547)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>305
,p_column_identifier=>'AR'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012082926108551)
,p_db_column_name=>'WERT'
,p_display_order=>325
,p_column_identifier=>'AT'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012134578108552)
,p_db_column_name=>'MWST'
,p_display_order=>335
,p_column_identifier=>'AU'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012291396108554)
,p_db_column_name=>'INVENTAR'
,p_display_order=>355
,p_column_identifier=>'AW'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012560304108556)
,p_db_column_name=>'PROJEKT'
,p_display_order=>375
,p_column_identifier=>'AY'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012605912108557)
,p_db_column_name=>'SEL_OK'
,p_display_order=>385
,p_column_identifier=>'AZ'
,p_column_label=>'Sel ok <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012729163108558)
,p_db_column_name=>'STORNO'
,p_display_order=>395
,p_column_identifier=>'BA'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10012854071108559)
,p_db_column_name=>'PK_LEX'
,p_display_order=>405
,p_column_identifier=>'BB'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10013762293108568)
,p_db_column_name=>'DIFF'
,p_display_order=>415
,p_column_identifier=>'BC'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10013876282108569)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>425
,p_column_identifier=>'BD'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10108960573646535)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>435
,p_column_identifier=>'BE'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10531567623994326)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>455
,p_column_identifier=>'BG'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10531958784994330)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>465
,p_column_identifier=>'BH'
,p_column_label=>'Sum betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52242871843941604)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>475
,p_column_identifier=>'BI'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52242947025941605)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>485
,p_column_identifier=>'BJ'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243006717941606)
,p_db_column_name=>'KTO_WAEHRUNG'
,p_display_order=>495
,p_column_identifier=>'BK'
,p_column_label=>'Kto Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243156467941607)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>505
,p_column_identifier=>'BL'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243210081941608)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>515
,p_column_identifier=>'BM'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243391200941609)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>525
,p_column_identifier=>'BN'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243426646941610)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>535
,p_column_identifier=>'BO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243558487941611)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>545
,p_column_identifier=>'BP'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243610791941612)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>555
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243740060941613)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>565
,p_column_identifier=>'BR'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243894103941614)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>575
,p_column_identifier=>'BS'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52243966550941615)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>585
,p_column_identifier=>'BT'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244091514941616)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>595
,p_column_identifier=>'BU'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244193346941617)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>605
,p_column_identifier=>'BV'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244276718941618)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>615
,p_column_identifier=>'BW'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244380236941619)
,p_db_column_name=>'IBAN'
,p_display_order=>625
,p_column_identifier=>'BX'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244420906941620)
,p_db_column_name=>'BANK'
,p_display_order=>635
,p_column_identifier=>'BY'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244511754941621)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>645
,p_column_identifier=>'BZ'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244668036941622)
,p_db_column_name=>'TBL'
,p_display_order=>655
,p_column_identifier=>'CA'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244710894941623)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>665
,p_column_identifier=>'CB'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244859612941624)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>675
,p_column_identifier=>'CC'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10008372610066000)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'178782'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_EURO:ZUSATZANGABE'
||'N:ID:VERWENDUNGSZWECK:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX::BEMERKUNGEN:BEZEICHNUNG:FK_IMP_BA_BEL:SUM_BETRAG:STEUERSCHLUESSEL:KOSTENTRAEGER:KTO_WAEHRUNG:WAEHRUNGSBETRAG:FREMDWAEHRUNG:FK'
||'_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:FK_KTO_BANKKONTO:KTO_BEZEICHNUNG:IBAN:BANK:DATUM_LEX_BUCHUNG_OK:TBL:PK_INV_INVENTAR:PK_PROJ_PROJEKT'
,p_break_on=>'SOLLKONTO'
,p_break_enabled_on=>'SOLLKONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10105056495640167)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10105430319640167)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10105882189640168)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10106214822640168)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10106633348640169)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10103435097640164)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKONTO'
,p_operator=>'='
,p_expr=>'1710'
,p_condition_sql=>'"HABENKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10103882705640165)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'is null'
,p_condition_sql=>'"KATEGORIE" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10104213781640166)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10104585945640166)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'='
,p_expr=>'6110'
,p_condition_sql=>'"SOLLKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10107034411640170)
,p_report_id=>wwv_flow_api.id(10008372610066000)
,p_name=>'Row text contains ''7.5'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'7.5'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10672541224561837)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Belegnummer'
,p_report_seq=>10
,p_report_alias=>'185424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:VERWENDUNGSZWECK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_'
||'EURO:ZUSATZANGABEN:ID:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX:BEMERKUNGEN:BEZEICHNUNG:BUCHT_DATUM:WERTT_DATUM:WERTT_JAHR:WERTT_MONAT:WERTT_TAG'
,p_sort_column_1=>'BELEGNUMMER'
,p_sort_direction_1=>'ASC'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11124364840488350)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11124685217488351)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11125101795488351)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11125552277488352)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11125906684488352)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>unistr('Steuerschl\00FCssel')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('STEUERSCHL\00DCSSEL')
,p_operator=>'is not null'
,p_condition_sql=>unistr(' (case when ("STEUERSCHL\00DCSSEL" is not null) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#EDEDED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11126352909488352)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11123531955488349)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'='
,p_expr=>'1251'
,p_condition_sql=>'"FK_MAIN_KEY" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11123974908488350)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"STORNO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11126783626488353)
,p_report_id=>wwv_flow_api.id(10672541224561837)
,p_name=>'Row text contains ''Fehlbuchung'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Fehlbuchung'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10013084742108562)
,p_plug_name=>'Kategorie'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>1
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto.kategorie,',
'sollkonto,',
'bezeichnung',
'--, lex. fk_main_key, kto.fk_main_key, pk_lex, fk_imp_ba_bel',
'ok',
'  from T_LEX lex',
'   left join v_kto_konten_zus kto on kto.fk_main_Key= lex.fk_main_key',
'   left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'where (storno is null or storno <> 1)',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10013187834108563)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17883003799137944
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10013318018108564)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10013424629108565)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11704192627273720)
,p_db_column_name=>'OK'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10080801104173626)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179507'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KATEGORIE:SOLLKONTO'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG:0:0:0:0'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10093044007380556)
,p_report_id=>wwv_flow_api.id(10080801104173626)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10092591763380556)
,p_report_id=>wwv_flow_api.id(10080801104173626)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'!='
,p_expr=>'1700'
,p_condition_sql=>'"SOLLKONTO" != to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10107471944646520)
,p_plug_name=>'sollkonto'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct Kontotyp,',
'sollkonto,',
'bezeichnung,',
'ok',
'  from T_LEX lex',
'   left join v_kto_konten_zus kto on kto.fk_buchung_steuer= lex.belegnummer',
'   left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'where (storno is null or storno <> 1) and (sollkonto between 1700 and 1900)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10107575268646521)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17977391233675902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10107686242646523)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10107880574646524)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10107942417646525)
,p_db_column_name=>'OK'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52242654036941602)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10117880214659982)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179877'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SOLLKONTO:BEZEICHNUNG:OK:KONTOTYP'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10108014716646526)
,p_plug_name=>'habenkonto'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct Kontotyp,',
'habenkonto,',
'',
'ok',
'  from T_LEX lex',
'   left join v_kto_konten_zus kto on kto.fk_buchung_steuer= lex.belegnummer',
'   left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'where (storno is null or storno <> 1) and (habenkonto between 1700 and 1900)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10108088122646527)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17977904087675908
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10108529934646531)
,p_db_column_name=>'OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10108813340646534)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52242727747941603)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10118427271659991)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179883'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:HABENKONTO:KONTOTYP'
,p_break_on=>'HABENKONTO'
,p_break_enabled_on=>'HABENKONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10124021732839644)
,p_report_id=>wwv_flow_api.id(10118427271659991)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10289864204418539)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11000562878679630)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10532046382994331)
,p_plug_name=>'lexware_bel'
,p_parent_plug_id=>wwv_flow_api.id(11000562878679630)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct BELEGDATUM',
',',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       lex.BUCHUNGSTEXT buchtext,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLueSSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRaeGER,',
'       BUCHUNGSBETRAG_EURO,',
'       lex.WaeHRUNG waehrung_lex,',
'       lex.ZUSATZANGABEN,',
'       lex.ok,',
'       ---',
'       ''Beleg'' art',
'       ,',
' kto.FK_kto_BUCHUNG,',
'null ID,',
' kto.DATUM,',
'kto.BETRAG,',
' kto.WaeHRUNG',
' ,',
'kto.WaeHRUNG_BETRAG,',
'null Fremdwaehrung,',
' kto.BEZEICHNUNG,',
'null FK_bas_Kat_Kategorie,',
'null FK_STD_VERW_Verwendungszweck,',
'null fk_STD_KTO_kontotyp,',
'null fk_BAS_KAL_buchungstag,',
'null fk_BAS_KAL_wertstellung,',
' kto.VERWENDUNGSZWECK,',
'null Kategorie,',
'null bucht_tag,',
'null bucht_monat,',
'null bucht_jahr,',
'null bucht_datum,',
'null wertt_tag,',
'null wertt_monat,',
'null wertt_jahr,',
'null wertt_datum,',
'null kontotyp,',
'null fk_KTO_vorgang,',
'null wiederholung,',
'null naechste_zahlung,',
'null fk_buchung_steuer,',
'kto.ART art2',
',',
' kto.PK_IMP_BA_ALLG_BEL,',
' kto.KENNZEICHEN,',
' kto.DATUM_VERGEHEN,',
'',
' kto.FK_BAS_KAL_ARBEITSTAG,',
' kto.ZAHLUNGSART,',
' kto.STEUERSATZ,',
' kto.MWST_BETRAG,',
' kto.NETTO,',
' kto.FK_INV_INVENTAR,',
' kto.FK_PROJ_PROJEKT,',
'       ',
'       ---',
'',
'     --  round(kto.Betrag,2) wert,',
'       apex_item.checkbox2(2, pk_lex) sel_ok,',
'       case when    STEUERSCHLUESSEL = 8 then ''7'' ',
'            when    STEUERSCHLUESSEL = 9 then ''19''',
'            else null',
'       end mwst,',
'       inv.pk_INV_inventar,',
'       inv.inventar,',
'       pr.pk_PROJ_projekt,',
'       pr.projekt,',
'       storno,',
'       pk_lex,',
'     --  lex_sum.sum_betrag - abs(round(kto.Betrag,2)) diff,',
'       lex.bemerkungen,',
'       konten.bezeichnung kto_bezeichnung,',
'       lex.fk_imp_ba_bel ,',
'       lex_sum.sum_betrag',
'       ',
'  from ',
'        T_LEX lex',
'        ',
'        left join v_imp_bel_zus kto on kto.fk_imp_ba_bel= lex.fk_imp_ba_bel',
'        left join t_rel_INV_inventar_zahlung invzahl on kto.fk_KTO_buchung = invzahl.fk_main_key',
'        left join t_INV_inventare inv on inv.pk_INV_inventar = invzahl.fk_INV_inventar',
'        left join t_rel_PROJ_projeCt_PAYMENT przahl on przahl.fk_main_key = kto.fk_KTO_buchung',
'        left join t_PROJ_projekt pr on pr.pk_PROJ_projekt = przahl.fk_PROJ_projekt',
'        left join t_LEX_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'        left join (select sum(buchungsbetrag) sum_betrag, fk_main_key from t_lex where storno is null or storno = 0 group by fk_main_key ) lex_sum on lex_sum.fk_main_key = kto.fk_KTO_buchung',
'where (pk_lex =nvl(:P221_PK_LEX,0) or :P221_PK_LEX is null) and (belegnummer = nvl(:P221_Belegnummer,0) or :P221_Belegnummer is null) and (lex.fk_main_key = nvl(:P221_fk_main_key,0) or :P221_fk_main_key is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10532323692994334)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18402139658023715
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10532467588994335)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10532836764994339)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10532946216994340)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>60
,p_column_identifier=>'C'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534055988994351)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>170
,p_column_identifier=>'D'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534416475994355)
,p_db_column_name=>'MWST'
,p_display_order=>210
,p_column_identifier=>'F'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534611009994357)
,p_db_column_name=>'INVENTAR'
,p_display_order=>230
,p_column_identifier=>'H'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534791751994359)
,p_db_column_name=>'PROJEKT'
,p_display_order=>250
,p_column_identifier=>'J'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534899690994360)
,p_db_column_name=>'SEL_OK'
,p_display_order=>260
,p_column_identifier=>'K'
,p_column_label=>'Sel ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10534988741994361)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>270
,p_column_identifier=>'L'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535107256994362)
,p_db_column_name=>'STORNO'
,p_display_order=>280
,p_column_identifier=>'M'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535253377994363)
,p_db_column_name=>'PK_LEX'
,p_display_order=>290
,p_column_identifier=>'N'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535395379994365)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>310
,p_column_identifier=>'P'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535521228994366)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>320
,p_column_identifier=>'Q'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535665845994367)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>330
,p_column_identifier=>'R'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535722879994368)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>340
,p_column_identifier=>'S'
,p_column_label=>'Sum betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10535804690994369)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>350
,p_column_identifier=>'T'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10581745772773120)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>360
,p_column_identifier=>'U'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10581871518773121)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>370
,p_column_identifier=>'V'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582079627773123)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>390
,p_column_identifier=>'W'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582118340773124)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>400
,p_column_identifier=>'X'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582185019773125)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>410
,p_column_identifier=>'Y'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582465386773127)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>430
,p_column_identifier=>'AA'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582680645773129)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>450
,p_column_identifier=>'AC'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582837377773131)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>470
,p_column_identifier=>'AE'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582965971773132)
,p_db_column_name=>'BUCHTEXT'
,p_display_order=>480
,p_column_identifier=>'AF'
,p_column_label=>'Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10583076382773133)
,p_db_column_name=>'OK'
,p_display_order=>490
,p_column_identifier=>'AG'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10584043594773143)
,p_db_column_name=>'WAEHRUNG_LEX'
,p_display_order=>500
,p_column_identifier=>'AH'
,p_column_label=>'Waehrung lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10584301241773146)
,p_db_column_name=>'ID'
,p_display_order=>530
,p_column_identifier=>'AK'
,p_column_label=>'Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10584390825773147)
,p_db_column_name=>'DATUM'
,p_display_order=>540
,p_column_identifier=>'AL'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585300838773156)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>630
,p_column_identifier=>'AU'
,p_column_label=>'Bucht tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585476817773157)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>640
,p_column_identifier=>'AV'
,p_column_label=>'Bucht monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585498104773158)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>650
,p_column_identifier=>'AW'
,p_column_label=>'Bucht jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585607042773159)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>660
,p_column_identifier=>'AX'
,p_column_label=>'Bucht datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585706160773160)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>670
,p_column_identifier=>'AY'
,p_column_label=>'Wertt tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585875064773161)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>680
,p_column_identifier=>'AZ'
,p_column_label=>'Wertt monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585943934773162)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>690
,p_column_identifier=>'BA'
,p_column_label=>'Wertt jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586046065773163)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>700
,p_column_identifier=>'BB'
,p_column_label=>'Wertt datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586166131773164)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>710
,p_column_identifier=>'BC'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586310171773166)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>730
,p_column_identifier=>'BE'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586474562773167)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>740
,p_column_identifier=>'BF'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586535999773168)
,p_db_column_name=>'ART'
,p_display_order=>750
,p_column_identifier=>'BG'
,p_column_label=>'Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586640915773169)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>760
,p_column_identifier=>'BH'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586684345786720)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>770
,p_column_identifier=>'BI'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10586796180786721)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>780
,p_column_identifier=>'BJ'
,p_column_label=>'Datum vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10587040636786723)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>800
,p_column_identifier=>'BL'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10587176947786724)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>810
,p_column_identifier=>'BM'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10587243164786725)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>820
,p_column_identifier=>'BN'
,p_column_label=>'Mwst betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10587327854786726)
,p_db_column_name=>'NETTO'
,p_display_order=>830
,p_column_identifier=>'BO'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10587615694786729)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>860
,p_column_identifier=>'BR'
,p_column_label=>'Kto bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968852865648268)
,p_db_column_name=>'BETRAG'
,p_display_order=>870
,p_column_identifier=>'BS'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10999542918679620)
,p_db_column_name=>'ART2'
,p_display_order=>890
,p_column_identifier=>'BU'
,p_column_label=>'Art2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52244990163941625)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>900
,p_column_identifier=>'BV'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245029924941626)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>910
,p_column_identifier=>'BW'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245185059941627)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>920
,p_column_identifier=>'BX'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245200797941628)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>930
,p_column_identifier=>'BY'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245382481941629)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>940
,p_column_identifier=>'BZ'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245497968941630)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>950
,p_column_identifier=>'CA'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245545227941631)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>960
,p_column_identifier=>'CB'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245698122941632)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>970
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245738102941633)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>980
,p_column_identifier=>'CD'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245844471941634)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>990
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52245976752941635)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>1000
,p_column_identifier=>'CF'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246018328941636)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>1010
,p_column_identifier=>'CG'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246130864941637)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1020
,p_column_identifier=>'CH'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246201276941638)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>1030
,p_column_identifier=>'CI'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246378399941639)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>1040
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246420102941640)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>1050
,p_column_identifier=>'CK'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52246503617941641)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>1060
,p_column_identifier=>'CL'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10616849895789887)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'184867'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGDATUM:VERWENDUNGSZWECK:KATEGORIE:WIEDERHOLUNG:MWST:INVENTAR:PROJEKT:SEL_OK:BUCHUNGSDATUM:STORNO:PK_LEX:BEMERKUNGEN:BEZEICHNUNG:FK_IMP_BA_BEL:SUM_BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BELEGNUMMER:BUCHUNGSSOLLKONTO:HABENKONTO:KOSTENSTELLE:BUCHUNGSBETR'
||'AG_EURO:ZUSATZANGABEN:BUCHTEXT:OK_LEX:ID:DATUM:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:KONTOTYP:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:ART:PK_IMP_BA_ALLG_BEL:KENNZEICHEN:DATUM_VERGEHEN:ZAHLUNGSART:STEUERS'
||'ATZ:MWST_NETTO:KTO_BEZEICHNUNG:BETRAG:ART2:STEUERSCHLUESSEL:KOSTENTRAEGER:FK_KTO_BUCHUNG:WAEHRUNG:WAEHRUNG_BETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KT'
||'O_VORGANG:FK_BAS_KAL_ARBEITSTAG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:PK_INV_INVENTAR:PK_PROJ_PROJEKT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10617739431838301)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'buch'
,p_report_seq=>10
,p_report_alias=>'184876'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:SEL_OK:ART:PK_LEX:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BELEGNUMMER:VERWENDUNGSZWECK:BEZEICHNUNG:BUCHTEXT:DATUM:BELEGDATUM:BUCHUNGSDATUM:BUCHUNGSBETRAG:BETRAG:STEUERSATZ:KATEGORIE:HABENKONTO:ZAHLUNGSART:KOSTENSTELLE:PROJEKT:INVENTAR:STORNO:BEMERKUNGEN:'
||'BELEGNUMMERNKREIS:SOLLKONTO:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:WAEHRUNG_LEX:ID:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:KONTOTYP:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:KENNZEICHEN:DATUM_VERGEHEN:KTO_BEZEICH'
||'NUNG:WIEDERHOLUNG:ART2:MWST'
,p_break_on=>'SOLLKONTO:KTO_BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:KTO_BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11127812513510414)
,p_report_id=>wwv_flow_api.id(10617739431838301)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11127406598510414)
,p_report_id=>wwv_flow_api.id(10617739431838301)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10011838718108549)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10001688587063589)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10292853399418569)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10001688587063589)
,p_button_name=>'back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Back'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:219:&SESSION.::&DEBUG.:RP:P219_BELEGNUMMER,P219_FK_BUCHUNG,P219_PK_LEX,P219_FK_MAIN_KEY:,,,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10012946074108560)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10001688587063589)
,p_button_name=>'Storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Storno'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10290141321418542)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10289864204418539)
,p_button_name=>'RESET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Reset filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10290911811418550)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(10289864204418539)
,p_button_name=>'SET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10532149984994332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10532046382994331)
,p_button_name=>'OK_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Ok_PK'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10532191278994333)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10532046382994331)
,p_button_name=>'Storno_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Storno_PK'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11109250735768895)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(11000562878679630)
,p_button_name=>'Belegzuordnung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Belegzuordnung'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10289913759418540)
,p_name=>'P221_PK_LEX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10289864204418539)
,p_prompt=>'Pk lex'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10290015154418541)
,p_name=>'P221_BELEGNUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10289864204418539)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Belegnummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10531694780994328)
,p_name=>'P221_FK_MAIN_KEY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(10289864204418539)
,p_prompt=>'Fk main key'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11108897409766692)
,p_name=>'P221_FK_IMP_BA_BEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11000562878679630)
,p_prompt=>'Fk imp ba bel'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select art || '' '' || fk_imp_ba_bel || '' '' || datum || '' '' || bezeichnung || '' '' || betrag, fk_imp_ba_bel',
'from v_imp_bel_zus',
'where instr(bezeichnung, :P219_Buchungstext)>0 or :P219_Buchungstext is null'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10290282611418543)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10290141321418542)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10290373545418544)
,p_event_id=>wwv_flow_api.id(10290282611418543)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10290456814418545)
,p_event_id=>wwv_flow_api.id(10290282611418543)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10291593440418557)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10290911811418550)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10291766253418558)
,p_event_id=>wwv_flow_api.id(10291593440418557)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_03=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10291827550418559)
,p_event_id=>wwv_flow_api.id(10291593440418557)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10011978216108550)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_lex set ok =1, datum_ok = sysdate where pk_lex = apex_application.g_f01(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10011838718108549)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11000408669679629)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'      update t_lex set ok =1, datum_ok = sysdate where pk_lex = apex_application.g_f02(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10532149984994332)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10013040550108561)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Storno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_lex set storno =1 where pk_lex = apex_application.g_f01(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10012946074108560)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11000608563679631)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Storno_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'      update t_lex set storno =1 where pk_lex = apex_application.g_f02(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10532191278994333)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11109468880771799)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_kontotyp varchar2(400 char);',
' v_cnt number;',
'begin',
'  ',
'',
'',
'   for i in 1..apex_application.g_f02.count loop',
'   ',
'     if apex_application.g_f02(i) is not null then',
'     ',
'        insert into test select 1, apex_application.g_f02(i),1 from dual; commit;',
'     ',
'        ',
'            insert into test select i, apex_application.g_f02(i), :P219_fk_buchung from dual; commit;',
'   ',
'            update t_lex set fk_imp_ba_bel =  :P221_fk_imp_ba_bel where pk_lex  = apex_application.g_f02(i) ;',
'           commit;',
'     ',
'     end if;',
'   ',
'   end loop;',
'   ',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11109250735768895)
);
wwv_flow_api.component_end;
end;
/
