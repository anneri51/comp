prompt --application/pages/page_00224
begin
--   Manifest
--     PAGE: 00224
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>224
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Belege'
,p_step_title=>'Belege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309772283708404)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200623103752'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10830284721608205)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct BELEGDATUM',
',',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       lex.BUCHUNGSTEXT buchtext,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLueSSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRaeGER,',
'       BUCHUNGSBETRAG_EURO,',
'       lex.WaeHRUNG waehrung_lex,',
'       lex.ZUSATZANGABEN,',
'       lex.ok,',
'       ---',
'       ''Beleg'' art',
'       ,',
' kto.FK_kto_BUCHUNG,',
'null ID,',
' kto.DATUM,',
'kto.BETRAG,',
' kto.WaeHRUNG',
' ,',
'kto.WaeHRUNG_BETRAG,',
'null Fremdwaehrung,',
' kto.BEZEICHNUNG,',
'null FK_bas_kat_Kategorie,',
'null FK_std_verw_Verwendungszweck,',
'null fk_bas_kto_kontotyp,',
'null fk_bas_kal_buchungstag,',
'null fk_bas_kal_wertstellung,',
' kto.VERWENDUNGSZWECK,',
'null Kategorie,',
'null bucht_tag,',
'null bucht_monat,',
'null bucht_jahr,',
'null bucht_datum,',
'null wertt_tag,',
'null wertt_monat,',
'null wertt_jahr,',
'null wertt_datum,',
'null kontotyp,',
'null fk_kto_vorgang,',
'null wiederholung,',
'null naechste_zahlung,',
'null fk_buchung_steuer,',
'kto.ART art2',
',',
' kto.PK_IMP_BA_ALLG_BEL,',
' kto.KENNZEICHEN,',
' kto.DATUM_VERGEHEN,',
'',
' kto.FK_bas_kal_ARBEITSTAG,',
' kto.ZAHLUNGSART,',
' kto.STEUERSATZ,',
' kto.MWST_BETRAG,',
' kto.NETTO,',
' kto.FK_inv_INVENTAR,',
' kto.FK_proj_PROJEKT,',
'       ',
'       ---',
'',
'     --  round(kto.Betrag,2) wert,',
'       apex_item.checkbox2(1, pk_lex) sel_ok,',
'       case when    STEUERSCHLueSSEL = 8 then ''7'' ',
'            when    STEUERSCHLueSSEL = 9 then ''19''',
'            else null',
'       end mwst,',
'       inv.pk_inv_inventar,',
'       inv.inventar,',
'       pr.pk_proj_projekt,',
'       pr.projekt,',
'       storno,',
'       pk_lex,',
'     --  lex_sum.sum_betrag - abs(round(kto.Betrag,2)) diff,',
'       lex.bemerkungen,',
'       konten.bezeichnung kto_bezeichnung,',
'       lex.fk_imp_ba_bel ,',
'       lex_sum.sum_betrag',
'       ',
'  from ',
'        T_LEX lex',
'        ',
'        left join v_imp_bel_zus kto on kto.fk_imp_ba_bel= lex.fk_imp_ba_bel',
'        left join t_rel_inv_inventar_zahlung invzahl on kto.fk_kto_buchung = invzahl.fk_main_key',
'        left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar',
'        left join t_rel_proj_project_payment przahl on przahl.fk_main_key = kto.fk_kto_buchung',
'        left join t_proj_projekt pr on pr.pk_proj_projekt = przahl.fk_proj_projekt',
'        left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'        left join (select sum(buchungsbetrag) sum_betrag, fk_main_key from t_lex where storno is null or storno = 0 group by fk_main_key ) lex_sum on lex_sum.fk_main_key = kto.fk_kto_buchung',
'--where (pk_lex =nvl(:P221_PK_LEX,0) or :P221_PK_LEX is null) and (belegnummer = nvl(:P221_Belegnummer,0) or :P221_Belegnummer is null) and (lex.fk_main_key = nvl(:P221_fk_main_key,0) or :P221_fk_main_key is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10830477151608205)
,p_name=>'Belege'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18700293116637586
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10830815885608214)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759258705556449)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>11
,p_column_identifier=>'Q'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759314130556450)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>21
,p_column_identifier=>'P'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759480095556451)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>31
,p_column_identifier=>'O'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759559969556452)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>41
,p_column_identifier=>'N'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759678451556453)
,p_db_column_name=>'BUCHTEXT'
,p_display_order=>51
,p_column_identifier=>'M'
,p_column_label=>'Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759692768556454)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>61
,p_column_identifier=>'L'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759812869556455)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>71
,p_column_identifier=>'K'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10759914160556456)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>81
,p_column_identifier=>'J'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760126383556458)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>101
,p_column_identifier=>'H'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760325096556460)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>121
,p_column_identifier=>'F'
,p_column_label=>'Buchungsbetrag euro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760388612556461)
,p_db_column_name=>'WAEHRUNG_LEX'
,p_display_order=>131
,p_column_identifier=>'E'
,p_column_label=>'Waehrung lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760495705556462)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>141
,p_column_identifier=>'D'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760681486556463)
,p_db_column_name=>'OK'
,p_display_order=>151
,p_column_identifier=>'C'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760767610556464)
,p_db_column_name=>'ART'
,p_display_order=>161
,p_column_identifier=>'B'
,p_column_label=>'Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10760969507556466)
,p_db_column_name=>'ID'
,p_display_order=>181
,p_column_identifier=>'U'
,p_column_label=>'Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10761014120556467)
,p_db_column_name=>'DATUM'
,p_display_order=>191
,p_column_identifier=>'T'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10761181675556468)
,p_db_column_name=>'BETRAG'
,p_display_order=>201
,p_column_identifier=>'S'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10964193023648222)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>241
,p_column_identifier=>'AR'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10964815730648228)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>301
,p_column_identifier=>'AL'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10964891490648229)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>311
,p_column_identifier=>'AK'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965056360648230)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>321
,p_column_identifier=>'AJ'
,p_column_label=>'Bucht tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965173034648231)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>331
,p_column_identifier=>'AI'
,p_column_label=>'Bucht monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965190736648232)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>341
,p_column_identifier=>'AH'
,p_column_label=>'Bucht jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965367882648233)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>351
,p_column_identifier=>'AG'
,p_column_label=>'Bucht datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965389396648234)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>361
,p_column_identifier=>'AF'
,p_column_label=>'Wertt tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965545452648235)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>371
,p_column_identifier=>'AE'
,p_column_label=>'Wertt monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965598446648236)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>381
,p_column_identifier=>'AD'
,p_column_label=>'Wertt jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965734674648237)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>391
,p_column_identifier=>'AC'
,p_column_label=>'Wertt datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10965804784648238)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>401
,p_column_identifier=>'AB'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966066381648240)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>421
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966157563648241)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>431
,p_column_identifier=>'Y'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966282882648242)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>441
,p_column_identifier=>'X'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966334340648243)
,p_db_column_name=>'ART2'
,p_display_order=>451
,p_column_identifier=>'W'
,p_column_label=>'Art2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966422020648244)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>461
,p_column_identifier=>'BR'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966508994648245)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>471
,p_column_identifier=>'BQ'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966614049648246)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>481
,p_column_identifier=>'BP'
,p_column_label=>'Datum vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966878810648248)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>501
,p_column_identifier=>'BN'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966892407648249)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>511
,p_column_identifier=>'BM'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967011476648250)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>521
,p_column_identifier=>'BL'
,p_column_label=>'Mwst betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967126894648251)
,p_db_column_name=>'NETTO'
,p_display_order=>531
,p_column_identifier=>'BK'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967501358648255)
,p_db_column_name=>'SEL_OK'
,p_display_order=>571
,p_column_identifier=>'BG'
,p_column_label=>'Sel ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967661436648256)
,p_db_column_name=>'MWST'
,p_display_order=>581
,p_column_identifier=>'BF'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967787968648258)
,p_db_column_name=>'INVENTAR'
,p_display_order=>601
,p_column_identifier=>'BD'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967993685648260)
,p_db_column_name=>'PROJEKT'
,p_display_order=>621
,p_column_identifier=>'BB'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968129776648261)
,p_db_column_name=>'STORNO'
,p_display_order=>631
,p_column_identifier=>'BA'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968235843648262)
,p_db_column_name=>'PK_LEX'
,p_display_order=>641
,p_column_identifier=>'AZ'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968404518648264)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>661
,p_column_identifier=>'AX'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968580529648265)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>671
,p_column_identifier=>'AW'
,p_column_label=>'Kto bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968629611648266)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>681
,p_column_identifier=>'AV'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10968782351648267)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>691
,p_column_identifier=>'AU'
,p_column_label=>'Sum betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331042346550305)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>701
,p_column_identifier=>'BS'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331172127550306)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>711
,p_column_identifier=>'BT'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331208511550307)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>721
,p_column_identifier=>'BU'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331396525550308)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>731
,p_column_identifier=>'BV'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331480130550309)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>741
,p_column_identifier=>'BW'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331517723550310)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>751
,p_column_identifier=>'BX'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331696136550311)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>761
,p_column_identifier=>'BY'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331705129550312)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>771
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331898571550313)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>781
,p_column_identifier=>'CA'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52331932078550314)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>791
,p_column_identifier=>'CB'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332027638550315)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>801
,p_column_identifier=>'CC'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332187603550316)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>811
,p_column_identifier=>'CD'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332211281550317)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>821
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332399875550318)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>831
,p_column_identifier=>'CF'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332416607550319)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>841
,p_column_identifier=>'CG'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332541786550320)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>851
,p_column_identifier=>'CH'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332654263550321)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>861
,p_column_identifier=>'CI'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10908926447618129)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'187788'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('BELEGART:OK:ZUSATZANGABEN_LEX_EURO:KOSTENSTELLE:HABENKONTO:SOLLKONTO:BUCHUNGSBUCHTEXT:BELEGNUMMER:BELEGNUMMERNKREIS:BUCHUNGSPERIODE:BUCHUNGSW\00C4HRUNG:BETRAG:DATUM:ID:ART2:FK_BUCHUNG_STEUER:NAECHSTE_ZAHLUNG:WIEDERHOLUNG:KONTOTYPT_DATUMT_JAHRT_MONATT_TAG')
||':BUCHT_DATUM:BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:KATEGORIE:VERWENDUNGSZWECK:BEZEICHNUNG:SUM_BETRAG:FK_IMP_BA_BEL:KTO_BEZEICHNUNG:BEMERKUNGEN:PK_LEX:STORNO:PROJEKT:INVENTAR:MWST:SEL_OK:NETTO:MWST_BETRAG:STEUERSATZ:ZAHLUNGSART:DATUM_VERGEHEN:KENNZEICHEN:P'
||'K_IMP_BA_ALLG_BEL:STEUERSCHLUESSEL:KOSTENTRAEGER:FK_KTO_BUCHUNG:WAEHRUNG:WAEHRUNG_BETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KTO_VORGANG:FK_BAS_KAL_ARBE'
||'ITSTAG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:PK_INV_INVENTAR:PK_PROJ_PROJEKT'
);
wwv_flow_api.component_end;
end;
/
