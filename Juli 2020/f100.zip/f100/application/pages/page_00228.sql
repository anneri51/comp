prompt --application/pages/page_00228
begin
--   Manifest
--     PAGE: 00228
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>228
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Beleg'
,p_step_title=>'Beleg'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309772283708404)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200628153032'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1800643920991714)
,p_plug_name=>'Ordner_Auswahl'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ord.PK_ABL_ORDNER,',
' ord_page.PK_ABL_ORDNER_page,',
'         ord.JAHR,',
'        ord.ORDNER_NAME,',
'        ord_page.page_number,',
'        case when pk_abl_ordner_page = :P228_PK_ABL_ORDNER_PAGE then 1 else 0 end sel',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1800740347991715)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:228:&SESSION.::&DEBUG.:RP,228:P228_PK_ABL_ORDNER,P228_PK_ABL_ORDNER_PAGE:#PK_ABL_ORDNER#,#PK_ABL_ORDNER_PAGE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>1800740347991715
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1800877513991716)
,p_db_column_name=>'PK_ABL_ORDNER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1800945949991717)
,p_db_column_name=>'JAHR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1801086842991718)
,p_db_column_name=>'ORDNER_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1801724338991725)
,p_db_column_name=>'PAGE_NUMBER'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>'Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1801943810991727)
,p_db_column_name=>'PK_ABL_ORDNER_PAGE'
,p_display_order=>50
,p_column_identifier=>'K'
,p_column_label=>'Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3594518100537542)
,p_db_column_name=>'SEL'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1943527244093592)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'19436'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR:ORDNER_NAME:PAGE_NUMBER::SEL'
,p_sort_column_1=>'PAGE_NUMBER'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3898957862887478)
,p_report_id=>wwv_flow_api.id(1943527244093592)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3898586165887478)
,p_report_id=>wwv_flow_api.id(1943527244093592)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(3899319469887487)
,p_report_id=>wwv_flow_api.id(1943527244093592)
,p_pivot_columns=>'ORDNER_NAME'
,p_row_columns=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(3899791136887489)
,p_pivot_id=>wwv_flow_api.id(3899319469887487)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'PK_ABL_ORDNER'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1954886075201626)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Jahr'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'19549'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_ABL_ORDNER:JAHR:ORDNER_NAME:PAGE_NUMBER'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(1955237394201651)
,p_report_id=>wwv_flow_api.id(1954886075201626)
,p_pivot_columns=>'ORDNER_NAME'
,p_row_columns=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(1955665642201651)
,p_pivot_id=>wwv_flow_api.id(1955237394201651)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'PK_ABL_ORDNER'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14036989912507550)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12151259463894510)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(14036989912507550)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    apex_item.checkbox2(1,  inp_bel."PK_INP_BELEGE_ALL") sel,',
'    inp_bel."PK_INP_BELEGE_ALL", ',
'    inp_bel."FK_LEX_BUCHUNG",',
'    inp_bel.FK_BAS_KAT_KATEGORIE,',
'    inp_bel."FK_BAS_KAL_ARBEITSTAG",',
'    inp_bel."FK_KTO_BUCHUNG",',
'    inp_bel."FK_STD_KTO_ZAHLUNGSART",',
'    inp_bel."FK_STD_VERW_VERWENDUNGSZWECK",',
'    inp_bel."FK_INV_INVENTAR",',
'    inp_bel."FK_PROJ_PROJEKT",',
'    inp_bel."BELEGNUMMER",',
'    inp_bel."BEZEICHNUNG",',
'    inp_bel."FK_ADR_LAND",',
'    inp_bel."FK_ADR_CITY",',
'    inp_bel."BEL_DATUM",',
'    inp_bel."VON",',
'    inp_bel."BIS",',
'    inp_bel."NETTO_BETRAG",',
'    inp_bel."FK_BAS_STEU_STEUER_SATZ",',
'    inp_bel."MWST_BETRAG",',
'    inp_bel."BRUTTO_BETRAG",',
'    inp_bel."FK_BAS_MON_WAEHRUNG",',
'    inp_bel."STEUERNUMMER",',
'    inp_bel."FK_BAS_MON_UMRECHNUNGSKURS",',
'    dbms_lob.substr(inp_bel."COMM_REST_BELEG",4000,1) "COMM_REST_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_TEL_BELEG",4000,1) "COMM_TEL_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_PRODUKTE",4000,1) "COMM_PRODUKTE",',
unistr('    dbms_lob.substr(inp_bel."COMM_BEGRUENDUNG",4000,1) "COMM_BEGR\00DCNDUNG",'),
'    dbms_lob.substr(inp_bel."COMM_SONSTIGES",4000,1) "COMM_SONSTIGES",',
'    dbms_lob.getlength("BELEG") "BELEG",',
'    dbms_lob.getlength("ZAHLUNGSBELEG") "ZAHLUNGSBELEG",',
'    inp_bel."LITER",',
'    inp_bel."ZAPFSAEULE",',
'    inp_bel.FK_loc_LOCATION,',
'    inp_bel.PERSOENLICH_VOR_ORT,',
'    inp_bel.fk_bel_beleg_ablage,',
'    abl_ord.jahr jahr_ordner,',
'    abl_ord.ordner_name,',
'    abl_ord_p.page_number,',
'    inp_bel.cnt_punkte,',
'    inp_bel.cnt_punkte_geschaetzt,',
'    inp_bel.punkte_von,',
'    inp_bel.punkte_bis,',
'    inv.inventar,',
'     kat.Kategorie,',
'     pr.projekt,',
'     verw.std_name verwendungszweck,',
'     bel.cnt_lex,',
'     inp_bel.FK_IMP_BA_BEL_OLD,',
'     inp_bel.fk_std_inp_status,',
'     inp_bel.fk_std_inp_zahlungsstatus,',
'     inp_bel.fk_kon_geschaeftspartner,',
'     cnt_rel,',
'     cnt_rel_det,',
'     case when det is null then ''0'' else det end det,',
'     ''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':273:'' || V(''APP_SESSION'') || ''::NO:RP:P273_PK_PROJEKT,P273_PK_LOCATION,P273_PK_INP_BELEGE_ALL:'' || ',
'                                          inp_bel.fk_proj_projekt || '','' || inp_bel.fk_loc_location || '','' ||  pk_inp_belege_all , P_CHECKSUM_TYPE => ''SESSION'') || ''">'' || fk_loc_location || ''</a>'' fk_loc_location1,',
'     vloc.ort,',
'     vloc.strasse,',
'     vloc.hsnr,',
'     vloc.land,',
'     vloc.ort loc_ort,',
'     case when datum_ort_ok is not null or datum_addresse_ok is not null or datum_bussgeld_ok is not null or datum_beleg_pos_ok is not null or datum_buchung_ok is not null  or datum_verpfl_bel_ok is not null then 1 else 0 end flg_kontr_bel_ok,',
'     ''ort_ok: <b><span style="color:green">'' || nvl( to_char(datum_ort_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> addresse_ok <b><span style="color:green">'' ||  nvl(to_char(datum_addresse_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) ||  ',
'     ''</b> bussgeld_ok <b><span style="color:green">'' || nvl(to_char(datum_bussgeld_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> beleg_pos_ok <b><span style="color:green">'' || nvl(to_char(datum_beleg_pos_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> buchung_ok <b><span style="color:green">'' || nvl(to_char(datum_buchung_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'')  || ''</span>'' || ''</b>'' || chr(10) ||',
'     ''</b> verpfl_bel_ok <b><span style="color:green">'' || nvl(to_char(datum_verpfl_bel_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'')  || ''</span>'' || ''</b>'' || chr(10) ',
'     ',
'     kontr_bel_ok',
', cnt_bel_pos',
'from t_INP_BELEGE_ALL inp_bel',
'  left join t_abl_ordner_page abl_ord_p on inp_bel.fk_abl_ordner_page = abl_ord_p.pk_abl_ordner_page',
'  left join t_abl_ordner abl_ord on abl_ord_p.fk_abl_ordner = abl_ord.pk_abl_ordner',
'  left join t_INV_inventare inv on inp_bel.fk_Inv_inventar = inv.pk_inv_inventar',
'  left join t_proj_projekt pr on pr.pk_proj_projekt = inp_bel.fk_proj_projekt',
'  left join t_bas_kat_konto_buch kat on kat.pk_bas_kat_konto_buch = inp_bel.fk_bas_kat_kategorie',
'  left join (select * from t_std where fk_std_group = 9) verw on verw.std_value = inp_bel.fk_std_verw_verwendungszweck',
'  left join v_loc_location vloc on vloc.pk_loc_location = inp_bel.fk_loc_location',
'  left join (select fk_inp_belege_all , case when count(*)  >0 then 1 else 0 end cnt_lex from  T_REL_LEX_KTO_BEL group by fk_inp_belege_all ) bel on inp_bel.pk_inp_belege_all = bel.fk_inp_belege_all ',
'  left join ( ',
'                    select fk_inp_belege_all',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) cnt_rel,',
'                     sum(case when fk_lex_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) cnt_rel_det,',
'                     listagg( ''('' || rnr || ''/'' || det_cnt_rel_det || '') ok: '' || det_sum_rel,'', - '') within group ( order by fk_inp_belege_all) det',
'                     ',
'                     ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      left join (',
'                          select fk_inp_belege_all det',
'                          --, pk_rel_lex_kto_bel det1',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) det_cnt_rel,',
'                     sum(case when fk_lex_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) det_cnt_rel_det,',
'                     row_number() over (partition by  fk_inp_belege_all order by fk_inp_belege_all) rnr,',
'                    sum(case when fk_lex_relation is not null then 1 else 0 end) det_sum_rel                ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      group by fk_inp_belege_all, pk_rel_lex_kto_bel',
'                      ',
'                      ) relbel_det on relbel_det.det = relbel.fk_inp_belege_all',
'                    group by fk_inp_belege_all',
'                    ',
'           ) ktobel on inp_bel.pk_inp_belege_all = ktobel.fk_inp_belege_all',
'  left join (select fk_inp_belege_all, count(*) cnt_bel_pos from t_inp_belege_pos_all group by fk_inp_belege_all) inp_pos on inp_pos.fk_inp_belege_all = inp_bel.pk_inp_belege_all',
'where (inp_bel.fk_abl_ordner_page =:P228_PK_ABL_ORDNER_PAGE or :P228_PK_ABL_ORDNER_PAGE is null )',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12151644956894511)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&APP_SESSION.::::P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>20021460921923892
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12151774471894522)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:349:&SESSION.::&DEBUG.:RP:P349_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12152170778894526)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12155308154894535)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12155764187894536)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP:P373_ZIEL_PK_INP_BELEGE_ALL,P373_SRC_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1:#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#,,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12156928837894539)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12157334064894540)
,p_db_column_name=>'VON'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12157739908894541)
,p_db_column_name=>'BIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12158166952894544)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12159214387894550)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12160802926894556)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12161203686894558)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12161600851894559)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12162062348894560)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12162412596894562)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12162837454894569)
,p_db_column_name=>'BELEG'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:INP_BELEGE_ALL:BELEG:PK_INP_BELEGE_ALL'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12163242121894570)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:INP_BELEGE_ALL:ZAHLUNGSBELEG:PK_INP_BELEGE_ALL'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12163646476894571)
,p_db_column_name=>'LITER'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12222737659251520)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>52
,p_column_identifier=>'AH'
,p_column_label=>'Mwst betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12607416026138056)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>82
,p_column_identifier=>'AK'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13234774150544956)
,p_db_column_name=>'JAHR_ORDNER'
,p_display_order=>122
,p_column_identifier=>'AO'
,p_column_label=>'Jahr ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13234795365544957)
,p_db_column_name=>'ORDNER_NAME'
,p_display_order=>132
,p_column_identifier=>'AP'
,p_column_label=>'Ordner name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13234958202544958)
,p_db_column_name=>'PAGE_NUMBER'
,p_display_order=>142
,p_column_identifier=>'AQ'
,p_column_label=>'Page number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235004004544959)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>152
,p_column_identifier=>'AR'
,p_column_label=>'Cnt punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235132665544960)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>162
,p_column_identifier=>'AS'
,p_column_label=>'Cnt punkte geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235238768544961)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>172
,p_column_identifier=>'AT'
,p_column_label=>'Punkte von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235374568544962)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>182
,p_column_identifier=>'AU'
,p_column_label=>'Punkte bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235390958544963)
,p_db_column_name=>'INVENTAR'
,p_display_order=>192
,p_column_identifier=>'AV'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235644705544965)
,p_db_column_name=>'PROJEKT'
,p_display_order=>212
,p_column_identifier=>'AX'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13235725623544966)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>222
,p_column_identifier=>'AY'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14036959374507549)
,p_db_column_name=>'SEL'
,p_display_order=>232
,p_column_identifier=>'AZ'
,p_column_label=>'sel <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1768894659274009)
,p_db_column_name=>'CNT_LEX'
,p_display_order=>242
,p_column_identifier=>'BA'
,p_column_label=>'Cnt Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2045372142337107)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>252
,p_column_identifier=>'BB'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4027400661640543)
,p_db_column_name=>'CNT_REL'
,p_display_order=>282
,p_column_identifier=>'BE'
,p_column_label=>'Cnt Rel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4027508503640544)
,p_db_column_name=>'CNT_REL_DET'
,p_display_order=>292
,p_column_identifier=>'BF'
,p_column_label=>'Cnt Rel Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4027662315640545)
,p_db_column_name=>'DET'
,p_display_order=>302
,p_column_identifier=>'BG'
,p_column_label=>'Det'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#DET#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6189328890462312)
,p_db_column_name=>'ORT'
,p_display_order=>322
,p_column_identifier=>'BI'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6189461168462313)
,p_db_column_name=>'STRASSE'
,p_display_order=>332
,p_column_identifier=>'BJ'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6189543992462314)
,p_db_column_name=>'HSNR'
,p_display_order=>342
,p_column_identifier=>'BK'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6189625502462315)
,p_db_column_name=>'LAND'
,p_display_order=>352
,p_column_identifier=>'BL'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6189730148462316)
,p_db_column_name=>'LOC_ORT'
,p_display_order=>362
,p_column_identifier=>'BM'
,p_column_label=>'Loc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15179049646814412)
,p_db_column_name=>'FLG_KONTR_BEL_OK'
,p_display_order=>372
,p_column_identifier=>'BN'
,p_column_label=>'Flg Kontr Bel Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15179148895814413)
,p_db_column_name=>'KONTR_BEL_OK'
,p_display_order=>382
,p_column_identifier=>'BO'
,p_column_label=>'Kontr Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45927910456806646)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>412
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45928270575806649)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>442
,p_column_identifier=>'BU'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45928332671806650)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>452
,p_column_identifier=>'BV'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120032919988301)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>462
,p_column_identifier=>'BW'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120176179988302)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>472
,p_column_identifier=>'BX'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120558120988306)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>512
,p_column_identifier=>'CB'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120735472988308)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>532
,p_column_identifier=>'CD'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120873422988309)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>542
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46120927394988310)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>552
,p_column_identifier=>'CF'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47124449423356106)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>562
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47124549278356107)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>572
,p_column_identifier=>'CK'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47124851620356110)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>602
,p_column_identifier=>'CN'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47124933433356111)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>612
,p_column_identifier=>'CO'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47125047578356112)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>622
,p_column_identifier=>'CP'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47125195655356113)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>632
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47125466160356116)
,p_db_column_name=>'FK_LOC_LOCATION1'
,p_display_order=>662
,p_column_identifier=>'CT'
,p_column_label=>'Fk Loc Location1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52332998152550324)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>682
,p_column_identifier=>'CW'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52674891436060941)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>692
,p_column_identifier=>'CX'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52674929084060942)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>702
,p_column_identifier=>'CY'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52675396606060946)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>712
,p_column_identifier=>'CZ'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52675414021060947)
,p_db_column_name=>'CNT_BEL_POS'
,p_display_order=>722
,p_column_identifier=>'DA'
,p_column_label=>'Cnt Bel Pos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52908744479684905)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>732
,p_column_identifier=>'DB'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12222119808247448)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'200920'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:BRUTTO_BETRAG:DET:PK_INP_BELEGE_ALL:FLG_KONTR_BEL_OK:KONTR_BEL_OK:BEZEICHNUNG:SEL:FK_IMP_BA_BEL_OLD:CNT_REL:FK_LEX_BUCHUNG:FK_FK_ARBEITSTAG:BEL_DATUM:VON:BIS:NETTO_BETRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKT'
||unistr('E:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:MWST_BETRAG:CNT_PUNKTE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:STEUERNUMMER:INVENTAR:PROJEKT:VERWENDUNGSZWECK:CNT_LEX:CNT_REL_DET:ORT:STRASSE:HSNR:LAND:LOC_ORT:BELEGNUMMER::FK_BAS_FK_BAS_')
||'ARBEITSTAG:FK_KTO_BUCHUNG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:ZAPFSAEULE:PERSOENLICH_VOR_ORT:FK_BEL_BELEG_ABLAGE:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:FK_BAS_MON_UMRECHNUN'
||'GSKURS:FK_LOC_LOCATION:FK_LOC_LOCATION1:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_INP_STATUS:FK_STD_INP_ZAHLUNGSSTATUS:FK_STD_KTO_ZAHLUNGSART:CNT_BEL_POS:FK_KON_GESCHAEFTSPARTNER'
,p_sort_column_1=>'PK_INP_BELEGE_ALL'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:0'
,p_break_enabled_on=>'JAHR_ORDNER:0'
,p_count_columns_on_break=>'PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(46155206413993457)
,p_report_id=>wwv_flow_api.id(12222119808247448)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KONTR_BEL_OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FLG_KONTR_BEL_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(46155660634993459)
,p_report_id=>wwv_flow_api.id(12222119808247448)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR_ORDNER'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR_ORDNER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(46156099583993465)
,p_report_id=>wwv_flow_api.id(12222119808247448)
,p_pivot_columns=>'CNT_PUNKTE'
,p_row_columns=>'JAHR_ORDNER'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(46156442683993465)
,p_pivot_id=>wwv_flow_api.id(46156099583993465)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'CNT_PUNKTE'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13287410363234095)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Pivot'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'211573'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:PK_INP_BELEGE_ALL:CNT_PUNKTE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:VERWENDUNGSZWECK:FK_LEX_BUCHUNG:BEZEICHNUNG:BEL_DATUM:VON:BIS:NETTO_BETRAG:BRUTTO_BETRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BE'
||unistr('GR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:MWST_BETRAG:STEUERNUMMER:INVENTAR:PROJEKT:BELEGNUMMER::SEL')
,p_sort_column_1=>'PK_INP_BELEGE_ALL'
,p_sort_direction_1=>'DESC'
,p_break_on=>'FK_VERWENDUNGSZWECK:FK_BELEG_ABLAGE:JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:0'
,p_break_enabled_on=>'0'
,p_count_columns_on_break=>'PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13503256359534998)
,p_report_id=>wwv_flow_api.id(13287410363234095)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KATEGORIE'
,p_operator=>'='
,p_expr=>'7'
,p_condition_sql=>'"FK_KATEGORIE" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13503595381535000)
,p_report_id=>wwv_flow_api.id(13287410363234095)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ORDNER_NAME'
,p_operator=>'='
,p_expr=>'Ordner 1'
,p_condition_sql=>'"ORDNER_NAME" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Ordner 1''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13504006933535002)
,p_report_id=>wwv_flow_api.id(13287410363234095)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NUMBER'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"PAGE_NUMBER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(13504458674535011)
,p_report_id=>wwv_flow_api.id(13287410363234095)
,p_pivot_columns=>'CNT_PUNKTE'
,p_row_columns=>'JAHR_ORDNER'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(13504873772535013)
,p_pivot_id=>wwv_flow_api.id(13504458674535011)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'CNT_PUNKTE'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(52627149740148327)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_ADR_ORT'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(52627226228148328)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>52627226228148328
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627320891148329)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627467590148330)
,p_db_column_name=>'ORT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627563383148331)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627602762148332)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627700394148333)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627839553148334)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52627968604148335)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52628076253148336)
,p_db_column_name=>'ORT_2'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ort 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52628179735148337)
,p_db_column_name=>'KOORDINATEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Koordinaten'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(54825861244901918)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'548259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_ADR_ORT:ORT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:FK_ADR_LAND:ORT_2:KOORDINATEN'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14037329936507553)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14036989912507550)
,p_button_name=>'Kopie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Kopie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3838687786805528)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(1800643920991714)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3593627619537533)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(14036989912507550)
,p_button_name=>'Add_to_page'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add To Page'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1802154902991729)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(14036989912507550)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:228:&SESSION.::&DEBUG.:RP,228:P228_PK_ABL_ORDNER,P228_PK_ABL_ORDNER_PAGE:,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20318005553993943)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(14036989912507550)
,p_button_name=>'move_to'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Move_to'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15245200853781413)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(14036989912507550)
,p_button_name=>'Delete_Beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete Beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12164391041894573)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12151259463894510)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:229'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13038396108408061)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12151259463894510)
,p_button_name=>'OLD_BELEGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Old belege'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:241:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1800481004991712)
,p_name=>'P228_PK_ABL_ORDNER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14036989912507550)
,p_prompt=>'Pk Abl Ordner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1801879793991726)
,p_name=>'P228_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14036989912507550)
,p_prompt=>'<b>Pk Abl Ordner Page</b>'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number || '' ('' || pk_abl_ordner_page || '')'' d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14037274542507552)
,p_name=>'P228_ANZAHL_KOPIEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14036989912507550)
,p_prompt=>'Anzahl Kopien'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20318116236993944)
,p_name=>'P228_PK_ABL_ORDNER_PAGE_TO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14036989912507550)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number || '' ('' || pk_abl_ordner_page || '')'' d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14037448577507554)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_COPY_INP_BEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'       p_inp_bel_cop( apex_application.g_f01(i), :P228_ANZAHL_KOPIEN);',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14037329936507553)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3593511894537532)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Add_to_page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update inp_belege_all set fk_ABL_ORDNER_PAGE  = :P228_PK_ABL_ORDNER_PAGE where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3593627619537533)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15245375027781414)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_delete_Beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      delete from  inp_belege_all where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15245200853781413)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20318273167993945)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_move_to_page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update inp_belege_all set fk_ABL_ORDNER_PAGE  = :P228_PK_ABL_ORDNER_PAGE_to where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20318005553993943)
);
wwv_flow_api.component_end;
end;
/
