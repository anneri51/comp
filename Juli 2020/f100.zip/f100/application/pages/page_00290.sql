prompt --application/pages/page_00290
begin
--   Manifest
--     PAGE: 00290
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>290
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'cal'
,p_step_title=>'cal'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44303882915666971)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524085946'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5582706575448101)
,p_plug_name=>'cal'
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pr.PK_PROJEKT,',
'       pr.FK_AUFTRAGGEBER,',
'       pr.FK_PROJEKTPARTNER_1,',
'       pr.FK_PROJEKTPARTNER_2,',
'       ''<span style="background-color:'' || pa.proj_art_col || ''">'' || pr.projekt || ''</span>'' projekt,',
'       pr.VON      ,',
'',
'          ',
'        pr.bis       ,',
'       pr.AKTUELLER_STUNDENSATZ,',
'       pr.PSP_ELEMENT,',
'       pr.CREATED_BY,',
'       pr.CREATED_AT,',
'       pr.MODIFIED_BY,',
'       pr.MODIFIED_AT,',
'       pr.RECHNUNG_GESTELLT,',
'       pr.ZAHLUNG_ABGESCHLOSSEN,',
'       pr.BELEGE_ZUGEORDNET,',
'       pr.KM_GERECHNET,',
'       pr.PROJEKT_ABGESCHLOSSEN,',
'       pr.FK_PROJEKT_ART,',
'       pr.FK_LEHRGANG,',
'       pr.BILD,',
'       pr.BILD1,',
'       pr.BILD2,',
'       pr.BILD3,',
'       pr.BILD4,',
'       pr.BILD5,',
'       pr.DATEINAME,',
'       pr.DATEINAME1,',
'       pr.DATEINAME2,',
'       pr.DATEINAME3,',
'       pr.DATEINAME4,',
'       pr.DATEINAME5,',
'       pr.DESCR,',
'       pr.COMM,',
'       pr.FK_PROJEKT_STATUS,',
'       pr.BILD6,',
'       pr.FILENAME6,',
'       pr.BILD7,',
'       pr.FILENAME7,',
'       pr.LEBENSLAUF_REL,',
'       pr.FK_JOB_TYPE,',
'       pr.POSITION,',
'       pr.ORT,',
'       pr.PROJEKTINHALTE,',
'       pr.TOOLS,',
'       pr.FK_REFERENZPROJEKT,',
'       pr.TECHN,',
'       pr.OTHER,',
'       pr.REFERENZEN,',
'       pr.ABSCHLUSSNOTE,',
'       pr.FK_PROJEKTPARTNER_3,',
'       pa.proj_art_col',
'  from T_PROJEKT pr ',
'   left join t_projekt_art pa on pr.fk_projekt_art = pa.pk_projekt_art'))
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'VON'
,p_attribute_02=>'BIS'
,p_attribute_03=>'PROJEKT'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_api.component_end;
end;
/
