prompt --application/pages/page_00310
begin
--   Manifest
--     PAGE: 00310
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>310
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Kontrolle_new'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kontrolle_new'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44341901507941496)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090309'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11585467920232851)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7663071394527527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_KONTROLLE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11588523352232875)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7663516197527529)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15392313264853621)
,p_plug_name=>'kontrolle_22'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when  kto.jahr = :P310_jahr then ''<span style="color:red">'' || cnt || ''</span>'' else '''' || cnt || '''' end cnt,',
'kto.jahr,',
'kto.kontonummer,',
'kto.sum_haben,',
'kto.sum_soll,',
'kto.jr,',
'case when nvl(kto.cnt,0) = kontr.final_cnt and kontr.finalisierungsdatum is not null then 1 else 0 end cnt_check,',
'kto.sum_aktiva,',
'kto.sum_passiva',
'from (',
'        select  count(*) cnt, sum(case when gegenkonto <> 9000 or gegenkonto is null  then habenbetrag_eur else 0 end)   sum_haben, sum(case when gegenkonto  <> 9000 or gegenkonto is null  then sollbetrag_eur else 0 end) sum_soll,',
'            sum(case when gegenkonto = 9000  then habenbetrag_eur else 0 end)   sum_passiva, sum(case when gegenkonto  = 9000   then sollbetrag_eur else 0 end) sum_aktiva,',
'        jahr,',
'        Kontonummer,',
'        case when jahr = :P310_jahr then 1 else 0 end jr',
'',
'          from',
'',
'         imp_kontenblatt_2018',
'         where to_number(kontonummer) = :p310_konto',
'         group by jahr, kontonummer',
'    ) kto',
'   left join t_kontrolle kontr on kto.kontonummer = kontr.konto and kto.jahr = kontr.jahr',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15392426265853622)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP,310:P310_PK_KONTROLLE:#PK_KONTROLLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15392426265853622
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15392676771853624)
,p_db_column_name=>'JAHR'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15393150240853629)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15393219711853630)
,p_db_column_name=>'JR'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Jr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15393410900853632)
,p_db_column_name=>'CNT'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Cnt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660284189510827)
,p_db_column_name=>'SUM_HABEN'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Sum Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660305189510828)
,p_db_column_name=>'SUM_SOLL'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Sum Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16858417921571013)
,p_db_column_name=>'CNT_CHECK'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Cnt Check'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16858592411571014)
,p_db_column_name=>'SUM_AKTIVA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Sum Aktiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16858689977571015)
,p_db_column_name=>'SUM_PASSIVA'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Sum Passiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15678878150802214)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'156789'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:CNT:KONTONUMMER:SUM_SOLL:SUM_HABEN::CNT_CHECK:SUM_AKTIVA:SUM_PASSIVA'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16883837008920995)
,p_report_id=>wwv_flow_api.id(15678878150802214)
,p_name=>'cnt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CNT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B5B3B5'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16884270750920995)
,p_report_id=>wwv_flow_api.id(15678878150802214)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_CHECK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CNT_CHECK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16884675514920995)
,p_report_id=>wwv_flow_api.id(15678878150802214)
,p_name=>'jr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'JR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("JR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17499692140587804)
,p_plug_name=>'kontrolle_24'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select susa.*,',
'kon.PK_KONTROLLE, ',
'     -- kon.jahr,',
'      case when kon.jahr = :P310_jahr then ''<span style="background-color:lightblue">''  || kon.JAHR || ''</span>'' else '''' || kon.jahr || '''' end JAHR_M ,',
'      -- kon.KONTO,',
'       kon.FINALISIERUNGSDATUM,',
'       kon.final_cnt,',
'       case when kon.pk_kontrolle = :P310_PK_Kontrolle then 1 else 0 end sel,',
'       ktbl.cnt,',
'       case when kon.jahr = :p310_jahr and kon.konto = :P310_konto then 1 else 0 end sel_jahr_konto,',
'       case when kon.konto = :P310_konto then 1 else 0 end sel_konto,',
'       case when kon.final_cnt = nvl(ktbl.cnt,0) and kon.finalisierungsdatum is not null then 1 else 0 end cnt_chk',
'  from imp_lex_susa susa',
'  ',
' left join   T_KONTROLLE kon on kon.konto = susa.konto and kon.jahr = susa.jahr',
'   left join (select count(*) cnt, jahr, kontonummer from imp_kontenblatt_2018 group by jahr, kontonummer) ktbl on kon.jahr = ktbl.jahr and kon.konto = ktbl.kontonummer'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(17499775573587805)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP,310:P310_PK_KONTROLLE:#PK_KONTROLLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>17499775573587805
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17499803354587806)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17499934555587807)
,p_db_column_name=>'CNT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500050664587808)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500107788587809)
,p_db_column_name=>'PK_KONTROLLE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pk Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500294690587810)
,p_db_column_name=>'KONTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500354318587811)
,p_db_column_name=>'FINAL_CNT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Final Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500467761587812)
,p_db_column_name=>'SEL_JAHR_KONTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Sel Jahr Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500520816587813)
,p_db_column_name=>'SEL_KONTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sel Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500613666587814)
,p_db_column_name=>'CNT_CHK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Cnt Chk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500754379587815)
,p_db_column_name=>'JAHR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500826326587816)
,p_db_column_name=>'JAHR_M'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr M'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17500955888587817)
,p_db_column_name=>'NAME'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501098352587818)
,p_db_column_name=>'LETZTE_BUCHUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Letzte Buchung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501107725587819)
,p_db_column_name=>'EB_WERT_SOLL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Eb Wert Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501279180587820)
,p_db_column_name=>'EB_WERT_HABEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Eb Wert Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501335795587821)
,p_db_column_name=>'SUMME_WJ_SOLL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Summe Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501466308587822)
,p_db_column_name=>'SUMME_WJ_HABEN'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Summe Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501581819587823)
,p_db_column_name=>'SUMME_PER_WJ_SOLL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Summe Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501669114587824)
,p_db_column_name=>'SUMME_PER_WJ_HABEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Summe Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501739869587825)
,p_db_column_name=>'SALDO_PER_WJ_SOLL'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Saldo Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501899312587826)
,p_db_column_name=>'SALDO_PER_WJ_HABEN'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Saldo Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17501983146587827)
,p_db_column_name=>'ID'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Id'
,p_column_link=>'f?p=&APP_ID.:374:&SESSION.::&DEBUG.:RP:P374_ID:#ID#'
,p_column_linktext=>'#ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502057104587828)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502131011587829)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502297097587830)
,p_db_column_name=>'OK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663354030374602)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663492802374603)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663522907374604)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663632106374605)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663742078374606)
,p_db_column_name=>'FK_ABSCHLUSS_VORANMELDG'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Abschluss Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663848079374607)
,p_db_column_name=>'FK_JAHRES_ABSCHLUSSS'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Fk Jahres Abschlusss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663920824374608)
,p_db_column_name=>'FK_BUCH_CNT'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Fk Buch Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19664070151374609)
,p_db_column_name=>'CNT_KASSE_MONAT'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Cnt Kasse Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19664199232374610)
,p_db_column_name=>'CNT_KASSE_JAHR'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Cnt Kasse Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19664247498374611)
,p_db_column_name=>'FK_IMP_LOG_LOAD'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Imp Log Load'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(17679625867123617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'176797'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FINALISIERUNGSDATUM:CNT:SEL:PK_KONTROLLE:KONTO:FINAL_CNT:SEL_JAHR_KONTO:SEL_KONTO:CNT_CHK:JAHR:JAHR_M:NAME:LETZTE_BUCHUNG:EB_WERT_SOLL:EB_WERT_HABEN:SUMME_WJ_SOLL:SUMME_WJ_HABEN:SUMME_PER_WJ_SOLL:SUMME_PER_WJ_HABEN:SALDO_PER_WJ_SOLL:SALDO_PER_WJ_HABE'
||unistr('N:ID:LOAD_DATE:DATUM_OK:OK:FK_STEUER_MONAT:FK_STEUER_VORANMELDG:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:FK_ABSCHLUSS_VORANMELDG:FK_JAHRES_ABSCHLUSSS:FK_BUCH_CNT:CNT_KASSE_MONAT:CNT_KASSE_JAHR:FK_IMP_LOG_LOAD')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17502367763587831)
,p_plug_name=>'kontrolle_21'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select susa.*,',
'kon.PK_KONTROLLE,',
'     -- kon.jahr,',
'      case when kon.jahr = :P310_jahr then ''<span style="background-color:lightblue">''  || kon.JAHR || ''</span>'' else '''' || kon.jahr || '''' end JAHR_M ,',
'      -- kon.KONTO,',
'       kon.FINALISIERUNGSDATUM,',
'       kon.final_cnt,',
'       case when kon.pk_kontrolle = :P310_PK_Kontrolle then 1 else 0 end sel,',
'       ktbl.cnt,',
'       case when kon.jahr = :p310_jahr and kon.konto = :P310_konto then 1 else 0 end sel_jahr_konto,',
'       case when kon.konto = :P310_konto then 1 else 0 end sel_konto,',
'       case when kon.final_cnt = nvl(ktbl.cnt,0) and kon.finalisierungsdatum is not null then 1 else 0 end cnt_chk',
'  from imp_lex_susa susa',
'  ',
' left join   T_KONTROLLE kon on kon.konto = susa.konto and kon.jahr = susa.jahr',
'   left join (select count(*) cnt, jahr, kontonummer from imp_kontenblatt_2018 group by jahr, kontonummer) ktbl on kon.jahr = ktbl.jahr and kon.konto = ktbl.kontonummer',
'  where susa.jahr = :P310_jahr and susa.konto = :P310_Konto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(17502412777587832)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP,310:P310_PK_KONTROLLE:#PK_KONTROLLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>17502412777587832
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502530742587833)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502625021587834)
,p_db_column_name=>'CNT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502797332587835)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502854164587836)
,p_db_column_name=>'PK_KONTROLLE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pk Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17502902911587837)
,p_db_column_name=>'KONTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503043700587838)
,p_db_column_name=>'FINAL_CNT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Final Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503137428587839)
,p_db_column_name=>'SEL_JAHR_KONTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Sel Jahr Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503234317587840)
,p_db_column_name=>'SEL_KONTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sel Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503393370587841)
,p_db_column_name=>'CNT_CHK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Cnt Chk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503414605587842)
,p_db_column_name=>'JAHR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503561463587843)
,p_db_column_name=>'JAHR_M'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr M'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503647089587844)
,p_db_column_name=>'NAME'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503747673587845)
,p_db_column_name=>'LETZTE_BUCHUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Letzte Buchung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503887508587846)
,p_db_column_name=>'EB_WERT_SOLL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Eb Wert Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17503961189587847)
,p_db_column_name=>'EB_WERT_HABEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Eb Wert Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17504001036587848)
,p_db_column_name=>'SUMME_WJ_SOLL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Summe Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17504189009587849)
,p_db_column_name=>'SUMME_WJ_HABEN'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Summe Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17504221805587850)
,p_db_column_name=>'SUMME_PER_WJ_SOLL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Summe Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17698665741167901)
,p_db_column_name=>'SUMME_PER_WJ_HABEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Summe Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17698768226167902)
,p_db_column_name=>'SALDO_PER_WJ_SOLL'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Saldo Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17698812743167903)
,p_db_column_name=>'SALDO_PER_WJ_HABEN'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Saldo Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17698972417167904)
,p_db_column_name=>'ID'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17699012921167905)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17699188725167906)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17699273712167907)
,p_db_column_name=>'OK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(17713521395197725)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'177136'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FINALISIERUNGSDATUM:CNT:SEL:PK_KONTROLLE:KONTO:FINAL_CNT:SEL_JAHR_KONTO:SEL_KONTO:CNT_CHK:JAHR:JAHR_M:NAME:LETZTE_BUCHUNG:EB_WERT_SOLL:EB_WERT_HABEN:SUMME_WJ_SOLL:SUMME_WJ_HABEN:SUMME_PER_WJ_SOLL:SUMME_PER_WJ_HABEN:SALDO_PER_WJ_SOLL:SALDO_PER_WJ_HABE'
||'N:ID:LOAD_DATE:DATUM_OK:OK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23277835649779757)
,p_plug_name=>'kontrolle_23'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'apex_item.checkbox2(1,susa.id) sel1,',
'kon.PK_KONTROLLE, ',
'      kon.jahr,',
'      case when kon.jahr = :P310_jahr then ''<span style="background-color:lightblue">''  || kon.JAHR || ''</span>'' else '''' || kon.jahr || '''' end JAHR_M ,',
'       kon.KONTO,',
'       kon.FINALISIERUNGSDATUM,',
'       kon.final_cnt,',
'       case when kon.pk_kontrolle = :P310_PK_Kontrolle then 1 else 0 end sel_anz,',
'       ktbl.cnt,',
'       case when kon.jahr = :p310_jahr and kon.konto = :P310_konto then 1 else 0 end sel_jahr_konto,',
'       case when kon.konto = :P310_konto then 1 else 0 end sel_konto,',
'       case when kon.final_cnt = nvl(ktbl.cnt,0) and kon.finalisierungsdatum is not null then 1 else 0 end cnt_chk,',
'       case when  kto.jahr = :P310_jahr then ''<span style="color:red">'' || ktbl.cnt || ''</span>'' else '''' || ktbl.cnt || '''' end cnt_check2,',
'',
'kto.sum_haben,',
'kto.sum_soll,',
'kto.jr,',
'case when nvl(kto.cnt,0) = kon.final_cnt and kon.finalisierungsdatum is not null then 1 else 0 end cnt_check1,',
'kto.sum_aktiva,',
'kto.sum_passiva,',
'',
'susa.NAME,',
'susa.LETZTE_BUCHUNG,',
'susa.EB_WERT_SOLL,',
'susa.EB_WERT_HABEN,',
'susa.SUMME_WJ_SOLL,',
'susa.SUMME_WJ_HABEN,',
'susa.SUMME_PER_WJ_SOLL,',
'susa.SUMME_PER_WJ_HABEN,',
'susa.SALDO_PER_WJ_SOLL,',
'susa.SALDO_PER_WJ_HABEN,',
'susa.ID,',
'susa.LOAD_DATE,',
'susa.DATUM_OK,',
'susa.OK,',
'susa.fk_imp_log_load',
'  from',
'  ',
'  T_KONTROLLE kon',
'   left join (select count(*) cnt, jahr, kontonummer from imp_kontenblatt_2018 group by jahr, kontonummer) ktbl on kon.jahr = ktbl.jahr and kon.konto = ktbl.kontonummer',
'   left join (',
'        select  count(*) cnt, sum(case when gegenkonto <> 9000 or gegenkonto is null  then habenbetrag_eur else 0 end)   sum_haben, sum(case when gegenkonto  <> 9000 or gegenkonto is null  then sollbetrag_eur else 0 end) sum_soll,',
'            sum(case when gegenkonto = 9000  then habenbetrag_eur else 0 end)   sum_passiva, sum(case when gegenkonto  = 9000   then sollbetrag_eur else 0 end) sum_aktiva,',
'        jahr,',
'        Kontonummer,',
'        case when jahr = :P310_jahr then 1 else 0 end jr',
'',
'          from',
'',
'         imp_kontenblatt_2018',
'        -- where to_number(kontonummer) = :p310_konto',
'         group by jahr, kontonummer',
'    ) kto on kon.konto = kto.kontonummer and kon.jahr = kto.jahr',
'    left join  imp_lex_susa susa on susa.jahr = kon.jahr and susa.konto = kon.konto',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(23277956281779757)
,p_name=>'kontrolle_2'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP,310:P310_PK_KONTROLLE:#PK_KONTROLLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>23277956281779757
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11641479003391420)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15393792544853635)
,p_db_column_name=>'CNT'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394227135853640)
,p_db_column_name=>'PK_KONTROLLE'
,p_display_order=>84
,p_column_identifier=>'M'
,p_column_label=>'Pk Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394482793853642)
,p_db_column_name=>'KONTO'
,p_display_order=>104
,p_column_identifier=>'O'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394543951853643)
,p_db_column_name=>'FINAL_CNT'
,p_display_order=>114
,p_column_identifier=>'P'
,p_column_label=>'Final Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394654366853644)
,p_db_column_name=>'SEL_JAHR_KONTO'
,p_display_order=>124
,p_column_identifier=>'Q'
,p_column_label=>'Sel Jahr Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394774058853645)
,p_db_column_name=>'SEL_KONTO'
,p_display_order=>134
,p_column_identifier=>'R'
,p_column_label=>'Sel Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15394934068853647)
,p_db_column_name=>'CNT_CHK'
,p_display_order=>154
,p_column_identifier=>'T'
,p_column_label=>'Cnt Chk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15395088421853648)
,p_db_column_name=>'JAHR'
,p_display_order=>164
,p_column_identifier=>'U'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15395290118853650)
,p_db_column_name=>'JAHR_M'
,p_display_order=>174
,p_column_identifier=>'W'
,p_column_label=>'Jahr M'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183035546735111)
,p_db_column_name=>'SEL1'
,p_display_order=>184
,p_column_identifier=>'X'
,p_column_label=>'Sel1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183178203735112)
,p_db_column_name=>'SEL_ANZ'
,p_display_order=>194
,p_column_identifier=>'Y'
,p_column_label=>'Sel Anz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183207675735113)
,p_db_column_name=>'CNT_CHECK2'
,p_display_order=>204
,p_column_identifier=>'Z'
,p_column_label=>'Cnt Check2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183344961735114)
,p_db_column_name=>'SUM_HABEN'
,p_display_order=>214
,p_column_identifier=>'AA'
,p_column_label=>'Sum Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183498285735115)
,p_db_column_name=>'SUM_SOLL'
,p_display_order=>224
,p_column_identifier=>'AB'
,p_column_label=>'Sum Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183523952735116)
,p_db_column_name=>'JR'
,p_display_order=>234
,p_column_identifier=>'AC'
,p_column_label=>'Jr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183616283735117)
,p_db_column_name=>'CNT_CHECK1'
,p_display_order=>244
,p_column_identifier=>'AD'
,p_column_label=>'Cnt Check1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183757013735118)
,p_db_column_name=>'SUM_AKTIVA'
,p_display_order=>254
,p_column_identifier=>'AE'
,p_column_label=>'Sum Aktiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183848023735119)
,p_db_column_name=>'SUM_PASSIVA'
,p_display_order=>264
,p_column_identifier=>'AF'
,p_column_label=>'Sum Passiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18183993579735120)
,p_db_column_name=>'NAME'
,p_display_order=>274
,p_column_identifier=>'AG'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184049658735121)
,p_db_column_name=>'LETZTE_BUCHUNG'
,p_display_order=>284
,p_column_identifier=>'AH'
,p_column_label=>'Letzte Buchung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184100428735122)
,p_db_column_name=>'EB_WERT_SOLL'
,p_display_order=>294
,p_column_identifier=>'AI'
,p_column_label=>'Eb Wert Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184204386735123)
,p_db_column_name=>'EB_WERT_HABEN'
,p_display_order=>304
,p_column_identifier=>'AJ'
,p_column_label=>'Eb Wert Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184310310735124)
,p_db_column_name=>'SUMME_WJ_SOLL'
,p_display_order=>314
,p_column_identifier=>'AK'
,p_column_label=>'Summe Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184450364735125)
,p_db_column_name=>'SUMME_WJ_HABEN'
,p_display_order=>324
,p_column_identifier=>'AL'
,p_column_label=>'Summe Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184533317735126)
,p_db_column_name=>'SUMME_PER_WJ_SOLL'
,p_display_order=>334
,p_column_identifier=>'AM'
,p_column_label=>'Summe Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184682755735127)
,p_db_column_name=>'SUMME_PER_WJ_HABEN'
,p_display_order=>344
,p_column_identifier=>'AN'
,p_column_label=>'Summe Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184718759735128)
,p_db_column_name=>'SALDO_PER_WJ_SOLL'
,p_display_order=>354
,p_column_identifier=>'AO'
,p_column_label=>'Saldo Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184865033735129)
,p_db_column_name=>'SALDO_PER_WJ_HABEN'
,p_display_order=>364
,p_column_identifier=>'AP'
,p_column_label=>'Saldo Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18184974845735130)
,p_db_column_name=>'ID'
,p_display_order=>374
,p_column_identifier=>'AQ'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18185086969735131)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>384
,p_column_identifier=>'AR'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18185134083735132)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>394
,p_column_identifier=>'AS'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18185253768735133)
,p_db_column_name=>'OK'
,p_display_order=>404
,p_column_identifier=>'AT'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19663253891374601)
,p_db_column_name=>'FK_IMP_LOG_LOAD'
,p_display_order=>414
,p_column_identifier=>'AU'
,p_column_label=>'Fk Imp Log Load'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11642238893399865)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'116423'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_KONTROLLE:KONTO:JAHR_M:FINALISIERUNGSDATUM:FINAL_CNT:CNT:SEL_JAHR_KONTO:SEL_KONTO::SEL1:SEL_ANZ:CNT_CHECK2:SUM_HABEN:SUM_SOLL:JR:CNT_CHECK1:SUM_AKTIVA:SUM_PASSIVA:NAME:LETZTE_BUCHUNG:EB_WERT_SOLL:EB_WERT_HABEN:SUMME_WJ_SOLL:SUMME_WJ_HABEN:SUMME_PE'
||'R_WJ_SOLL:SUMME_PER_WJ_HABEN:SALDO_PER_WJ_SOLL:SALDO_PER_WJ_HABEN:ID:LOAD_DATE:DATUM_OK:OK:FK_IMP_LOG_LOAD'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'KONTO'
,p_sort_direction_2=>'ASC'
,p_break_on=>'KONTO'
,p_break_enabled_on=>'KONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18275194509617954)
,p_report_id=>wwv_flow_api.id(11642238893399865)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_CHK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CNT_CHK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>5
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18275517900617954)
,p_report_id=>wwv_flow_api.id(11642238893399865)
,p_name=>'sel_jahr_konto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_JAHR_KONTO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_JAHR_KONTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18275945869617956)
,p_report_id=>wwv_flow_api.id(11642238893399865)
,p_name=>'sel_konto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_KONTO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_KONTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18274708661617954)
,p_report_id=>wwv_flow_api.id(11642238893399865)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11588900108232875)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11585467920232851)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18185493959735135)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(15392313264853621)
,p_button_name=>'set_susa_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set Susa Datum Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11590598090232885)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11585467920232851)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P310_PK_KONTROLLE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18185554039735136)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(15392313264853621)
,p_button_name=>'set_susa_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set Susa Datum Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11590925528232885)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11585467920232851)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P310_PK_KONTROLLE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11591367150232885)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11585467920232851)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P310_PK_KONTROLLE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11787925828700109)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11585467920232851)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Update fk_main_key tag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11585732184232854)
,p_name=>'P310_PK_KONTROLLE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_source_plug_id=>wwv_flow_api.id(11585467920232851)
,p_prompt=>'New'
,p_source=>'PK_KONTROLLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11586134211232865)
,p_name=>'P310_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_source_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 221',
'and mark = 1'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Jahr'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 221'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11586522141232870)
,p_name=>'P310_KONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_source_plug_id=>wwv_flow_api.id(11585467920232851)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Konto'
,p_source=>'KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11586942699232871)
,p_name=>'P310_FINALISIERUNGSDATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_source_plug_id=>wwv_flow_api.id(11585467920232851)
,p_prompt=>'Finalisierungsdatum'
,p_source=>'FINALISIERUNGSDATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15392150063853619)
,p_name=>'P310_FINAL_CNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11585467920232851)
,p_item_source_plug_id=>wwv_flow_api.id(11585467920232851)
,p_prompt=>'Final Cnt'
,p_source=>'FINAL_CNT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11589059570232875)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(11588900108232875)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11589800480232881)
,p_event_id=>wwv_flow_api.id(11589059570232875)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11592151643232889)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(11585467920232851)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11592519513232889)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11788018328700110)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Tag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'merge into kas_kasse t1',
'  using (',
'        select pk_arbeitstage, ',
'       pk_kas_kasse',
'',
'        from (select * from kas_kasse where datum is not null and fk_arbeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kas_kasse = t2.pk_kas_kasse)',
'        when matched then',
'        update set t1.fk_arbeitstag= t2.pk_arbeitstage;',
'        commit;',
'        ',
'        ',
'        ',
'   update Kas_Kasse set FK_MAIN_KEY = KTO_KONTO_SEQ.nextval where fk_main_key is null;',
'        commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11787925828700109)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18276565553671218)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_susa_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update imp_lex_susa set datum_ok = null where id =   apex_application.g_f01(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18185554039735136)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18185344629735134)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_susa_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update imp_lex_susa set datum_ok = sysdate where id =   apex_application.g_f01(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18185493959735135)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11591743457232887)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11585467920232851)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
