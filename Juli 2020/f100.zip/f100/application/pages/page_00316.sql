prompt --application/pages/page_00316
begin
--   Manifest
--     PAGE: 00316
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>316
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Buchungszuordnung'
,p_step_title=>'Buchungszuordnung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44310049295715590)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090255'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11851734029258890)
,p_plug_name=>'Buchungszuordnung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct relkto.*, ',
'',
'zus1.fk_main_key fk_main_key1,',
'zus1."Kontotyp" kontotyp1,',
'zus1.fk_konto fk_konto1,',
'zus1."Betrag" betrag1,',
'bel1.fk_relation fk_relation1,',
'zus1.bucht_tag bucht_tag1,',
'zus1.bucht_monat bucht_monat1,',
'zus1.bucht_jahr bucht_jahr1,',
'll1.habenkto hbkto1,',
'll1.sollkto slkto1,',
'll1.buchdat buchdat1,',
'll1.betrag lexbetrag1,',
'',
'',
'zus2.fk_main_key fk_main_key2,',
'zus2."Kontotyp" kontotyp2,',
'zus2.fk_konto fk_konto2,',
'zus2."Betrag" betrag2,',
'bel2.fk_relation fk_relation2,',
'zus2.bucht_tag bucht_tag2,',
'zus2.bucht_monat bucht_monat2,',
'zus2.bucht_jahr bucht_jahr2,',
'll2.habenkto hbkto2,',
'll2.sollkto slkto2,',
'll2.buchdat buchdat2,',
'll2.betrag lexbetrag2,',
'',
'case when zus1."Betrag"= -zus2."Betrag" then 1 else 0 end vgl',
'',
'from ( select distinct *',
'       from (',
'       select fk_konto_buch1, fk_konto_buch2, fk_type from t_rel_kont_buch_kont_buch where fk_type = 1',
'        union',
'            select  fk_konto_buch2, fk_konto_buch1, fk_type from t_rel_kont_buch_kont_buch where fk_type = 1',
'         )) relkto',
'         ',
' left join v_konten_zus zus1 on relkto.fk_konto_buch1 = zus1.fk_main_key',
' left join v_konten_zus zus2 on relkto.fk_konto_buch2 = zus2.fk_main_key',
' left join t_rel_lex_kto_bel bel1 on bel1.fk_main_key = zus1.fk_main_key',
' left join t_rel_lex_kto_bel bel2 on bel2.fk_main_key = zus2.fk_main_key',
' left join t_lex_long ll1 on ll1.relation = bel1.fk_relation',
' left join t_lex_long ll2 on ll2.relation = bel2.fk_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11851809632258890)
,p_name=>'Buchungszuordnung'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11851809632258890
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11852603643258901)
,p_db_column_name=>'FK_KONTO_BUCH1'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Konto Buch1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11853076428258901)
,p_db_column_name=>'FK_KONTO_BUCH2'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Konto Buch2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11855873671258903)
,p_db_column_name=>'FK_MAIN_KEY1'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Main Key1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11856236463258904)
,p_db_column_name=>'KONTOTYP1'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kontotyp1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11856643604258904)
,p_db_column_name=>'FK_KONTO1'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Konto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11857094830258904)
,p_db_column_name=>'BETRAG1'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Betrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11857404260258904)
,p_db_column_name=>'FK_RELATION1'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk Relation1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11857839895258904)
,p_db_column_name=>'BUCHT_TAG1'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Bucht Tag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11858271933258904)
,p_db_column_name=>'BUCHT_MONAT1'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Monat1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11858695604258906)
,p_db_column_name=>'BUCHT_JAHR1'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Jahr1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11859023833258906)
,p_db_column_name=>'HBKTO1'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Hbkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11859419382258906)
,p_db_column_name=>'SLKTO1'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Slkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11859859807258906)
,p_db_column_name=>'BUCHDAT1'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Buchdat1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11860252674258906)
,p_db_column_name=>'LEXBETRAG1'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Lexbetrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11860640412258906)
,p_db_column_name=>'FK_MAIN_KEY2'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Main Key2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11861008806258907)
,p_db_column_name=>'KONTOTYP2'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Kontotyp2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11861406691258907)
,p_db_column_name=>'FK_KONTO2'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fk Konto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11861816624258907)
,p_db_column_name=>'BETRAG2'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Betrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11862289308258907)
,p_db_column_name=>'FK_RELATION2'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Fk Relation2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11862680413258907)
,p_db_column_name=>'BUCHT_TAG2'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Bucht Tag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11863091813258907)
,p_db_column_name=>'BUCHT_MONAT2'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Bucht Monat2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11863448652258907)
,p_db_column_name=>'BUCHT_JAHR2'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Bucht Jahr2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11863848995258909)
,p_db_column_name=>'HBKTO2'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Hbkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11864268928258909)
,p_db_column_name=>'SLKTO2'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Slkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11864680198258909)
,p_db_column_name=>'BUCHDAT2'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Buchdat2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11865064337258909)
,p_db_column_name=>'LEXBETRAG2'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Lexbetrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11788524128700115)
,p_db_column_name=>'VGL'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'Vgl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11789365902700123)
,p_db_column_name=>'FK_TYPE'
,p_display_order=>53
,p_column_identifier=>'AI'
,p_column_label=>'Fk Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11865406140261900)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_KONTO_BUCH1:FK_KONTO_BUCH2:FK_MAIN_KEY1:KONTOTYP1:FK_KONTO1:BETRAG1:FK_RELATION1:BUCHT_TAG1:BUCHT_MONAT1:BUCHT_JAHR1:HBKTO1:SLKTO1:BUCHDAT1:LEXBETRAG1:FK_MAIN_KEY2:KONTOTYP2:FK_KONTO2:BETRAG2:FK_RELATION2:BUCHT_TAG2:BUCHT_MONAT2:BUCHT_JAHR2:HBKTO2'
||':SLKTO2:BUCHDAT2:LEXBETRAG2:VGL:FK_TYPE'
,p_break_on=>'FK_KONTO_BUCH1'
,p_break_enabled_on=>'FK_KONTO_BUCH1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11874617043364431)
,p_report_id=>wwv_flow_api.id(11865406140261900)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VGL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VGL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11873817200364429)
,p_report_id=>wwv_flow_api.id(11865406140261900)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR1'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR1" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11874273896364431)
,p_report_id=>wwv_flow_api.id(11865406140261900)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP1'
,p_operator=>'='
,p_expr=>'Tagesgeldkonto'
,p_condition_sql=>'"KONTOTYP1" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Tagesgeldkonto''  '
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
