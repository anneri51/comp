prompt --application/pages/page_00318
begin
--   Manifest
--     PAGE: 00318
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>318
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Imp_hotel_booking'
,p_step_title=>'Imp_hotel_booking'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44326507867825207)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090444'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12276362787532534)
,p_plug_name=>'ir_test'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select book.ZEITRAUM,',
'       book.HOTEL,',
'       book.ORT,',
'       book.BETRAG,',
'       book.SEITE,',
'       book.JAHR,',
'       book.FK_VON,',
'       book.FK_BIS,',
'       book.ID,',
'       book.FK_LOCATION,',
'       book.FK_INP_BELEGE_ALL,',
'       book.COMM,',
'       book.ok_datum,',
'       relbel.fk_relation,',
'       ll.betrag ll_betrag,',
'       book.betrag - ll.betrag diff,',
'       case when  book.betrag - ll.betrag = 0 then 1 else 0 end diff_ok,',
'       relbel.fk_main_key',
'  from IMP_HOTEL_BOOKING book',
'   left join t_rel_lex_kto_bel relbel on book.fk_inp_belege_all = relbel.fk_inp_belege_all',
'   left join t_lex_long ll on ll.relation = relbel.fk_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12276470365532535)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:318:&SESSION.::&DEBUG.:RP:P318_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>12276470365532535
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12276523666532536)
,p_db_column_name=>'FK_VON'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Von'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12276689094532537)
,p_db_column_name=>'FK_BIS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Bis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12276767215532538)
,p_db_column_name=>'ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12276823421532539)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12276911690532540)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP,229:P229_PK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277098285532541)
,p_db_column_name=>'ZEITRAUM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Zeitraum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277193061532542)
,p_db_column_name=>'HOTEL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Hotel'
,p_column_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL,P229_BEZEICHNUNG:,#HOTEL#  #ORT# (#ZEITRAUM#) #BETRAG#'
,p_column_linktext=>'#HOTEL#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277208377532543)
,p_db_column_name=>'ORT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277309891532544)
,p_db_column_name=>'BETRAG'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277436110532545)
,p_db_column_name=>'SEITE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Seite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277561666532546)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277694481532547)
,p_db_column_name=>'COMM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277732600532548)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277800788532549)
,p_db_column_name=>'LL_BETRAG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Ll Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12277904120532550)
,p_db_column_name=>'DIFF'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381087065813601)
,p_db_column_name=>'DIFF_OK'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Diff Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12413446242817920)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12413751286817923)
,p_db_column_name=>'OK_DATUM'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Ok Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12592076734829956)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125921'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_VON:FK_BIS:ID:FK_LOCATION:FK_INP_BELEGE_ALL:ZEITRAUM:HOTEL:ORT:BETRAG:SEITE:JAHR:COMM:FK_RELATION:LL_BETRAG:DIFF:DIFF_OK:FK_MAIN_KEY:OK_DATUM'
,p_break_on=>'FK_INP_BELEGE_ALL'
,p_break_enabled_on=>'FK_INP_BELEGE_ALL'
,p_sum_columns_on_break=>'LL_BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12622502848468129)
,p_report_id=>wwv_flow_api.id(12592076734829956)
,p_name=>'Betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BETRAG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D6CFD6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12622936275468129)
,p_report_id=>wwv_flow_api.id(12592076734829956)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK_DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("OK_DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12622103617468128)
,p_report_id=>wwv_flow_api.id(12592076734829956)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12310940066751678)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'IMP_HOTEL_BOOKING'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24308198719029702)
,p_plug_name=>'ir_test'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INP_BELEGE_ALL,',
'       FK_LEX_BUCHUNG,',
'       FK_KATEGORIE,',
'       FK_ARBEITSTAG,',
'       FK_BUCHUNG,',
'       FK_ZAHLUNGSART,',
'       FK_VERWENDUNGSZWECK,',
'       FK_INVENTAR,',
'       FK_PROJEKT,',
'       BELEGNUMMER,',
'       BEZEICHNUNG,',
'       FK_LAND,',
'       FK_CITY,',
'       BEL_DATUM,',
'       VON,',
'       BIS,',
'       NETTO_BETRAG,',
'       FK_STEUERSATZ,',
'       MWST_BETRAG,',
'       BRUTTO_BETRAG,',
'       FK_WAEHRUNG,',
'       STEUERNUMMER,',
'       FK_UMRECHNUNGSKURS,',
'       COMM_REST_BELEG,',
'       COMM_TEL_BELEG,',
'       COMM_PRODUKTE,',
unistr('       "COMM_BEGR\00DCNDUNG",'),
'       COMM_SONSTIGES,',
'       BELEG,',
'       ZAHLUNGSBELEG,',
'       LITER,',
unistr('       "ZAPFS\00C4ULE",'),
'       FK_LOCATION',
'from V_INP_BELEGE_ALL',
'where pk_inp_belege_all = :P318_fk_inp_belege_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(24308313889029702)
,p_name=>'ir_test'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP,229:P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL##ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>24308313889029702
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12358315947093379)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>160
,p_column_identifier=>'AD'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381194177813602)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>180
,p_column_identifier=>'AJ'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381292066813603)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>190
,p_column_identifier=>'AK'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381394602813604)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>200
,p_column_identifier=>'AL'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381483859813605)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>210
,p_column_identifier=>'AM'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381513772813606)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>220
,p_column_identifier=>'AN'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381625070813607)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>230
,p_column_identifier=>'AO'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381798571813608)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>240
,p_column_identifier=>'AP'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381898224813609)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>250
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12381923339813610)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>260
,p_column_identifier=>'AR'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382061961813611)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>270
,p_column_identifier=>'AS'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382196666813612)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>280
,p_column_identifier=>'AT'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382255716813613)
,p_db_column_name=>'FK_LAND'
,p_display_order=>290
,p_column_identifier=>'AU'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382324783813614)
,p_db_column_name=>'FK_CITY'
,p_display_order=>300
,p_column_identifier=>'AV'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382468064813615)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>310
,p_column_identifier=>'AW'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382508566813616)
,p_db_column_name=>'VON'
,p_display_order=>320
,p_column_identifier=>'AX'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382696763813617)
,p_db_column_name=>'BIS'
,p_display_order=>330
,p_column_identifier=>'AY'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382723364813618)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>340
,p_column_identifier=>'AZ'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382851570813619)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>350
,p_column_identifier=>'BA'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12382940592813620)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>360
,p_column_identifier=>'BB'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383049734813621)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>370
,p_column_identifier=>'BC'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383145358813622)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>380
,p_column_identifier=>'BD'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383268690813623)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>390
,p_column_identifier=>'BE'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383347299813624)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>400
,p_column_identifier=>'BF'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383470768813625)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>410
,p_column_identifier=>'BG'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383559826813626)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>420
,p_column_identifier=>'BH'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383656508813627)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>430
,p_column_identifier=>'BI'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383713918813628)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>440
,p_column_identifier=>'BJ'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383855057813629)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>450
,p_column_identifier=>'BK'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12383993785813630)
,p_db_column_name=>'BELEG'
,p_display_order=>460
,p_column_identifier=>'BL'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12384044489813631)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>470
,p_column_identifier=>'BM'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12384109155813632)
,p_db_column_name=>'LITER'
,p_display_order=>480
,p_column_identifier=>'BN'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12384253427813633)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>490
,p_column_identifier=>'BO'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12358973048098512)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123590'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BRUTTO_BETRAG:FK_LOCATION:PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_KATEGORIE:FK_ARBEITSTAG:FK_BUCHUNG:FK_ZAHLUNGSART:FK_VERWENDUNGSZWECK:FK_INVENTAR:BEZEICHNUNG:FK_LAND:FK_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_STEUERSATZ:MWST_BETRAG:FK_WAEHRUNG:STEUERNUM'
||unistr('MER:FK_UMRECHNUNGSKURS:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFS\00C4ULE:')
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12319622461754451)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12310940066751678)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P318_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12318407108754442)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(12310940066751678)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12320051313754451)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12310940066751678)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P318_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12319231295754448)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(12310940066751678)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P318_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12614428770245960)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(12310940066751678)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12311224316751679)
,p_name=>'P318_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12311641821751685)
,p_name=>'P318_ZEITRAUM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zeitraum'
,p_source=>'ZEITRAUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>128
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12312053238752284)
,p_name=>'P318_HOTEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Hotel'
,p_source=>'HOTEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>128
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12312308407752890)
,p_name=>'P318_ORT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ort'
,p_source=>'ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>26
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12312606934753489)
,p_name=>'P318_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Betrag'
,p_source=>'BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12312924962754095)
,p_name=>'P318_SEITE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Seite'
,p_source=>'SEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>26
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12313212113754435)
,p_name=>'P318_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jahr'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12313544043754437)
,p_name=>'P318_FK_VON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Von'
,p_source=>'FK_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12313999492754437)
,p_name=>'P318_FK_BIS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Bis'
,p_source=>'FK_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12314322106754437)
,p_name=>'P318_FK_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Location'
,p_source=>'FK_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12314799746754437)
,p_name=>'P318_FK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12413583714817921)
,p_name=>'P318_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12413683917817922)
,p_name=>'P318_OK_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(12310940066751678)
,p_item_source_plug_id=>wwv_flow_api.id(12310940066751678)
,p_prompt=>'Ok Datum'
,p_source=>'OK_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12320894868754454)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(12310940066751678)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12320492452754453)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(12310940066751678)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.component_end;
end;
/
