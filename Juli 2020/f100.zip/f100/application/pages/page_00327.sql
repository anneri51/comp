prompt --application/pages/page_00327
begin
--   Manifest
--     PAGE: 00327
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>327
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Verpflegungsmehraufwand'
,p_step_title=>'Verpflegungsmehraufwand'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(13610231510939284)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200306095124'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13294096990365471)
,p_plug_name=>'Verpflegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_VERPFLEGUNGSMEHRAUFWAND'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14043852357101128)
,p_plug_name=>'Buchungsvorgabe'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15207931877483431)
,p_plug_name=>'Buchung'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ll.relation, ll.habenkto, ll.sollkto, ll.betrag, ll.buchungstext, ll.nr, ll.belegnr, ll.belegdat',
'from t_rel_lex_kto_bel ktobel',
' left join t_lex_long ll on ktobel.fk_relation = ll.relation',
'where fk_inp_belege_all = :P327_fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15208241110483434)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_PK_VERPFLEGUNGSMEHRAUFWD_DET,P329_FK_ARBEITSTAG:#PK_VERPFLEGUNGSMEHRAUFWD_DET#,#FK_DATUM_VERPFMWED##PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>15208241110483434
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244447002781405)
,p_db_column_name=>'RELATION'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244574463781406)
,p_db_column_name=>'HABENKTO'
,p_display_order=>20
,p_column_identifier=>'V'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244605832781407)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244735037781408)
,p_db_column_name=>'BETRAG'
,p_display_order=>40
,p_column_identifier=>'X'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244839751781409)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>50
,p_column_identifier=>'Y'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15244992131781410)
,p_db_column_name=>'NR'
,p_display_order=>60
,p_column_identifier=>'Z'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15245053292781411)
,p_db_column_name=>'BELEGNR'
,p_display_order=>70
,p_column_identifier=>'AA'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15245179359781412)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15265171188810829)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'152652'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RELATION:HABENKTO:SOLLKTO:BETRAG:BUCHUNGSTEXT:NR:BELEGNR:BELEGDAT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26845374767868521)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_VERPFLEGUNGSMEHRAUFWD_DET,',
'       FK_VERPFLEGUNGSMEHRAUFWAND,',
'       DATUM_VERPFMWED,',
'       FK_DATUM_VERPFMWED,',
'       DESCR,',
'       COMM,',
'       FK_ORT,',
unistr('       "FK_FR\00DCHSTUECK",'),
'       FK_VERPFLEGUNGSPAUSCHALE_VOLL,',
'       FK_VERPFLEGUNGSPAUSCHALE_TEIL,',
unistr('       "FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ",'),
unistr('       "FK_\00DCBERNACHTUNGSPAUSCHALE",'),
'       FK_STATUS_VP_VOLL,',
'       FK_STATUS_VP_TEIL,',
unistr('       "FK_STATUS_VP_K\00DCRZ",'),
unistr('       "FK_STATUS_\00DCP",'),
'       FK_STATUS,',
'       CREATION_DATE,',
'       MODIFY_DATE,',
'              FK_VERPFLEGUNGSPAUSCHALE_VOLL+',
'       FK_VERPFLEGUNGSPAUSCHALE_TEIL+',
unistr('       "FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ"+'),
unistr('       "FK_\00DCBERNACHTUNGSPAUSCHALE" gesamt,'),
'       arb.*,',
'       case when arb.wochentag = ''Sonntag'' or arb.wochentag = ''Samstag'' then 1 else 0 end we,',
'       bel_src.inp,',
'       bel_ort.ort, ',
'       bel_std.std',
'  from T_VERPFLEGUNGSMEHRAUFWAND_DET det',
'    left join t_arbeitstage arb on det.FK_DATUM_VERPFMWED = arb.pk_arbeitstage',
'    left join (',
'                     select fk_verpflegungsmehraufwd_det, listagg(''<b>'' || pk_inp_belege_all || ''</b>'' || '' - '' || bezeichnung, ''<br>'') within group (order by fk_verpflegungsmehraufwd_det) inp ',
'                from  t_rel_verpfl_beleg_src bel left join inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all group by fk_verpflegungsmehraufwd_det',
'              ) bel_src on bel_src.fK_VERPFLEGUNGSMEHRAUFWD_DET = det.PK_VERPFLEGUNGSMEHRAUFWD_DEt',
'    left join  (',
'    ',
'         select fk_verpflegungsmehraufwd_det, listagg(ort, '','') within group (order by fk_verpflegungsmehraufwd_det) ort',
'                from  t_rel_verpfl_beleg_ort bel left join t_ort ort on bel.fk_ort = ort.pk_ort group by fk_verpflegungsmehraufwd_det',
'    )  bel_ort on bel_ort.fK_VERPFLEGUNGSMEHRAUFWD_DET = det.PK_VERPFLEGUNGSMEHRAUFWD_DEt',
'    left join  (',
'    ',
'                select fk_verpflegungsmehraufwd_det, listagg(jahr || '' / '' || projekt || '' / '' || beschreibung || '' / '' || zeitraum_von || '' - '' || zeitraum_bis, '','') within group (order by fk_verpflegungsmehraufwd_det) std',
'                from  t_rel_verpfl_beleg_src bel ',
'                   left join t_stundenzettel std on std.pk_stundenzettel = bel.fk_stundenzettel',
'                    left join t_projekt proj on std.fk_projekt  = proj.pk_projekt',
'                group by fk_verpflegungsmehraufwd_det',
'    )  bel_std on bel_std.fK_VERPFLEGUNGSMEHRAUFWD_DET = det.PK_VERPFLEGUNGSMEHRAUFWD_DEt',
'                      ',
'      ',
' where fk_verpflegungsmehraufwand = :P327_PK_Verpflegungsmehraufwand'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26845670630868521)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_PK_VERPFLEGUNGSMEHRAUFWD_DET,P329_FK_ARBEITSTAG:#PK_VERPFLEGUNGSMEHRAUFWD_DET#,#FK_DATUM_VERPFMWED##PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>26845670630868521
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544207182502818)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13544683212502818)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13545409100502820)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491427811959414)
,p_db_column_name=>'PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>17
,p_column_identifier=>'I'
,p_column_label=>'Pk Verpflegungsmehraufwd Det'
,p_column_link=>'f?p=&APP_ID.:339:&SESSION.::&DEBUG.:RP:P339_FK_VERPFLEGUNGSMEHRAUFWD_DET,P339_FK_ARBEITSTAG:#PK_VERPFLEGUNGSMEHRAUFWD_DET#,#PK_ARBEITSTAGE#'
,p_column_linktext=>'#PK_VERPFLEGUNGSMEHRAUFWD_DET#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491594154959415)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWAND'
,p_display_order=>27
,p_column_identifier=>'J'
,p_column_label=>'Fk Verpflegungsmehraufwand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491651794959416)
,p_db_column_name=>'DATUM_VERPFMWED'
,p_display_order=>37
,p_column_identifier=>'K'
,p_column_label=>'Datum Verpfmwed'
,p_column_link=>'f?p=&APP_ID.:342:&SESSION.::&DEBUG.:RP:P342_PK_VERPFLEGUNGSMEHRAUFWD_DET:#PK_VERPFLEGUNGSMEHRAUFWD_DET#'
,p_column_linktext=>'#DATUM_VERPFMWED#'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491765107959417)
,p_db_column_name=>'FK_DATUM_VERPFMWED'
,p_display_order=>47
,p_column_identifier=>'L'
,p_column_label=>'Fk Datum Verpfmwed'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491809147959418)
,p_db_column_name=>'DESCR'
,p_display_order=>57
,p_column_identifier=>'M'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491944863959419)
,p_db_column_name=>'FK_ORT'
,p_display_order=>67
,p_column_identifier=>'N'
,p_column_label=>'Fk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492093034959420)
,p_db_column_name=>unistr('FK_FR\00DCHSTUECK')
,p_display_order=>77
,p_column_identifier=>'O'
,p_column_label=>unistr('Fk Fr\00FChstueck')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492150474959421)
,p_db_column_name=>'FK_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_display_order=>87
,p_column_identifier=>'P'
,p_column_label=>'Fk Verpflegungspauschale Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492230232959422)
,p_db_column_name=>'FK_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_display_order=>97
,p_column_identifier=>'Q'
,p_column_label=>'Fk Verpflegungspauschale Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492361234959423)
,p_db_column_name=>unistr('FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ')
,p_display_order=>107
,p_column_identifier=>'R'
,p_column_label=>unistr('Fk Verpflegunspauschale K\00FCrz')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492442573959424)
,p_db_column_name=>unistr('FK_\00DCBERNACHTUNGSPAUSCHALE')
,p_display_order=>117
,p_column_identifier=>'S'
,p_column_label=>unistr('Fk \00DCbernachtungspauschale')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492582019959425)
,p_db_column_name=>'FK_STATUS_VP_VOLL'
,p_display_order=>127
,p_column_identifier=>'T'
,p_column_label=>'Fk Status Vp Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492648068959426)
,p_db_column_name=>'FK_STATUS_VP_TEIL'
,p_display_order=>137
,p_column_identifier=>'U'
,p_column_label=>'Fk Status Vp Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492799133959427)
,p_db_column_name=>unistr('FK_STATUS_VP_K\00DCRZ')
,p_display_order=>147
,p_column_identifier=>'V'
,p_column_label=>unistr('Fk Status Vp K\00FCrz')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492850462959428)
,p_db_column_name=>unistr('FK_STATUS_\00DCP')
,p_display_order=>157
,p_column_identifier=>'W'
,p_column_label=>unistr('Fk Status \00DCp')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492906951959429)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>167
,p_column_identifier=>'X'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14043697756101126)
,p_db_column_name=>'GESAMT'
,p_display_order=>177
,p_column_identifier=>'Y'
,p_column_label=>'Gesamt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793080512062117)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>187
,p_column_identifier=>'Z'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793195900062118)
,p_db_column_name=>'DATUM'
,p_display_order=>197
,p_column_identifier=>'AA'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793208252062119)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>207
,p_column_identifier=>'AB'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793394325062120)
,p_db_column_name=>'FK_WOCHENENDE'
,p_display_order=>217
,p_column_identifier=>'AC'
,p_column_label=>'Fk Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793425033062121)
,p_db_column_name=>'FK_FEIERTAG'
,p_display_order=>227
,p_column_identifier=>'AD'
,p_column_label=>'Fk Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793588510062122)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>237
,p_column_identifier=>'AE'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793669850062123)
,p_db_column_name=>'TAG'
,p_display_order=>247
,p_column_identifier=>'AF'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793755284062124)
,p_db_column_name=>'MONAT'
,p_display_order=>257
,p_column_identifier=>'AG'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793800822062125)
,p_db_column_name=>'JAHR'
,p_display_order=>267
,p_column_identifier=>'AH'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17793925470062126)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>277
,p_column_identifier=>'AI'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17794058747062127)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>287
,p_column_identifier=>'AJ'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17794181914062128)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>297
,p_column_identifier=>'AK'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17794202360062129)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>307
,p_column_identifier=>'AL'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17794361541062130)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>317
,p_column_identifier=>'AM'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17794413019062131)
,p_db_column_name=>'WE'
,p_display_order=>327
,p_column_identifier=>'AN'
,p_column_label=>'We'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17795218922062139)
,p_db_column_name=>'INP'
,p_display_order=>337
,p_column_identifier=>'AO'
,p_column_label=>'Inp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17795344784062140)
,p_db_column_name=>'ORT'
,p_display_order=>347
,p_column_identifier=>'AP'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18041875238873915)
,p_db_column_name=>'STD'
,p_display_order=>357
,p_column_identifier=>'AQ'
,p_column_label=>'Std'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26899764854093374)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135462'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_VERPFMWED:FEIERTAG:INP:STD:ORT:FK_ARBEITSTAG:FK_VERPFLEGUNGSMEHRAUFWAND:FK_WOCHENENDE:FK_STATUS:COMM:CREATION_DATE:PK_VERPFLEGUNGSMEHRAUFWD_DET:FK_DATUM_VERPFMWED:DESCR:FK_VERPFLEGUNGSPAUSCHALE_VOLL:FK_VERPFLEGUNGSPAUSCHALE_TEIL:FK_VERPFLEGUNSP'
||unistr('AUSCHALE_K\00DCRZ:FK_\00DCBERNACHTUNGSPAUSCHALE:GESAMT:FK_STATUS_VP_VOLL:FK_STATUS_VP_TEIL:FK_STATUS_VP_K\00DCRZ:FK_STATUS_\00DCP:MODIFY_DATE:PK_ARBEITSTAGE:DATUM:TAG:MONAT:JAHR:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:WOCHENTAG:WE:FK_FR\00DCHSTUECK:FK_ORT:FK_FEIER')
||'TAG:'
,p_sort_column_1=>'DATUM_VERPFMWED'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>unistr('FK_VERPFLEGUNGSPAUSCHALE_VOLL:FK_VERPFLEGUNGSPAUSCHALE_TEIL:FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ:FK_\00DCBERNACHTUNGSPAUSCHALE:GESAMT')
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18072039019060671)
,p_report_id=>wwv_flow_api.id(26899764854093374)
,p_name=>'Gesamt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'GESAMT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("GESAMT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0DCE0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18072439999060673)
,p_report_id=>wwv_flow_api.id(26899764854093374)
,p_name=>'we'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("WE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E0E0DD'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27194982845216669)
,p_plug_name=>'Verpflegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(13608881527914575)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7696346451527574)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35485954118131583)
,p_plug_name=>'Lex_buchung'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7667754196527536)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35483159760131556)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(35485954118131583)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,pk_VERPFLEGUNGSMEHRAUFWD_DET ) sel,',
'    det.*,',
'',
'     bel.PK_REL_VERPFL_BELEG_SRC,',
'       bel.FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_STUNDENZETTEL,',
'      bel.COMM bel_comm,',
'       bel.FK_STATUS bel_fk_status,',
'',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P327_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      ll.habenkto,',
'      ll.sollkto,',
'      ll.ust_kto,',
'      ',
unistr('      case when inp.fk_kategorie = 314 or inppos.fk_kategorie = 314 then 1 else 0 end fr\00FCh,'),
'      case when inp.fk_kategorie = 42 then 1 else 0 end rest,',
'      ',
'     case when  kat."FK_Oberkategorie" = 694 and  katpos."FK_Oberkategorie" = 694 then 1 else 0 end hotel,',
'     case when FK_VERPFLEGUNGSPAUSCHALE_VOLL>0 or FK_VERPFLEGUNGSPAUSCHALE_TEIL>0 then 1 else 0 end verpf,',
'      case when (FK_VERPFLEGUNGSPAUSCHALE_VOLL>0 or FK_VERPFLEGUNGSPAUSCHALE_TEIL>0)  and inp.fk_kategorie = 42 and sollkto = 6642 then 1 ',
'           when (FK_VERPFLEGUNGSPAUSCHALE_VOLL>0 or FK_VERPFLEGUNGSPAUSCHALE_TEIL>0 ) and inp.fk_kategorie = 42 and sollkto <> 6642 then 2 ',
'           else 0 end chk_buch',
'   ',
'from t_verpflegungsmehraufwand_det det ',
'   left join T_REL_VERPFL_BEleG_SRC bel on bel.fk_verpflegungsmehraufwd_det = det.pk_verpflegungsmehraufwd_det',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_rel_lex_kto_bel relbel on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation  = relbel.fk_relation ',
'      left join t_konto_buch_kat katpos on katpos.pk_konto_buch_kat = inppos.fk_kategorie',
'   left join t_konto_buch_kat katposob on katposob.pk_konto_buch_kat = katpos."FK_Oberkategorie"',
'   left join t_konto_buch_kat kat on kat.pk_konto_buch_kat = inp.fk_kategorie',
'',
' where det.FK_VERPFLEGUNGSMEHRAUFWand = :P327_PK_VERPFLEGUNGSMEHRAUFWAND'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(35483357616131558)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>35483357616131558
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17784472834963660)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17784860471963662)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17785267262963662)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17785686049963662)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17786092963963662)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_SRC'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Pk Rel Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17786443012963664)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17786840594963664)
,p_db_column_name=>'FK_STUNDENZETTEL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17787250394963664)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17787680425963665)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17788060850963665)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17788455489963665)
,p_db_column_name=>'INP_BEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17788808933963667)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17789202131963667)
,p_db_column_name=>'HABENKTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17789608731963667)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17790065620963668)
,p_db_column_name=>'UST_KTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702153747167936)
,p_db_column_name=>'PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Pk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702296285167937)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWAND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Verpflegungsmehraufwand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702343785167938)
,p_db_column_name=>'DATUM_VERPFMWED'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Datum Verpfmwed'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702447878167939)
,p_db_column_name=>'FK_DATUM_VERPFMWED'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Datum Verpfmwed'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702548012167940)
,p_db_column_name=>'DESCR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702698438167941)
,p_db_column_name=>'FK_ORT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702754214167942)
,p_db_column_name=>unistr('FK_FR\00DCHSTUECK')
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>unistr('Fk Fr\00FChstueck')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702829447167943)
,p_db_column_name=>'FK_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Verpflegungspauschale Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17702973116167944)
,p_db_column_name=>'FK_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fk Verpflegungspauschale Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703013253167945)
,p_db_column_name=>unistr('FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ')
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>unistr('Fk Verpflegunspauschale K\00FCrz')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703197950167946)
,p_db_column_name=>unistr('FK_\00DCBERNACHTUNGSPAUSCHALE')
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>unistr('Fk \00DCbernachtungspauschale')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703276086167947)
,p_db_column_name=>'FK_STATUS_VP_VOLL'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Status Vp Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703363732167948)
,p_db_column_name=>'FK_STATUS_VP_TEIL'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk Status Vp Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703417035167949)
,p_db_column_name=>unistr('FK_STATUS_VP_K\00DCRZ')
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('Fk Status Vp K\00FCrz')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17703511647167950)
,p_db_column_name=>unistr('FK_STATUS_\00DCP')
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>unistr('Fk Status \00DCp')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791493305062101)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791593289062102)
,p_db_column_name=>'BEL_COMM'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Bel Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791674585062103)
,p_db_column_name=>'BEL_FK_STATUS'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bel Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791751672062104)
,p_db_column_name=>unistr('FR\00DCH')
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>unistr('Fr\00FCh')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791857927062105)
,p_db_column_name=>'REST'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Rest'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17791907159062106)
,p_db_column_name=>'HOTEL'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Hotel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17792098847062107)
,p_db_column_name=>'VERPF'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Verpf'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17792138798062108)
,p_db_column_name=>'CHK_BUCH'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Chk Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17792282214062109)
,p_db_column_name=>'SEL'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(35566657054869405)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'177904'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'BEL_DATUM:VERPF:FK_STATUS:COMM:FK_INP_BELEGE_ALL:CHK_BUCH:CREATION_DATE:PK_REL_VERPFL_BELEG_SRC:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_STUNDENZETTEL:PK_INP_BELEGE_ALL:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:HABENKTO:SOLLKTO:UST_KTO:PK_VERPFLEGUNGSMEHRAUFWD_DET:'
||unistr('FK_VERPFLEGUNGSMEHRAUFWAND:DATUM_VERPFMWED:FK_DATUM_VERPFMWED:DESCR:FK_ORT:FK_FR\00DCHSTUECK:FK_VERPFLEGUNGSPAUSCHALE_VOLL:FK_VERPFLEGUNGSPAUSCHALE_TEIL:FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ:FK_\00DCBERNACHTUNGSPAUSCHALE:FK_STATUS_VP_VOLL:FK_STATUS_VP_TEIL:FK_STATUS_')
||unistr('VP_K\00DCRZ:FK_STATUS_\00DCP:MODIFY_DATE:BEL_COMM:BEL_FK_STATUS:FR\00DCH:REST:HOTEL::SEL')
,p_sort_column_1=>'SOLLKTO'
,p_sort_direction_1=>'ASC'
,p_break_on=>'BEL_DATUM'
,p_break_enabled_on=>'BEL_DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17822930716369853)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHK_BUCH'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHK_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#558555'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17823310214369854)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'nok_buch'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHK_BUCH'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("CHK_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17823758348369854)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>unistr('fr\00FCh')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('FR\00DCH')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("FR\00DCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17824141407369854)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'hotel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HOTEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("HOTEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17824527778369854)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'rest'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'REST'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("REST" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B6CBE0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17824992118369856)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'buch'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SOLLKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B6BDB6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17825333827369856)
,p_report_id=>wwv_flow_api.id(35566657054869405)
,p_name=>'verpf'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERPF'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERPF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0E0E0'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13493067210959430)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(26845374767868521)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_FK_VERPFLEGUNGSMEHRAUFWAND,P329_PK_VERPFLEGUNGSMEHRAUFWD_DET:&P327_PK_VERPFLEGUNGSMEHRAUFWAND.,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15208093477483432)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(15207931877483431)
,p_button_name=>'Create_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_FK_VERPFLEGUNGSMEHRAUFWAND,P329_PK_VERPFLEGUNGSMEHRAUFWD_DET:&P327_PK_VERPFLEGUNGSMEHRAUFWAND.,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17792351453062110)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(35483159760131556)
,p_button_name=>'del_verpfl_det'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'del_verpfl_det'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15208139723483433)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(15207931877483431)
,p_button_name=>'Select_inp_belege_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13358985438622896)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'Create_inp_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Create Inp Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13493258517959432)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'Update_date'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Update Date'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13608416156870468)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(26845374767868521)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13613115146959198)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13358603323621196)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13300429244365507)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P327_PK_VERPFLEGUNGSMEHRAUFWAND'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13299213047365503)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13300891126365507)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P327_PK_VERPFLEGUNGSMEHRAUFWAND'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13300082939365506)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13294096990365471)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P327_PK_VERPFLEGUNGSMEHRAUFWAND'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(13301120458365507)
,p_branch_action=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13294395862365478)
,p_name=>'P327_PK_VERPFLEGUNGSMEHRAUFWAND'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pk Verpflegungsmehraufwand'
,p_source=>'PK_VERPFLEGUNGSMEHRAUFWAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13295139040365495)
,p_name=>'P327_FK_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Fk Jahr'
,p_source=>'FK_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value, std_value',
'from t_std ',
'where fk_std_group = 221'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13295533935365495)
,p_name=>'P327_FK_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std ',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13295943772365496)
,p_name=>'P327_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13296372489365496)
,p_name=>'P327_FK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13296791551365498)
,p_name=>'P327_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13307662805416425)
,p_name=>'P327_FK_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Fk Monat'
,p_source=>'FK_MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Januar;1,Februar;2,M\00E4rz;3,April;4,Mai;5,Juni;6,Juli;7,August;8,September;9,Oktober;10,November;11,Dezember;12')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13358341176619423)
,p_name=>'P327_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13491318214959413)
,p_name=>'P327_FK_STEUER_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(13294096990365471)
,p_item_source_plug_id=>wwv_flow_api.id(13294096990365471)
,p_prompt=>'Fk Steuer Monat'
,p_source=>'FK_STEUER_MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select monat || '' '' || jahr, pk_steuer_monat',
'from t_steuer_monat'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14043768282101127)
,p_name=>'P327_BUCHUNGSVORGABE_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14043852357101128)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Verpflegungsmehraufwand '' ||  to_char(to_date(',
'                    ''01.'' || nvl(:P327_fk_monat,1) || ''.1900''',
'                ,''DD.MM.YYYY'') ,''MON'')',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Buchungsvorgabe Text'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14043995153101129)
,p_name=>'P327_BUCHUNGSVORGABE_DATUM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14043852357101128)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select to_date(',
'                    ''01.''|| ',
'                    case when :P327_fk_monat = 12 then 1 else (nvl(:P327_fk_monat,1)+1) end || ''.'' ||  ',
'                    case when :P327_fk_monat = 12 then nvl(:P327_fk_jahr,1900) + 1 else to_number(nvl(:P327_fk_jahr,1900))  end',
'                    --else nvl(:P327_fk_jahr,1900) end',
'                ,''DD.MM.YYYY'')-1  ',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Buchungsvorgabe Datum'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14044064089101130)
,p_name=>'P327_BETRAG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14043852357101128)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'     select sum(',
'              FK_VERPFLEGUNGSPAUSCHALE_VOLL+',
'       FK_VERPFLEGUNGSPAUSCHALE_TEIL+',
unistr('       "FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ"+'),
unistr('       "FK_\00DCBERNACHTUNGSPAUSCHALE") gesamt'),
'  from T_VERPFLEGUNGSMEHRAUFWAND_DET',
' where fk_verpflegungsmehraufwand = :P327_PK_Verpflegungsmehraufwand'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14044155067101131)
,p_name=>'P327_SOLLKONTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14043852357101128)
,p_item_default=>'6674'
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14044290430101132)
,p_name=>'P327_HABENKONTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14043852357101128)
,p_item_default=>'2180'
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13302076930365514)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(13294096990365471)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Verpflegungsmehraufwand'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13157898603804020)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_inp_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'insert into inp_belege_ALL (',
'',
'bel_datum,',
'bezeichnung,',
'--brutto_betrag,',
'fk_STATUS,',
'--fk_Kategorie,',
'--fk_verwendungszweck,',
'fk_abl_ordner_page,',
'comm_sonstiges,',
'create_at,',
'modify_at',
')',
'select ',
'''01.''||fk_monat||''.''||fk_jahr bt,',
'''Verpflegungsmehraufwand'' || '' '' || fk_monat || '' '' || fk_jahr,',
'--abs("Betrag") Betrag,',
'6 Status,',
'--"FK_Kategorie" ,',
'--"FK_Verwendungszweck",',
':P327_FK_ABL_ORDNER_PAGE,',
'''erstellt aus Verpflegungsmehraufwand '' ,',
'sysdate,',
'sysdate',
'from t_verpflegungsmehraufwand; -- &P321_FK_MAIN_KEY.;',
'commit;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13358985438622896)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13493390283959433)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Datum'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'merge into t_verpflegungsmehraufwand_det t1',
'  using (',
'        select pk_arbeitstage, ',
'        pk_verpflegungsmehraufwd_det',
'',
'        from (select * from t_verpflegungsmehraufwand_det where DATUM_VERPFMWED is not null and fk_DATUM_VERPFMWED is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.DATUM_VERPFMWED,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_verpflegungsmehraufwd_det = t2.pk_verpflegungsmehraufwd_det)',
'        when matched then',
'        update set t1.fk_DATUM_VERPFMWED= t2.pk_arbeitstage;',
'        commit;',
'  end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17792473597062111)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'del_verpf_det'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'       delete from t_verpflegungsmehraufwand_det where pk_verpflegungsmehraufwd_det = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13301683858365514)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(13294096990365471)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Verpflegungsmehraufwand'
);
wwv_flow_api.component_end;
end;
/
