prompt --application/pages/page_00339
begin
--   Manifest
--     PAGE: 00339
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>339
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Verpflegungsmehraufwand_Bel'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Verpflegungsmehraufwand_Bel'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(13610231510939284)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200306144431'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13584497336270424)
,p_plug_name=>'Verpflegungsmehraufwand_ort'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select',
' apex_item.checkbox2(1, pk_rel_verpfl_beleg_ort) sel,',
' belort.*, ort',
'from t_rel_verpfl_beleg_ort belort',
'',
' left join t_ort ort on ort.pk_ort = belort.fk_ort',
'where fk_verpflegungsmehraufwd_det = :P339_fk_verpflegungsmehraufwd_det or :P339_fk_verpflegungsmehraufwd_det is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13584576919270425)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13584576919270425
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13584796477270427)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13585235803270432)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13585531815270435)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'C'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13585780313270437)
,p_db_column_name=>'FK_ORT'
,p_display_order=>120
,p_column_identifier=>'E'
,p_column_label=>'Fk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13585888934270438)
,p_db_column_name=>'FK_AUSWAERTS'
,p_display_order=>130
,p_column_identifier=>'F'
,p_column_label=>'Fk Auswaerts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17792942740062116)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_ORT'
,p_display_order=>140
,p_column_identifier=>'G'
,p_column_label=>'Pk Rel Verpfl Beleg Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18043395904873930)
,p_db_column_name=>'SEL'
,p_display_order=>150
,p_column_identifier=>'H'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13899341755427245)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'138994'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_VERPFLEGUNGSMEHRAUFWD_DET:CREATION_DATE:ORT:FK_ORT:FK_AUSWAERTS:PK_REL_VERPFL_BELEG_ORT:SEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13585996312270439)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13890328635377576)
,p_plug_name=>'Verpflegungsmehraufwand_Bel'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2,pk_rel_verpfl_beleg_src) sel,',
'',
'belsrc.*, inp.bezeichnung, inp.bel_datum, ort',
'from t_rel_verpfl_beleg_src belsrc',
' left join inp_belege_all inp on belsrc.fk_inp_belege_all = inp.pk_inp_belege_all',
' left join t_ort ort on ort.pk_ort = inp.fk_city',
'where fk_verpflegungsmehraufwd_det = :P339_fk_verpflegungsmehraufwd_det or :P339_fk_verpflegungsmehraufwd_det is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13890460664377576)
,p_name=>'Verpflegungsmehraufwand_Bel'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13890460664377576
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13890877234377584)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_SRC'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13891232349377593)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13891609668377593)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892012343377595)
,p_db_column_name=>'FK_STUNDENZETTEL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Stundenzettel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892461097377595)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892802111377595)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893280003377595)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893618141377595)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13894069607377595)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13894456519377595)
,p_db_column_name=>'ORT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17944063731299040)
,p_db_column_name=>'SEL'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13898734778427217)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'138988'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_VERPFL_BELEG_SRC:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_INP_BELEGE_ALL:FK_STUNDENZETTEL:ORT:COMM:FK_STATUS:CREATION_DATE:BEZEICHNUNG:BEL_DATUM::SEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18041930297873916)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7667754196527536)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17795144879062138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13584497336270424)
,p_button_name=>'add_ort'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Ort'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:RP:P340_FK_VERPFLEGUNGSMEHRAUFWD_DET,P340_FK_ARBEITSTAG:&P339_FK_VERPFLEGUNGSMEHRAUFWD_DET.,&P339_FK_ARBEITSTAG.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17795448966062141)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13890328635377576)
,p_button_name=>'add_beleg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Beleg'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:367:&SESSION.::&DEBUG.:RP:P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,P367_FK_AREITSTAG:&P339_FK_VERPFLEGUNGSMEHRAUFWD_DET.,&P339_FK_ARBEITSTAG.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18043155847873928)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13584497336270424)
,p_button_name=>'remove_ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Remove Ort'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18043465034873931)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(13890328635377576)
,p_button_name=>'Kontoauszug_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17943979842299039)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(13890328635377576)
,p_button_name=>'del_vepf_det'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Del Vepf Det'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18082692816495193)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(18041930297873916)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18042142322873918)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(18041930297873916)
,p_button_name=>'create_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17944236885299042)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(13584497336270424)
,p_button_name=>'change_verpfl_beleg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Change Verpfl Beleg'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_redirect_url=>'f?p=&APP_ID.:368:&SESSION.::&DEBUG.:RP:P368_PK_VERPFLEGUNGSMEHRAUFWD_DET:&P339_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13586068065270440)
,p_name=>'P339_FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13585996312270439)
,p_prompt=>'Fk Verpflegungsmehraufwd Det'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17943887822299038)
,p_name=>'P339_FK_ARBEITSTAG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13585996312270439)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum, pk_arbeitstage',
'from t_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18042084575873917)
,p_name=>'P339_FK_MAIN_KEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18041930297873916)
,p_prompt=>'Fk Main Key'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_main_key d, fk_main_key r',
'from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18042243154873919)
,p_name=>'P339_FK_ABL_ORDNER_PAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(18041930297873916)
,p_item_default=>'1'
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pk_abl_ordner_page d, pk_abl_ordner_page r',
'from t_abl_ordner_page'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17944108287299041)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'del_bel_det'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'      delete from t_rel_verpfl_beleg_src where pk_rel_verpfl_beleg_src = apex_application.g_f02(i) ;',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17943979842299039)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18042394545873920)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'new_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' p_add_new_inp_bel_kto (:P339_FK_MAIN_KEY, :P339_PK_ABL_ORNDER_PAGE);',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18042142322873918)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18043207727873929)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'         delete from t_rel_verpfl_beleg_ort where pk_rel_verpfl_beleg_ort = apex_application.g_f01(i) ;',
'      commit;',
'',
'     end if;',
'     end loop;',
'     ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18043155847873928)
);
wwv_flow_api.component_end;
end;
/
