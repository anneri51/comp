prompt --application/pages/page_00351
begin
--   Manifest
--     PAGE: 00351
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>351
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'splitbuchung_storno'
,p_step_title=>'splitbuchung_storno'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090610'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14439701179335706)
,p_plug_name=>'t_lex_long'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14542692094691616)
,p_plug_name=>'splitbuchung_lex_long'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
'    substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4) split_nr_neu,  ',
'    split_nr,',
'    substr(fk_relation_main,length(substr(fk_relation_main,1,instr(fk_relation_main,''/'',-1)))+1,4) fin_relation_main,  ',
'    flg_split_buch,',
'    count(*) cnt,',
'    case when  substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4) > 0 then sum(case when substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4)>0 then 1 else 0 end ) - count(*)  end diff_split_buch',
'from t_lex_long ',
'group by substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4), ',
'split_nr,',
' substr(fk_relation_main,length(substr(fk_relation_main,1,instr(fk_relation_main,''/'',-1)))+1,4),',
' flg_split_buch',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14542802726691616)
,p_name=>'splitbuchung'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15983122002083156
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14543206872691627)
,p_db_column_name=>'SPLIT_NR_NEU'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Split Nr Neu'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14543607090691639)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14544078351691639)
,p_db_column_name=>'FIN_RELATION_MAIN'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fin Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14544432096691641)
,p_db_column_name=>'CNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14439599724335705)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>14
,p_column_identifier=>'E'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14556140063744391)
,p_db_column_name=>'DIFF_SPLIT_BUCH'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'Diff Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14551529360716117)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'159919'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SPLIT_NR_NEU:SPLIT_NR:FIN_RELATION_MAIN:CNT:FLG_SPLIT_BUCH:DIFF_SPLIT_BUCH'
,p_break_on=>'SPLIT_NR_NEU'
,p_break_enabled_on=>'SPLIT_NR_NEU'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14553375884744363)
,p_plug_name=>'splitbuchung_ktbl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
'    substr(fk_relation_sub,length(substr(fk_relation_sub,1,instr(fk_relation_sub,''/'',-1)))+1,4) split_nr_neu,  ',
'    split_nr,',
'    substr(fk_relation,length(substr(fk_relation,1,instr(fk_relation,''/'',-1)))+1,4) fin_relation,  ',
'    flg_split_buch,',
'    SPLIT_NR_MAN,',
'    count(*) cnt,',
'    case when substr(fk_relation_sub,length(substr(fk_relation_sub,1,instr(fk_relation_sub,''/'',-1)))+1,4) > 0 then  sum(case when datum_split_ok is not null then 1 else 0 end) - count(*) end split_ok,',
'     substr(fk_relation_main,length(substr(fk_relation_main,1,instr(fk_relation_main,''/'',-1)))+1,4) fin_relatin_main',
'from imp_kontenblatt_2018 kto',
'  full join (select fk_relation_main from  t_lex_long ) ll on kto.fk_relation = ll.fk_relation_main',
'group by ',
'',
'    substr(fk_relation_sub,length(substr(fk_relation_sub,1,instr(fK_relation_sub,''/'',-1)))+1,4) ,  ',
'    split_nr,',
'    substr(fk_relation,length(substr(fk_relation,1,instr(fk_relation,''/'',-1)))+1,4) ,',
'    flg_split_buch,',
'    SPLIT_NR_MAN,',
'         substr(fk_relation_main,length(substr(fk_relation_main,1,instr(fk_relation_main,''/'',-1)))+1,4)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14553415827744364)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15993735103135904
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14553498270744365)
,p_db_column_name=>'SPLIT_NR_NEU'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Split Nr Neu'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14553598925744366)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14553794127744368)
,p_db_column_name=>'CNT'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14553909985744369)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14553988288744370)
,p_db_column_name=>'FIN_RELATION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fin Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14554158244744371)
,p_db_column_name=>'SPLIT_NR_MAN'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Split Nr Man'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14556053266744390)
,p_db_column_name=>'SPLIT_OK'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Split Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14556227024744392)
,p_db_column_name=>'FIN_RELATIN_MAIN'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Fin Relatin Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14560844639785839)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'160012'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SPLIT_NR_NEU:SPLIT_NR:CNT:FLG_SPLIT_BUCH:FIN_RELATION:SPLIT_NR_MAN:SPLIT_OK:FIN_RELATIN_MAIN'
,p_break_on=>'SPLIT_NR'
,p_break_enabled_on=>'SPLIT_NR'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14556311878744393)
,p_plug_name=>'splitbuchung_ktbl_ov'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when id is not null then 1 else 0 end id, case when relation is not null then 1 else 0 end relation, case when fk_relation is not null then 1 else 0 end fk_relation,  count(*) cnt, ll_jahr, kto_jahr, nvl(ll_jahr, kto_jahr) jahr, ',
'case when  nvl(ll_jahr, kto_jahr) = to_number(jr.std_name) then 1 else 0 end act_jahr, case when ll_jahr = kto_jahr then 1 else 0 end ov_jahr, kto.flg_split_buch, fin_relation, ll_flg_split_buch',
'from (',
'',
'select kto.id, relation, fk_relation, kto.jahr kto_jahr, ll.jahr ll_jahr, kto.flg_split_buch, fin_relation, ll.flg_split_buch ll_flg_split_buch',
'from imp_kontenblatt_2018 kto',
'  full join (select jahr, fk_relation_main, relation, case when substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4) >0 then 1 else 0 end fin_relation, flg_split_buch from  t_lex_long ) ll on kto.fk_relation = ll.fk_relation_main',
'--where relation is null',
'  ) kto,',
'  (select * from t_std where fk_std_group =221  and mark = 1) jr',
'',
'group by case when id is not null then 1 else 0 end, case when relation is not null then 1 else 0 end, case when fk_relation is not null then 1 else 0 end, ll_jahr, kto_jahr, nvl(ll_jahr, kto_jahr), std_name , kto.flg_split_buch, fin_relation,ll_flg_'
||'split_buch'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14556434167744394)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15996753443135934
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14557773378744407)
,p_db_column_name=>'LL_JAHR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ll Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14557855559744408)
,p_db_column_name=>'KTO_JAHR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14557901691744409)
,p_db_column_name=>'JAHR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720208086796263)
,p_db_column_name=>'ID'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720305698796264)
,p_db_column_name=>'RELATION'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720422725796265)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>'Fk Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720519314796266)
,p_db_column_name=>'CNT'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720605360796267)
,p_db_column_name=>'OV_JAHR'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Ov Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720701884796268)
,p_db_column_name=>'ACT_JAHR'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Act Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720835556796269)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720979435796270)
,p_db_column_name=>'FIN_RELATION'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Fin Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14720995586796271)
,p_db_column_name=>'LL_FLG_SPLIT_BUCH'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'Ll Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14717480608753625)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'161578'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:ID:RELATION:FK_RELATION:CNT:OV_JAHR:ACT_JAHR:LL_JAHR:KTO_JAHR::FLG_SPLIT_BUCH:FIN_RELATION:LL_FLG_SPLIT_BUCH'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14740877724987167)
,p_report_id=>wwv_flow_api.id(14717480608753625)
,p_name=>'nok1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KTO_JAHR'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("KTO_JAHR" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14741240050987167)
,p_report_id=>wwv_flow_api.id(14717480608753625)
,p_name=>'nok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LL_JAHR'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("LL_JAHR" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14741672599987167)
,p_report_id=>wwv_flow_api.id(14717480608753625)
,p_name=>'ok2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OV_JAHR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OV_JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B6DEB6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14740478503987167)
,p_report_id=>wwv_flow_api.id(14717480608753625)
,p_name=>'act_jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ACT_JAHR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ACT_JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14723389479796295)
,p_plug_name=>'splitbuchung_ktbl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_lex_storno, buchungsstatus,status, count(*), kto.jahr kto_jahr, ll.jahr ll_jahr, nvl(ll.jahr, kto.jahr) comb_jahr',
'from t_lex_long ll',
'  full join imp_kontenblatt_2018 kto on ll.relation = kto.fk_relation_sub',
'group by  fk_lex_storno, buchungsstatus,status, kto.jahr, ll.jahr, nvl(ll.jahr, kto.jahr) '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14723550940796296)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>16163870216187836
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724477278796305)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724539223796306)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724665293796307)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724772886796308)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724827163796309)
,p_db_column_name=>'KTO_JAHR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kto Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14724916412796310)
,p_db_column_name=>'LL_JAHR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ll Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14875365277356761)
,p_db_column_name=>'COMB_JAHR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14882892010358824)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'163233'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_LEX_STORNO:BUCHUNGSSTATUS:STATUS:COUNT(*):KTO_JAHR:LL_JAHR:COMB_JAHR'
,p_break_on=>'COMB_JAHR'
,p_break_enabled_on=>'COMB_JAHR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14439862978335707)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14439968518335708)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'2_set_split_t_lex_long'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'2 Set Split T Lex Long'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14553093691744361)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'3_merge_into_kontenbl'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'3 Merge Into Kontenbl'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14723170617796292)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'2_set_storno_from_t_lex_to_imp_ktbl'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'2 Set Storno From T Lex To Imp Ktbl'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14723302327796294)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'3_set_storno_to_llex_from_imp_ktbl'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'3 Set Storno To Llex From Imp Ktbl'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14722846780796289)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14439701179335706)
,p_button_name=>'1_set_Storno_llex'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'1 Set Storno Llex'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14439991892335709)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14439862978335707)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14554272925744372)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_set_relation_lex_long'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'         ',
'merge into t_lex_long t1',
' using (',
' ',
' ',
'select relation, substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4) split_nr_neu,  split_nr, case when substr(relation,length(substr(relation,1,instr(relation,''/'',-1)))+1,4)>0 then 1 else 0 end  FLG_SPLIT_BUCH from t_lex_long',
'     ',
'    ',
' ) t2 on (t1.relation = t2.relation)',
' when matched then ',
'  update set t1.split_nr = t2.split_nr_neu,',
'  t1.flg_split_buch = t2.flg_split_buch;',
'  commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14439968518335708)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14553225731744362)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_merge_into_kontenbl'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' merge into imp_kontenblatt_2018 t1',
' using (',
'select  kto.id , max(ll.split_nr) split_nr, max(ll.flg_split_buch) flg_split_buch',
'from imp_kontenblatt_2018 kto ',
' left join t_lex_long ll ',
'   on  substr(relation,instr(relation,''/'')+1,instr( substr(relation,instr(relation,''/'')+1, length(relation)),''/'')-1) = kto.buchungsnummer and kto.jahr = ll.jahr',
'group by kto.id',
'   ) t2 on (t1.id = t2.id)',
'   when matched then ',
'   update set t1.split_nr = t2.split_nr,',
'   t1.flg_split_buch = t2.flg_split_buch;',
'   commit;',
'   ',
'      ',
'    merge into imp_kontenblatt_2018 t1',
' using (',
'select  kto.id , max(ll.split_nr) split_nr, max(ll.flg_split_buch) flg_split_buch',
'from imp_kontenblatt_2018 kto ',
'  left join imp_kontenblatt_2018 kto2 on kto.id = kto2.id',
' left join (',
' --0',
'   select nvl(habenkto,0) habenkto, nvl(sollkto,0) sollkto, nvl(ust_kto,0) ust_kto, relation, null rel, fk_relation_main, null rel_main, split_nr, jahr, flg_split_buch',
'   from t_lex_long',
'   where flg_split_buch = 1',
'   and split_nr  = 0',
'   union',
'--1',
' select nvl(ll_0.habenkto,ll_1.habenkto) habenkto, nvl(ll_0.sollkto,ll_1.sollkto) sollkto, nvl(ll_0.ust_kto,ll_1.ust_kto) ust_kto, ll_0.relation, ll_0.fk_relation_main, ll_1.relation, ll_1.fk_relation_main, ll_1.split_nr, ll_0.jahr, ll_1.flg_split_bu'
||'ch',
' from (  select *',
'   from t_lex_long',
'   where flg_split_buch = 1',
'   and split_nr  = 0) ll_0',
'     left join (  select *',
'   from t_lex_long',
'   where flg_split_buch = 1',
'   and split_nr  >0) ll_1 on ll_0.fk_relation_main = ll_1.fk_relation_main',
'   union',
'    select  nvl(ll_0.sollkto,ll_1.sollkto) sollkto, nvl(ll_0.habenkto,ll_1.habenkto) habenkto, nvl(ll_0.ust_kto,ll_1.ust_kto) ust_kto, ll_0.relation, ll_0.fk_relation_main, ll_1.relation, ll_1.fk_relation_main, ll_1.split_nr, ll_0.jahr, ll_1.flg_spli'
||'t_buch',
' from (  select *',
'   from t_lex_long',
'   where flg_split_buch = 1',
'   and split_nr  = 0) ll_0',
'     left join (  select *',
'   from t_lex_long',
'   where flg_split_buch = 1',
'   and split_nr  >0) ll_1 on ll_0.fk_relation_main = ll_1.fk_relation_main',
'',
' ',
' ',
' ',
' ',
' ) ll ',
'   on  substr(relation,instr(relation,''/'')+1,instr( substr(relation,instr(relation,''/'')+1, length(relation)),''/'')-1) = kto.buchungsnummer and kto.jahr = ll.jahr and ll.habenkto = kto2.kontonummer and ll.sollkto = kto2.gegenkonto and ll.ust_kto = kto.'
||'ustkonto',
'group by kto.id',
'   ) t2 on (t1.id = t2.id)',
'   when matched then ',
'   update set t1.split_nr = nvl(t2.split_nr,0),',
'   t1.flg_split_buch = nvl(t2.flg_split_buch,0);',
'   commit;',
'   ',
'   update t_lex_long set flg_split_buch = 1 where fk_relation_main in (select distinct fk_relation_main from t_lex_long where flg_split_buch = 1);',
'commit;',
'',
'update imp_kontenblatt_2018 set flg_split_buch = 1 where  fk_relation in (select distinct fk_relation from imp_kontenblatt_2018 where flg_split_buch = 1);',
'commit;',
'',
'update imp_kontenblatt_2018 set flg_split_buch = 1 where  fk_relation in (select distinct fk_relation from imp_kontenblatt_2018 where flg_split_buch = 1);',
'commit;',
'',
'',
'merge into imp_kontenblatt_2018 t1',
'using (',
'select kto2.id, max(kto.split_nr) split_nr_neu, max(kto.flg_split_buch) flg_split_buch_neu, max(kto.fk_relation_sub) fk_relation_sub_neu',
'from (select * from imp_kontenblatt_2018 where flg_split_buch = 1 and ustkonto in (1401,1406)) kto',
'   join (select * from imp_kontenblatt_2018 where flg_split_buch = 1) kto2 on kto.ustkonto = to_number(kto2.kontonummer) and kto.fk_relation = kto2.fk_relation',
'   group by kto2.id',
'   ) t2 on (t1.id = t2.id)',
'when matched then',
' update set t1.split_nr = t2.split_nr_neu,',
' t1.flg_split_buch = t2.flg_split_buch_neu,',
' t1.fk_relation_sub = t2.fk_relation_sub_neu;',
' commit;',
'   ',
'   ',
'   ',
'update imp_kontenblatt_2018 set flg_split_buch = 1 where fk_relation in (select ll.fk_relation_main',
'from t_lex_long ll',
'  left join imp_kontenbLatt_2018 kto on ll.relation = kto.fk_relation',
'where ll.flg_split_buch = 1',
'and kto.flg_split_buch = 0',
'and ll.jahr = 2018',
');',
'commit;',
' end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14553093691744361)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14722978390796290)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_Storno_lex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'update t_lex_long set fk_lex_storno = 1 where status is not null and fk_lex_storno is null;',
'commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14723032957796291)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_set_storno_from_t_lex_to_imp_ktbl'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'update imp_kontenblatt_2018 set buchungsstatus = 2 where id in (',
'',
'select kto.id',
'from t_lex_long ll',
' join imp_kontenblatt_2018 kto on ll.relation = kto.fk_relation_sub',
'where fk_lex_storno = 1',
' and ( buchungsstatus is null or buchungsstatus = 1));',
' commit;',
' end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14723170617796292)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14723256759796293)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_set_storno_to_llex_from_imp_ktbl'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update t_lex_long set fk_lex_storno = 1 where relation in (',
'',
'select relation',
'from t_lex_long ll',
' join imp_kontenblatt_2018 kto on ll.relation = kto.fk_relation_sub',
'where (fk_lex_storno is null or fk_lex_storno <> 1)',
' and ( buchungsstatus =2));',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14723302327796294)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15173006150334917)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14439862978335707)
);
wwv_flow_api.component_end;
end;
/
