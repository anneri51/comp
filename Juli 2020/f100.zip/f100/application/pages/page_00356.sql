prompt --application/pages/page_00356
begin
--   Manifest
--     PAGE: 00356
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>356
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'kontenabgleich_2017'
,p_step_title=>'kontenabgleich_2017'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44341901507941496)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090708'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16660448962510829)
,p_plug_name=>'kontenabgleich_2018'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2020_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2020 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2018'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16660579976510830)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>16660579976510830
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660677893510831)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660766507510832)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660827858510833)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16660942073510834)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661019760510835)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661166511510836)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661266368510837)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661331577510838)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661413802510839)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661512024510840)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661630980510841)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661710450510842)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661816290510843)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16661942208510844)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857251628571001)
,p_db_column_name=>'RNR'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857326979571002)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857476059571003)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857543908571004)
,p_db_column_name=>'RNR1'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857657608571005)
,p_db_column_name=>'ID'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857747243571006)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16857885979571007)
,p_db_column_name=>'DATUM'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16872165958607042)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'168722'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KTO2_BUCH:JAHR_IST:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGDATUM:KTO2_DATUM:MISS:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEITSTAGE:DATUM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16858172964571010)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31427611439596590)
,p_plug_name=>'kontenabgleich_2017'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
', kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2017_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2017 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2017'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(31427646400596590)
,p_name=>'kontenabgleich'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>31427646400596590
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16330285468905192)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16330615757905192)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16331057577905193)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16331419638905193)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16331853684905195)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16332240222905195)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16332647075905195)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16333049283905195)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16333478931905195)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16325849514905171)
,p_db_column_name=>'JAHR'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16326256346905184)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16326651931905184)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16327004518905185)
,p_db_column_name=>'MISS'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16327422293905185)
,p_db_column_name=>'KTO2_HABENBETR'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Kto2 Habenbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16327857911905185)
,p_db_column_name=>'KTO2_SOLLBETR'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Kto2 Sollbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16328294416905187)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>79
,p_column_identifier=>'P'
,p_column_label=>'Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16328652909905187)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>89
,p_column_identifier=>'Q'
,p_column_label=>'Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16329045711905189)
,p_db_column_name=>'DIFF_HABEN'
,p_display_order=>99
,p_column_identifier=>'R'
,p_column_label=>'Diff Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16329479651905189)
,p_db_column_name=>'DIFF_SOLL'
,p_display_order=>109
,p_column_identifier=>'S'
,p_column_label=>'Diff Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16329860206905190)
,p_db_column_name=>'RNR'
,p_display_order=>119
,p_column_identifier=>'T'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16333853460905196)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>129
,p_column_identifier=>'U'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16334259757905196)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>139
,p_column_identifier=>'V'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16334636525905196)
,p_db_column_name=>'RNR1'
,p_display_order=>149
,p_column_identifier=>'W'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16335045100905198)
,p_db_column_name=>'ID'
,p_display_order=>159
,p_column_identifier=>'X'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16335415696905198)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>169
,p_column_identifier=>'Y'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16335881620905198)
,p_db_column_name=>'DATUM'
,p_display_order=>179
,p_column_identifier=>'Z'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16336197288905200)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>189
,p_column_identifier=>'AA'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(31431845529600382)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'163365'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KTO2_BUCH:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGKTO2_MISS:KTO2_HABENBETR:KTO2_SOLLBETR:HABENBETRAG_EUR:SOLLBETRAG_EUR:DIFF_HABEN:DIFF_SOLL:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEIT'
||'STAGE:DATUM:JAHR_IST'
,p_break_on=>'KTO2_BUCH'
,p_break_enabled_on=>'KTO2_BUCH'
,p_count_columns_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16338556985905212)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_name=>'diff_jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF_JAHR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DIFF_JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16338918510905214)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_name=>'dupl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RNR1'
,p_operator=>'>'
,p_expr=>'1'
,p_condition_sql=>' (case when ("RNR1" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F2D9F2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16338176935905212)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_name=>'missing'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("BUCHUNGSNUMMER" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>25
,p_row_bg_color=>'#F0D9D3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16336958260905210)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>'"BUCHUNGSNUMMER" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16337351020905212)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KTO2_KONTO'
,p_operator=>'contains'
,p_expr=>'1600'
,p_condition_sql=>'upper("KTO2_KONTO") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1600  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16337708454905212)
,p_report_id=>wwv_flow_api.id(31431845529600382)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MISS'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"MISS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40518796645285827)
,p_plug_name=>'kontenabgleich_2019'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2019_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2019 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2019'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40518839054285828)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40518839054285828
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40518981861285829)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519079732285830)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519116574285831)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519270394285832)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519328261285833)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519479750285834)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519598718285835)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519688668285836)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519782571285837)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519878190285838)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40519992989285839)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520036960285840)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520163750285841)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520213312285842)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520303704285843)
,p_db_column_name=>'RNR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520478476285844)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520567339285845)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520636339285846)
,p_db_column_name=>'RNR1'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520758132285847)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520879165285848)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40520949734285849)
,p_db_column_name=>'DATUM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40616604198865350)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'406167'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KTO2_BUCH:JAHR_IST:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGDATUM:KTO2_DATUM:MISS:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEITSTAGE:DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40617601789871884)
,p_report_id=>wwv_flow_api.id(40616604198865350)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>'"BUCHUNGSNUMMER" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40618026307871884)
,p_report_id=>wwv_flow_api.id(40616604198865350)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KTO2_KONTO'
,p_operator=>'='
,p_expr=>'1401'
,p_condition_sql=>'"KTO2_KONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40521012180285850)
,p_plug_name=>'kontenabgleich_2020'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2020_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2020 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2020'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40596626193846201)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40596626193846201
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40596792005846202)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40596814385846203)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40596994048846204)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597089811846205)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597185642846206)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597268876846207)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597313034846208)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597433816846209)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597541238846210)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597635050846211)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597724196846212)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597815296846213)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40597991938846214)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598085248846215)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598164322846216)
,p_db_column_name=>'RNR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598296421846217)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598330902846218)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598480083846219)
,p_db_column_name=>'RNR1'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598513793846220)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598675113846221)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40598718487846222)
,p_db_column_name=>'DATUM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16858264446571011)
,p_name=>'P356_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16858172964571010)
,p_prompt=>'Sel'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2017;2017,2018;2018,2019;2019,2020;2020'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
