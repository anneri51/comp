prompt --application/pages/page_00367
begin
--   Manifest
--     PAGE: 00367
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>367
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>unistr('Verpflegungsmehraufw\00E4nde_Detail_Belege_mod')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Verpflegungsmehraufw\00E4nde_Detail_Belege_mod')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091022'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16600327008482363)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2,pk_stundenzettel)  sel,',
'',
'jahr || '' / '' || projekt || '' / '' || beschreibung || '' / '' || zeitraum_von || '' - '' || zeitraum_bis, pk_stundenzettel',
'from t_stundenzettel std',
'  left join t_projekt proj on std.fk_projekt  = proj.pk_projekt'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16600461005482364)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>18040780280873904
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16600704954482367)
,p_db_column_name=>'JAHR||''/''||PROJEKT||''/''||BESCHREIBUNG||''/''||ZEITRAUM_VON||''-''||ZEITRAUM_BIS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr||&#x27;&#x2F;&#x27;||projekt||&#x27;&#x2F;&#x27;||beschreibung||&#x27;&#x2F;&#x27;||zeitraum Von||&#x27;-&#x27;||zeitraum Bis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16600865889482368)
,p_db_column_name=>'PK_STUNDENZETTEL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Pk Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16601002453482370)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16625549801488375)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180659'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR||''/''||PROJEKT||''/''||BESCHREIBUNG||''/''||ZEITRAUM_VON||''-''||ZEITRAUM_BIS:PK_STUNDENZETTEL:SEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29868176510553228)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_VERPFL_BELEG_SRC'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34383446246538786)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,pk_inp_belege_all) sel,',
'',
'bezeichnung || '' '' || bel_datum || '' ('' || pk_inp_belege_all || '')'' de, pk_inp_belege_all,',
'case when fk_arbeitstag = :P367_fk_arbeitstag then 1 else 0 end arb,',
'case when fk_verpflegungsmehraufwd_det is not null then 1 else 0 end verpfl_det',
'from inp_belege_all inp',
'  left join (select * from t_rel_verpfl_beleg_src where fk_verpflegungsmehraufwd_det = :P367_fk_verpflegungsaufwd_det) belsrc on inp.pk_inp_belege_all = belsrc.fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(34383613484538788)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>35823932759930328
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16600150470482361)
,p_db_column_name=>'DE'
,p_display_order=>10
,p_column_identifier=>'AD'
,p_column_label=>'De'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16600183496482362)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16600978418482369)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'AF'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16603440643482394)
,p_db_column_name=>'ARB'
,p_display_order=>40
,p_column_identifier=>'AG'
,p_column_label=>'Arb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16603546262482395)
,p_db_column_name=>'VERPFL_DET'
,p_display_order=>50
,p_column_identifier=>'AH'
,p_column_label=>'Verpfl Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(34542727514786784)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180400'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DE:PK_INP_BELEGE_ALL:SEL:ARB:VERPFL_DET'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16602495665482385)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(34383446246538786)
,p_button_name=>'remove_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Remove Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16521098485994914)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P367_FK_AREITSTAG.,&P367_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16642053462098430)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16522291398994916)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16521522776994916)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16522724916994916)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16521964182994916)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29868176510553228)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16601176913482371)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(34383446246538786)
,p_button_name=>'add_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add Beleg'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16601197183482372)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16600327008482363)
,p_button_name=>'add_stundenzettel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add Stundenzettel'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(16529655762994939)
,p_branch_name=>'Go To Page 329'
,p_branch_action=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_PK_VERPFLEGUNGSMEHRAUFWD_DET:&P367_FK_VERPFLEGUNGSMEHRAUFWD_DET.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16523124816994916)
,p_name=>'P367_FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Verpflegungsmehraufwd Det'
,p_source=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16523573108994919)
,p_name=>'P367_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16523939608994919)
,p_name=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Pk Rel Verpfl Beleg Src'
,p_source=>'PK_REL_VERPFL_BELEG_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16524281878994919)
,p_name=>'P367_FK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || bel_datum || '' ('' || pk_inp_belege_all || '')'' de, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16524740151994919)
,p_name=>'P367_FK_STUNDENZETTEL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Fk Stundenzettel'
,p_source=>'FK_STUNDENZETTEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select jahr || '' / '' || projekt || '' / '' || beschreibung || '' / '' || zeitraum_von || '' - '' || zeitraum_bis, pk_stundenzettel',
'from t_stundenzettel std',
'  left join t_projekt proj on std.fk_projekt  = proj.pk_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16525098461994920)
,p_name=>'P367_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16525496713994920)
,p_name=>'P367_FK_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_item_source_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16525914046994920)
,p_name=>'P367_FK_AREITSTAG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(29868176510553228)
,p_prompt=>'Fk Areitstag'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum, pk_arbeitstage',
'from t_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16526728210994922)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(29868176510553228)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16601290733482373)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      insert into T_REL_VERPFL_BELEG_SRC (',
'     ',
'FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'FK_INP_BELEGE_ALL,',
'--FK_STUNDENZETTEL',
'COMM,',
'FK_STATUS,',
'CREATION_DATE',
'          )',
'      values (',
'      :P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'',
'       apex_application.g_f01(i),',
'          :P367_COMM,',
':P367_FK_STATUS,',
':P367_CREATION_DATE',
'      );',
'    ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16601176913482371)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16602477008482384)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'rmove_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'    delete from inp_belege_all where pk_inp_belege_all = apex_application.g_f01(i);',
'    commit;',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16602495665482385)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16601405961482374)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_stundenzettel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'      insert into T_REL_VERPFL_BELEG_SRC (',
'     ',
'FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'--FK_INP_BELEGE_ALL,',
'FK_STUNDENZETTEL,',
'COMM,',
'FK_STATUS,',
'CREATION_DATE',
'          )',
'      values (',
'      :P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'',
'       apex_application.g_f02(i),',
'          :P367_COMM,',
':P367_FK_STATUS,',
':P367_CREATION_DATE',
'      );',
'    ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16601197183482372)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16526352753994920)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(29868176510553228)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.component_end;
end;
/
