prompt --application/pages/page_00367
begin
--   Manifest
--     PAGE: 00367
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>367
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>unistr('Verpflegungsmehraufw\00E4nde_Detail_Belege_mod')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Verpflegungsmehraufw\00E4nde_Detail_Belege_mod')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(13610231510939284)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091022'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18040646283873903)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2,pk_stundenzettel)  sel,',
'',
'jahr || '' / '' || projekt || '' / '' || beschreibung || '' / '' || zeitraum_von || '' - '' || zeitraum_bis, pk_stundenzettel',
'from t_stundenzettel std',
'  left join t_projekt proj on std.fk_projekt  = proj.pk_projekt'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18040780280873904)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>18040780280873904
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18041024229873907)
,p_db_column_name=>'JAHR||''/''||PROJEKT||''/''||BESCHREIBUNG||''/''||ZEITRAUM_VON||''-''||ZEITRAUM_BIS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr||&#x27;&#x2F;&#x27;||projekt||&#x27;&#x2F;&#x27;||beschreibung||&#x27;&#x2F;&#x27;||zeitraum Von||&#x27;-&#x27;||zeitraum Bis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18041185164873908)
,p_db_column_name=>'PK_STUNDENZETTEL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Pk Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18041321728873910)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18065869076879915)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180659'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR||''/''||PROJEKT||''/''||BESCHREIBUNG||''/''||ZEITRAUM_VON||''-''||ZEITRAUM_BIS:PK_STUNDENZETTEL:SEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31308495785944768)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_VERPFL_BELEG_SRC'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35823765521930326)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,pk_inp_belege_all) sel,',
'',
'bezeichnung || '' '' || bel_datum || '' ('' || pk_inp_belege_all || '')'' de, pk_inp_belege_all,',
'case when fk_arbeitstag = :P367_fk_arbeitstag then 1 else 0 end arb,',
'case when fk_verpflegungsmehraufwd_det is not null then 1 else 0 end verpfl_det',
'from inp_belege_all inp',
'  left join (select * from t_rel_verpfl_beleg_src where fk_verpflegungsmehraufwd_det = :P367_fk_verpflegungsaufwd_det) belsrc on inp.pk_inp_belege_all = belsrc.fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(35823932759930328)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>35823932759930328
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18040469745873901)
,p_db_column_name=>'DE'
,p_display_order=>10
,p_column_identifier=>'AD'
,p_column_label=>'De'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18040502771873902)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18041297693873909)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'AF'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18043759918873934)
,p_db_column_name=>'ARB'
,p_display_order=>40
,p_column_identifier=>'AG'
,p_column_label=>'Arb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18043865537873935)
,p_db_column_name=>'VERPFL_DET'
,p_display_order=>50
,p_column_identifier=>'AH'
,p_column_label=>'Verpfl Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(35983046790178324)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180400'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DE:PK_INP_BELEGE_ALL:SEL:ARB:VERPFL_DET'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18042814940873925)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(35823765521930326)
,p_button_name=>'remove_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Remove Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17961417761386454)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P367_FK_AREITSTAG.,&P367_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18082372737489970)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17962610674386456)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17961842052386456)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17963044192386456)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17962283458386456)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(31308495785944768)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18041496188873911)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(35823765521930326)
,p_button_name=>'add_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add Beleg'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18041516458873912)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18040646283873903)
,p_button_name=>'add_stundenzettel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Add Stundenzettel'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(17969975038386479)
,p_branch_name=>'Go To Page 329'
,p_branch_action=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP:P329_PK_VERPFLEGUNGSMEHRAUFWD_DET:&P367_FK_VERPFLEGUNGSMEHRAUFWD_DET.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17963444092386456)
,p_name=>'P367_FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Verpflegungsmehraufwd Det'
,p_source=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17963892384386459)
,p_name=>'P367_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17964258884386459)
,p_name=>'P367_PK_REL_VERPFL_BELEG_SRC'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Pk Rel Verpfl Beleg Src'
,p_source=>'PK_REL_VERPFL_BELEG_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17964601154386459)
,p_name=>'P367_FK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || bel_datum || '' ('' || pk_inp_belege_all || '')'' de, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17965059427386459)
,p_name=>'P367_FK_STUNDENZETTEL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Fk Stundenzettel'
,p_source=>'FK_STUNDENZETTEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select jahr || '' / '' || projekt || '' / '' || beschreibung || '' / '' || zeitraum_von || '' - '' || zeitraum_bis, pk_stundenzettel',
'from t_stundenzettel std',
'  left join t_projekt proj on std.fk_projekt  = proj.pk_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17965417737386460)
,p_name=>'P367_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17965815989386460)
,p_name=>'P367_FK_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_item_source_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17966233322386460)
,p_name=>'P367_FK_AREITSTAG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(31308495785944768)
,p_prompt=>'Fk Areitstag'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum, pk_arbeitstage',
'from t_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17967047486386462)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(31308495785944768)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18041610008873913)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      insert into T_REL_VERPFL_BELEG_SRC (',
'     ',
'FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'FK_INP_BELEGE_ALL,',
'--FK_STUNDENZETTEL',
'COMM,',
'FK_STATUS,',
'CREATION_DATE',
'          )',
'      values (',
'      :P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'',
'       apex_application.g_f01(i),',
'          :P367_COMM,',
':P367_FK_STATUS,',
':P367_CREATION_DATE',
'      );',
'    ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18041496188873911)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18042796283873924)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'rmove_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'    delete from inp_belege_all where pk_inp_belege_all = apex_application.g_f01(i);',
'    commit;',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18042814940873925)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18041725236873914)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_stundenzettel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'      insert into T_REL_VERPFL_BELEG_SRC (',
'     ',
'FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'--FK_INP_BELEGE_ALL,',
'FK_STUNDENZETTEL,',
'COMM,',
'FK_STATUS,',
'CREATION_DATE',
'          )',
'      values (',
'      :P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'',
'       apex_application.g_f02(i),',
'          :P367_COMM,',
':P367_FK_STATUS,',
':P367_CREATION_DATE',
'      );',
'    ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18041516458873912)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17966672029386460)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(31308495785944768)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.component_end;
end;
/
