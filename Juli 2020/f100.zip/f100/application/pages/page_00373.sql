prompt --application/pages/page_00373
begin
--   Manifest
--     PAGE: 00373
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>373
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'inp_beleg_all_vergl'
,p_step_title=>'inp_beleg_all_vergl'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44309772283708404)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18740871487919567)
,p_plug_name=>'Ziel'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18821419319922533)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35327743095411937)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_rel_verpfl_beleg_src',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(35327832671411938)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>35327832671411938
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465075322119605)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_SRC'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Pk Rel Verpfl Beleg Src'
,p_column_link=>'f?p=&APP_ID.:367:&SESSION.::&DEBUG.:RP:P367_PK_REL_VERPFL_BELEG_SRC:#PK_REL_VERPFL_BELEG_SRC#'
,p_column_linktext=>'#PK_REL_VERPFL_BELEG_SRC#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465101176119606)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465244286119607)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465344219119608)
,p_db_column_name=>'FK_STUNDENZETTEL'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Fk Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465405647119609)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465590695119610)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19465627760119611)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(35346654433755130)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'194762'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_VERPFL_BELEG_SRC:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_INP_BELEGE_ALL:FK_STUNDENZETTEL:COMM:FK_STATUS:CREATION_DATE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39005208719345017)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from inp_belege_pos_all',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39005364250345018)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39005364250345018
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39005650986345021)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007080052345035)
,p_db_column_name=>'PK_INP_BELEGE_POS_ALL'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007112305345036)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007269344345037)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007347612345038)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007464788345039)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007569724345040)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007697068345041)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007711139345042)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007853892345043)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39007901146345044)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008046200345045)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008159772345046)
,p_db_column_name=>'FK_LAND'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008243667345047)
,p_db_column_name=>'FK_CITY'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008313505345048)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008428669345049)
,p_db_column_name=>'VON'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39008539810345050)
,p_db_column_name=>'BIS'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39041783889735301)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39041863552735302)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39041969064735303)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042029851735304)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042116941735305)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042221815735306)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042308875735307)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042424523735308)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042587056735309)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042656081735310)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>290
,p_column_identifier=>'AA'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042758370735311)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>300
,p_column_identifier=>'AB'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042881464735312)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>310
,p_column_identifier=>'AC'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39042992009735313)
,p_db_column_name=>'BELEG'
,p_display_order=>320
,p_column_identifier=>'AD'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043030795735314)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>330
,p_column_identifier=>'AE'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043156318735315)
,p_db_column_name=>'LITER'
,p_display_order=>340
,p_column_identifier=>'AF'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043265719735316)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>350
,p_column_identifier=>'AG'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043379515735317)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>360
,p_column_identifier=>'AH'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043442311735318)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>370
,p_column_identifier=>'AI'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043594904735319)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>380
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043657032735320)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>390
,p_column_identifier=>'AK'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043733960735321)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>400
,p_column_identifier=>'AL'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043806767735322)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>410
,p_column_identifier=>'AM'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39043918967735323)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>420
,p_column_identifier=>'AN'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044077907735324)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>430
,p_column_identifier=>'AO'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044125991735325)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AP'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044223216735326)
,p_db_column_name=>'DATUM_OK_BUCH'
,p_display_order=>450
,p_column_identifier=>'AQ'
,p_column_label=>'Datum Ok Buch'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044309045735327)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>460
,p_column_identifier=>'AR'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044400298735328)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>470
,p_column_identifier=>'AS'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39193015157617085)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'391931'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_INP_BELEGE_ALL:PK_INP_BELEGE_POS_ALL:FK_LEX_BUCHUNG:FK_KATEGORIE:FK_ARBEITSTAG:FK_BUCHUNG:FK_ZAHLUNGSART:FK_VERWENDUNGSZWECK:FK_INVENTAR:FK_PROJEKT:BELEGNUMMER:BEZEICHNUNG:FK_LAND:FK_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_STEUERSATZ:MWST_BETRAG:BR'
||unistr('UTTO_BETRAG:FK_WAEHRUNG:STEUERNUMMER:UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFS\00C4ULE:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FRMDW_NETTO_BETRAG:FK_FRMDW:FK_FR')
||unistr('MDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:DATUM_OK_BUCH:FK_LOCATION:PERS\00D6NLICH_VOR_ORT')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39006118845345026)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from inp_belege_pos_all',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39006234450345027)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39006234450345027
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39006574883345030)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044529448735329)
,p_db_column_name=>'PK_INP_BELEGE_POS_ALL'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044601993735330)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>50
,p_column_identifier=>'I'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044779175735331)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044835070735332)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39044992223735333)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>80
,p_column_identifier=>'L'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045088004735334)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>90
,p_column_identifier=>'M'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045180093735335)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045208596735336)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>110
,p_column_identifier=>'O'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045303856735337)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045401096735338)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>130
,p_column_identifier=>'Q'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045500630735339)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'R'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045600600735340)
,p_db_column_name=>'FK_LAND'
,p_display_order=>150
,p_column_identifier=>'S'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045765579735341)
,p_db_column_name=>'FK_CITY'
,p_display_order=>160
,p_column_identifier=>'T'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045837094735342)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>170
,p_column_identifier=>'U'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39045999317735343)
,p_db_column_name=>'VON'
,p_display_order=>180
,p_column_identifier=>'V'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046021156735344)
,p_db_column_name=>'BIS'
,p_display_order=>190
,p_column_identifier=>'W'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046122473735345)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'X'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046299940735346)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>210
,p_column_identifier=>'Y'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046348921735347)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>220
,p_column_identifier=>'Z'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046490344735348)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>230
,p_column_identifier=>'AA'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046576653735349)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>240
,p_column_identifier=>'AB'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39046691266735350)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>250
,p_column_identifier=>'AC'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063279362738001)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>260
,p_column_identifier=>'AD'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063330407738002)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>270
,p_column_identifier=>'AE'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063455290738003)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>280
,p_column_identifier=>'AF'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063559729738004)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>290
,p_column_identifier=>'AG'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063631486738005)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>300
,p_column_identifier=>'AH'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063746727738006)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>310
,p_column_identifier=>'AI'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063879668738007)
,p_db_column_name=>'BELEG'
,p_display_order=>320
,p_column_identifier=>'AJ'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39063924376738008)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>330
,p_column_identifier=>'AK'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064007585738009)
,p_db_column_name=>'LITER'
,p_display_order=>340
,p_column_identifier=>'AL'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064134851738010)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>350
,p_column_identifier=>'AM'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064251039738011)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>360
,p_column_identifier=>'AN'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064365214738012)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>370
,p_column_identifier=>'AO'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064490885738013)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>380
,p_column_identifier=>'AP'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064586850738014)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>390
,p_column_identifier=>'AQ'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064689267738015)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>400
,p_column_identifier=>'AR'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064736966738016)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>410
,p_column_identifier=>'AS'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064822744738017)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>420
,p_column_identifier=>'AT'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39064992845738018)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>430
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39065050402738019)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AV'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39065171793738020)
,p_db_column_name=>'DATUM_OK_BUCH'
,p_display_order=>450
,p_column_identifier=>'AW'
,p_column_label=>'Datum Ok Buch'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39065255295738021)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>460
,p_column_identifier=>'AX'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39065344440738022)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>470
,p_column_identifier=>'AY'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39193653511617098)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'391937'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_INP_BELEGE_ALL:PK_INP_BELEGE_POS_ALL:FK_LEX_BUCHUNG:FK_KATEGORIE:FK_ARBEITSTAG:FK_BUCHUNG:FK_ZAHLUNGSART:FK_VERWENDUNGSZWECK:FK_INVENTAR:FK_PROJEKT:BELEGNUMMER:BEZEICHNUNG:FK_LAND:FK_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_STEUERSATZ:MWST_BETRAG:BR'
||unistr('UTTO_BETRAG:FK_WAEHRUNG:STEUERNUMMER:UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFS\00C4ULE:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FRMDW_NETTO_BETRAG:FK_FRMDW:FK_FR')
||unistr('MDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:DATUM_OK_BUCH:FK_LOCATION:PERS\00D6NLICH_VOR_ORT')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39152135029471308)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>'select * from table(getCompinpbelegeall3 (:P373_SRC_PK_INP_BELEGE_ALL , :P373_Ziel_PK_INP_BELEGE_ALL))'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39152269699471309)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39152269699471309
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39153082786471317)
,p_db_column_name=>'SEL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40179313594103646)
,p_db_column_name=>'SUM1'
,p_display_order=>110
,p_column_identifier=>'CS'
,p_column_label=>'Sum1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40179474995103647)
,p_db_column_name=>'NR_ROW'
,p_display_order=>120
,p_column_identifier=>'CT'
,p_column_label=>'Nr Row'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40179588078103648)
,p_db_column_name=>'ERG'
,p_display_order=>130
,p_column_identifier=>'CU'
,p_column_label=>'Erg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40179677749103649)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>140
,p_column_identifier=>'CV'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40179703810103650)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>150
,p_column_identifier=>'CW'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40294804378859201)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>160
,p_column_identifier=>'CX'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40294962137859202)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>170
,p_column_identifier=>'CY'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295001214859203)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>180
,p_column_identifier=>'CZ'
,p_column_label=>'Fk Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295185938859204)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>190
,p_column_identifier=>'DA'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295250201859205)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>200
,p_column_identifier=>'DB'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295317879859206)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>210
,p_column_identifier=>'DC'
,p_column_label=>'Fk Inventar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295463111859207)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>220
,p_column_identifier=>'DD'
,p_column_label=>'Fk Projekt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295512756859208)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>230
,p_column_identifier=>'DE'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295625704859209)
,p_db_column_name=>'RNR'
,p_display_order=>240
,p_column_identifier=>'DF'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295734073859210)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>250
,p_column_identifier=>'DG'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295895050859211)
,p_db_column_name=>'FK_LAND'
,p_display_order=>260
,p_column_identifier=>'DH'
,p_column_label=>'Fk Land'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40295987424859212)
,p_db_column_name=>'FK_CITY'
,p_display_order=>270
,p_column_identifier=>'DI'
,p_column_label=>'Fk City'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296092391859213)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>280
,p_column_identifier=>'DJ'
,p_column_label=>'Bel Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296194124859214)
,p_db_column_name=>'VON'
,p_display_order=>290
,p_column_identifier=>'DK'
,p_column_label=>'Von'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296250693859215)
,p_db_column_name=>'BIS'
,p_display_order=>300
,p_column_identifier=>'DL'
,p_column_label=>'Bis'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296371308859216)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>310
,p_column_identifier=>'DM'
,p_column_label=>'Netto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296465600859217)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>320
,p_column_identifier=>'DN'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296560937859218)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>330
,p_column_identifier=>'DO'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296685975859219)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>340
,p_column_identifier=>'DP'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296741313859220)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>350
,p_column_identifier=>'DQ'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296876323859221)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>360
,p_column_identifier=>'DR'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40296985402859222)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>370
,p_column_identifier=>'DS'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297042650859223)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>380
,p_column_identifier=>'DT'
,p_column_label=>'Comm Rest Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297127348859224)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>390
,p_column_identifier=>'DU'
,p_column_label=>'Comm Tel Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297235458859225)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>400
,p_column_identifier=>'DV'
,p_column_label=>'Comm Produkte'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297312253859226)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>410
,p_column_identifier=>'DW'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297458080859227)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>420
,p_column_identifier=>'DX'
,p_column_label=>'Comm Sonstiges'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297589378859228)
,p_db_column_name=>'BELEG'
,p_display_order=>430
,p_column_identifier=>'DY'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297625793859229)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>440
,p_column_identifier=>'DZ'
,p_column_label=>'Zahlungsbeleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297785182859230)
,p_db_column_name=>'LITER'
,p_display_order=>450
,p_column_identifier=>'EA'
,p_column_label=>'Liter'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297823684859231)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>460
,p_column_identifier=>'EB'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40297954146859232)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>470
,p_column_identifier=>'EC'
,p_column_label=>'Fk Location'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298086506859233)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>480
,p_column_identifier=>'ED'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298110205859234)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>490
,p_column_identifier=>'EE'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298277713859235)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>500
,p_column_identifier=>'EF'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298329486859236)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>510
,p_column_identifier=>'EG'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298404844859237)
,p_db_column_name=>'FK_VON_ARBEITSTAG'
,p_display_order=>520
,p_column_identifier=>'EH'
,p_column_label=>'Fk Von Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298545955859238)
,p_db_column_name=>'FK_BIS_ARBEITSTAG'
,p_display_order=>530
,p_column_identifier=>'EI'
,p_column_label=>'Fk Bis Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298649039859239)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>540
,p_column_identifier=>'EJ'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298796831859240)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>550
,p_column_identifier=>'EK'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298839553859241)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>560
,p_column_identifier=>'EL'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40298918549859242)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>570
,p_column_identifier=>'EM'
,p_column_label=>'Comm Parkticket'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299083090859243)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>580
,p_column_identifier=>'EN'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299149932859244)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>590
,p_column_identifier=>'EO'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299234489859245)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>600
,p_column_identifier=>'EP'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299312069859246)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>610
,p_column_identifier=>'EQ'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299465954859247)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>620
,p_column_identifier=>'ER'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299503375859248)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>630
,p_column_identifier=>'ES'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299637793859249)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>640
,p_column_identifier=>'ET'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40299780430859250)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>650
,p_column_identifier=>'EU'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314176818996701)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>660
,p_column_identifier=>'EV'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314292038996702)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>670
,p_column_identifier=>'EW'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314330990996703)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>680
,p_column_identifier=>'EX'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314419111996704)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>690
,p_column_identifier=>'EY'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314593164996705)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>700
,p_column_identifier=>'EZ'
,p_column_label=>'La Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314653138996706)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>710
,p_column_identifier=>'FA'
,p_column_label=>'Fk La Konto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314781029996707)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>720
,p_column_identifier=>'FB'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314864646996708)
,p_db_column_name=>'FK_ZAHLSTATUS'
,p_display_order=>730
,p_column_identifier=>'FC'
,p_column_label=>'Fk Zahlstatus'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40314915323996709)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>740
,p_column_identifier=>'FD'
,p_column_label=>'Comm Vergehen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315023777996710)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>750
,p_column_identifier=>'FE'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315151401996711)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>760
,p_column_identifier=>'FF'
,p_column_label=>'Cnt Punkte'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315284005996712)
,p_db_column_name=>'FK_BELEG_ABLAGE'
,p_display_order=>770
,p_column_identifier=>'FG'
,p_column_label=>'Fk Beleg Ablage'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315341779996713)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>780
,p_column_identifier=>'FH'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315443801996714)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>790
,p_column_identifier=>'FI'
,p_column_label=>'Cnt Punkte Geschaetzt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315580806996715)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>800
,p_column_identifier=>'FJ'
,p_column_label=>'Punkte Von'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315669208996716)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>810
,p_column_identifier=>'FK'
,p_column_label=>'Punkte Bis'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315784082996717)
,p_db_column_name=>'FK_LOCATION_VERG'
,p_display_order=>820
,p_column_identifier=>'FL'
,p_column_label=>'Fk Location Verg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315813454996718)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>830
,p_column_identifier=>'FM'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40315917883996719)
,p_db_column_name=>'GESCHW_IST'
,p_display_order=>840
,p_column_identifier=>'FN'
,p_column_label=>'Geschw Ist'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316046880996720)
,p_db_column_name=>'GESCHW_SOLL'
,p_display_order=>850
,p_column_identifier=>'FO'
,p_column_label=>'Geschw Soll'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316142813996721)
,p_db_column_name=>'GESCHW_UEBER_GRZ'
,p_display_order=>860
,p_column_identifier=>'FP'
,p_column_label=>'Geschw Ueber Grz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316221532996722)
,p_db_column_name=>'GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>870
,p_column_identifier=>'FQ'
,p_column_label=>'Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316387268996723)
,p_db_column_name=>'CODE_BUSSGELD'
,p_display_order=>880
,p_column_identifier=>'FR'
,p_column_label=>'Code Bussgeld'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316489697996724)
,p_db_column_name=>'DESCR_BUSSGELD'
,p_display_order=>890
,p_column_identifier=>'FS'
,p_column_label=>'Descr Bussgeld'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316506422996725)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>900
,p_column_identifier=>'FT'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316660953996726)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>910
,p_column_identifier=>'FU'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316782299996727)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>920
,p_column_identifier=>'FV'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316858418996728)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>930
,p_column_identifier=>'FW'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40316900371996729)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>940
,p_column_identifier=>'FX'
,p_column_label=>'Fk Calc State'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317033533996730)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>950
,p_column_identifier=>'FY'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317104728996731)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>960
,p_column_identifier=>'FZ'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317295371996732)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>970
,p_column_identifier=>'GA'
,p_column_label=>'Fk Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317328615996733)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>980
,p_column_identifier=>'GB'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317482916996734)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>990
,p_column_identifier=>'GC'
,p_column_label=>'Create At'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317555935996735)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>1000
,p_column_identifier=>'GD'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317679375996736)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>1010
,p_column_identifier=>'GE'
,p_column_label=>'Modify At'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317718698996737)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>1020
,p_column_identifier=>'GF'
,p_column_label=>'Modify By'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317806821996738)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>1030
,p_column_identifier=>'GG'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40317933064996739)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>1040
,p_column_identifier=>'GH'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318069393996740)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>1050
,p_column_identifier=>'GI'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318123252996741)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>1060
,p_column_identifier=>'GJ'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318257572996742)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>1070
,p_column_identifier=>'GK'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318389956996743)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>1080
,p_column_identifier=>'GL'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318433352996744)
,p_db_column_name=>'FK_INTERNET_APP'
,p_display_order=>1090
,p_column_identifier=>'GM'
,p_column_label=>'Fk Internet App'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318562495996745)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>1100
,p_column_identifier=>'GN'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318610881996746)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>1110
,p_column_identifier=>'GO'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318789082996747)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>1120
,p_column_identifier=>'GP'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318891060996748)
,p_db_column_name=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_display_order=>1130
,p_column_identifier=>'GQ'
,p_column_label=>unistr('Fk Gesch\00E4ftspartner')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40318952282996749)
,p_db_column_name=>'DUMMY'
,p_display_order=>1140
,p_column_identifier=>'GR'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40319055466996750)
,p_db_column_name=>'STORNIERT'
,p_display_order=>1150
,p_column_identifier=>'GS'
,p_column_label=>'Storniert'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40319133483996701)
,p_db_column_name=>'FK_ADRESSE_SCHNELL'
,p_display_order=>1160
,p_column_identifier=>'GT'
,p_column_label=>'Fk Adresse Schnell'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40319245103996702)
,p_db_column_name=>'SEL_PK_INP_BELEGE_ALL'
,p_display_order=>1170
,p_column_identifier=>'GU'
,p_column_label=>'Sel Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39590290733256782)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'395903'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('SUM1:SEL:NR_ROW:ERG:FK_PROJEKTNUMMER:RNR:BEZEICHNUNG:FK_LAND:FK_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_STEUERSATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_WAEHRUNG:STEUERNUMMER:FK_UMRECHNUNGSKURS:COMM_REST_COMM_TEL_COMM_PRODUKTE:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BE')
||unistr('LEG:ZAHLUNGSBELEG:LITER:ZAPFS\00C4ULE:FK_LOCATION:PERS\00D6NLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_VON_ARBEITSTAG:FK_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_FRMDW:FK_FRMDW_MWST')
||'_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_ZAHLSTATUS:COMM_VERGEHEN:VERG_BEHOERDE:CNT_'
||'PUNKTE:FK_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:FK_LOCATION_VERG:FK_IMP_BA_BEL_OLD:GESCHW_IST:GESCHW_SOLL:GESCHW_UEBER_GRZ:GESCHW_UEBER_GRZ_ABZGL_MESSTOL:CODE_BUSSGELD:DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUM'
||'MER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_I'
||unistr('NTERNET_APP:FK_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_GESCH\00C4FTSPARTNER:DUMMY:STORNIERT:FK_ADRESSE_SCHNELL:SEL_PK_INP_BELEGE_ALL')
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40293627379815460)
,p_report_id=>wwv_flow_api.id(39590290733256782)
,p_name=>'erg'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ERG'
,p_operator=>'='
,p_expr=>'erg'
,p_condition_sql=>' (case when ("ERG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''erg''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D4D4D4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40294049640815462)
,p_report_id=>wwv_flow_api.id(39590290733256782)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SUM1'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("SUM1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40294444825815462)
,p_report_id=>wwv_flow_api.id(39590290733256782)
,p_name=>'nok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SUM1'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("SUM1" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40293240726815460)
,p_report_id=>wwv_flow_api.id(39590290733256782)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ERG'
,p_operator=>'='
,p_expr=>'erg'
,p_condition_sql=>'"ERG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''erg''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(56492267503811925)
,p_plug_name=>'Src'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18822195747922540)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18821419319922533)
,p_button_name=>'Select'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Select'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(21165063751887315)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(56492267503811925)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18811558488919615)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(18740871487919567)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18810305043919612)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18740871487919567)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18811957358919615)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(18740871487919567)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18811137177919614)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(18740871487919567)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(18822605894922545)
,p_branch_name=>'Go To Page 373'
,p_branch_action=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP:P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1,P373_SRC_PK_INP_BELEGE_ALL,P373_ZIEL_PK_INP_BELEGE_ALL:&P373_ZIEL_PK_INP_BELEGE_ALL.,&P373_SRC_PK_INP_BELEGE_ALL.,&P373_SRC_PK_INP_BELEGE_ALL.,&P373_ZIEL_PK_INP_BELEGE_ALL.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(18822195747922540)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18741132429919568)
,p_name=>'P373_PK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'ID ZIel'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18741501514919573)
,p_name=>'P373_FK_LEX_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Lex Buchung'
,p_source=>'FK_LEX_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18741911212919575)
,p_name=>'P373_FK_KATEGORIE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Kategorie'
,p_source=>'FK_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18742303371919575)
,p_name=>'P373_FK_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_source=>'FK_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18742797478919575)
,p_name=>'P373_FK_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Buchung'
,p_source=>'FK_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18743182787919575)
,p_name=>'P373_FK_ZAHLUNGSART'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Zahlungsart'
,p_source=>'FK_ZAHLUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18743527625919575)
,p_name=>'P373_FK_VERWENDUNGSZWECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Verwendungszweck'
,p_source=>'FK_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18743988576919575)
,p_name=>'P373_FK_INVENTAR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Inventar'
,p_source=>'FK_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18744328030919576)
,p_name=>'P373_FK_PROJEKT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Projekt'
,p_source=>'FK_PROJEKT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18744735113919576)
,p_name=>'P373_BELEGNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Belegnummer'
,p_source=>'BELEGNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>128
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18745116971919576)
,p_name=>'P373_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18745548306919576)
,p_name=>'P373_FK_LAND'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Land'
,p_source=>'FK_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18745911246919576)
,p_name=>'P373_FK_CITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk City'
,p_source=>'FK_CITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18746366913919576)
,p_name=>'P373_BEL_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Bel Datum'
,p_source=>'BEL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18746763455919576)
,p_name=>'P373_VON'
,p_source_data_type=>'DATE'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Von'
,p_source=>'VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18747161708919578)
,p_name=>'P373_BIS'
,p_source_data_type=>'DATE'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Bis'
,p_source=>'BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18747589622919578)
,p_name=>'P373_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Netto Betrag'
,p_source=>'NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18747985851919578)
,p_name=>'P373_FK_STEUERSATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Steuersatz'
,p_source=>'FK_STEUERSATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18748392082919578)
,p_name=>'P373_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Mwst Betrag'
,p_source=>'MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18748745049919578)
,p_name=>'P373_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>650
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Brutto Betrag'
,p_source=>'BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18749143796919578)
,p_name=>'P373_FK_WAEHRUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>670
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Waehrung'
,p_source=>'FK_WAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18749504207919578)
,p_name=>'P373_STEUERNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Steuernummer'
,p_source=>'STEUERNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18749931280919578)
,p_name=>'P373_FK_UMRECHNUNGSKURS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Umrechnungskurs'
,p_source=>'FK_UMRECHNUNGSKURS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18750373664919579)
,p_name=>'P373_COMM_REST_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>770
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Rest Beleg'
,p_source=>'COMM_REST_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18750731865919579)
,p_name=>'P373_COMM_TEL_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Tel Beleg'
,p_source=>'COMM_TEL_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18751127551919579)
,p_name=>'P373_COMM_PRODUKTE'
,p_source_data_type=>'CLOB'
,p_item_sequence=>820
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Produkte'
,p_source=>'COMM_PRODUKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18751597100919579)
,p_name=>unistr('P373_COMM_BEGR\00DCNDUNG')
,p_source_data_type=>'CLOB'
,p_item_sequence=>840
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Comm Begr\00FCndung')
,p_source=>unistr('COMM_BEGR\00DCNDUNG')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18751929411919579)
,p_name=>'P373_COMM_SONSTIGES'
,p_source_data_type=>'CLOB'
,p_item_sequence=>860
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Sonstiges'
,p_source=>'COMM_SONSTIGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18752304428919579)
,p_name=>'P373_BELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>940
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Beleg'
,p_source=>'BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18752791077919579)
,p_name=>'P373_ZAHLUNGSBELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>960
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Zahlungsbeleg'
,p_source=>'ZAHLUNGSBELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18753196998919579)
,p_name=>'P373_LITER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>990
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Liter'
,p_source=>'LITER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18753502856919581)
,p_name=>unistr('P373_ZAPFS\00C4ULE')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Zapfs\00E4ule')
,p_source=>unistr('ZAPFS\00C4ULE')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18753971218919581)
,p_name=>'P373_FK_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1060
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Location'
,p_source=>'FK_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18754390415919581)
,p_name=>unistr('P373_PERS\00D6NLICH_VOR_ORT')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1130
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Pers\00F6nlich Vor Ort')
,p_source=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18754731957919581)
,p_name=>'P373_BELEG_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>1150
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Beleg Uhrzeit'
,p_format_mask=>'HH24:MI:SS'
,p_source=>'BELEG_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18755117851919581)
,p_name=>'P373_VON_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>1190
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Von Uhrzeit'
,p_format_mask=>'HH24:MI:SS'
,p_source=>'VON_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18755578038919581)
,p_name=>'P373_BIS_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>1210
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Bis Uhrzeit'
,p_format_mask=>'HH24:MI:SS'
,p_source=>'BIS_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18755981644919581)
,p_name=>'P373_FK_VON_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1230
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Von Arbeitstag'
,p_source=>'FK_VON_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18756376999919582)
,p_name=>'P373_FK_BIS_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1320
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Bis Arbeitstag'
,p_source=>'FK_BIS_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18756726455919582)
,p_name=>'P373_COMM_ADRESSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1340
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Adresse'
,p_source=>'COMM_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18757135659919582)
,p_name=>'P373_TANKSTELLEN_NR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1360
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Tankstellen Nr'
,p_source=>'TANKSTELLEN_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18757555091919582)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1380
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Brutto Betrag Incl Trinkg'
,p_source=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18757977504919582)
,p_name=>'P373_COMM_PARKTICKET'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1420
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Parkticket'
,p_source=>'COMM_PARKTICKET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18758396769919582)
,p_name=>'P373_FRMDW_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1440
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Frmdw Netto Betrag'
,p_source=>'FRMDW_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18758787104919582)
,p_name=>'P373_FK_FRMDW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1460
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Frmdw'
,p_source=>'FK_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18759104778919582)
,p_name=>'P373_FK_FRMDW_MWST_SATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1580
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Frmdw Mwst Satz'
,p_source=>'FK_FRMDW_MWST_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18759553139919584)
,p_name=>'P373_FRMDW_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1600
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Frmdw Mwst Betrag'
,p_source=>'FRMDW_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18759962305919584)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1620
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Frmdw Brutto Betrag'
,p_source=>'FRMDW_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18760334894919584)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1640
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Frmdw Brutto Incl Trinkg'
,p_source=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18760789278919584)
,p_name=>'P373_MWST_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1660
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Mwst Betrag Eur'
,p_source=>'MWST_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18761160643919584)
,p_name=>'P373_BRUTTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1680
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Brutto Betrag Eur'
,p_source=>'BRUTTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18761578710919584)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1700
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Brutto Incl Trinkg Eur'
,p_source=>'BRUTTO_INCL_TRINKG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18761974472919584)
,p_name=>'P373_NETTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1720
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Netto Betrag Eur'
,p_source=>'NETTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18762347571919585)
,p_name=>'P373_PREIS_PRO_MENGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1820
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Preis Pro Menge'
,p_source=>'PREIS_PRO_MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18762713843919585)
,p_name=>'P373_MENGENEINHEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1850
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Mengeneinheit'
,p_source=>'MENGENEINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18763134083919585)
,p_name=>'P373_LA_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2150
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'La Datum'
,p_source=>'LA_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18763585801919585)
,p_name=>'P373_FK_LA_KONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2170
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk La Konto'
,p_source=>'FK_LA_KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18763925602919585)
,p_name=>'P373_FK_LA_WDH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2190
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk La Wdh'
,p_source=>'FK_LA_WDH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18764329535919585)
,p_name=>'P373_FK_ZAHLSTATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2210
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Zahlstatus'
,p_source=>'FK_ZAHLSTATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18764721376919585)
,p_name=>'P373_COMM_VERGEHEN'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2230
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Comm Vergehen'
,p_source=>'COMM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18765170379919587)
,p_name=>'P373_VERG_BEHOERDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2250
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Verg Behoerde'
,p_source=>'VERG_BEHOERDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18765563169919587)
,p_name=>'P373_CNT_PUNKTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2270
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Cnt Punkte'
,p_source=>'CNT_PUNKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18765936806919587)
,p_name=>'P373_FK_BELEG_ABLAGE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2290
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Beleg Ablage'
,p_source=>'FK_BELEG_ABLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18766337152919587)
,p_name=>'P373_FK_ABL_ORDNER_PAGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2310
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Abl Ordner Page'
,p_source=>'FK_ABL_ORDNER_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18766777930919587)
,p_name=>'P373_CNT_PUNKTE_GESCHAETZT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2330
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Cnt Punkte Geschaetzt'
,p_source=>'CNT_PUNKTE_GESCHAETZT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18767102895919587)
,p_name=>'P373_PUNKTE_VON'
,p_source_data_type=>'DATE'
,p_item_sequence=>2340
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Punkte Von'
,p_source=>'PUNKTE_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18767553417919587)
,p_name=>'P373_PUNKTE_BIS'
,p_source_data_type=>'DATE'
,p_item_sequence=>2350
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Punkte Bis'
,p_source=>'PUNKTE_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18767903121919589)
,p_name=>'P373_FK_LOCATION_VERG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2370
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Location Verg'
,p_source=>'FK_LOCATION_VERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18768380971919589)
,p_name=>'P373_FK_IMP_BA_BEL_OLD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2390
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Imp Ba Bel Old'
,p_source=>'FK_IMP_BA_BEL_OLD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18768773756919589)
,p_name=>'P373_GESCHW_IST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2410
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Geschw Ist'
,p_source=>'GESCHW_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18769147833919589)
,p_name=>'P373_GESCHW_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2430
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Geschw Soll'
,p_source=>'GESCHW_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18769546530919589)
,p_name=>'P373_GESCHW_UEBER_GRZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2450
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Geschw Ueber Grz'
,p_source=>'GESCHW_UEBER_GRZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18769997037919589)
,p_name=>'P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2470
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Geschw Ueber Grz Abzgl Messtol'
,p_source=>'GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18770327971919592)
,p_name=>'P373_CODE_BUSSGELD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2490
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Code Bussgeld'
,p_source=>'CODE_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18770729275919592)
,p_name=>'P373_DESCR_BUSSGELD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2510
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Descr Bussgeld'
,p_source=>'DESCR_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18771113265919592)
,p_name=>'P373_GEZAHLT_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2530
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Gezahlt Am'
,p_source=>'GEZAHLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18771597264919592)
,p_name=>'P373_WEBSEITE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2550
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Webseite'
,p_source=>'WEBSEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18771970425919592)
,p_name=>'P373_KUNDENNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2570
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Kundennummer'
,p_source=>'KUNDENNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18772366292919592)
,p_name=>'P373_FK_REAL_BELEG_EXIST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2590
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Real Beleg Exist'
,p_source=>'FK_REAL_BELEG_EXIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18772789921919592)
,p_name=>'P373_FK_CALC_STATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2610
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Calc State'
,p_source=>'FK_CALC_STATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18773157354919593)
,p_name=>'P373_FK_CALC_STATE_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2630
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Calc State Eur'
,p_source=>'FK_CALC_STATE_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18773571969919593)
,p_name=>'P373_FK_CALC_STATE_FRMDW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2650
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Calc State Frmdw'
,p_source=>'FK_CALC_STATE_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18773910162919593)
,p_name=>'P373_FK_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2670
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18774360536919593)
,p_name=>'P373_DATUM_VERGEHEN'
,p_source_data_type=>'DATE'
,p_item_sequence=>2690
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Vergehen'
,p_source=>'DATUM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18774722840919593)
,p_name=>'P373_CREATE_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>2710
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Create At'
,p_source=>'CREATE_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18775112627919593)
,p_name=>'P373_CREATE_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2750
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Create By'
,p_source=>'CREATE_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18775527958919595)
,p_name=>'P373_MODIFY_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>2790
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Modify At'
,p_source=>'MODIFY_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18775968047919595)
,p_name=>'P373_MODIFY_BY'
,p_source_data_type=>'DATE'
,p_item_sequence=>2820
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Modify By'
,p_source=>'MODIFY_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'Y'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18776350651919595)
,p_name=>'P373_DATUM_ORT_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2850
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'Y'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18776768740919595)
,p_name=>'P373_DATUM_ADDRESSE_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2870
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18777139839919595)
,p_name=>'P373_DATUM_BUSSGELD_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2890
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18777502404919596)
,p_name=>'P373_DATUM_BELEG_POS_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2910
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18777955993919596)
,p_name=>'P373_DATUM_BUCHUNG_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2930
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18778376799919596)
,p_name=>'P373_DATUM_VERPFL_BEL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2950
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_source=>'DATUM_VERPFL_BEL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18778724568919596)
,p_name=>'P373_FK_INTERNET_APP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2970
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Internet App'
,p_source=>'FK_INTERNET_APP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18779155619919596)
,p_name=>'P373_FK_DUPL_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2990
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Dupl Status'
,p_source=>'FK_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18779577515919598)
,p_name=>'P373_DATUM_DUPL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>3010
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Datum Dupl Ok'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'Y'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18779927021919598)
,p_name=>'P373_DUPL_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>3030
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18780307033919598)
,p_name=>unistr('P373_FK_GESCH\00C4FTSPARTNER')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>3050
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_item_source_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Fk Gesch\00E4ftspartner')
,p_source=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18821531268922534)
,p_name=>'P373_ZIEL_PK_INP_BELEGE_ALL'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(18821419319922533)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18822926318922548)
,p_name=>'P373_FK_LEX_BUCHUNG_1_FLG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Lex Buchung'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'4'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18823058436922549)
,p_name=>'P373_FK_KATEGORIE_1_FLG'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Kategorie'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18823172794922550)
,p_name=>'P373_NEW_1_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18895973108948512)
,p_name=>'P373_PK_INP_BELEGE_ALL_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'ID SRC'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18896373416948512)
,p_name=>'P373_FK_LEX_BUCHUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Lex Buchung'
,p_source=>'FK_LEX_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18896725019948514)
,p_name=>'P373_FK_KATEGORIE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Kategorie'
,p_source=>'FK_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18897116798948514)
,p_name=>'P373_FK_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_source=>'FK_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18897594388948514)
,p_name=>'P373_FK_BUCHUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Buchung'
,p_source=>'FK_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18897954722948514)
,p_name=>'P373_FK_ZAHLUNGSART_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Zahlungsart'
,p_source=>'FK_ZAHLUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18898320240948514)
,p_name=>'P373_FK_VERWENDUNGSZWECK_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Verwendungszweck'
,p_source=>'FK_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18898706304948514)
,p_name=>'P373_FK_INVENTAR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Inventar'
,p_source=>'FK_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18899167383948514)
,p_name=>'P373_FK_PROJEKT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Projekt'
,p_source=>'FK_PROJEKT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18899552933948515)
,p_name=>'P373_BELEGNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Belegnummer'
,p_source=>'BELEGNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18899950948948515)
,p_name=>'P373_BEZEICHNUNG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18900368657948515)
,p_name=>'P373_FK_LAND_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Land'
,p_source=>'FK_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18900727541948515)
,p_name=>'P373_FK_CITY_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk City'
,p_source=>'FK_CITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18901124146948515)
,p_name=>'P373_BEL_DATUM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Bel Datum'
,p_source=>'BEL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18901568355948515)
,p_name=>'P373_VON_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Von'
,p_source=>'VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18901921186948515)
,p_name=>'P373_BIS_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Bis'
,p_source=>'BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18902320514948517)
,p_name=>'P373_NETTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Netto Betrag'
,p_source=>'NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18902716322948517)
,p_name=>'P373_FK_STEUERSATZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Steuersatz'
,p_source=>'FK_STEUERSATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18903182757948517)
,p_name=>'P373_MWST_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Mwst Betrag'
,p_source=>'MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18903564774948517)
,p_name=>'P373_BRUTTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Brutto Betrag'
,p_source=>'BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18903992260948517)
,p_name=>'P373_FK_WAEHRUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>600
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Waehrung'
,p_source=>'FK_WAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18904310270948517)
,p_name=>'P373_STEUERNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>630
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Steuernummer'
,p_source=>'STEUERNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18904753242948517)
,p_name=>'P373_FK_UMRECHNUNGSKURS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>660
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Umrechnungskurs'
,p_source=>'FK_UMRECHNUNGSKURS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18905104609948517)
,p_name=>'P373_COMM_REST_BELEG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>690
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Rest Beleg'
,p_source=>'COMM_REST_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18905520288948518)
,p_name=>'P373_COMM_TEL_BELEG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>720
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Tel Beleg'
,p_source=>'COMM_TEL_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18905929403948518)
,p_name=>'P373_COMM_PRODUKTE_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Produkte'
,p_source=>'COMM_PRODUKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18906361493948518)
,p_name=>'P373_COMM_BEGRUENDUNG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>unistr('Comm Begr\00FCndung')
,p_source=>unistr('COMM_BEGR\00DCNDUNG')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18906779319948518)
,p_name=>'P373_COMM_SONSTIGES_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>810
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Sonstiges'
,p_source=>'COMM_SONSTIGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18907130237948518)
,p_name=>'P373_BELEG_1'
,p_source_data_type=>'BLOB'
,p_item_sequence=>840
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Beleg'
,p_source=>'BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18907523588948518)
,p_name=>'P373_ZAHLUNGSBELEG_1'
,p_source_data_type=>'BLOB'
,p_item_sequence=>870
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Zahlungsbeleg'
,p_source=>'ZAHLUNGSBELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18907986559948518)
,p_name=>'P373_LITER_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>900
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Liter'
,p_source=>'LITER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18908394954948518)
,p_name=>'P373_ZAPFSAEULE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>930
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Zapfsaeule'
,p_source=>unistr('ZAPFS\00C4ULE')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18908731185948520)
,p_name=>'P373_FK_LOCATION_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>960
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Location'
,p_source=>'FK_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18909154987948520)
,p_name=>'P373_PERSOENLICH_VOR_ORT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>990
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>unistr('Pers\00F6nlich Vor Ort')
,p_source=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18909571826948520)
,p_name=>'P373_BELEG_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1020
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Beleg Uhrzeit'
,p_format_mask=>'HH24:MI:SS'
,p_source=>'BELEG_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18909910648948520)
,p_name=>'P373_VON_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1050
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Von Uhrzeit'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_source=>'VON_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18910337246948520)
,p_name=>'P373_BIS_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1080
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Bis Uhrzeit'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_source=>'BIS_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18910774870948520)
,p_name=>'P373_FK_VON_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1110
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Von Arbeitstag'
,p_source=>'FK_VON_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18911137660948520)
,p_name=>'P373_FK_BIS_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1140
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Bis Arbeitstag'
,p_source=>'FK_BIS_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18911599177948520)
,p_name=>'P373_COMM_ADRESSE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1170
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Adresse'
,p_source=>'COMM_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18911910218948521)
,p_name=>'P373_TANKSTELLEN_NR_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1200
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Tankstellen Nr'
,p_source=>'TANKSTELLEN_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18912343472948521)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1230
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Brutto Betrag Incl Trinkg'
,p_source=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18912765864948521)
,p_name=>'P373_COMM_PARKTICKET_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1260
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Parkticket'
,p_source=>'COMM_PARKTICKET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18913176178948521)
,p_name=>'P373_FRMDW_NETTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1290
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Frmdw Netto Betrag'
,p_source=>'FRMDW_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18913519763948521)
,p_name=>'P373_FK_FRMDW_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1320
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Frmdw'
,p_source=>'FK_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18913959755948521)
,p_name=>'P373_FK_FRMDW_MWST_SATZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1350
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Frmdw Mwst Satz'
,p_source=>'FK_FRMDW_MWST_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18914319151948521)
,p_name=>'P373_FRMDW_MWST_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1380
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Frmdw Mwst Betrag'
,p_source=>'FRMDW_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18914724489948521)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1410
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Frmdw Brutto Betrag'
,p_source=>'FRMDW_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18915172912948523)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1440
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Frmdw Brutto Incl Trinkg'
,p_source=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18915528896948523)
,p_name=>'P373_MWST_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1470
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Mwst Betrag Eur'
,p_source=>'MWST_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18915992444948523)
,p_name=>'P373_BRUTTO_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1500
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Brutto Betrag Eur'
,p_source=>'BRUTTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18916308654948523)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1530
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Brutto Incl Trinkg Eur'
,p_source=>'BRUTTO_INCL_TRINKG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18916774154948523)
,p_name=>'P373_NETTO_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1560
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Netto Betrag Eur'
,p_source=>'NETTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18917172583948523)
,p_name=>'P373_PREIS_PRO_MENGE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1590
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Preis Pro Menge'
,p_source=>'PREIS_PRO_MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18917597781948523)
,p_name=>'P373_MENGENEINHEIT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1620
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Mengeneinheit'
,p_source=>'MENGENEINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18917976077948523)
,p_name=>'P373_LA_DATUM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1650
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'La Datum'
,p_source=>'LA_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18918337900948525)
,p_name=>'P373_FK_LA_KONTO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1680
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk La Konto'
,p_source=>'FK_LA_KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18918786912948525)
,p_name=>'P373_FK_LA_WDH_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1710
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk La Wdh'
,p_source=>'FK_LA_WDH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18919195309948525)
,p_name=>'P373_FK_ZAHLSTATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1740
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Zahlstatus'
,p_source=>'FK_ZAHLSTATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18919595347948525)
,p_name=>'P373_COMM_VERGEHEN_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1770
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Comm Vergehen'
,p_source=>'COMM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18919905450948525)
,p_name=>'P373_VERG_BEHOERDE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1800
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Verg Behoerde'
,p_source=>'VERG_BEHOERDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18920342698948525)
,p_name=>'P373_CNT_PUNKTE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1830
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Cnt Punkte'
,p_source=>'CNT_PUNKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18920725297948525)
,p_name=>'P373_FK_BELEG_ABLAGE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1860
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Beleg Ablage'
,p_source=>'FK_BELEG_ABLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18921171970948525)
,p_name=>'P373_FK_ABL_ORDNER_PAGE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1890
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Abl Ordner Page'
,p_source=>'FK_ABL_ORDNER_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18921545425948526)
,p_name=>'P373_CNT_PUNKTE_GESCHAETZT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1920
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Cnt Punkte Geschaetzt'
,p_source=>'CNT_PUNKTE_GESCHAETZT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18921986451948526)
,p_name=>'P373_PUNKTE_VON_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1950
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Punkte Von'
,p_source=>'PUNKTE_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18922355573948526)
,p_name=>'P373_PUNKTE_BIS_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1980
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Punkte Bis'
,p_source=>'PUNKTE_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18922719733948526)
,p_name=>'P373_FK_LOCATION_VERG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2010
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Location Verg'
,p_source=>'FK_LOCATION_VERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18923175210948526)
,p_name=>'P373_FK_IMP_BA_BEL_OLD_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2040
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Imp Ba Bel Old'
,p_source=>'FK_IMP_BA_BEL_OLD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18923541953948526)
,p_name=>'P373_GESCHW_IST_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2070
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Geschw Ist'
,p_source=>'GESCHW_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18923932168948526)
,p_name=>'P373_GESCHW_SOLL_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2100
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Geschw Soll'
,p_source=>'GESCHW_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18924385410948526)
,p_name=>'P373_GESCHW_UEBER_GRZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2130
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Geschw Ueber Grz'
,p_source=>'GESCHW_UEBER_GRZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18924756983948526)
,p_name=>'P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2160
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Geschw Ueber Grz Abzgl Messtol'
,p_source=>'GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18925138647948526)
,p_name=>'P373_CODE_BUSSGELD_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2190
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Code Bussgeld'
,p_source=>'CODE_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18925590358948528)
,p_name=>'P373_DESCR_BUSSGELD_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2220
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Descr Bussgeld'
,p_source=>'DESCR_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18925940401948528)
,p_name=>'P373_GEZAHLT_AM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2250
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Gezahlt Am'
,p_source=>'GEZAHLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18926343065948528)
,p_name=>'P373_WEBSEITE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2280
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Webseite'
,p_source=>'WEBSEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18926724872948528)
,p_name=>'P373_KUNDENNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2310
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Kundennummer'
,p_source=>'KUNDENNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18927198712948528)
,p_name=>'P373_FK_REAL_BELEG_EXIST_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2340
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Real Beleg Exist'
,p_source=>'FK_REAL_BELEG_EXIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18927539850948528)
,p_name=>'P373_FK_CALC_STATE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2370
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Calc State'
,p_source=>'FK_CALC_STATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18927966010948528)
,p_name=>'P373_FK_CALC_STATE_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2400
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Calc State Eur'
,p_source=>'FK_CALC_STATE_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18928356419948528)
,p_name=>'P373_FK_CALC_STATE_FRMDW_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2430
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Calc State Frmdw'
,p_source=>'FK_CALC_STATE_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18928743957948529)
,p_name=>'P373_FK_STATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2460
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18929156136948529)
,p_name=>'P373_DATUM_VERGEHEN_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2490
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Vergehen'
,p_source=>'DATUM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18929589291948529)
,p_name=>'P373_CREATE_AT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2520
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Create At'
,p_source=>'CREATE_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18929933205948529)
,p_name=>'P373_CREATE_BY_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2550
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Create By'
,p_source=>'CREATE_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18930321073948529)
,p_name=>'P373_MODIFY_AT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2580
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Modify At'
,p_source=>'MODIFY_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18930706294948529)
,p_name=>'P373_MODIFY_BY_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2610
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Modify By'
,p_source=>'MODIFY_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18931120314948529)
,p_name=>'P373_DATUM_ORT_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2640
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18931545412948529)
,p_name=>'P373_DATUM_ADDRESSE_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2670
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18931920820948529)
,p_name=>'P373_DATUM_BUSSGELD_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2700
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18932329710948529)
,p_name=>'P373_DATUM_BELEG_POS_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2730
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18932792526948529)
,p_name=>'P373_DATUM_BUCHUNG_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2760
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18933168348948531)
,p_name=>'P373_DATUM_VERPFL_BEL_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2790
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_source=>'DATUM_VERPFL_BEL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18933564636948531)
,p_name=>'P373_FK_INTERNET_APP_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2820
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Internet App'
,p_source=>'FK_INTERNET_APP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18933982187948531)
,p_name=>'P373_FK_DUPL_STATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2850
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Dupl Status'
,p_source=>'FK_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18934379286948531)
,p_name=>'P373_DATUM_DUPL_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2880
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Datum Dupl Ok'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18934770281948531)
,p_name=>'P373_DUPL_BEMERKUNG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2910
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18935138339948531)
,p_name=>'P373_FK_GESCHAEFTSPARTNER_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2940
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_item_source_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>unistr('Fk Gesch\00E4ftspartner')
,p_source=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18966712245967998)
,p_name=>'P373_SRC_PK_INP_BELEGE_ALL'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(18821419319922533)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19186757191478801)
,p_name=>'P373_NEW_1_1_1'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19186835012478802)
,p_name=>'P373_NEW_1_1_1_1'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19186983348478803)
,p_name=>'P373_NEW_1_1_1_1_1'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187043117478804)
,p_name=>'P373_NEW_1_1_1_1_1_1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187101492478805)
,p_name=>'P373_NEW_1_1_1_2'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187266653478806)
,p_name=>'P373_NEW_1_1_1_2_1'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187372279478807)
,p_name=>'P373_NEW_1_1_1_2_1_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187463416478808)
,p_name=>'P373_NEW_1_1_1_2_1_1_1'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187599537478809)
,p_name=>'P373_NEW_1_1_1_2_2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187602940478810)
,p_name=>'P373_NEW_1_1_1_2_2_1'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187701648478811)
,p_name=>'P373_NEW_1_1_1_2_2_1_1'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187872569478812)
,p_name=>'P373_NEW_1_1_1_2_2_1_1_1'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19187907835478813)
,p_name=>'P373_NEW_1_1_1_2_3'
,p_item_sequence=>670
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188065246478814)
,p_name=>'P373_NEW_1_1_1_2_3_1'
,p_item_sequence=>640
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188138818478815)
,p_name=>'P373_NEW_1_1_1_2_3_1_1'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188266100478816)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188350556478817)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1_1'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188469628478818)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1_1_1'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188542455478819)
,p_name=>'P373_NEW_1_1_1_2_4'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188664127478820)
,p_name=>'P373_NEW_1_1_1_2_3_2'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188721468478821)
,p_name=>'P373_NEW_1_1_1_2_3_2_1'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188853874478822)
,p_name=>'P373_NEW_1_1_1_2_3_2_1_1'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19188903620478823)
,p_name=>'P373_NEW_1_1_1_2_3_2_1_1_1'
,p_item_sequence=>700
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189044533478824)
,p_name=>'P373_NEW_1_1_1_2_3_2_2'
,p_item_sequence=>880
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189106152478825)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1'
,p_item_sequence=>850
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189242580478826)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1'
,p_item_sequence=>910
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189346616478827)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1'
,p_item_sequence=>940
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189427537478828)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_1'
,p_item_sequence=>820
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189519259478829)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2'
,p_item_sequence=>1060
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189633155478830)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1'
,p_item_sequence=>1030
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189771781478831)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1_1'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189813117478832)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1_1_1'
,p_item_sequence=>970
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19189950620478833)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2'
,p_item_sequence=>1180
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190042569478834)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1'
,p_item_sequence=>1120
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190106221478835)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1_1'
,p_item_sequence=>1150
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190275542478836)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1_1_1'
,p_item_sequence=>1090
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190318262478837)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2'
,p_item_sequence=>1330
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190470835478838)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1'
,p_item_sequence=>1300
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190550965478839)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1'
,p_item_sequence=>1270
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190682775478840)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1_1'
,p_item_sequence=>1240
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190746751478841)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1_1_1'
,p_item_sequence=>1210
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190891622478842)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2'
,p_item_sequence=>1420
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19190947044478843)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1'
,p_item_sequence=>1450
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191010012478844)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_1'
,p_item_sequence=>1390
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191173699478845)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_1_1'
,p_item_sequence=>1360
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191277230478846)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2'
,p_item_sequence=>1630
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191385989478847)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1'
,p_item_sequence=>1600
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191457783478848)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1'
,p_item_sequence=>1570
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191500629478849)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1'
,p_item_sequence=>1540
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19191694235478850)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1_1'
,p_item_sequence=>1510
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355150995537001)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1_1_1'
,p_item_sequence=>1480
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355288298537002)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2'
,p_item_sequence=>1780
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355329471537003)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1'
,p_item_sequence=>1720
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355429393537004)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1'
,p_item_sequence=>1690
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355577677537005)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1_1'
,p_item_sequence=>1750
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355655138537006)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1_1_1'
,p_item_sequence=>1660
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355705993537007)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2'
,p_item_sequence=>1930
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355835782537008)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1'
,p_item_sequence=>1900
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19355991678537009)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1'
,p_item_sequence=>1870
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356096804537010)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1_1'
,p_item_sequence=>1840
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356114439537011)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1_1_1'
,p_item_sequence=>1810
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356239125537012)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2'
,p_item_sequence=>2050
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356396524537013)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1'
,p_item_sequence=>2020
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356471442537014)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1_1'
,p_item_sequence=>1990
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356508339537015)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1_1_1'
,p_item_sequence=>1960
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356666647537016)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2'
,p_item_sequence=>2140
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356783100537017)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_1'
,p_item_sequence=>2110
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356807458537018)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_1_1'
,p_item_sequence=>2080
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19356928729537019)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2'
,p_item_sequence=>2290
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357080990537020)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1'
,p_item_sequence=>2260
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357113857537021)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1'
,p_item_sequence=>2200
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357215094537022)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2230
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357379549537023)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>2170
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357474288537024)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2'
,p_item_sequence=>2470
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357515108537025)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1'
,p_item_sequence=>2410
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357648818537026)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2380
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357778109537027)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2350
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357876358537028)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>2440
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19357995738537029)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1_1_1'
,p_item_sequence=>2320
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358098233537030)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2'
,p_item_sequence=>2620
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358116816537031)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2560
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358211767537032)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2530
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358325317537033)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2590
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358425923537034)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>2500
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358539605537035)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2830
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358686250537036)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2710
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358714485537037)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2740
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358851762537038)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2680
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19358937460537039)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>2650
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359039095537040)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2860
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359159182537041)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2770
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359292594537042)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2800
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359372193537043)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2920
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359454007537044)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2950
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19359570916537045)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2890
,p_item_plug_id=>wwv_flow_api.id(56492267503811925)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165216454887317)
,p_name=>'P373_FK_LEX_BUCHUNG_FLG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Lex Buchung'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165354731887318)
,p_name=>'P373_FK_VERWENDUNGSZWECK_FLG'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk verwendungszweck'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165429891887319)
,p_name=>'P373_FK_KATEGORIE_FLG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165558428887320)
,p_name=>'P373_FK_ARBEITSTAG_FLG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165616930887321)
,p_name=>'P373_FK_INVENTAR_FLG'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165793256887322)
,p_name=>'P373_FK_BUCHUNG_FLG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Buchung'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165880433887323)
,p_name=>'P373_FK_ZAHLUNGSART_FLG'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk zahlungsart'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21165937268887324)
,p_name=>'P373_BEL_DATUM_FLG'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk bel_datum'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166065413887325)
,p_name=>'P373_BIS_FLG'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk bis'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166108307887326)
,p_name=>'P373_FK_STEUERSATZ_FLG'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk steuersatz'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166209019887327)
,p_name=>'P373_COMM_BEGRUENDUNG_FLG'
,p_item_sequence=>850
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Fk begr\00FCndung')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166368691887328)
,p_name=>'P373_VON_UHRZEIT_FLG'
,p_item_sequence=>1200
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk von uhrzeit flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166472623887329)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG_FLG'
,p_item_sequence=>1390
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk brutto_betrag_incl_trinkg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166557621887330)
,p_name=>'P373_COMM_PARKTICKET_FLG'
,p_item_sequence=>1430
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166626187887331)
,p_name=>'P373_FK_FRMDW_MWST_SATZ_FLG'
,p_item_sequence=>1590
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166749375887332)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG_FLG'
,p_item_sequence=>1630
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166833929887333)
,p_name=>'P373_BRUTTO_BETRAG_EUR_FLG'
,p_item_sequence=>1690
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21166950314887334)
,p_name=>'P373_PREIS_PRO_MENGE_FLG'
,p_item_sequence=>1830
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk preis pro menge flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167048396887335)
,p_name=>'P373_LA_DATUM_FLG'
,p_item_sequence=>2160
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167121322887336)
,p_name=>'P373_FK_LA_WDH_FLG'
,p_item_sequence=>2200
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167214442887337)
,p_name=>'P373_FK_ZAHLSTATUS_FLG'
,p_item_sequence=>2220
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167387285887338)
,p_name=>'P373_VERG_BEHOERDE_FLG'
,p_item_sequence=>2260
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167429405887339)
,p_name=>'P373_CNT_PUNKTE_FLG'
,p_item_sequence=>2280
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk cnt punkte'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167541132887340)
,p_name=>'P373_BRUTTO_BETRAG_FLG'
,p_item_sequence=>660
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk_brutto_betrag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167683843887341)
,p_name=>'P373_MWST_BETRAG_FLG'
,p_item_sequence=>620
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk mwst_betrag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167787846887342)
,p_name=>'P373_PUNKTE_BIS_FLG'
,p_item_sequence=>2360
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167879785887343)
,p_name=>'P373_FK_LOCATION_VERG_FLG'
,p_item_sequence=>2380
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21167929089887344)
,p_name=>'P373_GESCHW_SOLL_FLG'
,p_item_sequence=>2440
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168022482887345)
,p_name=>'P373_GESCHW_UEBER_GRZ_FLG'
,p_item_sequence=>2460
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168109944887346)
,p_name=>'P373_FK_CITY_FLG'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk city'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168223636887347)
,p_name=>'P373_CODE_BUSSGELD_FLG'
,p_item_sequence=>2500
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk code bussgeld'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168314436887348)
,p_name=>'P373_GEZAHLT_AM_FLG'
,p_item_sequence=>2540
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168497005887349)
,p_name=>'P373_KUNDENNUMMER_FLG'
,p_item_sequence=>2580
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk KUNDENNUMMER_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21168565660887350)
,p_name=>'P373_COMM_SONSTIGES_FLG'
,p_item_sequence=>900
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk omm sonstiges flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21362537869318201)
,p_name=>'P373_FK_CALC_STATE_FLG'
,p_item_sequence=>2620
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk calc_state flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21362663550318202)
,p_name=>'P373_FK_CALC_STATE_EUR_FLG'
,p_item_sequence=>2640
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21362704226318203)
,p_name=>'P373_DATUM_VERGEHEN_FLG'
,p_item_sequence=>2700
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21362860460318204)
,p_name=>'P373_CREATE_AT_FLG'
,p_item_sequence=>2720
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21362984191318205)
,p_name=>'P373_DATUM_BUSSGELD_OK_FLG'
,p_item_sequence=>2900
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363044596318206)
,p_name=>'P373_CREATE_BY_FLG'
,p_item_sequence=>2760
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363131356318207)
,p_name=>'P373_ZAPFSAEULE_FLG'
,p_item_sequence=>1040
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk zapfsaeuler'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363202510318208)
,p_name=>'P373_BELEG_UHRZEIT_FLG'
,p_item_sequence=>1160
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk beleg uhrzeit'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363352651318209)
,p_name=>'P373_FK_BIS_ARBEITSTAG_FLG'
,p_item_sequence=>1330
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363424965318210)
,p_name=>'P373_FK_FRMDW_FLG'
,p_item_sequence=>1470
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk frmdw'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363547088318211)
,p_name=>'P373_NETTO_BETRAG_EUR_FLG'
,p_item_sequence=>1730
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363665685318212)
,p_name=>'P373_MENGENEINHEIT_FLG'
,p_item_sequence=>1850
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363723004318213)
,p_name=>'P373_FK_STATUS_FLG'
,p_item_sequence=>2680
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363820491318214)
,p_name=>'P373_FK_GESCHAEFTSPARTNER_FLG'
,p_item_sequence=>3060
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21363920454318215)
,p_name=>'P373_FK_INTERNET_APP_FLG'
,p_item_sequence=>2980
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364023687318216)
,p_name=>'P373_FK_DUPL_STATUS_FLG'
,p_item_sequence=>3000
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364152120318217)
,p_name=>'P373_PUNKTE_VON_FLG'
,p_item_sequence=>2340
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364231157318218)
,p_name=>'P373_GESCHW_IST_FLG'
,p_item_sequence=>2420
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk geschw_ist'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364379472318219)
,p_name=>'P373_FK_CALC_STATE_FRMDW_FLG'
,p_item_sequence=>2660
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk calc state frmdw'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364467397318220)
,p_name=>'P373_DATUM_BUCHUNG_OK_FLG'
,p_item_sequence=>2940
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364526058318221)
,p_name=>'P373_ZAHLUNGSBELEG_FLG'
,p_item_sequence=>970
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364633106318222)
,p_name=>'P373_MODIFY_AT_FLG'
,p_item_sequence=>2800
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364767671318223)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR_FLG'
,p_item_sequence=>1710
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364823571318224)
,p_name=>'P373_DATUM_ADDRESSE_OK_FLG'
,p_item_sequence=>2880
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21364995859318225)
,p_name=>'P373_FK_LA_KONTO_FLG'
,p_item_sequence=>2180
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365002602318226)
,p_name=>'P373_DATUM_BELEG_POS_OK_FLG'
,p_item_sequence=>2920
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365166723318227)
,p_name=>'P373_COMM_VERGEHEN_FLG'
,p_item_sequence=>2240
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365292859318228)
,p_name=>'P373_MWST_BETRAG_EUR_FLG'
,p_item_sequence=>1670
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk MWST_BETRAG_EUR'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365324921318229)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG_FLG'
,p_item_sequence=>1650
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk frmdw_brutto_incl_trinkg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365429149318230)
,p_name=>'P373_FK_LAND_FLG'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk land'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365594301318231)
,p_name=>'P373_VON_FLG'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk von'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365643557318232)
,p_name=>'P373_FK_BELEG_ABLAGE_FLG'
,p_item_sequence=>2300
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk beleg_ablage_'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365776894318233)
,p_name=>'P373_CNT_PUNKTE_GESCHAETZT_FLG'
,p_item_sequence=>2330
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365851838318234)
,p_name=>'P373_NETTO_BETRAG_FLG'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk netto betrag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21365955532318235)
,p_name=>'P373_FK_ABL_ORDNER_PAGE_FLG'
,p_item_sequence=>2310
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk beleg ablage'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366045767318236)
,p_name=>'P373_FK_LOCATION_FLG'
,p_item_sequence=>1070
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk location'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366161651318237)
,p_name=>'P373_WEBSEITE_FLG'
,p_item_sequence=>2560
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366231494318238)
,p_name=>'P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_FLG'
,p_item_sequence=>2480
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366341260318239)
,p_name=>'P373_FK_PROJEKT_FLG'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk projekt'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366481872318240)
,p_name=>'P373_BELEGNUMMER_FLG'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk belegnummer'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FClllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366557637318241)
,p_name=>'P373_FK_IMP_BA_BEL_OLD_FLG'
,p_item_sequence=>2390
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk imp ba bel old'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366697059318242)
,p_name=>'P373_BEZEICHNUNG_FLG'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk bezeichnung'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366759539318243)
,p_name=>'P373_COMM_TEL_BELEG_FLG'
,p_item_sequence=>800
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk comm_tel_beleg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366863785318244)
,p_name=>'P373_STEUERNUMMER_FLG'
,p_item_sequence=>740
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21366931951318245)
,p_name=>'P373_COMM_PRODUKTE_FLG'
,p_item_sequence=>830
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21367023198318246)
,p_name=>'P373_COMM_REST_BELEG_FLG'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk comm rest beleg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21367166278318247)
,p_name=>'P373_FK_WAEHRUNG_FLG'
,p_item_sequence=>680
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21367219660318248)
,p_name=>'P373_FK_REAL_BELEG_EXIST_FLG'
,p_item_sequence=>2600
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21367315273318249)
,p_name=>'P373_FK_UMRECHNUNGSKURS_FLG'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Umrechnungskurs'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21367460800318250)
,p_name=>'P373_DESCR_BUSSGELD_FLG'
,p_item_sequence=>2520
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462054016339601)
,p_name=>'P373_MODIFY_BY_FLG'
,p_item_sequence=>2830
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462119878339602)
,p_name=>'P373_BELEG_FLG'
,p_item_sequence=>950
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FClllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462292955339603)
,p_name=>'P373_FK_VON_ARBEITSTAG_FLG'
,p_item_sequence=>1240
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462343839339604)
,p_name=>'P373_LITER_FLG'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462470758339605)
,p_name=>'P373_BIS_UHRZEIT_FLG'
,p_item_sequence=>1220
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462530894339606)
,p_name=>'P373_PERSOENLICH_VOR_ORT_FLG'
,p_item_sequence=>1140
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>unistr('Fk pers\00F6nlich vor ort')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462609376339607)
,p_name=>'P373_COMM_ADRESSE_FLG'
,p_item_sequence=>1350
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462768246339608)
,p_name=>'P373_FRMDW_MWST_BETRAG_FLG'
,p_item_sequence=>1610
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk frmdw mwst betrag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462892310339609)
,p_name=>'P373_TANKSTELLEN_NR_FLG'
,p_item_sequence=>1370
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21462903407339610)
,p_name=>'P373_FRMDW_NETTO_BETRAG_FLG'
,p_item_sequence=>1450
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21463010699339611)
,p_name=>'P373_DATUM_VERPFL_BEL_OK_FLG'
,p_item_sequence=>2960
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk datum_verpfl_bel_ok'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21463130884339612)
,p_name=>'P373_DATUM_ORT_OK_FLG'
,p_item_sequence=>2860
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21463214682339613)
,p_name=>'P373_DUPL_BEMERKUNG_FLG'
,p_item_sequence=>3040
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nein;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21463374255339614)
,p_name=>'P373_DATUM_DUPL_OK_FLG'
,p_item_sequence=>3020
,p_item_plug_id=>wwv_flow_api.id(18740871487919567)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC2:ja;1,nen;0,ausgef\00FCllt;2')
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(21463651076339617)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P373_FK_LEX_BUCHUNG_FLG'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(21463723780339618)
,p_event_id=>wwv_flow_api.id(21463651076339617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P373_FK_LEX_BUCHUNG_FLG'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18812797051919615)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(18740871487919567)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Delete'
,p_process_when_type=>'REQUEST_NOT_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(21165117289887316)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  delete from inp_belege_all where pk_inp_belege_all = :P373_SRC_PK_INP_BELEGE_ALL;',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(21165063751887315)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18812353908919615)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(18740871487919567)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18822860664922547)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Create Form_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' --1 - SRC-Belege Daten laden',
'',
'  if :P373_PK_INP_BELEGE_ALL_1 is not null then',
'  ',
'  select',
'',
'            FK_LEX_BUCHUNG	,',
'            FK_KATEGORIE	,',
'            FK_ARBEITSTAG	,',
'            FK_BUCHUNG	,',
'            FK_ZAHLUNGSART	,',
'            FK_VERWENDUNGSZWECK	,',
'            FK_INVENTAR	,',
'            FK_PROJEKT	,',
'            BELEGNUMMER	,',
'            BEZEICHNUNG	,',
'            FK_LAND	,',
'            FK_CITY	,',
'            BEL_DATUM	,',
'            VON	,',
'            BIS	,',
'            NETTO_BETRAG	,',
'            FK_STEUERSATZ	,',
'            MWST_BETRAG	,',
'            BRUTTO_BETRAG	,',
'            FK_WAEHRUNG	,',
'            STEUERNUMMER	,',
'            FK_UMRECHNUNGSKURS	,',
'            COMM_REST_BELEG	,',
'            COMM_TEL_BELEG	,',
'            COMM_PRODUKTE	,',
unistr('            "COMM_BEGR\00DCNDUNG"	,'),
'            COMM_SONSTIGES	,',
'            BELEG	,',
'            ZAHLUNGSBELEG	,',
'            LITER	,',
unistr('            ZAPFS\00C4ULE	,'),
'            FK_LOCATION	,',
unistr('            PERS\00D6NLICH_VOR_ORT	,'),
'            to_char(BELEG_UHRZEIT,''DD.MM.YYYY HH24:MI:SS'')	,',
'            to_char(VON_UHRZEIT,''DD.MM.YYYY HH24:MI:SS'')	,',
'            to_char(BIS_UHRZEIT	,''DD.MM.YYYY HH24:MI:SS''),',
'            FK_VON_ARBEITSTAG	,',
'            FK_BIS_ARBEITSTAG	,',
'            COMM_ADRESSE	,',
'            TANKSTELLEN_NR	,',
'            BRUTTO_BETRAG_INCL_TRINKG	,',
'            COMM_PARKTICKET	,',
'            FRMDW_NETTO_BETRAG	,',
'            FK_FRMDW	,',
'            FK_FRMDW_MWST_SATZ	,',
'            FRMDW_MWST_BETRAG	,',
'            FRMDW_BRUTTO_BETRAG	,',
'            FRMDW_BRUTTO_INCL_TRINKG	,',
'            MWST_BETRAG_EUR	,',
'            BRUTTO_BETRAG_EUR	,',
'            BRUTTO_INCL_TRINKG_EUR	,',
'            NETTO_BETRAG_EUR	,',
'            PREIS_PRO_MENGE	,',
'            MENGENEINHEIT	,',
'            LA_DATUM	,',
'            FK_LA_KONTO	,',
'            FK_LA_WDH	,',
'            FK_ZAHLSTATUS	,',
'            COMM_VERGEHEN	,',
'            VERG_BEHOERDE	,',
'            CNT_PUNKTE	,',
'            FK_BELEG_ABLAGE	,',
'            FK_ABL_ORDNER_PAGE	,',
'            CNT_PUNKTE_GESCHAETZT	,',
'            PUNKTE_VON	,',
'            PUNKTE_BIS	,',
'            FK_LOCATION_VERG	,',
'            FK_IMP_BA_BEL_OLD	,',
'            GESCHW_IST	,',
'            GESCHW_SOLL	,',
'            GESCHW_UEBER_GRZ	,',
'            GESCHW_UEBER_GRZ_ABZGL_MESSTOL	,',
'            CODE_BUSSGELD	,',
'            DESCR_BUSSGELD	,',
'            GEZAHLT_AM	,',
'            WEBSEITE	,',
'            KUNDENNUMMER	,',
'            FK_REAL_BELEG_EXIST	,',
'            FK_CALC_STATE	,',
'            FK_CALC_STATE_EUR	,',
'            FK_CALC_STATE_FRMDW	,',
'            FK_STATUS	,',
'            DATUM_VERGEHEN	,',
'            CREATE_AT	,',
'            CREATE_BY	,',
'            MODIFY_AT	,',
'            MODIFY_BY	,',
'            DATUM_ORT_OK	,',
'            DATUM_ADDRESSE_OK	,',
'            DATUM_BUSSGELD_OK	,',
'            DATUM_BELEG_POS_OK	,',
'            DATUM_BUCHUNG_OK	,',
'            DATUM_VERPFL_BEL_OK	,',
'            FK_INTERNET_APP	,',
'            FK_DUPL_STATUS	,',
'            DATUM_DUPL_OK	,',
'            DUPL_BEMERKUNG	,',
unistr('            FK_GESCH\00C4FTSPARTNER	 '),
'        Into',
'        :P373_FK_LEX_BUCHUNG_1,',
'        :P373_FK_KATEGORIE_1,',
'        :P373_FK_ARBEITSTAG_1,',
'        :P373_FK_BUCHUNG_1,',
'        :P373_FK_ZAHLUNGSART_1,',
'        :P373_FK_VERWENDUNGSZWECK_1,',
'        :P373_FK_INVENTAR_1,',
'        :P373_FK_PROJEKT_1,',
'        :P373_BELEGNUMMER_1,',
'        :P373_BEZEICHNUNG_1,',
'        :P373_FK_LAND_1,',
'        :P373_FK_CITY_1,',
'        :P373_BEL_DATUM_1,',
'        :P373_VON_1,',
'        :P373_BIS_1,',
'        :P373_NETTO_BETRAG_1,',
'        :P373_FK_STEUERSATZ_1,',
'        :P373_MWST_BETRAG_1,',
'        :P373_BRUTTO_BETRAG_1,',
'        :P373_FK_WAEHRUNG_1,',
'        :P373_STEUERNUMMER_1,',
'        :P373_FK_UMRECHNUNGSKURS_1,',
'        :P373_COMM_REST_BELEG_1,',
'        :P373_COMM_TEL_BELEG_1,',
'        :P373_COMM_PRODUKTE_1,',
'        :P373_COMM_BEGRUENDUNG_1,',
'        :P373_COMM_SONSTIGES_1,',
'        :P373_BELEG_1,',
'        :P373_ZAHLUNGSBELEG_1,',
'        :P373_LITER_1,',
'        :P373_ZAPFSAEULE_1,',
'        :P373_FK_LOCATION_1,',
'        :P373_PERSOENLICH_VOR_ORT_1,',
'        :P373_BELEG_UHRZEIT_1,',
'        :P373_VON_UHRZEIT_1,',
'        :P373_BIS_UHRZEIT_1,',
'        :P373_FK_VON_ARBEITSTAG_1,',
'        :P373_FK_BIS_ARBEITSTAG_1,',
'        :P373_COMM_ADRESSE_1,',
'        :P373_TANKSTELLEN_NR_1,',
'        :P373_BRUTTO_BETRAG_INCL_TRINKG_1,',
'        :P373_COMM_PARKTICKET_1,',
'        :P373_FRMDW_NETTO_BETRAG_1,',
'        :P373_FK_FRMDW_1,',
'        :P373_FK_FRMDW_MWST_SATZ_1,',
'        :P373_FRMDW_MWST_BETRAG_1,',
'        :P373_FRMDW_BRUTTO_BETRAG_1,',
'        :P373_FRMDW_BRUTTO_INCL_TRINKG_1,',
'        :P373_MWST_BETRAG_EUR_1,',
'        :P373_BRUTTO_BETRAG_EUR_1,',
'        :P373_BRUTTO_INCL_TRINKG_EUR_1,',
'        :P373_NETTO_BETRAG_EUR_1,',
'        :P373_PREIS_PRO_MENGE_1,',
'        :P373_MENGENEINHEIT_1,',
'        :P373_LA_DATUM_1,',
'        :P373_FK_LA_KONTO_1,',
'        :P373_FK_LA_WDH_1,',
'        :P373_FK_ZAHLSTATUS_1,',
'        :P373_COMM_VERGEHEN_1,',
'        :P373_VERG_BEHOERDE_1,',
'        :P373_CNT_PUNKTE_1,',
'        :P373_FK_BELEG_ABLAGE_1,',
'        :P373_FK_ABL_ORDNER_PAGE_1,',
'        :P373_CNT_PUNKTE_GESCHAETZT_1,',
'        :P373_PUNKTE_VON_1,',
'        :P373_PUNKTE_BIS_1,',
'        :P373_FK_LOCATION_VERG_1,',
'        :P373_FK_IMP_BA_BEL_OLD_1,',
'        :P373_GESCHW_IST_1,',
'        :P373_GESCHW_SOLL_1,',
'        :P373_GESCHW_UEBER_GRZ_1,',
'        :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,',
'        :P373_CODE_BUSSGELD_1,',
'        :P373_DESCR_BUSSGELD_1,',
'        :P373_GEZAHLT_AM_1,',
'        :P373_WEBSEITE_1,',
'        :P373_KUNDENNUMMER_1,',
'        :P373_FK_REAL_BELEG_EXIST_1,',
'        :P373_FK_CALC_STATE_1,',
'        :P373_FK_CALC_STATE_EUR_1,',
'        :P373_FK_CALC_STATE_FRMDW_1,',
'        :P373_FK_STATUS_1,',
'        :P373_DATUM_VERGEHEN_1,',
'        :P373_CREATE_AT_1,',
'        :P373_CREATE_BY_1,',
'        :P373_MODIFY_AT_1,',
'        :P373_MODIFY_BY_1,',
'        :P373_DATUM_ORT_OK_1,',
'        :P373_DATUM_ADDRESSE_OK_1,',
'        :P373_DATUM_BUSSGELD_OK_1,',
'        :P373_DATUM_BELEG_POS_OK_1,',
'        :P373_DATUM_BUCHUNG_OK_1,',
'        :P373_DATUM_VERPFL_BEL_OK_1,',
'        :P373_FK_INTERNET_APP_1,',
'        :P373_FK_DUPL_STATUS_1,',
'        :P373_DATUM_DUPL_OK_1,',
'        :P373_DUPL_BEMERKUNG_1,',
'        :P373_FK_GESCHAEFTSPARTNER_1',
'from inp_belege_all ',
'  where Pk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1;',
'end if;',
'  ',
'',
'',
'end;'))
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(21463840732339619)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P373_PK_INP_BELEGE_ALL_1 is not null and :P373_PK_INP_BELEGE_ALL is not null then   --2 - Abgleich SRC-Beleg mit Ziel-Beleg',
'select',
'--fk_lex_buchung',
'case when nvl(:P373_FK_LEX_BUCHUNG,0) =  nvl(:P373_FK_LEX_BUCHUNG_1,0) and :P373_lex_buchung is not null then ''1:2''',
'when nvl(:P373_FK_LEX_BUCHUNG,0) =  nvl(:P373_FK_LEX_BUCHUNG_1,0) and :P373_lex_buchung is null then ''1''',
'when :P373_LEX_BUCHUNG is not null then ''0:2'' else ''0'' end,',
'--fk_kategorie',
'case when nvl(:P373_FK_KATEGORIE,0) =  nvl(:P373_FK_KATEGORIE_1,0) and :P373_fk_kategorie is not null then ''1:2''',
'when nvl(:P373_FK_kategorie,0) =  nvl(:P373_FK_kategorie_1,0) and :P373_fk_kategorie is null then ''1''',
'when :P373_fk_kateogrie is not null then ''0:2'' else ''0'' end,',
'--fk_arbeitstag',
'case when nvl(:P373_FK_arbeitstag,0) =  nvl(:P373_FK_arbeitstag_1,0) and :P373_FK_arbeitstag is not null then ''1:2''',
'when nvl(:P373_FK_arbeitstag,0) =  nvl(:P373_FK_arbeitstag_1,0) and :P373_FK_arbeitstag is null then ''1''',
'when :P373_FK_arbeitstag is not null then ''0:2'' else ''0'' end,',
'--fk_buchung',
'case when nvl(:P373_FK_buchung,0) =  nvl(:P373_FK_buchung_1,0) and :P373_FK_buchung is not null then ''1:2''',
'when nvl(:P373_FK_buchung,0) =  nvl(:P373_FK_buchung_1,0) and :P373_FK_buchung is null then ''1''',
'when :P373_FK_buchung is not null then ''0:2'' else ''0'' end,',
'--fk_zahlungsart',
'case when nvl(:P373_FK_zahlungsart,0) =  nvl(:P373_FK_zahlungsart_1,0) and :P373_FK_zahlungsart is not null then ''1:2''',
'when nvl(:P373_FK_zahlungsart,0) =  nvl(:P373_FK_zahlungsart_1,0) and :P373_FK_zahlungsart is null then ''1''',
'when :P373_FK_zahlungsart is not null then ''0:2''  else ''0'' end,',
'--fk_verwendungszweck',
'case when nvl(:P373_FK_verwendungszweck,0) =  nvl(:P373_FK_verwendungszweck_1,0) and :P373_FK_verwendungszweck is not null then ''1:2''',
'when nvl(:P373_FK_verwendungszweck,0) =  nvl(:P373_FK_verwendungszweck_1,0) and :P373_FK_verwendungszweck is null then ''1''',
'when :P373_FK_verwendungszweck is not null then ''0:2'' else ''0'' end,',
'--fk-inventar',
'case when nvl(:P373_FK_INVENTAR,0) = nvl(:P373_FK_INVENTAR_1,0) and :P373_FK_INVENTAR is not null then ''1:2''',
'when nvl(:P373_FK_INVENTAR,0) =  nvl(:P373_FK_INVENTAR_1,0) and :P373_FK_INVENTAR is null then ''1''',
'when :P373_FK_INVENTAR is not null then ''0:2'' else ''0'' end,',
'--fk_projekt',
'case when nvl(:P373_FK_PROJEKT,0) = nvl(:P373_FK_PROJEKT_1,0) and :P373_FK_PROJEKT is not null then ''1:2''',
'when nvl(:P373_FK_PROJEKT,0) =  nvl(:P373_FK_PROJEKT_1,0) and :P373_FK_PROJEKT is null then ''1''',
'when :P373_FK_PROJEKT is not null then ''0:2''  else ''0'' end,',
'--belegnummer',
'case when nvl(:P373_BELEGNUMMER,0) = nvl(:P373_BELEGNUMMER_1,0) and :P373_BELEGNUMMER is not null then ''1:2''',
'when nvl(:P373_BELEGNUMMER,0) =  nvl(:P373_BELEGNUMMER_1,0) and :P373_BELEGNUMMER is null then ''1''',
'when :P373_BELEGNUMMER is not null then ''0:2'' else ''0'' end,',
'--bezeichnung',
'case when nvl(:P373_BEZEICHNUNG,0) = nvl(:P373_BEZEICHNUNG_1,0) and :P373_BEZEICHNUNG is not null then ''1:2''',
'when nvl(:P373_BEZEICHNUNG,0) =  nvl(:P373_BEZEICHNUNG_1,0) and :P373_BEZEICHNUNG is null then ''1''',
'when :P373_BEZEICHNUNG is not null then ''0:2'' else ''0'' end,',
'--fk_land',
'case when nvl(:P373_FK_LAND,0) = nvl(:P373_FK_LAND_1,0) and :P373_FK_LAND is not null then ''1:2''',
'when nvl(:P373_FK_LAND,0) =  nvl(:P373_FK_LAND_1,0) and :P373_FK_LAND is null then ''1''',
'when :P373_FK_LAND is not null then ''0:2'' else ''0'' end,',
'--fk_city',
'case when nvl(:P373_FK_CITY,0) = nvl(:P373_FK_CITY_1,0) and :P373_FK_CITY is not null then ''1:2''',
'when nvl(:P373_FK_CITY,0) =  nvl(:P373_FK_CITY_1,0) and :P373_FK_CITY is null then ''1''',
'when :P373_FK_CITY is not null then ''0:2'' else ''0'' end,',
'--bel_datum',
'case when nvl(:P373_BEL_DATUM,0) = nvl(:P373_BEL_DATUM_1,0) and :P373_BEL_DATUM is not null then ''1:2''',
'when nvl(:P373_BEL_DATUM,0) =  nvl(:P373_BEL_DATUM_1,0) and :P373_BEL_DATUM is null then ''1''',
'when :P373_BEL_DATUM is not null then ''0:2'' else ''0'' end,',
'--von',
'case when nvl(:P373_VON,0) = nvl(:P373_VON_1,0) and :P373_VON is not null then ''1:2''',
'when nvl(:P373_VON,0) =  nvl(:P373_VON_1,0) and :P373_VON is null then ''1''',
'when :P373_VON is not null then ''0:2'' else ''0'' end,',
'--bis',
'case when nvl(:P373_BIS,0) = nvl(:P373_BIS_1,0)  and :P373_BIS is not null then ''1:2''',
'when nvl(:P373_BIS,0) =  nvl(:P373_BIS_1,0) and :P373_BIS is null then ''1''',
'when :P373_BIS is not null then ''0:2'' else ''0'' end,',
'--netto_betrag',
'case when nvl(:P373_NETTO_BETRAG,0) = nvl(:P373_NETTO_BETRAG_1,0)  and :P373_NETTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_NETTO_BETRAG,0) =  nvl(:P373_NETTO_BETRAG_1,0) and :P373_NETTO_BETRAG is null then ''1''',
'when :P373_NETTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_steuersatz',
'case when nvl(:P373_FK_STEUERSATZ,0) = nvl(:P373_FK_STEUERSATZ_1,0)  and :P373_FK_STEUERSATZ is not null then ''1:2''',
'when nvl(:P373_FK_STEUERSATZ,0) =  nvl(:P373_FK_STEUERSATZ_1,0) and :P373_FK_STEUERSATZ is null then ''1''',
'when :P373_FK_STEUERSATZ is not null then ''0:2''  else ''0'' end,',
'--mwst_betrag',
'case when nvl(:P373_MWST_BETRAG,0) = nvl(:P373_MWST_BETRAG_1,0)  and :P373_MWST_BETRAG is not null then ''1:2''',
'when nvl(:P373_MWST_BETRAG,0) =  nvl(:P373_MWST_BETRAG_1,0) and :P373_MWST_BETRAG is null then ''1''',
'when :P373_MWST_BETRAG is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag',
'case when nvl(:P373_BRUTTO_BETRAG,0) = nvl(:P373_BRUTTO_BETRAG_1,0) and :P373_BRUTTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG,0) =  nvl(:P373_BRUTTO_BETRAG_1,0) and :P373_BRUTTO_BETRAG is null then ''1''',
'when :P373_BRUTTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_waehrung',
'case when nvl(:P373_FK_WAEHRUNG,0) = nvl(:P373_FK_WAEHRUNG_1,0)  and :P373_FK_WAEHRUNG is not null then ''1:2''',
'when nvl(:P373_FK_WAEHRUNG,0) =  nvl(:P373_FK_WAEHRUNG_1,0) and :P373_FK_WAEHRUNG is null then ''1''',
'when :P373_FK_WAEHRUNG is not null then ''0:2'' else ''0'' end,',
'--steuernummer',
'case when nvl(:P373_STEUERNUMMER,0) = nvl(:P373_STEUERNUMMER_1,0)  and :P373_STEUERNUMMER is not null then ''1:2''',
'when nvl(:P373_STEUERNUMMER,0) =  nvl(:P373_STEUERNUMMER_1,0) and :P373_STEUERNUMMER is null then ''1''',
'when :P373_STEUERNUMMER is not null then ''0:2'' else ''0'' end,',
'--fk_umrechnungskurs',
'case when nvl(:P373_FK_UMRECHNUNGSKURS,0) = nvl(:P373_FK_UMRECHNUNGSKURS_1,0)  and :P373_FK_UMRECHNUNGSKURS is not null then ''1:2''',
'when nvl(:P373_FK_UMRECHNUNGSKURS,0) =  nvl(:P373_FK_UMRECHNUNGSKURS_1,0) and :P373_FK_UMRECHNUNGSKURS is null then ''1''',
'when :P373_FK_UMRECHNUNGSKURS is not null then ''0:2'' else ''0'' end,',
'--comm_rest_beleg',
'case when nvl(:P373_COMM_REST_BELEG,0) = nvl(:P373_COMM_REST_BELEG_1,0) and :P373_COMM_REST_BELEG is not null then ''1:2''',
'when nvl(:P373_COMM_REST_BELEG,0) =  nvl(:P373_COMM_REST_BELEG_1,0) and :P373_COMM_REST_BELEG is null then ''1''',
'when :P373_COMM_REST_BELEG is not null then ''0:2'' else ''0'' end,',
'--comm_tel_beleg',
'case when nvl(:P373_COMM_TEL_BELEG,0) = nvl(:P373_COMM_TEL_BELEG_1,0)  and :P373_COMM_TEL_BELEG is not null then ''1:2''',
'when nvl(:P373_COMM_TEL_BELEG,0) =  nvl(:P373_COMM_TEL_BELEG_1,0) and :P373_COMM_TEL_BELEG is null then ''1''',
'when :P373_COMM_TEL_BELEG is not null then ''0:2'' else ''0'' end,',
'--comm_produkte',
'case when nvl(:P373_COMM_PRODUKTE,0) = nvl(:P373_COMM_PRODUKTE_1,0)  and :P373_COMM_PRODUKTE is not null then ''1:2''',
'when nvl(:P373_COMM_PRODUKTE,0) =  nvl(:P373_COMM_PRODUKTE_1,0) and :P373_COMM_PRODUKTE is null then ''1''',
'when :P373_COMM_PRODUKTE is not null then ''0:2'' else ''0'' end,',
unistr('--comm_begr\00FCndung'),
'case when nvl(:P373_COMM_BEGRUENDUNG,0) = nvl(:P373_COMM_BEGRUENDUNG_1,0)  and :P373_COMM_BEGRUENDUNG is not null then ''1:2''',
'when nvl(:P373_COMM_BEGRUENDUNG,0) =  nvl(:P373_COMM_BEGRUENDUNG_1,0) and :P373_COMM_BEGRUENDUNG is null then ''1''',
'when :P373_COMM_BEGRUENDUNG is not null then ''0:2'' else ''0'' end,',
'--comm_sonstiges',
'case when nvl(:P373_COMM_SONSTIGES,0) = nvl(:P373_COMM_SONSTIGES_1,0)  and :P373_COMM_SONSTIGES is not null then ''1:2''',
'when nvl(:P373_COMM_SONSTIGES,0) =  nvl(:P373_COMM_SONSTIGES_1,0) and :P373_COMM_SONSTIGES is null then ''1''',
'when :P373_COMM_SONSTIGES is not null then ''0:2'' else ''0'' end,',
'--beleg',
'case when nvl(:P373_BELEG,0) = nvl(:P373_BELEG_1,0)  and :P373_BELEG is not null then ''1:2''',
'when nvl(:P373_BELEG,0) =  nvl(:P373_BELEG_1,0) and :P373_BELEG is null then ''1''',
'when :P373_BELEG is not null then ''0:2'' else ''0'' end,',
'--zahlungsbeleg',
'case when nvl(:P373_ZAHLUNGSBELEG,0) = nvl(:P373_ZAHLUNGSBELEG_1,0)  and :P373_ZAHLUNGSBELEG is not null then ''1:2''',
'when nvl(:P373_ZAHLUNGSBELEG,0) =  nvl(:P373_ZAHLUNGSBELEG_1,0) and :P373_ZAHLUNGSBELEG is null then ''1''',
'when :P373_ZAHLUNGSBELEG is not null then ''0:2'' else ''0'' end,',
'--liter',
'case when nvl(:P373_LITER,0) = nvl(:P373_LITER_1,0) and :P373_LITER is not null then ''1:2''',
'when nvl(:P373_LITER,0) =  nvl(:P373_LITER_1,0) and :P373_LITER is null then ''1''',
'when :P373_LITER is not null then ''0:2'' else ''0'' end,',
unistr('--zapfs\00F6ule'),
'case when nvl(:P373_ZAPFSAEULE,0) = nvl(:P373_ZAPFSAEULE_1,0)  and :P373_ZAPFSAEULE is not null then ''1:2''',
'when nvl(:P373_ZAPFSAEULE,0) =  nvl(:P373_ZAPFSAEULE_1,0) and :P373_ZAPFSAEULE is null then ''1''',
'when :P373_ZAPFSAEULE is not null then ''0:2'' else ''0'' end,',
'--fk-location',
'case when nvl(:P373_FK_LOCATION,0) = nvl(:P373_FK_LOCATION_1,0)  and :P373_FK_LOCATION is not null then ''1:2''',
'when nvl(:P373_FK_LOCATION,0) =  nvl(:P373_FK_LOCATION_1,0) and :P373_FK_LOCATION is null then ''1''',
'when :P373_FK_LOCATION is not null then ''0:2'' else ''0'' end,',
unistr('--pers\00F6nlich_vor_ort'),
'case when nvl(:P373_PERSOENLICH_VOR_ORT,0) = nvl(:P373_PERSOENLICH_VOR_ORT_1,0)  and :P373_PERSOENLICH_VOR_ORT is not null then ''1:2''',
'when nvl(:P373_PERSOENLICH_VOR_ORT,0) =  nvl(:P373_PERSOENLICH_VOR_ORT_1,0) and :P373_PERSOENLICH_VOR_ORT is null then ''1''',
'when :P373_PERSOENLICH_VOR_ORT is not null then ''0:2'' else ''0'' end,',
'--beleg_uhrzeit',
' case when nvl(:P373_BELEG_UHRZEIT,0) = nvl(:P373_BELEG_UHRZEIT_1,0)  and :P373_BELEG_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_BELEG_UHRZEIT,0) =  nvl(:P373_BELEG_UHRZEIT_1,0) and :P373_BELEG_UHRZEIT is null then ''1''',
'when :P373_BELEG_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--von_uhrzeit',
'case when nvl(:P373_VON_UHRZEIT,0) = nvl(:P373_VON_UHRZEIT_1,0)  and :P373_VON_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_VON_UHRZEIT,0) =  nvl(:P373_VON_UHRZEIT_1,0) and :P373_VON_UHRZEIT is null then ''1''',
'when :P373_VON_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--bis_uhrzeit',
'case when nvl(:P373_BIS_UHRZEIT,0) = nvl(:P373_BIS_UHRZEIT_1,0)  and :P373_BIS_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_BIS_UHRZEIT,0) =  nvl(:P373_BIS_UHRZEIT_1,0) and :P373_BIS_UHRZEIT is null then ''1''',
'when :P373_BIS_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--fk_von_arbeitstag',
'case when nvl(:P373_FK_VON_ARBEITSTAG,0) = nvl(:P373_FK_VON_ARBEITSTAG_1,0) and :P373_FK_VON_ARBEITSTAG is not null then ''1:2''',
'when nvl(:P373_FK_VON_ARBEITSTAG,0) =  nvl(:P373_FK_VON_ARBEITSTAG_1,0) and :P373_FK_VON_ARBEITSTAG is null then ''1''',
'when :P373_FK_VON_ARBEITSTAG is not null then ''0:2'' else ''0'' end,',
'--fk_bis_arbeitstag',
'case when nvl(:P373_FK_BIS_ARBEITSTAG,0) = nvl(:P373_FK_BIS_ARBEITSTAG_1,0) and :P373_FK_BIS_ARBEITSTAG is not null then ''1:2''',
'when nvl(:P373_FK_BIS_ARBEITSTAG,0) =  nvl(:P373_FK_BIS_ARBEITSTAG_1,0) and :P373_FK_BIS_ARBEITSTAG is null then ''1''',
'when :P373_FK_BIS_ARBEITSTAG is not null then ''0:2'' else ''0'' end,',
'--comm_addresse',
'case when nvl(:P373_COMM_ADRESSE,0) = nvl(:P373_COMM_ADRESSE_1,0)  and :P373_COMM_ADRESSE is not null then ''1:2''',
'when nvl(:P373_COMM_ADRESSE,0) =  nvl(:P373_COMM_ADRESSE_1,0) and :P373_COMM_ADRESSE is null then ''1''',
'when :P373_COMM_ADRESSE is not null then ''0:2'' else ''0'' end,',
'--tankstelllen_nr',
'case when nvl(:P373_TANKSTELLEN_NR,0) = nvl(:P373_TANKSTELLEN_NR_1,0)  and :P373_TANKSTELLEN_NR is not null then ''1:2''',
'when nvl(:P373_TANKSTELLEN_NR,0) =  nvl(:P373_TANKSTELLEN_NR_1,0) and :P373_TANKSTELLEN_NR is null then ''1''',
'when :P373_TANKSTELLEN_NR is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag_incl_trinkg',
'case when nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG,0) = nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG_1,0) and :P373_BRUTTO_BETRAG_INCL_TRINKG is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG,0) =  nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG_1,0) and :P373_BRUTTO_BETRAG_INCL_TRINKG is null then ''1''',
'when :P373_BRUTTO_BETRAG_INCL_TRINKG is not null then ''0:2'' else ''0'' end,',
'--comm_parkticket',
'case when nvl(:P373_COMM_PARKTICKET,0) = nvl(:P373_COMM_PARKTICKET_1,0)  and :P373_COMM_PARKTICKET is not null then ''1:2''',
'when nvl(:P373_COMM_PARKTICKET,0) =  nvl(:P373_COMM_PARKTICKET_1,0) and :P373_COMM_PARKTICKET is null then ''1''',
'when :P373_COMM_PARKTICKET is not null then ''0:2'' else ''0'' end,',
'--frmdw_netto_betrag',
'case when nvl(:P373_FRMDW_NETTO_BETRAG,0) = nvl(:P373_FRMDW_NETTO_BETRAG_1,0)  and :P373_FRMDW_NETTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_NETTO_BETRAG,0) =  nvl(:P373_FRMDW_NETTO_BETRAG_1,0) and :P373_FRMDW_NETTO_BETRAG is null then ''1''',
'when :P373_FRMDW_NETTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_frmdw',
'case when nvl(:P373_FK_FRMDW,0) = nvl(:P373_FK_FRMDW_1,0)  and :P373_FK_FRMDW is not null then ''1:2''',
'when nvl(:P373_FK_FRMDW,0) =  nvl(:P373_FK_FRMDW_1,0) and :P373_FK_FRMDW is null then ''1''',
'when :P373_FK_FRMDW is not null then ''0:2'' else ''0'' end,',
'---fk_frmdw_mwst_satz',
'case when nvl(:P373_FK_FRMDW_MWST_SATZ,0) = nvl(:P373_FK_FRMDW_MWST_SATZ_1,0)  and :P373_FK_FRMDW_MWST_SATZ is not null then ''1:2''',
'when nvl(:P373_FK_FRMDW_MWST_SATZ,0) =  nvl(:P373_FK_FRMDW_MWST_SATZ_1,0) and :P373_FK_FRMDW_MWST_SATZ is null then ''1''',
'when :P373_FK_FRMDW_MWST_SATZ is not null then ''0:2'' else ''0'' end,',
'--frmdw_mwst_betrag',
'case when nvl(:P373_FRMDW_MWST_BETRAG,0) = nvl(:P373_FRMDW_MWST_BETRAG_1,0)  and :P373_FRMDW_MWST_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_MWST_BETRAG,0) =  nvl(:P373_FRMDW_MWST_BETRAG_1,0) and :P373_FRMDW_MWST_BETRAG is null then ''1''',
'when :P373_FRMDW_MWST_BETRAG is not null then ''0:2'' else ''0'' end,',
'--frmdw_brutto_betrag',
'case when nvl(:P373_FRMDW_BRUTTO_BETRAG,0) = nvl(:P373_FRMDW_BRUTTO_BETRAG_1,0)   and :P373_FRMDW_BRUTTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_BRUTTO_BETRAG,0) =  nvl(:P373_FRMDW_BRUTTO_BETRAG_1,0) and :P373_FRMDW_BRUTTO_BETRAG is null then ''1''',
'when :P373_FRMDW_BRUTTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--frmdw_brutto_inkl_trinkg',
'case when nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG,0) = nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG_1,0)   and :P373_FRMDW_BRUTTO_INCL_TRINKG is not null then ''1:2''',
'when nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG,0) =  nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG_1,0) and :P373_FRMDW_BRUTTO_INCL_TRINKG is null then ''1''',
'when :P373_FRMDW_BRUTTO_INCL_TRINKG is not null then ''0:2'' else ''0'' end,',
'--mwst_betrag_eur',
'case when nvl(:P373_MWST_BETRAG_EUR,0) = nvl(:P373_MWST_BETRAG_EUR_1,0)  and :P373_MWST_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_MWST_BETRAG_EUR,0) =  nvl(:P373_MWST_BETRAG_EUR_1,0) and :P373_MWST_BETRAG_EUR is null then ''1''',
'when :P373_MWST_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag_eur',
'case when nvl(:P373_BRUTTO_BETRAG_EUR,0) = nvl(:P373_BRUTTO_BETRAG_EUR_1,0)   and :P373_BRUTTO_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG_EUR,0) =  nvl(:P373_BRUTTO_BETRAG_EUR_1,0) and :P373_BRUTTO_BETRAG_EUR is null then ''1''',
'when :P373_BRUTTO_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'---brutto_inkl_trink_eur',
'case when nvl(:P373_BRUTTO_INCL_TRINKG_EUR,0) = nvl(:P373_BRUTTO_INCL_TRINKG_EUR_1,0)   and :P373_BRUTTO_INCL_TRINKG_EUR is not null then ''1:2''',
'when nvl(:P373_BRUTTO_INCL_TRINKG_EUR,0) =  nvl(:P373_BRUTTO_INCL_TRINKG_EUR_1,0) and :P373_BRUTTO_INCL_TRINKG_EUR is null then ''1''',
'when :P373_BRUTTO_INCL_TRINKG_EUR is not null then ''0:2'' else ''0'' end,',
'--netto_betrag_eur',
'case when nvl(:P373_NETTO_BETRAG_EUR,0) = nvl(:P373_NETTO_BETRAG_EUR_1,0)   and :P373_NETTO_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_NETTO_BETRAG_EUR,0) =  nvl(:P373_NETTO_BETRAG_EUR_1,0) and :P373_NETTO_BETRAG_EUR is null then ''1''',
'when :P373_NETTO_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'--preis_pro_menge',
'case when nvl(:P373_PREIS_PRO_MENGE,0) = nvl(:P373_PREIS_PRO_MENGE_1,0)  and :P373_PREIS_PRO_MENGE is not null then ''1:2''',
'when nvl(:P373_PREIS_PRO_MENGE,0) =  nvl(:P373_PREIS_PRO_MENGE_1,0) and :P373_PREIS_PRO_MENGE is null then ''1''',
'when :P373_PREIS_PRO_MENGE is not null then ''0:2'' else ''0'' end,',
'--mengeneinheit',
'case when nvl(:P373_MENGENEINHEIT,0) = nvl(:P373_MENGENEINHEIT_1,0)   and :P373_MENGENEINHEIT is not null then ''1:2''',
'when nvl(:P373_MENGENEINHEIT,0) =  nvl(:P373_MENGENEINHEIT_1,0) and :P373_MENGENEINHEIT is null then ''1''',
'when :P373_MENGENEINHEIT is not null then ''0:2'' else ''0'' end,',
'--la_datum',
'case when nvl(:P373_LA_DATUM,0) = nvl(:P373_LA_DATUM_1,0)   and :P373_LA_DATUM is not null then ''1:2''',
'when nvl(:P373_LA_DATUM,0) =  nvl(:P373_LA_DATUM_1,0) and :P373_LA_DATUM is null then ''1''',
'when :P373_LA_DATUM is not null then ''0:2'' else ''0'' end,',
'--fk_la_konto',
'case when nvl(:P373_FK_LA_KONTO,0) = nvl(:P373_FK_LA_KONTO_1,0)  and :P373_FK_LA_KONTO is not null then ''1:2''',
'when nvl(:P373_FK_LA_KONTO,0) =  nvl(:P373_FK_LA_KONTO_1,0) and :P373_FK_LA_KONTO is null then ''1''',
'when :P373_FK_LA_KONTO is not null then ''0:2'' else ''0'' end,',
'--fk_la_wdh',
'case when nvl(:P373_FK_LA_WDH,0) = nvl(:P373_FK_LA_WDH_1,0)   and :P373_FK_LA_WDH is not null then ''1:2''',
'when nvl(:P373_FK_LA_WDH,0) =  nvl(:P373_FK_LA_WDH_1,0) and :P373_FK_LA_WDH is null then ''1''',
'when :P373_FK_LA_WDH is not null then ''0:2'' else ''0'' end,',
'--fk_zahlstatus',
'case when nvl(:P373_FK_ZAHLSTATUS,0) = nvl(:P373_FK_ZAHLSTATUS_1,0)  and :P373_FK_ZAHLSTATUS is not null then ''1:2''',
'when nvl(:P373_FK_ZAHLSTATUS,0) =  nvl(:P373_FK_ZAHLSTATUS_1,0) and :P373_FK_ZAHLSTATUS is null then ''1''',
'when :P373_FK_ZAHLSTATUS is not null then ''0:2'' else ''0'' end,',
'--comm_vergehen',
'case when nvl(:P373_COMM_VERGEHEN,0) = nvl(:P373_COMM_VERGEHEN_1,0)   and :P373_COMM_VERGEHEN is not null then ''1:2''',
'when nvl(:P373_COMM_VERGEHEN,0) =  nvl(:P373_COMM_VERGEHEN_1,0) and :P373_COMM_VERGEHEN is null then ''1''',
'when :P373_COMM_VERGEHEN is not null then ''0:2'' else ''0'' end,',
unistr('--verg_beh\00F6rden'),
'case when nvl(:P373_VERG_BEHOERDE,0) = nvl(:P373_VERG_BEHOERDE_1,0)   and :P373_VERG_BEHOERDE is not null then ''1:2''',
'when nvl(:P373_VERG_BEHOERDE,0) =  nvl(:P373_VERG_BEHOERDE_1,0) and :P373_VERG_BEHOERDE is null then ''1''',
'when :P373_VERG_BEHOERDE is not null then ''0:2'' else ''0'' end,',
'--cnt_punkte',
'case when nvl(:P373_CNT_PUNKTE,0) = nvl(:P373_CNT_PUNKTE_1,0)   and :P373_CNT_PUNKTE is not null then ''1:2''',
'when nvl(:P373_CNT_PUNKTE,0) =  nvl(:P373_CNT_PUNKTE_1,0) and :P373_CNT_PUNKTE is null then ''1''',
'when :P373_CNT_PUNKTE is not null then ''0:2'' else ''0'' end,',
'--fk_belege_ablage',
'case when nvl(:P373_FK_BELEG_ABLAGE,0) = nvl(:P373_FK_BELEG_ABLAGE_1,0)   and :P373_FK_BELEG_ABLAGE is not null then ''1:2''',
'when nvl(:P373_FK_BELEG_ABLAGE,0) =  nvl(:P373_FK_BELEG_ABLAGE_1,0) and :P373_FK_BELEG_ABLAGE is null then ''1''',
'when :P373_FK_BELEG_ABLAGE is not null then ''0:2'' else ''0'' end,',
'--fk_abl_ordner_page',
'case when nvl(:P373_FK_ABL_ORDNER_PAGE,0) = nvl(:P373_FK_ABL_ORDNER_PAGE_1,0)   and :P373_FK_ABL_ORDNER_PAGE is not null then ''1:2''',
'when nvl(:P373_FK_ABL_ORDNER_PAGE,0) =  nvl(:P373_FK_ABL_ORDNER_PAGE_1,0) and :P373_FK_ABL_ORDNER_PAGE is null then ''1''',
'when :P373_FK_ABL_ORDNER_PAGE is not null then ''0:2'' else ''0'' end,',
'--cnt_punkte_gescchaetzt',
'case when nvl(:P373_CNT_PUNKTE_GESCHAETZT,0) = nvl(:P373_CNT_PUNKTE_GESCHAETZT_1,0)   and :P373_CNT_PUNKTE_GESCHAETZT is not null then ''1:2''',
'when nvl(:P373_CNT_PUNKTE_GESCHAETZT,0) =  nvl(:P373_CNT_PUNKTE_GESCHAETZT_1,0) and :P373_CNT_PUNKTE_GESCHAETZT is null then ''1''',
'when :P373_CNT_PUNKTE_GESCHAETZT is not null then ''0:2'' else ''0'' end,',
'--punkte_von',
'case when nvl(:P373_PUNKTE_VON,0) = nvl(:P373_PUNKTE_VON_1,0)   and :P373_PUNKTE_VON is not null then ''1:2''',
'when nvl(:P373_PUNKTE_VON,0) =  nvl(:P373_PUNKTE_VON_1,0) and :P373_PUNKTE_VON is null then ''1''',
'when :P373_PUNKTE_VON is not null then ''0:2'' else ''0'' end,',
'--punkte_bis',
'case when nvl(:P373_PUNKTE_BIS,0) = nvl(:P373_PUNKTE_BIS_1,0)   and :P373_PUNKTE_BIS is not null then ''1:2''',
'when nvl(:P373_PUNKTE_BIS,0) =  nvl(:P373_PUNKTE_BIS_1,0) and :P373_PUNKTE_BIS is null then ''1''',
'when :P373_PUNKTE_BIS is not null then ''0:2'' else ''0'' end,',
'--fk_location_verg',
'case when nvl(:P373_FK_LOCATION_VERG,0) = nvl(:P373_FK_LOCATION_VERG_1,0)   and :P373_FK_LOCATION_VERG is not null then ''1:2''',
'when nvl(:P373_FK_LOCATION_VERG,0) =  nvl(:P373_FK_LOCATION_VERG_1,0) and :P373_FK_LOCATION_VERG is null then ''1''',
'when :P373_FK_LOCATION_VERG is not null then ''0:2'' else ''0'' end,',
'--fk_inp_bel_old',
'case when nvl(:P373_FK_IMP_BA_BEL_OLD,0) = nvl(:P373_FK_IMP_BA_BEL_OLD_1,0)   and :P373_FK_IMP_BA_BEL_OLD is not null then ''1:2''',
'when nvl(:P373_FK_IMP_BA_BEL_OLD,0) =  nvl(:P373_FK_IMP_BA_BEL_OLD_1,0) and :P373_FK_IMP_BA_BEL_OLD is null then ''1''',
'when :P373_FK_IMP_BA_BEL_OLD is not null then ''0:2'' else ''0'' end,',
'--geschw_ist',
'case when nvl(:P373_GESCHW_IST,0) = nvl(:P373_GESCHW_IST_1,0)   and :P373_GESCHW_IST is not null then ''1:2''',
'when nvl(:P373_GESCHW_IST,0) =  nvl(:P373_GESCHW_IST_1,0) and :P373_GESCHW_IST is null then ''1''',
'when :P373_GESCHW_IST is not null then ''0:2'' else ''0'' end,',
'--geschw_soll',
'case when nvl(:P373_GESCHW_SOLL,0) = nvl(:P373_GESCHW_SOLL_1,0)  and :P373_GESCHW_SOLL is not null then ''1:2''',
'when nvl(:P373_GESCHW_SOLL,0) =  nvl(:P373_GESCHW_SOLL_1,0) and :P373_GESCHW_SOLL is null then ''1''',
'when :P373_GESCHW_SOLL is not null then ''0:2'' else ''0'' end,',
'--geschw_ueber_grz',
'case when nvl(:P373_GESCHW_UEBER_GRZ,0) = nvl(:P373_GESCHW_UEBER_GRZ_1,0)   and :P373_GESCHW_UEBER_GRZ is not null then ''1:2''',
'when nvl(:P373_GESCHW_UEBER_GRZ,0) =  nvl(:P373_GESCHW_UEBER_GRZ_1,0) and :P373_GESCHW_UEBER_GRZ is null then ''1''',
'when :P373_GESCHW_UEBER_GRZ is not null then ''0:2'' else ''0'' end,',
'--geschw_ueber_grz_abzgl_messstol',
'case when nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,0) = nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,0)   and :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is not null then ''1:2''',
'when nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,0) =  nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,0) and :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is null then ''1''',
'when :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is not null then ''0:2'' else ''0'' end,',
'--code-bussgeld',
'case when nvl(:P373_CODE_BUSSGELD,0) = nvl(:P373_CODE_BUSSGELD_1,0)   and :P373_CODE_BUSSGELD is not null then ''1:2''',
'when nvl(:P373_CODE_BUSSGELD,0) =  nvl(:P373_CODE_BUSSGELD_1,0) and :P373_CODE_BUSSGELD is null then ''1''',
'when :P373_CODE_BUSSGELD is not null then ''0:2'' else ''0'' end,',
'---descr_bussgeld',
'case when nvl(:P373_DESCR_BUSSGELD,0) = nvl(:P373_DESCR_BUSSGELD_1,0)  and :P373_DESCR_BUSSGELD is not null then ''1:2''',
'when nvl(:P373_DESCR_BUSSGELD,0) =  nvl(:P373_DESCR_BUSSGELD_1,0) and :P373_DESCR_BUSSGELD is null then ''1''',
'when :P373_DESCR_BUSSGELD is not null then ''0:2'' else ''0'' end,',
'--gezahlt_am',
'case when nvl(:P373_GEZAHLT_AM,0) = nvl(:P373_GEZAHLT_AM_1,0)   and :P373_GEZAHLT_AM is not null then ''1:2''',
'when nvl(:P373_GEZAHLT_AM,0) =  nvl(:P373_GEZAHLT_AM_1,0) and :P373_GEZAHLT_AM is null then ''1''',
'when :P373_GEZAHLT_AM is not null then ''0:2'' else ''0'' end,',
'--webseite',
'case when nvl(:P373_WEBSEITE,0) = nvl(:P373_WEBSEITE_1,0)   and :P373_WEBSEITE is not null then ''1:2''',
'when nvl(:P373_WEBSEITE,0) =  nvl(:P373_WEBSEITE_1,0) and :P373_WEBSEITE is null then ''1''',
'when :P373_WEBSEITE is not null then ''0:2'' else ''0'' end,',
'--kundennummer',
'case when nvl(:P373_KUNDENNUMMER,0) = nvl(:P373_KUNDENNUMMER_1,0)   and :P373_KUNDENNUMMER is not null then ''1:2''',
'when nvl(:P373_KUNDENNUMMER,0) =  nvl(:P373_KUNDENNUMMER_1,0) and :P373_KUNDENNUMMER is null then ''1''',
'when :P373_KUNDENNUMMER is not null then ''0:2'' else ''0'' end,',
'--fk_real_beleg_exist',
'case when nvl(:P373_FK_REAL_BELEG_EXIST,0) = nvl(:P373_FK_REAL_BELEG_EXIST_1,0)   and :P373_FK_REAL_BELEG_EXIST is not null then ''1:2''',
'when nvl(:P373_FK_REAL_BELEG_EXIST,0) =  nvl(:P373_FK_REAL_BELEG_EXIST_1,0) and :P373_FK_REAL_BELEG_EXIST is null then ''1''',
'when :P373_FK_REAL_BELEG_EXIST is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state',
'case when nvl(:P373_FK_CALC_STATE,0) = nvl(:P373_FK_CALC_STATE_1,0)   and :P373_FK_CALC_STATE is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE,0) =  nvl(:P373_FK_CALC_STATE_1,0) and :P373_FK_CALC_STATE is null then ''1''',
'when :P373_FK_CALC_STATE is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state_eur',
'case when nvl(:P373_FK_CALC_STATE_EUR,0) = nvl(:P373_FK_CALC_STATE_EUR_1,0)   and :P373_FK_CALC_STATE_EUR is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE_EUR,0) =  nvl(:P373_FK_CALC_STATE_EUR_1,0) and :P373_FK_CALC_STATE_EUR is null then ''1''',
'when :P373_FK_CALC_STATE_EUR is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state_frmdw',
'case when nvl(:P373_FK_CALC_STATE_FRMDW,0) = nvl(:P373_FK_CALC_STATE_FRMDW_1,0)   and :P373_FK_CALC_STATE_FRMDW is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE_FRMDW,0) =  nvl(:P373_FK_CALC_STATE_FRMDW_1,0) and :P373_FK_CALC_STATE_FRMDW is null then ''1''',
'when :P373_FK_CALC_STATE_FRMDW is not null then ''0:2'' ',
'else ''0'' end,',
'--fk_status',
'case when nvl(:P373_FK_STATUS,0) = nvl(:P373_FK_STATUS_1,0)   and :P373_FK_STATUS is not null then ''1:2''',
'when nvl(:P373_FK_STATUS,0) =  nvl(:P373_FK_STATUS_1,0) and :P373_FK_STATUS is null then ''1''',
'when :P373_FK_STATUS is not null then ''0:2'' else ''0'' end,',
'---datum_vergehen',
'case when nvl(:P373_DATUM_VERGEHEN,0) = nvl(:P373_DATUM_VERGEHEN_1,0)   and :P373_DATUM_VERGEHEN is not null then ''1:2''',
'when nvl(:P373_DATUM_VERGEHEN,0) =  nvl(:P373_DATUM_VERGEHEN_1,0) and :P373_DATUM_VERGEHEN is null then ''1''',
'when :P373_DATUM_VERGEHEN is not null then ''0:2'' else ''0'' end,',
'--create_at',
'case when nvl(:P373_CREATE_AT,0) = nvl(:P373_CREATE_AT_1,0)   and :P373_CREATE_AT is not null then ''1:2''',
'when nvl(:P373_CREATE_AT,0) =  nvl(:P373_CREATE_AT_1,0) and :P373_CREATE_AT is null then ''1''',
'when :P373_CREATE_AT is not null then ''0:2'' else ''0'' end,',
'--create_by',
'case when nvl(:P373_CREATE_BY,0) = nvl(:P373_CREATE_BY_1,0)   and :P373_CREATE_BY is not null then ''1:2''',
'when nvl(:P373_CREATE_BY,0) =  nvl(:P373_CREATE_BY_1,0) and :P373_CREATE_BY is null then ''1''',
'when :P373_CREATE_BY is not null then ''0:2'' else ''0'' end,',
'--modify_at',
'case when nvl(:P373_MODIFY_AT,0) = nvl(:P373_MODIFY_AT_1,0)   and :P373_MODIFY_AT is not null then ''1:2''',
'when nvl(:P373_MODIFY_AT,0) =  nvl(:P373_MODIFY_AT_1,0) and :P373_MODIFY_AT is null then ''1''',
'when :P373_MODIFY_AT is not null then ''0:2'' else ''0'' end,',
'--modify_by',
'case when nvl(:P373_MODIFY_BY,0) = nvl(:P373_MODIFY_BY_1,0)   and :P373_MODIFY_BY is not null then ''1:2''',
'when nvl(:P373_MODIFY_BY,0) =  nvl(:P373_MODIFY_BY_1,0) and :P373_MODIFY_BY is null then ''1''',
'when :P373_MODIFY_BY is not null then ''0:2'' else ''0'' end,',
'--datum_ort_ok',
'case when nvl(:P373_DATUM_ORT_OK,0) = nvl(:P373_DATUM_ORT_OK_1,0)  and :P373_DATUM_ORT_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_ORT_OK,0) =  nvl(:P373_DATUM_ORT_OK_1,0) and :P373_DATUM_ORT_OK is null then ''1''',
'when :P373_DATUM_ORT_OK is not null then ''0:2'' else ''0'' end,',
'--datum_addresse_ok',
'case when nvl(:P373_DATUM_ADDRESSE_OK,''01.01.1900'') = nvl(:P373_DATUM_ADDRESSE_OK_1,''01.01.1900'')   and :P373_DATUM_ADDRESSE_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_ADDRESSE_OK,0) =  nvl(:P373_DATUM_ADDRESSE_OK_1,0) and :P373_DATUM_ADDRESSE_OK is null then ''1''',
'when :P373_DATUM_ADDRESSE_OK is not null then ''0:2'' else ''0'' end,',
'--datum_bussgeld_ok',
'case when nvl(:P373_DATUM_BUSSGELD_OK,''01.01.1900'') = nvl(:P373_DATUM_BUSSGELD_OK_1,''01.01.1900'')   and :P373_DATUM_BUSSGELD_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BUSSGELD_OK,0) =  nvl(:P373_DATUM_BUSSGELD_OK_1,0) and :P373_DATUM_BUSSGELD_OK is null then ''1''',
'when :P373_DATUM_BUSSGELD_OK is not null then ''0:2'' else ''0'' end,',
'--datum_beleg_pos_ok',
'case when nvl(:P373_DATUM_BELEG_POS_OK,''01.01.1900'') = nvl(:P373_DATUM_BELEG_POS_OK_1,''01.01.1900'')   and :P373_DATUM_BELEG_POS_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BELEG_POS_OK,0) =  nvl(:P373_DATUM_BELEG_POS_OK_1,0) and :P373_DATUM_BELEG_POS_OK is null then ''1''',
'when :P373_DATUM_BELEG_POS_OK is not null then ''0:2'' else ''0'' end,',
'--datum_buchung_ok',
'case when nvl(:P373_DATUM_BUCHUNG_OK,''01.01.1900'') = nvl(:P373_DATUM_BUCHUNG_OK_1,''01.01.1900'')   and :P373_DATUM_BUCHUNG_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BUCHUNG_OK,0) =  nvl(:P373_DATUM_BUCHUNG_OK_1,0) and :P373_DATUM_BUCHUNG_OK is null then ''1''',
'when :P373_DATUM_BUCHUNG_OK is not null then ''0:2'' else ''0'' end,',
'--datum_verpfl_bel_ok',
'case when nvl(:P373_DATUM_VERPFL_BEL_OK,''01.01.1900'') = nvl(:P373_DATUM_VERPFL_BEL_OK_1,''01.01.1900'')   and :P373_DATUM_VERPFL_BEL_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_VERPFL_BEL_OK,0) =  nvl(:P373_DATUM_VERPFL_BEL_OK_1,0) and :P373_DATUM_VERPFL_BEL_OK is null then ''1''',
'when :P373_DATUM_VERPFL_BEL_OK is not null then ''0:2'' else ''0'' end,',
'--fk_internet_app',
'case when nvl(:P373_FK_INTERNET_APP,0) = nvl(:P373_FK_INTERNET_APP_1,0)   and :P373_FK_INTERNET_APP is not null then ''1:2''',
'when nvl(:P373_FK_INTERNET_APP,0) =  nvl(:P373_FK_INTERNET_APP_1,0) and :P373_FK_INTERNET_APP is null then ''1''',
'when :P373_FK_INTERNET_APP is not null then ''0:2'' else ''0'' end,',
'--fk_dupl_status',
'case when nvl(:P373_FK_DUPL_STATUS,0) = nvl(:P373_FK_DUPL_STATUS_1,0)   and :P373_FK_DUPL_STATUS is not null then ''1:2''',
'when nvl(:P373_FK_DUPL_STATUS,0) =  nvl(:P373_FK_DUPL_STATUS_1,0) and :P373_FK_DUPL_STATUS is null then ''1''',
'when :P373_FK_DUPL_STATUS is not null then ''0:2'' else ''0'' end,',
'--datum_dupl_ok',
'case when nvl(:P373_DATUM_DUPL_OK,''01.01.1900'') = nvl(:P373_DATUM_DUPL_OK_1,''01.01.1900'')   and :P373_DATUM_DUPL_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_DUPL_OK,0) =  nvl(:P373_DATUM_DUPL_OK_1,0) and :P373_DATUM_DUPL_OK is null then ''1''',
'when :P373_DATUM_DUPL_OK is not null then ''0:2'' else ''0'' end,',
'--dupl_buchung',
'case when nvl(:P373_DUPL_BEMERKUNG,0) = nvl(:P373_DUPL_BEMERKUNG_1,0)   and :P373_DUPL_BEMERKUNG is not null then ''1:2''',
'when nvl(:P373_DUPL_BEMERKUNG,0) =  nvl(:P373_DUPL_BEMERKUNG_1,0) and :P373_DUPL_BEMERKUNG is null then ''1''',
'when :P373_DUPL_BEMERKUNG is not null then ''0:2'' else ''0'' end,',
'--fk_gechaeftspartner',
'case when nvl(:P373_FK_GESCHAEFTSPARTNER,0) = nvl(:P373_FK_GESCHAEFTSPARTNER_1,0)   and :P373_FK_GESCHAEFTSPARTNER is not null then ''1:2''',
'when nvl(:P373_FK_GESCHAEFTSPARTNER,0) =  nvl(:P373_FK_GESCHAEFTSPARTNER_1,0) and :P373_FK_GESCHAEFTSPARTNER is null then ''1''',
'when :P373_FK_GESCHAEFTSPARTNER is not null then ''0:2'' else ''0'' end              ',
'Into',
':P373_FK_LEX_BUCHUNG_FLG,',
':P373_FK_KATEGORIE_FLG,             ',
':P373_FK_ARBEITSTAG_FLG,',
':P373_FK_BUCHUNG_FLG,',
':P373_FK_ZAHLUNGSART_FLG,                ',
':P373_FK_VERWENDUNGSZWECK_flg,',
' :P373_FK_INVENTAR_FLG,',
':P373_FK_PROJEKT_FLG,',
':P373_BELEGNUMMER_FLG,',
':P373_BEZEICHNUNG_FLG,',
':P373_FK_LAND_FLG,',
':P373_FK_CITY_FLG,',
':P373_BEL_DATUM_FLG,',
':P373_VON_FLG,',
':P373_BIS_FLG,',
':P373_NETTO_BETRAG_FLG,',
':P373_FK_STEUERSATZ_FLG,',
':P373_MWST_BETRAG_FLG,',
':P373_BRUTTO_BETRAG_FLG,',
':P373_FK_WAEHRUNG_FLG,',
':P373_STEUERNUMMER_FLG,',
':P373_FK_UMRECHNUNGSKURS_FLG,',
':P373_COMM_REST_BELEG_FLG,',
':P373_COMM_TEL_BELEG_FLG,',
':P373_COMM_PRODUKTE_FLG,',
':P373_COMM_BEGRUENDUNG_FLG,',
':P373_COMM_SONSTIGES_FLG,',
':P373_BELEG_FLG,',
':P373_ZAHLUNGSBELEG_FLG,',
':P373_LITER_FLG,',
':P373_ZAPFSAEULE_FLG,',
':P373_FK_LOCATION_FLG,',
':P373_PERSOENLICH_VOR_ORT_FLG,',
':P373_BELEG_UHRZEIT_FLG,',
':P373_VON_UHRZEIT_FLG,',
':P373_BIS_UHRZEIT_FLG,',
':P373_FK_VON_ARBEITSTAG_FLG,',
':P373_FK_BIS_ARBEITSTAG_FLG,',
':P373_COMM_ADRESSE_FLG,',
':P373_TANKSTELLEN_NR_FLG,',
':P373_BRUTTO_BETRAG_INCL_TRINKG_FLG,',
':P373_COMM_PARKTICKET_FLG,',
':P373_FRMDW_NETTO_BETRAG_FLG,',
':P373_FK_FRMDW_FLG,',
':P373_FK_FRMDW_MWST_SATZ_FLG,',
':P373_FRMDW_MWST_BETRAG_FLG,',
':P373_FRMDW_BRUTTO_BETRAG_FLG,',
':P373_FRMDW_BRUTTO_INCL_TRINKG_FLG,',
':P373_MWST_BETRAG_EUR_FLG,',
':P373_BRUTTO_BETRAG_EUR_FLG,',
':P373_BRUTTO_INCL_TRINKG_EUR_FLG,',
':P373_NETTO_BETRAG_EUR_FLG,',
':P373_PREIS_PRO_MENGE_FLG,',
':P373_MENGENEINHEIT_FLG,',
':P373_LA_DATUM_FLG,',
':P373_FK_LA_KONTO_FLG,',
':P373_FK_LA_WDH_FLG,',
':P373_FK_ZAHLSTATUS_FLG,',
':P373_COMM_VERGEHEN_FLG,',
':P373_VERG_BEHOERDE_FLG,',
':P373_CNT_PUNKTE_FLG,',
':P373_FK_BELEG_ABLAGE_FLG,',
':P373_FK_ABL_ORDNER_PAGE_FLG,',
':P373_CNT_PUNKTE_GESCHAETZT_FLG,',
':P373_PUNKTE_VON_FLG,',
':P373_PUNKTE_BIS_FLG,',
':P373_FK_LOCATION_VERG_FLG,',
':P373_FK_IMP_BA_BEL_OLD_FLG,',
':P373_GESCHW_IST_FLG,',
':P373_GESCHW_SOLL_FLG,',
':P373_GESCHW_UEBER_GRZ_FLG,',
':P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_FLG,',
':P373_CODE_BUSSGELD_FLG,',
':P373_DESCR_BUSSGELD_FLG,',
':P373_GEZAHLT_AM_FLG,',
':P373_WEBSEITE_FLG,',
':P373_KUNDENNUMMER_FLG,',
':P373_FK_REAL_BELEG_EXIST_FLG,',
':P373_FK_CALC_STATE_FLG,',
':P373_FK_CALC_STATE_EUR_FLG,',
':P373_FK_CALC_STATE_FRMDW_FLG,',
':P373_FK_STATUS_FLG,',
':P373_DATUM_VERGEHEN_FLG,',
':P373_CREATE_AT_FLG,',
':P373_CREATE_BY_FLG,',
':P373_MODIFY_AT_FLG,',
':P373_MODIFY_BY_FLG,',
':P373_DATUM_ORT_OK_FLG,',
':P373_DATUM_ADDRESSE_OK_FLG,',
':P373_DATUM_BUSSGELD_OK_FLG,',
':P373_DATUM_BELEG_POS_OK_FLG,',
':P373_DATUM_BUCHUNG_OK_FLG,',
':P373_DATUM_VERPFL_BEL_OK_FLG,',
':P373_FK_INTERNET_APP_FLG,',
':P373_FK_DUPL_STATUS_FLG,',
':P373_DATUM_DUPL_OK_FLG,',
':P373_DUPL_BEMERKUNG_FLG,',
':P373_FK_GESCHAEFTSPARTNER_FLG               ',
'from dual;',
'end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
null;
wwv_flow_api.component_end;
end;
/
