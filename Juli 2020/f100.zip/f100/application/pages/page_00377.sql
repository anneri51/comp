prompt --application/pages/page_00377
begin
--   Manifest
--     PAGE: 00377
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>377
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'dupl_lex_buch'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'dupl_lex_buch'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44341901507941496)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090908'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19722568906686623)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19880840468713003)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19927130359493201)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_duplikat_check_kontrolle'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19927246301493202)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19927246301493202
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19929379985493223)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19929789394493227)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19931005972493240)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>380
,p_column_identifier=>'C'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936208407493242)
,p_db_column_name=>'PK_DUPLIKAT_CHECK_KONTROLLE'
,p_display_order=>390
,p_column_identifier=>'D'
,p_column_label=>'Pk Duplikat Check Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936324952493243)
,p_db_column_name=>'FK_DUPLKAT_TYPE'
,p_display_order=>400
,p_column_identifier=>'E'
,p_column_label=>'Fk Duplkat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936482461493244)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>410
,p_column_identifier=>'F'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936518242493245)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>420
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936646211493246)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>430
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936719978493247)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>440
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936822478493248)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>450
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19936902163493249)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>460
,p_column_identifier=>'K'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19937074249493250)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>470
,p_column_identifier=>'L'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19956469067505117)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'199565'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:FK_STEUER_MONAT:PK_DUPLIKAT_CHECK_KONTROLLE:FK_DUPLKAT_TYPE:FK_DUPLIKAT_CHECK_STATUS:DATUM_OK:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:'
,p_sort_column_1=>'FK_DUPLKAT_TYPE'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR:FK_STEUER_MONAT'
,p_break_enabled_on=>'JAHR:FK_STEUER_MONAT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19962005032564118)
,p_report_id=>wwv_flow_api.id(19956469067505117)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19962492442564120)
,p_report_id=>wwv_flow_api.id(19956469067505117)
,p_name=>'all'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'='
,p_expr=>'999'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19962891274564120)
,p_report_id=>wwv_flow_api.id(19956469067505117)
,p_name=>'inp_bel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'in'
,p_expr=>'1,2'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1, 2  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19963297275564120)
,p_report_id=>wwv_flow_api.id(19956469067505117)
,p_name=>'t_lex'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19963633775564121)
,p_report_id=>wwv_flow_api.id(19956469067505117)
,p_name=>'inp_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19937198181497901)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dpc.*, dp.FK_RELATION1_LEX, ll.betrag',
'from t_duplikat_check dpc',
' left join t_duplikat dp on  dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join t_lex_long ll on ll.relation  = dp.fk_relation1_lex '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19937268630497902)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19937268630497902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19937380634497903)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19937408560497904)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19937884589497908)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19937952759497909)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938050457497910)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938112805497911)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938220562497912)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938379409497913)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938471185497914)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938549564497915)
,p_db_column_name=>'PK_DUPLIKAT_CHECK'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Pk Duplikat Check'
,p_column_link=>'f?p=&APP_ID.:377:&SESSION.::&DEBUG.:RP:P377_PK_DUPLIKAT_CHECK,P377_FK_TYPE:#PK_DUPLIKAT_CHECK#,#FK_DUPLIKAT_TYPE#'
,p_column_linktext=>'#PK_DUPLIKAT_CHECK#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19938620399497916)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Fk Relation1 Lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261752866074414)
,p_db_column_name=>'FK_DUPLIKAT_TYPE'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Fk Duplikat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20532309116370107)
,p_db_column_name=>'BETRAG'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19957017130505137)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'199571'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'JAHR:DATUM_OK:FK_DUPLIKAT_CHECK_STATUS:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:PK_DUPLIKAT_CHECK:FK_RELATION1_LEX:FK_DUPLIKAT_TYPE:BETRAG'
,p_sort_column_1=>'PK_DUPLIKAT_CHECK'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'FK_DUPLIKAT_TYPE:PK_DUPLIKAT_CHECK'
,p_break_enabled_on=>'FK_DUPLIKAT_TYPE:PK_DUPLIKAT_CHECK'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20445369295060293)
,p_report_id=>wwv_flow_api.id(19957017130505137)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19941818148497948)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2, pk_duplikat_check) sel,',
'apex_item.checkbox2(3, pk_duplikat) sel2,',
'dpc.*, dp.FK_RELATION1_LEX, ',
'Betrag',
'from t_duplikat_check dpc ',
' left join t_duplikat dp on dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join t_lex_long ll on ll.relation = dp.fk_relation1_lex',
' where Pk_duplikat_check = :P377_PK_duplikat_check'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19941931448497949)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19941931448497949
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19942002837497950)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20260487190074401)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20260623165074403)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20260782847074404)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20260899187074405)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20260932134074406)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261035666074407)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261102311074408)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261217286074409)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261384054074410)
,p_db_column_name=>'PK_DUPLIKAT_CHECK'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Duplikat Check'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261428410074411)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Relation1 Lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261633082074413)
,p_db_column_name=>'SEL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20261860964074415)
,p_db_column_name=>'FK_DUPLIKAT_TYPE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Duplikat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20263016538074427)
,p_db_column_name=>'SEL2'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373580939865747)
,p_db_column_name=>'BETRAG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20275551071155946)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'202756'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:JAHR:DATUM_OK:FK_DUPLIKAT_CHECK_STATUS:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:PK_DUPLIKAT_CHECK:FK_RELATION1_LEX:FK_DUPLIKAT_TYPE::BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20444716675019118)
,p_report_id=>wwv_flow_api.id(20275551071155946)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20484508463168049)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7676299225527541)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19761792519776898)
,p_plug_name=>'dupl_lex_buch_selected'
,p_parent_plug_id=>wwv_flow_api.id(20484508463168049)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'                select ',
'                    ll.* ,',
'                    ---duplettencheck',
'                    row_number() over (partition by ll.jahr order by ll.jahr) dupl_jahr,',
'                    row_number() over (partition by monat order by monat) dupl_monat,',
'                    row_number() over (partition by tag order by tag) dupl_tag,',
'                    row_number() over (partition by buchungstext order by buchungstext ) dupl_buchtxt, ',
'                    row_number() over (partition by betrag order by betrag) dupl_betrag,',
'                    row_number() over (partition by habenkto order by habenkto) dupl_habenkto,',
'                    row_number() over (partition by sollkto order by sollkto) dupl_sollkto,',
'                    row_number() over (partition by ust_kto order by ust_kto) dupl_ustkto,',
'                    row_number() over (partition by habeneur order by habeneur) dupl_habeneur,',
'                    row_number() over (partition by solleur order by solleur) dupl_solleur,',
'                    row_number() over (partition by ust_eur order by ust_eur) dupl_usteur,',
'                   arb.monat,',
'                   arb.tag,',
'                   arb.jahr arb_jahr, ',
'                    dp.pk_duplikat,',
'                  dp.datum_ok dp_datum_ok',
'                from (select * from t_lex_long where status is null) ll',
'                 join (select * from t_duplikat where fk_duplikat_check = :P377_PK_duplikat_check) dp  on dp.fk_relation1_lex = ll.relation',
'                  left join t_arbeitstage arb on arb.pk_arbeitstage = ll.fk_belegdat',
'               ',
'                     ',
'    /*',
'    ---1 jahr',
'    ---2 monat',
'    ---3 tag',
'    ---4 buchungstext',
'    ---5 betrag',
'    ---6 habenkto',
'    ---7 sollkto',
'    ---8 ustkto',
'    ---9 habeneur',
'    ---10 solleur',
'    ---11 usteur',
'    ',
'    */',
')',
'select apex_item.checkbox2(1, bas.relation) sel,',
'    apex_item.checkbox2(3, pk_duplikat) sel_pk_dp,',
'    bas.*,',
'    case when dupl_jahr.jahr = bas.Jahr then bas.jahr else 0 end dupl_jahr_mark,',
'    case when dupl_monat.monat = bas.monat then bas.monat else 0 end dupl_monat_mark,',
'    case when dupl_tag.tag = bas.tag then bas.tag else 0 end dupl_tag_mark,',
'    case when dupl_buchtxt.buchungstext = bas.buchungstext then bas.buchungstext else '''' end dupl_buchungstxt_mark,',
'    case when dupl_betrag.betrag = bas.betrag then bas.betrag else 0 end dupl_betrag_mark,',
'    case when dupl_habenkto.habenkto = bas.habenkto then bas.habenkto else 0 end dupl_habenkto_mark,',
'    dupl_sollkto.sollkto  dupl_sollkto_mark, -- case when dupl_sollkto = bas.sollkto then bas.sollkto else 0 end dupl_sollkto_mark,',
'    case when dupl_ustkto.ust_kto = bas.ust_kto then bas.ust_kto else 0 end dupl_ustkto_mark,',
'    case when dupl_habeneur.habeneur = bas.habeneur then bas.habeneur else 0 end dupl_habeneur_mark,',
'    case when dupl_solleur.solleur = bas.solleur then bas.solleur else 0 end dupl_solleur_mark,',
'    case when dupl_usteur.ust_eur = bas.ust_eur then bas.ust_eur else 0 end dupl_ust_eur_mark',
'from bas',
'  left join (select distinct jahr from bas where dupl_jahr >1 ) dupL_jahr on  dupl_jahr.jahr = bas.jahr ',
'  left join (select distinct monat from bas where dupl_monat >1 ) dupL_monat on  dupl_monat.monat = bas.monat ',
'  left join (select distinct tag from bas where dupl_tag >1 ) dupL_tag on  dupl_tag.tag = bas.tag',
'  left join (select distinct buchungstext from bas where dupl_buchtxt >1 ) dupL_buchtxt on  dupl_buchtxt.buchungstext = bas.buchungstext',
'  left join (select distinct betrag from bas where dupl_betrag >1 ) dupL_betrag on  dupl_betrag.betrag= bas.betrag',
'  left join (select distinct habenkto from bas where dupl_habenkto >1 ) dupL_habenkto on  dupl_habenkto.habenkto= bas.habenkto',
'  left join (select distinct sollkto from bas where dupl_sollkto >1 ) dupL_sollkto on  dupl_sollkto.sollkto= bas.sollkto',
'  left join (select distinct ust_kto from bas where dupl_ustkto >1 ) dupL_ustkto on  dupl_ustkto.ust_kto= bas.ust_kto',
'  left join (select distinct habeneur from bas where dupl_habeneur >1 ) dupL_habeneur on  dupl_habeneur.habeneur= bas.habeneur',
'  left join (select distinct solleur from bas where dupl_solleur >1 ) dupL_solleur on  dupl_solleur.solleur= bas.solleur',
'  left join (select distinct ust_eur from bas where dupl_usteur >1 ) dupL_usteur on  dupl_usteur.ust_eur= bas.ust_eur',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19761809831776898)
,p_name=>'dupl_lex_buch'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19761809831776898
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19762220130776900)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19762574406776900)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19762922209776900)
,p_db_column_name=>'BELEG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19763333055776900)
,p_db_column_name=>'BENUTZER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19763759009776900)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19764175222776901)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19764573483776901)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19764961195776901)
,p_db_column_name=>'NR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19765331629776901)
,p_db_column_name=>'HABENDM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19765724967776901)
,p_db_column_name=>'HABENEUR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19766156936776903)
,p_db_column_name=>'HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19766583908776903)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19766913803776903)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:378:&SESSION.::&DEBUG.:RP:P378_FK_RELATION:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19767358485776903)
,p_db_column_name=>'SOLLDM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19767756178776903)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19768198314776904)
,p_db_column_name=>'SOLL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19768527533776904)
,p_db_column_name=>'SPERRE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19768962194776904)
,p_db_column_name=>'STAPEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19769338365776904)
,p_db_column_name=>'STATUS'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19769715276776904)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19770198343776906)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19770511990776906)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19770995095776906)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19771329549776906)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19771779717776906)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19772119147776907)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19772579298776907)
,p_db_column_name=>'UST_DM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19772973108776907)
,p_db_column_name=>'UST_EUR'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19773321313776907)
,p_db_column_name=>'UST'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19773745875776909)
,p_db_column_name=>'UST_KTO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19774136597776909)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19774522942776909)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19774974005776909)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19775353584776909)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19775711263776910)
,p_db_column_name=>'PERIODE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19776181182776910)
,p_db_column_name=>'BELEGNR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19776538494776910)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19776976574776910)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19777364643776912)
,p_db_column_name=>'WHRG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19777749951776912)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19778138092776912)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19778564297776912)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19778983270776912)
,p_db_column_name=>'NOTIZ'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19779302726776914)
,p_db_column_name=>'KST'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19779735041776914)
,p_db_column_name=>'KTR'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19780141619776914)
,p_db_column_name=>'JAHR'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19780502150776914)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19780944494776915)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19781328981776915)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19781712635776915)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19782102517776915)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19782590443776917)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19782940606776917)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19783705701776918)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19784177450776918)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19784582555776918)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19784994905776918)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19785378392776920)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19785744438776920)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19786182314776920)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19786526046776920)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>62
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19786952636776921)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>63
,p_column_identifier=>'BK'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19787372396776921)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>64
,p_column_identifier=>'BL'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19787798576776921)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>65
,p_column_identifier=>'BM'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19788150581776923)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>66
,p_column_identifier=>'BN'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723392484686631)
,p_db_column_name=>'DUPL_JAHR'
,p_display_order=>76
,p_column_identifier=>'BO'
,p_column_label=>'Dupl Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723459922686632)
,p_db_column_name=>'DUPL_BUCHTXT'
,p_display_order=>86
,p_column_identifier=>'BP'
,p_column_label=>'Dupl Buchtxt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723571035686633)
,p_db_column_name=>'DUPL_BETRAG'
,p_display_order=>96
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723686820686634)
,p_db_column_name=>'DUPL_HABENKTO'
,p_display_order=>106
,p_column_identifier=>'BR'
,p_column_label=>'Dupl Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723755437686635)
,p_db_column_name=>'DUPL_SOLLKTO'
,p_display_order=>116
,p_column_identifier=>'BS'
,p_column_label=>'Dupl Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723831647686636)
,p_db_column_name=>'DUPL_JAHR_MARK'
,p_display_order=>126
,p_column_identifier=>'BT'
,p_column_label=>'Dupl Jahr Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19723924816686637)
,p_db_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_display_order=>136
,p_column_identifier=>'BU'
,p_column_label=>'Dupl Buchungstxt Mark'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724030462686638)
,p_db_column_name=>'DUPL_BETRAG_MARK'
,p_display_order=>146
,p_column_identifier=>'BV'
,p_column_label=>'Dupl Betrag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724137809686639)
,p_db_column_name=>'DUPL_USTKTO'
,p_display_order=>156
,p_column_identifier=>'BW'
,p_column_label=>'Dupl Ustkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724241423686640)
,p_db_column_name=>'DUPL_HABENEUR'
,p_display_order=>166
,p_column_identifier=>'BX'
,p_column_label=>'Dupl Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724377403686641)
,p_db_column_name=>'DUPL_SOLLEUR'
,p_display_order=>176
,p_column_identifier=>'BY'
,p_column_label=>'Dupl Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724408763686642)
,p_db_column_name=>'FK_BELEGDAT'
,p_display_order=>186
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724575516686643)
,p_db_column_name=>'FK_JOURDAT'
,p_display_order=>196
,p_column_identifier=>'CA'
,p_column_label=>'Fk Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724673631686644)
,p_db_column_name=>'DUPL_MONAT'
,p_display_order=>206
,p_column_identifier=>'CB'
,p_column_label=>'Dupl Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724707036686645)
,p_db_column_name=>'DUPL_TAG'
,p_display_order=>216
,p_column_identifier=>'CC'
,p_column_label=>'Dupl Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724865296686646)
,p_db_column_name=>'MONAT'
,p_display_order=>226
,p_column_identifier=>'CD'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19724978099686647)
,p_db_column_name=>'TAG'
,p_display_order=>236
,p_column_identifier=>'CE'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19725080925686648)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>246
,p_column_identifier=>'CF'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19725113046686649)
,p_db_column_name=>'DUPL_HABENKTO_MARK'
,p_display_order=>256
,p_column_identifier=>'CG'
,p_column_label=>'Dupl Habenkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19725208386686650)
,p_db_column_name=>'DUPL_USTEUR'
,p_display_order=>266
,p_column_identifier=>'CH'
,p_column_label=>'Dupl Usteur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19880666231713001)
,p_db_column_name=>'DUPL_MONAT_MARK'
,p_display_order=>276
,p_column_identifier=>'CI'
,p_column_label=>'Dupl Monat Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19880709751713002)
,p_db_column_name=>'DUPL_TAG_MARK'
,p_display_order=>286
,p_column_identifier=>'CJ'
,p_column_label=>'Dupl Tag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19881412723713009)
,p_db_column_name=>'SEL'
,p_display_order=>296
,p_column_identifier=>'CL'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19881595995713010)
,p_db_column_name=>'SEL_RELATION'
,p_display_order=>306
,p_column_identifier=>'CM'
,p_column_label=>'Sel Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373655935865748)
,p_db_column_name=>'DUPL_SOLLKTO_MARK'
,p_display_order=>316
,p_column_identifier=>'CN'
,p_column_label=>'Dupl Sollkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373773979865749)
,p_db_column_name=>'DUPL_USTKTO_MARK'
,p_display_order=>326
,p_column_identifier=>'CO'
,p_column_label=>'Dupl Ustkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373878894865750)
,p_db_column_name=>'DUPL_HABENEUR_MARK'
,p_display_order=>336
,p_column_identifier=>'CP'
,p_column_label=>'Dupl Habeneur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449178522063201)
,p_db_column_name=>'DUPL_SOLLEUR_MARK'
,p_display_order=>346
,p_column_identifier=>'CQ'
,p_column_label=>'Dupl Solleur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449263272063202)
,p_db_column_name=>'DUPL_UST_EUR_MARK'
,p_display_order=>356
,p_column_identifier=>'CR'
,p_column_label=>'Dupl Ust Eur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20531855564370102)
,p_db_column_name=>'PK_DUPLIKAT'
,p_display_order=>376
,p_column_identifier=>'CU'
,p_column_label=>'Pk Duplikat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20531915865370103)
,p_db_column_name=>'SEL_PK_DP'
,p_display_order=>386
,p_column_identifier=>'CV'
,p_column_label=>'Sel Pk Dp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20532299261370106)
,p_db_column_name=>'DP_DATUM_OK'
,p_display_order=>396
,p_column_identifier=>'CW'
,p_column_label=>'Dp Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19791112656835164)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197912'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:SEL_PK_DP:BELEGDAT:ABSCHLUSS:BUCHDAT:JOUR_DAT:NR:BELEG:RELATION:BETRAGEUR:BETRAGDM:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:HABENDM:HABENEUR:HABEN:SOLLDM:SOLLEUR:SOLL:SPERRE:DUPL_JAHR_MARK:DUPL_MONAT_MARK:DUPL_TAG_MARK:DUPL_BUCHUNGSTXT_MARK:DUPL_BETRA'
||'G_MARK:DUPL_HABENKTO_MARK:DUPL_SOLLKTO_MARK:DUPL_USTKTO_MARK:DUPL_HABENEUR_MARK:DUPL_SOLLEUR_MARK:DUPL_UST_EUR_MARK:STAPEL:STATUS:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_P'
||unistr('ROZ:UST_TEXT:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:\00DCBERGABEDATUM_AN_STB:FK_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DU')
||unistr('PL_OK:DUPL_BEMERKUNG:FK_DUPL_STATUS:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:DUPL_JAHR:DUPL_BUCHTXT:DUPL_BETRAG:DUPL_HABENKTO:DUPL_SOLLKTO:DUPL_USTKTO:DUPL_HABENEUR:DUPL_SOLLEUR:FK_BELEGDAT:FK_JOURDAT:TAG:ARB_JAHR:DUPL_USTEUR:SEL_RELATION:DUPL_MONAT')
||':DUPL_TAG:FK_STEUER_MONAT:FK_STEUER_VORANMELDG:MONAT:PK_DUPLIKAT::DP_DATUM_OK'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20576942985092354)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'betr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BETRAG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0E0E0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20577304894092356)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DP_DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DP_DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20577760093092356)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'bm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_BETRAG_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_BETRAG_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20578108456092356)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'btxtm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_BUCHUNGSTXT_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20578596791092357)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'hem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENEUR_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENEUR_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20578925736092359)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'hbktom'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENKTO_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENKTO_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20579345587092359)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'hkm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENKTO_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENKTO_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20579741505092359)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'jrm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_JAHR_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_JAHR_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20580104850092360)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'mm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_MONAT_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_MONAT_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20580532049092360)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'mnodup'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_MONAT_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_MONAT_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20580928032092360)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'sem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLEUR_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_SOLLEUR_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20581344239092362)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'skom'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLKTO_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_SOLLKTO_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20581762054092362)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'skm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLKTO_MARK'
,p_operator=>'is null'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_SOLLKTO_MARK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20582130515092362)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'tm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_TAG_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_TAG_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20582579459092364)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'tnodup'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_TAG_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_TAG_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20582938859092365)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'ukm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_USTKTO_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_USTKTO_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20583384900092365)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'uem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_UST_EUR_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_UST_EUR_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20583711129092367)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'habenkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("HABENKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E3E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20584173862092368)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("JAHR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#BAB6BA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20584521491092370)
,p_report_id=>wwv_flow_api.id(19791112656835164)
,p_name=>'sollkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SOLLKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#F0F0F0'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20449340655063203)
,p_plug_name=>'dupl_lex_buch_wo_select'
,p_parent_plug_id=>wwv_flow_api.id(20484508463168049)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'                select ',
'                    ll.* ,',
'                    ---duplettencheck',
'                    row_number() over (partition by ll.jahr order by ll.jahr) dupl_jahr,',
'                    row_number() over (partition by monat order by monat) dupl_monat,',
'                    row_number() over (partition by tag order by tag) dupl_tag,',
'                    row_number() over (partition by buchungstext order by buchungstext ) dupl_buchtxt, ',
'                    row_number() over (partition by betrag order by betrag) dupl_betrag,',
'                    row_number() over (partition by habenkto order by habenkto) dupl_habenkto,',
'                    row_number() over (partition by sollkto order by sollkto) dupl_sollkto,',
'                    row_number() over (partition by ust_kto order by ust_kto) dupl_ustkto,',
'                    row_number() over (partition by habeneur order by habeneur) dupl_habeneur,',
'                    row_number() over (partition by solleur order by solleur) dupl_solleur,',
'                    row_number() over (partition by ust_eur order by ust_eur) dupl_usteur,',
'                   arb.monat,',
'                   arb.tag,',
'                   arb.jahr arb_jahr',
'                from (select * from t_lex_long where status is null) ll',
'                  left join t_arbeitstage arb on arb.pk_arbeitstage = ll.fk_belegdat',
'                where (betrag = replace(:P377_betrag,''%2C'','','')  or :P377_betrag is null)',
'                 and (belegdat= :P377_datum or  :P377_datum is null)',
'                 and (ll.jahr = :P377_jahr or :P377_jahr is null)',
'                     ',
'    /*',
'    ---1 jahr',
'    ---2 monat',
'    ---3 tag',
'    ---4 buchungstext',
'    ---5 betrag',
'    ---6 habenkto',
'    ---7 sollkto',
'    ---8 ustkto',
'    ---9 habeneur',
'    ---10 solleur',
'    ---11 usteur',
'    ',
'    */',
')',
'select apex_item.checkbox2(1, bas.relation) sel,',
'    bas.*,',
'    case when dupl_jahr.jahr = bas.Jahr then bas.jahr else 0 end dupl_jahr_mark,',
'    case when dupl_monat.monat = bas.monat then bas.monat else 0 end dupl_monat_mark,',
'    case when dupl_tag.tag = bas.tag then bas.tag else 0 end dupl_tag_mark,',
'    case when dupl_buchtxt.buchungstext = bas.buchungstext then bas.buchungstext else '''' end dupl_buchungstxt_mark,',
'    case when dupl_betrag.betrag = bas.betrag then bas.betrag else 0 end dupl_betrag_mark,',
'    case when dupl_habenkto.habenkto = bas.habenkto then bas.habenkto else 0 end dupl_habenkto_mark,',
'    dupl_sollkto.sollkto  dupl_sollkto_mark, -- case when dupl_sollkto = bas.sollkto then bas.sollkto else 0 end dupl_sollkto_mark,',
'    case when dupl_ustkto.ust_kto = bas.ust_kto then bas.ust_kto else 0 end dupl_ustkto_mark,',
'    case when dupl_habeneur.habeneur = bas.habeneur then bas.habeneur else 0 end dupl_habeneur_mark,',
'    case when dupl_solleur.solleur = bas.solleur then bas.solleur else 0 end dupl_solleur_mark,',
'    case when dupl_usteur.ust_eur = bas.ust_eur then bas.ust_eur else 0 end dupl_ust_eur_mark',
'from bas',
'  left join (select distinct jahr from bas where dupl_jahr >1 ) dupL_jahr on  dupl_jahr.jahr = bas.jahr ',
'  left join (select distinct monat from bas where dupl_monat >1 ) dupL_monat on  dupl_monat.monat = bas.monat ',
'  left join (select distinct tag from bas where dupl_tag >1 ) dupL_tag on  dupl_tag.tag = bas.tag',
'  left join (select distinct buchungstext from bas where dupl_buchtxt >1 ) dupL_buchtxt on  dupl_buchtxt.buchungstext = bas.buchungstext',
'  left join (select distinct betrag from bas where dupl_betrag >1 ) dupL_betrag on  dupl_betrag.betrag= bas.betrag',
'  left join (select distinct habenkto from bas where dupl_habenkto >1 ) dupL_habenkto on  dupl_habenkto.habenkto= bas.habenkto',
'  left join (select distinct sollkto from bas where dupl_sollkto >1 ) dupL_sollkto on  dupl_sollkto.sollkto= bas.sollkto',
'  left join (select distinct ust_kto from bas where dupl_ustkto >1 ) dupL_ustkto on  dupl_ustkto.ust_kto= bas.ust_kto',
'  left join (select distinct habeneur from bas where dupl_habeneur >1 ) dupL_habeneur on  dupl_habeneur.habeneur= bas.habeneur',
'  left join (select distinct solleur from bas where dupl_solleur >1 ) dupL_solleur on  dupl_solleur.solleur= bas.solleur',
'  left join (select distinct ust_eur from bas where dupl_usteur >1 ) dupL_usteur on  dupl_usteur.ust_eur= bas.ust_eur',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(20449450221063204)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>20449450221063204
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449533381063205)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449693071063206)
,p_db_column_name=>'UST_DM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449705106063207)
,p_db_column_name=>'UST_EUR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449893073063208)
,p_db_column_name=>'UST'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20449907023063209)
,p_db_column_name=>'UST_KTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450066585063210)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450134498063211)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450218360063212)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450348848063213)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450446137063214)
,p_db_column_name=>'PERIODE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450551650063215)
,p_db_column_name=>'BELEGNR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450644649063216)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450754844063217)
,p_db_column_name=>'BETRAG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450823385063218)
,p_db_column_name=>'WHRG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20450990591063219)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451037840063220)
,p_db_column_name=>'HABENKTO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451168464063221)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451265436063222)
,p_db_column_name=>'NOTIZ'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451316000063223)
,p_db_column_name=>'KST'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451457168063224)
,p_db_column_name=>'KTR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451541798063225)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451690309063226)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451799863063227)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451872817063228)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20451972286063229)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452007927063230)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452182476063231)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452238140063232)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452313202063233)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452475193063234)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452575668063235)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452687157063236)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452711077063237)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452833002063238)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20452985154063239)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453054770063240)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453127867063241)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453278150063242)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453374155063243)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453436905063244)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453575874063245)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453634623063246)
,p_db_column_name=>'DUPL_JAHR'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Dupl Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453738337063247)
,p_db_column_name=>'DUPL_BUCHTXT'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Dupl Buchtxt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453802614063248)
,p_db_column_name=>'DUPL_BETRAG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Dupl Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20453925114063249)
,p_db_column_name=>'DUPL_HABENKTO'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Dupl Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20454072718063250)
,p_db_column_name=>'DUPL_SOLLKTO'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Dupl Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20479728285168001)
,p_db_column_name=>'DUPL_JAHR_MARK'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Dupl Jahr Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20479810013168002)
,p_db_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Dupl Buchungstxt Mark'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20479919635168003)
,p_db_column_name=>'DUPL_BETRAG_MARK'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Dupl Betrag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480015703168004)
,p_db_column_name=>'DUPL_USTKTO'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Dupl Ustkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480157414168005)
,p_db_column_name=>'DUPL_HABENEUR'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Dupl Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480286088168006)
,p_db_column_name=>'DUPL_SOLLEUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Dupl Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480335157168007)
,p_db_column_name=>'FK_BELEGDAT'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480493874168008)
,p_db_column_name=>'BELEG'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480569215168009)
,p_db_column_name=>'FK_JOURDAT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fk Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480641530168010)
,p_db_column_name=>'DUPL_MONAT'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Dupl Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480746019168011)
,p_db_column_name=>'DUPL_TAG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Dupl Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480820551168012)
,p_db_column_name=>'MONAT'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20480988237168013)
,p_db_column_name=>'TAG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481019952168014)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481157444168015)
,p_db_column_name=>'DUPL_HABENKTO_MARK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Habenkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481218859168016)
,p_db_column_name=>'DUPL_USTEUR'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Dupl Usteur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481344183168017)
,p_db_column_name=>'DUPL_MONAT_MARK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Dupl Monat Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481448606168018)
,p_db_column_name=>'DUPL_TAG_MARK'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Dupl Tag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481538296168019)
,p_db_column_name=>'SEL'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481635590168020)
,p_db_column_name=>'SEL_RELATION'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Sel Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481722511168021)
,p_db_column_name=>'DUPL_SOLLKTO_MARK'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Dupl Sollkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481877626168022)
,p_db_column_name=>'DUPL_USTKTO_MARK'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Dupl Ustkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20481984799168023)
,p_db_column_name=>'DUPL_HABENEUR_MARK'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Habeneur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482094099168024)
,p_db_column_name=>'DUPL_SOLLEUR_MARK'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Dupl Solleur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482170020168025)
,p_db_column_name=>'DUPL_UST_EUR_MARK'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Dupl Ust Eur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482222650168026)
,p_db_column_name=>'BENUTZER'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482385395168027)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482426827168028)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482534874168029)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482608376168030)
,p_db_column_name=>'NR'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482744044168031)
,p_db_column_name=>'HABENDM'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482857482168032)
,p_db_column_name=>'HABENEUR'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20482991527168033)
,p_db_column_name=>'HABEN'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483048605168034)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483155478168035)
,p_db_column_name=>'RELATION'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:378:&SESSION.::&DEBUG.:RP:P378_FK_RELATION:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483222465168036)
,p_db_column_name=>'SOLLDM'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483314178168037)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483437794168038)
,p_db_column_name=>'SOLL'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483598048168039)
,p_db_column_name=>'SPERRE'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483660966168040)
,p_db_column_name=>'STAPEL'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483755889168041)
,p_db_column_name=>'STATUS'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483800784168042)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20483926298168043)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20484006422168044)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20484141375168045)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20484235074168046)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20484365158168047)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20484455505168048)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20515818097195800)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'205159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGDAT:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:ABS'
||unistr('CHLUSS:\00DCBERGABEDATUM_AN_STB:FK_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_DUPL_STATUS:FK_STEUER_MONAT:FK_STEUER_VORANMELDG:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:DUPL_JAHR:DUPL_BUCHTXT:DUPL_')
||'BETRAG:DUPL_HABENKTO:DUPL_SOLLKTO:DUPL_JAHR_MARK:DUPL_BUCHUNGSTXT_MARK:DUPL_BETRAG_MARK:DUPL_USTKTO:DUPL_HABENEUR:DUPL_SOLLEUR:FK_BELEGDAT:BELEG:FK_JOURDAT:DUPL_MONAT:DUPL_TAG:MONAT:TAG:ARB_JAHR:DUPL_HABENKTO_MARK:DUPL_USTEUR:DUPL_MONAT_MARK:DUPL_TAG'
||'_MARK:SEL:SEL_RELATION:DUPL_SOLLKTO_MARK:DUPL_USTKTO_MARK:DUPL_HABENEUR_MARK:DUPL_SOLLEUR_MARK:DUPL_UST_EUR_MARK:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:RELATION:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H'
||'_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19722846583686626)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(19722568906686623)
,p_button_name=>'set_dupl_Ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set Dupl Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19881910778713014)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'Mark_Duplikat'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Mark Duplikat'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19881690860713011)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'New_Duplikatscheck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Duplikatscheck'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19881712380713012)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'add_duplikatsscheck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Duplikatsscheck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20263126082074428)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'remove_duplikat'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'remove_duplikat'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19881016732713005)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'SEt_Type'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set Type'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20262114747074418)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'set_dupl_check_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set Dupl Check Datum Ok'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20262276291074419)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'set_dupl_check_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'set_dupl_check_datum_nok'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19881298502713007)
,p_button_sequence=>230
,p_button_plug_id=>wwv_flow_api.id(19880840468713003)
,p_button_name=>'SEt_STatus'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Set Status'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19722646514686624)
,p_name=>'P377_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19722568906686623)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19722944150686627)
,p_name=>'P377_DATUM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(19722568906686623)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19723186290686629)
,p_name=>'P377_BETRAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(19722568906686623)
,p_item_default=>'select replace(:P377_Betr,''%2C'','','') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19880924235713004)
,p_name=>'P377_FK_TYPE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 361'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19881181769713006)
,p_name=>'P377_FK_STATUS'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'fk_status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:keine Angabe;0,ok;1,nok;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19881871339713013)
,p_name=>'P377_FK_DUPLIKATSCHECK'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Duplikatscheck'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_duplikat_check || '' '' || std.std_name d, pk_duplikat_check r',
'from t_duplikat_check dpc',
' left join t_duplikat dp on dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join (select std_name, std_value',
'from t_std',
'where fk_std_group = 361) std on std.std_value = dpc.FK_DUPLiKAT_TYPE',
'where fk_duplikat_check is null',
'order by pk_duplikat_check desc '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882096748713015)
,p_name=>'P377_TXT!'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'<b>1 - Mark Duplikat</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882167486713016)
,p_name=>'P377_TXT2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'<b>2 - Add Duplikatcheck</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882253189713017)
,p_name=>'P377_TXT!3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'<b>3 - Set Status</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882560493713020)
,p_name=>'P377_FK_OBJEKT_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Objekt 1'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882635203713021)
,p_name=>'P377_FK_OBJEKT_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>' Fk Objekt 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882796089713022)
,p_name=>'P377_FK_OBJEKT_3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Objekt 3'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882836326713023)
,p_name=>'P377_FK_OBJEKT_4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Objekt 4'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19882908197713024)
,p_name=>'P377_FK_OBJEKT_5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Fk Objekt 5'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19883142698713026)
,p_name=>'P377_FK_OBJEKT_6'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20261511227074412)
,p_name=>'P377_PK_DUPLIKAT_CHECK'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(19880840468713003)
,p_prompt=>'Pk Duplikat Check'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'pk_duplikat_check || '' - '' || std_name || datum_ok , pk_duplikat_check',
'from t_duplikat_check dpc',
' left join (select * from t_std where fk_std_group = 361) std on std.std_value = dpc.fk_duplikat_type',
'order by pk_duplikat_check desc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19723282475686630)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' if :P377_betr is not null then',
' ',
' select replace(:P377_Betr,''%2C'','','')  ',
' into :P377_betrag',
' from dual;',
' ',
' end if;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19882388257713018)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_mark_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update t_lex_long  set fk_dupl_status = 1 where relation = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19881910778713014)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19882449903713019)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_new_duplikatscheck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_duplikat_check (FK_DUPLiKAT_TYPE, fk_objekt_1, fk_objekt_2, fk_objekt_3, fk_objekt_4, fk_objekt_5,  creation_date)',
'  values (:P377_fk_type, :P377_FK_OBJEKT_1, :P377_FK_OBJEKT_2, :P377_FK_OBJEKT_3 , :P377_FK_OBJEKT_4, :P377_FK_OBJEKT_5, sysdate);',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19881690860713011)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19883231485713027)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_add_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'  insert into t_duplikat (',
'',
'FK_DUPLIKAT_CHECK,',
'FK_DUPL_TYPE,',
'FK_DUPL_STATE,',
'FK_INP_BELEG_ALL1,',
'FK_INP_BELEG_ALL2,',
'FK_RELATION1_LEX,',
'FK_RELATION2_LEX,',
'FK_MAIN_KEY1,',
'FK_MAIN_KEY2,',
'FK_RELATION1_KTBL,',
'FK_RELATION2_KTBL',
'  ',
'  )',
'  values (',
'      ',
'    ',
':P377_FK_DUPLIKATSCHECK,',
':P377_FK_TYPE,',
'null, -- FK_DUPL_STATE,',
'null, --FK_INP_BELEG_ALL1,',
'null, --FK_INP_BELEG_ALL2,',
'apex_application.g_f01(i), ',
'null, --FK_RELATION2_LEX,',
'null, --FK_MAIN_KEY1,',
'null, ---FK_MAIN_KEY2,',
'null, --FK_RELATION1_KTBL,',
'null --FK_RELATION2_KTBL',
'  ',
'  ',
'  ',
'  );',
'  commit;',
'  ',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19881712380713012)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20262848642074425)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_remove_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'     delete from t_duplikat where pk_duplikat = apex_application.g_f03(i);',
'  commit;',
'  ',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20263126082074428)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20261932606074416)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  --',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    update t_duplikat_check set datum_ok = sysdate where pk_duplikat_check =  apex_application.g_f02(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20262114747074418)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20532021516370104)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_ok_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'     for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    update t_duplikat set datum_ok = sysdate where pk_duplikat =  apex_application.g_f03(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20262114747074418)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20262014270074417)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  --',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    update t_duplikat_check set datum_ok = null where pk_duplikat_check =  apex_application.g_f02(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'   ',
' ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20262276291074419)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20532151723370105)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_nok_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'     for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    update t_duplikat set datum_ok = null where pk_duplikat =  apex_application.g_f03(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20262276291074419)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20262953188074426)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'   --1_mark_duplikat: 1',
'   --2_new_duplikatscheck: --',
'   --3_add_duplikat: 1',
'   --3_remove_duplikat 3',
'   --4_set_status_dupl_check_ok / 4_set_status_dupl_check_nok: 2',
'',
'null;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
