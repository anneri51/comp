prompt --application/pages/page_00378
begin
--   Manifest
--     PAGE: 00378
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>378
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'duplikate_relation_inp_beleg'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'duplikate_relation_inp_beleg'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44341901507941496)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090908'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19938771884497917)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19965954263770060)
,p_plug_name=>'duplikate_relation_inp_beleg'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dp.fk_relation1_lex, vinp.pk_inp_belege_all, vinp.bezeichnung, vinp.ort, vinp.land, vinp.proj_projekt_art, zahl_art_name, proj_projekt, vloc_location, comm_parkticket, comm_sonstiges, comm_produkte, comm_rest_beleg, brutto_betrag, comm_tel_bel'
||unistr('eg, bel_datum, von, bis, von_uhrzeit, bis_uhrzeit, pers\00F6nlich_vor_ort, comm_begr\00FCndung, ktokat_kategorie,'),
'to_char(beleg_uhrzeit, ''HH24:MI:SS'') bel_ur, to_char(von_uhrzeit,''HH24:MI:SS'') von_ur, to_char(bis_uhrzeit, ''HH24:MI:SS'') bis_ur, vinp.abl_ord_jahr, vinp.abl_ord_page_number',
'from (select * from t_duplikat where fk_relation1_lex = :P378_FK_relation) dup',
' left join t_duplikat dp on dp.fk_duplikat_check= dup.fk_duplikat_check',
' left join t_rel_lex_kto_bel relbel on relbel.fk_relation = dp.fk_relation1_lex',
' left join v_inp_belege_all vinp on vinp.pk_inp_belege_all = relbel.fk_inp_belege_all ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19966073871770060)
,p_name=>'duplikate_relation_inp_beleg'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19966073871770060
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19966459492770075)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Relation1 Lex'
,p_column_link=>'f?p=&APP_ID.:382:&SESSION.::&DEBUG.:RP:P382_RELATION:#FK_RELATION1_LEX#'
,p_column_linktext=>'#FK_RELATION1_LEX#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19966878390770076)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19970851633770081)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20036820319770159)
,p_db_column_name=>'LAND'
,p_display_order=>179
,p_column_identifier=>'FU'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20037649549770160)
,p_db_column_name=>'ORT'
,p_display_order=>181
,p_column_identifier=>'FW'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940077287497930)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>191
,p_column_identifier=>'FX'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940100328497931)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>201
,p_column_identifier=>'FY'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940236962497932)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>211
,p_column_identifier=>'FZ'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940355797497933)
,p_db_column_name=>'VLOC_LOCATION'
,p_display_order=>221
,p_column_identifier=>'GA'
,p_column_label=>'Vloc Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940462187497934)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>231
,p_column_identifier=>'GB'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940578146497935)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>241
,p_column_identifier=>'GC'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940685037497936)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>251
,p_column_identifier=>'GD'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940781728497937)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>261
,p_column_identifier=>'GE'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940880647497938)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>271
,p_column_identifier=>'GF'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19940997887497939)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>281
,p_column_identifier=>'GG'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941017978497940)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>291
,p_column_identifier=>'GH'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941183175497941)
,p_db_column_name=>'VON'
,p_display_order=>301
,p_column_identifier=>'GI'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941251561497942)
,p_db_column_name=>'BIS'
,p_display_order=>311
,p_column_identifier=>'GJ'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941353553497943)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>321
,p_column_identifier=>'GK'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941468258497944)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>331
,p_column_identifier=>'GL'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941569460497945)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>341
,p_column_identifier=>'GM'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941638419497946)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>351
,p_column_identifier=>'GN'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19941763084497947)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>361
,p_column_identifier=>'GO'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20263362492074430)
,p_db_column_name=>'BEL_UR'
,p_display_order=>371
,p_column_identifier=>'GP'
,p_column_label=>'Bel Ur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20263472259074431)
,p_db_column_name=>'VON_UR'
,p_display_order=>381
,p_column_identifier=>'GQ'
,p_column_label=>'Von Ur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20263524858074432)
,p_db_column_name=>'BIS_UR'
,p_display_order=>391
,p_column_identifier=>'GR'
,p_column_label=>'Bis Ur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373317691865745)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>401
,p_column_identifier=>'GS'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20373425319865746)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>411
,p_column_identifier=>'GT'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20080216070796696)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'200803'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_RELATION1_LEX:PK_INP_BELEGE_ALL:BEZEICHNUNG:LAND:ORT_ART:ZAHL_ART_NAME:PROJ_PROJEKT:VLOC_LOCATION:COMM_PARKTICKET:COMM_SONSTIGES:COMM_PRODUKTE:COMM_REST_BELEG:BRUTTO_BETRAG:COMM_TEL_BELEG:BEL_DATUM:VON:BIS:VON_UHRZEIT:BIS_UHRZEIT:PERS\00D6NLICH_VOR_OR')
||unistr('T:COMM_BEGR\00DCNDUNG:KTOKAT_KATEGORIE:BEL_UR:VON_UR:BIS_UR:ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER')
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20263624068074433)
,p_plug_name=>'duplikate_relation_inp_beleg'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dp.fk_relation1_lex,zus.*, ktoaus.fk_konto_auszug',
'from (select * from t_duplikat where fk_relation1_lex = :P378_FK_relation) dup',
' left join t_duplikat dp on dp.fk_duplikat_check= dup.fk_duplikat_check',
' left join t_rel_lex_kto_bel relbel on relbel.fk_relation = dp.fk_relation1_lex',
'left join v_konten_zus zus on relbel.fk_main_key = zus.fk_main_key',
' left join t_rel_konto_auszug_gir ktoaus on ktoaus.fk_main_key = zus.fk_main_key',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(20263730830074434)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>20263730830074434
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20263856332074435)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Relation1 Lex'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20314839863993911)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20314975713993912)
,p_db_column_name=>'ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315043744993913)
,p_db_column_name=>'Buchungstag'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315183800993914)
,p_db_column_name=>'Betrag'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315237261993915)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315341955993916)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315429043993917)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315586659993918)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315627001993919)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315782383993920)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315853974993921)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20315978312993922)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316096670993923)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316112573993924)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316259416993925)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316323692993926)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316448157993927)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316534546993928)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316677948993929)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316725265993930)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316893756993931)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20316962771993932)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317046481993933)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317198696993934)
,p_db_column_name=>'Kontotyp'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317210457993935)
,p_db_column_name=>'FK_VORGANG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317385488993936)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317477377993937)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317598426993938)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317681068993939)
,p_db_column_name=>'FK_KONTO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317771992993940)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317864161993941)
,p_db_column_name=>'IBAN'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20317925035993942)
,p_db_column_name=>'BANK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21464515415339626)
,p_db_column_name=>'FK_KONTO_AUSZUG'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20329452414001287)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'203295'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_KONTO_AUSZUG:FK_RELATION1_LEX:FK_MAIN_KEY:ID:Buchungstag:Betrag:W\00E4hrung:Fremdw\00E4hrungsbetrag:Fremdw\00E4hrung:BUCHUNGSTEXT:FK_Kategorie:FK_Verwendungszweck:FK_Kontotyp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCH')
||'T_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:Kontotyp:FK_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KONTO:KTO_BEZEICHNUNG:IBAN:BANK:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(23137237895506395)
,p_report_id=>wwv_flow_api.id(20329452414001287)
,p_name=>'ktoaus_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KONTO_AUSZUG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_KONTO_AUSZUG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19938816914497918)
,p_name=>'P378_FK_RELATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19938771884497917)
,p_prompt=>'Fk Relation'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20259632161023601)
,p_name=>'P378_FK_MAIN_KEY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(19938771884497917)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Main Key'
,p_source=>'FK_MAIN_KEY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20259990309031396)
,p_name=>'P378_FK_INP_BELEGE_ALL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(19938771884497917)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20260103941043295)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_mark_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update t_lex_long  set fk_dupl_status = 1 where relation = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
