prompt --application/pages/page_00381
begin
--   Manifest
--     PAGE: 00381
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>381
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>unistr('kontenzusammenf\00FChrung')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('kontenzusammenf\00FChrung')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44315674703751187)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091447'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20533956035370123)
,p_plug_name=>unistr('kontenzusammenf\00FChrung')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all, ktokat_kategorie, brutto_betrag, verwendungszweck  , ll.betrag, ll.habenkto, ll.sollkto, ll.relation, bel.pk_rel_lex_kto_bel',
'',
'from v_inp_belege_all inp',
'  left join t_rel_lex_kto_bel bel on inp.pk_inp_belege_all = bel.fk_inp_belege_all',
'  left join (select * from  t_lex_long where status is null ) ll on ll.relation = bel.fk_relation',
'',
'',
'where instr(ktokat_kategorie, ''uszahlung'')>0 and abl_ord_jahr = :P381_jahr',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(20534047117370124)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>20534047117370124
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20698052985269943)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20699911114273412)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20712334752273536)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20712535357273538)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725551243273618)
,p_db_column_name=>'BETRAG'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725603312273619)
,p_db_column_name=>'HABENKTO'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725710569273620)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725881514273621)
,p_db_column_name=>'RELATION'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726000374273623)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20891788785313646)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'208918'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>'PK_INP_BELEGE_ALL:KTOKAT_KATEGORIE:BETRAG:HABENKTO:SOLLKTO:BRUTTO_BETRAG:VERWENDUNGSZWECK::RELATION:PK_REL_LEX_KTO_BEL'
,p_break_on=>'PK_INP_BELEGE_ALL'
,p_break_enabled_on=>'PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20666074972265360)
,p_plug_name=>unistr('kontenzusammenf\00FChrung')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ll.*, arb.monat, pk_rel_lex_kto_bel,fk_inp_belege_all, rellex.pk_rel_lex_lex, fk_relation1, fk_relation2, std.std_name, inp.pk_inp_belege_all, zus.buchungstext kto_buchungstext, v_inp.ktokat_kategorie',
'from (',
'    ',
'--Kasse - Auszahlung',
'   select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1600 and habenkto = 1460 and status is null',
'union',
'       select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1600 and status is null',
'union',
'--Girokonto - Coba',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1700 and status is null',
'union',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1700 and habenkto = 1460 and status is null',
'union',
'--Girokonto - 1740',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1740 and habenkto = 1460 and status is null',
'union',
' select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1740 and status is null',
'union',
'--Girokonto - 1730',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1730 and status is null',
'union',
'    select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1730 and habenkto = 1460 and status is null',
'    union',
'--Girokonto - 1710',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1710 and status is null',
'union',
'    select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1710 and habenkto = 1460 and status is null',
'    union',
'--Girokonto - 1720',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1720 and status is null',
'union',
'    select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1720 and habenkto = 1460 and status is null',
'  union',
'--Girokonto - 1750',
'select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1460 and habenkto = 1750 and status is null',
'union',
'    select * from t_lex_long where jahr  = :P381_jahr and sollkto = 1750 and habenkto = 1460 and status is null',
'   ',
'',
'      ) ll',
'      left join t_arbeitstage arb on arb.pk_arbeitstage = ll.fk_belegdat',
'      left join t_rel_lex_kto_bel relbel on relbel.fk_relation = ll.relation',
'      left join inp_belege_all inp on inp.pk_inp_belege_all  = relbel.fk_inp_belege_all',
'      left join v_inp_belege_all v_inp on v_inp.pk_inp_belege_all = inp.pk_inp_belege_all',
'      left join t_rel_lex_lex rellex on rellex.fk_relation1 = ll.relation or rellex.fk_relation2 = ll.relation',
'      left join v_konten_zus zus on zus.fk_main_key = relbel.fk_main_Key',
'      left join (select std_name, std_value',
'from t_std ',
'where fk_std_group = 281) std on std.std_value = rellex.fk_rel_type_lex_lex'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(20666112842265360)
,p_name=>unistr('kontenzusammenf\00FChrung')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>20666112842265360
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20666522270265384)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20666964842265398)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20667393359265398)
,p_db_column_name=>'BELEG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20667677332265400)
,p_db_column_name=>'BENUTZER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20668095156265400)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20668456597265401)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20668832225265401)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_FK_RELATION1:#RELATION#'
,p_column_linktext=>'#BUCHDAT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20669276976265403)
,p_db_column_name=>'NR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20669686504265404)
,p_db_column_name=>'HABENDM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20670065100265404)
,p_db_column_name=>'HABENEUR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20670470296265406)
,p_db_column_name=>'HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20670806950265406)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20671229738265407)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_FK_RELATION,P252_FK_INP_BELEGE_ALL:#RELATION#,#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20671650924265409)
,p_db_column_name=>'SOLLDM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20672018383265409)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20672486898265410)
,p_db_column_name=>'SOLL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20672852062265410)
,p_db_column_name=>'SPERRE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20673247796265412)
,p_db_column_name=>'STAPEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20673601014265412)
,p_db_column_name=>'STATUS'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20674010013265414)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20674468580265414)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20674879966265414)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20675299807265415)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20675617788265415)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20676054477265415)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20676477164265417)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20676855627265417)
,p_db_column_name=>'UST_DM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20677285090265417)
,p_db_column_name=>'UST_EUR'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20677605046265418)
,p_db_column_name=>'UST'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20678082608265418)
,p_db_column_name=>'UST_KTO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_FK_RELATION1:#RELATION#'
,p_column_linktext=>'#UST_KTO#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20678431274265418)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20678831571265420)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20679270764265420)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20679613161265420)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20680039008265421)
,p_db_column_name=>'PERIODE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20680403744265421)
,p_db_column_name=>'BELEGNR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20680801165265421)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20681275275265423)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20681688805265423)
,p_db_column_name=>'WHRG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20682060859265425)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20682494943265425)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20682813669265426)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20683200918265426)
,p_db_column_name=>'NOTIZ'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20683678530265426)
,p_db_column_name=>'KST'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20684058608265428)
,p_db_column_name=>'KTR'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20684402359265428)
,p_db_column_name=>'JAHR'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20684847865265428)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20685246879265429)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20685605122265429)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20686006818265429)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20686421731265431)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20686833367265431)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20687256030265431)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20687606178265431)
,p_db_column_name=>'SEL_RELATION'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Sel Relation'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20688015226265432)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20688499696265432)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20688862207265434)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20689289747265434)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20689661608265435)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20690019569265435)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20690452011265435)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20690822492265437)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>62
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20691250774265437)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>63
,p_column_identifier=>'BK'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20691654644265437)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>64
,p_column_identifier=>'BL'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20692037609265439)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>65
,p_column_identifier=>'BM'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20692497892265439)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>66
,p_column_identifier=>'BN'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20692875661265440)
,p_db_column_name=>'FK_BELEGDAT'
,p_display_order=>67
,p_column_identifier=>'BO'
,p_column_label=>'Fk Belegdat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20693262922265440)
,p_db_column_name=>'FK_JOURDAT'
,p_display_order=>68
,p_column_identifier=>'BP'
,p_column_label=>'Fk Jourdat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725400380273617)
,p_db_column_name=>'MONAT'
,p_display_order=>78
,p_column_identifier=>'BQ'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20725973768273622)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>88
,p_column_identifier=>'BR'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#PK_REL_LEX_KTO_BEL#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726196263273624)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>98
,p_column_identifier=>'BS'
,p_column_label=>'Fk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_FK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726228908273625)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>108
,p_column_identifier=>'BT'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_column_linktext=>'#PK_REL_LEX_LEX#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726338817273626)
,p_db_column_name=>'FK_RELATION1'
,p_display_order=>118
,p_column_identifier=>'BU'
,p_column_label=>'Fk Relation1'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_FK_RELATION,P252_FK_INP_BELEGE_ALL,P252_PK_REL_LEX_KTO_BEL:#FK_RELATION1#,#FK_INP_BELEGE_ALL#,'
,p_column_linktext=>'#FK_RELATION1#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726494341273627)
,p_db_column_name=>'FK_RELATION2'
,p_display_order=>128
,p_column_identifier=>'BV'
,p_column_label=>'Fk Relation2'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_FK_RELATION,P252_FK_INP_BELEGE_ALL,P252_PK_REL_LEX_KTO_BEL:#FK_RELATION2#,#FK_INP_BELEGE_ALL#,'
,p_column_linktext=>'#FK_RELATION2#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726794525273630)
,p_db_column_name=>'STD_NAME'
,p_display_order=>138
,p_column_identifier=>'BW'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20726902539273632)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>148
,p_column_identifier=>'BX'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20727065218273633)
,p_db_column_name=>'KTO_BUCHUNGSTEXT'
,p_display_order=>158
,p_column_identifier=>'BY'
,p_column_label=>'Kto Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20727548416273638)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>168
,p_column_identifier=>'BZ'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20892370510314025)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'208924'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'FK_RELATION1:FK_RELATION2:JAHR:MONAT:PK_REL_LEX_LEX:BELEGDAT:ABSCHLUSS:BELEG:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:RELATION:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST'
||unistr('_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:\00DC')
||unistr('BERGABEDATUM_AN_STB:SEL_RELATION:FK_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_DUPL_STATUS:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:FK_BELEGDAT:FK_JOURDAT:PK_REL_LEX_KTO_BEL:FK_INP_BELEGE_ALL:')
||'FK_STEUER_MONAT:FK_STEUER_VORANMELDG::STD_NAME:PK_INP_BELEGE_ALL:KTO_BUCHUNGSTEXT:KTOKAT_KATEGORIE'
,p_sort_column_1=>'BUCHUNGSTEXT'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR:FK_STEUER_MONAT:MONAT:FK_INP_BELEGE_ALL:PK_REL_LEX_LEX:PK_INP_BELEGE_ALL'
,p_break_enabled_on=>'JAHR:FK_INP_BELEGE_ALL:PK_REL_LEX_LEX:PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20962566356727414)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'betr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAGEUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BETRAGEUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D1D1D1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20963707978727415)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'habenkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("HABENKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D9D9D9'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20964543278727415)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'sollkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SOLLKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#DBD2DB'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20964993684727415)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STD_NAME'
,p_operator=>'='
,p_expr=>'Storno'
,p_condition_sql=>' (case when ("STD_NAME" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20962960125727414)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'habenkto_v'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'!='
,p_expr=>'1460'
,p_condition_sql=>' (case when ("HABENKTO" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>12
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20964154570727415)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'sollkto_v'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'!='
,p_expr=>'1460'
,p_condition_sql=>' (case when ("SOLLKTO" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>12
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20963394529727414)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'chk_bar_einz'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'='
,p_expr=>'1600'
,p_condition_sql=>' (case when ("HABENKTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20962135349727414)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MONAT'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>'"MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(20965310906727417)
,p_report_id=>wwv_flow_api.id(20892370510314025)
,p_name=>'Row text contains ''2018/1685/0'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'2018/1685/0'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20726506682273628)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20726619586273629)
,p_name=>'P381_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(20726506682273628)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 2018, 2018 from dual',
'union',
'select 2019, 2019 from dual',
'union',
'select 2020, 2020 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
