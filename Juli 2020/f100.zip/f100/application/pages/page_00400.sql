prompt --application/pages/page_00400
begin
--   Manifest
--     PAGE: 00400
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>400
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Niederschlagsmenge'
,p_page_mode=>'MODAL'
,p_step_title=>'Niederschlagsmenge'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44302042836637501)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1000'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200609175518'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41130372186469825)
,p_plug_name=>'Niederschlagsmenge'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7673105345527539)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_WET_NIEDERSCHLAGSMENGE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(84710487109572919)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select arb.datum',
'  from T_wet_NIEDERSCHLAGSMENGE ndlm',
'    join t_bas_kal_arbeitstage arb on arb.pk_bas_Kal_arbeitstage = ndlm.fk_bas_kal_datum',
'',
'where ndlm.fk_loc_location = :P400_FK_loc_location',
'and arb.jahr = :P400_jahr'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(84710888489572919)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:RP:P400_PK_NIEDERSCHLAGSMENGE:\#PK_NIEDERSCHLAGSMENGE#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>84710888489572919
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43572018824103164)
,p_db_column_name=>'DATUM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(84721276259633835)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'435760'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'DATUM'
,p_sort_column_1=>'ARB_JAHR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ARB_MONAT'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'ARB_TAG'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0'
,p_break_enabled_on=>'0:0:0:0'
,p_sum_columns_on_break=>'NIEDERSCHLAGSMENGE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43578213599157803)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(41130372186469825)
,p_button_name=>'Copy'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Copy'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41138105306469839)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(41130372186469825)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P400_PK_WET_NIEDERSCHLAGSMENGE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41136903403469837)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(41130372186469825)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:399:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41138522744469839)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(41130372186469825)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P400_PK_WET_NIEDERSCHLAGSMENGE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41137762723469839)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(41130372186469825)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P400_PK_WET_NIEDERSCHLAGSMENGE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(41138803002469840)
,p_branch_action=>'f?p=&APP_ID.:399:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41066005483599530)
,p_name=>'P400_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41066272897599532)
,p_name=>'P400_FLG_KAL_AUFSTELLTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_default=>'0'
,p_prompt=>'Flg Kal Aufstelltag'
,p_source=>'FLG_KAL_AUFSTELLTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:nein;0,ja;1'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'2'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41131074621469831)
,p_name=>'P400_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jahr'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41131410387469834)
,p_name=>'P400_BAS_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Bas Datum'
,p_source=>'DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41132232503469834)
,p_name=>'P400_NIEDERSCHLAGSMENGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Niederschlagsmenge'
,p_source=>'NIEDERSCHLAGSMENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41132681260469834)
,p_name=>'P400_EINHEIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_default=>'l'
,p_prompt=>'Einheit'
,p_source=>'EINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41133026461469834)
,p_name=>'P400_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43578086564157801)
,p_name=>'P400_FLG_KAL_ABBAUTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_default=>'0'
,p_prompt=>'Flg Kal Abbautag'
,p_source=>'FLG_KAL_ABBAUTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:nein;0,ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'2'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46121889422988319)
,p_name=>'P400_FK_LOC_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Fk Loc Location'
,p_source=>'FK_LOC_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location || '' ('' || pk_loc_location || '')'' , pk_loc_location',
'from v_loc_location',
'where fk_bas_loc_location_type = 401'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46121983134988320)
,p_name=>'P400_PK_WET_NIEDERSCHLAGSMENGE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Pk Wet Niederschlagsmenge'
,p_source=>'PK_WET_NIEDERSCHLAGSMENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(46122039421988321)
,p_name=>'P400_FK_BAS_KAL_DATUM'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(41130372186469825)
,p_item_source_plug_id=>wwv_flow_api.id(41130372186469825)
,p_prompt=>'Fk Bas Kal Datum'
,p_source=>'FK_BAS_KAL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum, pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7695378527527568)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(41139712681469842)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(41130372186469825)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Niederschlagsmenge'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43578360301157804)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'copy'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  insert into t_niederschlagsmenge (',
'',
'       jAHR,',
'      DATUM,',
'       FK_DATUM,',
'       NIEDERSCHLAGSMENGE,',
'       EINHEIT,',
'       COMM,',
'     CREATED_AT,',
'       FK_LOCATION,',
'       FLG_AUFSTELLTAG,',
'      flg_abbautag',
'  ',
'  ',
'  )',
'  ',
'  ',
'  values (',
'',
'       :P400_jAHR,',
'      :P400_DATUM,',
'       :P400_FK_DATUM,',
'       :P400_NIEDERSCHLAGSMENGE,',
'       :P400_EINHEIT,',
'       :P400_COMM,',
'     :P400_CREATED_AT,',
'       :P400_FK_LOCATION,',
'       :P400_FLG_AUFSTELLTAG,',
'      :P400_flg_abbautag',
'  );',
'  commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43578213599157803)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(41139343065469842)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(41130372186469825)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Niederschlagsmenge'
);
wwv_flow_api.component_end;
end;
/
