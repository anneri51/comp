prompt --application/pages/page_00407
begin
--   Manifest
--     PAGE: 00407
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>407
,p_user_interface_id=>wwv_flow_api.id(7706626501527598)
,p_name=>'Termine'
,p_step_title=>'Termine'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(44303882915666971)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524091159'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(43321777525667828)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7672604522527537)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_TERMIN,',
'       DATUM,',
'       DESCR,',
'       COMM,',
'       CREATE_AT,',
'       WDH,',
'       FK_INVENTAR,',
'       FK_INP_BELEGE_ALL,',
'       FK_PROJEKT,',
'       FK_STUNDENZETTE,',
'       FK_MAIN_KEY,',
'       FK_LOCATION,',
'       FK_LAND,',
'       COLUMN2,',
'       FK_PLZ_ORT,',
'       FK_ADRESSE_SCHNELL,',
'       FK_STATUS,',
'       FK_TERMIN_TYP,',
'       DATUM_NEXT,',
'       WDH1',
'  from T_TERMINE ter',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(43322124566667828)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.:RP:P408_PK_TERMIN:\#PK_TERMIN#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>43322124566667828
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43322292246667832)
,p_db_column_name=>'PK_TERMIN'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Termin'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43323087577667842)
,p_db_column_name=>'DESCR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43323471147667842)
,p_db_column_name=>'COMM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43323814635667842)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43324607019667842)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43325013935667843)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43325488101667843)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43325845518667843)
,p_db_column_name=>'FK_STUNDENZETTE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Stundenzette'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240581143616321)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240665711616322)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240703000616323)
,p_db_column_name=>'FK_LAND'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240849401616324)
,p_db_column_name=>'COLUMN2'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>'Column2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43240901636616325)
,p_db_column_name=>'FK_PLZ_ORT'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Fk Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43241018325616326)
,p_db_column_name=>'FK_ADRESSE_SCHNELL'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Fk Adresse Schnell'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43241126181616327)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43241275371616328)
,p_db_column_name=>'FK_TERMIN_TYP'
,p_display_order=>90
,p_column_identifier=>'S'
,p_column_label=>'Fk Termin Typ'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242126209616337)
,p_db_column_name=>'DATUM'
,p_display_order=>100
,p_column_identifier=>'T'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242580500616341)
,p_db_column_name=>'WDH'
,p_display_order=>110
,p_column_identifier=>'U'
,p_column_label=>'Wdh'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242675870616342)
,p_db_column_name=>'DATUM_NEXT'
,p_display_order=>120
,p_column_identifier=>'V'
,p_column_label=>'Datum Next'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43242705427616343)
,p_db_column_name=>'WDH1'
,p_display_order=>130
,p_column_identifier=>'W'
,p_column_label=>'Wdh1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(43337930385774348)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'433380'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_TERMIN:DESCR:COMM:CREATE_AT:FK_FK_INVENTAR:FK_INP_BELEGE_ALL:FK_PROJEKT:FK_STUNDENZETTE:FK_MAIN_KEY:FK_LOCATION:FK_LAND:COLUMN2:FK_PLZ_ORT:FK_ADRESSE_SCHNELL:FK_STATUS:FK_TERMIN_TYP:DATUM:WDH:DATUM_NEXT:WDH1'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43327447694667853)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(43321777525667828)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7695842909527573)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.:408'
);
wwv_flow_api.component_end;
end;
/
