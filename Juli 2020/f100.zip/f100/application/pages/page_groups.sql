prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42861002794232885)
,p_group_name=>'01  - Allgemein'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42861136434236736)
,p_group_name=>'02 - Import'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42866741590295131)
,p_group_name=>'03 - Einkauf - Artikel'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42860323612223917)
,p_group_name=>'04 - Buchhaltung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869453008316864)
,p_group_name=>'04 - Buchhaltung - Belege'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42886081086432219)
,p_group_name=>'04 - Buchhaltung - Belege - Arbeit'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42885805042427536)
,p_group_name=>'04 - Buchhaltung - Belege - Auto'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42892390626467717)
,p_group_name=>'04 - Buchhaltung - Belege - Kleidung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42886027507430877)
,p_group_name=>'04 - Buchhaltung - Belege - Krankenkasse'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42886188592433667)
,p_group_name=>'04 - Buchhaltung - Belege - Reise'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42892366292466303)
,p_group_name=>'04 - Buchhaltung - Belege - Telefon'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42885974540429369)
,p_group_name=>'04 - Buchhaltung - Belege - Wohnung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869730020324050)
,p_group_name=>'04 - Buchhaltung - Buchungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869195534312536)
,p_group_name=>'04 - Buchhaltung - Konten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869320059313897)
,p_group_name=>'04 - Buchhaltung - Kontenplan'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869612033322303)
,p_group_name=>unistr('04 - Buchhaltung - Kontoausz\00FCge')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42901582232549956)
,p_group_name=>'04 - Buchhaltung - Kontrolle'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869485845319322)
,p_group_name=>'04 - Buchhaltung - Rechnungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42881936682393325)
,p_group_name=>'04 - Buchhaltung - Steuer'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(12169912235547744)
,p_group_name=>'04 - Buchhaltung - Verpflegungsmehraufwand'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42870062622330169)
,p_group_name=>'06 - Inventare'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42862362175257547)
,p_group_name=>'100 - Stammdaten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42862992502268653)
,p_group_name=>'101 - Basisdaten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42871455341341817)
,p_group_name=>'300 - Testseiten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42896149436500086)
,p_group_name=>'400 - Demo'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42860244778222425)
,p_group_name=>'600 - Data'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42930713606718074)
,p_group_name=>'87 - Dokumente'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42930510606714158)
,p_group_name=>'88 - Internet'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42924821574681713)
,p_group_name=>'89 - Todo'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42895035126488081)
,p_group_name=>'90 - Bilder'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42883777108408044)
,p_group_name=>'91 - Kontakte'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42875355428359647)
,p_group_name=>'92 - Zuordungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42863836018282035)
,p_group_name=>'93 - Projekte'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42869878746326130)
,p_group_name=>'93 - Projekte - Stundenzettel'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42863750944281147)
,p_group_name=>unistr('94 - Lehrg\00E4nge')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42863563640275431)
,p_group_name=>'95 - Termine'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42861723561245961)
,p_group_name=>'96 - Wetter'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42862188611255483)
,p_group_name=>'98 - Adressen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(42860129893221480)
,p_group_name=>'99 - Geo'
);
wwv_flow_api.component_end;
end;
/
