prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44301322069624425)
,p_group_name=>'01  - Allgemein'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44301455709628276)
,p_group_name=>'02 - Import'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44307060865686671)
,p_group_name=>'03 - Einkauf - Artikel'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44300642887615457)
,p_group_name=>'04 - Buchhaltung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44309772283708404)
,p_group_name=>'04 - Buchhaltung - Belege'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44326400361823759)
,p_group_name=>'04 - Buchhaltung - Belege - Arbeit'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44326124317819076)
,p_group_name=>'04 - Buchhaltung - Belege - Auto'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44332709901859257)
,p_group_name=>'04 - Buchhaltung - Belege - Kleidung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44326346782822417)
,p_group_name=>'04 - Buchhaltung - Belege - Krankenkasse'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44326507867825207)
,p_group_name=>'04 - Buchhaltung - Belege - Reise'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44332685567857843)
,p_group_name=>'04 - Buchhaltung - Belege - Telefon'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44326293815820909)
,p_group_name=>'04 - Buchhaltung - Belege - Wohnung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44310049295715590)
,p_group_name=>'04 - Buchhaltung - Buchungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44309514809704076)
,p_group_name=>'04 - Buchhaltung - Konten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44309639334705437)
,p_group_name=>'04 - Buchhaltung - Kontenplan'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44309931308713843)
,p_group_name=>unistr('04 - Buchhaltung - Kontoausz\00FCge')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44341901507941496)
,p_group_name=>'04 - Buchhaltung - Kontrolle'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44309805120710862)
,p_group_name=>'04 - Buchhaltung - Rechnungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44322255957784865)
,p_group_name=>'04 - Buchhaltung - Steuer'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(13610231510939284)
,p_group_name=>'04 - Buchhaltung - Verpflegungsmehraufwand'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44310381897721709)
,p_group_name=>'06 - Inventare'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44302681450649087)
,p_group_name=>'100 - Stammdaten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44303311777660193)
,p_group_name=>'101 - Basisdaten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44311774616733357)
,p_group_name=>'300 - Testseiten'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44336468711891626)
,p_group_name=>'400 - Demo'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44300564053613965)
,p_group_name=>'600 - Data'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44371032882109614)
,p_group_name=>'87 - Dokumente'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44370829882105698)
,p_group_name=>'88 - Internet'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44365140850073253)
,p_group_name=>'89 - Todo'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44335354401879621)
,p_group_name=>'90 - Bilder'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44324096383799584)
,p_group_name=>'91 - Kontakte'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44315674703751187)
,p_group_name=>'92 - Zuordungen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44304155293673575)
,p_group_name=>'93 - Projekte'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44310198021717670)
,p_group_name=>'93 - Projekte - Stundenzettel'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44304070219672687)
,p_group_name=>unistr('94 - Lehrg\00E4nge')
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44303882915666971)
,p_group_name=>'95 - Termine'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44302042836637501)
,p_group_name=>'96 - Wetter'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44302507886647023)
,p_group_name=>'98 - Adressen'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(44300449168613020)
,p_group_name=>'99 - Geo'
);
wwv_flow_api.component_end;
end;
/
