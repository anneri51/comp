prompt --application/shared_components/navigation/breadcrumbs/verpflegungsmehraufwand
begin
--   Manifest
--     MENU: Verpflegungsmehraufwand
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(13608881527914575)
,p_name=>'Verpflegungsmehraufwand'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13609263515917751)
,p_parent_id=>0
,p_short_name=>'Verpflegungsmehraufwand'
,p_link=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:::'
,p_page_id=>326
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13609467572921007)
,p_parent_id=>wwv_flow_api.id(13609263515917751)
,p_short_name=>'Verpflegungsmehraufwand_erzeugen'
,p_link=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.:::'
,p_page_id=>327
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13609654009925887)
,p_parent_id=>wwv_flow_api.id(13609263515917751)
,p_short_name=>'Verpflegungsmehraufwand Detail'
,p_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:::'
,p_page_id=>329
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13609875268930493)
,p_parent_id=>wwv_flow_api.id(13609654009925887)
,p_short_name=>'Verpflegungsmehraufwand Detail'
,p_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:::'
,p_page_id=>330
);
wwv_flow_api.component_end;
end;
/
