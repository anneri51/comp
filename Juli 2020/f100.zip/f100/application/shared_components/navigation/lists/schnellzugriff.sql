prompt --application/shared_components/navigation/lists/schnellzugriff
begin
--   Manifest
--     LIST: Schnellzugriff
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>101
,p_default_id_offset=>1600316168505681
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(8048992676452464)
,p_name=>'Schnellzugriff'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8049244334452482)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Kontoauszug'
,p_list_item_link_target=>'f?p=&APP_ID.:94:&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8049591340452483)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Allgemeine Belege'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8050025319452484)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Allgemeine Belege Erfassung'
,p_list_item_link_target=>'f?p=&APP_ID.:184:&SESSION.:'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
