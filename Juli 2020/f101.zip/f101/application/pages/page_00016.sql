prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>2201717242293144
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_api.id(47574086381610126)
,p_name=>unistr('Navigation_Men\00FCs')
,p_step_title=>unistr('Navigation_Men\00FCs')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200614161158'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(49467360229483226)
,p_plug_name=>unistr('Navigation_Men\00FCs')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>' select * from APEX_APPLICATION_list_entries where list_name = ''Desktop Navigation Menu'' and application_id = 101'
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(49467445216483226)
,p_name=>unistr('Navigation_Men\00FCs')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>49467445216483226
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49467844206483248)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49468227335483251)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49468621063483253)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49469015040483253)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49469420751483253)
,p_db_column_name=>'LIST_NAME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'List Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49469828499483254)
,p_db_column_name=>'PARENT_ENTRY_TEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Parent Entry Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49470252997483254)
,p_db_column_name=>'DISPLAY_SEQUENCE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Display Sequence'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49470674045483254)
,p_db_column_name=>'ENTRY_TEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Entry Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49471042870483254)
,p_db_column_name=>'ENTRY_TARGET'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Entry Target'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49471479486483254)
,p_db_column_name=>'ENTRY_IMAGE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Entry Image'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49471819036483256)
,p_db_column_name=>'ENTRY_IMAGE_ATTRIBUTES'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Entry Image Attributes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49472266478483256)
,p_db_column_name=>'ENTRY_IMAGE_ALT_ATTRIBUTE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Entry Image Alt Attribute'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49472637120483256)
,p_db_column_name=>'CURRENT_FOR_PAGES_TYPE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Current For Pages Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49473019104483257)
,p_db_column_name=>'CURRENT_FOR_PAGES_TYPE_CODE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Current For Pages Type Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49473480487483257)
,p_db_column_name=>'CURRENT_FOR_PAGES_EXPRESSION'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Current For Pages Expression'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49473812454483257)
,p_db_column_name=>'CONDITION_TYPE'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Condition Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49474229590483259)
,p_db_column_name=>'CONDITION_TYPE_CODE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Condition Type Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49474620194483259)
,p_db_column_name=>'CONDITION_EXPRESSION1'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Condition Expression1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49475011165483260)
,p_db_column_name=>'CONDITION_EXPRESSION2'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Condition Expression2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49475471282483260)
,p_db_column_name=>'COUNT_CLICKS'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Count Clicks'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49475898807483260)
,p_db_column_name=>'CLICK_COUNT_CATEGORY'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Click Count Category'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49476280518483262)
,p_db_column_name=>'ENTRY_ATTRIBUTE_01'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Entry Attribute 01'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49476617225483262)
,p_db_column_name=>'ENTRY_ATTRIBUTE_02'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Entry Attribute 02'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49477094399483264)
,p_db_column_name=>'ENTRY_ATTRIBUTE_03'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Entry Attribute 03'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49477481357483264)
,p_db_column_name=>'ENTRY_ATTRIBUTE_04'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Entry Attribute 04'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49477852055483264)
,p_db_column_name=>'ENTRY_ATTRIBUTE_05'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Entry Attribute 05'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49478248912483264)
,p_db_column_name=>'ENTRY_ATTRIBUTE_06'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Entry Attribute 06'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49478657890483265)
,p_db_column_name=>'ENTRY_ATTRIBUTE_07'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Entry Attribute 07'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49479075282483265)
,p_db_column_name=>'ENTRY_ATTRIBUTE_08'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Entry Attribute 08'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49479481903483265)
,p_db_column_name=>'ENTRY_ATTRIBUTE_09'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Entry Attribute 09'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49479891675483267)
,p_db_column_name=>'ENTRY_ATTRIBUTE_10'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Entry Attribute 10'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49480244881483267)
,p_db_column_name=>'TRANSLATE_ATTRIBUTES'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Translate Attributes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49480658430483267)
,p_db_column_name=>'BUILD_OPTION'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Build Option'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49481070409483268)
,p_db_column_name=>'AUTHORIZATION_SCHEME'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Authorization Scheme'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49481470771483268)
,p_db_column_name=>'AUTHORIZATION_SCHEME_ID'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Authorization Scheme Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49481838102483268)
,p_db_column_name=>'PRIMARY_APPLICATION_ID'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Primary Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49482201240483268)
,p_db_column_name=>'TRANSLATED_APP_LANGUAGE'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Translated App Language'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49482672230483270)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49483058636483270)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49483409294483271)
,p_db_column_name=>'COMPONENT_COMMENT'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Component Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49483875547483271)
,p_db_column_name=>'LIST_ID'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'List Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49484212693483271)
,p_db_column_name=>'LIST_ENTRY_PARENT_ID'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'List Entry Parent Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49484682537483273)
,p_db_column_name=>'LIST_ENTRY_ID'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'List Entry Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49485073068483273)
,p_db_column_name=>'COMPONENT_SIGNATURE'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Component Signature'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(49485670232484671)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'494857'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:APPLICATION_NAME:LIST_NAME:PARENT_ENTRY_TEXT:DISPLAY_SEQUENCE:ENTRY_TEXT:ENTRY_TARGET:ENTRY_IMAGE:ENTRY_IMAGE_ATTRIBUTES:ENTRY_IMAGE_ALT_ATTRIBUTE:CURRENT_FOR_PAGES_TYPE:CURRENT_FOR_PAGES_TYPE_CODE:CURR'
||'ENT_FOR_PAGES_EXPRESSION:CONDITION_TYPE:CONDITION_TYPE_CODE:CONDITION_EXPRESSION1:CONDITION_EXPRESSION2:COUNT_CLICKS:CLICK_COUNT_CATEGORY:ENTRY_ATTRIBUTE_01:ENTRY_ATTRIBUTE_02:ENTRY_ATTRIBUTE_03:ENTRY_ATTRIBUTE_04:ENTRY_ATTRIBUTE_05:ENTRY_ATTRIBUTE_0'
||'6:ENTRY_ATTRIBUTE_07:ENTRY_ATTRIBUTE_08:ENTRY_ATTRIBUTE_09:ENTRY_ATTRIBUTE_10:TRANSLATE_ATTRIBUTES:BUILD_OPTION:AUTHORIZATION_SCHEME:AUTHORIZATION_SCHEME_ID:PRIMARY_APPLICATION_ID:TRANSLATED_APP_LANGUAGE:LAST_UPDATED_BY:LAST_UPDATED_ON:COMPONENT_COMM'
||'ENT:LIST_ID:LIST_ENTRY_PARENT_ID:LIST_ENTRY_ID:COMPONENT_SIGNATURE'
);
wwv_flow_api.component_end;
end;
/
