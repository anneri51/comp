prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>2201717242293144
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_api.id(47574086381610126)
,p_name=>'table_columns_compare'
,p_step_title=>'table_columns_compare'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200628035556'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(54669942693715682)
,p_plug_name=>'table_columns_compare'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with all_obj as (select * from all_objects),',
'tab_ as (select ut.*, rownum rnr, row_number() over (partition by column_id order by table_name) rnr1 , row_number() over (partition by table_name order by column_id) rnr2 from user_tab_cols ut)',
'select table_name, column_name, data_type, data_length , column_id, rnr, rnr1, rnr2 from tab_ where instr(table_name, ''INP_BELEGE_ALL'')>0 and substr(table_name,1,1) =''T''',
';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(54670091957715682)
,p_name=>'table_columns_compare'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>54670091957715682
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54670438492715706)
,p_db_column_name=>'TABLE_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Table Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54670800987715734)
,p_db_column_name=>'COLUMN_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Column Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54671281368715734)
,p_db_column_name=>'DATA_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Data Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54671680793715735)
,p_db_column_name=>'DATA_LENGTH'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Data Length'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54672057982715735)
,p_db_column_name=>'COLUMN_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Column Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54672444049715737)
,p_db_column_name=>'RNR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54672864872715739)
,p_db_column_name=>'RNR1'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54673272026715739)
,p_db_column_name=>'RNR2'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Rnr2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(54673823508717954)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'546739'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABLE_NAME:COLUMN_NAME:DATA_TYPE:DATA_LENGTH:COLUMN_ID:RNR:RNR1:RNR2'
);
wwv_flow_api.component_end;
end;
/
