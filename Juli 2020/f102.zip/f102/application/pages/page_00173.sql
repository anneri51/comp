prompt --application/pages/page_00173
begin
--   Manifest
--     PAGE: 00173
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>173
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>'Familien'
,p_step_title=>'Familien'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'// Modal-Dialog initialisieren',
'function initDialog ( pRegId , pTitle , pWidth , pHeight ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( {',
'      autoOpen:   false,',
'      bgiframe:   true,',
'      modal:      false,',
'      minHeight:  pHeight,',
'      width:      pWidth,',
'      minWidth:   pWidth,',
'      title:      pTitle,',
'      resizable: true,',
'      closeOnEscape : true',
'  } )',
'}',
'',
unistr('// setzt die Breite des Dialogs auf (nahezu) genau die f\00FCr den Report ben\00F6tigte Breite'),
'function setzeDialogBreite ( pRegId ) {',
'  var $vRegion  = $( "#" + pRegId );',
'  var vMinWidth = $vRegion.dialog ( "option" , "minWidth" );',
'  var vWidth    = $vRegion.find ( "table[id^=''report_'']" ).width();',
'  //',
'  $vRegion.dialog ( "option" , "width" , Math.max ( vMinWidth , vWidth + 30 ) );',
'}',
'',
'',
'// zeigt die Reports-Region als jQuery-Dialog an',
'function showDialog ( pRegId ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( "open" );',
'  setzeDialogBreite ( pRegId );',
'',
'}',
'',
'',
'// jQuery-Dialog schliessen',
'function closeDialog (pRegId) {',
'  $("#" + pRegId).dialog("close");',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160125103833'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3329321360532609)
,p_plug_name=>'Familien'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM Familie'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3329504888532609)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>3329504888532609
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3333629250536046)
,p_db_column_name=>'FAMILIE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Familie'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'FAMILIE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3495521687578349)
,p_db_column_name=>'PK_FAMILIE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Pk Familie'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_FAMILIE'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3330302899532610)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33304'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>500
,p_report_columns=>'PK_FAMILIE:FAMILIE:'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(3333219233532612)
,p_branch_action=>'f?p=&APP_ID.:173:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3332702478532611)
,p_name=>'daShowOrte'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'daShowOrte'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3333016368532611)
,p_event_id=>wwv_flow_api.id(3332702478532611)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Orte'',''Erfassungsmaske f\00FCr neue Orte\00C4);'),
'showDialog(''md_Orte''):'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3332314144532611)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of ORT'
,p_attribute_02=>'ORT'
,p_attribute_03=>'P173_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3332522697532611)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_FOR_PAGES'
,p_attribute_04=>'171'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3330909347532610)
);
wwv_flow_api.component_end;
end;
/
