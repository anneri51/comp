prompt --application/pages/page_00175
begin
--   Manifest
--     PAGE: 00175
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>175
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>'Report 1'
,p_step_title=>'Report 1'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160205134904'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(5641095907343038)
,p_name=>'Report 1'
,p_template=>wwv_flow_api.id(3295300200618255)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY_3'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion,',
'  p.*',
'from bilder_tab',
' left join person_bild pb on pb.fk_bild = bilder_tab.id',
' left join person p on p.pk_person = pb.fk_person'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5641434070343049)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5641890796343053)
,p_query_column_id=>2
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>2
,p_column_heading=>'Dateiname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5642290271343054)
,p_query_column_id=>3
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>3
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5642682594343055)
,p_query_column_id=>4
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>4
,p_column_heading=>'Bildgroesse'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5643052928343055)
,p_query_column_id=>5
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>5
,p_column_heading=>'Breite Px'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5643439961343055)
,p_query_column_id=>6
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>6
,p_column_heading=>'Hoehe Px'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5643877583343056)
,p_query_column_id=>7
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>7
,p_column_heading=>'Bild Aktion'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5750309981460265)
,p_query_column_id=>8
,p_column_alias=>'PK_PERSON'
,p_column_display_sequence=>8
,p_column_heading=>'Pk Person'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5750748940460266)
,p_query_column_id=>9
,p_column_alias=>'NAME'
,p_column_display_sequence=>9
,p_column_heading=>'Name'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5751149110460266)
,p_query_column_id=>10
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>10
,p_column_heading=>'Vorname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5751544060460267)
,p_query_column_id=>11
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>11
,p_column_heading=>'Geschlecht'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10388450297445757)
,p_query_column_id=>12
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>25
,p_column_heading=>'Geboren Am'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5752359416460267)
,p_query_column_id=>13
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>12
,p_column_heading=>'Gestorben Am'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5752761783460268)
,p_query_column_id=>14
,p_column_alias=>'FK_GEBURTSORT'
,p_column_display_sequence=>13
,p_column_heading=>'Fk Geburtsort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5753115123460268)
,p_query_column_id=>15
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>14
,p_column_heading=>'Beschreibung'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5753584705460268)
,p_query_column_id=>16
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>15
,p_column_heading=>'Geburtsname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5753977157460269)
,p_query_column_id=>17
,p_column_alias=>'TITEL'
,p_column_display_sequence=>16
,p_column_heading=>'Titel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5754371662460269)
,p_query_column_id=>18
,p_column_alias=>'ADELSTITEL'
,p_column_display_sequence=>17
,p_column_heading=>'Adelstitel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5754704072460269)
,p_query_column_id=>19
,p_column_alias=>'FK_STERBEORT'
,p_column_display_sequence=>18
,p_column_heading=>'Fk Sterbeort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5755167286460269)
,p_query_column_id=>20
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>19
,p_column_heading=>'Rufname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5755510416460270)
,p_query_column_id=>21
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>20
,p_column_heading=>'Nr Ahnentafel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6666628311340461)
,p_query_column_id=>22
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>21
,p_column_heading=>'Creation Date'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6667047147340462)
,p_query_column_id=>23
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>22
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6667452841340462)
,p_query_column_id=>24
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>23
,p_column_heading=>'Modify Date'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6667841416340463)
,p_query_column_id=>25
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>24
,p_column_heading=>'Modified By'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5644237032343058)
,p_plug_name=>'Bild hochladen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3295300200618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5860197361542658)
,p_plug_name=>'Bildanzeige'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion,',
'  p.*',
'from bilder_tab',
' left join person_bild pb on pb.fk_bild = bilder_tab.id',
' left join person p on p.pk_person = pb.fk_person'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5860201563542663)
,p_name=>'Bildanzeige'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>5860201563542663
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5860560954542694)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5861764620542697)
,p_db_column_name=>'BREITE_PX'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Breite Px'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5862159290542700)
,p_db_column_name=>'HOEHE_PX'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Hoehe Px'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5862587262542701)
,p_db_column_name=>'DATEINAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Dateiname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5870901787545393)
,p_db_column_name=>'VORSCHAU'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Vorschau'
,p_sync_form_label=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5871324230545396)
,p_db_column_name=>'BILDGROESSE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Bildgroesse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5871793329545397)
,p_db_column_name=>'BILD_AKTION'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Bild Aktion'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5872194526545397)
,p_db_column_name=>'PK_PERSON'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Pk Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5872506337545397)
,p_db_column_name=>'NAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5872974781545398)
,p_db_column_name=>'VORNAME'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5873315002545398)
,p_db_column_name=>'GESCHLECHT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Geschlecht'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5874159562545399)
,p_db_column_name=>'GESTORBEN_AM'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Gestorben Am'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5874580806545399)
,p_db_column_name=>'FK_GEBURTSORT'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Fk Geburtsort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5874930452545400)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Beschreibung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5875307175545400)
,p_db_column_name=>'GEBURTSNAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Geburtsname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5875759227545400)
,p_db_column_name=>'TITEL'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Titel'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5876132863545401)
,p_db_column_name=>'ADELSTITEL'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Adelstitel'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5876510640545401)
,p_db_column_name=>'FK_STERBEORT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Fk Sterbeort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5876962460545401)
,p_db_column_name=>'RUFNAME'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Rufname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5877347895545402)
,p_db_column_name=>'NR_AHNENTAFEL'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Nr Ahnentafel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10384270592440042)
,p_db_column_name=>'GEBOREN_AM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Geboren Am'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10384896123440048)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10385506906440051)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10386297540440053)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10386962143440056)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5890386655561779)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'58904'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:BREITE_PX:HOEHE_PX:DATEINAME:VORSCHAU:BILDGROESSE:BILD_AKTION:PK_PERSON:NAME:VORNAME:GESCHLECHT:GESTORBEN_AM:FK_GEBURTSORT:BESCHREIBUNG:GEBURTSNAME:TITEL:ADELSTITEL:FK_STERBEORT:RUFNAME:NR_AHNENTAFEL:GEBOREN_AM:CREATION_DATE:CREATED_BY:MODIFY_DATE'
||':MODIFIED_BY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5644659181343058)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5644237032343058)
,p_button_name=>'P175_UPLOAD'
,p_button_static_id=>'P20_UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5550342904646573)
,p_button_image_alt=>'Datei hochladen'
,p_button_position=>'BODY'
,p_button_alignment=>'LEFT'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5645093871343060)
,p_name=>'P175_FILE_UPLOAD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5644237032343058)
,p_prompt=>'File Upload'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(3299619060618260)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'WWV_FLOW_FILES'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5645403008343077)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_filename  wwv_flow_files.filename%type;',
'',
' v_bild      blob := null;',
' v_thumb     blob := null;',
'',
' v_oi_bild   ordimage := null;',
' v_oi_thumb  ordimage := null;',
'',
' v_id BILDER_TAB.ID%TYPE;',
'begin',
'   begin',
'     -- Bild aus WWV_FLOW_FILES holen ...',
'     select blob_content, filename ',
'      into v_bild, v_filename ',
'     from wwv_flow_files',
'     where name = :P175_FILE_UPLOAD;',
'',
unistr('     -- Tempor\00E4ren LOB f\00FCr Thumbnail erzeugen'),
'     dbms_lob.createtemporary(v_thumb, true, dbms_lob.call);',
'',
unistr('     -- ORDIMAGE-Objekt f\00FCr Bild und Thumbnail erzeugen'),
'     v_oi_bild  := ordimage(v_bild);',
'     v_oi_bild.setproperties();',
'     v_oi_thumb := ordimage(v_thumb);',
'',
'     -- Thumbnail generieren',
'     v_oi_bild.processcopy(',
'       command => ''maxScale=100 100'',',
'       dest    => v_oi_thumb',
'     );',
'',
'     -- Bild und Thumbnail in Tabelle BILDER_TAB ablegen',
'     insert into bilder_tab (id, bild, thumbnail, dateiname)',
'     values (seq_bilder_tab.nextval, v_bild, v_oi_thumb.getcontent(), v_filename);',
'',
'     -- Bild aus WWV_FLOW_FILES entfernen',
'     delete from wwv_flow_files where name = :P175_FILE_UPLOAD;',
'',
unistr('     -- Tempor\00E4ren LOB freigeben'),
'     dbms_lob.freetemporary(v_thumb);',
'   exception ',
'     -- Im Fehlerfall nix machen; in der Praxis aber zumindest Logging!',
'     when NO_DATA_FOUND then null; ',
'     when TOO_MANY_ROWS then null; ',
'   end;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5644659181343058)
);
wwv_flow_api.component_end;
end;
/
