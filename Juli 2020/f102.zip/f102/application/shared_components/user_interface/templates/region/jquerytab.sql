prompt --application/shared_components/user_interface/templates/region/jquerytab
begin
--   Manifest
--     REGION TEMPLATE: JQUERYTAB
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_plug_template(
 p_id=>wwv_flow_api.id(3385524356555473)
,p_layout=>'TABLE'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#TITLE#',
'<div id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>',
'#BODY##SUB_REGION_HEADERS##SUB_REGIONS#',
'<div style="clear:both;"></div>',
'</div>',
'<link rel="stylesheet" href="#JQUERYUI_DIRECTORY#themes/base/jquery.ui.tabs.css" type="text/css" />',
'<script src="#JQUERYUI_DIRECTORY#ui/minified/jquery.ui.tabs.min.js" type="text/javascript"></script>'))
,p_sub_plug_header_template=>'<ul style="height: auto;">#ENTRIES#</ul>'
,p_sub_plug_header_entry_templ=>'<li><a href="##REGION_STATIC_ID#-tab-#SUB_REGION_ID#">#SUB_REGION_TITLE#</a></li>'
,p_sub_plug_template=>'<div id="#REGION_STATIC_ID#-tab-#SUB_REGION_ID#">#SUB_REGION#</div>'
,p_page_plug_template_name=>'jqueryTab'
,p_internal_name=>'JQUERYTAB'
,p_theme_id=>26
,p_theme_class_id=>21
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>wwv_flow_api.id(3388427416668518)
,p_plug_template_id=>wwv_flow_api.id(3385524356555473)
,p_name=>'Subregion'
,p_placeholder=>'SUB_REGIONS'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>wwv_flow_api.id(3388802015668518)
,p_plug_template_id=>wwv_flow_api.id(3385524356555473)
,p_name=>'Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.component_end;
end;
/
