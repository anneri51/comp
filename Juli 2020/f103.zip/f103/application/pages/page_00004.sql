prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'PLANES'
,p_step_title=>'PLANES'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190420230811'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4432671936830908)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4432689971830909)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4432885745830910)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4432948779830911)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7931185085026050)
,p_plug_name=>'Flugzeuge'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22993546817180756)
,p_plug_name=>'Planes'
,p_parent_plug_id=>wwv_flow_api.id(7931185085026050)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pl."PK_APL_PLANE", ',
'    pl."FK_MDT_MANDANT",',
'    pl."PLANE_NO",',
'    length(pl."IMAGE") "IMAGE",',
'    pl.DESCRIPTION,',
'    pl.FK_APL_PLANE_MODELL,',
'    pl.FK_APL_ENGINE_TYPE,',
'    pl.CABIN_OV_13000_FT,',
'    pl.BORD_00,',
'    pl.BOARDING_OPPORTUNITY,',
'    pl.CRUISING_SPEED_HG_20000_FT,',
'    pl.CRUISING_SPEED_UNIT,',
'    pl.WEIGHT_KERB_KG,',
'    pl.WEIGHT_TAKEOFF_MAX_KG,',
'    pl.PERMITTED_LOAD_KG,',
'    pl.CNT_PASSENGERS_MAX,',
'    pl.FUEL_TANK_SIZE_L,',
'    pl.CONSUMPTION_L,',
'    pl.RANGE_AVERAGE_FT,',
'    pl.DIST_TAKE_OFF_FT,',
'    pl.DIST_LANDING_FT,',
'    mdt.mandant,',
'    plt.PLANE_TYPE,',
'    plm.MODELL_NO,',
'    ple.engine_type,',
'    plmp.MAINT_PROGR',
'from "#OWNER#"."APL_PLANE" pl',
'  left join mdt_mandant mdt on mdt.pk_mdt_mandant = pl.fk_mdt_mandant',
'',
'  left join apl_plane_modell plm on plm.pk_apl_plane_modell  = pl.fk_apl_plane_modell',
'  left join apl_plane_type plt on plt.pk_apl_plane_type = plm.fk_apl_plane_type',
'  left join apl_engine_type ple on ple.pk_apl_engine_type = pl.fk_apl_engine_type',
'  left join apl_maint_progr plmp on plmp.pk_apl_maint_progr = pl.fk_apl_maint_progr',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22993905759180756)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:5:&APP_SESSION.::::P5_PK_APL_PLANE:#PK_APL_PLANE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>19218720068078634
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22994022462180759)
,p_db_column_name=>'PK_APL_PLANE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Apl Plane'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22994471153180761)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22994797591180761)
,p_db_column_name=>'PLANE_NO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Plane No'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3879644133907020)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>15
,p_column_identifier=>'F'
,p_column_label=>'Description'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3879822732907022)
,p_db_column_name=>'FK_APL_ENGINE_TYPE'
,p_display_order=>35
,p_column_identifier=>'H'
,p_column_label=>'Fk apl engine type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3879888086907023)
,p_db_column_name=>'CABIN_OV_13000_FT'
,p_display_order=>45
,p_column_identifier=>'I'
,p_column_label=>'Cabin ov 13000 ft'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880048495907024)
,p_db_column_name=>'BORD_00'
,p_display_order=>55
,p_column_identifier=>'J'
,p_column_label=>'Bord 00'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880118464907025)
,p_db_column_name=>'BOARDING_OPPORTUNITY'
,p_display_order=>65
,p_column_identifier=>'K'
,p_column_label=>'Boarding opportunity'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880220636907026)
,p_db_column_name=>'CRUISING_SPEED_HG_20000_FT'
,p_display_order=>75
,p_column_identifier=>'L'
,p_column_label=>'Cruising speed hg 20000 ft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880378135907027)
,p_db_column_name=>'CRUISING_SPEED_UNIT'
,p_display_order=>85
,p_column_identifier=>'M'
,p_column_label=>'Cruising speed unit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880479372907028)
,p_db_column_name=>'WEIGHT_KERB_KG'
,p_display_order=>95
,p_column_identifier=>'N'
,p_column_label=>'Weight kerb kg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880573259907029)
,p_db_column_name=>'WEIGHT_TAKEOFF_MAX_KG'
,p_display_order=>105
,p_column_identifier=>'O'
,p_column_label=>'Weight takeoff max kg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880588477907030)
,p_db_column_name=>'PERMITTED_LOAD_KG'
,p_display_order=>115
,p_column_identifier=>'P'
,p_column_label=>'Permitted load kg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880724478907031)
,p_db_column_name=>'CNT_PASSENGERS_MAX'
,p_display_order=>125
,p_column_identifier=>'Q'
,p_column_label=>'Cnt passengers max'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880861245907032)
,p_db_column_name=>'FUEL_TANK_SIZE_L'
,p_display_order=>135
,p_column_identifier=>'R'
,p_column_label=>'Fuel tank size l'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880924009907033)
,p_db_column_name=>'CONSUMPTION_L'
,p_display_order=>145
,p_column_identifier=>'S'
,p_column_label=>'Consumption l'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881004563907034)
,p_db_column_name=>'RANGE_AVERAGE_FT'
,p_display_order=>155
,p_column_identifier=>'T'
,p_column_label=>'Range average ft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881132469907035)
,p_db_column_name=>'DIST_TAKE_OFF_FT'
,p_display_order=>165
,p_column_identifier=>'U'
,p_column_label=>'Dist take off ft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881203841907036)
,p_db_column_name=>'DIST_LANDING_FT'
,p_display_order=>175
,p_column_identifier=>'V'
,p_column_label=>'Dist landing ft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881400557907038)
,p_db_column_name=>'IMAGE'
,p_display_order=>185
,p_column_identifier=>'X'
,p_column_label=>'Image'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:APL_PLANE:IMAGE:PK_APL_PLANE::::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881520147907039)
,p_db_column_name=>'FK_APL_PLANE_MODELL'
,p_display_order=>195
,p_column_identifier=>'Y'
,p_column_label=>'Fk apl plane modell'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881643333907040)
,p_db_column_name=>'MANDANT'
,p_display_order=>205
,p_column_identifier=>'Z'
,p_column_label=>'Mandant'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881757428907041)
,p_db_column_name=>'PLANE_TYPE'
,p_display_order=>215
,p_column_identifier=>'AA'
,p_column_label=>'Plane type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881823214907042)
,p_db_column_name=>'MODELL_NO'
,p_display_order=>225
,p_column_identifier=>'AB'
,p_column_label=>'Modell no'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881956992907043)
,p_db_column_name=>'ENGINE_TYPE'
,p_display_order=>235
,p_column_identifier=>'AC'
,p_column_label=>'Engine type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3882040344907044)
,p_db_column_name=>'MAINT_PROGR'
,p_display_order=>245
,p_column_identifier=>'AD'
,p_column_label=>'Maint progr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(23026503585219868)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'192514'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_APL_PLANE:MANDANT:PLANE_NO:IMAGE:PLANE_TYPE:MODELL_NO:ENGINE_TYPE:MAINT_PROGR:BORD_00:BOARDING_OPPORTUNITY:CRUISING_SPEED_HG_20000_FT:CRUISING_SPEED_UNIT:WEIGHT_KERB_KG:WEIGHT_TAKEOFF_MAX_KG:PERMITTED_LOAD_KG:CNT_PASSENGERS_MAX:FUEL_TANK_SIZE_L:CO'
||'NSUMPTION_L:RANGE_AVERAGE_FT:DIST_TAKE_OFF_FT:DIST_LANDING_FT:FK_APL_PLANE_MODELL:CABIN_OV_13000_FT:DESCRIPTION:FK_MDT_MANDANT:FK_APL_ENGINE_TYPE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22996082848180765)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7931185085026050)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5'
);
wwv_flow_api.component_end;
end;
/
