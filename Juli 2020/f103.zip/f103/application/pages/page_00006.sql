prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'CUSTOMER'
,p_step_title=>'CUSTOMER'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190328074857'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23003694910185424)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from org_org_unit'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(23004129393185424)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:7:&APP_SESSION.::::P7_PK_CST_CUSTOMER:#PK_CST_CUSTOMER#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>19228943702083302
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4019531332230343)
,p_db_column_name=>'COMPANY_NAME'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Company name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020335877230351)
,p_db_column_name=>'PK_ORG_ORG_UNIT'
,p_display_order=>40
,p_column_identifier=>'O'
,p_column_label=>'Pk org org unit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020402679230352)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>50
,p_column_identifier=>'P'
,p_column_label=>'Fk mdt mandant'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020551983230353)
,p_db_column_name=>'ORG_UNIT_NAME'
,p_display_order=>60
,p_column_identifier=>'Q'
,p_column_label=>'Org unit name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020636939230354)
,p_db_column_name=>'FK_CON_CONTACT'
,p_display_order=>70
,p_column_identifier=>'R'
,p_column_label=>'Fk con contact'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020749052230355)
,p_db_column_name=>'ACTIVE'
,p_display_order=>80
,p_column_identifier=>'S'
,p_column_label=>'Active'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020876256230356)
,p_db_column_name=>'ACTIVE_FROM'
,p_display_order=>90
,p_column_identifier=>'T'
,p_column_label=>'Active from'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4020925488230357)
,p_db_column_name=>'ACTIVE_TO'
,p_display_order=>100
,p_column_identifier=>'U'
,p_column_label=>'Active to'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021000447230358)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>110
,p_column_identifier=>'V'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021121684230359)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>120
,p_column_identifier=>'W'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021234997230360)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>130
,p_column_identifier=>'X'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021358549230361)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>140
,p_column_identifier=>'Y'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021413298230362)
,p_db_column_name=>'FK_ORG_ORG_UNIT_TYPE'
,p_display_order=>150
,p_column_identifier=>'Z'
,p_column_label=>'Fk org org unit type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4021481886230363)
,p_db_column_name=>'FK_ORG_ORG_UNIT_REL_TYPE'
,p_display_order=>160
,p_column_identifier=>'AA'
,p_column_label=>'Fk org org unit rel type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(23027171193220009)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'192520'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CUSTOMER_CUSTOMER_NAME:COMPANY_NAME:FK_COM_COMPANY_TYPE_MAIN:PK_ORG_ORG_UNIT:ORG_UNIT_NAME:FK_CON_CONTACT:ACTIVE:ACTIVE_FROM:ACTIVE_TO:CREATED_AT:CREATED_BY:MODIFIED_AT:MODIFIED_BY:FK_ORG_ORG_UNIT_TYPE:FK_ORG_ORG_UNIT_REL_TYPE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23005828090185427)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(23003694910185424)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7'
);
wwv_flow_api.component_end;
end;
/
