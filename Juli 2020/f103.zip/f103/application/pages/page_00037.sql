prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>37
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Flights'
,p_step_title=>'Flights'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190421083538'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3895833125434004)
,p_plug_name=>'Flights'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7557957389886726)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(3895833125434004)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'vfli."PK_FLI_FLIGHT", ',
'vfli."FK_MDT_MANDANT",',
'vfli."DEPARTURE",',
'vfli."ARRIVAL",',
'vfli."DEPARTURE_TIME",',
'vfli."ARRIVAL_TIME",',
'vfli."DURATION",',
'vfli."ADDITIONAL_TIMESLOTS",',
'vfli."FK_ADDITIONAL_TIMESLOTTYPE",',
'vfli."FK_APL_PLANE",',
'pl."PK_APL_PLANE",',
'length(pl.image) image',
'from "#OWNER#"."V_FLI_FLIGHT" vfli',
'  left join apl_plane pl on pl.pk_apl_plane = vfli.fk_apl_plane',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7558370794886728)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:38:&APP_SESSION.::::P38_PK_FLI_FLIGHT:#PK_FLI_FLIGHT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>5658044338850628
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7558450467886734)
,p_db_column_name=>'PK_FLI_FLIGHT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Fli Flight'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7558836165886735)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7559235434886736)
,p_db_column_name=>'DEPARTURE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Departure'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7559721085886737)
,p_db_column_name=>'ARRIVAL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Arrival'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7560073670886739)
,p_db_column_name=>'DEPARTURE_TIME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Departure Time'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7560474029886740)
,p_db_column_name=>'ARRIVAL_TIME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Arrival Time'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7560914920886741)
,p_db_column_name=>'DURATION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Duration'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7561229133886742)
,p_db_column_name=>'ADDITIONAL_TIMESLOTS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Additional Timeslots'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7561705397886744)
,p_db_column_name=>'FK_ADDITIONAL_TIMESLOTTYPE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Additional Timeslottype'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7562097176886744)
,p_db_column_name=>'FK_APL_PLANE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Apl Plane'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7562455621886746)
,p_db_column_name=>'PK_APL_PLANE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Pk Apl Plane'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3896035991434006)
,p_db_column_name=>'IMAGE'
,p_display_order=>21
,p_column_identifier=>'M'
,p_column_label=>'Image'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:APL_PLANE:IMAGE:PK_APL_PLANE::::::::'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7584503796914854)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'56842'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IMAGE:PK_FLI_FLIGHT:FK_MDT_MANDANT:DEPARTURE:ARRIVAL:DEPARTURE_TIME:ARRIVAL_TIME:DURATION:ADDITIONAL_TIMESLOTS:FK_ADDITIONAL_TIMESLOTTYPE:FK_APL_PLANE:PK_APL_PLANE:'
,p_break_on=>'IMAGE:0:PK_APL_PLANE:0:0:0'
,p_break_enabled_on=>'IMAGE:0:PK_APL_PLANE:0:0:0'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7562863035886746)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3895833125434004)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38'
);
wwv_flow_api.component_end;
end;
/
