prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Bordbuch'
,p_step_title=>'Bordbuch'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Button   {',
'  margin-bottom: 8px;',
'} '))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190419204942'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3896219059434007)
,p_plug_name=>'Bordbuch'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3896583495434011)
,p_name=>'Selection1'
,p_region_name=>'CD_PLANES'
,p_parent_plug_id=>wwv_flow_api.id(3896219059434007)
,p_template=>wwv_flow_api.id(22872632320920976)
,p_display_sequence=>5
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--accent6:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--featured:t-Cards--3cols:t-Cards--animRaiseCard'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
'    distinct',
'    ''<img src="'' || img_src || ''"/>'' card_title,',
'    plane_no  card_text,',
unistr('    ''<b>Bordbuch: </b>''|| pk_bor_bord_log || ''<br>'' || ''<b>Datum: </b>''|| bor.bord_log_date || ''<br>'' ||  ''n\FFFDste Inspektion: ''|| ''<br>'' || ''Flugstunden: '' || ''<br>'' || ''Flugkilometer: '' card_subtext,'),
'    ''f?p=&APP_ID.:39:&APP_SESSION.::NO::P39_PK_APL_PLANE:'' || pk_apl_plane  card_link,',
'    case when apl.pk_apl_plane = :P39_PK_APL_PLANE then ''LightGrey'' end style_plane',
'from (select * from  apl_plane where (pk_apl_plane = :P39_pK_APL_PLANE  or :P39_pK_APL_PLANE is null) ) apl',
' left join (',
'                 select bor.*',
'                 from bor_bord_log bor ',
'                     join (select fk_apl_plane, max(pk_bor_bord_log) pk_bor_bord_log from bor_bord_log group by fk_apl_plane ) bor_max on bor.pk_bor_bord_log = bor_max.pk_bor_bord_log',
'           ) bor on bor.fk_apl_plane =apl.pk_apl_plane'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(22879789685920985)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3897230078434018)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3897607504434021)
,p_query_column_id=>2
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span style="background-color:#STYLE_PLANE#">#CARD_TEXT#</span>'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3897706749434022)
,p_query_column_id=>3
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3898232177434028)
,p_query_column_id=>4
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>4
,p_column_heading=>'Card link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3898467056434030)
,p_query_column_id=>5
,p_column_alias=>'STYLE_PLANE'
,p_column_display_sequence=>5
,p_column_heading=>'Style plane'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7575952309901821)
,p_plug_name=>'Bordbuch'
,p_parent_plug_id=>wwv_flow_api.id(3896219059434007)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    "PK_BOR_BORD_LOG", ',
'    "BORD_LOG",',
'    "BORD_LOG_DATE",',
'    "FK_MDT_MANDANT",',
'    "FK_APL_PLANE",',
'    "PK_BOR_BORD_LOG_ENTRY",',
'    "FK_FLI_FLIGHT",',
'    "ENTRY_DATE",',
'    "PIC",',
'    "T_O_TIME",',
'    "LDG_TIME",',
'    "CHARGES",',
'    "EDMA",',
'    "ARRIVAL",',
'    "FK_BOR_BORD_LOG_ENTRY_GRP",',
'    "COMM",',
'    "COST_ADD"',
'from "#OWNER#"."V_BOR_BORD_LOG" ',
'where (fk_apl_plane = :P39_pK_APL_PLANE  or :P39_pK_APL_PLANE is null) ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7576330282901830)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::P40_PK_BOR_BORD_LOG_ENTRY:#PK_BOR_BORD_LOG_ENTRY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>5676003826865730
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7576472368901870)
,p_db_column_name=>'PK_BOR_BORD_LOG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Bor Bord Log'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7576812363901888)
,p_db_column_name=>'BORD_LOG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Bord Log'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7577179138901914)
,p_db_column_name=>'BORD_LOG_DATE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Bord Log Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7577611071901932)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7577973506901951)
,p_db_column_name=>'FK_APL_PLANE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fk Apl Plane'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7578274558901985)
,p_db_column_name=>'PK_BOR_BORD_LOG_ENTRY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Pk Bor Bord Log Entry'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7578694754902004)
,p_db_column_name=>'FK_FLI_FLIGHT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fk Fli Flight'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7579032892902027)
,p_db_column_name=>'ENTRY_DATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Entry Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7579492356902048)
,p_db_column_name=>'PIC'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Pic'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7579806703902091)
,p_db_column_name=>'T_O_TIME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'T O Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7580134378902112)
,p_db_column_name=>'LDG_TIME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Ldg Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7580605723902147)
,p_db_column_name=>'CHARGES'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Charges'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7580972012902166)
,p_db_column_name=>'EDMA'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Edma'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7581274457902182)
,p_db_column_name=>'ARRIVAL'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Arrival'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7582034347902257)
,p_db_column_name=>'COMM'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7582482621902276)
,p_db_column_name=>'COST_ADD'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Cost Add'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7370225519064740)
,p_db_column_name=>'FK_BOR_BORD_LOG_ENTRY_GRP'
,p_display_order=>27
,p_column_identifier=>'R'
,p_column_label=>'Fk bor bord log entry grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7585323293917274)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'56850'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_BOR_BORD_LOG:BORD_LOG:BORD_LOG_DATE:FK_MDT_MANDANT:FK_APL_PLANE:PK_BOR_BORD_LOG_ENTRY:FK_FLI_FLIGHT:ENTRY_DATE:PIC:T_O_TIME:LDG_TIME:CHARGES:EDMA:ARRIVAL:COMM:COST_ADD:FK_BOR_BORD_LOG_ENTRY_GRP'
,p_break_on=>'BORD_LOG'
,p_break_enabled_on=>'BORD_LOG'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7984444344249412)
,p_button_sequence=>5
,p_button_plug_id=>wwv_flow_api.id(3896219059434007)
,p_button_name=>'Reset_Filter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Reset filter'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:RP:P39_PK_APL_PLANE:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7582853963902279)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3896219059434007)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7759385137835209)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7575952309901821)
,p_button_name=>'Create_Bord_Log'
,p_button_static_id=>'button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Create Bord log'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7759438934835210)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7575952309901821)
,p_button_name=>'Create_Bord_log_Entry'
,p_button_static_id=>'button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Bord log Entry'
,p_button_position=>'TOP'
,p_button_condition=>'P39_PK_APL_PLANE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7759591955835211)
,p_branch_name=>'Goto  Page 42 (Create Bord Log)'
,p_branch_action=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP:P0_PK_BOR_BORD_LOG,P42_FK_APL_PLANE:,&P39_PK_APL_PLANE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7759385137835209)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7759724996835212)
,p_branch_name=>'Goto  Page 43 (Create Bord Log Entry)'
,p_branch_action=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7759438934835210)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3898420045434029)
,p_name=>'P39_PK_APL_PLANE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3896219059434007)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.component_end;
end;
/
