prompt --application/shared_components/navigation/lists/mandanten
begin
--   Manifest
--     LIST: Mandanten
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(3903263073757409)
,p_name=>'Mandanten'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'"PK_MDT_MANDANT",',
'"MANDANT" list_title,',
'fk_org_org_unit list_text',
'from "MDT_MANDANT" ',
'  '))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
