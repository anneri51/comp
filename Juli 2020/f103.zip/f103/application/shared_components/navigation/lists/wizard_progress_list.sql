prompt --application/shared_components/navigation/lists/wizard_progress_list
begin
--   Manifest
--     LIST: Wizard Progress List
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>3603891666954175
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(7685234047266396)
,p_name=>'Wizard Progress List'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7686783950266404)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Step 1:<br> Bordbuch <b>anlegen</b>/ausw\FFFDen')
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'43'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7690356772266414)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Step 1:<br> Bordbuch anlegen/<b>ausw\FFFDen</b>')
,p_list_item_link_target=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'42'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7694635398266416)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Step 2:<br> Flug <b>anlegen</b>/ausw\FFFDen')
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'43,45'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7699018880266419)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Step 2:<br> Flug anlegen/<b>ausw\FFFDen</b>')
,p_list_item_link_target=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'42,44'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7703265958266421)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Step 3: Bordbucheintraggruppe <b>anlegen</b>/ausw\FFFDen')
,p_list_item_link_target=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'43,45'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7707535565266423)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('Step 3: Bordbucheintraggruppe anlegen/<b>ausw\FFFDen</b>')
,p_list_item_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_list_item_disp_condition=>'42,44,46'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7711918361266426)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Step 4: Bordbucheintrag anlegen'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
