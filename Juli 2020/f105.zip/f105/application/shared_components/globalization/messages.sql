prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 105
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>19526726201355085
,p_default_application_id=>120
,p_default_id_offset=>3612186064963784
,p_default_owner=>'FLUGZEUGVERMIETUNG_DEV'
);
null;
wwv_flow_api.component_end;
end;
/
