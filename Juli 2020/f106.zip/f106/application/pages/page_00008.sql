prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Location'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Location'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42862188611255483)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200628195817'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6287836690364998)
,p_plug_name=>'LOCATION'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6300633304365089)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6237109585136001)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(6267651341136083)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8120016228920687)
,p_plug_name=>'Neue Adresse'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10967421148730927)
,p_plug_name=>'Vorgabe'
,p_parent_plug_id=>wwv_flow_api.id(8120016228920687)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10967509473730928)
,p_plug_name=>'Erfassung'
,p_parent_plug_id=>wwv_flow_api.id(8120016228920687)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11135159553536505)
,p_plug_name=>'Search_Location'
,p_region_name=>'dlSearchLoc'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6231249347135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11135247279536506)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION,P8_FK_ADRESSE,P8_NEW_ADDRESS,P8_NEW_LOCATION_NAME,P8_SRC_PAGE,P8_SRC_PK:#PK_LOCATION#,#FK_ADRESSE#,&P8_NEW_ADDRESS.,&P8_NEW_LOCATION_NAME.,&P8_SRC_PAGE.,&P8_SRC_PK.'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20445382519957427
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11135394055536508)
,p_db_column_name=>'LOCATION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11135670097536511)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11135798188536512)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11135897921536513)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136023919536514)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136111123536515)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136237766536516)
,p_db_column_name=>'STRASSE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136336396536517)
,p_db_column_name=>'HSNR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136451014536518)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136548248536519)
,p_db_column_name=>'COMM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136635556536520)
,p_db_column_name=>'POSTFACH'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136752082536521)
,p_db_column_name=>'PLZ'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136808186536522)
,p_db_column_name=>'ORT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136898249536523)
,p_db_column_name=>'LAND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11136987711536524)
,p_db_column_name=>'ADR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284139309508387)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284235062508388)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284346013508389)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284469220508390)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284541410508391)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284650230508392)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284692830508393)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11160334561695221)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'204705'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCATION:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ORT:LAND:ADR:PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11166040608746505)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(6235979950136001)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(116527361374993)
,p_plug_name=>'Location / Adresse'
,p_parent_plug_id=>wwv_flow_api.id(11166040608746505)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location',
'where pk_loc_location = :P8_PK_loc_LOCATION',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(116646200374994)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>9426781440795915
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(116846820374996)
,p_db_column_name=>'STRASSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(116882692374997)
,p_db_column_name=>'HSNR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117030805374998)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117229870375000)
,p_db_column_name=>'POSTFACH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117327901375001)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117404055375002)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117494579375003)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117656264375004)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(117702081375005)
,p_db_column_name=>'COMM'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966513802730918)
,p_db_column_name=>'LOCATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966776627730921)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10966899444730922)
,p_db_column_name=>'PLZ'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967016324730923)
,p_db_column_name=>'ORT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967164633730924)
,p_db_column_name=>'LAND'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10967199091730925)
,p_db_column_name=>'ADR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45282941106508375)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283069256508376)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283090536508377)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283235902508378)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283352885508379)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283467168508380)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283504957508381)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(151730569168847)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94619'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOCATION:LOCATION_TYPE:ADR:STRASSE:HSNR:POSTFACH:PLZ:ORT:LAND:BESCHREIBUNG:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:COMM::PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11166153419746506)
,p_plug_name=>'Adresse'
,p_parent_plug_id=>wwv_flow_api.id(11166040608746505)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_adr_adresse',
'where pk_adr_adresse = :P8_FK_adr_Adresse'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11166177800746507)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20476313041167428
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166394145746509)
,p_db_column_name=>'STRASSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166528677746510)
,p_db_column_name=>'HSNR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166642883746511)
,p_db_column_name=>'PLZ'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166680094746512)
,p_db_column_name=>'ORT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166823904746513)
,p_db_column_name=>'LAND'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166903302746514)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11166990577746515)
,p_db_column_name=>'ADR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283620968508382)
,p_db_column_name=>'PK_ADR_ADRESSE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283686297508383)
,p_db_column_name=>'OT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ot'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283874863508384)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45283899656508385)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284061521508386)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11248072605695216)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'205583'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STRASSE:HSNR:PLZ:ORT:LAND:BESCHREIBUNG:ADR:PK_ADR_ADRESSE:OT:PK_ADR_ORT:PK_ADR_LAND:PK_ADR_PLZ_ORT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11385688524651325)
,p_plug_name=>'All Locations'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_loc_location',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11385798003651326)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'15'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_PK_ADRESSE:#PK_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20695933244072247
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11385911033651327)
,p_db_column_name=>'STRASSE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11386023871651328)
,p_db_column_name=>'HSNR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11386108676651329)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11527901456767880)
,p_db_column_name=>'POSTFACH'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528023693767881)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528128252767882)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528257503767883)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528320735767884)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528368745767885)
,p_db_column_name=>'COMM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528568987767887)
,p_db_column_name=>'LOCATION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11528896960767890)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11529022440767891)
,p_db_column_name=>'PLZ'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11529123682767892)
,p_db_column_name=>'ORT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11529178320767893)
,p_db_column_name=>'LAND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11529265226767894)
,p_db_column_name=>'ADR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284819173508394)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284899865508395)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45284999084508396)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45285160384508397)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45285182418508398)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45285290843508399)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45285470086508400)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11539053393771167)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'208492'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STRASSE:HSNR:BESCHREIBUNG:POSTFACH:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:COMM:LOCATION:LOCATION_TYPE:PLZ:ORT:LAND:ADR:PK_LOC_LOCATION:FK_BAS_LOC_LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8122118815920708)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8120016228920687)
,p_button_name=>'create_adress_new'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Create adress new'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8121011563920697)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(10967509473730928)
,p_button_name=>'CREATE_ADRESS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Create adress'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11137098034536525)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'Search_Location'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Search location'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_column=>8
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11137448881536528)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'Reset_Location'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION,P8_FK_ADRESSE,P8_NEW_LOCATION_NAME,P8_NEW_ADDRESS,P8_SRC_PK,P8_SRC_PAGE:,,&P8_NEW_LOCATION_NAME.,&P8_NEW_ADDRESS.,&P8_SRC_PK.,&P8_SRC_PAGE.'
,p_grid_new_row=>'N'
,p_grid_column=>10
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11382489174651293)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'Location_Type'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Location type'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:234:&SESSION.::&DEBUG.:RP,234:P234_PK_LOCATION_TYPE:&P8_FK_LOCATION_TYPE.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8121343495920700)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(10967509473730928)
,p_button_name=>'Add_Adr_PLZ_ORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add plz ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8120620270920693)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(10967509473730928)
,p_button_name=>'Add_ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8120352276920690)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(10967509473730928)
,p_button_name=>'Add_Land'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add land'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>9
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6288697344365061)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6288825713365062)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6288597703365061)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6288784615365061)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6287836690364998)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P8_PK_LOC_LOCATION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8121677767920704)
,p_branch_name=>'Go To Page 8'
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_PK_LOCATION:&P8_PK_LOCATION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8121343495920700)
,p_branch_sequence=>31
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(6290425489365069)
,p_branch_name=>'Go To Page 7'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>61
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6291281810365073)
,p_name=>'P8_PK_LOC_LOCATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_use_cache_before_default=>'NO'
,p_source=>'PK_LOC_LOCATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6291658830365073)
,p_name=>'P8_LOCATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Location'
,p_source=>'LOCATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6292021912365073)
,p_name=>'P8_FK_BAS_LOC_LOCATION_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Typ'
,p_source=>'FK_BAS_LOC_LOCATION_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Location_type, pk_bas_loc_location_type',
'from t_bas_loc_location_type',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6292406610365074)
,p_name=>'P8_FK_ADR_ADRESSE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_use_cache_before_default=>'NO'
,p_prompt=>'zugeh. Adresse'
,p_source=>'FK_ADR_ADRESSE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select strasse || '' '' || hsnr || '' '' || plz || '' '' || ort || '' - '' || ot || '' ('' || pk_adr_adresse || '')'', pk_adr_adresse',
'from t_adr_Adresse ta',
' left join t_adr_plz_ort tpo on tpo.pk_adr_plz_ort = ta.fk_adr_plz_ort',
' left join t_adr_ort tor on tor.pk_adr_ort = tpo.fk_adr_ort',
'order by strasse, plz, ort'))
,p_lov_display_null=>'YES'
,p_cSize=>60
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120160481920688)
,p_name=>'P8_LAND'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land',
'from t_adr_land',
'order by land'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120211693920689)
,p_name=>'P8_ORT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Ort'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort',
'from t_adr_ort',
'order by ort'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120382539920691)
,p_name=>'P8_FK_ADR_LAND'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Fk land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land, pk_land',
'from t_land'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120464939920692)
,p_name=>'P8_FK_ADR_ORT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Fk ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ('' || land || '')'', pk_adr_ort',
'from t_adr_ort ort ',
'  left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land',
'order by ort'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120691273920694)
,p_name=>'P8_STRASSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Strasse'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120820710920695)
,p_name=>'P8_HSNR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'HSNR'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8120883561920696)
,p_name=>'P8_PLZ'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Plz'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8121123326920698)
,p_name=>'P8_FK_ADR_PLZ_ORT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(10967509473730928)
,p_prompt=>'Fk plz ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select plz || '' '' || ort || '' - '' || ot ||  '' ('' || land || '')'', pk_adr_plz_ort',
'from t_adr_plz_ort plzort',
'  left join t_adr_ort ort on plzort.fk_adr_ort = ort.pk_adr_ort',
'  left join t_ADR_land la on la.pk_ADR_land = ort.fk_adr_land',
'order by ort'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cattributes_element=>'style="margin-right:8px"'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10966243337730915)
,p_name=>'P8_NEW_ADDRESS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10967421148730927)
,p_prompt=>'Neue Adresse'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11132633380536480)
,p_name=>'P8_NEW_LOCATION_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10967421148730927)
,p_prompt=>'Neue Locationsbezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11137552303536529)
,p_name=>'P8_SRC_PAGE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11163552107746480)
,p_name=>'P8_SRC_PK'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(6287836690364998)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8122378456920711)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_FK_ADR_PLZ_ORT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8122497439920712)
,p_event_id=>wwv_flow_api.id(8122378456920711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P8_FK_ADR_ORT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_adr_ort',
'from t_adr_plz_ort',
'where pk_adr_plz_ort = :P8_FK_adr_PLZ_ORT'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8122632380920713)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_FK_ADR_ORT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8122753809920714)
,p_event_id=>wwv_flow_api.id(8122632380920713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' if :P118_fk_adr_ort is not null then',
'select fk_adr_land',
'into :P118_fk_adr_land',
'from t_adr_ort',
'where pk_adr_ort = :P118_fk_adr_ort;',
'end if;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11137230114536526)
,p_name=>'Search_Location'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(11137098034536525)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11137265018536527)
,p_event_id=>wwv_flow_api.id(11137230114536526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''dlSearchLoc'');'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6294474379365077)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_LOC_LOCATION'
,p_attribute_02=>'T_LOC_LOCATION'
,p_attribute_03=>'P8_PK_LOC_LOCATION'
,p_attribute_04=>'PK_LOC_LOCATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6294851201365079)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_LOCATION'
,p_attribute_02=>'T_LOCATION'
,p_attribute_03=>'P8_PK_LOC_LOCATION'
,p_attribute_04=>'PK_LOCATION'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6295288060365079)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(6288784615365061)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8121192626920699)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_ort ',
'  (',
'    fk_land,',
'     ort',
'  )',
'  values (',
'       :P8_FK_LAnd,',
'       :P8_ort',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8120620270920693)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8121436969920701)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_plz_ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_plz_ort ',
'  (',
'    fk_ort,',
'     plz',
'  )',
'  values (',
'       :P8_FK_ort,',
'       :P8_plz',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8121343495920700)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8121848310920705)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_adress'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into T_ADRESSE',
'  (',
'    fk_plz_ort,',
'    strasse,',
'      hsnr',
'  )',
'  values (',
'       :P8_FK_plz_ort,',
'       :P8_strasse,',
'      :P8_hsnr',
'  );',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8121011563920697)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8122218118920709)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create_adr_new'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_pk_plz_ort   NUMBER;',
'    v_pk_ort       NUMBER;',
'    v_pk_land      NUMBER;',
'BEGIN',
'',
unistr('  --Land hinzuf\00FCgen'),
'    IF :p8_fk_land IS NULL THEN',
'        v_pk_land := t_land_seq.nextval;',
'        INSERT INTO t_land (',
'            pk_land,',
'            land',
'        ) VALUES (',
'            v_pk_land,',
'            :p8_land',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_land :=:p8_fk_land;',
'    END IF;',
'  ',
unistr('  --Ort hinzuf\00FCgen'),
'',
'    IF :p8_fk_ort IS NULL THEN',
'        v_pk_ort := seq_ort.nextval;',
'        INSERT INTO t_ort (',
'            pk_ort,',
'            fk_land,',
'            ort',
'        ) VALUES (',
'            v_pk_ort,',
'            v_pk_land,',
'            :P8_ORT',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_ort :=:p8_fk_ort;',
'    END IF;',
'  ',
unistr('  --PLZ Ort hinzuf\00FCgen'),
'    IF :p8_fk_plz_ort IS NULL THEN',
'        v_pk_plz_ort := seq_plz_ort.nextval;',
'        INSERT INTO t_plz_ort (',
'            pk_plz_ort,',
'            fk_ort,',
'            plz',
'        ) VALUES (',
'            v_pk_plz_ort,',
'            v_pk_ort,',
'            :p8_plz',
'        );',
'',
'        COMMIT;',
'    ELSE',
'        v_pk_plz_ort := :p8_fk_plz_ort;',
'    END IF;',
'  ',
unistr('  --Adresse hinzuf\00FCgen'),
'    INSERT INTO t_adresse (',
'        fk_plz_ort,',
'        strasse,',
'        hsnr',
'    ) VALUES (',
'        v_pk_plz_ort,',
'        :p8_strasse,',
'        :p8_hsnr',
'    );',
'',
'    COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8122118815920708)
);
wwv_flow_api.component_end;
end;
/
