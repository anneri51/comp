prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Artikel'
,p_step_title=>'Artikel'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42866741590295131)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200612190958'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6366138608843946)
,p_plug_name=>'Artikel'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_WH_ART_ARTIKEL" ID, ',
'"ARTIKEL",',
'"FK_BAS_WH_PACKUNGSTYP" Packungstyp,',
'"MENGE",',
'"PREIS_NETTO",',
'"FK_STEU_STEUER_SATZ" Steuersatz,',
'"PREIS_BRUTTO",',
'"KOMMENTAR",',
'"FK_BAS_WH_MENGENEINHEIT" Mengeneinheit,',
'"FK_BAS_WH_ARTIKELBUENDELUNG" Buendelung,',
'"FK_STD_WH_ARTIKEL" Std_Artikel,',
'"FK_STD_WH_ARTIKEL_FLAG" Std_Artikel_Flag,',
'"FK_KON_HERSTELLER" Hersteller,',
'"FK_BAS_BAS_FARBE" Farbe,',
'"EXT_ARTIKELNR"',
'from "T_WH_ART_ARTIKEL" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6366531568843946)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::P19_PK_WH_ART_ARTIKEL:#ID##PK_ARTIKEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6366531568843946
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6367091962843954)
,p_db_column_name=>'ARTIKEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Artikel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6367874572843957)
,p_db_column_name=>'MENGE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Menge'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6368228825843959)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Preis Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6369064821843961)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Preis Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6369405740843961)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6372287726843965)
,p_db_column_name=>'EXT_ARTIKELNR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Ext Artikelnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436259889436409)
,p_db_column_name=>'PACKUNGSTYP'
,p_display_order=>35
,p_column_identifier=>'Q'
,p_column_label=>'Packungstyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436391166436410)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>45
,p_column_identifier=>'R'
,p_column_label=>'Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436445800436411)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>55
,p_column_identifier=>'S'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436564555436412)
,p_db_column_name=>'BUENDELUNG'
,p_display_order=>65
,p_column_identifier=>'T'
,p_column_label=>'Buendelung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436611206436413)
,p_db_column_name=>'STD_ARTIKEL'
,p_display_order=>75
,p_column_identifier=>'U'
,p_column_label=>'Std artikel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436766454436414)
,p_db_column_name=>'STD_ARTIKEL_FLAG'
,p_display_order=>85
,p_column_identifier=>'V'
,p_column_label=>'Std artikel flag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436884407436415)
,p_db_column_name=>'HERSTELLER'
,p_display_order=>95
,p_column_identifier=>'W'
,p_column_label=>'Hersteller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5436916896436416)
,p_db_column_name=>'FARBE'
,p_display_order=>105
,p_column_identifier=>'X'
,p_column_label=>'Farbe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880119456762700)
,p_db_column_name=>'ID'
,p_display_order=>115
,p_column_identifier=>'Y'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6374481404844719)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'63745'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ARTIKEL:PACKUNGSTYP:STEUERSATZ:MENGENEINHEIT:BUENDELUNG:STD_ARTIKEL:STD_ARTIKEL_FLAG:HERSTELLER:FARBE:EXT_ARTIKELNR:MENGE:PREIS_BRUTTO:PREIS_NETTO:KOMMENTAR'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6373248776843965)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6237109585136001)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(6267651341136083)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6372678897843965)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6366138608843946)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:19:P19_PK_WH_ART_ARTIKEL:'
);
wwv_flow_api.component_end;
end;
/
