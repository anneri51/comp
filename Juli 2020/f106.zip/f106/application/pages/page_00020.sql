prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'BUENDELUNG'
,p_step_title=>'BUENDELUNG'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42866741590295131)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200612201013'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6381759996896753)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_BAS_WH_ARTIKELBUENDELUNG", ',
'"BUENDELUNG"',
'from "T_BAS_WH_ARTIKELBUENDELUNG" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6382199560896753)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::P21_PK_BAS_WH_ARTIKELBUENDELUNG:#PK_BAS_WH_ARTIKELBUENDELUNG##PK_BUENDELUNG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6382199560896753
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6382663023896755)
,p_db_column_name=>'BUENDELUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buendelung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880197918762701)
,p_db_column_name=>'PK_BAS_WH_ARTIKELBUENDELUNG'
,p_display_order=>12
,p_column_identifier=>'C'
,p_column_label=>'Pk Bas Wh Artikelbuendelung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6384896537899273)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'63849'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUENDELUNG:PK_BAS_WH_ARTIKELBUENDELUNG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6383643716896756)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6237109585136001)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(6267651341136083)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6383023012896755)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6381759996896753)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:21:P21_PK_BAS_WH_ARTIKELBUENDELUNG:'
);
wwv_flow_api.component_end;
end;
/
