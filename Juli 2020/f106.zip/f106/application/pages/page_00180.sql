prompt --application/pages/page_00180
begin
--   Manifest
--     PAGE: 00180
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>180
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'V_Belege_Zus'
,p_step_title=>'V_Belege_Zus'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42875355428359647)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200621112512'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6161264493122391)
,p_plug_name=>'V_Belege_Zus'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  bel.ART, ',
'        bel.FK_IMP_BA_BEL,',
'        bel.PK_IMP_BA_ALLG_BEL,',
'        bel.BEZEICHNUNG,',
'        bel.KENNZEICHEN,',
'        bel.DATUM,',
'        bel.DATUM_VERGEHEN,',
'        bel.FK_bas_kal_ARBEITSTAG,',
'        bel.FK_kto_BUCHUNG,',
'        bel.BETRAG,',
'        bel.waehrung_betrag,',
'        bel.WaEHRUNG,',
'        bel.STEUERSATZ,',
'        bel.MWST_BETRAG,',
'        bel.NETTO,',
'        bel.ZAHLUNGSART,',
'        bel.fk_inv_inventar,',
'        bel.fk_proj_projekt,',
'        inv.pk_inv_inventar,',
'        inv.inventar,',
'        inv.anschaffungsjahr,',
'        inv.abgangsjahr,',
'        pr.pk_proj_projekt,',
'        pr.projekt,',
'        pr.von,',
'        pr.bis,',
'        bel.fk_bel_beleg_ablage',
'from V_IMP_BEL_ZUS bel',
'   left join t_proj_projekt pr on bel.fk_proj_projekt = pr.pk_proj_projekt',
'   left join t_inv_inventare inv on bel.fk_inv_inventar = inv.pk_Inv_inventar'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6161295233122391)
,p_name=>'V_Belege_Zus'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15471430473543312
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6161735558122401)
,p_db_column_name=>'ART'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Art'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6162065699122403)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6162564631122403)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6162933367122403)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6163287054122404)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6163683157122404)
,p_db_column_name=>'DATUM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6164092479122404)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6728148326156709)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6728222668156710)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>58
,p_column_identifier=>'M'
,p_column_label=>'Mwst betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6728320167156711)
,p_db_column_name=>'NETTO'
,p_display_order=>68
,p_column_identifier=>'N'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6728378313156712)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>78
,p_column_identifier=>'O'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885373631545724)
,p_db_column_name=>'INVENTAR'
,p_display_order=>118
,p_column_identifier=>'S'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885520660545725)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>128
,p_column_identifier=>'T'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885629140545726)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>138
,p_column_identifier=>'U'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885861604545728)
,p_db_column_name=>'PROJEKT'
,p_display_order=>158
,p_column_identifier=>'W'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885888431545729)
,p_db_column_name=>'VON'
,p_display_order=>168
,p_column_identifier=>'X'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7939917339463080)
,p_db_column_name=>'BIS'
,p_display_order=>178
,p_column_identifier=>'Y'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11385573057651324)
,p_db_column_name=>'BETRAG'
,p_display_order=>208
,p_column_identifier=>'AJ'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108328156262165)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>218
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108434869262166)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>228
,p_column_identifier=>'AM'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108507949262167)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>238
,p_column_identifier=>'AN'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108581272262168)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>248
,p_column_identifier=>'AO'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108765650262169)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>258
,p_column_identifier=>'AP'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108829298262170)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>268
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50108937423262171)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>278
,p_column_identifier=>'AR'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109022354262172)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>288
,p_column_identifier=>'AS'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109086689262173)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>298
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6165107009125073)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'154753'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ART:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BEZEICHNUNG:KENNZEICHEN:DATUM:DATUM_VERGEHEN:STEUERSATZ:ZAHLUNGSART:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PROJEKT:VON:BIS:MWST_NETTO:W\00C4HRUNG_:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG_BETRAG:WAEHRUNG:FK_INV_INVENTAR:FK')
||'_PROJ_PROJEKT:PK_INV_INVENTAR:PK_PROJ_PROJEKT:FK_BEL_BELEG_ABLAGE'
,p_break_on=>'PK_PROJEKT:PROJEKT:0:0:0:0:ART'
,p_break_enabled_on=>'PK_PROJEKT:PROJEKT:0:0:0:0:ART'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.component_end;
end;
/
