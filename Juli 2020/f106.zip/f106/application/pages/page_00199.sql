prompt --application/pages/page_00199
begin
--   Manifest
--     PAGE: 00199
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>199
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Auslandsbuchungen'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Auslandsbuchungen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622125738'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6634442832819927)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6713414816152410)
,p_plug_name=>'Auslandsbuchungen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with book as (',
'                select *',
'                from (',
'                            select ID,',
'                                   "Buchungstag",',
'                                   "Beleg",',
'                                   "Unternehmen",',
'                                   round("Betrag",2) "Betrag",',
'                                   Waehrung,',
'                                   "Betrag Ursprung",',
'                                   Waehrung_Ursprung,',
'                                   "Belastete Kreditkarte",',
'                                   Kategorie,',
'                                   "Wertstellungsmonat",',
'                                   FK_bas_kat_Kategorie,',
'                                   FK_std_verw_Verwendungszweck,',
'                                   fk_main_key,',
'                                   apex_item.checkbox2(1,fk_main_key) sel1,',
'                                   apex_item.checkbox2(2,fk_main_key) sel2,',
'                                   case when pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_ausl,',
'                                    round(("Betrag"*1.5/100),2) Betrag_15,',
'                                    round(("Betrag"*1.75/100),2) Betrag_175,',
'                                    "Betrag"*100/1.5 betrag_100_15',
'                              from t_KTO_Kreditkarte kto',
unistr('                                left join t_rel_kto_kont_buch_kont_buch relkto on (kto.fk_main_key = relkto.fk_kto_konto_buch1 or kto.fk_main_key = relkto.fk_kto_konto_buch2) and instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'') >0'),
'                             order by "Buchungstag"',
'                 )',
'                 order by Betrag_15, Betrag_175',
' ) ,',
' book_2 as (',
'                select *',
'                 from book ',
'                 where instr("Unternehmen", ''AUSLANDSEINSATZ'')=0',
' ),',
' book_ausl as (',
'                 select *',
'                 from book',
'                 where instr("Unternehmen", ''AUSLANDSEINSATZ'')>0',
' ),',
' book_zuord as (',
'                 select book_2.fk_main_key book_2_fk_main_key, ',
'                 book_2."Unternehmen" book_2_Unternehmen,',
'                 book_2."Betrag" book_2_Betrag,',
'                ',
'                 book_2.Betrag_15 book_2_Betrag_15,',
'                 book_2.Betrag_175 book_2_betrag_175,',
'                 book_2."Buchungstag" book_2_buchungstag,',
'                 --book_2.betrag_100_15,',
'                 ',
'                 ',
'                 book_ausl.fk_main_key book_ausl_fk_main_key,',
'                 book_ausl."Unternehmen" book_ausl_Unternehmen,',
'                 book_ausl."Betrag" book_ausl_betrag,',
'                 book_ausl."Buchungstag" book_ausl_buchungstag,',
'                 book_ausl.betrag_100_15',
'                 from book_2',
'                  left join book_ausl on round(book_2.Betrag_15,2) = round(book_ausl."Betrag",2) or round(book_2.Betrag_175,2) = round(book_ausl."Betrag",2)',
'                  ',
'                where book_ausl.fk_main_key is not null and book_2."Buchungstag" = book_ausl."Buchungstag"',
' )',
' select book_zuord.*, relkto.*, row_number() over (partition by book_zuord.book_2_fk_main_key order by book_zuord.book_ausl_fk_main_key      ) rnr',
' from book_zuord',
'  left join t_rel_kto_kont_buch_kont_buch relkto on ',
'                                                  ((book_zuord.book_2_fk_main_key = relkto.fk_kto_konto_buch1',
'                                                  and book_zuord.book_ausl_fk_main_key = relkto.fk_kto_konto_buch2)',
'                                                  or (book_zuord.book_2_fk_main_key = relkto.fk_kto_konto_buch2',
'                                                and book_zuord.book_ausl_fk_main_key = relkto.fk_kto_konto_buch1))',
'where relkto.fk_kto_konto_buch1 is null and relkto.fk_kto_konto_buch2 is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6725317151156681)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.:RP:P199_FK_MAIN_KEY1,P199_FK_MAIN_KEY2:#BOOK_2_FK_MAIN_KEY#,#BOOK_AUSL_FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>16035452391577602
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725405530156682)
,p_db_column_name=>'BOOK_2_FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Book 2 fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725547059156683)
,p_db_column_name=>'BOOK_2_UNTERNEHMEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Book 2 unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725596483156684)
,p_db_column_name=>'BOOK_2_BETRAG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Book 2 betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725721682156685)
,p_db_column_name=>'BOOK_2_BETRAG_15'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Book 2 betrag 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725787327156686)
,p_db_column_name=>'BOOK_2_BETRAG_175'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Book 2 betrag 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6725908829156687)
,p_db_column_name=>'BOOK_AUSL_FK_MAIN_KEY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Book ausl fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726049706156688)
,p_db_column_name=>'BOOK_AUSL_UNTERNEHMEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Book ausl unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726083250156689)
,p_db_column_name=>'BOOK_AUSL_BETRAG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Book ausl betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726513240156693)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726643592156694)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726738099156695)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726827969156696)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6726962344156697)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6727156056156699)
,p_db_column_name=>'BOOK_2_BUCHUNGSTAG'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Book 2 buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6727207956156700)
,p_db_column_name=>'BOOK_AUSL_BUCHUNGSTAG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Book ausl buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6728510234156713)
,p_db_column_name=>'RNR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893706117241189)
,p_db_column_name=>'BETRAG_100_15'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Betrag 100 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283125008707994)
,p_db_column_name=>'PK_REL_KTO_KONT_BUCH_KONT_BUCH'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Rel Kto Kont Buch Kont Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283243326707995)
,p_db_column_name=>'FK_KTO_KONTO_BUCH1'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fk Kto Konto Buch1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283291996707996)
,p_db_column_name=>'FK_KTO_KONTO_BUCH2'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Kto Konto Buch2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283442185707997)
,p_db_column_name=>'FK_STD_BUCHUNGSVORGANG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Buchungsvorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283496204707998)
,p_db_column_name=>'FK_STD_TYPE'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Std Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6745254220174409)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'160554'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BOOK_2_FK_MAIN_KEY:BOOK_2_UNTERNEHMEN:BOOK_2_BETRAG:BOOK_2_BETRAG_15:BOOK_2_BETRAG_175:BOOK_AUSL_FK_MAIN_KEY:BOOK_AUSL_UNTERNEHMEN:BOOK_AUSL_BETRAG:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:BEMERKUNG:BOOK_2_BUCHUNGSTAG:BOOK_AUSL_BUCHUNGSTAG:RNR:B'
||'ETRAG_100_15:PK_REL_KTO_KONT_BUCH_KONT_BUCH:FK_KTO_KONTO_BUCH1:FK_KTO_KONTO_BUCH2:FK_STD_BUCHUNGSVORGANG:FK_STD_TYPE'
,p_sort_column_1=>'BOOK_2_BUCHUNGSTAG'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13893829057241190)
,p_plug_name=>'Auslandsbuchungen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'         select ID,',
'                                   "Buchungstag",',
'                                   "Beleg",',
'                                   "Unternehmen",',
'                                   round("Betrag",2) "Betrag",',
'                                   Waehrung,',
'                                   "Betrag Ursprung",',
'                                   Waehrung_Ursprung,',
'                                   "Belastete Kreditkarte",',
'                                   Kategorie,',
'                                   "Wertstellungsmonat",',
'                                   FK_bas_kat_Kategorie,',
'                                   FK_std_verw_Verwendungszweck,',
'                                   fk_main_key,',
'                                   apex_item.checkbox2(1,fk_main_key) sel1,',
'                                   apex_item.checkbox2(2,fk_main_key) sel2,',
'                                   case when pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_ausl,',
'                                    round(("Betrag"*1.5/100),2) Betrag_15,',
'                                    round(("Betrag"*1.75/100),2) Betrag_175,',
'                                    "Betrag"*100/1.5 betrag_100_15,',
'                                    "Betrag"*100/1.75 betrag_100_175',
'                              from t_KTO_Kreditkarte kto',
unistr('                                left join t_rel_kto_kont_buch_kont_buch relkto on (kto.fk_main_key = relkto.fk_kto_konto_buch1 or kto.fk_main_key = relkto.fk_kto_konto_buch2) and instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'') >0'),
'                         ',
'                            where fk_main_key = :P199_FK_Main_key1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13893967153241191)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.:RP:P199_FK_MAIN_KEY1,P199_FK_MAIN_KEY2:#BOOK_2_FK_MAIN_KEY#,#BOOK_AUSL_FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15334286428632731
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13926624433257863)
,p_db_column_name=>'BETRAG_100_15'
,p_display_order=>220
,p_column_identifier=>'A'
,p_column_label=>'Betrag 100 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13926769779257864)
,p_db_column_name=>'ID'
,p_display_order=>230
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13926783950257865)
,p_db_column_name=>'Buchungstag'
,p_display_order=>240
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13926961098257866)
,p_db_column_name=>'Beleg'
,p_display_order=>250
,p_column_identifier=>'D'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13926985052257867)
,p_db_column_name=>'Unternehmen'
,p_display_order=>260
,p_column_identifier=>'E'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927158463257868)
,p_db_column_name=>'Betrag'
,p_display_order=>270
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927368897257870)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>290
,p_column_identifier=>'H'
,p_column_label=>'Betrag Ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927510158257872)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>310
,p_column_identifier=>'J'
,p_column_label=>'Belastete Kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13927691788257874)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>330
,p_column_identifier=>'L'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928072060257877)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>360
,p_column_identifier=>'O'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928084446257878)
,p_db_column_name=>'SEL1'
,p_display_order=>370
,p_column_identifier=>'P'
,p_column_label=>'Sel1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928206058257879)
,p_db_column_name=>'SEL2'
,p_display_order=>380
,p_column_identifier=>'Q'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928293033257880)
,p_db_column_name=>'ZUORD_AUSL'
,p_display_order=>390
,p_column_identifier=>'R'
,p_column_label=>'Zuord Ausl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928423955257881)
,p_db_column_name=>'BETRAG_15'
,p_display_order=>400
,p_column_identifier=>'S'
,p_column_label=>'Betrag 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928576835257882)
,p_db_column_name=>'BETRAG_175'
,p_display_order=>410
,p_column_identifier=>'T'
,p_column_label=>'Betrag 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928623689257883)
,p_db_column_name=>'BETRAG_100_175'
,p_display_order=>420
,p_column_identifier=>'U'
,p_column_label=>'Betrag 100 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282117040707984)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>430
,p_column_identifier=>'V'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282248572707985)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>440
,p_column_identifier=>'W'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282318947707986)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>450
,p_column_identifier=>'X'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282436470707987)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>460
,p_column_identifier=>'Y'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282556409707988)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>470
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13947378911337564)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'153877'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BETRAG_100_15:ID:Buchungstag:Beleg:Unternehmen:Betrag:Betrag Ursprung:Belastete Kreditkarte:Wertstellungsmonat:FK_MAIN_KEY:SEL1:SEL2:ZUORD_AUSL:BETRAG_15:BETRAG_175:BETRAG_100_175:WAEHRUNG:WAEHRUNG_URSPRUNG:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_'
||'VERWENDUNGSZWECK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13928771010257884)
,p_plug_name=>'Auslandsbuchungen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'         select apex_item.checkbox2(1,id) sel,',
'         ',
'               ID,',
'                                   "Buchungstag",',
'                                   "Beleg",',
'                                   "Unternehmen",',
'                                   round("Betrag",2) "Betrag",',
'                                   Waehrung,',
'                                   "Betrag Ursprung",',
'                                   Waehrung_Ursprung,',
'                                   "Belastete Kreditkarte",',
'                                   Kategorie,',
'                                   "Wertstellungsmonat",',
'                                   FK_bas_kat_Kategorie,',
'                                   FK_std_verw_Verwendungszweck,',
'                                   fk_main_key,',
'                                   apex_item.checkbox2(1,fk_main_key) sel1,',
'                                   apex_item.checkbox2(2,fk_main_key) sel2,',
'                                   case when pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_ausl,',
'                                    round(("Betrag"*1.5/100),2) Betrag_15,',
'                                    round(("Betrag"*1.75/100),2) Betrag_175,',
'                                    "Betrag"*100/1.5 betrag_100_15,',
'                                    "Betrag"*100/1.75 betrag_100_175',
'                              from t_KTO_Kreditkarte kto',
unistr('                                left join t_rel_kto_kont_buch_kont_buch relkto on (kto.fk_main_key = relkto.fk_kto_konto_buch1 or kto.fk_main_key = relkto.fk_kto_konto_buch2) and instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'') >0'),
'                         ',
'                            where    "Buchungstag" = :P199_SEL_DATE'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13928873710257885)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.:RP:P199_FK_MAIN_KEY1,P199_FK_MAIN_KEY2,P199_TEXT,P199_SEL_DATE:&P199_FK_MAIN_KEY1.,#FK_MAIN_KEY#,&P199_TEXT.,&P199_SEL_DATE.#BOOK_2_FK_MAIN_KEY#,#BOOK_AUSL_FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15369192985649425
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928922504257886)
,p_db_column_name=>'BETRAG_100_15'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Betrag 100 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13928984435257887)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929176943257888)
,p_db_column_name=>'Buchungstag'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929222320257889)
,p_db_column_name=>'Beleg'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929372521257890)
,p_db_column_name=>'Unternehmen'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929430254257891)
,p_db_column_name=>'Betrag'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929600894257893)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Betrag Ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13929825037257895)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Belastete Kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930003633257897)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930317582257900)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930449446257901)
,p_db_column_name=>'SEL1'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Sel1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930543325257902)
,p_db_column_name=>'SEL2'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930627424257903)
,p_db_column_name=>'ZUORD_AUSL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Zuord Ausl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930746898257904)
,p_db_column_name=>'BETRAG_15'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Betrag 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930854516257905)
,p_db_column_name=>'BETRAG_175'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Betrag 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13930917964257906)
,p_db_column_name=>'BETRAG_100_175'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Betrag 100 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13931177494257908)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282663214707989)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282723876707990)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282834003707991)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282902481707992)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50283075586707993)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13947881456337583)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'153883'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BETRAG_100_15:ID:Buchungstag:Beleg:Unternehmen:Betrag:Betrag Ursprung:Belastete Kreditkarte:Wertstellungsmonat:FK_MAIN_KEY:SEL1:SEL2:ZUORD_AUSL:BETRAG_15:BETRAG_175:BETRAG_100_175:SEL:WAEHRUNG:WAEHRUNG_URSPRUNG:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_V'
||'ERW_VERWENDUNGSZWECK'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6727352031156701)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(6634442832819927)
,p_button_name=>'Insert'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Insert'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13951403270462075)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(6634442832819927)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6634481399819928)
,p_name=>'P199_FK_MAIN_KEY1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6634442832819927)
,p_prompt=>'Fk main key1'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'  from v_kto_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6634584700819929)
,p_name=>'P199_FK_MAIN_KEY2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6634442832819927)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'  from v_kto_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6725173354156680)
,p_name=>'P199_TEXT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(6634442832819927)
,p_item_default=>unistr('Zuordnung Auslandsgeb\00FChr')
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13930996713257907)
,p_name=>'P199_SEL_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(6634442832819927)
,p_prompt=>'Sel Date'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13951240766462073)
,p_name=>'P199_PK_KTO_KONT_BUCH_KONT_BUCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6634442832819927)
,p_prompt=>'Pk Kto Kont Buch Kont Buch'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6727425156156702)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' insert into t_rel_kont_buch_kont_buch',
' (',
' ',
'  fk_konto_buch1,',
'     fk_konto_buch2,',
'     bemerkung',
' )',
' select :P199_FK_MAiN_KEY1,',
' :P199_FK_MAIN_KEY2,',
' :P199_Text',
' from dual;',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(6727352031156701)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13951328799462074)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' delete from  t_rel_kont_buch_kont_buch where pk_rel_kont_buch_kont_buch = :P199_PK_KONT_BUCH_KONT_BUCH;',
'',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13951403270462075)
);
wwv_flow_api.component_end;
end;
/
