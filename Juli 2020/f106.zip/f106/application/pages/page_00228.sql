prompt --application/pages/page_00228
begin
--   Manifest
--     PAGE: 00228
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>228
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Beleg'
,p_step_title=>'Beleg'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200628153032'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(360324645600174)
,p_plug_name=>'Ordner_Auswahl'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ord.PK_ABL_ORDNER,',
' ord_page.PK_ABL_ORDNER_page,',
'         ord.JAHR,',
'        ord.ORDNER_NAME,',
'        ord_page.page_number,',
'        case when pk_abl_ordner_page = :P228_PK_ABL_ORDNER_PAGE then 1 else 0 end sel',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(360421072600175)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:228:&SESSION.::&DEBUG.:RP,228:P228_PK_ABL_ORDNER,P228_PK_ABL_ORDNER_PAGE:#PK_ABL_ORDNER#,#PK_ABL_ORDNER_PAGE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>1800740347991715
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(360558238600176)
,p_db_column_name=>'PK_ABL_ORDNER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(360626674600177)
,p_db_column_name=>'JAHR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(360767567600178)
,p_db_column_name=>'ORDNER_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(361405063600185)
,p_db_column_name=>'PAGE_NUMBER'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>'Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(361624535600187)
,p_db_column_name=>'PK_ABL_ORDNER_PAGE'
,p_display_order=>50
,p_column_identifier=>'K'
,p_column_label=>'Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2154198825146002)
,p_db_column_name=>'SEL'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(503207968702052)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'19436'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR:ORDNER_NAME:PAGE_NUMBER::SEL'
,p_sort_column_1=>'PAGE_NUMBER'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2458638587495938)
,p_report_id=>wwv_flow_api.id(503207968702052)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2458266890495938)
,p_report_id=>wwv_flow_api.id(503207968702052)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(2459000194495947)
,p_report_id=>wwv_flow_api.id(503207968702052)
,p_pivot_columns=>'ORDNER_NAME'
,p_row_columns=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(2459471861495949)
,p_pivot_id=>wwv_flow_api.id(2459000194495947)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'PK_ABL_ORDNER'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(514566799810086)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Jahr'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'19549'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_ABL_ORDNER:JAHR:ORDNER_NAME:PAGE_NUMBER'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(514918118810111)
,p_report_id=>wwv_flow_api.id(514566799810086)
,p_pivot_columns=>'ORDNER_NAME'
,p_row_columns=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(515346366810111)
,p_pivot_id=>wwv_flow_api.id(514918118810111)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'PK_ABL_ORDNER'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12304755419066872)
,p_application_user=>'ANNE'
,p_name=>'2016'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR:ORDNER_NAME:PAGE_NUMBER::SEL'
,p_sort_column_1=>'PAGE_NUMBER'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12304928655066872)
,p_report_id=>wwv_flow_api.id(12304755419066872)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12304877302066872)
,p_report_id=>wwv_flow_api.id(12304755419066872)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(12304991675066875)
,p_report_id=>wwv_flow_api.id(12304755419066872)
,p_pivot_columns=>'ORDNER_NAME'
,p_row_columns=>'JAHR'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(12305086938066875)
,p_pivot_id=>wwv_flow_api.id(12304991675066875)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'PK_ABL_ORDNER'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12596670637116010)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10710940188502970)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(12596670637116010)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    apex_item.checkbox2(1,  inp_bel."PK_INP_BELEGE_ALL") sel,',
'    inp_bel."PK_INP_BELEGE_ALL", ',
'    inp_bel."FK_LEX_BUCHUNG",',
'    inp_bel.FK_BAS_KAT_KATEGORIE,',
'    inp_bel."FK_BAS_KAL_ARBEITSTAG",',
'    inp_bel."FK_KTO_BUCHUNG",',
'    inp_bel."FK_STD_KTO_ZAHLUNGSART",',
'    inp_bel."FK_STD_VERW_VERWENDUNGSZWECK",',
'    inp_bel."FK_INV_INVENTAR",',
'    inp_bel."FK_PROJ_PROJEKT",',
'    inp_bel."BELEGNUMMER",',
'    inp_bel."BEZEICHNUNG",',
'    inp_bel."FK_ADR_LAND",',
'    inp_bel."FK_ADR_CITY",',
'    inp_bel."BEL_DATUM",',
'    inp_bel."VON",',
'    inp_bel."BIS",',
'    inp_bel."NETTO_BETRAG",',
'    inp_bel."FK_BAS_STEU_STEUER_SATZ",',
'    inp_bel."MWST_BETRAG",',
'    inp_bel."BRUTTO_BETRAG",',
'    inp_bel."FK_BAS_MON_WAEHRUNG",',
'    inp_bel."STEUERNUMMER",',
'    inp_bel."FK_BAS_MON_UMRECHNUNGSKURS",',
'    dbms_lob.substr(inp_bel."COMM_REST_BELEG",4000,1) "COMM_REST_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_TEL_BELEG",4000,1) "COMM_TEL_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_PRODUKTE",4000,1) "COMM_PRODUKTE",',
unistr('    dbms_lob.substr(inp_bel."COMM_BEGRUENDUNG",4000,1) "COMM_BEGR\00DCNDUNG",'),
'    dbms_lob.substr(inp_bel."COMM_SONSTIGES",4000,1) "COMM_SONSTIGES",',
'    dbms_lob.getlength("BELEG") "BELEG",',
'    dbms_lob.getlength("ZAHLUNGSBELEG") "ZAHLUNGSBELEG",',
'    inp_bel."LITER",',
'    inp_bel."ZAPFSAEULE",',
'    inp_bel.FK_loc_LOCATION,',
'    inp_bel.PERSOENLICH_VOR_ORT,',
'    inp_bel.fk_bel_beleg_ablage,',
'    abl_ord.jahr jahr_ordner,',
'    abl_ord.ordner_name,',
'    abl_ord_p.page_number,',
'    inp_bel.cnt_punkte,',
'    inp_bel.cnt_punkte_geschaetzt,',
'    inp_bel.punkte_von,',
'    inp_bel.punkte_bis,',
'    inv.inventar,',
'     kat.Kategorie,',
'     pr.projekt,',
'     verw.std_name verwendungszweck,',
'     bel.cnt_lex,',
'     inp_bel.FK_IMP_BA_BEL_OLD,',
'     inp_bel.fk_std_inp_status,',
'     inp_bel.fk_std_inp_zahlungsstatus,',
'     inp_bel.fk_kon_geschaeftspartner,',
'     cnt_rel,',
'     cnt_rel_det,',
'     case when det is null then ''0'' else det end det,',
'     ''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':273:'' || V(''APP_SESSION'') || ''::NO:RP:P273_PK_PROJEKT,P273_PK_LOCATION,P273_PK_INP_BELEGE_ALL:'' || ',
'                                          inp_bel.fk_proj_projekt || '','' || inp_bel.fk_loc_location || '','' ||  pk_inp_belege_all , P_CHECKSUM_TYPE => ''SESSION'') || ''">'' || fk_loc_location || ''</a>'' fk_loc_location1,',
'     vloc.ort,',
'     vloc.strasse,',
'     vloc.hsnr,',
'     vloc.land,',
'     vloc.ort loc_ort,',
'     case when datum_ort_ok is not null or datum_addresse_ok is not null or datum_bussgeld_ok is not null or datum_beleg_pos_ok is not null or datum_buchung_ok is not null  or datum_verpfl_bel_ok is not null then 1 else 0 end flg_kontr_bel_ok,',
'     ''ort_ok: <b><span style="color:green">'' || nvl( to_char(datum_ort_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> addresse_ok <b><span style="color:green">'' ||  nvl(to_char(datum_addresse_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) ||  ',
'     ''</b> bussgeld_ok <b><span style="color:green">'' || nvl(to_char(datum_bussgeld_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> beleg_pos_ok <b><span style="color:green">'' || nvl(to_char(datum_beleg_pos_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'') || ''</span>'' || chr(10) || ',
'     ''</b> buchung_ok <b><span style="color:green">'' || nvl(to_char(datum_buchung_ok,''DD.MM.YYY'') , ''<span style = "color:red"> 01.01.1900'')  || ''</span>'' || ''</b>'' || chr(10) ||',
'     ''</b> verpfl_bel_ok <b><span style="color:green">'' || nvl(to_char(datum_verpfl_bel_ok,''DD.MM.YYY'')  , ''<span style = "color:red"> 01.01.1900'')  || ''</span>'' || ''</b>'' || chr(10) ',
'     ',
'     kontr_bel_ok',
', cnt_bel_pos',
'from t_INP_BELEGE_ALL inp_bel',
'  left join t_abl_ordner_page abl_ord_p on inp_bel.fk_abl_ordner_page = abl_ord_p.pk_abl_ordner_page',
'  left join t_abl_ordner abl_ord on abl_ord_p.fk_abl_ordner = abl_ord.pk_abl_ordner',
'  left join t_INV_inventare inv on inp_bel.fk_Inv_inventar = inv.pk_inv_inventar',
'  left join t_proj_projekt pr on pr.pk_proj_projekt = inp_bel.fk_proj_projekt',
'  left join t_bas_kat_konto_buch kat on kat.pk_bas_kat_konto_buch = inp_bel.fk_bas_kat_kategorie',
'  left join (select * from t_std where fk_std_group = 9) verw on verw.std_value = inp_bel.fk_std_verw_verwendungszweck',
'  left join v_loc_location vloc on vloc.pk_loc_location = inp_bel.fk_loc_location',
'  left join (select fk_inp_belege_all , case when count(*)  >0 then 1 else 0 end cnt_lex from  T_REL_LEX_KTO_BEL group by fk_inp_belege_all ) bel on inp_bel.pk_inp_belege_all = bel.fk_inp_belege_all ',
'  left join ( ',
'                    select fk_inp_belege_all',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) cnt_rel,',
'                     sum(case when fk_lex_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) cnt_rel_det,',
'                     listagg( ''('' || rnr || ''/'' || det_cnt_rel_det || '') ok: '' || det_sum_rel,'', - '') within group ( order by fk_inp_belege_all) det',
'                     ',
'                     ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      left join (',
'                          select fk_inp_belege_all det',
'                          --, pk_rel_lex_kto_bel det1',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) det_cnt_rel,',
'                     sum(case when fk_lex_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) det_cnt_rel_det,',
'                     row_number() over (partition by  fk_inp_belege_all order by fk_inp_belege_all) rnr,',
'                    sum(case when fk_lex_relation is not null then 1 else 0 end) det_sum_rel                ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      group by fk_inp_belege_all, pk_rel_lex_kto_bel',
'                      ',
'                      ) relbel_det on relbel_det.det = relbel.fk_inp_belege_all',
'                    group by fk_inp_belege_all',
'                    ',
'           ) ktobel on inp_bel.pk_inp_belege_all = ktobel.fk_inp_belege_all',
'  left join (select fk_inp_belege_all, count(*) cnt_bel_pos from t_inp_belege_pos_all group by fk_inp_belege_all) inp_pos on inp_pos.fk_inp_belege_all = inp_bel.pk_inp_belege_all',
'where (inp_bel.fk_abl_ordner_page =:P228_PK_ABL_ORDNER_PAGE or :P228_PK_ABL_ORDNER_PAGE is null )',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10711325681502971)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&APP_SESSION.::::P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>20021460921923892
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10711455196502982)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:349:&SESSION.::&DEBUG.:RP:P349_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10711851503502986)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10714988879502995)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10715444912502996)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP:P373_ZIEL_PK_INP_BELEGE_ALL,P373_SRC_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1:#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#,,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10716609562502999)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10717014789503000)
,p_db_column_name=>'VON'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10717420633503001)
,p_db_column_name=>'BIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10717847677503004)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10718895112503010)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10720483651503016)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10720884411503018)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10721281576503019)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10721743073503020)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10722093321503022)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10722518179503029)
,p_db_column_name=>'BELEG'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:INP_BELEGE_ALL:BELEG:PK_INP_BELEGE_ALL'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10722922846503030)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:INP_BELEGE_ALL:ZAHLUNGSBELEG:PK_INP_BELEGE_ALL'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10723327201503031)
,p_db_column_name=>'LITER'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10782418383859980)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>52
,p_column_identifier=>'AH'
,p_column_label=>'Mwst betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11167096750746516)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>82
,p_column_identifier=>'AK'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794454875153416)
,p_db_column_name=>'JAHR_ORDNER'
,p_display_order=>122
,p_column_identifier=>'AO'
,p_column_label=>'Jahr ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794476090153417)
,p_db_column_name=>'ORDNER_NAME'
,p_display_order=>132
,p_column_identifier=>'AP'
,p_column_label=>'Ordner name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794638927153418)
,p_db_column_name=>'PAGE_NUMBER'
,p_display_order=>142
,p_column_identifier=>'AQ'
,p_column_label=>'Page number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794684729153419)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>152
,p_column_identifier=>'AR'
,p_column_label=>'Cnt punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794813390153420)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>162
,p_column_identifier=>'AS'
,p_column_label=>'Cnt punkte geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11794919493153421)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>172
,p_column_identifier=>'AT'
,p_column_label=>'Punkte von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11795055293153422)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>182
,p_column_identifier=>'AU'
,p_column_label=>'Punkte bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11795071683153423)
,p_db_column_name=>'INVENTAR'
,p_display_order=>192
,p_column_identifier=>'AV'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11795325430153425)
,p_db_column_name=>'PROJEKT'
,p_display_order=>212
,p_column_identifier=>'AX'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11795406348153426)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>222
,p_column_identifier=>'AY'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12596640099116009)
,p_db_column_name=>'SEL'
,p_display_order=>232
,p_column_identifier=>'AZ'
,p_column_label=>'sel <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(328575383882469)
,p_db_column_name=>'CNT_LEX'
,p_display_order=>242
,p_column_identifier=>'BA'
,p_column_label=>'Cnt Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(605052866945567)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>252
,p_column_identifier=>'BB'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2587081386249003)
,p_db_column_name=>'CNT_REL'
,p_display_order=>282
,p_column_identifier=>'BE'
,p_column_label=>'Cnt Rel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2587189228249004)
,p_db_column_name=>'CNT_REL_DET'
,p_display_order=>292
,p_column_identifier=>'BF'
,p_column_label=>'Cnt Rel Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2587343040249005)
,p_db_column_name=>'DET'
,p_display_order=>302
,p_column_identifier=>'BG'
,p_column_label=>'Det'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#DET#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4749009615070772)
,p_db_column_name=>'ORT'
,p_display_order=>322
,p_column_identifier=>'BI'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4749141893070773)
,p_db_column_name=>'STRASSE'
,p_display_order=>332
,p_column_identifier=>'BJ'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4749224717070774)
,p_db_column_name=>'HSNR'
,p_display_order=>342
,p_column_identifier=>'BK'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4749306227070775)
,p_db_column_name=>'LAND'
,p_display_order=>352
,p_column_identifier=>'BL'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4749410873070776)
,p_db_column_name=>'LOC_ORT'
,p_display_order=>362
,p_column_identifier=>'BM'
,p_column_label=>'Loc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13738730371422872)
,p_db_column_name=>'FLG_KONTR_BEL_OK'
,p_display_order=>372
,p_column_identifier=>'BN'
,p_column_label=>'Flg Kontr Bel Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13738829620422873)
,p_db_column_name=>'KONTR_BEL_OK'
,p_display_order=>382
,p_column_identifier=>'BO'
,p_column_label=>'Kontr Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44487591181415106)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>412
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44487951300415109)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>442
,p_column_identifier=>'BU'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44488013396415110)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>452
,p_column_identifier=>'BV'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44679713644596761)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>462
,p_column_identifier=>'BW'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44679856904596762)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>472
,p_column_identifier=>'BX'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44680238845596766)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>512
,p_column_identifier=>'CB'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44680416197596768)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>532
,p_column_identifier=>'CD'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44680554147596769)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>542
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44680608119596770)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>552
,p_column_identifier=>'CF'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684130147964566)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>562
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684230002964567)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>572
,p_column_identifier=>'CK'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684532344964570)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>602
,p_column_identifier=>'CN'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684614157964571)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>612
,p_column_identifier=>'CO'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684728302964572)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>622
,p_column_identifier=>'CP'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45684876379964573)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>632
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45685146884964576)
,p_db_column_name=>'FK_LOC_LOCATION1'
,p_display_order=>662
,p_column_identifier=>'CT'
,p_column_label=>'Fk Loc Location1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50892678877158784)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>682
,p_column_identifier=>'CW'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51234572160669401)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>692
,p_column_identifier=>'CX'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51234609808669402)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>702
,p_column_identifier=>'CY'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51235077330669406)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>712
,p_column_identifier=>'CZ'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51235094745669407)
,p_db_column_name=>'CNT_BEL_POS'
,p_display_order=>722
,p_column_identifier=>'DA'
,p_column_label=>'Cnt Bel Pos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51468425204293365)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>732
,p_column_identifier=>'DB'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10781800532855908)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'200920'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:BRUTTO_BETRAG:DET:PK_INP_BELEGE_ALL:FLG_KONTR_BEL_OK:KONTR_BEL_OK:BEZEICHNUNG:SEL:FK_IMP_BA_BEL_OLD:CNT_REL:FK_LEX_BUCHUNG:FK_FK_ARBEITSTAG:BEL_DATUM:VON:BIS:NETTO_BETRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKT'
||unistr('E:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:MWST_BETRAG:CNT_PUNKTE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:STEUERNUMMER:INVENTAR:PROJEKT:VERWENDUNGSZWECK:CNT_LEX:CNT_REL_DET:ORT:STRASSE:HSNR:LAND:LOC_ORT:BELEGNUMMER::FK_BAS_FK_BAS_')
||'ARBEITSTAG:FK_KTO_BUCHUNG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:ZAPFSAEULE:PERSOENLICH_VOR_ORT:FK_BEL_BELEG_ABLAGE:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:FK_BAS_MON_UMRECHNUN'
||'GSKURS:FK_LOC_LOCATION:FK_LOC_LOCATION1:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_INP_STATUS:FK_STD_INP_ZAHLUNGSSTATUS:FK_STD_KTO_ZAHLUNGSART:CNT_BEL_POS:FK_KON_GESCHAEFTSPARTNER'
,p_sort_column_1=>'PK_INP_BELEGE_ALL'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:0'
,p_break_enabled_on=>'JAHR_ORDNER:0'
,p_count_columns_on_break=>'PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(44714887138601917)
,p_report_id=>wwv_flow_api.id(10781800532855908)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KONTR_BEL_OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FLG_KONTR_BEL_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(44715341359601919)
,p_report_id=>wwv_flow_api.id(10781800532855908)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR_ORDNER'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR_ORDNER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(44715780308601925)
,p_report_id=>wwv_flow_api.id(10781800532855908)
,p_pivot_columns=>'CNT_PUNKTE'
,p_row_columns=>'JAHR_ORDNER'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(44716123408601925)
,p_pivot_id=>wwv_flow_api.id(44715780308601925)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'CNT_PUNKTE'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11847091087842555)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Pivot'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'211573'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:PK_INP_BELEGE_ALL:CNT_PUNKTE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:VERWENDUNGSZWECK:FK_LEX_BUCHUNG:BEZEICHNUNG:BEL_DATUM:VON:BIS:NETTO_BETRAG:BRUTTO_BETRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BE'
||unistr('GR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:MWST_BETRAG:STEUERNUMMER:INVENTAR:PROJEKT:BELEGNUMMER::SEL')
,p_sort_column_1=>'PK_INP_BELEGE_ALL'
,p_sort_direction_1=>'DESC'
,p_break_on=>'FK_VERWENDUNGSZWECK:FK_BELEG_ABLAGE:JAHR_ORDNER:ORDNER_NAME:PAGE_NUMBER:0'
,p_break_enabled_on=>'0'
,p_count_columns_on_break=>'PK_INP_BELEGE_ALL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12062937084143458)
,p_report_id=>wwv_flow_api.id(11847091087842555)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KATEGORIE'
,p_operator=>'='
,p_expr=>'7'
,p_condition_sql=>'"FK_KATEGORIE" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12063276106143460)
,p_report_id=>wwv_flow_api.id(11847091087842555)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ORDNER_NAME'
,p_operator=>'='
,p_expr=>'Ordner 1'
,p_condition_sql=>'"ORDNER_NAME" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Ordner 1''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12063687658143462)
,p_report_id=>wwv_flow_api.id(11847091087842555)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NUMBER'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"PAGE_NUMBER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(12064139399143471)
,p_report_id=>wwv_flow_api.id(11847091087842555)
,p_pivot_columns=>'CNT_PUNKTE'
,p_row_columns=>'JAHR_ORDNER'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(12064554497143473)
,p_pivot_id=>wwv_flow_api.id(12064139399143471)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'CNT_PUNKTE'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(51186830464756787)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_ADR_ORT'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(51186906952756788)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>52627226228148328
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187001615756789)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187148314756790)
,p_db_column_name=>'ORT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187244107756791)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187283486756792)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187381118756793)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187520277756794)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187649328756795)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187756977756796)
,p_db_column_name=>'ORT_2'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ort 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51187860459756797)
,p_db_column_name=>'KOORDINATEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Koordinaten'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(53385541969510378)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'548259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_ADR_ORT:ORT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:FK_ADR_LAND:ORT_2:KOORDINATEN'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12597010661116013)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12596670637116010)
,p_button_name=>'Kopie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kopie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2398368511413988)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(360324645600174)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2153308344145993)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(12596670637116010)
,p_button_name=>'Add_to_page'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add To Page'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(361835627600189)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(12596670637116010)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:228:&SESSION.::&DEBUG.:RP,228:P228_PK_ABL_ORDNER,P228_PK_ABL_ORDNER_PAGE:,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18877686278602403)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(12596670637116010)
,p_button_name=>'move_to'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Move_to'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>7
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13804881578389873)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(12596670637116010)
,p_button_name=>'Delete_Beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete Beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10724071766503033)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10710940188502970)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:229'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11598076833016521)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10710940188502970)
,p_button_name=>'OLD_BELEGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Old belege'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:241:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(360161729600172)
,p_name=>'P228_PK_ABL_ORDNER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(12596670637116010)
,p_prompt=>'Pk Abl Ordner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(361560518600186)
,p_name=>'P228_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12596670637116010)
,p_prompt=>'<b>Pk Abl Ordner Page</b>'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number || '' ('' || pk_abl_ordner_page || '')'' d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12596955267116012)
,p_name=>'P228_ANZAHL_KOPIEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12596670637116010)
,p_prompt=>'Anzahl Kopien'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18877796961602404)
,p_name=>'P228_PK_ABL_ORDNER_PAGE_TO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(12596670637116010)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number || '' ('' || pk_abl_ordner_page || '')'' d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12597129302116014)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_COPY_INP_BEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'       p_inp_bel_cop( apex_application.g_f01(i), :P228_ANZAHL_KOPIEN);',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12597010661116013)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2153192619145992)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Add_to_page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update inp_belege_all set fk_ABL_ORDNER_PAGE  = :P228_PK_ABL_ORDNER_PAGE where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2153308344145993)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13805055752389874)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_delete_Beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      delete from  inp_belege_all where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13804881578389873)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18877953892602405)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_move_to_page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update inp_belege_all set fk_ABL_ORDNER_PAGE  = :P228_PK_ABL_ORDNER_PAGE_to where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18877686278602403)
);
wwv_flow_api.component_end;
end;
/
