prompt --application/pages/page_00243
begin
--   Manifest
--     PAGE: 00243
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>243
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Lexware Buchungen'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Lexware Buchungen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200626144610'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12075257581988574)
,p_plug_name=>'Lexware Buchungen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'      apex_item.checkbox2(1,pk_lex) sel_pk,',
'      apex_item.checkbox2(2,Belegnummer) sel_bel,',
'      apex_item.checkbox2(3,fk_Main_key) sel_fk_main_key,',
'      BELEGDATUM,',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLUESSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRAEGER,',
'       BUCHUNGSBETRAG_EURO,',
'       WAEHRUNG,',
'       ZUSATZANGABEN,',
'       OK,',
'       STORNO,',
'       PK_LEX,',
'       BEMERKUNGEN,',
'       datum_ok,',
'       fk_main_key,',
'       fk_imp_ba_bel,',
'       bezeichnung',
'  from T_LEX lex',
'    left join t_lex_kontenplan_konten kto on kto.konten_nr_ext = lex.sollkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12075289791988574)
,p_name=>'Lexware Buchungen'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>21385425032409495
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12075709881988606)
,p_db_column_name=>'SEL_PK'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sel Pk'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12076101741988609)
,p_db_column_name=>'SEL_BEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Sel Bel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12076502645988609)
,p_db_column_name=>'SEL_FK_MAIN_KEY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Sel Fk Main Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12076888683988610)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12077364381988610)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12077744375988611)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12078080047988611)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12078509682988612)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12078943859988612)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12079334994988612)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12079711220988613)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12080148283988613)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12080937618988615)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12081741049988616)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12082550915988617)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12082956239988618)
,p_db_column_name=>'OK'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12083360947988618)
,p_db_column_name=>'STORNO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12083668852988619)
,p_db_column_name=>'PK_LEX'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Pk Lex'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12084068095988620)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12084561977988620)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12084938924988621)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12085293293988622)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12085725656988623)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720088728903966)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>36
,p_column_identifier=>'AA'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720195049903967)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>46
,p_column_identifier=>'AB'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720362668903968)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>56
,p_column_identifier=>'AC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12086464283999230)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'213966'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL_PK:SEL_BEL:SEL_FK_MAIN_KEY:BELEGDATUM:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BELEGNUMMER:BUCHUNGSTEXT:BUCHUNGSBETRAG:SOLLKONTO:HABENKONTO:KOSTENSTELLE:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:OK:STORNO:PK_LEX:BEMERKUNGEN:DATUM_OK:FK_MAIN_KEY:FK'
||'_IMP_BA_BEL:BEZEICHNUNG:STEUERSCHLUESSEL:KOSTENTRAEGER:WAEHRUNG'
);
wwv_flow_api.component_end;
end;
/
