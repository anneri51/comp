prompt --application/pages/page_00267
begin
--   Manifest
--     PAGE: 00267
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>267
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Projekt - Location'
,p_step_title=>'Projekt - Location'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42863836018282035)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200627102022'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3337587918170539)
,p_plug_name=>'Projekt - Location'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    apex_item.checkbox2(1, pk_inp_belege_ALL) SEL,',
'    proj.projekt, ',
'    persoenlich_vor_ort, ',
'    pk_inp_belege_all, ',
'    loc.land, ',
'    loc.ort, ',
'    la.land bel_land,',
'    ort.ort bel_ort,',
'    bel_datum, ',
'    loc.pk_loc_location, ',
'    loc.fk_adr_adresse, ',
'    proj.von, ',
'    proj.bis,',
'    inp1.bezeichnung,',
'    inv.pk_inv_inventar,',
'    inv.inventar || '' ('' ||anschaffungsjahr || '')'' inventar,',
'    inp1.fk_std_verw_verwendungszweck,',
'    ver.std_name verwendungszweck,',
'    Kategorie, ',
'    pk_bas_kat_konto_buch',
'    datum_vergehen',
'from t_inp_belege_all inp1 ',
' left join v_loc_location loc on inp1.fk_loc_location = loc.pk_loc_location',
' left Join t_proj_projekt proj on proj.pk_proj_projekt = inp1.fk_proj_projekt',
' left join t_inv_inventare inv on inv.pk_inv_inventar = inp1.fk_inv_inventar',
' left join (select * from t_std where fk_std_group = 9) ver on ver.std_value = inp1.fk_std_verw_verwendungszweck',
' left join t_bas_kat_konto_buch kat on kat.pk_bas_kat_konto_buch = inp1.fk_bas_kat_kategorie',
' left join t_adr_land la on la.pk_adr_land = inp1.fk_adr_land',
' left join t_adr_ort ort on ort.pk_adr_ort = inp1.fk_adr_city'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3337718547170539)
,p_name=>'Projekr - Location'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>4778037822562079
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3338101147170552)
,p_db_column_name=>'PROJEKT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3338390913170567)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3338834109170567)
,p_db_column_name=>'LAND'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3339188111170567)
,p_db_column_name=>'ORT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3339678374170567)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3359733942738468)
,p_db_column_name=>'VON'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3359867166738469)
,p_db_column_name=>'BIS'
,p_display_order=>37
,p_column_identifier=>'J'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3360277187738473)
,p_db_column_name=>'SEL'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3360470323738475)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3360615912738477)
,p_db_column_name=>'INVENTAR'
,p_display_order=>77
,p_column_identifier=>'N'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3360854206738479)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>97
,p_column_identifier=>'P'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3361111573738482)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>117
,p_column_identifier=>'S'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004058523079594)
,p_db_column_name=>'BEL_LAND'
,p_display_order=>127
,p_column_identifier=>'T'
,p_column_label=>'Bel Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004153683079595)
,p_db_column_name=>'BEL_ORT'
,p_display_order=>137
,p_column_identifier=>'U'
,p_column_label=>'Bel Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433506270411502)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>147
,p_column_identifier=>'V'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433645169411503)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>157
,p_column_identifier=>'W'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433738262411504)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>167
,p_column_identifier=>'X'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433795018411505)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>177
,p_column_identifier=>'Y'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433905043411506)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>187
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52434036587411507)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>197
,p_column_identifier=>'AA'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3341253919187174)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'47816'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:PROJEKT:VON:BIS:BEL_DATUM:PK_INP_BELEGE_ALL:LAND:ORT::BEZEICHNUNG:INVENTAR:VERWENDUNGSZWECK:DATUM_VERGEHEN:BEL_LAND:BEL_ORT:PERSOENLICH_VOR_ORT:PK_LOC_LOCATION:FK_ADR_ADRESSE:PK_INV_INVENTAR:FK_STD_VERW_VERWENDUNGSZWECK:KATEGORIE'
,p_sort_column_1=>'BEL_DATUM'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3360060068738471)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3361555416738486)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3360060068738471)
,p_button_name=>'NeuesProjekt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Neuesprojekt'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:269:&SESSION.::&DEBUG.:RP,269:P269_PK_PROJEKT:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3360105292738472)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3360060068738471)
,p_button_name=>'ADD_PROJEKT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add to Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3361379386738484)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(3360060068738471)
,p_button_name=>'Projekt_bearbeiten'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Projekt Bearbeiten'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:269:&SESSION.::&DEBUG.:RP,269:P269_PK_PROJEKT:&P267_PK_PROJEKT.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1816056736252686)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(3360060068738471)
,p_button_name=>'Projektliste'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Projektliste'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:266:&SESSION.::&DEBUG.:RP,266::'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3359964024738470)
,p_name=>'P267_PK_PROJ_PROJEKT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3360060068738471)
,p_prompt=>'Pk Proj Projekt'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || pk_proj_projekt || '') '' || to_char(von,''DD.MM.YYYY'') || '' - '' || to_char(bis, ''DD.MM.YYYY'')  d, pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3360321222738474)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update t_inp_belege_all set fk_proj_projekt = :P267_PK_proj_PROJEKT where pk_inp_belege_all = apex_application.g_f01(i);',
'      commit;',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3360105292738472)
);
wwv_flow_api.component_end;
end;
/
