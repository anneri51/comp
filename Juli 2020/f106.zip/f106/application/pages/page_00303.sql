prompt --application/pages/page_00303
begin
--   Manifest
--     PAGE: 00303
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>303
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'vorsteuerabzug'
,p_step_title=>'vorsteuerabzug'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42881936682393325)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090223'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7002169654079575)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7461572791258600)
,p_plug_name=>'vorsteuerabzug'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zus.FK_MAIN_KEY,',
'       ID,',
'       "Buchungstag",',
'       "Betrag",',
unistr('       "W\00E4hrung",'),
unistr('       "Fremdw\00E4hrungsbetrag",'),
unistr('       "Fremdw\00E4hrung",'),
'       BUCHUNGSTEXT,',
'       "FK_Kategorie",',
'       "FK_Verwendungszweck",',
'       "FK_Kontotyp",',
'       FK_BUCHUNGSTAG,',
'       FK_WERTSTELLUNG,',
'       VERWENDUNGSZWECK,',
'       KATEGORIE,',
'       BUCHT_TAG,',
'       BUCHT_MONAT,',
'       BUCHT_JAHR,',
'       BUCHT_DATUM,',
'       WERTT_TAG,',
'       WERTT_MONAT,',
'       WERTT_JAHR,',
'       WERTT_DATUM,',
'       "Kontotyp",',
'       FK_VORGANG,',
'       WIEDERHOLUNG,',
'       NAECHSTE_ZAHLUNG,',
'       FK_BUCHUNG_STEUER,',
'       FK_KONTO,',
'       KTO_BEZEICHNUNG,',
'       IBAN,',
'       BANK,',
'       case when fk_relation is not null then 1 else 0 end exist_fk_relation,',
'       fk_relation',
'  from V_KONTEN_ZUS zus',
'   left join (select listagg(fk_relation || '' ('' || status || '')'' || '' '' || betrag,'','') within group (order by fk_main_key) fk_relation, fk_main_key from t_rel_lex_kto_bel bel left join t_lex_long ll on bel.fk_relation = ll.relation   where fk_main_k'
||'ey is not null group by fk_main_key  ) kto on kto.fk_main_key = zus.fk_main_key',
' where bucht_jahr = :P303_Jahr and bucht_monat = :P303_Monat'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7461665737258600)
,p_name=>'vorsteuerabzug'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>8901985012650140
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462036281258620)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462404162258627)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7462873799258627)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7463200432258627)
,p_db_column_name=>'Betrag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7463639144258628)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7464068629258628)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7464468050258628)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7464835382258628)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7465265274258628)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7465595207258630)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7466042402258630)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7466403207258630)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7466861485258631)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467192972258631)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467676672258631)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7467991778258631)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7468440502258633)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7468784991258633)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7469235265258633)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7469614002258633)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470046968258633)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470430260258633)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7470783225258635)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7471229055258635)
,p_db_column_name=>'Kontotyp'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7471651576258635)
,p_db_column_name=>'FK_VORGANG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fk Vorgang'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7472041093258635)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7472846314258636)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7473261285258636)
,p_db_column_name=>'IBAN'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003632471079590)
,p_db_column_name=>'FK_KONTO'
,p_display_order=>49
,p_column_identifier=>'AE'
,p_column_label=>'Fk Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003685791079591)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>59
,p_column_identifier=>'AF'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003787054079592)
,p_db_column_name=>'BANK'
,p_display_order=>69
,p_column_identifier=>'AG'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003971882079593)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>79
,p_column_identifier=>'AH'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974607025962287)
,p_db_column_name=>'EXIST_FK_RELATION'
,p_display_order=>89
,p_column_identifier=>'AI'
,p_column_label=>'Exist Fk Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974779965962288)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>99
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7473869422260153)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'89142'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>unistr('Kontotyp:FK_KONTO:KTO_BEZEICHNUNG:BANK:KATEGORIE:VERWENDUNGSZWECK:FK_MAIN_KEY:ID:Buchungstag:Betrag:FK_RELATION:W\00E4hrung:Fremdw\00E4hrungsbetrag:Fremdw\00E4hrung:BUCHUNGSTEXT:FK_Kategorie:FK_Verwendungszweck:FK_Kontotyp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:BUCHT_TA')
||'G:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:FK_VORGANG:WIEDERHOLUNG:FK_BUCHUNG_STEUER:IBAN:NAECHSTE_ZAHLUNG:EXIST_FK_RELATION:'
,p_break_on=>'Kontotyp:FK_KONTO:WIEDERHOLUNG'
,p_break_enabled_on=>'Kontotyp:FK_KONTO:WIEDERHOLUNG'
,p_sum_columns_on_break=>'Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9390380475107510)
,p_report_id=>wwv_flow_api.id(7473869422260153)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EXIST_FK_RELATION'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("EXIST_FK_RELATION" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9203974114769553)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204271880772061)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontenblatt'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204506509773364)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9204825598774877)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Kontenauswahl'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontenauswahl'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9254070852912699)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(7461572791258600)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7002253801079576)
,p_name=>'P303_MONAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7002169654079575)
,p_prompt=>'Monat'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Januar;1,Februar;2,M\00E4rz;3,April;4,Mai;5,Juni;6,Juli;7,August;8,September;9,Oktober;10,November;11,Dezember;12')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7002331353079577)
,p_name=>'P303_JAHR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7002169654079575)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value, std_value',
'from t_std ',
'where fk_std_group = 221'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
