prompt --application/pages/page_00306
begin
--   Manifest
--     PAGE: 00306
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>306
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kontoblatt_IR'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kontoblatt_IR'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200708141227'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7976405739962305)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8190015197173467)
,p_plug_name=>'Kontoblatt_IR'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum rnr,',
' a.*',
' from (',
'select   ',
'    ',
'       BUCHUNGSNUMMER,',
'',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'',
'',
'       OK,',
'       sum(habenbetrag_eur) sum_habenbetrag_eur,',
'       sum(sollbetrag_eur) sum_sollbetrag_eur,',
'              sum(habenbetrag_eur) -',
'       sum(sollbetrag_eur) diff,',
'',
'buchungsstatus,',
'count(*),',
'     fk_lex_relation1,',
'     fk_lex_relation2,',
'     std_name storno,',
'     rellex.bemerkung ,',
'     pk_rel_lex_lex',
'  from (select * from  t_lex_kontenblatt  where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                      jahr, nr, fk_lex_relation,',
'                      listagg(relkto.fk_main_key || '' '' || substr(zus."Buchungstag",1,10) || '' '' || zus."Betrag" || '' '' || zus.buchungstext || '' '' || Kontotyp || '' '' || kto.iban,'','') within group (order by relkto.fk_main_key) lg,',
'                      listagg(relkto.fk_main_key || case when zus.fk_main_key is null then '''' else '' ('' ||  zus.fk_kto_bankkonto || '')'' end,'','') within group (order by relkto.fk_main_key) lex_bkkto',
'                  from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto',
'                      left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                      left join (select * from t_kto_bankkonto where valid = 1) kto on zus.fk_kto_bankkonto = kto.pk_kto_bankkonto and trunc(zus."Buchungstag") between valid_from and valid_to',
'                      join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   where relkto.fk_lex_relation is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relkto on to_char(relkto.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'    left join (',
'                   select nr, jahr, fk_lex_relation,',
'                   listagg(inp.pk_inp_belege_all || '' '' || brutto_betrag || '' '' || zahl_art_name || '' '' || bezeichnung || '' '' || bel_datum || '' '' || case when fk_inv_inventar is not null then ''Inventar: '' || fk_inv_inventar end ,'','') within group (or'
||'der by inp.pk_inp_belege_all) lb,',
'                   listagg(inp.pk_inp_belege_all || case when fk_std_kto_zahlungsart = 3 then '' (01600)'' else '''' end )  within group (order by inp.pk_inp_belege_all) lex_kto',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_inp_belege_all inp on inp.pk_inp_belege_all = relkto.fk_inp_belege_all',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                  where pk_inp_belege_all is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relbel on to_char(relbel.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'             ',
'    left join (',
'                select  pk_rel_lex_lex, id, bemerkung, std_name, fk_lex_relation1, fk_lex_relation2',
'                    from t_rel_lex_lex lex ',
'                        join t_lex_kontenblatt kto1 on ( lex.fk_lex_relation1 = kto1.fk_lex_relation_sub or  lex.fk_lex_relation2 = kto1.fk_lex_relation_sub )',
'                        join (select * from t_std where fk_std_group = 281 and std_value = 2) std on std.std_value = lex.fk_rel_type_lex_lex',
'                        ) rellex on rellex.id = kto.id',
'                    ',
'   group by   ',
'       BUCHUNGSNUMMER,',
'',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'',
'       OK,',
'',
'buchungsstatus,',
'     ',
'     fk_lex_relation1,',
'     fk_lex_relation2,',
'     std_name ,',
'     rellex.bemerkung ,',
'     pk_rel_lex_lex',
'     order by buchungsnummer',
'     ) a'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8190165196173467)
,p_name=>'Kontoblatt_IR'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>9630484471565007
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8190561229173488)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8191598444173503)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8192011484173503)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8192474908173503)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8195242776173506)
,p_db_column_name=>'OK'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8300896516210167)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286505833362594)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>83
,p_column_identifier=>'AI'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286621641362595)
,p_db_column_name=>'SUM_HABENBETRAG_EUR'
,p_display_order=>93
,p_column_identifier=>'AJ'
,p_column_label=>'Sum Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286778665362596)
,p_db_column_name=>'SUM_SOLLBETRAG_EUR'
,p_display_order=>103
,p_column_identifier=>'AK'
,p_column_label=>'Sum Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286796837362597)
,p_db_column_name=>'DIFF'
,p_display_order=>113
,p_column_identifier=>'AL'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286934693362598)
,p_db_column_name=>'RNR'
,p_display_order=>123
,p_column_identifier=>'AM'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721837920796279)
,p_db_column_name=>'STORNO'
,p_display_order=>153
,p_column_identifier=>'AP'
,p_column_label=>'Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721962433796280)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>163
,p_column_identifier=>'AQ'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722558557796286)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>173
,p_column_identifier=>'AR'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_column_linktext=>'#PK_REL_LEX_LEX#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790607936417984)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>183
,p_column_identifier=>'AS'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790752366417985)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>193
,p_column_identifier=>'AT'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8203008156231860)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'96434'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSNUMMER:BUCHUNGSSTATUS:BELEGDATUM:BELEGNUMMER:BUCHUNGSTEXT:OK::COUNT(*):SUM_HABENBETRAG_EUR:SUM_SOLLBETRAG_EUR:DIFF:RNR:STORNO:BEMERKUNG:PK_REL_LEX_LEX:FK_LEX_RELATION1:FK_LEX_RELATION2'
,p_break_on=>'BUCHUNGSNUMMER'
,p_break_enabled_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR1:HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14353916071339213)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14354355120339214)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C0CCC0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14354742099339216)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14353487973339211)
,p_report_id=>wwv_flow_api.id(8203008156231860)
,p_name=>'ok1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_row_bg_color=>'#79B827'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11596756221840288)
,p_application_user=>'ANNE'
,p_name=>unistr('Buchungs\00FCbersicht')
,p_report_seq=>10
,p_report_columns=>'BUCHUNGSNUMMER:BUCHUNGSSTATUS:BELEGDATUM:BELEGNUMMER:BUCHUNGSTEXT:OK'
,p_break_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR1:HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597224947840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597337617840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597093833840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_name=>'ok1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_row_bg_color=>'#79B827'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11596850705840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11596914703840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11597063599840289)
,p_report_id=>wwv_flow_api.id(11596756221840288)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTONUMMER'
,p_operator=>'contains'
,p_expr=>'6680'
,p_condition_sql=>'upper("KONTONUMMER") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''6680''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8300702862210165)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14283207104362561)
,p_plug_name=>'Kontoblatt_IR1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select    case when buchungsstatus is null and ok is null   then  apex_item.checkbox2(1,kto.id,''CHECKED'')  else  apex_item.checkbox2(1,kto.id) end sel,',
'      apex_item.checkbox(2, ''j'' || kto.jahr || ''bu'' || kto.buchungsnummer || ''be'' || kto.belegnummer) sel_book ,',
'       kto.id,',
'       BUCHUNGSNUMMER,',
'       KONTONUMMER,',
'       KONTOBEZEICHNUNG,',
'       BELEGDATUM,',
'       BELEGNUMMER,',
'       BUCHUNGSTEXT,',
'       GEGENKONTO,',
'       SOLLBETRAG_EUR,',
'       HABENBETRAG_EUR,',
'       USTKONTO,',
'       UST,',
'       DATUM_OK,',
'       OK,',
'       SOLLBETRAG_EUR1,',
'buchungsstatus,',
'lg,',
'lb,',
'abs(nvl(SOLLBETRAG_EUR,0))+abs(nvl(HABENBETRAG_EUR,0)) SEARCH_EUR,',
'kto.jahr,',
'',
'       kto.kst kst_ktbl,',
'       kto.ktr ktr_ktbl,',
'      nvl(lex_bkkto, lex_kto) lex_bkkto,',
'      datum_steuer_ok,',
'      split_nr,',
'      kto.fk_lex_relation',
'      fk_lex_relation_sub,',
'      split_nr_man,',
'      flg_split_buch,',
'      rellex.fk_lex_relation1,',
'      rellex.fk_lex_relation2,',
'      rellex.bemerkung rellex_bemerkung,',
'      rellex.std_name storno,',
'      pk_rel_lex_lex,',
'      kto.fk_lex_relation,',
'        row_number() over (partition by kto.buchungsnummer, kto.belegnummer, kto.jahr, kto.kontonummer order by kto.id ) rnr,',
'        fk_bas_kal_belegdatum',
'  from (select * from t_lex_kontenblatt where (belegnummer = :P306_Belegnr and jahr = :P306_Jahr) or  :P306_Belegnr is null or :P306_Jahr is null) kto',
'       left join (select ',
'                      jahr, nr, fk_lex_relation,',
'                      listagg(relkto.fk_main_key || '' '' || substr(zus."Buchungstag",1,10) || '' '' || zus."Betrag" || '' '' || zus.buchungstext || '' '' || Kontotyp || '' '' || kto.iban,'','') within group (order by relkto.fk_main_key) lg,',
'                      listagg(relkto.fk_main_key || case when zus.fk_main_key is null then '''' else '' ('' ||  fk_kto_bankkonto || '')'' end,'','') within group (order by relkto.fk_main_key) lex_bkkto',
'                  from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                      left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                      left join (select * from t_kto_bankkonto where valid = 1) kto on zus.fk_kto_bankkonto = kto.pk_kto_bankkonto and trunc(zus."Buchungstag") between valid_from and valid_to',
'                      join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   where relkto.fk_lex_relation is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relkto on to_char(relkto.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'    left join (',
'                   select nr, jahr, fk_lex_relation,',
'                   listagg(inp.pk_inp_belege_all || '' '' || brutto_betrag || '' '' || zahl_art_name || '' '' || bezeichnung || '' '' || bel_datum || '' '' || case when fk_inv_inventar is not null then ''Inventar: '' || fk_inv_inventar end ,'','') within group (or'
||'der by inp.pk_inp_belege_all) lb,',
'                   listagg(inp.pk_inp_belege_all || case when fk_std_kto_zahlungsart = 3 then '' (01600)'' else '''' end )  within group (order by inp.pk_inp_belege_all) lex_kto',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_inp_belege_all inp on inp.pk_inp_belege_all = relkto.fk_inp_belege_all',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                  where pk_inp_belege_all is not null',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relbel on to_char(relbel.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0''',
'                         ',
'    left join (',
'                select  pk_rel_lex_lex, id, bemerkung, std_name, fk_lex_relation1, fk_lex_relation2',
'                    from t_rel_lex_lex lex ',
'                        join t_lex_kontenblatt kto1 on ( lex.fk_lex_relation1 = kto1.fk_lex_relation_sub or  lex.fk_lex_relation2 = kto1.fk_lex_relation_sub )',
'                        join (select * from t_std where fk_std_group = 281 and std_value = 2) std on std.std_value = lex.fk_rel_type_lex_lex',
'                        ) rellex on rellex.id = kto.id',
'   '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14283401875362563)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15723721150754103
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283499950362564)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283593874362565)
,p_db_column_name=>'LEX_BKKTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Lex Bkkto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283726624362566)
,p_db_column_name=>'DATUM_STEUER_OK'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Datum Steuer Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14283804776362567)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284034597362569)
,p_db_column_name=>'SPLIT_NR_MAN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Split Nr Man'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284082452362570)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284279898362571)
,p_db_column_name=>'SEL_BOOK'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sel Book'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284350914362572)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284388157362573)
,p_db_column_name=>'KONTOBEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Kontobezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284565616362574)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284652045362575)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284740340362576)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284807560362577)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14284913928362578)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Habenbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#HABENBETRAG_EUR#'
,p_column_linktext=>'#HABENBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285075052362579)
,p_db_column_name=>'USTKONTO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Ustkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285145181362580)
,p_db_column_name=>'UST'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285202331362581)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285351225362582)
,p_db_column_name=>'OK'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285398390362583)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Sollbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#SOLLBETRAG_EUR#'
,p_column_linktext=>'#SOLLBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285570931362584)
,p_db_column_name=>'SOLLBETRAG_EUR1'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Sollbetrag Eur1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285599565362585)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285704284362586)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285793527362587)
,p_db_column_name=>'LG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14285901331362588)
,p_db_column_name=>'SEARCH_EUR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Search Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286074545362589)
,p_db_column_name=>'LB'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Lb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286170604362590)
,p_db_column_name=>'JAHR'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286258763362591)
,p_db_column_name=>'ID'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286345787362592)
,p_db_column_name=>'KST_KTBL'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Kst Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14286416361362593)
,p_db_column_name=>'KTR_KTBL'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ktr Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722190893796283)
,p_db_column_name=>'RELLEX_BEMERKUNG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Rellex Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722293141796284)
,p_db_column_name=>'STORNO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722613508796287)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_column_linktext=>'#PK_REL_LEX_LEX#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15056462148097995)
,p_db_column_name=>'RNR'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790803154417986)
,p_db_column_name=>'FK_LEX_RELATION_SUB'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Fk Lex Relation Sub'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53790946997417987)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791036513417988)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791132548417989)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53791206012417990)
,p_db_column_name=>'FK_BAS_KAL_BELEGDATUM'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Belegdatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14312495770383147)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'157529'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSNUMMER:SEL_BOOK:SEL:KONTONUMMER:KONTOBEZEICHNUNG:BELEGNUMMER:BUCHUNGSTEXT:KST_KTBL:KTR_KTBL:GEGENKONTO:HABENBETRAG_EUR:SOLLBETRAG_EUR:SEARCH_EUR:USTKONTO:UST:BUCHUNGSSTATUS:OK:LEX_BKKTO:LG:LB:JAHR:ID:SOLLBETRAG_EUR1:DATUM_OK:SPLIT_NR:DATUM_ST'
||'EUER_OK:SPLIT_NR_MAN:FLG_SPLIT_BUCH:RELLEX_BEMERKUNG:STORNO:PK_REL_LEX_LEX:BELEGDATUM:RNR::FK_BELEGDATUM_SUB12:FK_LEX_RELATION:FK_BAS_KAL_BELEGDATUM'
,p_break_on=>'BUCHUNGSNUMMER'
,p_break_enabled_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15300977635239139)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5EEB8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15301333830239139)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'ok2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>12
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15300568509239139)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#79B827'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15301766307239139)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_name=>'sel_book'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_BOOK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL_BOOK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_column_bg_color=>'#EDC2ED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15300099339239138)
,p_report_id=>wwv_flow_api.id(14312495770383147)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'RNR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"RNR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14283379732362562)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14283207104362561)
,p_button_name=>'Relation_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8300544945210163)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Set_Buchungsstatus'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Buchungsstatus'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8212509211291208)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Set_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14759824331132506)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Steuer_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Steuer Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14760085286134308)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Steuer_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Steuer Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15172798645332647)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11577058016419164)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7976405739962305)
,p_button_name=>'Reset_Belegnr'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Reset Belegnr'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP,306:P306_BUCHUNGSSTATUS,P306_JAHR,P306_BELEGNR:&P306_BUCHUNGSSTATUS.,&P306_JAHR.,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7973905370962280)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8300702862210165)
,p_button_name=>'Remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Remove'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9254295501929160)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8190015197173467)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Relation'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7976054899962301)
,p_name=>'P306_BELEGNR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7976405739962305)
,p_prompt=>'Belegnr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8300813179210166)
,p_name=>'P306_BUCHUNGSSTATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8300702862210165)
,p_prompt=>'Buchungsstatus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 201'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10833056431140964)
,p_name=>'P306_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7976405739962305)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15056373923097994)
,p_name=>'P306_DATUM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8300702862210165)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Datum'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8212453297291207)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'begin',
'',
'  --sel 1 -- single line',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_kontenblatt set ok = 2, datum_ok = sysdate, buchungsstatus = nvl(buchungsstatus, 1) where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'    ',
'       ',
'   -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        update  t_lex_kontenblatt set ok = 2, datum_ok = sysdate, buchungsstatus = nvl(buchungsstatus, 1) where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8212509211291208)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8300609864210164)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_Buchungsstatus'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'',
'begin',
' ',
' ',
' --sel 1 -- single line',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'        update  t_lex_kontenblatt set buchungsstatus = :P306_Buchungsstatus where id  = apex_application.g_f01(i);',
'        commit;',
'    end if;',
'    end loop;',
'    ',
'   -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        update  t_lex_kontenblatt set buchungsstatus = :P306_Buchungsstatus where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8300544945210163)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7974078165962281)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_jahr number;',
' v_bu number;',
' v_bel number;',
'begin',
'  --sel 1 - each line',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     delete from  t_lex_kontenblatt  where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'    ',
'  -- sel 2 - 1 booking',
'    for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        select ',
'                substr(apex_application.g_f02(i),2,4) jahr, ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''bu'')+2,instr(apex_application.g_f02(i),''be'')-(instr(apex_application.g_f02(i),''bu'')+2)) bu,  ',
'                substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),''be'')+2,length(apex_application.g_f02(i))) bel',
'        into v_jahr, v_bu, v_bel',
'        from dual;',
'        ',
'        delete from  t_lex_kontenblatt  where jahr = v_jahr and buchungsnummer = v_bu and belegnummer = v_bel;',
'        commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7973905370962280)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14760333682138960)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Steuer_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      ',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = sysdate where id = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14759824331132506)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14760636066139900)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Steuer_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'   ',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = null where id= apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14760085286134308)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15176361527702097)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15172798645332647)
);
wwv_flow_api.component_end;
end;
/
