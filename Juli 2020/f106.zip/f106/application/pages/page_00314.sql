prompt --application/pages/page_00314
begin
--   Manifest
--     PAGE: 00314
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>314
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kasse'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kasse'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200610034818'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10217497032300441)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1, pk_kto_kas_kasse) sel ,',
'       kas.PK_kto_KAS_KASSE,',
'       kas.FK_bas_kto_KONTOTYP,',
'       kas.FK_EIN_AUS,',
'       kas.DATUM,',
'       kas.BETRAG,',
'       kas.BUCHUNGSTEXT,',
'       kas.COMM,',
'       kas.JAHR,',
'       kas.CREATION_DATE,',
'       kas.FK_MAIN_KEY,',
'       kas.FK_kto_bankKONTO,',
'       kas.FREMDWAEHRUNGSBETRAG,',
'       kas.FK_bas_mon_FREMDWAEHRUNG,',
'       kas.FK_bas_kal_ARBEITSTAG,',
'       kas.FK_bas_kat_KATEGORIE,',
'       kas.FK_bas_std_VERWENDUNGSZWECK,',
'       kas.FK_inv_INVENTAR,',
'       kas.FK_loc_LOCATION,',
'       rellex.fk_lex_relation,',
'       case when rellex.fk_lex_relation is not null then 1 else 0 end lex_buch,',
'      lex.sum_betrag,',
'      arb.tag arb_tag,',
'      arb.monat arb_monat,',
'      arb.jahr arb_jahr,',
'      kas.fk_main_key_bankkonto,',
'      kas.datum_var,',
'',
'kas.FK_steu_STEUER_MONAT,',
'kas.FK_steu_STEUER_VORANMELDG,',
'',
'',
'kas.GEBueHREN,',
'kas.GESAMT_BETRAG',
'',
'  from t_kto_KAS_KASSE kas',
'   left join t_rel_lex_kto_bel rellex on rellex.fk_main_key = kas.fk_main_key',
'   left join (select sum(betrag) sum_betrag, relation from t_lex_long group by relation) lex on lex.relation = rellex.fk_lex_relation',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = kas.fk_bas_kal_arbeitstag'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10217942614300441)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:315:&SESSION.::&DEBUG.:RP:P315_PK_KTO_KAS_KASSE:#PK_KTO_KAS_KASSE##PK_KAS_KASSE#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>11658261889691981
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10218876349300447)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10219218798300447)
,p_db_column_name=>'DATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10219595446300447)
,p_db_column_name=>'BETRAG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10220059513300449)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252:P252_FK_MAIN_KEY,P252_FK_RELATION_DISPLAY_ONLY:#FK_MAIN_KEY#,#COMM#'
,p_column_linktext=>'#BUCHUNGSTEXT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10220445794300449)
,p_db_column_name=>'COMM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10220829038300449)
,p_db_column_name=>'JAHR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10221273495300449)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10221637160300450)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10171886643959995)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10347358531308566)
,p_db_column_name=>'LEX_BUCH'
,p_display_order=>110
,p_column_identifier=>'T'
,p_column_label=>'Lex Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10347427347308567)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>120
,p_column_identifier=>'U'
,p_column_label=>'Sum Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10347908121308572)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>130
,p_column_identifier=>'V'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348062428308573)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>140
,p_column_identifier=>'W'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348096420308574)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>150
,p_column_identifier=>'X'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348399537308577)
,p_db_column_name=>'FK_MAIN_KEY_BANKKONTO'
,p_display_order=>160
,p_column_identifier=>'Y'
,p_column_label=>'Fk Main Key Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36609258433519068)
,p_db_column_name=>'SEL'
,p_display_order=>170
,p_column_identifier=>'Z'
,p_column_label=>' <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36610698386519083)
,p_db_column_name=>'GESAMT_BETRAG'
,p_display_order=>210
,p_column_identifier=>'AD'
,p_column_label=>'Gesamt Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40458171238191687)
,p_db_column_name=>'DATUM_VAR'
,p_display_order=>220
,p_column_identifier=>'AE'
,p_column_label=>'Datum Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552330344578093)
,p_db_column_name=>'PK_KTO_KAS_KASSE'
,p_display_order=>230
,p_column_identifier=>'AF'
,p_column_label=>'Pk Kto Kas Kasse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552440959578094)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>240
,p_column_identifier=>'AG'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552511662578095)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>250
,p_column_identifier=>'AH'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552586264578096)
,p_db_column_name=>'FK_BAS_MON_FREMDWAEHRUNG'
,p_display_order=>260
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Mon Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552701649578097)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>270
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552838732578098)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>280
,p_column_identifier=>'AK'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46552958067578099)
,p_db_column_name=>'FK_BAS_STD_VERWENDUNGSZWECK'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Std Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553030545578100)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553140080578101)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553277718578102)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553353668578103)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553455949578104)
,p_db_column_name=>'FK_STEU_STEUER_VORANMELDG'
,p_display_order=>340
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Steu Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46553526249578105)
,p_db_column_name=>'GEBUEHREN'
,p_display_order=>350
,p_column_identifier=>'AR'
,p_column_label=>'Gebuehren'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10229725582610335)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'116701'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ARB_JAHR:ARB_MONAT:SEL:FK_EIN_AUS:DATUM:BETRAG:GESAMT_BETRAG:BUCHUNGSTEXT:COMM:JAHR:CREATION_DATE:FK_MAIN_KEY:FK_MAIN_KEY_BANKKONTO:FREMDWAEHRUNGSBETRAG:LEX_BUCH:SUM_BETRAG:ARB_TAG::DATUM_VAR:PK_KTO_KAS_KASSE:FK_BAS_KTO_KONTOTYP:FK_KTO_BANKKONTO:FK_B'
||'AS_MON_FREMDWAEHRUNG:FK_BAS_KAL_ARBEITSTAG:FK_BAS_KAT_KATEGORIE:FK_BAS_STD_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_LOC_LOCATION:FK_LEX_RELATION:FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMELDG:GEBUEHREN'
,p_sort_column_1=>'ARB_TAG'
,p_sort_direction_1=>'ASC'
,p_break_on=>'ARB_JAHR:ARB_MONAT'
,p_break_enabled_on=>'ARB_JAHR:ARB_MONAT'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36692499908043042)
,p_report_id=>wwv_flow_api.id(10229725582610335)
,p_name=>'Abbuchung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'<'
,p_expr=>'0'
,p_condition_sql=>' (case when ("BETRAG" < to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# < #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#F5A6F5'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36692921615043044)
,p_report_id=>wwv_flow_api.id(10229725582610335)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LEX_BUCH'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("LEX_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36692147618043042)
,p_report_id=>wwv_flow_api.id(10229725582610335)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10224032712300463)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10217497032300441)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:315:&SESSION.::&DEBUG.:315'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10363648107684920)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10217497032300441)
,p_button_name=>'Update_Kasse'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Update fk_main_key tag'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(36609297899519069)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10217497032300441)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10223003218300461)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(10217497032300441)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10223541058300461)
,p_event_id=>wwv_flow_api.id(10223003218300461)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(10217497032300441)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10363868276686261)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Tag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'',
'        ',
'        ',
'   update t_kto_Kas_Kasse set FK_MAIN_KEY = t_KTO_bankKONTO_SEQ.nextval where fk_main_key is null;',
'   ',
'   merge into t_kto_kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from t_kto_kas_kasse kas',
' left join v_kto_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'    ',
'    merge into t_kto_kas_kasse t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'       pk_kto_kas_kasse',
'',
'        from (select * from t_kto_kas_kasse where datum is not null and fk_bas_kal_arbeitstag is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kto_kas_kasse = t2.pk_kto_kas_kasse)',
'        when matched then',
'        update set t1.fk_bas_kal_arbeitstag= t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update t_kto_kas_kasse set fk_kto_bankkonto = 61 where fk_kto_bankkonto is null;',
'   update t_kto_kas_kasse set fk_bas_kto_kontotyp = 6 where fk_bas_kto_kontotyp is null;',
'   update t_kto_kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10363648107684920)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12143820786878881)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Tag_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'',
'        ',
'        ',
'   update Kas_Kasse set FK_MAIN_KEY = KTO_KONTO_SEQ.nextval where fk_main_key is null;',
'   commit;',
'   ',
'   merge into kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from kas_kasse kas',
' left join v_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'    ',
'    merge into kas_kasse t1',
'  using (',
'        select pk_arbeitstage, ',
'       pk_kas_kasse',
'',
'        from (select * from kas_kasse where datum is not null and fk_arbeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kas_kasse = t2.pk_kas_kasse)',
'        when matched then',
'        update set t1.fk_arbeitstag= t2.pk_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update kas_kasse set fk_konto = 61 where fk_konto is null;',
'   update kas_kasse set fk_kontotyp = 6 where fk_kontotyp is null;',
'   update kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10224032712300463)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(36609423228519070)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    delete from Kas_kasse where pk_kas_kasse = apex_application.g_f01(i);',
'    commit;',
'  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(36609297899519069)
);
wwv_flow_api.component_end;
end;
/
