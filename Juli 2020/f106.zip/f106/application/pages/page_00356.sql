prompt --application/pages/page_00356
begin
--   Manifest
--     PAGE: 00356
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>356
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'kontenabgleich_2017'
,p_step_title=>'kontenabgleich_2017'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42901582232549956)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090708'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15220129687119289)
,p_plug_name=>'kontenabgleich_2018'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2020_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2020 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2018'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15220260701119290)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>16660579976510830
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220358618119291)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220447232119292)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220508583119293)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220622798119294)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220700485119295)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220847236119296)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15220947093119297)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221012302119298)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221094527119299)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221192749119300)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221311705119301)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221391175119302)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221497015119303)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15221622933119304)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15416932353179461)
,p_db_column_name=>'RNR'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417007704179462)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417156784179463)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417224633179464)
,p_db_column_name=>'RNR1'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417338333179465)
,p_db_column_name=>'ID'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417427968179466)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417566704179467)
,p_db_column_name=>'DATUM'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15431846683215502)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'168722'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KTO2_BUCH:JAHR_IST:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGDATUM:KTO2_DATUM:MISS:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEITSTAGE:DATUM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15417853689179470)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29987292164205050)
,p_plug_name=>'kontenabgleich_2017'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
', kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2017_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2017 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2017'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29987327125205050)
,p_name=>'kontenabgleich'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>31427646400596590
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14889966193513652)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14890296482513652)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14890738302513653)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14891100363513653)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14891534409513655)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14891920947513655)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14892327800513655)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14892730008513655)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14893159656513655)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14885530239513631)
,p_db_column_name=>'JAHR'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14885937071513644)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14886332656513644)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14886685243513645)
,p_db_column_name=>'MISS'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14887103018513645)
,p_db_column_name=>'KTO2_HABENBETR'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Kto2 Habenbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14887538636513645)
,p_db_column_name=>'KTO2_SOLLBETR'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Kto2 Sollbetr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14887975141513647)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>79
,p_column_identifier=>'P'
,p_column_label=>'Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14888333634513647)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>89
,p_column_identifier=>'Q'
,p_column_label=>'Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14888726436513649)
,p_db_column_name=>'DIFF_HABEN'
,p_display_order=>99
,p_column_identifier=>'R'
,p_column_label=>'Diff Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14889160376513649)
,p_db_column_name=>'DIFF_SOLL'
,p_display_order=>109
,p_column_identifier=>'S'
,p_column_label=>'Diff Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14889540931513650)
,p_db_column_name=>'RNR'
,p_display_order=>119
,p_column_identifier=>'T'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14893534185513656)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>129
,p_column_identifier=>'U'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14893940482513656)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>139
,p_column_identifier=>'V'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14894317250513656)
,p_db_column_name=>'RNR1'
,p_display_order=>149
,p_column_identifier=>'W'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14894725825513658)
,p_db_column_name=>'ID'
,p_display_order=>159
,p_column_identifier=>'X'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14895096421513658)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>169
,p_column_identifier=>'Y'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14895562345513658)
,p_db_column_name=>'DATUM'
,p_display_order=>179
,p_column_identifier=>'Z'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14895878013513660)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>189
,p_column_identifier=>'AA'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29991526254208842)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'163365'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KTO2_BUCH:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGKTO2_MISS:KTO2_HABENBETR:KTO2_SOLLBETR:HABENBETRAG_EUR:SOLLBETRAG_EUR:DIFF_HABEN:DIFF_SOLL:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEIT'
||'STAGE:DATUM:JAHR_IST'
,p_break_on=>'KTO2_BUCH'
,p_break_enabled_on=>'KTO2_BUCH'
,p_count_columns_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14898237710513672)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_name=>'diff_jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF_JAHR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DIFF_JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14898599235513674)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_name=>'dupl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RNR1'
,p_operator=>'>'
,p_expr=>'1'
,p_condition_sql=>' (case when ("RNR1" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F2D9F2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14897857660513672)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_name=>'missing'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("BUCHUNGSNUMMER" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>25
,p_row_bg_color=>'#F0D9D3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14896638985513670)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>'"BUCHUNGSNUMMER" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14897031745513672)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KTO2_KONTO'
,p_operator=>'contains'
,p_expr=>'1600'
,p_condition_sql=>'upper("KTO2_KONTO") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1600  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14897389179513672)
,p_report_id=>wwv_flow_api.id(29991526254208842)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MISS'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"MISS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39078477369894287)
,p_plug_name=>'kontenabgleich_2019'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2019_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2019 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2019'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39078519778894288)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40518839054285828
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39078662585894289)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39078760456894290)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39078797298894291)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39078951118894292)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079008985894293)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079160474894294)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079279442894295)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079369392894296)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079463295894297)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079558914894298)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079673713894299)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079717684894300)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079844474894301)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079894036894302)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39079984428894303)
,p_db_column_name=>'RNR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080159200894304)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080248063894305)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080317063894306)
,p_db_column_name=>'RNR1'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080438856894307)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080559889894308)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39080630458894309)
,p_db_column_name=>'DATUM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39176284923473810)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'406167'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KTO2_BUCH:JAHR_IST:KTO2_BELEG:BUCHUNGSNUMMER:BELEGNUMMER:KTO2_KONTO:KTO2_GEGENKTO:KONTONUMMER:GEGENKONTO:BUCHUNGSTEXT:JAHR:BELEGDATUM:KTO2_DATUM:MISS:RNR:DIFF_JAHR:ARB_JAHR:RNR1:ID:PK_ARBEITSTAGE:DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(39177282514480344)
,p_report_id=>wwv_flow_api.id(39176284923473810)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNUMMER'
,p_operator=>'is null'
,p_condition_sql=>'"BUCHUNGSNUMMER" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(39177707032480344)
,p_report_id=>wwv_flow_api.id(39176284923473810)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KTO2_KONTO'
,p_operator=>'='
,p_expr=>'1401'
,p_condition_sql=>'"KTO2_KONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39080692904894310)
,p_plug_name=>'kontenabgleich_2020'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto2.buchungsnummer kto2_buch, kto2.belegnummer kto2_beleg, kto.buchungsnummer, kto.belegnummer, kto2.kontonummer kto2_konto, ',
'kto2.gegenkonto kto2_gegenkto, kto.kontonummer, kto.gegenkonto, kto.buchungstext, kto.jahr, kto.belegdatum, kto2.belegdatum kto2_datum, ',
'case when kto.buchungsnummer is null then 1 else 0 end miss',
'--, kto2.habenbetrag_eur kto2_habenbetr, kto2.sollbetrag_eur kto2_sollbetr, kto.habenbetrag_eur, kto.sollbetrag_eur, kto2.habenbetrag_eur - kto.habenbetrag_eur diff_haben, kto2.sollbetrag_eur - kto.sollbetrag_eur diff_soll',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, kto2.kontonummer, kto2.gegenkonto order by kto2.belegnummer) rnr',
', case when nvl(arb.jahr,0) <> kto.jahr then 1 else 0 end diff_jahr',
', arb.jahr arb_jahr',
', row_number() over (partition by kto2.belegnummer, kto2.buchungsnummer, substr(kto2.belegdatum, 7,4) order by kto2.belegdatum) rnr1',
',kto.id',
', arb_ist.pk_arbeitstage',
', arb_ist.datum',
', arb_ist.jahr jahr_ist',
'from imp_kontenblatt_2020_2 kto2',
' left join imp_kontenblatt_2018 kto on kto2.buchungsnummer = kto.buchungsnummer and kto2.belegnummer  = kto.belegnummer and kto.jahr = 2020 and kto2.kontonummer = kto.kontonummer ',
' left join t_arbeitstage arb on arb.pk_arbeitstage= kto.fk_belegdatum',
'  left join t_arbeitstage arb_ist on arb_ist.datum = kto.belegdatum',
' --and kto2.gegenkonto = kto.gegenkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P356_SEL'
,p_plug_display_when_cond2=>'2020'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39156306918454661)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40596626193846201
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156472730454662)
,p_db_column_name=>'KTO2_BUCH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kto2 Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156495110454663)
,p_db_column_name=>'JAHR_IST'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Jahr Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156674773454664)
,p_db_column_name=>'KTO2_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Kto2 Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156770536454665)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156866367454666)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNUMMER#,#JAHR#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156949601454667)
,p_db_column_name=>'KTO2_KONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kto2 Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39156993759454668)
,p_db_column_name=>'KTO2_GEGENKTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kto2 Gegenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157114541454669)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157221963454670)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157315775454671)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157404921454672)
,p_db_column_name=>'JAHR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157496021454673)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157672663454674)
,p_db_column_name=>'KTO2_DATUM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kto2 Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157765973454675)
,p_db_column_name=>'MISS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Miss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157845047454676)
,p_db_column_name=>'RNR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39157977146454677)
,p_db_column_name=>'DIFF_JAHR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Diff Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39158011627454678)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39158160808454679)
,p_db_column_name=>'RNR1'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Rnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39158194518454680)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39158355838454681)
,p_db_column_name=>'PK_ARBEITSTAGE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39158399212454682)
,p_db_column_name=>'DATUM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15417945171179471)
,p_name=>'P356_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15417853689179470)
,p_prompt=>'Sel'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2017;2017,2018;2018,2019;2019,2020;2020'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
