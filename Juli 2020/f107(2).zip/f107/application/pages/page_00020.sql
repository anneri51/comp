prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(20543567030983233)
,p_name=>'Materialdupletten'
,p_alias=>'MATERIALDUPLETTEN'
,p_step_title=>'Materialdupletten'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200731164603'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22626494056704628)
,p_plug_name=>'Materialdupletten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select materialbezeichnung,grundpreis, count(*) cnt',
'from t_masch_material',
'group by  materialbezeichnung, grundpreis'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Materialdupletten'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22626552000704628)
,p_name=>'Materialdupletten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>22626552000704628
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22626915685704632)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22627331484704632)
,p_db_column_name=>'GRUNDPREIS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Grundpreis'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22627784887704632)
,p_db_column_name=>'CNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22628360411707215)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'226284'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MATERIALBEZEICHNUNG:GRUNDPREIS:CNT'
,p_sort_column_1=>'CNT'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(22629218980711580)
,p_report_id=>wwv_flow_api.id(22628360411707215)
,p_name=>'dupl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT'
,p_operator=>'>'
,p_expr=>'1'
,p_condition_sql=>' (case when ("CNT" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFD6D2'
);
wwv_flow_api.component_end;
end;
/
