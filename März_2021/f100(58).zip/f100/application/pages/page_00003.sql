prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Adressen'
,p_alias=>'ADRESSEN_3'
,p_step_title=>'Adressen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42862188611255483)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(41030239536197395)
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210310122829'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6281302677155576)
,p_plug_name=>'Adressen'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    "PK_ADR_ADRESSE",',
'    "STRASSE",',
'    "HSNR",',
'    "BESCHREIBUNG",',
'    "FK_ADR_ORT",',
'    "POSTFACH",',
'    plz,',
'    ort,',
'    pk_adr_plz_ort',
'from "T_ADR_ADRESSE" ta',
'    left join t_adr_plz_ort tpo on tpo.pk_adr_plz_ort = ta.fk_adr_plz_ort',
'    left join t_adr_ort tor on tor.pk_adr_ort = tpo.fk_adr_ort ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_customized=>'1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6281767384155577)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_PK_ADR_ADRESSE:#PK_ADR_ADRESSE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6281767384155577
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6282671671155593)
,p_db_column_name=>'STRASSE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6283010832155595)
,p_db_column_name=>'HSNR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6283356693155596)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6284136610155598)
,p_db_column_name=>'POSTFACH'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(115267709374981)
,p_db_column_name=>'PLZ'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(115428661374982)
,p_db_column_name=>'ORT'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682993105596794)
,p_db_column_name=>'PK_ADR_ADRESSE'
,p_display_order=>37
,p_column_identifier=>'K'
,p_column_label=>'Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44683161279596795)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>47
,p_column_identifier=>'L'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44683195189596796)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>57
,p_column_identifier=>'M'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6286317085155983)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'62864'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STRASSE:HSNR:BESCHREIBUNG:FK_POSTFACH:PLZ:ORT:PK_ADR_ADRESSE:FK_ADR_ORT:PK_ADR_PLZ_ORT'
,p_break_on=>'ORT:PLZ'
,p_break_enabled_on=>'ORT:PLZ'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6284544974155598)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6281302677155576)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4'
);
wwv_flow_api.component_end;
end;
/
