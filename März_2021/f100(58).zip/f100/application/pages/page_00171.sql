prompt --application/pages/page_00171
begin
--   Manifest
--     PAGE: 00171
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>171
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Paypalzuordnung'
,p_alias=>'PAYPALZUORDNUNG_171'
,p_page_mode=>'MODAL'
,p_step_title=>'Paypalzuordnung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210108175133'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3783836364134182)
,p_plug_name=>'Kreditkonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
' apex_item.checkbox2(2, fk_main_key) sel,',
' round(kred.Betrag,2) wert, ',
' kred.*,',
' case when abs(:P171_SEL_VALUE ) = abs(kred.Betrag) then 1 else 0 end  sel_value,',
' case when kto.pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zugeord,',
' case when kto_zu.pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_fin ',
'from t_KTO_Kreditkarte kred',
'  left join (select kto_in.* from  t_rel_kto_kont_buch_kont_buch kto_in left join t_KTO_Paypal pay_in on kto_in.fk_kto_konto_buch1 = pay_in.fk_main_key where pay_in.id = :P171_SEL_ID) kto on kto.fk_kto_konto_buch2 = kred.fk_main_key',
'  left join (select kto_in1.* from t_rel_kto_kont_buch_kont_buch kto_in1 join t_KTO_Paypal pay_in1 on kto_in1.fk_kto_konto_buch1 = pay_in1.fk_main_key) kto_zu  on kto_zu.fk_kto_konto_buch2 = kred.fk_main_key',
'where instr(Unternehmen,''PAYPAL'')>0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3786633432134210)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13096768672555131
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3786683768134211)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'C'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3788335880134227)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>170
,p_column_identifier=>'H'
,p_column_label=>'Fk main beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3788437896134228)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>180
,p_column_identifier=>'G'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3873761947528483)
,p_db_column_name=>'SEL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874181132528488)
,p_db_column_name=>'WERT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874558514528491)
,p_db_column_name=>'SEL_VALUE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Sel value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875289123528499)
,p_db_column_name=>'ZUGEORD'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Zugeord'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875962049528505)
,p_db_column_name=>'ZUORD_FIN'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Zuord fin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5429738412463422)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932854816886890)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>280
,p_column_identifier=>'AC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932936542886891)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>290
,p_column_identifier=>'AD'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933049712886892)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933114110886893)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933193964886894)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933360925886895)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933440931886896)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933547084886897)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933636286886898)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933759280886899)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933800950886900)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933948313886901)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49933981695886902)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934133813886903)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934257959886904)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934291710886905)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934399192886906)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>440
,p_column_identifier=>'AS'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934571367886907)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>450
,p_column_identifier=>'AT'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934603554886908)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>460
,p_column_identifier=>'AU'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870840197845716)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>470
,p_column_identifier=>'AV'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870990335845717)
,p_db_column_name=>'BELEG'
,p_display_order=>480
,p_column_identifier=>'AW'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871014782845718)
,p_db_column_name=>'UNTERNEHMEN'
,p_display_order=>490
,p_column_identifier=>'AX'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871123989845719)
,p_db_column_name=>'BETRAG'
,p_display_order=>500
,p_column_identifier=>'AY'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871287462845720)
,p_db_column_name=>'BETRAG_URSPRUNG'
,p_display_order=>510
,p_column_identifier=>'AZ'
,p_column_label=>'Betrag Ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871332614845721)
,p_db_column_name=>'BELASTETE_KREDITKARTE'
,p_display_order=>520
,p_column_identifier=>'BA'
,p_column_label=>'Belastete Kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871405808845722)
,p_db_column_name=>'WERTSTELLUNGSMONAT'
,p_display_order=>530
,p_column_identifier=>'BB'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871563575845723)
,p_db_column_name=>'DUMMY'
,p_display_order=>540
,p_column_identifier=>'BC'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871654867845724)
,p_db_column_name=>'REFERENZ'
,p_display_order=>550
,p_column_identifier=>'BD'
,p_column_label=>'Referenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871784116845725)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>560
,p_column_identifier=>'BE'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871889372845726)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>570
,p_column_identifier=>'BF'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17871939118845727)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>580
,p_column_identifier=>'BG'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17872081101845728)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>590
,p_column_identifier=>'BH'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17872188081845729)
,p_db_column_name=>'KONTOSTAND_EUR'
,p_display_order=>600
,p_column_identifier=>'BI'
,p_column_label=>'Kontostand Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3885385367529821)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131956'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:ID:ZUGEORD:WERT:FK_MAIN_FK_MAIN_KEY:SEL_VALUE::ZUORD_FIN:BEMERKUNG:WAEHRUNG:WAEHRUNG_URSPRUNG:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_FK_BEL_FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHL'
||'UNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BEMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:BUCHUNGSTAG:BELEG:UNTERNEHMEN:BETRAG:BETRAG_URSPRUNG:BELASTETE_KREDITKARTE:WERTSTELLUNGSMONAT:DUMMY:REFERENZ:FK_STD_CONTR_STATUS_KA'
||'T:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:KONTOSTAND_EUR'
,p_sort_column_1=>'WERT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'Buchungstag'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'Belastete Kreditkarte'
,p_break_enabled_on=>'Belastete Kreditkarte'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3939772284226924)
,p_report_id=>wwv_flow_api.id(3885385367529821)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_FIN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_FIN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3940204159226925)
,p_report_id=>wwv_flow_api.id(3885385367529821)
,p_name=>'Sel_Value'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_VALUE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_VALUE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3940565103226926)
,p_report_id=>wwv_flow_api.id(3885385367529821)
,p_name=>'zugeordnet'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUGEORD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUGEORD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#41B034'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3783882505134183)
,p_plug_name=>'Girokonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' apex_item.checkbox2(3, fk_main_key) sel,',
' round(kred.Betrag,2) wert,',
' kred.*, ',
' case when abs(:P171_SEL_VALUE ) = abs(kred.Betrag) then 1 else 0 end  sel_value,',
' case when kto.pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zugeord,',
' case when kto_zu.pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_fin',
'from t_KTO_Girokonto kred',
'  left join (select kto_in.* from  t_rel_kto_kont_buch_kont_buch kto_in left join t_KTO_Paypal pay_in on kto_in.fk_kto_konto_buch1 = pay_in.fk_main_key',
'             where pay_in.id = :P171_SEL_ID) kto on kto.fk_kto_konto_buch2 = kred.fk_main_key',
'  left join t_rel_kto_kont_buch_kont_buch kto_zu on kto_zu.fk_kto_konto_buch2 = kred.fk_main_key',
'where instr(Buchungstext,''PAYPAL'')>0'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3784047131134184)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13094182371555105
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3784088006134185)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'V'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3785197857134196)
,p_db_column_name=>'F12'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'F12'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3785357354134197)
,p_db_column_name=>'F13'
,p_display_order=>130
,p_column_identifier=>'J'
,p_column_label=>'F13'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3785865518134203)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>190
,p_column_identifier=>'D'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3786169274134206)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>220
,p_column_identifier=>'A'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3873773658528484)
,p_db_column_name=>'SEL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874351475528489)
,p_db_column_name=>'WERT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874600017528492)
,p_db_column_name=>'SEL_VALUE'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Sel value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875404259528500)
,p_db_column_name=>'ZUGEORD'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Zugeord'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875984558528506)
,p_db_column_name=>'ZUORD_FIN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Zuord fin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876259484099997)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876500911100000)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876635333100001)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876716909100002)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876784023100003)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876914428100004)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877059317100005)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877105127100006)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877233545100007)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877281731100008)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877449127100009)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49877552265100010)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49929980646886861)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49929983622886862)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930135782886863)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930191365886864)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930377666886865)
,p_db_column_name=>'SALDO'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930452134886866)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930533910886867)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930603085886868)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930778834886869)
,p_db_column_name=>'FK_KON_EMPFAENGER'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Kon Empfaenger'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930826244886870)
,p_db_column_name=>'BUCHUNGSTAG_DT'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Buchungstag Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49930958222886871)
,p_db_column_name=>'WERTSTELLUNG_DT'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Wertstellung Dt'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931075246886872)
,p_db_column_name=>'BUCHUNGSTAG_VAR'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Buchungstag Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931105489886873)
,p_db_column_name=>'WERTSTELLUNG_VAR'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Wertstellung Var'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931249698886874)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931352977886875)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931471905886876)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931519036886877)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931667969886878)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931682700886879)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931847348886880)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49931899615886881)
,p_db_column_name=>'BEGUENSTIGTER'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Beguenstigter'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932051309886882)
,p_db_column_name=>'IBAN_ZUSATZ'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Iban Zusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932124746886883)
,p_db_column_name=>'BIC'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Bic'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932212784886884)
,p_db_column_name=>'MANDATSREFERENZ'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Mandatsreferenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932350650886885)
,p_db_column_name=>'GLAEUBIGER'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Glaeubiger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932428091886886)
,p_db_column_name=>'FREMDGEBUEHREN'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Fremdgebuehren'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932573757886887)
,p_db_column_name=>'ABWEICHENDEREMPFAENGER'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Abweichenderempfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932620082886888)
,p_db_column_name=>'ANZAHLAUFTRAEGE'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Anzahlauftraege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49932763998886889)
,p_db_column_name=>'ANZAHLSCHECKS'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Anzahlschecks'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17742321604595149)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17742470731595150)
,p_db_column_name=>'WERTSTELLUNG'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869345101845701)
,p_db_column_name=>'UMSATZART'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869493683845702)
,p_db_column_name=>'BUCHUNGSTEXT1'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Buchungstext1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869566450845703)
,p_db_column_name=>'BETRAG'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869655812845704)
,p_db_column_name=>'AUFTRAGGEBERKONTO'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869742142845705)
,p_db_column_name=>'BANKLEITZAHL_AUFTRAGGEBERKONTO'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869836109845706)
,p_db_column_name=>'ALT_ID'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Alt Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17869912841845707)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870029714845708)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870187552845709)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870247065845710)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870384741845711)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870401632845712)
,p_db_column_name=>'OFFENER_BETRAG'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Offener Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870527553845713)
,p_db_column_name=>'DATUM_FAELLIGKEIT'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Datum Faelligkeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870664316845714)
,p_db_column_name=>'FK_BAS_KAL_DATUM_FAELLIGKEIT'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Fk Bas Kal Datum Faelligkeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17870771302845715)
,p_db_column_name=>'KONTOSTAND_EUR'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Kontostand Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3872825490525248)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131830'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:ID:WERT:Bankleitzahl IBAN Kategorie:F12:F13:FK_MAIN_KEY:BUCHUNGSTEXT::SEL_VALUE:ZUGEORD:ZUORD_FIN:WAEHRUNG:IBAN_KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_FK_BAS_KAL_FK_KTO_BANKKONTO:KONTOSTAND:WIED'
||'ERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_VORGANG:FK_LOC_LOCATION:EMPFAENGER:SALDO:KONTONUMMER:AUFTRAGGEBER:FK_KON_AUFTRAGGEBER:FK_KON_EMPFAENGER_DT_DT_VAR_VAR:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FLG_KREDITKARTENBUCHUNG:LOAD_DA'
||'TE:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:BEGUENSTIGTER:IBAN_ZUSATZ:BIC:MANDATSREFERENZ:GLAEUBIGER:FREMDGEBUEHREN:ABWEICHENDEREMPFAENGER:ANZAHLAUFTRAEGE:ANZAHLSCHECKS:BUCHUNGSTAG:WERTSTELLUNG:UMSATZART:BUCHUNGSTEXT1:BETRAG:AUFTRAGGEBERKONTO:BANKLEITZAHL_AUF'
||'TRAGGEBERKONTO:ALT_ID:BEMERKUNGEN:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:OFFENER_BETRAG:DATUM_FAELLIGKEIT:FK_BAS_KAL_DATUM_FAELLIGKEIT:KONTOSTAND_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3941354647231295)
,p_report_id=>wwv_flow_api.id(3872825490525248)
,p_name=>'Sel_value'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_VALUE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_VALUE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3941737381231297)
,p_report_id=>wwv_flow_api.id(3872825490525248)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_FIN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_FIN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3942125534231299)
,p_report_id=>wwv_flow_api.id(3872825490525248)
,p_name=>'Zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUGEORD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUGEORD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#41B034'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3806094382327155)
,p_plug_name=>'Paypalzuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ',
'       apex_item.checkbox2(1,  pay.fk_main_key) sel,',
'       pay.ID,',
'       pay.Datum,',
'       pay.Uhrzeit,',
'       pay.Zeitzone,',
'       pay.Name,',
'       pay.Typ,',
'       pay.Status,',
'       pay.Waehrung,',
'       round(pay.Brutto,2) Brutto,',
'       pay.Gebuehr,',
'       pay.Netto,',
'       pay.Absender_Email,',
'       pay.Empfaenger_Email,',
'       pay.Transaktionscode,',
'       pay.Lieferadresse,',
'       pay.Adress_Status,',
'       pay.Artikelbezeichnung,',
'       pay.Artikelnummer,',
'       pay.Versand_Bearbeitungsgebuehr,',
'       pay.Versicherungsbetrag,',
'       pay.Umsatzsteuer,',
'       pay.Option_1_Name,',
'       pay.Option_1_Wert,',
'       pay.Option_2_Name,',
'       pay.Option_2_Wert,',
'       pay.Zugehoeriger_Transaktionscode,',
'       pay.Rechnungsnummer,',
'       pay.Zollnummer,',
'       pay.Anzahl,',
'       pay.Empfangsnummer,',
'       pay.Guthaben,',
'       pay.Adresszeile_1,',
'       pay.Adresszusatz,',
'       pay.Ort,',
'       pay.Bundesland,',
'       pay.PLZ,',
'       pay.Land,',
'       pay.Telefon,',
'       pay.Betreff,',
'       pay.Hinweis,',
'       pay.Laendervorwahl,',
'       pay.Auswirkung_Guthaben,',
'       pay.FK_bas_kat_Kategorie,',
'       pay.FK_std_verw_Verwendungszweck,',
'       pay.FK_std_kto_Kontotyp,',
'       pay.FK_kto_VORGANG,',
'       pay.FK_MAIN_KEY,',
'       pay.FK_bas_kal_ARBEITSTAG,',
'       pay.FK_ZUORD_ERL,',
'       case when abs(:P171_SEL_VALUE ) = abs(pay.Brutto) then 1 else 0 end  sel_value,',
'       case when :P171_SEL_ID = pay.ID then 1 else 0 end sel_id,',
'       kont_vor.cnt cnt_vor,',
'       kont.cnt ',
'  from t_KTO_Paypal pay',
'    left join (  ',
'                    select ',
'                       count(*) cnt, ',
'                       kto.fk_kto_konto_buch1 ,',
'                       pay_in.fk_kto_vorgang',
'                    from  t_rel_kto_kont_buch_kont_buch kto',
'                       join t_KTO_Paypal pay_in on pay_in.fk_main_key = kto.fk_kto_konto_buch1',
'                    group by kto.fk_kto_konto_buch1,',
'                        pay_in.fk_kto_vorgang',
'             ) kont_vor on pay.fk_kto_vorgang = kont_vor.fk_kto_vorgang',
'     left join (  ',
'                    select ',
'                       count(*) cnt, ',
'                       kto.fk_kto_konto_buch1 ',
'                    from  t_rel_kto_kont_buch_kont_buch kto',
'                       join t_KTO_Paypal pay_in on pay_in.fk_main_key = kto.fk_kto_konto_buch1',
'                    group by kto.fk_kto_konto_buch1',
'             ) kont on pay.fk_main_key = kont.fk_kto_konto_buch1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3806183519327155)
,p_name=>'Paypalzuordnung'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:RP:P171_SEL_VALUE,P171_SEL_ID,P171_SEL_VORGANG:#Brutto#,#ID#,#FK_VORGANG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13116318759748076
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3806881753327167)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3820907306327183)
,p_db_column_name=>'PLZ'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3825354699327186)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3873569807528482)
,p_db_column_name=>'SEL'
,p_display_order=>88
,p_column_identifier=>'AZ'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874943633528495)
,p_db_column_name=>'SEL_VALUE'
,p_display_order=>98
,p_column_identifier=>'BA'
,p_column_label=>'Sel value'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3874967467528496)
,p_db_column_name=>'SEL_ID'
,p_display_order=>108
,p_column_identifier=>'BB'
,p_column_label=>'Sel id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875134369528497)
,p_db_column_name=>'CNT'
,p_display_order=>118
,p_column_identifier=>'BC'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875173289528498)
,p_db_column_name=>'CNT_VOR'
,p_display_order=>128
,p_column_identifier=>'BD'
,p_column_label=>'Cnt vor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3875728792528503)
,p_db_column_name=>'FK_ZUORD_ERL'
,p_display_order=>138
,p_column_identifier=>'BE'
,p_column_label=>'Fk zuord erl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875048048099985)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>148
,p_column_identifier=>'BF'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875123345099986)
,p_db_column_name=>'GEBUEHR'
,p_display_order=>158
,p_column_identifier=>'BG'
,p_column_label=>'Gebuehr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875226240099987)
,p_db_column_name=>'EMPFAENGER_EMAIL'
,p_display_order=>168
,p_column_identifier=>'BH'
,p_column_label=>'Empfaenger Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875290039099988)
,p_db_column_name=>'ZUGEHOERIGER_TRANSAKTIONSCODE'
,p_display_order=>178
,p_column_identifier=>'BI'
,p_column_label=>'Zugehoeriger Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875569345099990)
,p_db_column_name=>'LAENDERVORWAHL'
,p_display_order=>198
,p_column_identifier=>'BK'
,p_column_label=>'Laendervorwahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875624024099991)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>208
,p_column_identifier=>'BL'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875700937099992)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>218
,p_column_identifier=>'BM'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875846689099993)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>228
,p_column_identifier=>'BN'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49875922284099994)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>238
,p_column_identifier=>'BO'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49876038934099995)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>248
,p_column_identifier=>'BP'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17738835173595114)
,p_db_column_name=>'DATUM'
,p_display_order=>258
,p_column_identifier=>'BQ'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17738966562595115)
,p_db_column_name=>'UHRZEIT'
,p_display_order=>268
,p_column_identifier=>'BR'
,p_column_label=>'Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739007693595116)
,p_db_column_name=>'ZEITZONE'
,p_display_order=>278
,p_column_identifier=>'BS'
,p_column_label=>'Zeitzone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739144977595117)
,p_db_column_name=>'NAME'
,p_display_order=>288
,p_column_identifier=>'BT'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739297466595118)
,p_db_column_name=>'TYP'
,p_display_order=>298
,p_column_identifier=>'BU'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739371250595119)
,p_db_column_name=>'STATUS'
,p_display_order=>308
,p_column_identifier=>'BV'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739437516595120)
,p_db_column_name=>'BRUTTO'
,p_display_order=>318
,p_column_identifier=>'BW'
,p_column_label=>'Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739527861595121)
,p_db_column_name=>'NETTO'
,p_display_order=>328
,p_column_identifier=>'BX'
,p_column_label=>'Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739632962595122)
,p_db_column_name=>'ABSENDER_EMAIL'
,p_display_order=>338
,p_column_identifier=>'BY'
,p_column_label=>'Absender Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739734002595123)
,p_db_column_name=>'TRANSAKTIONSCODE'
,p_display_order=>348
,p_column_identifier=>'BZ'
,p_column_label=>'Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739857317595124)
,p_db_column_name=>'LIEFERADRESSE'
,p_display_order=>358
,p_column_identifier=>'CA'
,p_column_label=>'Lieferadresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17739913144595125)
,p_db_column_name=>'ADRESS_STATUS'
,p_display_order=>368
,p_column_identifier=>'CB'
,p_column_label=>'Adress Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740043649595126)
,p_db_column_name=>'ARTIKELBEZEICHNUNG'
,p_display_order=>378
,p_column_identifier=>'CC'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740125083595127)
,p_db_column_name=>'ARTIKELNUMMER'
,p_display_order=>388
,p_column_identifier=>'CD'
,p_column_label=>'Artikelnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740276464595128)
,p_db_column_name=>'VERSAND_BEARBEITUNGSGEBUEHR'
,p_display_order=>398
,p_column_identifier=>'CE'
,p_column_label=>'Versand Bearbeitungsgebuehr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740335584595129)
,p_db_column_name=>'VERSICHERUNGSBETRAG'
,p_display_order=>408
,p_column_identifier=>'CF'
,p_column_label=>'Versicherungsbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740488677595130)
,p_db_column_name=>'UMSATZSTEUER'
,p_display_order=>418
,p_column_identifier=>'CG'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740568483595131)
,p_db_column_name=>'OPTION_1_NAME'
,p_display_order=>428
,p_column_identifier=>'CH'
,p_column_label=>'Option 1 Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740657952595132)
,p_db_column_name=>'OPTION_1_WERT'
,p_display_order=>438
,p_column_identifier=>'CI'
,p_column_label=>'Option 1 Wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740750024595133)
,p_db_column_name=>'OPTION_2_NAME'
,p_display_order=>448
,p_column_identifier=>'CJ'
,p_column_label=>'Option 2 Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740818573595134)
,p_db_column_name=>'OPTION_2_WERT'
,p_display_order=>458
,p_column_identifier=>'CK'
,p_column_label=>'Option 2 Wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17740929101595135)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>468
,p_column_identifier=>'CL'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741058559595136)
,p_db_column_name=>'ZOLLNUMMER'
,p_display_order=>478
,p_column_identifier=>'CM'
,p_column_label=>'Zollnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741184815595137)
,p_db_column_name=>'ANZAHL'
,p_display_order=>488
,p_column_identifier=>'CN'
,p_column_label=>'Anzahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741261030595138)
,p_db_column_name=>'EMPFANGSNUMMER'
,p_display_order=>498
,p_column_identifier=>'CO'
,p_column_label=>'Empfangsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741379041595139)
,p_db_column_name=>'GUTHABEN'
,p_display_order=>508
,p_column_identifier=>'CP'
,p_column_label=>'Guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741451862595140)
,p_db_column_name=>'ADRESSZEILE_1'
,p_display_order=>518
,p_column_identifier=>'CQ'
,p_column_label=>'Adresszeile 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741581029595141)
,p_db_column_name=>'ADRESSZUSATZ'
,p_display_order=>528
,p_column_identifier=>'CR'
,p_column_label=>'Adresszusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741684564595142)
,p_db_column_name=>'ORT'
,p_display_order=>538
,p_column_identifier=>'CS'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741701496595143)
,p_db_column_name=>'BUNDESLAND'
,p_display_order=>548
,p_column_identifier=>'CT'
,p_column_label=>'Bundesland'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741858376595144)
,p_db_column_name=>'LAND'
,p_display_order=>558
,p_column_identifier=>'CU'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17741957385595145)
,p_db_column_name=>'TELEFON'
,p_display_order=>568
,p_column_identifier=>'CV'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17742025140595146)
,p_db_column_name=>'BETREFF'
,p_display_order=>578
,p_column_identifier=>'CW'
,p_column_label=>'Betreff'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17742124420595147)
,p_db_column_name=>'HINWEIS'
,p_display_order=>588
,p_column_identifier=>'CX'
,p_column_label=>'Hinweis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17742246309595148)
,p_db_column_name=>'AUSWIRKUNG_GUTHABEN'
,p_display_order=>598
,p_column_identifier=>'CY'
,p_column_label=>'Auswirkung Guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3872182397525215)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131824'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'FK_ZUORD_ERL:ID:FK_MAIN_KEY:CNT:PLZ:Auswirkung_FK_Kategorie:SEL_VALUE:SEL_ID:CNT_VOR::WAEHRUNG:GEBUEHR:EMPFAENGER_EMAIL:ZUGEHOERIGER_LAENDERVORWAHL:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOFK_KTO_VORGANG:FK_BAS_KAL_ARBEITSTAG'
||':DATUM:UHRZEIT:ZEITZONE:NAME:TYP:STATUS:BRUTTO:NETTO:ABSENDER_EMAIL:TRANSAKTIONSCODE:LIEFERADRESSE:ADRESS_STATUS:ARTIKELBEZEICHNUNG:ARTIKELNUMMER:VERSAND_BEARBEITUNGSGEBUEHR:VERSICHERUNGSBETRAG:UMSATZSTEUER:OPTION_1_NAME:OPTION_1_WERT:OPTION_2_NAME:O'
||'PTION_2_WERT:RECHNUNGSNUMMER:ZOLLNUMMER:ANZAHL:EMPFANGSNUMMER:GUTHABEN:ADRESSZEILE_1:ADRESSZUSATZ:ORT:BUNDESLAND:LAND:TELEFON:BETREFF:HINWEIS:AUSWIRKUNG_GUTHABEN'
,p_break_on=>'FK_VORGANG'
,p_break_enabled_on=>'FK_VORGANG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4046434696942181)
,p_report_id=>wwv_flow_api.id(3872182397525215)
,p_name=>'SEL_VALUE'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_VALUE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_VALUE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4045979102942180)
,p_report_id=>wwv_flow_api.id(3872182397525215)
,p_name=>unistr('keine Zuordnung m\00F6glich')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_ZUORD_ERL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_ZUORD_ERL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>14
,p_row_bg_color=>'#D9D9D9'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4045257194942177)
,p_report_id=>wwv_flow_api.id(3872182397525215)
,p_name=>'zugeordnet'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_VOR'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("CNT_VOR" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4045603287942179)
,p_report_id=>wwv_flow_api.id(3872182397525215)
,p_name=>'Zuordnung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("CNT" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_row_bg_color=>'#41B034'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4046770636942181)
,p_report_id=>wwv_flow_api.id(3872182397525215)
,p_name=>'sel_id'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_ID'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_ID" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3873916805528485)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17872213398845730)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_list_id=>wwv_flow_api.id(7926368973409904)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7262397714999326)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3874054229528486)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3873916805528485)
,p_button_name=>'Zuordnen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Zuordnen'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3875634375528502)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3873916805528485)
,p_button_name=>'Zuord_erl'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Zuord erl'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4001032072759507)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3873916805528485)
,p_button_name=>'Zuord_rem'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Zuord rem'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8780994615211938)
,p_button_sequence=>10
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8781273187211938)
,p_button_sequence=>30
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8781174473211938)
,p_button_sequence=>20
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8782601488211939)
,p_branch_action=>'f?p=&APP_ID.:172:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8781273187211938)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8781915171211938)
,p_branch_action=>'f?p=&APP_ID.:170:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8781174473211938)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3874443573528490)
,p_name=>'P171_SEL_VALUE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3873916805528485)
,p_prompt=>'Sel value'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3874808048528494)
,p_name=>'P171_SEL_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3873916805528485)
,p_prompt=>'Sel id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3875491873528501)
,p_name=>'P171_SEL_VORGANG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3873916805528485)
,p_prompt=>'Sel vorgang'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8780699835211938)
,p_name=>'P171_ITEM1'
,p_item_sequence=>10
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3874065458528487)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'  ',
'    select count(*)',
'    into v_cnt',
'    from "KTO_Paypal"',
'    where id =:P171_SEL_ID;',
'    ',
'    select fk_main_key',
'    into v_fk_main_key',
'    from "KTO_Paypal"',
'    where id = :P171_SEL_ID;',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f02.count loop',
'           if apex_application.g_f02(j) is not null then',
'           ',
'             insert into t_rel_kont_buch_kont_buch ',
'               (',
'                   FK_KONTO_BUCH1,',
'                   FK_KONTO_BUCH2,',
'                   created_at',
'               )',
'             select v_fk_main_key,',
'                   --apex_application.g_f01(i),',
'                    apex_application.g_f02(j),',
'                    sysdate',
'             from dual;',
'             commit;',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f03.count loop',
'        if apex_application.g_f03(k) is not null then',
'        ',
'            insert into t_rel_kont_buch_kont_buch ',
'               (',
'                     FK_KONTO_BUCH1,',
'                     FK_KONTO_BUCH2,',
'                     created_at',
'               ',
'               )',
'             select v_fk_main_key,',
'             --apex_application.g_f01(i),',
'                    apex_application.g_f03(k),',
'                    sysdate',
'             from dual;',
'             commit;',
'           ',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'     --end if;',
'',
'',
'--  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3874054229528486)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4001111022759508)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuordnen_rem'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_cnt number;',
'  v_FK_main_key number;',
'begin',
'',
'  --Paypal',
'  ',
'    select count(*)',
'    into v_cnt',
'    from "KTO_Paypal"',
'    where id =:P171_SEL_ID;',
'    ',
'    select fk_main_key',
'    into v_fk_main_key',
'    from "KTO_Paypal"',
'    where id = :P171_SEL_ID;',
'  ',
'    -- for i in 1..apex_application.g_f01.count loop',
'    --  if apex_application.g_f01(i) is not null then',
'         for j in 1..apex_application.g_f02.count loop',
'           if apex_application.g_f02(j) is not null then',
'           ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 = v_fk_main_key and FK_KONTO_BUCH2 = apex_application.g_f02(j)',
'              ;',
'             commit;',
'          end if;',
'         ',
'         end loop;',
'      ',
'',
'      ',
'      for k in 1..apex_application.g_f03.count loop',
'        if apex_application.g_f03(k) is not null then',
'        ',
'            delete from t_rel_kont_buch_kont_buch ',
'               where ',
'                   FK_KONTO_BUCH1 = v_fk_main_key and FK_KONTO_BUCH2 = apex_application.g_f03(k)',
'              ;',
'             commit;',
'           ',
'        ',
'        end if;',
'      ',
'      end loop;',
'     ',
'     --end if;',
'',
'',
'--  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4001032072759507)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3875841539528504)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Zuord_erl'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update "KTO_Paypal" set fk_zuord_erl = 1 where fk_vorgang = :P171_SEL_Vorgang;',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3875634375528502)
);
wwv_flow_api.component_end;
end;
/
