prompt --application/pages/page_00320
begin
--   Manifest
--     PAGE: 00320
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>320
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Girokonto'
,p_alias=>'GIROKONTO1'
,p_step_title=>'Girokonto'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011160016'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11327917424207520)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gir.ID,',
'       gir."Buchungstag",',
'       gir."Wertstellung",',
'       gir."Umsatzart",',
'       gir."Buchungstext",',
'       gir."Betrag",',
'       gir.Waehrung,',
'       gir."Auftraggeberkonto",',
'       gir."Bankleitzahl Auftraggeberkonto",',
'       gir.IBAN_Auftraggeberkonto,',
'       gir.Kategorie,',
'       gir.F12,',
'       gir.F13,',
'       gir."alt_ID",',
'       gir.FK_bas_kat_Kategorie,',
'       gir.FK_std_verw_Verwendungszweck,',
'       gir.FK_std_kto_Kontotyp,',
'       gir."Bemerkungen",',
'       gir.FK_MAIN_KEY,',
'       gir.FK_bas_kal_BUCHUNGSTAG,',
'       gir.FK_bas_kal_WERTSTELLUNG,',
'       gir.BUCHUNGSTEXT,',
'       gir.FK_kto_bankKONTO,',
'       gir.KONTOSTAND,',
'       gir.WIEDERHOLUNG,',
'       gir.NaeCHSTE_ZAHLUNG,',
'       gir.FK_BUCHUNG_STEUER,',
'       gir.FK_kto_VORGANG,',
'       gir.FK_loc_LOCATION,',
'       gir.EMPFaeNGER,',
'       gir.SALDO,',
'       gir.KONTONUMMER,',
'       gir.AUFTRAGGEBER,',
'       zus.Kategorie zus_kategorie,',
'       zus.Verwendungszweck,',
'       zus.bucht_jahr',
'  from t_KTO_GIROKONTO gir',
'   left join v_kto_konten_zus zus on zus.fk_main_key = gir.fk_main_key'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_comment=>'report'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11328377654207520)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:321:&SESSION.::&DEBUG.:RP:P321_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>12768696929599060
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11328429549207524)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11328815290207525)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11329254182207525)
,p_db_column_name=>'Wertstellung'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11329598668207525)
,p_db_column_name=>'Umsatzart'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11329983944207525)
,p_db_column_name=>'Buchungstext'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11330445903207527)
,p_db_column_name=>'Betrag'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11331229237207527)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11331644978207527)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11332843892207527)
,p_db_column_name=>'F12'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'F12'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11333233007207528)
,p_db_column_name=>'F13'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'F13'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11333627680207528)
,p_db_column_name=>'alt_ID'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Alt Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11335242089207528)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11335678178207528)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11336836780207530)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11337649283207530)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11338033465207530)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11338823443207530)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11340416347207531)
,p_db_column_name=>'SALDO'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11340793381207531)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11341243212207531)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11576783381419162)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11576886787419163)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>53
,p_column_identifier=>'AI'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11717073363412475)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>63
,p_column_identifier=>'AJ'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52255868690477176)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>73
,p_column_identifier=>'AK'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52255938203477177)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>83
,p_column_identifier=>'AL'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52255990116477178)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>93
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256145242477179)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>103
,p_column_identifier=>'AN'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256189972477180)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>113
,p_column_identifier=>'AO'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256367874477181)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>123
,p_column_identifier=>'AP'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256433900477182)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>133
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256488873477183)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>143
,p_column_identifier=>'AR'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256660822477184)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>153
,p_column_identifier=>'AS'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256767413477185)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>163
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256875072477186)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>173
,p_column_identifier=>'AU'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52256886686477187)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>183
,p_column_identifier=>'AV'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52257048911477188)
,p_db_column_name=>'ZUS_KATEGORIE'
,p_display_order=>193
,p_column_identifier=>'AW'
,p_column_label=>'Zus Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11342880442209027)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'127832'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:Buchungstag:Wertstellung:Umsatzart:Buchungstext:Betrag:Auftraggeberkonto:Bankleitzahl Auftraggeberkonto:F12:F13:alt_ID:Bemerkungen:FK_MAIN_KEY:BUCHUNGSTEXT:KONTOSTAND:WIEDERHOLUNG:FK_BUCHUNG_STEUER:SALDO:KONTONUMMER:AUFTRAGGEBER:KATEGORIE:VERWENDU'
||'NGSZWECK:BUCHT_JAHR:WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KTO_BANKKONTO:NAECHSTE_ZAHLUNG:FK_KTO_VORGANG:FK_LOC_LOCATION:EMPFAENGER:ZUS_K'
||'ATEGORIE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11342361663207544)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11327917424207520)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:321:&SESSION.::&DEBUG.:321'
);
wwv_flow_api.component_end;
end;
/
