prompt --application/shared_components/navigation/lists/list_inv_inventare
begin
--   Manifest
--     LIST: LIST - INV - Inventare
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(8512421858239614)
,p_name=>'LIST - INV - Inventare'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8513458952239615)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'1 - Inventare'
,p_list_item_link_target=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8516964172239618)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'2 - Subkomponenten'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'133,134'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8521178323239619)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Anlagenbuchhaltung'
,p_list_item_link_target=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
