prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Company_neu'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42861002794232885)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210214082911'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(21206663205831030)
,p_plug_name=>'Dokumente'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select doc.document_type,ablaufdatum, case when substr(ablaufdatum, 7,4) = substr(sysdate, 7,4) then 1 else 0 end this_year',
'',
'from t_doc_document doc ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(21206739918831031)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::P39_PK_INV_INVENTAR:#PK_INV_INVENTAR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>21206739918831031
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21207989999831043)
,p_db_column_name=>'THIS_YEAR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'This Year'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21871476567075223)
,p_db_column_name=>'DOCUMENT_TYPE'
,p_display_order=>130
,p_column_identifier=>'AP'
,p_column_label=>'Document Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21871564973075224)
,p_db_column_name=>'ABLAUFDATUM'
,p_display_order=>140
,p_column_identifier=>'AQ'
,p_column_label=>'Ablaufdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(21900664957104131)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'219007'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENT_TYPE:ABLAUFDATUM:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21901985378117169)
,p_report_id=>wwv_flow_api.id(21900664957104131)
,p_name=>'This Year'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'THIS_YEAR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("THIS_YEAR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFF5CE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26071419590554938)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13416660472242847)
,p_plug_name=>'offene Belege'
,p_parent_plug_id=>wwv_flow_api.id(26071419590554938)
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v_inp.*',
'from v_inp_belege_all v_inp',
'where FK_STD_INP_ZAHLUNGSSTATUS = 1',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13416750218242848)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP,:P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13416750218242848
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14177865573935502)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14177950130935503)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14178074871935504)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14178479748935508)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14178772450935511)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14179028388935514)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14179662149935520)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180764625935531)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>230
,p_column_identifier=>'AG'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180823654935532)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>240
,p_column_identifier=>'AH'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14180910009935533)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>250
,p_column_identifier=>'AI'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181075039935534)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>260
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181164143935535)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>270
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181203122935536)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>280
,p_column_identifier=>'AL'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181392604935537)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>290
,p_column_identifier=>'AM'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181409493935538)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>300
,p_column_identifier=>'AN'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181514033935539)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>310
,p_column_identifier=>'AO'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181634021935540)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>320
,p_column_identifier=>'AP'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181747863935541)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>330
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181876127935542)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>340
,p_column_identifier=>'AR'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14181982874935543)
,p_db_column_name=>'VON'
,p_display_order=>350
,p_column_identifier=>'AS'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182089566935544)
,p_db_column_name=>'BIS'
,p_display_order=>360
,p_column_identifier=>'AT'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182181399935545)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>370
,p_column_identifier=>'AU'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182221713935546)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>380
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182394384935547)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>390
,p_column_identifier=>'AW'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182423436935548)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>400
,p_column_identifier=>'AX'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182541967935549)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>410
,p_column_identifier=>'AY'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14182629910935550)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>420
,p_column_identifier=>'AZ'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192727263940601)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>430
,p_column_identifier=>'BA'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192833171940602)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>440
,p_column_identifier=>'BB'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14192927536940603)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>450
,p_column_identifier=>'BC'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193038920940604)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>460
,p_column_identifier=>'BD'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193162125940605)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>470
,p_column_identifier=>'BE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193209344940606)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>480
,p_column_identifier=>'BF'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193340759940607)
,p_db_column_name=>'BELEG'
,p_display_order=>490
,p_column_identifier=>'BG'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193443942940608)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>500
,p_column_identifier=>'BH'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193579668940609)
,p_db_column_name=>'LITER'
,p_display_order=>510
,p_column_identifier=>'BI'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193670873940610)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>520
,p_column_identifier=>'BJ'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193786126940611)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>530
,p_column_identifier=>'BK'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193805901940612)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>540
,p_column_identifier=>'BL'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14193954726940613)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>550
,p_column_identifier=>'BM'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194024562940614)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>560
,p_column_identifier=>'BN'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194180911940615)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>570
,p_column_identifier=>'BO'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194231663940616)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>580
,p_column_identifier=>'BP'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194350538940617)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>590
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194456854940618)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>600
,p_column_identifier=>'BR'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194528700940619)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>610
,p_column_identifier=>'BS'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194680268940620)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>620
,p_column_identifier=>'BT'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194754384940621)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>630
,p_column_identifier=>'BU'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194866652940622)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>640
,p_column_identifier=>'BV'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14194964270940623)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>650
,p_column_identifier=>'BW'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195035921940624)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>660
,p_column_identifier=>'BX'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195174046940625)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>670
,p_column_identifier=>'BY'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195286997940626)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>680
,p_column_identifier=>'BZ'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195344925940627)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>690
,p_column_identifier=>'CA'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195471667940628)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>700
,p_column_identifier=>'CB'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195524688940629)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>710
,p_column_identifier=>'CC'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195615541940630)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>720
,p_column_identifier=>'CD'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195792114940631)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>730
,p_column_identifier=>'CE'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195849475940632)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>740
,p_column_identifier=>'CF'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14195955884940633)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>750
,p_column_identifier=>'CG'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196052147940634)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>760
,p_column_identifier=>'CH'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196194884940635)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>770
,p_column_identifier=>'CI'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196296018940636)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>780
,p_column_identifier=>'CJ'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196315669940637)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>790
,p_column_identifier=>'CK'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196448823940638)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>800
,p_column_identifier=>'CL'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196587330940639)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>810
,p_column_identifier=>'CM'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196615826940640)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>820
,p_column_identifier=>'CN'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196768210940641)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>830
,p_column_identifier=>'CO'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196827265940642)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>840
,p_column_identifier=>'CP'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14196968673940643)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>850
,p_column_identifier=>'CQ'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197028568940644)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>860
,p_column_identifier=>'CR'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197176904940645)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>870
,p_column_identifier=>'CS'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197287480940646)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>880
,p_column_identifier=>'CT'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197363778940647)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>890
,p_column_identifier=>'CU'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197407180940648)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>900
,p_column_identifier=>'CV'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197597936940649)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>910
,p_column_identifier=>'CW'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197679703940650)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>920
,p_column_identifier=>'CX'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197798758940601)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>930
,p_column_identifier=>'CY'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197853259940602)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>940
,p_column_identifier=>'CZ'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14197986368940603)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>950
,p_column_identifier=>'DA'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198024420940604)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>960
,p_column_identifier=>'DB'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198122961940605)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>970
,p_column_identifier=>'DC'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198249247940606)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>980
,p_column_identifier=>'DD'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198314101940607)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>990
,p_column_identifier=>'DE'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198478246940608)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>1000
,p_column_identifier=>'DF'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198530490940609)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>1010
,p_column_identifier=>'DG'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198608713940610)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>1020
,p_column_identifier=>'DH'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198767760940611)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>1030
,p_column_identifier=>'DI'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198846301940612)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>1040
,p_column_identifier=>'DJ'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14198936258940613)
,p_db_column_name=>'ZAHL_ART_VAL'
,p_display_order=>1050
,p_column_identifier=>'DK'
,p_column_label=>'Zahl Art Val'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199065875940614)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>1060
,p_column_identifier=>'DL'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199160103940615)
,p_db_column_name=>'LA_WDH_VALUE'
,p_display_order=>1070
,p_column_identifier=>'DM'
,p_column_label=>'La Wdh Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199286408940616)
,p_db_column_name=>'LA_WDH_NAME'
,p_display_order=>1080
,p_column_identifier=>'DN'
,p_column_label=>'La Wdh Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199360723940617)
,p_db_column_name=>'STA_VALUE'
,p_display_order=>1090
,p_column_identifier=>'DO'
,p_column_label=>'Sta Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199401426940618)
,p_db_column_name=>'STA_NAME'
,p_display_order=>1100
,p_column_identifier=>'DP'
,p_column_label=>'Sta Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199568919940619)
,p_db_column_name=>'BEL_EX_VALUE'
,p_display_order=>1110
,p_column_identifier=>'DQ'
,p_column_label=>'Bel Ex Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199631139940620)
,p_db_column_name=>'BEL_EX_NAME'
,p_display_order=>1120
,p_column_identifier=>'DR'
,p_column_label=>'Bel Ex Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199788628940621)
,p_db_column_name=>'PROJ_PK_PROJ_PROJEKT'
,p_display_order=>1130
,p_column_identifier=>'DS'
,p_column_label=>'Proj Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199832799940622)
,p_db_column_name=>'PROJ_FK_KON_AUFTRAGGEBER'
,p_display_order=>1140
,p_column_identifier=>'DT'
,p_column_label=>'Proj Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14199909009940623)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_1'
,p_display_order=>1150
,p_column_identifier=>'DU'
,p_column_label=>'Proj Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200082360940624)
,p_db_column_name=>'PROJ_FK_KON_PROJEKTPARTNER_2'
,p_display_order=>1160
,p_column_identifier=>'DV'
,p_column_label=>'Proj Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200184646940625)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>1170
,p_column_identifier=>'DW'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200216985940626)
,p_db_column_name=>'PROJ_VON'
,p_display_order=>1180
,p_column_identifier=>'DX'
,p_column_label=>'Proj Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200379942940627)
,p_db_column_name=>'PROJ_BIS'
,p_display_order=>1190
,p_column_identifier=>'DY'
,p_column_label=>'Proj Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200464948940628)
,p_db_column_name=>'PROJ_AKTUELLER_STUNDENSATZ'
,p_display_order=>1200
,p_column_identifier=>'DZ'
,p_column_label=>'Proj Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200541209940629)
,p_db_column_name=>'PROJ_PSP_ELEMENT'
,p_display_order=>1210
,p_column_identifier=>'EA'
,p_column_label=>'Proj Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200619379940630)
,p_db_column_name=>'PROJ_CREATED_BY'
,p_display_order=>1220
,p_column_identifier=>'EB'
,p_column_label=>'Proj Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200784614940631)
,p_db_column_name=>'PROJ_CREATED_AT'
,p_display_order=>1230
,p_column_identifier=>'EC'
,p_column_label=>'Proj Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200860719940632)
,p_db_column_name=>'PROJ_MODIFIED_BY'
,p_display_order=>1240
,p_column_identifier=>'ED'
,p_column_label=>'Proj Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14200933067940633)
,p_db_column_name=>'PROJ_MODIFIED_AT'
,p_display_order=>1250
,p_column_identifier=>'EE'
,p_column_label=>'Proj Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201006560940634)
,p_db_column_name=>'PROJ_RECHNUNG_GESTELLT'
,p_display_order=>1260
,p_column_identifier=>'EF'
,p_column_label=>'Proj Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201154557940635)
,p_db_column_name=>'PROJ_ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>1270
,p_column_identifier=>'EG'
,p_column_label=>'Proj Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201254937940636)
,p_db_column_name=>'PROJ_BELEGE_ZUGEORDNET'
,p_display_order=>1280
,p_column_identifier=>'EH'
,p_column_label=>'Proj Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201313045940637)
,p_db_column_name=>'PROJ_KM_GERECHNET'
,p_display_order=>1290
,p_column_identifier=>'EI'
,p_column_label=>'Proj Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201463165940638)
,p_db_column_name=>'PROJ_PROJEKT_ABGESCHLOSSEN'
,p_display_order=>1300
,p_column_identifier=>'EJ'
,p_column_label=>'Proj Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201555570940639)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>1310
,p_column_identifier=>'EK'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201643559940640)
,p_db_column_name=>'PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1320
,p_column_identifier=>'EL'
,p_column_label=>'Proj Auft Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201731902940641)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNER'
,p_display_order=>1330
,p_column_identifier=>'EM'
,p_column_label=>'Proj Auft Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201823217940642)
,p_db_column_name=>'PROJ_AUFT_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1340
,p_column_identifier=>'EN'
,p_column_label=>'Proj Auft Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14201978361940643)
,p_db_column_name=>'PROJ_AUFT_PK_ADR_ADRESSE'
,p_display_order=>1350
,p_column_identifier=>'EO'
,p_column_label=>'Proj Auft Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202007642940644)
,p_db_column_name=>'PROJ_AUFT_STRASSE'
,p_display_order=>1360
,p_column_identifier=>'EP'
,p_column_label=>'Proj Auft Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202133823940645)
,p_db_column_name=>'PROJ_AUFT_HSNR'
,p_display_order=>1370
,p_column_identifier=>'EQ'
,p_column_label=>'Proj Auft Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202215655940646)
,p_db_column_name=>'PROJ_AUFT_PLZ'
,p_display_order=>1380
,p_column_identifier=>'ER'
,p_column_label=>'Proj Auft Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202308919940647)
,p_db_column_name=>'PROJ_AUFT_ORT'
,p_display_order=>1390
,p_column_identifier=>'ES'
,p_column_label=>'Proj Auft Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202458299940648)
,p_db_column_name=>'PROJ_AUFT_LAND'
,p_display_order=>1400
,p_column_identifier=>'ET'
,p_column_label=>'Proj Auft Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202524429940649)
,p_db_column_name=>'PROJ_AUFT_BESCHREIBUNG'
,p_display_order=>1410
,p_column_identifier=>'EU'
,p_column_label=>'Proj Auft Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202652315940650)
,p_db_column_name=>'PROJ_AUFT_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1420
,p_column_identifier=>'EV'
,p_column_label=>'Proj Auft Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202769731940601)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNERTYP'
,p_display_order=>1430
,p_column_identifier=>'EW'
,p_column_label=>'Proj Auft Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202896642940602)
,p_db_column_name=>'PROJ_PP1_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1440
,p_column_identifier=>'EX'
,p_column_label=>'Proj Pp1 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14202921961940603)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNER'
,p_display_order=>1450
,p_column_identifier=>'EY'
,p_column_label=>'Proj Pp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203030166940604)
,p_db_column_name=>'PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1460
,p_column_identifier=>'EZ'
,p_column_label=>'Proj Pp1 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203109623940605)
,p_db_column_name=>'PROJ_PP1_PK_ADR_ADRESSE'
,p_display_order=>1470
,p_column_identifier=>'FA'
,p_column_label=>'Proj Pp1 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203232419940606)
,p_db_column_name=>'PROJ_PP1_STRASSE'
,p_display_order=>1480
,p_column_identifier=>'FB'
,p_column_label=>'Proj Pp1 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203368110940607)
,p_db_column_name=>'PROJ_PP1_HSNR'
,p_display_order=>1490
,p_column_identifier=>'FC'
,p_column_label=>'Proj Pp1 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203417302940608)
,p_db_column_name=>'PROJ_PP1_PLZ'
,p_display_order=>1500
,p_column_identifier=>'FD'
,p_column_label=>'Proj Pp1 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203581736940609)
,p_db_column_name=>'PROJ_PP1_ORT'
,p_display_order=>1510
,p_column_identifier=>'FE'
,p_column_label=>'Proj Pp1 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203663333940610)
,p_db_column_name=>'PROJ_PP1_LAND'
,p_display_order=>1520
,p_column_identifier=>'FF'
,p_column_label=>'Proj Pp1 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203704894940611)
,p_db_column_name=>'PROJ_PP1_BESCHREIBUNG'
,p_display_order=>1530
,p_column_identifier=>'FG'
,p_column_label=>'Proj Pp1 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203848186940612)
,p_db_column_name=>'PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1540
,p_column_identifier=>'FH'
,p_column_label=>'Proj Pp1 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14203974174940613)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNERTYP'
,p_display_order=>1550
,p_column_identifier=>'FI'
,p_column_label=>'Proj Pp1 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204040284940614)
,p_db_column_name=>'PROJ_PP2_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1560
,p_column_identifier=>'FJ'
,p_column_label=>'Proj Pp2 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204124848940615)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNER'
,p_display_order=>1570
,p_column_identifier=>'FK'
,p_column_label=>'Proj Pp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204230020940616)
,p_db_column_name=>'PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP'
,p_display_order=>1580
,p_column_identifier=>'FL'
,p_column_label=>'Proj Pp2 Fk Bas Kon Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204345216940617)
,p_db_column_name=>'PROJ_PP2_PK_ADR_ADRESSE'
,p_display_order=>1590
,p_column_identifier=>'FM'
,p_column_label=>'Proj Pp2 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204495934940618)
,p_db_column_name=>'PROJ_PP2_STRASSE'
,p_display_order=>1600
,p_column_identifier=>'FN'
,p_column_label=>'Proj Pp2 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204513253940619)
,p_db_column_name=>'PROJ_PP2_HSNR'
,p_display_order=>1610
,p_column_identifier=>'FO'
,p_column_label=>'Proj Pp2 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204615760940620)
,p_db_column_name=>'PROJ_PP2_PLZ'
,p_display_order=>1620
,p_column_identifier=>'FP'
,p_column_label=>'Proj Pp2 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204701527940621)
,p_db_column_name=>'PROJ_PP2_ORT'
,p_display_order=>1630
,p_column_identifier=>'FQ'
,p_column_label=>'Proj Pp2 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204875131940622)
,p_db_column_name=>'PROJ_PP2_LAND'
,p_display_order=>1640
,p_column_identifier=>'FR'
,p_column_label=>'Proj Pp2 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14204959722940623)
,p_db_column_name=>'PROJ_PP2_BESCHREIBUNG'
,p_display_order=>1650
,p_column_identifier=>'FS'
,p_column_label=>'Proj Pp2 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205040205940624)
,p_db_column_name=>'PROJ_PP2_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
,p_display_order=>1660
,p_column_identifier=>'FT'
,p_column_label=>'Proj Pp2 Pk Rel Kon Geschaeftspartner Kontakt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205159578940625)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNERTYP'
,p_display_order=>1670
,p_column_identifier=>'FU'
,p_column_label=>'Proj Pp2 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205207681940626)
,p_db_column_name=>'PK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>1680
,p_column_identifier=>'FV'
,p_column_label=>'Pk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205381475940627)
,p_db_column_name=>'PK_BAS_KAT_KATEGORIE'
,p_display_order=>1690
,p_column_identifier=>'FW'
,p_column_label=>'Pk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205471783940628)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1700
,p_column_identifier=>'FX'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205580298940629)
,p_db_column_name=>'KTOKAT_NEU_ALT'
,p_display_order=>1710
,p_column_identifier=>'FY'
,p_column_label=>'Ktokat Neu Alt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205679902940630)
,p_db_column_name=>'KTOKAT_FK_BAS_KAT_OBERKATEGORIE'
,p_display_order=>1720
,p_column_identifier=>'FZ'
,p_column_label=>'Ktokat Fk Bas Kat Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205762778940631)
,p_db_column_name=>'KTOKAT_VALID'
,p_display_order=>1730
,p_column_identifier=>'GA'
,p_column_label=>'Ktokat Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205815140940632)
,p_db_column_name=>'ARB_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1740
,p_column_identifier=>'GB'
,p_column_label=>'Arb Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14205905208940633)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>1750
,p_column_identifier=>'GC'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206006557940634)
,p_db_column_name=>'ARB_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1760
,p_column_identifier=>'GD'
,p_column_label=>'Arb Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206136543940635)
,p_db_column_name=>'ARB_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1770
,p_column_identifier=>'GE'
,p_column_label=>'Arb Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206272494940636)
,p_db_column_name=>'ARB_FK_STD_KAL_FEIERTAG'
,p_display_order=>1780
,p_column_identifier=>'GF'
,p_column_label=>'Arb Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206356348940637)
,p_db_column_name=>'ARB_FEIERTAG'
,p_display_order=>1790
,p_column_identifier=>'GG'
,p_column_label=>'Arb Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206486782940638)
,p_db_column_name=>'ARB_VON_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1800
,p_column_identifier=>'GH'
,p_column_label=>'Arb Von Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206504571940639)
,p_db_column_name=>'ARB_VON_DATUM'
,p_display_order=>1810
,p_column_identifier=>'GI'
,p_column_label=>'Arb Von Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206619330940640)
,p_db_column_name=>'ARB_VON_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1820
,p_column_identifier=>'GJ'
,p_column_label=>'Arb Von Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206701971940641)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1830
,p_column_identifier=>'GK'
,p_column_label=>'Arb Von Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206846475940642)
,p_db_column_name=>'ARB_VON_FK_STD_KAL_FEIERTAG'
,p_display_order=>1840
,p_column_identifier=>'GL'
,p_column_label=>'Arb Von Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14206983465940643)
,p_db_column_name=>'ARB_VON_FEIERTAG'
,p_display_order=>1850
,p_column_identifier=>'GM'
,p_column_label=>'Arb Von Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207017531940644)
,p_db_column_name=>'ARB_VON_TAG'
,p_display_order=>1860
,p_column_identifier=>'GN'
,p_column_label=>'Arb Von Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207142306940645)
,p_db_column_name=>'ARB_VON_MONAT'
,p_display_order=>1870
,p_column_identifier=>'GO'
,p_column_label=>'Arb Von Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207245088940646)
,p_db_column_name=>'ARB_VON_JAHR'
,p_display_order=>1880
,p_column_identifier=>'GP'
,p_column_label=>'Arb Von Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207368912940647)
,p_db_column_name=>'ARB_BIS_PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>1890
,p_column_identifier=>'GQ'
,p_column_label=>'Arb Bis Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207473055940648)
,p_db_column_name=>'ARB_BIS_DATUM'
,p_display_order=>1900
,p_column_identifier=>'GR'
,p_column_label=>'Arb Bis Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207550909940649)
,p_db_column_name=>'ARB_BIS_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1910
,p_column_identifier=>'GS'
,p_column_label=>'Arb Bis Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207656332940650)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_WOCHENENDE'
,p_display_order=>1920
,p_column_identifier=>'GT'
,p_column_label=>'Arb Bis Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207732603940701)
,p_db_column_name=>'ARB_BIS_FK_STD_KAL_FEIERTAG'
,p_display_order=>1930
,p_column_identifier=>'GU'
,p_column_label=>'Arb Bis Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207809470940702)
,p_db_column_name=>'ARB_BIS_FEIERTAG'
,p_display_order=>1940
,p_column_identifier=>'GV'
,p_column_label=>'Arb Bis Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14207902417940703)
,p_db_column_name=>'ARB_BIS_TAG'
,p_display_order=>1950
,p_column_identifier=>'GW'
,p_column_label=>'Arb Bis Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208031998940704)
,p_db_column_name=>'ARB_BIS_MONAT'
,p_display_order=>1960
,p_column_identifier=>'GX'
,p_column_label=>'Arb Bis Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208163406940705)
,p_db_column_name=>'ARB_BIS_JAHR'
,p_display_order=>1970
,p_column_identifier=>'GY'
,p_column_label=>'Arb Bis Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208220056940706)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>1980
,p_column_identifier=>'GZ'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208318600940707)
,p_db_column_name=>'LAND'
,p_display_order=>1990
,p_column_identifier=>'HA'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208425643940708)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>2000
,p_column_identifier=>'HB'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208551300940709)
,p_db_column_name=>'ORT'
,p_display_order=>2010
,p_column_identifier=>'HC'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208655541940710)
,p_db_column_name=>'CI_PK_ADR_LAND'
,p_display_order=>2020
,p_column_identifier=>'HD'
,p_column_label=>'Ci Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208775242940711)
,p_db_column_name=>'CI_LAND'
,p_display_order=>2030
,p_column_identifier=>'HE'
,p_column_label=>'Ci Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208804107940712)
,p_db_column_name=>'STEU_STEUERSATZ'
,p_display_order=>2040
,p_column_identifier=>'HF'
,p_column_label=>'Steu Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14208945037940713)
,p_db_column_name=>'STEU_LAND'
,p_display_order=>2050
,p_column_identifier=>'HG'
,p_column_label=>'Steu Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209045762940714)
,p_db_column_name=>'STEU_PK_ADR_LAND'
,p_display_order=>2060
,p_column_identifier=>'HH'
,p_column_label=>'Steu Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209114211940715)
,p_db_column_name=>'STEU_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>2070
,p_column_identifier=>'HI'
,p_column_label=>'Steu Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209233805940716)
,p_db_column_name=>'STEU_ZUS_ST'
,p_display_order=>2080
,p_column_identifier=>'HJ'
,p_column_label=>'Steu Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209365112940717)
,p_db_column_name=>'STEU_FRMD_STEUERSATZ'
,p_display_order=>2090
,p_column_identifier=>'HK'
,p_column_label=>'Steu Frmd Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209471486940718)
,p_db_column_name=>'STEU_FRMD_LAND'
,p_display_order=>2100
,p_column_identifier=>'HL'
,p_column_label=>'Steu Frmd Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209507862940719)
,p_db_column_name=>'STEU_FRMD_PK_ADR_LAND'
,p_display_order=>2110
,p_column_identifier=>'HM'
,p_column_label=>'Steu Frmd Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209666489940720)
,p_db_column_name=>'STEU_FRMD_PK_BAS_STEU_STEUER_SATZ'
,p_display_order=>2120
,p_column_identifier=>'HN'
,p_column_label=>'Steu Frmd Pk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209700650940721)
,p_db_column_name=>'STEU_FRMD_ZUS_ST'
,p_display_order=>2130
,p_column_identifier=>'HO'
,p_column_label=>'Steu Frmd Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209813397940722)
,p_db_column_name=>'PK_BAS_MON_WAEHRUNG'
,p_display_order=>2140
,p_column_identifier=>'HP'
,p_column_label=>'Pk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14209959861940723)
,p_db_column_name=>'WAEHRUNG_LANG'
,p_display_order=>2150
,p_column_identifier=>'HQ'
,p_column_label=>'Waehrung Lang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210007474940724)
,p_db_column_name=>'COMM'
,p_display_order=>2160
,p_column_identifier=>'HR'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210196016940725)
,p_db_column_name=>'ABL_ORD_J_PAGE_NUMBER'
,p_display_order=>2170
,p_column_identifier=>'HS'
,p_column_label=>'Abl Ord J Page Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210281090940726)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>2180
,p_column_identifier=>'HT'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210365580940727)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>2190
,p_column_identifier=>'HU'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210477072940728)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>2200
,p_column_identifier=>'HV'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210564966940729)
,p_db_column_name=>'ABL_ORD_ORDNER_NAME'
,p_display_order=>2210
,p_column_identifier=>'HW'
,p_column_label=>'Abl Ord Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210670545940730)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER'
,p_display_order=>2220
,p_column_identifier=>'HX'
,p_column_label=>'Abl Ord Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210754286940731)
,p_db_column_name=>'VBEL_ART'
,p_display_order=>2230
,p_column_identifier=>'HY'
,p_column_label=>'Vbel Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210818656940732)
,p_db_column_name=>'VBEL_FK_IMP_BA_BEL'
,p_display_order=>2240
,p_column_identifier=>'HZ'
,p_column_label=>'Vbel Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14210923903940733)
,p_db_column_name=>'VBEL_PK_IMP_BA_ALLG_BEL'
,p_display_order=>2250
,p_column_identifier=>'IA'
,p_column_label=>'Vbel Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211044255940734)
,p_db_column_name=>'VBEL_BEZEICHNUNG'
,p_display_order=>2260
,p_column_identifier=>'IB'
,p_column_label=>'Vbel Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211165519940735)
,p_db_column_name=>'VBEL_KENNZEICHEN'
,p_display_order=>2270
,p_column_identifier=>'IC'
,p_column_label=>'Vbel Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211213019940736)
,p_db_column_name=>'VBEL_DATUM'
,p_display_order=>2280
,p_column_identifier=>'ID'
,p_column_label=>'Vbel Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211381364940737)
,p_db_column_name=>'VBEL_DATUM_VERGEHEN'
,p_display_order=>2290
,p_column_identifier=>'IE'
,p_column_label=>'Vbel Datum Vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211484686940738)
,p_db_column_name=>'VBEL_FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>2300
,p_column_identifier=>'IF'
,p_column_label=>'Vbel Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211553035940739)
,p_db_column_name=>'VBEL_FK_KTO_BUCHUNG'
,p_display_order=>2310
,p_column_identifier=>'IG'
,p_column_label=>'Vbel Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211664418940740)
,p_db_column_name=>'VBEL_BETRAG'
,p_display_order=>2320
,p_column_identifier=>'IH'
,p_column_label=>'Vbel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211782919940741)
,p_db_column_name=>'VBEL_WAEHRUNG'
,p_display_order=>2330
,p_column_identifier=>'II'
,p_column_label=>'Vbel Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211896909940742)
,p_db_column_name=>'VBEL_STEUERSATZ'
,p_display_order=>2340
,p_column_identifier=>'IJ'
,p_column_label=>'Vbel Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14211926253940743)
,p_db_column_name=>'VBEL_MWST_BETRAG'
,p_display_order=>2350
,p_column_identifier=>'IK'
,p_column_label=>'Vbel Mwst Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212013269940744)
,p_db_column_name=>'VBEL_NETTO'
,p_display_order=>2360
,p_column_identifier=>'IL'
,p_column_label=>'Vbel Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212149175940745)
,p_db_column_name=>'VBEL_ZAHLUNGSART'
,p_display_order=>2370
,p_column_identifier=>'IM'
,p_column_label=>'Vbel Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212245073940746)
,p_db_column_name=>'VBEL_BILD'
,p_display_order=>2380
,p_column_identifier=>'IO'
,p_column_label=>'Vbel Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212325181940747)
,p_db_column_name=>'VBEL_BILD1'
,p_display_order=>2390
,p_column_identifier=>'IP'
,p_column_label=>'Vbel Bild1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212473256940748)
,p_db_column_name=>'VBEL_VERWENDUNGSZWECK'
,p_display_order=>2400
,p_column_identifier=>'IQ'
,p_column_label=>'Vbel Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212578629940749)
,p_db_column_name=>'VBEL_FK_INV_INVENTAR'
,p_display_order=>2410
,p_column_identifier=>'IR'
,p_column_label=>'Vbel Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212611695940750)
,p_db_column_name=>'VBEL_FK_PROJ_PROJEKT'
,p_display_order=>2420
,p_column_identifier=>'IT'
,p_column_label=>'Vbel Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212715209940701)
,p_db_column_name=>'VBEL_WAEHRUNG_BETRAG'
,p_display_order=>2430
,p_column_identifier=>'IU'
,p_column_label=>'Vbel Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212825049940702)
,p_db_column_name=>'VBEL_FK_BAS_KAT_KATEGORIE'
,p_display_order=>2440
,p_column_identifier=>'IV'
,p_column_label=>'Vbel Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14212949455940703)
,p_db_column_name=>'VBEL_KATEGORIE'
,p_display_order=>2450
,p_column_identifier=>'IW'
,p_column_label=>'Vbel Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213056684940704)
,p_db_column_name=>'VBEL_PROJEKT'
,p_display_order=>2460
,p_column_identifier=>'IX'
,p_column_label=>'Vbel Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213164115940705)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>2470
,p_column_identifier=>'IY'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213216153940706)
,p_db_column_name=>'VBEL_FK_BEL_BELEG_ABLAGE'
,p_display_order=>2480
,p_column_identifier=>'IZ'
,p_column_label=>'Vbel Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213379972940707)
,p_db_column_name=>'IBAN'
,p_display_order=>2490
,p_column_identifier=>'JA'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213431890940708)
,p_db_column_name=>'PK_KTO_BANKKONTO'
,p_display_order=>2500
,p_column_identifier=>'JB'
,p_column_label=>'Pk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213597071940709)
,p_db_column_name=>'BANK'
,p_display_order=>2510
,p_column_identifier=>'JC'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213691133940710)
,p_db_column_name=>'PK_KTO_BANK'
,p_display_order=>2520
,p_column_identifier=>'JD'
,p_column_label=>'Pk Kto Bank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213758795940711)
,p_db_column_name=>'VLOC_PK_LOC_LOCATION'
,p_display_order=>2530
,p_column_identifier=>'JE'
,p_column_label=>'Vloc Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213882556940712)
,p_db_column_name=>'VLOC_LOCATION'
,p_display_order=>2540
,p_column_identifier=>'JF'
,p_column_label=>'Vloc Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14213963395940713)
,p_db_column_name=>'VLOC_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2550
,p_column_identifier=>'JG'
,p_column_label=>'Vloc Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214027272940714)
,p_db_column_name=>'VLOC_FK_ADR_ADRESSE'
,p_display_order=>2560
,p_column_identifier=>'JH'
,p_column_label=>'Vloc Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214196576940715)
,p_db_column_name=>'VLOC_CREATED_BY'
,p_display_order=>2570
,p_column_identifier=>'JI'
,p_column_label=>'Vloc Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214282619940716)
,p_db_column_name=>'VLOC_CREATED_AT'
,p_display_order=>2580
,p_column_identifier=>'JJ'
,p_column_label=>'Vloc Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214345146940717)
,p_db_column_name=>'VLOC_MODIFIED_BY'
,p_display_order=>2590
,p_column_identifier=>'JK'
,p_column_label=>'Vloc Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214449097940718)
,p_db_column_name=>'VLOC_MODIFIED_AT'
,p_display_order=>2600
,p_column_identifier=>'JL'
,p_column_label=>'Vloc Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214502921940719)
,p_db_column_name=>'VLOC_LOCATION_TYPE'
,p_display_order=>2610
,p_column_identifier=>'JM'
,p_column_label=>'Vloc Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214626216940720)
,p_db_column_name=>'VLOC_STRASSE'
,p_display_order=>2620
,p_column_identifier=>'JN'
,p_column_label=>'Vloc Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214713460940721)
,p_db_column_name=>'VLOC_HSNR'
,p_display_order=>2630
,p_column_identifier=>'JO'
,p_column_label=>'Vloc Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214866224940722)
,p_db_column_name=>'VLOC_BESCHREIBUNG'
,p_display_order=>2640
,p_column_identifier=>'JP'
,p_column_label=>'Vloc Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14214969277940723)
,p_db_column_name=>'VLOC_COMM'
,p_display_order=>2650
,p_column_identifier=>'JQ'
,p_column_label=>'Vloc Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215065094940724)
,p_db_column_name=>'VLOC_POSTFACH'
,p_display_order=>2660
,p_column_identifier=>'JR'
,p_column_label=>'Vloc Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215126716940725)
,p_db_column_name=>'VLOC_PLZ'
,p_display_order=>2670
,p_column_identifier=>'JS'
,p_column_label=>'Vloc Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215274106940726)
,p_db_column_name=>'VLOC_ORT'
,p_display_order=>2680
,p_column_identifier=>'JT'
,p_column_label=>'Vloc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215354294940727)
,p_db_column_name=>'VLOC_LAND'
,p_display_order=>2690
,p_column_identifier=>'JU'
,p_column_label=>'Vloc Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215460993940728)
,p_db_column_name=>'VLOC_ADR'
,p_display_order=>2700
,p_column_identifier=>'JV'
,p_column_label=>'Vloc Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215553025940729)
,p_db_column_name=>'VLOC_VERG_PK_LOC_LOCATION'
,p_display_order=>2710
,p_column_identifier=>'JW'
,p_column_label=>'Vloc Verg Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215670659940730)
,p_db_column_name=>'VLOC_VERG_LOCATION'
,p_display_order=>2720
,p_column_identifier=>'JX'
,p_column_label=>'Vloc Verg Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215797163940731)
,p_db_column_name=>'VLOC_VERG_FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>2730
,p_column_identifier=>'JY'
,p_column_label=>'Vloc Verg Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215868339940732)
,p_db_column_name=>'VLOC_VERG_FK_ADR_ADRESSE'
,p_display_order=>2740
,p_column_identifier=>'JZ'
,p_column_label=>'Vloc Verg Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14215904039940733)
,p_db_column_name=>'VLOC_VERG_CREATED_BY'
,p_display_order=>2750
,p_column_identifier=>'KA'
,p_column_label=>'Vloc Verg Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216036388940734)
,p_db_column_name=>'VLOC_VERG_CREATED_AT'
,p_display_order=>2760
,p_column_identifier=>'KB'
,p_column_label=>'Vloc Verg Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216153234940735)
,p_db_column_name=>'VLOC_VERG_MODIFIED_BY'
,p_display_order=>2770
,p_column_identifier=>'KC'
,p_column_label=>'Vloc Verg Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216230802940736)
,p_db_column_name=>'VLOC_VERG_MODIFIED_AT'
,p_display_order=>2780
,p_column_identifier=>'KD'
,p_column_label=>'Vloc Verg Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216345976940737)
,p_db_column_name=>'VLOC_VERG_LOCATION_TYPE'
,p_display_order=>2790
,p_column_identifier=>'KE'
,p_column_label=>'Vloc Verg Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216403803940738)
,p_db_column_name=>'VLOC_VERG_STRASSE'
,p_display_order=>2800
,p_column_identifier=>'KF'
,p_column_label=>'Vloc Verg Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216565668940739)
,p_db_column_name=>'VLOC_VERG_HSNR'
,p_display_order=>2810
,p_column_identifier=>'KG'
,p_column_label=>'Vloc Verg Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216686267940740)
,p_db_column_name=>'VLOC_VERG_BESCHREIBUNG'
,p_display_order=>2820
,p_column_identifier=>'KH'
,p_column_label=>'Vloc Verg Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216758751940741)
,p_db_column_name=>'VLOC_VERG_COMM'
,p_display_order=>2830
,p_column_identifier=>'KI'
,p_column_label=>'Vloc Verg Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216875084940742)
,p_db_column_name=>'VLOC_VERG_POSTFACH'
,p_display_order=>2840
,p_column_identifier=>'KJ'
,p_column_label=>'Vloc Verg Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14216946629940743)
,p_db_column_name=>'VLOC_VERG_PLZ'
,p_display_order=>2850
,p_column_identifier=>'KK'
,p_column_label=>'Vloc Verg Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217090106940744)
,p_db_column_name=>'VLOC_VERG_ORT'
,p_display_order=>2860
,p_column_identifier=>'KL'
,p_column_label=>'Vloc Verg Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217117096940745)
,p_db_column_name=>'VLOC_VERG_LAND'
,p_display_order=>2870
,p_column_identifier=>'KM'
,p_column_label=>'Vloc Verg Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217291979940746)
,p_db_column_name=>'VLOC_VERG_ADR'
,p_display_order=>2880
,p_column_identifier=>'KN'
,p_column_label=>'Vloc Verg Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217376706940747)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>2890
,p_column_identifier=>'KO'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217408354940748)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>2900
,p_column_identifier=>'KP'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217577673940749)
,p_db_column_name=>'BELEG_STATUS'
,p_display_order=>2910
,p_column_identifier=>'KQ'
,p_column_label=>'Beleg Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14217650268940750)
,p_db_column_name=>'INVENTAR'
,p_display_order=>2920
,p_column_identifier=>'KR'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14306525430943591)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'143066'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BRUTTO_BETRAG:ARB_TAG:ARB_MONAT:ARB_JAHR:WAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:VERWENDUNGSZWECK:PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUM'
||'MER:BEZEICHNUNG:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:FK_BAS_MON_WAEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:'
||'ZAHLUNGSBELEG:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_B'
||'AS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_STATUS:COMM_VERGEHE'
||'N:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZG'
||'L_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZEICHEN:VERG_TATBESTANDSNUMMER:ZAHL_ART_VAL:ZAHL_ART_NAME:LA_WDH_VALUE:LA_WDH_'
||'NAME:STA_VALUE:STA_NAME:BEL_EX_VALUE:BEL_EX_NAME:PROJ_PK_PROJ_PROJEKT:PROJ_FK_KON_AUFTRAGGEBER:PROJ_FK_KON_PROJEKTPARTNER_1:PROJ_FK_KON_PROJEKTPARTNER_2:PROJ_PROJEKT:PROJ_VON:PROJ_BIS:PROJ_AKTUELLER_STUNDENSATZ:PROJ_PSP_ELEMENT:PROJ_CREATED_BY:PROJ_C'
||'REATED_AT:PROJ_MODIFIED_BY:PROJ_MODIFIED_AT:PROJ_RECHNUNG_GESTELLT:PROJ_ZAHLUNG_ABGESCHLOSSEN:PROJ_BELEGE_ZUGEORDNET:PROJ_KM_GERECHNET:PROJ_PROJEKT_ABGESCHLOSSEN:PROJ_PROJEKT_ART:PROJ_AUFT_PK_KON_GESCHAEFTSPARTNER:PROJ_AUFT_GESCHAEFTSPARTNER:PROJ_AUF'
||'T_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_AUFT_PK_ADR_ADRESSE:PROJ_AUFT_STRASSE:PROJ_AUFT_HSNR:PROJ_AUFT_PLZ:PROJ_AUFT_ORT:PROJ_AUFT_LAND:PROJ_AUFT_BESCHREIBUNG:PROJ_AUFT_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_AUFT_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_KO'
||'N_GESCHAEFTSPARTNER:PROJ_PP1_GESCHAEFTSPARTNER:PROJ_PP1_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_ADR_ADRESSE:PROJ_PP1_STRASSE:PROJ_PP1_HSNR:PROJ_PP1_PLZ:PROJ_PP1_ORT:PROJ_PP1_LAND:PROJ_PP1_BESCHREIBUNG:PROJ_PP1_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT'
||':PROJ_PP1_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_KON_GESCHAEFTSPARTNER:PROJ_PP2_GESCHAEFTSPARTNER:PROJ_PP2_FK_BAS_KON_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_ADR_ADRESSE:PROJ_PP2_STRASSE:PROJ_PP2_HSNR:PROJ_PP2_PLZ:PROJ_PP2_ORT:PROJ_PP2_LAND:PROJ_PP2_BESCHREIBUNG:'
||'PROJ_PP2_PK_REL_KON_GESCHAEFTSPARTNER_KONTAKT:PROJ_PP2_GESCHAEFTSPARTNERTYP:PK_STD_VERW_VERWENDUNGSZWECK:PK_BAS_KAT_KATEGORIE:KTOKAT_KATEGORIE:KTOKAT_NEU_ALT:KTOKAT_FK_BAS_KAT_OBERKATEGORIE:KTOKAT_VALID:ARB_PK_BAS_KAL_ARBEITSTAGE:ARB_DATUM:ARB_FK_BAS'
||'_KAL_ARBEITSTAG:ARB_FK_STD_KAL_WOCHENENDE:ARB_FK_STD_KAL_FEIERTAG:ARB_FEIERTAG:ARB_VON_PK_BAS_KAL_ARBEITSTAGE:ARB_VON_DATUM:ARB_VON_FK_BAS_KAL_ARBEITSTAG:ARB_VON_FK_STD_KAL_WOCHENENDE:ARB_VON_FK_STD_KAL_FEIERTAG:ARB_VON_FEIERTAG:ARB_VON_TAG:ARB_VON_M'
||'ONAT:ARB_VON_JAHR:ARB_BIS_PK_BAS_KAL_ARBEITSTAGE:ARB_BIS_DATUM:ARB_BIS_FK_BAS_KAL_ARBEITSTAG:ARB_BIS_FK_STD_KAL_WOCHENENDE:ARB_BIS_FK_STD_KAL_FEIERTAG:ARB_BIS_FEIERTAG:ARB_BIS_TAG:ARB_BIS_MONAT:ARB_BIS_JAHR:PK_ADR_LAND:LAND:PK_ADR_ORT:ORT:CI_PK_ADR_L'
||'AND:CI_LAND:STEU_STEUERSATZ:STEU_LAND:STEU_PK_ADR_LAND:STEU_PK_BAS_STEU_STEUER_SATZ:STEU_ZUS_ST:STEU_FRMD_STEUERSATZ:STEU_FRMD_LAND:STEU_FRMD_PK_ADR_LAND:STEU_FRMD_PK_BAS_STEU_STEUER_SATZ:STEU_FRMD_ZUS_ST:PK_BAS_MON_WAEHRUNG:WAEHRUNG_LANG:COMM:ABL_OR'
||'D_J_PAGE_NUMBER:ABL_ORD_PK_ABL_ORDNER_PAGE:ABL_ORD_PAGE_NUMBER:ABL_ORD_JAHR:ABL_ORD_ORDNER_NAME:ABL_ORD_PK_ABL_ORDNER:VBEL_ART:VBEL_FK_IMP_BA_BEL:VBEL_PK_IMP_BA_ALLG_BEL:VBEL_BEZEICHNUNG:VBEL_KENNZEICHEN:VBEL_DATUM:BRUTTO_BETRAG_EUR:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14316594231028655)
,p_report_id=>wwv_flow_api.id(14306525430943591)
,p_name=>'offener_Betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BRUTTO_BETRAG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BRUTTO_BETRAG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26071556755554939)
,p_plug_name=>'Einnahmen / Ausgaben'
,p_parent_plug_id=>wwv_flow_api.id(26071419590554938)
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when betrag >0 then ''Einnahme'' else ''Ausgabe'' end ein_aus,''<b>'' || bucht_jahr || ''</b>''|| case when betrag >0 then '' (A-EIN)'' else '' (B-AUS)'' end  bucht_jahr,',
'case when sum(betrag)>0 then sum(betrag) else -1*sum(betrag) end betrag , count(*) cnt from v_kto_konten_zus group by bucht_jahr, ',
'''<b>'' || bucht_jahr || ''</b>''|| case when betrag >0 then '' (A-EIN)'' else '' (B-AUS)'' end  ,case when betrag >0 then ''Einnahme'' else ''Ausgabe'' end',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26071662785554940)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>26071662785554940
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26495263258519418)
,p_db_column_name=>'EIN_AUS'
,p_display_order=>10
,p_column_identifier=>'JT'
,p_column_label=>'Ein Aus'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26495426547519420)
,p_db_column_name=>'BETRAG'
,p_display_order=>30
,p_column_identifier=>'JV'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26495527732519421)
,p_db_column_name=>'CNT'
,p_display_order=>40
,p_column_identifier=>'JW'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26495681668519422)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>50
,p_column_identifier=>'JX'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26669631037525662)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'266697'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EIN_AUS:BETRAG:CNT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26495706167519423)
,p_plug_name=>'Einnahmen / Ausgaben (graph.)'
,p_parent_plug_id=>wwv_flow_api.id(26071419590554938)
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when betrag >0 then ''Einnahme'' else ''Ausgabe'' end ein_aus,''<b>'' || bucht_jahr || ''</b>''|| case when betrag >0 then '' (A-EIN)'' else '' (B-AUS)'' end  bucht_jahr,',
'case when sum(betrag)>0 then sum(betrag) else -1*sum(betrag) end betrag , count(*) cnt from v_kto_konten_zus group by bucht_jahr, ',
'''<b>'' || bucht_jahr || ''</b>''|| case when betrag >0 then '' (A-EIN)'' else '' (B-AUS)'' end  ,case when betrag >0 then ''Einnahme'' else ''Ausgabe'' end',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26495889950519424)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>26495889950519424
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26495931244519425)
,p_db_column_name=>'EIN_AUS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ein Aus'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26496044751519426)
,p_db_column_name=>'BETRAG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26496139402519427)
,p_db_column_name=>'CNT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26496285330519428)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26681129111036171)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'266812'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EIN_AUS:BETRAG:CNT:BUCHT_JAHR'
,p_chart_type=>'lineWithArea'
,p_chart_label_column=>'BUCHT_JAHR'
,p_chart_value_column=>'BETRAG'
,p_chart_sorting=>'DEFAULT'
,p_chart_orientation=>'horizontal'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26682044804056342)
,p_report_id=>wwv_flow_api.id(26681129111036171)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'EIN_AUS'
,p_operator=>'='
,p_expr=>'Ausgabe'
,p_condition_sql=>'"EIN_AUS" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Ausgabe''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26496307084519429)
,p_plug_name=>'Plan/Ist'
,p_parent_plug_id=>wwv_flow_api.id(26071419590554938)
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  case when fk_std_inp_zahlungsstatus = 1  then ''A - Offen'' ',
'            when  fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 3 then ''B - Abgeschlossen (geplant)'' ',
'            when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 1 then ''C - Abgeschlossen (ungeplant)'' ',
'             when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 4 then ''D - Abgeschlossen (geplant - ohne Zahlung)''',
unistr('              when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 2 then ''E - Abgeschlossen (geplant - ge\00E4ndert)'''),
'            else ''F - other'' || fk_std_inp_zahlungsstatus || fk_std_inp_planned ',
'            end grp , sum(brutto_betrag) betrag  ',
'from t_inp_belege_all ',
'where fk_abl_ordner_page in (388,282,264)',
'group by case when fk_std_inp_zahlungsstatus = 1  then ''A - Offen'' ',
'             when  fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 3 then ''B - Abgeschlossen (geplant)'' ',
'            when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 1 then ''C - Abgeschlossen (ungeplant)''',
'                         when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 4 then ''D - Abgeschlossen (geplant - ohne Zahlung)''',
unistr('                          when fk_std_inp_zahlungsstatus = 3 and fk_std_inp_planned = 2 then ''E - Abgeschlossen (geplant - ge\00E4ndert)'''),
'            else ''F - other''  || fk_std_inp_zahlungsstatus || fk_std_inp_planned  end',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26496403054519430)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>26496403054519430
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26496693831519432)
,p_db_column_name=>'BETRAG'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26496953805519435)
,p_db_column_name=>'GRP'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Grp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26684043789277640)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'266841'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BETRAG:GRP'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41088305197228403)
,p_plug_name=>'Inventare'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inv.*, datum_next, case when substr(datum_next, 7,4) = substr(sysdate, 7,4) then 1 else 0 end this_year,    case when arb1.pk_bas_kal_arbeitstage is not null then 1 else 0 end sel_date  ',
'from t_inv_inventare inv  ',
' left join t_kal_termine ter on ter.fk_inv_inventar = inv.pk_inv_inventar',
' left join t_bas_kal_arbeitstage arb on arb.datum = substr(ter.datum_next, 1, 10)',
' left join   (select * from t_bas_kal_arbeitstage where datum = to_date(:P1_sel_date,''DD.MM.YYYY''))  arb1 on (arb.monat = arb1.monat or arb.monat = arb1.monat+1) and arb.jahr = arb1.jahr',
'where to_date(datum_next,''DD.MM.YYYY'') >= to_date(sysdate,''DD.MM.YYYY'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41088436099228404)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::P39_PK_INV_INVENTAR:#PK_INV_INVENTAR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>42528755374619944
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41795861035221487)
,p_db_column_name=>'INVENTAR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41795931856221488)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796012794221489)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796126067221490)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796207492221491)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796303933221492)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796398730221493)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796519454221494)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796631007221495)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796686206221496)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Preis Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41796878476221497)
,p_db_column_name=>'MWST'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797029395221499)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Preis Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797180405221500)
,p_db_column_name=>'COMM'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797244929221501)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797342159221502)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797558468221504)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Kfz Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797593893221505)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797745747221506)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797787894221507)
,p_db_column_name=>'BILD'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Bild'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41797921045221508)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798038452221509)
,p_db_column_name=>'ABGANGSDATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Abgangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798128448221510)
,p_db_column_name=>'ABGANGSWERT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Abgangswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798325534224762)
,p_db_column_name=>'GWG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Gwg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798434523224763)
,p_db_column_name=>'RESTBUCHWERT_2017'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Restbuchwert 2017'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798481155224764)
,p_db_column_name=>'ABGANGSGRUND'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Abgangsgrund'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798657966224765)
,p_db_column_name=>'MAC_ADRESSE'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Mac Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798722426224766)
,p_db_column_name=>'SERIENNUMMER'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Seriennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798973115224768)
,p_db_column_name=>'OK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41798991862224769)
,p_db_column_name=>'OK_BEMERKUNGEN'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ok Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41799096795224770)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41799221378224771)
,p_db_column_name=>'INV_BILD'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Inv Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41799329080224772)
,p_db_column_name=>'ANSCHAFFUNGSWERT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Anschaffungswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41802523429224804)
,p_db_column_name=>'DATUM_NEXT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Datum Next'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41802626183224805)
,p_db_column_name=>'THIS_YEAR'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'This Year'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41802759040224806)
,p_db_column_name=>'SEL_DATE'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sel Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44410060066171971)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682264121596786)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>430
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682478077596788)
,p_db_column_name=>'GERAETENAME'
,p_display_order=>450
,p_column_identifier=>'AV'
,p_column_label=>'Geraetename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46338731712755206)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>470
,p_column_identifier=>'AX'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46338793955755207)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>480
,p_column_identifier=>'AY'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47810245114542182)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>490
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41815708710227730)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'432561'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_NEXT:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:RESTBUCHWERT_2018:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PREIS_NETTO:MWST:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHRGESTELLNR:BEMERKUNGEN:BILD:'
||'ABGANGSJAHR:ABGANGSDATUM:ABGANGSWERT:GWG:RESTBUCHWERT_2017:ABGANGSGRUND:MAC_ADRESSE:SERIENNUMMER:OK:OK_BEMERKUNGEN:RESTBUCHWERT_2019:INV_BILD:ANSCHAFFUNGSWERT::THIS_YEAR:SEL_DATE:PK_INV_INVENTAR:FK_BAS_INV_INVENTARTYP:GERAETENAME:FK_BAS_STEU_STEUER_S'
||'ATZ:RESTBUCHWERT_2020:FK_STD_VERW_VERWENDUNGSZWECK'
,p_sort_column_1=>'DATUM_NEXT'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41952722531696099)
,p_report_id=>wwv_flow_api.id(41815708710227730)
,p_name=>'this_next_month'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_DATE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_DATE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41953127820696099)
,p_report_id=>wwv_flow_api.id(41815708710227730)
,p_name=>'this_year'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'THIS_YEAR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("THIS_YEAR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0EACE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41799402927224773)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(93625233107085176)
,p_plug_name=>unistr('n\00E4chste_Zahlung')
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FK_MAIN_KEY,',
'       ID,',
'       Buchungstag,',
'       Betrag,',
'       Waehrung,',
'       Fremdwaehrungsbetrag,',
'       Fremdwaehrung,',
'       BUCHUNGSTEXT,',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       FK_std_kto_Kontotyp,',
'       FK_bas_kal_BUCHUNGSTAG,',
'       FK_bas_kal_WERTSTELLUNG,',
'       VERWENDUNGSZWECK,',
'       KATEGORIE,',
'       BUCHT_TAG,',
'       BUCHT_MONAT,',
'       BUCHT_JAHR,',
'       BUCHT_DATUM,',
'       WERTT_TAG,',
'       WERTT_MONAT,',
'       WERTT_JAHR,',
'       WERTT_DATUM,',
'       Kontotyp,',
'       FK_kto_VORGANG,',
'       WIEDERHOLUNG,',
'       NAECHSTE_ZAHLUNG,',
'       substr(naechste_Zahlung,7,4) jahr,',
'       arb.tag arb_tag,',
'       arb.monat arb_monat,',
'       arb.jahr arb_jahr,',
'       case when arb1.pk_bas_kal_arbeitstage is not null then 1 else 0 end sel_date',
'  from V_kto_KONTEN_ZUS zus',
'   left join  t_bas_kal_arbeitstage  arb on zus.naechste_zahlung = arb.datum',
'   left join   (select * from t_bas_kal_arbeitstage where datum = :P1_sel_date)  arb1 on (arb.monat = arb1.monat or arb.monat = arb1.monat+1) and arb.jahr = arb1.jahr',
'  where  trunc(naechste_Zahlung) >= trunc(sysdate)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(93625327054085176)
,p_name=>unistr('n\00E4chste_Zahlung')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL:'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>95065646329476716
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41771332691213547)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41771756765213547)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41773319741213547)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41775762729213549)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41776117705213549)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41776501197213549)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41776948768213550)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41777322177213550)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41777777748213550)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41778132511213550)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41778481199213550)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41778977407213550)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41779285002213550)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41780482254213552)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41780891995213552)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41770901929213545)
,p_db_column_name=>'JAHR'
,p_display_order=>57
,p_column_identifier=>'AD'
,p_column_label=>'Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41781330448213552)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>67
,p_column_identifier=>'AE'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41781696742213553)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>77
,p_column_identifier=>'AF'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41782168420213553)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>87
,p_column_identifier=>'AG'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41800158164224780)
,p_db_column_name=>'SEL_DATE'
,p_display_order=>97
,p_column_identifier=>'AH'
,p_column_label=>'Sel Date'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44410953019171980)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>157
,p_column_identifier=>'AN'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44411025128171981)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>167
,p_column_identifier=>'AO'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44681845960596782)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>177
,p_column_identifier=>'AP'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44681918288596783)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>187
,p_column_identifier=>'AQ'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44681990551596784)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>197
,p_column_identifier=>'AR'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682513789596789)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>207
,p_column_identifier=>'AS'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682861290596792)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>237
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44682881843596793)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>247
,p_column_identifier=>'AW'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47810099075542181)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>257
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48787112724065803)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>267
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13416152908242842)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>277
,p_column_identifier=>'BA'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13416299427242843)
,p_db_column_name=>'BETRAG'
,p_display_order=>287
,p_column_identifier=>'BB'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(93637885940106563)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'432228'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:ARB_JAHR:ARB_MONAT:NAECHSTE_ZAHLUNG:FK_MAIN_KEY:ID:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:WERTT_TAG:WERTT_MONAT:WIEDERHOLUNG:ARB_TAG:SEL_DATE::FK_BAS_FK_BAS_KONTOTYP:FK_KTO_VORGANG:WAEHRUNGSFREMDWAEHRUNG:FK_BAS_KAT_KATEGOR'
||'IE:FK_BAS_KAL_FK_BAS_KAL_WERTSTELLUNG:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:BUCHUNGSTAG:BETRAG'
,p_break_on=>'JAHR:ARB_JAHR:ARB_MONAT'
,p_break_enabled_on=>'JAHR:ARB_JAHR:ARB_MONAT'
,p_sum_columns_on_break=>'Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41853784634586822)
,p_report_id=>wwv_flow_api.id(93637885940106563)
,p_name=>unistr('N\00E4chste Zahlung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'NAECHSTE_ZAHLUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("NAECHSTE_ZAHLUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41854207520586824)
,p_report_id=>wwv_flow_api.id(93637885940106563)
,p_name=>'this_month'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_DATE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL_DATE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41853009912586822)
,p_report_id=>wwv_flow_api.id(93637885940106563)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(41853480046586822)
,p_report_id=>wwv_flow_api.id(93637885940106563)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'20 0'
,p_condition_sql=>'"JAHR" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''20 0''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41799540751224774)
,p_name=>'P1_SEL_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(41799402927224773)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Sel Date'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(datum,''DD.MM.YYYY'') d ,  to_char(datum,''DD.MM.YYYY'') r',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41799606840224775)
,p_name=>'P1_DAY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(41799402927224773)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41799728055224776)
,p_name=>'P1_MONTH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(41799402927224773)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(41799834094224777)
,p_name=>'P1_YEAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(41799402927224773)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum d , datum r',
'from t_bas_kal_arbeitstage',
'where datum = :P1_sel_date'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(41799893630224778)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_SEL_DATE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(41800061072224779)
,p_event_id=>wwv_flow_api.id(41799893630224778)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
