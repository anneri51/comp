prompt --application/shared_components/security/authorizations/group_check_open
begin
--   Manifest
--     SECURITY SCHEME: Group_CHECK_OPEN
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(41030239536197395)
,p_name=>'Group_CHECK_OPEN'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_cnt number;',
'begin',
'  select  count(*)',
'  into v_cnt',
'  from T_REL_USM_USER_GROUP_USER',
'  where fk_usM_user =8 and fk_usm_user_group =2 and :APP_USER = ''ANNE'';',
' ',
'  if v_cnt >0 then ',
'   return true;',
'  else',
'    return false;',
'  end if;',
'  ',
'end;'))
,p_error_message=>'Keine Berechtigung!'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
