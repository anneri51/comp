prompt --application/pages/page_00207
begin
--   Manifest
--     PAGE: 00207
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>207
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'FIN_BUDGET_BUCHUNG'
,p_alias=>'FIN-BUDGET-BUCHUNG_207'
,p_step_title=>'FIN_BUDGET_BUCHUNG'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210214180851'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24330188393161696)
,p_plug_name=>'FIN_BUDGET_BUCHUNG'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24337270530161715)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(24330188393161696)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P207_PK_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24336097696161710)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24330188393161696)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24337612114161715)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(24330188393161696)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P207_PK_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24336877103161714)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(24330188393161696)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P207_PK_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24330456151161696)
,p_name=>'P207_PK_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pk Rel Fin Budget Kto Buchung'
,p_source=>'PK_REL_FIN_BUDGET_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24330894782161704)
,p_name=>'P207_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24331230441161707)
,p_name=>'P207_FK_FIN_BUDGET'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_prompt=>'Fk Fin Budget'
,p_source=>'FK_FIN_BUDGET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select comm, pk_fin_budget',
'from t_fin_budget'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24331630971161707)
,p_name=>'P207_FK_MAIN_KEY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_prompt=>'Fk Main Key'
,p_source=>'FK_MAIN_KEY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_MAIN_KEY_BUCHUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  zus.fk_main_key  || '' '' || Buchungstag || '' '' || round(Betrag,2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum ||  '' '' ||   mark_buchung   d',
'    ,',
'    zus.FK_MAIN_KEY r',
'from v_kto_konten_zus zus',
' left join (',
' ',
' ',
' select  distinct fk_main_key, listagg(buchung, '' / '') over (partition by fk_main_key) mark_buchung',
' from (',
' select fk_main_key,  case when lex_buchung = ''Buchung'' then ''Buchung'' when inpBel_status = ''vorbereitet'' then ''vorbereitet'' else ''nix!!!'' end buchung',
' from (',
' select fk_main_key, case when fk_std_inp_status = 11 then ''vorbereitet'' else null end inpbel_status , case when fk_lex_relation is not null then ''Buchung'' else null end lex_buchung, row_number() over (partition by fk_main_key order by fk_main_key) r'
||'nr',
' from t_rel_lex_kto_bel relbel',
'   left join t_inp_belege_all inp on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
' ',
' ) a',
' where rnr <=10',
' )b',
' ) mark_buch on mark_buch.fk_main_key = zus.fk_main_key'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24332016040161707)
,p_name=>'P207_CREATED_DT'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Created Dt'
,p_source=>'CREATED_DT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24332472378161707)
,p_name=>'P207_MODIFY_DT'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_prompt=>'Modify Dt'
,p_source=>'MODIFY_DT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24332829128161708)
,p_name=>'P207_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(24333212676161708)
,p_name=>'P207_MODIFIED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(24330188393161696)
,p_item_source_plug_id=>wwv_flow_api.id(24330188393161696)
,p_prompt=>'Modified By'
,p_source=>'MODIFIED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24338479125161716)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(24330188393161696)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form FIN_BUDGET_BUCHUNG'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24338051608161715)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(24330188393161696)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FIN_BUDGET_BUCHUNG'
);
wwv_flow_api.component_end;
end;
/
