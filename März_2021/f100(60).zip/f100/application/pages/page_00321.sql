prompt --application/pages/page_00321
begin
--   Manifest
--     PAGE: 00321
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>321
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>unistr('beleg\00FCbersicht_finanzhilfe')
,p_alias=>unistr('BELEG\00DCBERSICHT-FINANZHILFE_321')
,p_step_title=>unistr('beleg\00FCbersicht_finanzhilfe')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210313144802'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40701549705637661)
,p_plug_name=>unistr('Beleg\00FCbersicht (Finanzhilfe)')
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INP_BELEGE_ALL,',
'       bezeichnung',
'       FK_STD_INP_BELEGART,',
'       BELEGART,',
'       FLG_GEPLANT_UNGEPLANT,',
'       FK_STD_INP_PLANNED,',
'       FK_STD_INP_FIX_VARIABEL,',
'       FLG_FIX_VARIABEL,',
'       arb_jahr,',
'       arb_monat,',
'      -1* brutto_betrag  brutto_betrag,',
'       fk_kon_geschaeftspartner,',
'       geschaeftspartner,',
'       inventar,',
'       fk_bas_kat_kategorie,',
'       ktokat_Kategorie,',
'       arb_datum,',
'       bel_datum,',
'      Einnahme_ausgabe,',
'  fk_std_inp_ein_aus,',
'   fk_inp_belege_all_template',
'  from V_INP_BELEGE_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Beleg\00FCbersicht (Finanzhilfe)')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(40701685221637661)
,p_name=>unistr('beleg\00FCbersicht_finanzhilfe')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.::P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>40701685221637661
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40702068427637944)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40811481581638027)
,p_db_column_name=>'BELEGART'
,p_display_order=>279
,p_column_identifier=>'JQ'
,p_column_label=>'Belegart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40811877994638027)
,p_db_column_name=>'FLG_GEPLANT_UNGEPLANT'
,p_display_order=>280
,p_column_identifier=>'JR'
,p_column_label=>'Flg Geplant Ungeplant'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40812278460638027)
,p_db_column_name=>'FK_STD_INP_PLANNED'
,p_display_order=>281
,p_column_identifier=>'JS'
,p_column_label=>'Fk Std Inp Planned'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40812660099638028)
,p_db_column_name=>'FK_STD_INP_FIX_VARIABEL'
,p_display_order=>282
,p_column_identifier=>'JT'
,p_column_label=>'Fk Std Inp Fix Variabel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40813098586638028)
,p_db_column_name=>'FLG_FIX_VARIABEL'
,p_display_order=>283
,p_column_identifier=>'JU'
,p_column_label=>'Flg Fix Variabel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814231180645301)
,p_db_column_name=>'FK_STD_INP_BELEGART'
,p_display_order=>293
,p_column_identifier=>'JV'
,p_column_label=>'Fk Std Inp Belegart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814329536645302)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>303
,p_column_identifier=>'JW'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814427069645303)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>313
,p_column_identifier=>'JX'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814534804645304)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>323
,p_column_identifier=>'JY'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814608093645305)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>333
,p_column_identifier=>'JZ'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814716579645306)
,p_db_column_name=>'GESCHAEFTSPARTNER'
,p_display_order=>343
,p_column_identifier=>'KA'
,p_column_label=>'Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40814819981645307)
,p_db_column_name=>'INVENTAR'
,p_display_order=>353
,p_column_identifier=>'KB'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40815518105645314)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>363
,p_column_identifier=>'KC'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40815632976645315)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>373
,p_column_identifier=>'KD'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40817532021645334)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>383
,p_column_identifier=>'KE'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40817623925645335)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>393
,p_column_identifier=>'KF'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40817712481645336)
,p_db_column_name=>'EINNAHME_AUSGABE'
,p_display_order=>403
,p_column_identifier=>'KG'
,p_column_label=>'Einnahme Ausgabe'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40817870053645337)
,p_db_column_name=>'FK_STD_INP_EIN_AUS'
,p_display_order=>413
,p_column_identifier=>'KH'
,p_column_label=>'Fk Std Inp Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(40817971347645338)
,p_db_column_name=>'FK_INP_BELEGE_ALL_TEMPLATE'
,p_display_order=>423
,p_column_identifier=>'KI'
,p_column_label=>'Fk Inp Belege All Template'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40813610371640053)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'408137'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_INP_BELEGE_ALL:BELEGART:FK_STD_INP_BELEGART:FK_STD_INP_FIX_VARIABEL:FK_STD_INP_PLANNED:FLG_FIX_VARIABEL:FLG_GEPLANT_UNGEPLANT::ARB_JAHR:ARB_MONAT:BRUTTO_BETRAG:FK_KON_GESCHAEFTSPARTNER:GESCHAEFTSPARTNER:INVENTAR:FK_BAS_KAT_KATEGORIE:KTOKAT_KATEGOR'
||'IE:ARB_DATUM:BEL_DATUM:EINNAHME_AUSGABE:FK_STD_INP_EIN_AUS:FK_INP_BELEGE_ALL_TEMPLATE'
,p_break_on=>'ARB_MONAT'
,p_break_enabled_on=>'ARB_MONAT'
,p_sum_columns_on_break=>'BRUTTO_BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42580121274304628)
,p_report_id=>wwv_flow_api.id(40813610371640053)
,p_name=>'ein'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EINNAHME_AUSGABE'
,p_operator=>'='
,p_expr=>'Einnahme'
,p_condition_sql=>' (case when ("EINNAHME_AUSGABE" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Einnahme''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42578976848304627)
,p_report_id=>wwv_flow_api.id(40813610371640053)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2019'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42579380133304627)
,p_report_id=>wwv_flow_api.id(40813610371640053)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_FIX_VARIABEL'
,p_operator=>'='
,p_expr=>'FIX'
,p_condition_sql=>'"FLG_FIX_VARIABEL" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''FIX''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(42579765147304628)
,p_report_id=>wwv_flow_api.id(40813610371640053)
,p_name=>'Einnahmen_Ausgaben_fix'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_expr_type=>'ROW'
,p_expr=>'KG =''Einnahme'' or ( KG =''Ausgabe'' and JT  = ''1'')'
,p_condition_sql=>'"EINNAHME_AUSGABE" =''Einnahme'' or ( "EINNAHME_AUSGABE" =''Ausgabe'' and "FK_STD_INP_FIX_VARIABEL"  = ''1'')'
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
