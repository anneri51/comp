prompt --application/shared_components/navigation/lists/list_kto_kontoauszug_prüfen
begin
--   Manifest
--     LIST: LIST - KTO - Kontoauszug prüfen
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(8101658331214164)
,p_name=>unistr('LIST - KTO - Kontoauszug pr\00FCfen')
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8102645314214169)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'1 - Kontoauszug (94)'
,p_list_item_link_target=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(39340333420186743)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>unistr('2 - Kontoauszug pr\00FCfen (295)')
,p_list_item_link_target=>'f?p=&APP_ID.:295:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8106187781214171)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('3 - Kontoauszug pr\00FCfen (386)')
,p_list_item_link_target=>'f?p=&APP_ID.:386 :&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8110333619214172)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('4 - Kontoauszug pr\00FCfen (475)')
,p_list_item_link_target=>'f?p=&APP_ID.:475:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
