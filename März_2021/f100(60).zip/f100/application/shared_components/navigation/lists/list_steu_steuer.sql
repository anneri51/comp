prompt --application/shared_components/navigation/lists/list_steu_steuer
begin
--   Manifest
--     LIST: LIST - STEU -  Steuer
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(7875167789057310)
,p_name=>'LIST - STEU -  Steuer'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7876179350057311)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Belegerfassung'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7879602979057313)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Belegbuchung'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7883854945057315)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Belegkontrolle'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7888010465057316)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Erstellung Steuererkl\00E4rung')
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7892230800057318)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Abgabe Steuererkl\00E4rung')
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7896429531057320)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Steuerbescheid'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7900619306057322)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Steuerzahlung'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
