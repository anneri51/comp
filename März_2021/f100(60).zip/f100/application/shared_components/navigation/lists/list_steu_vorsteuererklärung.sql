prompt --application/shared_components/navigation/lists/list_steu_vorsteuererklärung
begin
--   Manifest
--     LIST: LIST - STEU - Vorsteuererklärung
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(7969438609734085)
,p_name=>unistr('LIST - STEU - Vorsteuererkl\00E4rung')
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7982298988734108)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>unistr('Vorsteuererkl\00E4rung Monate')
,p_list_item_link_target=>'f?p=&APP_ID.:331:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7970349966734098)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Vorsteuer Monate bearbeiten'
,p_list_item_link_target=>'f?p=&APP_ID.:332:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27327811226287977)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Vorsteuer - Buchungen bearbeiten'
,p_list_item_link_target=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27337888242557691)
,p_list_item_display_sequence=>17
,p_list_item_link_text=>'1460 - Konto Geldtransit'
,p_list_item_link_target=>'f?p=&APP_ID.:346:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27343944232583177)
,p_list_item_display_sequence=>18
,p_list_item_link_text=>unistr('Kontenzusammenf\00FChrung (Auszahlungen)')
,p_list_item_link_target=>'f?p=&APP_ID.:381:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7973899188734104)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Liste Vorsteuererkl\00E4rung \00DCbermittlungen')
,p_list_item_link_target=>'f?p=&APP_ID.:333:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7978026980734106)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Vorsteuer\00FCbermittlung erfassen')
,p_list_item_link_target=>'f?p=&APP_ID.:334:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27347391955634172)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Vorsteuer-',
'zusammenfassung'))
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
