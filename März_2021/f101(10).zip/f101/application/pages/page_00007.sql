prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'1_4_TXTW_Text_replace_zuord'
,p_alias=>'TEXT_REPLACE_ZUORD_7'
,p_step_title=>'Text_replace_zuord'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632876297608890)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210214192924'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7326600034531396)
,p_plug_name=>'Text Replacement Zuordnen'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7059309376925217)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7379751201542016)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7088215084925228)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7326759988531396)
,p_plug_name=>'Step 6'
,p_parent_plug_id=>wwv_flow_api.id(7326600034531396)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7021577436925200)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(93754242641794469)
,p_plug_name=>unistr('Zuordnung von Text Replacements (\00DCbersicht)')
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select relrep.PK_REL_db_TXT_REPLACED,',
'       relrep.FK_db_TXT_REPLACE,',
'       relrep.FK_db_TXT_REPLACE_log,',
'       relrep.DATUM,',
'       rep.FROM_TXT,',
'       rep.TO_TXT,',
'       relrep.SORT,',
'       rp.suchen,',
'       rp.ersetzen,',
'       substr(rep.from_txt,1,4000) ausgangstxt',
'  from T_REL_db_TXT_REPLACEd relrep',
'   left join t_db_txt_replace rp on rp.pk_db_txt_replace = relrep.fk_db_txt_replace',
'   left join t_db_txt_replace_log rep on rep.pk_db_txt_replace_log = relrep.fk_db_txt_replace_log'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(93754726263794471)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,:P8_PK_REL_DB_TXT_REPLACED:#PK_REL_DB_TXT_REPLACED#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>93754726263794471
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47648613587661584)
,p_db_column_name=>'DATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47649033513661584)
,p_db_column_name=>'FROM_TXT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'From Txt'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47649493118661584)
,p_db_column_name=>'TO_TXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'To Txt'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47649850088661584)
,p_db_column_name=>'SORT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47646231342661578)
,p_db_column_name=>'SUCHEN'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Suchen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47646629827661582)
,p_db_column_name=>'ERSETZEN'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Ersetzen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47647039149661582)
,p_db_column_name=>'AUSGANGSTXT'
,p_display_order=>37
,p_column_identifier=>'J'
,p_column_label=>'Ausgangstxt'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16597548442395264)
,p_db_column_name=>'PK_REL_DB_TXT_REPLACED'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Pk Rel Db Txt Replaced'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16597590856395265)
,p_db_column_name=>'FK_DB_TXT_REPLACE'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Fk Db Txt Replace'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16597747121395266)
,p_db_column_name=>'FK_DB_TXT_REPLACE_LOG'
,p_display_order=>67
,p_column_identifier=>'M'
,p_column_label=>'Fk Db Txt Replace Log'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(93758758842816624)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'476502'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM:FROM_TXT:TO_TXT:SORT:SUCHEN:ERSETZEN:AUSGANGSTXT:PK_REL_DB_TXT_REPLACED:FK_DB_TXT_REPLACE:FK_DB_TXT_REPLACE_LOG'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7328444305531397)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7326600034531396)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7328777788531397)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7326600034531396)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7111190258925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7328657921531397)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7326600034531396)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7110358808925237)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47650658742661585)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(93754242641794469)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_PK_REL_DB_TXT_REPLACED:'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7330085020531398)
,p_branch_action=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7328777788531397)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7329304485531397)
,p_branch_action=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7328657921531397)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7328155198531397)
,p_name=>'P7_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7326759988531396)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
