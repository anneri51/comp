prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>24
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'1_2_TBW_OBJ_OBJECT_LIST'
,p_alias=>'OBJECT_LIST_24'
,p_step_title=>'TBW Object List'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210216195444'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31086220464558137)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(33138696848925477)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7112489922925237)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40572290194637347)
,p_plug_name=>'Step 1'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7059309376925217)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(33149523868055607)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7088215084925228)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40572425844637347)
,p_plug_name=>'Step 3'
,p_parent_plug_id=>wwv_flow_api.id(40572290194637347)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7021577436925200)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(54991282090623051)
,p_plug_name=>'Object List'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select obj.PK_DB_OBJ_OBJECT_LIST,',
'       obj.OBJECT_TYPE,',
'      ',
'       obj.OBJECT_NAME,',
'   ',
'       obj.FK_STD_DB_OBJ_STATUS,',
'       obj.COMM,',
'       obj.CREATE_AT,',
'       obj.FLG_NEU,',
'       allobj.object_name allobj_object_name,',
'       obj.page_id,',
'       obj.application_id,',
'       obj.workspace_id,',
'       pg.page_title, ',
'       pg.page_mode,',
'       pg.page_name,',
'       pg.page_group,',
'       pg.page_group_id,',
'       obj.fk_std_db_app_obj_status,',
'       aps.std_name apex_obj_status,',
'       objs.std_name obj_status,',
'       obj.page_name obj_page_name,',
'       obj.page_group obj_page_group,',
'       obj.page_mode obj_page_mode,',
'       obj.column_name,',
'       obj.data_type,',
'       obj.data_length,',
'       obj.data_default,',
'       obj.column_id,',
'       obj.nullable,',
'       obj.page_comment,',
'       obj.created_on,',
'       obj.created_by,',
'       obj.last_updated_on,',
'       obj.last_updated_by',
'  from T_DB_OBJ_OBJECT_LIST obj',
'    left join all_objects allobj on obj.object_type = allobj.object_type and obj.object_name = allobj.object_name',
'    left join apex_application_pages pg on pg.page_id = obj.page_id and pg.application_id = obj.application_id',
'    left join (select * from t_std where fk_std_group =41 ) aps on aps.std_value = obj.fk_std_db_app_obj_status',
'    left join (select * from t_std where fk_std_group =641 ) objs on objs.std_value = obj.fK_STD_DB_OBJ_STATUS'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(54991305460623051)
,p_name=>'T_DB_OBJ_OBJECT_LIST'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP:P25_PK_DB_OBJ_OBJECT_LIST:#PK_DB_OBJ_OBJECT_LIST#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>54991305460623051
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54991780340623067)
,p_db_column_name=>'PK_DB_OBJ_OBJECT_LIST'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Db Obj Object List'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54992064506623076)
,p_db_column_name=>'OBJECT_TYPE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Object Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54992836833623079)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(54993682486623081)
,p_db_column_name=>'FK_STD_DB_OBJ_STATUS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Std Db Obj Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55015019252829133)
,p_db_column_name=>'COMM'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55015136281829134)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55015275659829135)
,p_db_column_name=>'FLG_NEU'
,p_display_order=>36
,p_column_identifier=>'I'
,p_column_label=>'Flg Neu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55015335981829136)
,p_db_column_name=>'ALLOBJ_OBJECT_NAME'
,p_display_order=>46
,p_column_identifier=>'J'
,p_column_label=>'Allobj Object Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55093670026932623)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55093708420932624)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55093833055932625)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>86
,p_column_identifier=>'N'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55093928652932626)
,p_db_column_name=>'PAGE_TITLE'
,p_display_order=>96
,p_column_identifier=>'O'
,p_column_label=>'Page Title'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55094078466932627)
,p_db_column_name=>'PAGE_MODE'
,p_display_order=>106
,p_column_identifier=>'P'
,p_column_label=>'Page Mode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55094133393932628)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>116
,p_column_identifier=>'Q'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55094242879932629)
,p_db_column_name=>'PAGE_GROUP'
,p_display_order=>126
,p_column_identifier=>'R'
,p_column_label=>'Page Group'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55094394792932630)
,p_db_column_name=>'PAGE_GROUP_ID'
,p_display_order=>136
,p_column_identifier=>'S'
,p_column_label=>'Page Group Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55136473574192750)
,p_db_column_name=>'APEX_OBJ_STATUS'
,p_display_order=>156
,p_column_identifier=>'U'
,p_column_label=>'Apex Obj Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55174244319684401)
,p_db_column_name=>'OBJ_STATUS'
,p_display_order=>166
,p_column_identifier=>'V'
,p_column_label=>'Obj Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55174316720684402)
,p_db_column_name=>'OBJ_PAGE_NAME'
,p_display_order=>176
,p_column_identifier=>'W'
,p_column_label=>'Obj Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55174425351684403)
,p_db_column_name=>'OBJ_PAGE_GROUP'
,p_display_order=>186
,p_column_identifier=>'X'
,p_column_label=>'Obj Page Group'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55174576509684404)
,p_db_column_name=>'OBJ_PAGE_MODE'
,p_display_order=>196
,p_column_identifier=>'Y'
,p_column_label=>'Obj Page Mode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177187110684430)
,p_db_column_name=>'COLUMN_NAME'
,p_display_order=>206
,p_column_identifier=>'Z'
,p_column_label=>'Column Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177233829684431)
,p_db_column_name=>'DATA_TYPE'
,p_display_order=>216
,p_column_identifier=>'AA'
,p_column_label=>'Data Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177333029684432)
,p_db_column_name=>'DATA_LENGTH'
,p_display_order=>226
,p_column_identifier=>'AB'
,p_column_label=>'Data Length'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177487866684433)
,p_db_column_name=>'DATA_DEFAULT'
,p_display_order=>236
,p_column_identifier=>'AC'
,p_column_label=>'Data Default'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177549946684434)
,p_db_column_name=>'COLUMN_ID'
,p_display_order=>246
,p_column_identifier=>'AD'
,p_column_label=>'Column Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177665490684435)
,p_db_column_name=>'NULLABLE'
,p_display_order=>256
,p_column_identifier=>'AE'
,p_column_label=>'Nullable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177741945684436)
,p_db_column_name=>'PAGE_COMMENT'
,p_display_order=>266
,p_column_identifier=>'AF'
,p_column_label=>'Page Comment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177819403684437)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>276
,p_column_identifier=>'AG'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55177937408684438)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>286
,p_column_identifier=>'AH'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55178083148684439)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>296
,p_column_identifier=>'AI'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(55178113914684440)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>306
,p_column_identifier=>'AJ'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33742660411614549)
,p_db_column_name=>'FK_STD_DB_APP_OBJ_STATUS'
,p_display_order=>316
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Db App Obj Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(54994269702624282)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'549943'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_DB_OBJ_OBJECT_LIST:OBJECT_TYPE:OBJECT_NAME:COLUMN_NAME:CREATE_AT:FLG_NEU:ALLOBJ_OBJECT_NAME:PAGE_ID:APPLICATION_ID:WORKSPACE_ID:PAGE_TITLE:PAGE_MODE:OBJ_PAGE_NAME:PAGE_NAME:PAGE_GROUP:PAGE_GROUP_ID:OBJ_STATUS:APEX_OBJ_STATUS:COMM:FK_STD_DB_OBJ_STA'
||'TUS:OBJ_PAGE_GROUP:OBJ_PAGE_MODE:DATA_TYPE:DATA_LENGTH:DATA_DEFAULT:COLUMN_ID:NULLABLE:PAGE_COMMENT:CREATED_ON:CREATED_BY:LAST_UPDATED_ON:LAST_UPDATED_BY:FK_STD_DB_APP_OBJ_STATUS'
,p_sort_column_1=>'COLUMN_ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PAGE_ID'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(33499100763369085)
,p_report_id=>wwv_flow_api.id(54994269702624282)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_APEX_OBJ_STATUS'
,p_operator=>'in'
,p_expr=>'4,7'
,p_condition_sql=>' (case when ("FK_STD_APEX_OBJ_STATUS" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 4, 7  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(33499554533369086)
,p_report_id=>wwv_flow_api.id(54994269702624282)
,p_name=>'to_check'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_APEX_OBJ_STATUS'
,p_operator=>'in'
,p_expr=>'5'
,p_condition_sql=>' (case when ("FK_STD_APEX_OBJ_STATUS" in (#APXWS_EXPR_VAL1#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 5  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(33499903972369086)
,p_report_id=>wwv_flow_api.id(54994269702624282)
,p_name=>'not ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_APEX_OBJ_STATUS'
,p_operator=>'in'
,p_expr=>'6,8'
,p_condition_sql=>' (case when ("FK_STD_APEX_OBJ_STATUS" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 6, 8  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(33498740202369085)
,p_report_id=>wwv_flow_api.id(54994269702624282)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APPLICATION_ID'
,p_operator=>'contains'
,p_expr=>'100'
,p_condition_sql=>'upper("APPLICATION_ID") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 100  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(55136396985192749)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(54991282090623051)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'New'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP:P25_PK_DB_OBJ_OBJECT_LIST:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(55179073578684449)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(54991282090623051)
,p_button_name=>'add_new_column'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Add New Column'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33159424050095320)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(40572290194637347)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33159898472095321)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(40572290194637347)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33160261122095321)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(40572290194637347)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7110358808925237)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7395650269542025)
,p_branch_name=>'Go To Page 25'
,p_branch_action=>'f?p=&APP_ID.:25:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33160972759095325)
,p_name=>'P24_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(40572425844637347)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(55178924566684448)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_new_column'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' insert into t_db_obj_object_list (object_type, object_name, column_name, data_type, data_length, data_precision, nullable, column_id, data_default, create_at, created_on, last_updated_on)',
'select ''COLUMN'', ut.table_name, ut.column_name, ut.data_type, ut.data_length, ut.data_precision, ut.nullable, ut.column_id, null data_default, sysdate, sysdate sd, sysdate',
'from user_tab_cols ut',
' left join t_db_obj_object_list obj on ut.column_name = obj.column_name and ut.data_type = obj.data_type and obj.object_name = ut.table_name',
'where obj.object_name is null;',
'commit;',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(55179073578684449)
);
wwv_flow_api.component_end;
end;
/
