prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>32
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'1_2_TBW_OBJ_OBJECT_STATUS_HIST'
,p_alias=>'1-2-TBW-OBJ-OBJECT-STATUS-HIST'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'1_2_TBW_OBJ_OBJECT_STATUS_HIST'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210217071832'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33197353241394334)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(33138696848925477)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7112489922925237)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33205990359415305)
,p_plug_name=>'Object Status'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_DB_OBJ_OBJECT_LIST_STATUS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(64307197304997727)
,p_plug_name=>'Object'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_DB_OBJ_OBJECT_LIST,',
'       OBJECT_TYPE,',
'       OBJECT_NAME,',
'       FK_STD_DB_OBJ_STATUS,',
'       COMM,',
'       CREATE_AT,',
'       FLG_NEU,',
'       PAGE_ID,',
'       APPLICATION_ID,',
'       WORKSPACE_ID,',
'       FK_STD_db_APP_OBJ_STATUS,',
'       PAGE_NAME,',
'       PAGE_GROUP,',
'       PAGE_MODE,',
'       COLUMN_NAME,',
'       DATA_TYPE,',
'       DATA_LENGTH,',
'       DATA_PRECISION,',
'       NULLABLE,',
'       COLUMN_ID,',
'       DATA_DEFAULT,',
'       CREATED_BY,',
'       CREATED_ON,',
'       LAST_UPDATED_BY,',
'       LAST_UPDATED_ON,',
'       PAGE_COMMENT,',
'       FK_KON_REWORKED_BY,',
'       REWORKED_ON',
'  from T_DB_OBJ_OBJECT_LIST',
'  where pk_db_obj_object_list = :P32_fk_db_obj_object_list'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(64307474387997729)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:RP,:P33_FK_DB_OBJ_OBJECT_LIST,P33_PK_REL_DB_OBJ_OBJECT_LIST_PART:#FK_STD_DB_APP_OBJ_STATUS#,#PK_REL_DB_OBJ_OBJECT_LIST_PART#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>64307474387997729
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33221156422439596)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'A'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33194609382394307)
,p_db_column_name=>'PK_DB_OBJ_OBJECT_LIST'
,p_display_order=>60
,p_column_identifier=>'M'
,p_column_label=>'Pk Db Obj Object List'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33194730564394308)
,p_db_column_name=>'OBJECT_TYPE'
,p_display_order=>70
,p_column_identifier=>'N'
,p_column_label=>'Object Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33194809350394309)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>80
,p_column_identifier=>'O'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33194960689394310)
,p_db_column_name=>'FK_STD_DB_OBJ_STATUS'
,p_display_order=>90
,p_column_identifier=>'P'
,p_column_label=>'Fk Std Db Obj Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195015662394311)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>100
,p_column_identifier=>'Q'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195179092394312)
,p_db_column_name=>'FLG_NEU'
,p_display_order=>110
,p_column_identifier=>'R'
,p_column_label=>'Flg Neu'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195288717394313)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195308888394314)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>130
,p_column_identifier=>'T'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195479675394315)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>140
,p_column_identifier=>'U'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195638135394317)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>160
,p_column_identifier=>'W'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195759697394318)
,p_db_column_name=>'PAGE_GROUP'
,p_display_order=>170
,p_column_identifier=>'X'
,p_column_label=>'Page Group'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195874096394319)
,p_db_column_name=>'PAGE_MODE'
,p_display_order=>180
,p_column_identifier=>'Y'
,p_column_label=>'Page Mode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33195980225394320)
,p_db_column_name=>'COLUMN_NAME'
,p_display_order=>190
,p_column_identifier=>'Z'
,p_column_label=>'Column Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196023547394321)
,p_db_column_name=>'DATA_TYPE'
,p_display_order=>200
,p_column_identifier=>'AA'
,p_column_label=>'Data Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196192605394322)
,p_db_column_name=>'DATA_LENGTH'
,p_display_order=>210
,p_column_identifier=>'AB'
,p_column_label=>'Data Length'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196246321394323)
,p_db_column_name=>'DATA_PRECISION'
,p_display_order=>220
,p_column_identifier=>'AC'
,p_column_label=>'Data Precision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196303141394324)
,p_db_column_name=>'NULLABLE'
,p_display_order=>230
,p_column_identifier=>'AD'
,p_column_label=>'Nullable'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196441821394325)
,p_db_column_name=>'COLUMN_ID'
,p_display_order=>240
,p_column_identifier=>'AE'
,p_column_label=>'Column Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196513237394326)
,p_db_column_name=>'DATA_DEFAULT'
,p_display_order=>250
,p_column_identifier=>'AF'
,p_column_label=>'Data Default'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196650160394327)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>260
,p_column_identifier=>'AG'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196790184394328)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>270
,p_column_identifier=>'AH'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196831529394329)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>280
,p_column_identifier=>'AI'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33196949425394330)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>290
,p_column_identifier=>'AJ'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33197087153394331)
,p_db_column_name=>'PAGE_COMMENT'
,p_display_order=>300
,p_column_identifier=>'AK'
,p_column_label=>'Page Comment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33197142117394332)
,p_db_column_name=>'FK_KON_REWORKED_BY'
,p_display_order=>310
,p_column_identifier=>'AL'
,p_column_label=>'Fk Kon Reworked By'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33197203671394333)
,p_db_column_name=>'REWORKED_ON'
,p_display_order=>320
,p_column_identifier=>'AM'
,p_column_label=>'Reworked On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33742789522614550)
,p_db_column_name=>'FK_STD_DB_APP_OBJ_STATUS'
,p_display_order=>330
,p_column_identifier=>'AN'
,p_column_label=>'Fk Std Db App Obj Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(66425439779838276)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'332259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:FK_DB_OBJ_OBJECT_LIST_STATUS:MODIFIED_AT_ERROR_DEV_ALL:PK_DB_OBJ_OBJECT_LIST:OBJECT_TYPE:OBJECT_NAME:FK_STD_DB_OBJ_STATUS:CREATE_AT:FLG_NEU:PAGE_ID:APPLICATION_ID:WORKSPACE_ID:PAGE_NAME:PAGE_GROUP:PAGE_MODE:COLUMN_NAME:DATA_TYPE:DATA_LENGTH:DATA'
||'_PRECISION:NULLABLE:COLUMN_ID:DATA_DEFAULT:CREATED_BY:CREATED_ON:LAST_UPDATED_BY:LAST_UPDATED_ON:PAGE_COMMENT:FK_KON_REWORKED_BY:REWORKED_ON:FK_STD_DB_APP_OBJ_STATUS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106985855027191825)
,p_plug_name=>'Step 6'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7059309376925217)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(33149523868055607)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7088215084925228)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(106985990677191825)
,p_plug_name=>'Step 6'
,p_parent_plug_id=>wwv_flow_api.id(106985855027191825)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7021577436925200)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33215859216415322)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(33205990359415305)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P32_PK_DB_OBJ_OBJECT_LIST_STATUS'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33214636483415319)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33205990359415305)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33250087306451257)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(106985855027191825)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33216236889415322)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(33205990359415305)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P32_PK_DB_OBJ_OBJECT_LIST_STATUS'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33215496268415321)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(33205990359415305)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P32_PK_DB_OBJ_OBJECT_LIST_STATUS'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33250460452451257)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(106985855027191825)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33250801045451258)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(106985855027191825)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7110358808925237)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33198647098394347)
,p_name=>'P32_FK_STD_DB_OBJ_STATUS_ZUORD_OBJ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Std Db Obj Status Zuord Obj'
,p_source=>'FK_STD_DB_OBJ_STATUS_ZUORD_OBJ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_STD_DB_OBJ_STATUS_ZUORD_OBJ'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Std_name, std_value',
'from t_std',
'where fk_std_group = 1263'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33198711551394348)
,p_name=>'P32_STATUS_ZUORD_OBJ'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Status Zuord Obj'
,p_source=>'STATUS_ZUORD_OBJ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33206249771415307)
,p_name=>'P32_PK_DB_OBJ_OBJECT_LIST_STATUS'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'ID'
,p_source=>'PK_DB_OBJ_OBJECT_LIST_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33206655438415312)
,p_name=>'P32_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33207018340415314)
,p_name=>'P32_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33207461415415315)
,p_name=>'P32_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33207830569415315)
,p_name=>'P32_FK_STD_DB_OBJ_STATUS_ERROR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Std Db Obj Status Error'
,p_source=>'FK_STD_DB_OBJ_STATUS_ERROR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_STD_DB_OBJ_STATUS_ERROR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 1243'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33208249344415315)
,p_name=>'P32_FK_STD_DB_OBJ_STATUS_DEV'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Std Db Obj Status Dev'
,p_source=>'FK_STD_DB_OBJ_STATUS_DEV'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_STD_DB_OBJ_STATUS_DEV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 1244'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33208666070415315)
,p_name=>'P32_FK_STD_DB_OBJ_STATUS_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Std Db Obj Status All'
,p_source=>'FK_STD_DB_OBJ_STATUS_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_STD_DB_OBJ_STATUS_ALL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 1245'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33209071864415316)
,p_name=>'P32_STATUS_ERROR_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Status Error Date'
,p_source=>'STATUS_ERROR_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33209468611415316)
,p_name=>'P32_STATUS_DEV_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Status Dev Date'
,p_source=>'STATUS_DEV_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33209837949415316)
,p_name=>'P32_STATUS_ALL_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Status All Date'
,p_source=>'STATUS_ALL_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33210256555415316)
,p_name=>'P32_FK_DB_OBJ_OBJECT_LIST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Fk Db Obj Object List'
,p_source=>'FK_DB_OBJ_OBJECT_LIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33210638594415316)
,p_name=>'P32_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(33205990359415305)
,p_item_source_plug_id=>wwv_flow_api.id(33205990359415305)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33251592798451261)
,p_name=>'P32_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(106985990677191825)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33217051357415323)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(33205990359415305)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 1_2_TBW_OBJ_OBJECT_STATUS_HIST'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(33216606802415323)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(33205990359415305)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 1_2_TBW_OBJ_OBJECT_STATUS_HIST'
);
wwv_flow_api.component_end;
end;
/
