prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>40
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'HISTORY_BACKUP'
,p_alias=>'HISTORY_BACKUP_40'
,p_step_title=>'HISTORY_BACKUP'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(48250276776250054)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210217092612'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16652561570306673)
,p_plug_name=>'Object_History'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16652641466306674)
,p_plug_name=>'Column_History'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16652773101306675)
,p_plug_name=>'APEX_History'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16652824569306676)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16652561570306673)
,p_button_name=>'Load_Object_History_new_DB_Objects'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Load Object History New Db Objects'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16653015903306678)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16652641466306674)
,p_button_name=>'Load_Object_History_new_DB_tab_Columns'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Load_Object_History_new_DB_tab_Columns'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16653353731306681)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16652773101306675)
,p_button_name=>'Load_Object_History_update_apex_pages'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Load_Object_History_update_apex_pages'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16653579301306683)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(16652561570306673)
,p_button_name=>'Load_Objects_History_table_count_new_DB_Objects'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Load Objects History Table Count New Db Objects'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16653716503306685)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(16652561570306673)
,p_button_name=>'Load_Object_History_add_table_count_cnt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Load Object History Add Table Count Cnt'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(34275986626855301)
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16652898930306677)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1 - 1  Load_Objects_new_db_objects'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pkg_db_obj_hist.p_1_load_object_list_new_db_objects;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16653605261306684)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4- 1  Load_Objects_table_count_new_db_objects_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pkg_db_obj_hist.p_4_load_objects_table_count_new_db_objects;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16653812929306686)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6- 1  Load_Objects_add_table_count_cnt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pkg_db_obj_hist.p_6_load_object_table_count_cnt;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16653132478306679)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2 - 1  Load_Objects_new_db_tab_columns'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pkg_db_obj_hist.p_2_load_object_list_new_tab_column;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16653465629306682)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3 - 1  Load_Objects_update_apex_pages'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   pkg_db_obj_hist.p_3_load_objects_list_new_apex_pages;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31083038267558105)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'11 - dummy_add_pages'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'insert into t_db_app_pages_history',
'select',
'null PK_DB_APP_PAGES_HISTORY,',
'1 FK_MDT_MANDANT,',
'sysdate CREATED_AT,',
'sysdate MODIFIED_AT,',
'PAGE_ID,',
'null COMM,',
'last_updated_on,',
'PAGE_NAME,',
'PAGE_TITLE,',
'PAGE_GROUP_ID,',
'null PAGE_GROUP_NAME,',
'null FK_DB_APP_APPLICATION,',
'null FK_STD_PAG_ITEM_ALL_STATUS,',
'null FK_STD_PAG_ITEM_SEL_POPUP_STATUS,',
'null FK_STD_PAG_BUTTON_STATUS,',
'null FK_STD_PAG_REPORTS_STATUS,',
'null FK_STD_PAG_LINKS_STATUS,',
'null FK_STD_PAG_PROCESSES_STATUS,',
'null FK_STD_PAG_STATUS,',
'null application_id,',
'ITEMS,',
'BUTTONS,',
'COMPUTATIONS,',
'VALIDATIONS,',
'PROCESSES,',
'BRANCHES,',
'REPORT_COLUMNS,',
'PAGE_ALIAS,',
'null FK_DB_APP_PAGE_HISTORY_COPY_FROM',
'from apex_application_pages;',
'commit;',
'---',
'insert into T_DB_APP_APEX_PAGES_CONTENT_CNT_LINES',
'select',
'null PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES,',
'null WORKSPACE_ID,',
'APPlication_ID,',
'PAGE_ID,',
'null CNT_LINES,',
'null COMM,',
'null COMPLETE_IMPORTED,',
'sysdate CREATED_DATE,',
'null REBUILD_COMPLETED,',
'null REBUILD_COMPLETED_ON,',
'null FK_DB_APP_APPLICATION,',
'sysdate MODIFIED_AT,',
'null FK_STD_PAG_STATUS,',
'1 FK_MDT_MANDANT,',
'last_updated_on,',
'null FK_STD_PAG_ITEM_ALL_STATUS,',
'null FK_STD_PAG_ITEM_SEL_POPUP_STATUS,',
'null FK_STD_PAG_BUTTON_STATUS,',
'null FK_STD_PAG_REPORTS_STATUS,',
'null FK_STD_PAG_LINKS_STATUS,',
'null FK_STD_PAG_PROCESSES_STATUS,',
'workspace',
'from apex_application_pages;',
'commit;',
'--',
'create table t_rel_db_obj_object_dependency as',
'select rownum pk_rel_db_obj_object_dependency,',
'DEPENDENCY_TYPE,',
'NAME,',
'REFERENCED_LINK_NAME,',
'REFERENCED_NAME,',
'REFERENCED_OWNER,',
'REFERENCED_TYPE,',
'SCHEMAID,',
'TYPE,',
'0 fk_db_obj_object_list_reference,',
'0 fk_db_obj_object_list_referenced,',
'''a'' comm,',
'''a'' created_by,',
'sysdate created_at,',
'''a'' modified_by,',
'sysdate modified_at',
'from user_dependencies;',
'--',
'insert into t_REL_DB_OBJ_OBJECT_DEPENDENCY (',
'',
'APPLication_ID,',
'APPLICATION_NAME,',
'DB_COLUMN_NAME,',
'DB_TABLE_NAME,',
'DISPLAY_AS,',
'DISPLAY_SEQUENCE,',
'HELP_TEXT,',
'INLINE_HELP_TEXT,',
'ITEM_ID,',
'ITEM_LABEL,',
'ITEM_NAME,',
'PAGE_ID,',
'PAGE_NAME,',
'REGION,',
'WORKSPACE,',
'WORKSPACE_DISPLAY_NAME,',
'created_at',
')',
'select',
'APPLication_ID,',
'APPLICATION_NAME,',
'DB_COLUMN_NAME,',
'DB_TABLE_NAME,',
'DISPLAY_AS,',
'DISPLAY_SEQUENCE,',
'HELP_TEXT,',
'INLINE_HELP_TEXT,',
'ITEM_ID,',
'ITEM_LABEL,',
'ITEM_NAME,',
'PAGE_ID,',
'PAGE_NAME,',
'REGION,',
'WORKSPACE,',
'WORKSPACE_DISPLAY_NAME,',
'sysdate',
'from aPEX_APPLICATION_PAGE_DB_ITEMS;',
'commit;',
'',
'End;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
