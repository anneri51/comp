prompt --application/pages/page_00047
begin
--   Manifest
--     PAGE: 00047
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>47
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'2_2_APP_Page_Errors'
,p_alias=>'PAGE-ERRORS_47'
,p_step_title=>'Page_errors1'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(27902563542196336)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210223194325'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31083131368558106)
,p_plug_name=>'Page Error Overview'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--accent2:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7031923036925204)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id, page_id,  app, category, page, count(*) cnt',
'  from (select * from apex_application_pages where workspace  = ''COMPANY'') app',
'  left join   T_DB_APP_PAGES_ERRORS err on app.application_id = to_number(err.app) and app.page_id = to_number(err.page)',
'group by application_id, page_id, app, category, page'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Page Error Overview'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(31083226431558107)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>31083226431558107
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31083575613558110)
,p_db_column_name=>'APP'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'App'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31084290568558117)
,p_db_column_name=>'CATEGORY'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Category'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31084781652558122)
,p_db_column_name=>'PAGE'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Page'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31084895551558123)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31084995379558124)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085011532558125)
,p_db_column_name=>'CNT'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(32410631441751767)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'324107'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'APPLICATION_ID:PAGE_ID:APP:CATEGORY:PAGE:CNT:'
,p_break_on=>'PAGE_ID'
,p_break_enabled_on=>'PAGE_ID'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32302316459515260)
,p_plug_name=>'Page_errors'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,id) sel,',
'  ID,',
'       ROWNR,',
'       APP,',
'       DESCR,',
'       NR,',
'       SUBNR,',
'       PAGE,',
'       ATTRIBUTE,',
'       CHECK1,',
'       CATEGORY,',
'       MESSAGE,',
'       VALUE,',
'       DATUM,',
'       FK_DB_APP_ERR_STATUS,',
'       STATUS_DATE,',
'       FK_STD_PAG_DEB_IMPORTANCE,',
'       FK_STD_PAG_DEB_STATUS',
'  from T_DB_APP_PAGES_ERRORS',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Page_errors'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(32302455721515261)
,p_name=>'Page_errors1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>32302455721515261
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32302843034515270)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32303295562515277)
,p_db_column_name=>'ROWNR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Rownr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32303608190515277)
,p_db_column_name=>'APP'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'App'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32304002158515278)
,p_db_column_name=>'DESCR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32304485179515278)
,p_db_column_name=>'NR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32304853105515278)
,p_db_column_name=>'SUBNR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Subnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32305255752515278)
,p_db_column_name=>'PAGE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Page'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32305694900515279)
,p_db_column_name=>'ATTRIBUTE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Attribute'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32306467476515279)
,p_db_column_name=>'CATEGORY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Category'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32306890338515279)
,p_db_column_name=>'MESSAGE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32307223285515280)
,p_db_column_name=>'VALUE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32307611731515280)
,p_db_column_name=>'DATUM'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085122414558126)
,p_db_column_name=>'CHECK1'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Check1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085254314558127)
,p_db_column_name=>'FK_DB_APP_ERR_STATUS'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Fk Db App Err Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085385887558128)
,p_db_column_name=>'STATUS_DATE'
,p_display_order=>43
,p_column_identifier=>'P'
,p_column_label=>'Status Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085415267558129)
,p_db_column_name=>'FK_STD_PAG_DEB_IMPORTANCE'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Fk Std Pag Deb Importance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085559867558130)
,p_db_column_name=>'FK_STD_PAG_DEB_STATUS'
,p_display_order=>63
,p_column_identifier=>'R'
,p_column_label=>'Fk Std Pag Deb Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(31085861303558133)
,p_db_column_name=>'SEL'
,p_display_order=>73
,p_column_identifier=>'S'
,p_column_label=>'pk <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(32308262578517570)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'323083'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:ID:ROWNR:APP:DESCR:NR:SUBNR:PAGE:ATTRIBUTE:CATEGORY:MESSAGE:VALUE:DATUM:CHECK1:FK_DB_APP_ERR_STATUS:STATUS_DATE:FK_STD_PAG_DEB_IMPORTANCE:FK_STD_PAG_DEB_STATUS:'
,p_break_on=>'SUBNR'
,p_break_enabled_on=>'SUBNR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(34154751083873000)
,p_report_id=>wwv_flow_api.id(32308262578517570)
,p_name=>'Fehler_behoben'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DB_APP_ERR_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_DB_APP_ERR_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(34153563145872999)
,p_report_id=>wwv_flow_api.id(32308262578517570)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APP'
,p_operator=>'='
,p_expr=>'101'
,p_condition_sql=>'"APP" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(34153973583872999)
,p_report_id=>wwv_flow_api.id(32308262578517570)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE'
,p_operator=>'='
,p_expr=>'10'
,p_condition_sql=>'"PAGE" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''10''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(34154308017873000)
,p_report_id=>wwv_flow_api.id(32308262578517570)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SUBNR'
,p_operator=>'='
,p_expr=>'12'
,p_condition_sql=>'"SUBNR" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''12''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(35906352411040632)
,p_plug_name=>'Page_errors'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>3
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   APP,',
'   page,',
'       FK_DB_APP_ERR_STATUS,',
'      count(*) cnt',
'  from T_DB_APP_PAGES_ERRORS',
'  group by app,',
'  page,',
'       FK_DB_APP_ERR_STATUS',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Page_errors'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(35906632675040635)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>35906632675040635
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(35908001921040649)
,p_db_column_name=>'FK_DB_APP_ERR_STATUS'
,p_display_order=>140
,p_column_identifier=>'B'
,p_column_label=>'Fk Db App Err Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36201430243323004)
,p_db_column_name=>'CNT'
,p_display_order=>150
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36201523248323005)
,p_db_column_name=>'APP'
,p_display_order=>160
,p_column_identifier=>'D'
,p_column_label=>'App'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36201661010323006)
,p_db_column_name=>'PAGE'
,p_display_order=>170
,p_column_identifier=>'E'
,p_column_label=>'Page'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(36207499563342198)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'362075'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_DB_APP_ERR_STATUS:CNT:APP:PAGE'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_break_on=>'PAGE'
,p_break_enabled_on=>'PAGE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36212221468398630)
,p_report_id=>wwv_flow_api.id(36207499563342198)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APP'
,p_operator=>'='
,p_expr=>'100'
,p_condition_sql=>'"APP" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31085614318558131)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(32302316459515260)
,p_button_name=>'Set_OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set Ok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(31085754520558132)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(32302316459515260)
,p_button_name=>'Set_Not_OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Set Not Ok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31085926579558134)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_Set_OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'   ',
'     update t_db_app_pages_errors set fk_db_app_err_status = 1, status_date = sysdate where id = apex_application.g_f01(i);',
'     commit;',
'   end if;',
' ',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(31085614318558131)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(31086065891558135)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Set_Not_OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'   ',
'     update t_db_app_pages_errors set fk_db_app_err_status = 2, status_date = sysdate where id = apex_application.g_f01(i);',
'     commit;',
'   end if;',
' ',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(31085754520558132)
);
wwv_flow_api.component_end;
end;
/
