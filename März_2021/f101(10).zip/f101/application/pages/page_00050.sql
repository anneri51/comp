prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>50
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'2_2_APP_apex_page_content_overview'
,p_alias=>'APEX-PAGE-CONTENT-OVERV_50'
,p_step_title=>'APP apex_page_conten OVt_overview'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(27902563542196336)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210217094743'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7502861565070101)
,p_plug_name=>'apex_page_content_overview'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       APP_ID app_id1,',
'       count(*),',
'       case when app_id = :P50_app_id1 then 1 else 0 end sel',
'  from T_DB_APP_PAGES_CONTENT_CNT_LINES',
'  group by app_id,',
'  case when app_id = :P50_app_id1 then 1 else 0 end'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'apex_page_content_overview'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7502970535070102)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::P50_APP_ID1,P50_APP_ID:#APP_ID1#,#APP_ID1##AP_ID1#,#AP_ID1#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>7502970535070102
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7503867012070111)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504197733070114)
,p_db_column_name=>'SEL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(34276139572855303)
,p_db_column_name=>'APP_ID1'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'App Id1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7509269946075617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75093'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COUNT(*):SEL:APP_ID1'
,p_sort_column_1=>'AP_ID1'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'APP_ID'
,p_sort_direction_2=>'ASC'
,p_sum_columns_on_break=>'COUNT(*)'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7520030499326843)
,p_report_id=>wwv_flow_api.id(7509269946075617)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7503970619070112)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7504565613070118)
,p_plug_name=>'Apex Page Content Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apcntli.PK_DB_APP_PAGES_CONTENT_CNT_LINES,',
'        apcntli.WORKSPACE_ID,',
'        apcntli.APP_ID,',
'        apcntli.PAGE_ID,',
'        apcntli.CNT_LINES,',
'        apcntli.COMM,',
'        apcntli.COMPLETE_IMPORTED,',
'        apcntli.CREATED_DATE,',
'        apcntli.REBUILD_COMPLETED,',
'        apcntli.REBUILD_COMPLETED_ON,',
'       case when app_id = :P50_app_id1 then 1 else 0 end sel,',
'       apcnt.cnt,',
'        apcntli.CNT_LINES-apcnt.cnt diff,',
'      --  pg.page_name,',
'      fk_db_app_workspace,',
'      connection_string,',
'      apcntli.FK_DB_APP_APPLICATION, apcntli.MODIFIED_AT, apcntli.FK_STD_PAG_STATUS, apcntli.FK_MDT_MANDANT, apcntli.LAST_CHANGE_DATE,',
'      ',
'       app_pages.page_name,',
'       app_pages.page_alias,',
'       app_pages.page_title,',
'       FK_STD_PAG_ITEM_ALL_STATUS,',
'       FK_STD_PAG_ITEM_SEL_POPUP_STATUS,',
'       FK_STD_PAG_BUTTON_STATUS,',
'       FK_STD_PAG_REPORTS_STATUS,',
'       FK_STD_PAG_LINKS_STATUS,',
'       FK_STD_PAG_PROCESSES_STATUS',
'from T_DB_APP_PAGES_CONTENT_CNT_LINES apcntli',
'  ',
'   left join (select application_id, page_id, count(*) cnt from  t_db_app_pages_content group by application_id, page_id) apcnt on apcntli.app_id = apcnt.application_id and apcntli.page_id = apcnt.page_id',
'   left join t_db_app_application app on app.pK_db_app_application = apcntli.fk_db_app_application',
'   left join t_db_app_workspace wsp on wsp.pk_db_app_workspace  = app.fk_db_app_workspace',
'   left join t_db_datenbank db on db.pk_db_datenbank = wsp.fk_db_datenbank',
'   left join (select * from apex_application_pages  ) app_pages on app_pages.page_id = apcntli.page_id and app_pages.application_id = apcntli.app_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Apex Page Content Overview'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7504638305070119)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::P50_PK_DB_APP_PAGES_CONTENT_CNT_LINES:#PK_DB_APP_PAGES_CONTENT_CNT_LINES#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>7504638305070119
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504833824070121)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504958832070122)
,p_db_column_name=>'APP_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'App Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505090994070123)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505127222070124)
,p_db_column_name=>'CNT_LINES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cnt Lines'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505292211070125)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505356093070126)
,p_db_column_name=>'COMPLETE_IMPORTED'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Complete Imported'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505416700070127)
,p_db_column_name=>'CREATED_DATE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505510470070128)
,p_db_column_name=>'REBUILD_COMPLETED'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Rebuild Completed'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505613508070129)
,p_db_column_name=>'REBUILD_COMPLETED_ON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Rebuild Completed On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505780542070130)
,p_db_column_name=>'SEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505843085070131)
,p_db_column_name=>'CNT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505982999070132)
,p_db_column_name=>'DIFF'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358778220365225)
,p_db_column_name=>'FK_DB_APP_WORKSPACE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Db App Workspace'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28358870216365226)
,p_db_column_name=>'CONNECTION_STRING'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Connection String'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359115008365229)
,p_db_column_name=>'FK_DB_APP_APPLICATION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Db App Application'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359246704365230)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359317029365231)
,p_db_column_name=>'FK_STD_PAG_STATUS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Std Pag Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359489758365232)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359515016365233)
,p_db_column_name=>'LAST_CHANGE_DATE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Last Change Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359613720365234)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359740077365235)
,p_db_column_name=>'PAGE_ALIAS'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Page Alias'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359868138365236)
,p_db_column_name=>'PAGE_TITLE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Page Title'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28359972031365237)
,p_db_column_name=>'FK_STD_PAG_ITEM_ALL_STATUS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Std Pag Item All Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28360077081365238)
,p_db_column_name=>'FK_STD_PAG_ITEM_SEL_POPUP_STATUS'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Pag Item Sel Popup Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28360139674365239)
,p_db_column_name=>'FK_STD_PAG_BUTTON_STATUS'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Std Pag Button Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28360212973365240)
,p_db_column_name=>'FK_STD_PAG_REPORTS_STATUS'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk Std Pag Reports Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28360361074365241)
,p_db_column_name=>'FK_STD_PAG_LINKS_STATUS'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Pag Links Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28360478728365242)
,p_db_column_name=>'FK_STD_PAG_PROCESSES_STATUS'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Std Pag Processes Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(33742389042614546)
,p_db_column_name=>'PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Pk Db App Pages Content Cnt Lines'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7715817868222420)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'77159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE_ID:APP_ID:PAGE_ID:CNT_LINES:COMM:COMPLETE_IMPORTED:CREATED_DATE:REBUILD_COMPLETED:REBUILD_COMPLETED_ON:SEL:CNT:DIFF:FK_DB_APP_WORKSPACE:CONNECTION_STRING:FK_DB_APP_APPLICATION:MODIFIED_AT:FK_STD_PAG_STATUS:FK_MDT_MANDANT:LAST_CHANGE_DATE:PA'
||'GE_NAME:PAGE_ALIAS:PAGE_TITLE:FK_STD_PAG_ITEM_ALL_STATUS:FK_STD_PAG_ITEM_SEL_POPUP_STATUS:FK_STD_PAG_BUTTON_STATUS:FK_STD_PAG_REPORTS_STATUS:FK_STD_PAG_LINKS_STATUS:FK_STD_PAG_PROCESSES_STATUS:PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_sort_column_1=>'APP_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_ID'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7719045639305599)
,p_report_id=>wwv_flow_api.id(7715817868222420)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7719484477305599)
,p_report_id=>wwv_flow_api.id(7715817868222420)
,p_name=>'rebuild_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'REBUILD_COMPLETED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("REBUILD_COMPLETED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(57867021521301390)
,p_plug_name=>'Apex Pages  Content cnt_lines'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28360860554365246)
,p_plug_name=>'Standard'
,p_parent_plug_id=>wwv_flow_api.id(57867021521301390)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28360900936365247)
,p_plug_name=>'Final'
,p_parent_plug_id=>wwv_flow_api.id(57867021521301390)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28361056018365248)
,p_plug_name=>'Status'
,p_parent_plug_id=>wwv_flow_api.id(57867021521301390)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28977825424717401)
,p_plug_name=>'tab'
,p_parent_plug_id=>wwv_flow_api.id(28361056018365248)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7055796252925215)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28361149363365249)
,p_plug_name=>'Rebuild'
,p_parent_plug_id=>wwv_flow_api.id(28977825424717401)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28361274121365250)
,p_plug_name=>'Continual_Development'
,p_parent_plug_id=>wwv_flow_api.id(28977825424717401)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28943435806653890)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(57867021521301390)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P50_PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28942603747653888)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(57867021521301390)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28943815582653890)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(57867021521301390)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P50_PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28943087592653889)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(57867021521301390)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P50_PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7504388071070116)
,p_name=>'P50_APP_ID1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7503970619070112)
,p_prompt=>'App Id1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28944680798653896)
,p_name=>'P50_WORKSPACE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Workspace Id'
,p_source=>'WORKSPACE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28945092424653897)
,p_name=>'P50_APP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'App Id'
,p_source=>'APP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28945438371653897)
,p_name=>'P50_PAGE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Page Id'
,p_source=>'PAGE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28945805846653897)
,p_name=>'P50_CNT_LINES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Cnt Lines'
,p_source=>'CNT_LINES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28946163767653897)
,p_name=>'P50_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28361056018365248)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28946519911653898)
,p_name=>'P50_COMPLETE_IMPORTED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(57867021521301390)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Complete Imported'
,p_source=>'COMPLETE_IMPORTED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28946907828653898)
,p_name=>'P50_CREATED_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28360900936365247)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Created Date'
,p_source=>'CREATED_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28947351486653898)
,p_name=>'P50_REBUILD_COMPLETED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28361149363365249)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Rebuild Completed'
,p_source=>'REBUILD_COMPLETED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28947766362653899)
,p_name=>'P50_REBUILD_COMPLETED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28361149363365249)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Rebuild Completed On'
,p_source=>'REBUILD_COMPLETED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28948151288653899)
,p_name=>'P50_FK_DB_APP_APPLICATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Db App Application'
,p_source=>'FK_DB_APP_APPLICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28948528881653900)
,p_name=>'P50_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(28360900936365247)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28948965618653900)
,p_name=>'P50_FK_STD_PAG_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(57867021521301390)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Status'
,p_source=>'FK_STD_PAG_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28949314072653901)
,p_name=>'P50_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28360860554365246)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28949707439653901)
,p_name=>'P50_LAST_CHANGE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28360900936365247)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Last Change Date'
,p_source=>'LAST_CHANGE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28950105093653901)
,p_name=>'P50_FK_STD_PAG_ITEM_ALL_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Item All Status'
,p_source=>'FK_STD_PAG_ITEM_ALL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28950574454653902)
,p_name=>'P50_FK_STD_PAG_ITEM_SEL_POPUP_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Item Sel Popup Status'
,p_source=>'FK_STD_PAG_ITEM_SEL_POPUP_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28950941607653902)
,p_name=>'P50_FK_STD_PAG_BUTTON_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Button Status'
,p_source=>'FK_STD_PAG_BUTTON_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28951386442653902)
,p_name=>'P50_FK_STD_PAG_REPORTS_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Reports Status'
,p_source=>'FK_STD_PAG_REPORTS_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28951767208653902)
,p_name=>'P50_FK_STD_PAG_LINKS_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Links Status'
,p_source=>'FK_STD_PAG_LINKS_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28952194847653903)
,p_name=>'P50_FK_STD_PAG_PROCESSES_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(28361274121365250)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Fk Std Pag Processes Status'
,p_source=>'FK_STD_PAG_PROCESSES_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_BAS_YES_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Keine Angabe'' d, 0 r from dual',
'union',
'select ''ja / yes'', 1 from dual',
'union',
'select ''nein / no'', 2 from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33742130374614544)
,p_name=>'P50_PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(57867021521301390)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Pk Db App Pages Content Cnt Lines'
,p_source=>'PK_DB_APP_PAGES_CONTENT_CNT_LINES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33742219603614545)
,p_name=>'P50_WORKSPACE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(57867021521301390)
,p_item_source_plug_id=>wwv_flow_api.id(57867021521301390)
,p_prompt=>'Workspace Name'
,p_source=>'WORKSPACE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28360665218365244)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_api.id(57867021521301390)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize Form'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28360757104365245)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(57867021521301390)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
