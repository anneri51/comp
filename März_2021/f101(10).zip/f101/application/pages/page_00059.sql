prompt --application/pages/page_00059
begin
--   Manifest
--     PAGE: 00059
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>59
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>unistr('1_5_DBOV - Datenbank \00DCberblick')
,p_alias=>unistr('DATENBANK-\00DCBERBLICK_59')
,p_step_title=>unistr('DBOV Datebank \00DCberblick')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210215012201'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33739837147614521)
,p_plug_name=>unistr('DBOV - Datenbank \00DCberblick')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
