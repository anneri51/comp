prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test4'
,p_alias=>'TEST4'
,p_step_title=>'test4'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210314163414'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3471203505018113)
,p_name=>'Report 1'
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY_3'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion',
'from bilder_tab'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5590300144294444)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5590753880294445)
,p_query_column_id=>2
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>2
,p_column_heading=>'Dateiname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5591159491294446)
,p_query_column_id=>3
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>3
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5591596812294446)
,p_query_column_id=>4
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>4
,p_column_heading=>'Bildgroesse'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5591960182294446)
,p_query_column_id=>5
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>5
,p_column_heading=>'Breite Px'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5592357005294447)
,p_query_column_id=>6
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>6
,p_column_heading=>'Hoehe Px'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5592723059294447)
,p_query_column_id=>7
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>7
,p_column_heading=>'Bild Aktion'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3472411592040747)
,p_plug_name=>'Bild hochladen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6020281726827976)
,p_plug_name=>'bilder'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(3295300200618255)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3473004104048102)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3472411592040747)
,p_button_name=>'P20_UPLOAD'
,p_button_static_id=>'P20_UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Datei hochladen'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3472713712043503)
,p_name=>'P20_FILE_UPLOAD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3472411592040747)
,p_prompt=>'File Upload'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'WWV_FLOW_FILES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6030295370846161)
,p_name=>'P20_BILD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6020281726827976)
,p_prompt=>'Bild'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>wwv_flow_api.id(3299619060618260)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SQL'
,p_attribute_06=>'SELECt thumbnail from bilder_tab where id = 41'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5578850849115477)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_filename  wwv_flow_files.filename%type;',
'',
' v_bild      blob := null;',
' v_thumb     blob := null;',
'',
' v_oi_bild   ordimage := null;',
' v_oi_thumb  ordimage := null;',
'',
' v_id BILDER_TAB.ID%TYPE;',
'begin',
'   begin',
'     -- Bild aus WWV_FLOW_FILES holen ...',
'     select blob_content, filename ',
'      into v_bild, v_filename ',
'     from wwv_flow_files',
'     where name = :P20_FILE_UPLOAD;',
'',
unistr('     -- Tempor\00E4ren LOB f\00FCr Thumbnail erzeugen'),
'     dbms_lob.createtemporary(v_thumb, true, dbms_lob.call);',
'',
unistr('     -- ORDIMAGE-Objekt f\00FCr Bild und Thumbnail erzeugen'),
'     v_oi_bild  := ordimage(v_bild);',
'     v_oi_bild.setproperties();',
'     v_oi_thumb := ordimage(v_thumb);',
'',
'     -- Thumbnail generieren',
'     v_oi_bild.processcopy(',
'       command => ''maxScale=100 100'',',
'       dest    => v_oi_thumb',
'     );',
'',
'     -- Bild und Thumbnail in Tabelle BILDER_TAB ablegen',
'     insert into bilder_tab (id, bild, thumbnail, dateiname)',
'     values (seq_bilder_tab.nextval, v_bild, v_oi_thumb.getcontent(), v_filename);',
'',
'     -- Bild aus WWV_FLOW_FILES entfernen',
'     delete from wwv_flow_files where name = :P20_FILE_UPLOAD;',
'',
unistr('     -- Tempor\00E4ren LOB freigeben'),
'     dbms_lob.freetemporary(v_thumb);',
'   exception ',
'     -- Im Fehlerfall nix machen; in der Praxis aber zumindest Logging!',
'     when NO_DATA_FOUND then null; ',
'     when TOO_MANY_ROWS then null; ',
'   end;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3473004104048102)
);
wwv_flow_api.component_end;
end;
/
