prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test6'
,p_alias=>'TEST6'
,p_step_title=>'test6'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210315093205'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3382908599505471)
,p_plug_name=>'Person'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_plug_footer=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="text/javascript">',
' apex.jQuery(function() {',
' apex.jQuery("##REGION_STATIC_ID#").tabs();',
' });',
'</script>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3389203816683899)
,p_plug_name=>'Person'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3389411781686166)
,p_plug_name=>'Eltern  / Kind'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9750260067692245)
,p_name=>'Eltern'
,p_parent_plug_id=>wwv_flow_api.id(3389411781686166)
,p_template=>wwv_flow_api.id(3295300200618255)
,p_display_sequence=>200
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_report_attributes=>'style="background-color:#7FFFD4;"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
' apex_item.checkbox2(1,E."PK_ELTERN") as pk_eltern,',
' E."PK_ELTERN" PK_ELTERN_DISPLAY,',
' P.TITEL,',
' E."FK_ELTERN",',
' :P121_PK_PERSON "FK_KIND",',
' E."CREATION_DATE",',
' E."CREATED_BY",',
' E."MODIFY_DATE",',
' E."MODIFIED_BY",',
' P.NAME,',
' P.VORNAME,',
' P.GESCHLECHT,',
' P.NR_AHNENTAFEL,',
' P.GEBOREN_AM,',
' P.GESTORBEN_AM,',
' P.BESCHREIBUNG,',
' P.RUFNAME,',
' P.GEBURTSNAME,',
' GO.ORT GEBURTSORT,',
' GOl.LAND GEBURTSLAND,',
' SO.ORT STERBEORT,',
' SOl.LAND STERBELAND',
',   bt.id',
',   bt.dateiname',
',   dbms_lob.getlength(bt.thumbnail) vorschau',
',   dbms_lob.getlength(bt.bild)      bildgroesse',
',   bt.breite_px',
',   bt.hoehe_px',
',   null as bild_aktion',
'from "#OWNER#"."ELTERN" E',
'  LEFT JOIN PERSON P ON P.PK_PERSON = E.FK_ELTERN',
'  LEFT JOIN ORT GO ON GO.PK_ORT = P.FK_GEBURTSORT',
'  left join land gol on gol.pk_land = go.fk_land',
'  LEFT JOIN ORT SO ON SO.PK_ORT = P.FK_STERBEORT',
'  left join land sol on sol.pk_land = so.fk_land',
'  left join person_bild pb on pb.fk_person = p.pk_person',
'  left join bilder_tab bt on bt.id = pb.fk_bild',
'',
'WHERE FK_KIND = :P121_PK_PERSON'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9750819626692270)
,p_query_column_id=>1
,p_column_alias=>'PK_ELTERN'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" onClick="$f_CheckFirstColumn(this)"/>'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'YES'
,p_pk_col_source_type=>'T'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9751295408692270)
,p_query_column_id=>2
,p_column_alias=>'PK_ELTERN_DISPLAY'
,p_column_display_sequence=>2
,p_column_heading=>'Pk Eltern Display'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9751629447692271)
,p_query_column_id=>3
,p_column_alias=>'TITEL'
,p_column_display_sequence=>3
,p_column_heading=>'Titel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9752012862692271)
,p_query_column_id=>4
,p_column_alias=>'FK_ELTERN'
,p_column_display_sequence=>4
,p_column_heading=>'Fk Eltern'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9752474170692271)
,p_query_column_id=>5
,p_column_alias=>'FK_KIND'
,p_column_display_sequence=>5
,p_column_heading=>'Fk Kind'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9752853510692271)
,p_query_column_id=>6
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>21
,p_column_heading=>'Erstelldatum'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9753240365692272)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>22
,p_column_heading=>'Erstellt von'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9753663545692272)
,p_query_column_id=>8
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>23
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9754073866692272)
,p_query_column_id=>9
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>24
,p_column_heading=>unistr('Ge\00E4ndert durch')
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9754404953692273)
,p_query_column_id=>10
,p_column_alias=>'NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b>#NAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9754803395692273)
,p_query_column_id=>11
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>7
,p_column_heading=>'Vorname'
,p_use_as_row_header=>'N'
,p_column_html_expression=>' <b>#VORNAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9755298367692274)
,p_query_column_id=>12
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>8
,p_column_heading=>'Geschlecht'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b><i>#GESCHLECHT#</i></b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9755612808692274)
,p_query_column_id=>13
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>10
,p_column_heading=>'<span title="Nr der Person in der Ahnentafel (Papierform)">Nr Ahnentafel</span>'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9756081333692274)
,p_query_column_id=>14
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>13
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9756460654692274)
,p_query_column_id=>15
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>16
,p_column_heading=>'Gestorben Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9756807750692275)
,p_query_column_id=>16
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>19
,p_column_heading=>'Beschreibung'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9757253362692275)
,p_query_column_id=>17
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>12
,p_column_heading=>'Rufname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9757603180692275)
,p_query_column_id=>18
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>11
,p_column_heading=>'Geburtsname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9758021917692275)
,p_query_column_id=>19
,p_column_alias=>'GEBURTSORT'
,p_column_display_sequence=>14
,p_column_heading=>'Geburtsort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9758476948692276)
,p_query_column_id=>20
,p_column_alias=>'GEBURTSLAND'
,p_column_display_sequence=>15
,p_column_heading=>'Geburtsland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9758813435692276)
,p_query_column_id=>21
,p_column_alias=>'STERBEORT'
,p_column_display_sequence=>17
,p_column_heading=>'Sterbeort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9759266141692276)
,p_query_column_id=>22
,p_column_alias=>'STERBELAND'
,p_column_display_sequence=>18
,p_column_heading=>'Sterbeland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10345378893396452)
,p_query_column_id=>23
,p_column_alias=>'ID'
,p_column_display_sequence=>25
,p_column_heading=>'Id'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10345642910396453)
,p_query_column_id=>24
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>20
,p_column_heading=>'Dateiname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10346065318396455)
,p_query_column_id=>25
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>9
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10346462183396456)
,p_query_column_id=>26
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>26
,p_column_heading=>'Bildgroesse'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10346812233396457)
,p_query_column_id=>27
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>27
,p_column_heading=>'Breite Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10347292053396459)
,p_query_column_id=>28
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>28
,p_column_heading=>'Hoehe Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10347647570396460)
,p_query_column_id=>29
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>29
,p_column_heading=>'Bild Aktion'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9779832239707434)
,p_plug_name=>'md_Eltern'
,p_region_name=>'md_Eltern'
,p_parent_plug_id=>wwv_flow_api.id(3389411781686166)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>200
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9978913137917642)
,p_name=>'Kinder'
,p_parent_plug_id=>wwv_flow_api.id(3389411781686166)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>310
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_report_attributes=>'style="background-color:#FFB6C1"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
' apex_item.checkbox2(2,E."PK_ELTERN") PK_Eltern,',
' E."PK_ELTERN" PK_ELTERN_DISPLAY,',
' P.TITEL,',
' E."FK_KIND",',
' :P121_PK_PERSON "FK_ELTERN",',
' E."CREATION_DATE",',
' E."CREATED_BY",',
' E."MODIFY_DATE",',
' E."MODIFIED_BY",',
' P.NAME,',
' P.VORNAME,',
' P.GESCHLECHT,',
' P.NR_AHNENTAFEL,',
' P.GEBOREN_AM,',
' P.GESTORBEN_AM,',
' P.BESCHREIBUNG,',
' P.RUFNAME,',
' P.GEBURTSNAME,',
' GO.ORT GEBURTSORT,',
' GOl.LAND GEBURTSLAND,',
' SO.ORT STERBEORT,',
' SOl.LAND STERBELAND',
',   bt.id',
',   bt.dateiname',
',   dbms_lob.getlength(bt.thumbnail) vorschau',
',   dbms_lob.getlength(bt.bild)      bildgroesse',
',   bt.breite_px',
',   bt.hoehe_px',
',   null as bild_aktion',
'from "#OWNER#"."ELTERN" E',
'  LEFT JOIN PERSON P ON P.PK_PERSON = E.FK_KIND',
'    LEFT JOIN ORT go ON go.PK_ORT = P.FK_geburtsort',
'  left join land gol on gol.pk_land = go.fk_land',
'  LEFT JOIN ORT SO ON SO.PK_ORT = P.FK_STERBEORT',
'  left join land sol on sol.pk_land = so.fk_land',
'  left join person_bild pb on pb.fk_person = p.pk_person',
'  left join bilder_tab bt on bt.id = pb.fk_bild    ',
'WHERE FK_ELTERN = :P121_PK_PERSON'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9979236942917646)
,p_query_column_id=>1
,p_column_alias=>'PK_ELTERN'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" onClick="$f_CheckFirstColumn(this)"/>'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'YES'
,p_pk_col_source_type=>'T'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9979652677917646)
,p_query_column_id=>2
,p_column_alias=>'PK_ELTERN_DISPLAY'
,p_column_display_sequence=>2
,p_column_heading=>'Pk Eltern Display'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9980079603917647)
,p_query_column_id=>3
,p_column_alias=>'TITEL'
,p_column_display_sequence=>3
,p_column_heading=>'Titel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9980852454917647)
,p_query_column_id=>4
,p_column_alias=>'FK_KIND'
,p_column_display_sequence=>5
,p_column_heading=>'Fk Kind'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9980420138917647)
,p_query_column_id=>5
,p_column_alias=>'FK_ELTERN'
,p_column_display_sequence=>4
,p_column_heading=>'Fk Eltern'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9981226962917647)
,p_query_column_id=>6
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>21
,p_column_heading=>'Erstelldatum'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9981600712917648)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>22
,p_column_heading=>'Erstellt von'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9982040775917648)
,p_query_column_id=>8
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>23
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9982496245917648)
,p_query_column_id=>9
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>24
,p_column_heading=>unistr('Ge\00E4ndert durch')
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9982865709917648)
,p_query_column_id=>10
,p_column_alias=>'NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b>#NAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9983214593917649)
,p_query_column_id=>11
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>7
,p_column_heading=>'Vorname'
,p_use_as_row_header=>'N'
,p_column_html_expression=>' <b>#VORNAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9983600434917649)
,p_query_column_id=>12
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>8
,p_column_heading=>'Geschlecht'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b><i>#GESCHLECHT#</i></b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9984093414917649)
,p_query_column_id=>13
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>10
,p_column_heading=>'<span title="Nr der Person in der Ahnentafel (Papierform)">Nr Ahnentafel</span>'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9987637191917651)
,p_query_column_id=>14
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>13
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9984470527917649)
,p_query_column_id=>15
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>16
,p_column_heading=>'Gestorben Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9984827317917650)
,p_query_column_id=>16
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>19
,p_column_heading=>'Beschreibung'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9985239761917650)
,p_query_column_id=>17
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>12
,p_column_heading=>'Rufname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9985602709917650)
,p_query_column_id=>18
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>11
,p_column_heading=>'Geburtsname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9986037191917650)
,p_query_column_id=>19
,p_column_alias=>'GEBURTSORT'
,p_column_display_sequence=>14
,p_column_heading=>'Geburtsort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9986475092917651)
,p_query_column_id=>20
,p_column_alias=>'GEBURTSLAND'
,p_column_display_sequence=>15
,p_column_heading=>'Geburtsland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9986842762917651)
,p_query_column_id=>21
,p_column_alias=>'STERBEORT'
,p_column_display_sequence=>17
,p_column_heading=>'Sterbeort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9987298225917651)
,p_query_column_id=>22
,p_column_alias=>'STERBELAND'
,p_column_display_sequence=>18
,p_column_heading=>'Sterbeland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10515595612536058)
,p_query_column_id=>23
,p_column_alias=>'ID'
,p_column_display_sequence=>25
,p_column_heading=>'Id'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10515888411536061)
,p_query_column_id=>24
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>20
,p_column_heading=>'Dateiname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10516214073536062)
,p_query_column_id=>25
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>9
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10516693328536063)
,p_query_column_id=>26
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>26
,p_column_heading=>'Bildgroesse'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10517066491536065)
,p_query_column_id=>27
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>27
,p_column_heading=>'Breite Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10517474121536066)
,p_query_column_id=>28
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>28
,p_column_heading=>'Hoehe Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10517889427536067)
,p_query_column_id=>29
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>29
,p_column_heading=>'Bild Aktion'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10016646063950139)
,p_plug_name=>'md_Kinder'
,p_region_name=>'md_Kinder'
,p_parent_plug_id=>wwv_flow_api.id(3389411781686166)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>320
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3389619746688458)
,p_plug_name=>'Geschwister'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(10610130923591300)
,p_name=>'Geschwister'
,p_parent_plug_id=>wwv_flow_api.id(3389619746688458)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>330
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_report_attributes=>'style="background-color:#ADD8E6"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
' apex_item.checkbox2(3, G."PK_GESCHWISTER") PK_GESCHWISTER,',
' G."PK_GESCHWISTER" PK_GESCHWISTER_DISPLAY,',
' P.TITEL,',
' G."FK_GESCHWISTER",',
' :P121_PK_PERSON "FK_PERSON",',
' G."CREATION_DATE",',
' G."CREATED_BY",',
' G."MODIFY_DATE",',
' G."MODIFIED_BY",',
' P.NAME,',
' P.VORNAME,',
' P.GESCHLECHT,',
' P.NR_AHNENTAFEL,',
' P.GEBOREN_AM,',
' P.GESTORBEN_AM,',
' TO_CHAR(SUBSTR(P.BESCHREIBUNG,1,2000)) BESCHREIBUNG,',
' P.RUFNAME,',
' P.GEBURTSNAME,',
' GO.ORT GEBURTSORT,',
' GOl.LAND GEBURTSLAND,',
' SO.ORT STERBEORT,',
' SOl.LAND SlTERBELAND',
',   bt.id',
',   bt.dateiname',
',   dbms_lob.getlength(bt.thumbnail) vorschau',
',   dbms_lob.getlength(bt.bild)      bildgroesse',
',   bt.breite_px',
',   bt.hoehe_px',
',   null as bild_aktion',
'from "GESCHWISTER" G',
'  LEFT JOIN PERSON P ON P.PK_PERSON = G.FK_GESCHWISTER',
'  LEFT JOIN ORT GO ON GO.PK_ORT = P.FK_GEBURTSORT',
'  left join land gol on gol.pk_land = go.fk_land',
'  LEFT JOIN ORT SO ON SO.PK_ORT = P.FK_STERBEORT',
'  left join land sol on sol.pk_land = so.fk_land',
'  left join person_bild pb on pb.fk_person = p.pk_person',
'  left join bilder_tab bt on bt.id = pb.fk_bild    ',
'WHERE g.FK_PERSON = :P121_PK_PERSON'))
,p_header=>'<div style="Overflow:auto;height:90%">'
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10631855121622146)
,p_query_column_id=>1
,p_column_alias=>'PK_GESCHWISTER'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" onClick="$f_CheckFirstColumn(this)"/>'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10632105048622153)
,p_query_column_id=>2
,p_column_alias=>'PK_GESCHWISTER_DISPLAY'
,p_column_display_sequence=>26
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10611232173591395)
,p_query_column_id=>3
,p_column_alias=>'TITEL'
,p_column_display_sequence=>2
,p_column_heading=>'Titel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10632519549622155)
,p_query_column_id=>4
,p_column_alias=>'FK_GESCHWISTER'
,p_column_display_sequence=>27
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10632938923622157)
,p_query_column_id=>5
,p_column_alias=>'FK_PERSON'
,p_column_display_sequence=>28
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10612498734591398)
,p_query_column_id=>6
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>17
,p_column_heading=>'Erstelldatum'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10612876393591399)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>18
,p_column_heading=>'Erstellt von'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10613237278591400)
,p_query_column_id=>8
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>19
,p_column_heading=>unistr('\00C4nderungsdatum')
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10613636045591402)
,p_query_column_id=>9
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>20
,p_column_heading=>unistr('Ge\00E4ndert durch')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10614097734591403)
,p_query_column_id=>10
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b>#NAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10614464412591404)
,p_query_column_id=>11
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>4
,p_column_heading=>'Vorname'
,p_use_as_row_header=>'N'
,p_column_html_expression=>' <b>#VORNAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10614868171591405)
,p_query_column_id=>12
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>5
,p_column_heading=>'Geschlecht'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b><i>#GESCHLECHT#</i></b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10615289912591406)
,p_query_column_id=>13
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>7
,p_column_heading=>'<span title="Nr der Person in der Ahnentafel (Papierform)">Nr Ahnentafel</span>'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10618831920591416)
,p_query_column_id=>14
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>10
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10615657781591408)
,p_query_column_id=>15
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>13
,p_column_heading=>'Gestorben Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10616080299591409)
,p_query_column_id=>16
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>15
,p_column_heading=>'Beschreibung'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10616499160591410)
,p_query_column_id=>17
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>9
,p_column_heading=>'Rufname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10616816258591411)
,p_query_column_id=>18
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>8
,p_column_heading=>'Geburtsname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10617214077591412)
,p_query_column_id=>19
,p_column_alias=>'GEBURTSORT'
,p_column_display_sequence=>11
,p_column_heading=>'Geburtsort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10617682671591413)
,p_query_column_id=>20
,p_column_alias=>'GEBURTSLAND'
,p_column_display_sequence=>12
,p_column_heading=>'Geburtsland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10618087579591414)
,p_query_column_id=>21
,p_column_alias=>'STERBEORT'
,p_column_display_sequence=>14
,p_column_heading=>'Sterbeort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(42955111007310447)
,p_query_column_id=>22
,p_column_alias=>'SLTERBELAND'
,p_column_display_sequence=>29
,p_column_heading=>'Slterbeland'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10619201755591418)
,p_query_column_id=>23
,p_column_alias=>'ID'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10619613305591419)
,p_query_column_id=>24
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>16
,p_column_heading=>'Dateiname'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10620045405591421)
,p_query_column_id=>25
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>6
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::::'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10620456085591422)
,p_query_column_id=>26
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10620834714591423)
,p_query_column_id=>27
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>23
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10621255354591424)
,p_query_column_id=>28
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>24
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10621688301591425)
,p_query_column_id=>29
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>25
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10678523054668158)
,p_plug_name=>'md_Geschwister'
,p_region_name=>'md_Geschwister'
,p_parent_plug_id=>wwv_flow_api.id(3389619746688458)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>340
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3389832559692140)
,p_plug_name=>'Familie'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8920115021495286)
,p_plug_name=>'Familien'
,p_parent_plug_id=>wwv_flow_api.id(3389832559692140)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>240
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select f.Familie',
', pf.Herkunft',
', pf.kommentar',
', pf.pk_person_familie',
', pf.fk_familie',
'from Person_Familie pf',
' join Familie f on f.pk_familie = pf.fk_familie',
'where pf.fK_person= :P121_PK_PERSON'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9260203009539307)
,p_plug_name=>'md_familien'
,p_region_name=>'md_Familien'
,p_parent_plug_id=>wwv_flow_api.id(3389832559692140)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>250
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3390006718694121)
,p_plug_name=>'Lebenspartner'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(10803211016131599)
,p_name=>'Lebenspartner'
,p_parent_plug_id=>wwv_flow_api.id(3390006718694121)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>350
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_report_attributes=>'style="background-color:#DCDCDC"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
' apex_item.checkbox2(4, lb.pk_lebenspartner) as lebenspartner_id	',
', case when p.pk_person is not null then p.pk_person else plb.pk_person end as leb',
', nvl(p.pk_person, plb.pk_person) as pk_person',
', nvl(p.NAME, plb.name) as name',
', nvl(p.VORNAME, plb.vorname) as vorname',
', nvl(p.GESCHLECHT, plb.geschlecht) as geschlecht',
', nvl(p.GEBOREN_AM, plb.geboren_am) as geboren_am',
', nvl(p.GESTORBEN_AM, plb.gestorben_am) as gestorben_am',
', nvl(p.GEBURTSNAME, plb.geburtsname) as geburtsname',
', nvl(p.TITEL, plb.titel) as titel',
', nvl(p.ADELSTITEL, plb.adelstitel) as adelstitel',
', nvl(p.RUFNAME, plb.rufname) as rufname',
', nvl(p.NR_AHNENTAFEL, plb.nr_ahnentafel) as nr_ahnentafel',
', lb.status',
', lb.datum_standesamtlich',
', lb.standesamt',
', lb.datum_kirchlich',
', lb.kirche',
', lb.KOMMENTAR',
', lb.fk_ort',
', o.ort',
', ol.land',
', nvl(pgo.ort, plbgo.ort) geburtsort',
', nvl(pso.ort, plbso.ort) sterbeort',
', nvl(pgol.land, plbgol.land) geburtsland',
', nvl(psol.land, plbsol.land) sterbeland',
', nvl(bt.id, btplb.id) id',
', nvl(bt.dateiname, btplb.dateiname) dateiname',
', nvl(dbms_lob.getlength(bt.thumbnail),  dbms_lob.getlength( btplb.thumbnail)) vorschau',
', nvl(dbms_lob.getlength(bt.bild), dbms_lob.getlength( btplb.bild))      bildgroesse',
', nvl(bt.breite_px, btplb.breite_px) breite_px',
', nvl(bt.hoehe_px,  btplb.hoehe_px)  hoehe_px',
'from Lebenspartner lb',
' left join (select * from Person where pk_person <> :P121_PK_PERSON)  p on lb.fk_person = p.pk_person',
' left join (select * from Person where pk_person <> :P121_PK_PERSON) plb on lb.fk_lebenspartner = plb.pk_person',
' left join ort o on lb.fk_ort = o.pk_ort ',
'  left join land ol on ol.pk_land = o.fk_land',
' left join ort pgo on pgo.pk_ort = p.fk_geburtsort',
' left join ort pso on pso.pk_ort = p.fk_sterbeort',
' left join ort plbgo on plbgo.pk_ort = plb.fk_geburtsort',
'   left join land pgol on pgol.pk_land = pgo.fk_land',
'     left join land plbgol on plbgol.pk_land = plbgo.fk_land',
'',
' left join ort plbso on plbso.pk_ort = plb.fk_sterbeort',
'    left join land plbsol on plbsol.pk_land = plbso.fk_land',
'   left join land psol on psol.pk_land = pso.fk_land',
' left join person_bild pb on pb.fk_person = p.pk_person',
' left join bilder_tab bt on bt.id = pb.fk_bild ',
' left join person_bild pbplb on pbplb.fk_person = plb.pk_person',
' left join bilder_tab btplb on btplb.id = pbplb.fk_bild ',
'where (lb.fk_lebenspartner = :P121_PK_PERSON',
' or lb.fk_person =:P121_PK_PERSON)'))
,p_header=>'<div style="Overflow:auto;height:90%">'
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10830170220216199)
,p_query_column_id=>1
,p_column_alias=>'LEBENSPARTNER_ID'
,p_column_display_sequence=>1
,p_column_heading=>'<input type="checkbox" onClick="$f_CheckFirstColumn(this)"/>'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10830492623216212)
,p_query_column_id=>2
,p_column_alias=>'LEB'
,p_column_display_sequence=>30
,p_column_heading=>'Leb'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10830863410216214)
,p_query_column_id=>3
,p_column_alias=>'PK_PERSON'
,p_column_display_sequence=>2
,p_column_heading=>'PK_PERSON'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10805458969131642)
,p_query_column_id=>4
,p_column_alias=>'NAME'
,p_column_display_sequence=>4
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b>#NAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10805815357131643)
,p_query_column_id=>5
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>5
,p_column_heading=>'Vorname'
,p_use_as_row_header=>'N'
,p_column_html_expression=>' <b>#VORNAME#</b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10806255528131644)
,p_query_column_id=>6
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>6
,p_column_heading=>'Geschlecht'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b><i>#GESCHLECHT#</i></b>'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10810215953131658)
,p_query_column_id=>7
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>11
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10807025659131648)
,p_query_column_id=>8
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>14
,p_column_heading=>'Gestorben Am'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10808249069131651)
,p_query_column_id=>9
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>9
,p_column_heading=>'Geburtsname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10803570646131633)
,p_query_column_id=>10
,p_column_alias=>'TITEL'
,p_column_display_sequence=>3
,p_column_heading=>'Titel'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10831217992216215)
,p_query_column_id=>11
,p_column_alias=>'ADELSTITEL'
,p_column_display_sequence=>31
,p_column_heading=>'Adelstitel'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10807899450131650)
,p_query_column_id=>12
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>10
,p_column_heading=>'Rufname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10806619264131646)
,p_query_column_id=>13
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>8
,p_column_heading=>'<span title="Nr der Person in der Ahnentafel (Papierform)">Nr Ahnentafel</span>'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10831664303216217)
,p_query_column_id=>14
,p_column_alias=>'STATUS'
,p_column_display_sequence=>19
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<b>#STATUS#</b>'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10832080418216219)
,p_query_column_id=>15
,p_column_alias=>'DATUM_STANDESAMTLICH'
,p_column_display_sequence=>18
,p_column_heading=>'Datum Standesamtlich'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10832487103216221)
,p_query_column_id=>16
,p_column_alias=>'STANDESAMT'
,p_column_display_sequence=>20
,p_column_heading=>'Standesamt'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10832860191216222)
,p_query_column_id=>17
,p_column_alias=>'DATUM_KIRCHLICH'
,p_column_display_sequence=>21
,p_column_heading=>'Datum Kirchlich'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10833201868216224)
,p_query_column_id=>18
,p_column_alias=>'KIRCHE'
,p_column_display_sequence=>22
,p_column_heading=>'Kirche'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10833634742216226)
,p_query_column_id=>19
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>23
,p_column_heading=>'Kommentar'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10834016624216227)
,p_query_column_id=>20
,p_column_alias=>'FK_ORT'
,p_column_display_sequence=>32
,p_column_heading=>'Fk Ort'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10834442760216229)
,p_query_column_id=>21
,p_column_alias=>'ORT'
,p_column_display_sequence=>24
,p_column_heading=>'Ort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10834880435216231)
,p_query_column_id=>22
,p_column_alias=>'LAND'
,p_column_display_sequence=>25
,p_column_heading=>'Land'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10808643331131652)
,p_query_column_id=>23
,p_column_alias=>'GEBURTSORT'
,p_column_display_sequence=>12
,p_column_heading=>'Geburtsort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10809434518131655)
,p_query_column_id=>24
,p_column_alias=>'STERBEORT'
,p_column_display_sequence=>15
,p_column_heading=>'Sterbeort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10809024697131654)
,p_query_column_id=>25
,p_column_alias=>'GEBURTSLAND'
,p_column_display_sequence=>13
,p_column_heading=>'Geburtsland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10809881831131656)
,p_query_column_id=>26
,p_column_alias=>'STERBELAND'
,p_column_display_sequence=>16
,p_column_heading=>'Sterbeland'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10810659742131659)
,p_query_column_id=>27
,p_column_alias=>'ID'
,p_column_display_sequence=>26
,p_column_heading=>'Id'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10811084331131660)
,p_query_column_id=>28
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>17
,p_column_heading=>'Dateiname'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10811415015131662)
,p_query_column_id=>29
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>7
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10811875880131663)
,p_query_column_id=>30
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>27
,p_column_heading=>'Bildgroesse'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10812246203131665)
,p_query_column_id=>31
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>28
,p_column_heading=>'Breite Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10812630139131666)
,p_query_column_id=>32
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>29
,p_column_heading=>'Hoehe Px'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11060531260357096)
,p_plug_name=>'md_Lebenspartner'
,p_region_name=>'md_Lebenspartner'
,p_parent_plug_id=>wwv_flow_api.id(3390006718694121)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>360
,p_plug_display_point=>'BODY'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3390513990696258)
,p_plug_name=>'Beruf'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9493716810775912)
,p_name=>'Beruf'
,p_parent_plug_id=>wwv_flow_api.id(3390513990696258)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>260
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_TABFORM'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_PERSON_BERUF',
', BERUF',
', FK_PERSON',
', KOMMENTAR',
', REIHENFOLGE',
', VON',
', BIS',
', CREATION_DATE',
', CREATED_BY',
', MODIFY_DATE',
', MODIFIED_BY',
'from person_beruf',
'where fK_person= :P121_PK_PERSON'))
,p_display_condition_type=>'NEVER'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'(null)'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9494884555775916)
,p_query_column_id=>1
,p_column_alias=>'CHECK$01'
,p_column_display_sequence=>1
,p_column_heading=>'Select Row'
,p_display_as=>'CHECKBOX'
,p_derived_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9502366024781465)
,p_query_column_id=>2
,p_column_alias=>'PK_PERSON_BERUF'
,p_column_display_sequence=>2
,p_column_heading=>'Pk Person Beruf'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9502737878781465)
,p_query_column_id=>3
,p_column_alias=>'BERUF'
,p_column_display_sequence=>4
,p_column_heading=>'Beruf'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT'
,p_lov_show_nulls=>'YES'
,p_column_height=>3
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9503108286781466)
,p_query_column_id=>4
,p_column_alias=>'FK_PERSON'
,p_column_display_sequence=>3
,p_column_heading=>'Fk Person'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9495212421775917)
,p_query_column_id=>5
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>8
,p_column_heading=>'Kommentar'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXTAREA'
,p_lov_show_nulls=>'YES'
,p_column_height=>3
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9503571932781466)
,p_query_column_id=>6
,p_column_alias=>'REIHENFOLGE'
,p_column_display_sequence=>5
,p_column_heading=>'Reihenfolge'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9503927197781466)
,p_query_column_id=>7
,p_column_alias=>'VON'
,p_column_display_sequence=>6
,p_column_heading=>'Von'
,p_use_as_row_header=>'N'
,p_display_as=>'PICK_DATE_DD_MM_YYYY_HH24_MI_DOT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9504317121781467)
,p_query_column_id=>8
,p_column_alias=>'BIS'
,p_column_display_sequence=>7
,p_column_heading=>'Bis'
,p_use_as_row_header=>'N'
,p_display_as=>'PICK_DATE_DD_MM_YYYY_HH24_MI_DOT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9504717829781467)
,p_query_column_id=>9
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>9
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9505113299781467)
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9505547446781467)
,p_query_column_id=>11
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>11
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9505998276781468)
,p_query_column_id=>12
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Modified By'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9700870029054901)
,p_name=>'md_Berufe'
,p_region_name=>'md_Beruf'
,p_parent_plug_id=>wwv_flow_api.id(3390513990696258)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>290
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="display:none"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT BERUF',
'FROM PERSON_BERUF',
'GROUP BY BERUF'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9701448290054916)
,p_query_column_id=>1
,p_column_alias=>'BERUF'
,p_column_display_sequence=>1
,p_column_heading=>'Beruf'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3390719877697906)
,p_plug_name=>'Religion'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>110
,p_plug_display_point=>'BODY'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9652136957984620)
,p_name=>'Religion'
,p_parent_plug_id=>wwv_flow_api.id(3390719877697906)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>280
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_TABFORM'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_PERSON_religion',
', religion',
', FK_PERSON',
', ausgetreten_am',
', status',
', CREATION_DATE',
', CREATED_BY',
', MODIFY_DATE',
', MODIFIED_BY',
'from person_religion',
'where fK_person= :P121_PK_PERSON'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'(null)'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_LEFT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9652409644984621)
,p_query_column_id=>1
,p_column_alias=>'CHECK$01'
,p_column_display_sequence=>1
,p_column_heading=>'Select Row'
,p_display_as=>'CHECKBOX'
,p_derived_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9661495745002964)
,p_query_column_id=>2
,p_column_alias=>'PK_PERSON_RELIGION'
,p_column_display_sequence=>10
,p_column_heading=>'Pk Person Religion'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9661814141002965)
,p_query_column_id=>3
,p_column_alias=>'RELIGION'
,p_column_display_sequence=>2
,p_column_heading=>'Religion'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9653299579984622)
,p_query_column_id=>4
,p_column_alias=>'FK_PERSON'
,p_column_display_sequence=>5
,p_column_heading=>'Fk Person'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9662292020002965)
,p_query_column_id=>5
,p_column_alias=>'AUSGETRETEN_AM'
,p_column_display_sequence=>4
,p_column_heading=>'Ausgetreten Am'
,p_use_as_row_header=>'N'
,p_display_as=>'PICK_DATE_DD_MM_YYYY_HH24_MI_DOT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9662617357002965)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>3
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT'
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9654898067984623)
,p_query_column_id=>7
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>6
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9655229036984624)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9655688133984624)
,p_query_column_id=>9
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>8
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9656064135984624)
,p_query_column_id=>10
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Modified By'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9720292396487518)
,p_name=>'Liste der Religionen'
,p_parent_plug_id=>wwv_flow_api.id(3390719877697906)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>300
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select religion',
'from person_religion',
'group by religion'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9720760030487537)
,p_query_column_id=>1
,p_column_alias=>'RELIGION'
,p_column_display_sequence=>1
,p_column_heading=>'Liste der Religionen'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3414615326408835)
,p_plug_name=>'Wohnort'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7180439374613765)
,p_plug_name=>'md_Orte'
,p_region_name=>'md_Orte'
,p_parent_plug_id=>wwv_flow_api.id(3414615326408835)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>190
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9616531328906882)
,p_name=>'Wohnorte'
,p_parent_plug_id=>wwv_flow_api.id(3414615326408835)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>270
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_TABFORM'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_PERSON_WOHNORT',
', FK_WOHNORT',
', FK_PERSON',
', KOMMENTAR',
', REIHENFOLGE',
', VON',
', BIS',
', CREATION_DATE',
', CREATED_BY',
', MODIFY_DATE',
', MODIFIED_BY',
'from person_wohnort',
'where fK_person= :P121_PK_PERSON'))
,p_display_condition_type=>'NEVER'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'(null)'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9616870485906890)
,p_query_column_id=>1
,p_column_alias=>'CHECK$01'
,p_column_display_sequence=>1
,p_column_heading=>'Select Row'
,p_display_as=>'CHECKBOX'
,p_derived_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9629347502917089)
,p_query_column_id=>2
,p_column_alias=>'PK_PERSON_WOHNORT'
,p_column_display_sequence=>11
,p_column_heading=>'Pk Person Wohnort'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9629765906917089)
,p_query_column_id=>3
,p_column_alias=>'FK_WOHNORT'
,p_column_display_sequence=>12
,p_column_heading=>'Fk Wohnort'
,p_use_as_row_header=>'N'
,p_display_as=>'POPUPKEY_QUERY'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' '' Land',
', pk_ort',
'from ort',
'order by ort, land'))
,p_lov_show_nulls=>'YES'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9618492734906891)
,p_query_column_id=>4
,p_column_alias=>'FK_PERSON'
,p_column_display_sequence=>2
,p_column_heading=>'Fk Person'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9617213995906890)
,p_query_column_id=>5
,p_column_alias=>'KOMMENTAR'
,p_column_display_sequence=>8
,p_column_heading=>'Kommentar'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXTAREA'
,p_lov_show_nulls=>'YES'
,p_column_height=>3
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9618813803906892)
,p_query_column_id=>6
,p_column_alias=>'REIHENFOLGE'
,p_column_display_sequence=>3
,p_column_heading=>'Reihenfolge'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9619266479906892)
,p_query_column_id=>7
,p_column_alias=>'VON'
,p_column_display_sequence=>4
,p_column_heading=>'Von'
,p_use_as_row_header=>'N'
,p_display_as=>'PICK_DATE_DD_MM_YYYY_HH24_MI_DOT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9619621766906892)
,p_query_column_id=>8
,p_column_alias=>'BIS'
,p_column_display_sequence=>5
,p_column_heading=>'Bis'
,p_use_as_row_header=>'N'
,p_display_as=>'PICK_DATE_DD_MM_YYYY_HH24_MI_DOT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9620040026906892)
,p_query_column_id=>9
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>6
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9620449861906893)
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9620852585906893)
,p_query_column_id=>11
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>9
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD.MM.YYY HH24:MI:SS'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(9621207566906893)
,p_query_column_id=>12
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Modified By'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3460301264940695)
,p_name=>'stammbaum'
,p_parent_plug_id=>wwv_flow_api.id(3382908599505471)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>180
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select * from table(get_tree.f_get_stamm(:P121_PK_PERSON)) ;'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3460621464940698)
,p_query_column_id=>1
,p_column_alias=>'PERS'
,p_column_display_sequence=>1
,p_column_heading=>'PERS'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3460801315940698)
,p_query_column_id=>2
,p_column_alias=>'LEV'
,p_column_display_sequence=>2
,p_column_heading=>'LEV'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3461724011392064)
,p_query_column_id=>3
,p_column_alias=>'STAMM'
,p_column_display_sequence=>3
,p_column_heading=>'Stamm'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8931684698495379)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8920115021495286)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9496490829775918)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9493716810775912)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9621672105906894)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9616531328906882)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9657608218984627)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9652136957984620)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8931232058495378)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8920115021495286)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9497622791775919)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(9493716810775912)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9622870101906895)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(9616531328906882)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9658415989984627)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(9652136957984620)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9795434751769934)
,p_button_sequence=>310
,p_button_plug_id=>wwv_flow_api.id(9779832239707434)
,p_button_name=>'P121_ADD_ELTERNTEIL'
,p_button_static_id=>'P121_BTN_ADD_ELTERNTEIL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('Hinzf\00FCgen')
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10016935098950139)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(10016646063950139)
,p_button_name=>'P121_ADD_KINDER'
,p_button_static_id=>'P121_BTN_ADD_KINDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('Hinzf\00FCgen')
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10678888803668172)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(10678523054668158)
,p_button_name=>'P121_ADD_GESCHWISTER'
,p_button_static_id=>'P121_BTN_ADD_GESCHWISTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('Hinzf\00FCgen')
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11060841460357122)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(11060531260357096)
,p_button_name=>'P121_ADD_LEBENSPARTNER'
,p_button_static_id=>'P121_BTN_ADD_LEBENSPARTNER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('Hinzf\00FCgen')
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8932418736495380)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8920115021495286)
,p_button_name=>'ADD_Familien'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9497285237775919)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(9493716810775912)
,p_button_name=>'ADD_Beruf'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9622406052906895)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(9616531328906882)
,p_button_name=>'ADD_Wohnorte'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9658043626984627)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(9652136957984620)
,p_button_name=>'ADD_Religion'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8932096363495380)
,p_button_sequence=>45
,p_button_plug_id=>wwv_flow_api.id(8920115021495286)
,p_button_name=>'MULTI_ROW_DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''MULTI_ROW_DELETE'');'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9496867992775918)
,p_button_sequence=>45
,p_button_plug_id=>wwv_flow_api.id(9493716810775912)
,p_button_name=>'MULTI_ROW_DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''MULTI_ROW_DELETE'');'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9622055932906895)
,p_button_sequence=>45
,p_button_plug_id=>wwv_flow_api.id(9616531328906882)
,p_button_name=>'MULTI_ROW_DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''MULTI_ROW_DELETE'');'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9657276972984626)
,p_button_sequence=>45
,p_button_plug_id=>wwv_flow_api.id(9652136957984620)
,p_button_name=>'MULTI_ROW_DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''MULTI_ROW_DELETE'');'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9796529935781803)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(9750260067692245)
,p_button_name=>'ADD_ELTERN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9988013842917652)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(9978913137917642)
,p_button_name=>'ADD_KINDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10622029555591428)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(10610130923591300)
,p_button_name=>'ADD_GESCHWISTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10815085602131675)
,p_button_sequence=>320
,p_button_plug_id=>wwv_flow_api.id(10803211016131599)
,p_button_name=>'ADD_LEBENSPARTNER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'+'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9820640397293526)
,p_button_sequence=>330
,p_button_plug_id=>wwv_flow_api.id(9750260067692245)
,p_button_name=>'REMOVE_ELTERN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9988425335917653)
,p_button_sequence=>330
,p_button_plug_id=>wwv_flow_api.id(9978913137917642)
,p_button_name=>'REMOVE_KINDER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10622431967591432)
,p_button_sequence=>330
,p_button_plug_id=>wwv_flow_api.id(10610130923591300)
,p_button_name=>'REMOVE_GESCHWISTER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10815459143131680)
,p_button_sequence=>330
,p_button_plug_id=>wwv_flow_api.id(10803211016131599)
,p_button_name=>'REMOVE_LEBENSPARTNER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'-'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7180718918613915)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7180439374613765)
,p_button_name=>'SAVE_ORTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Speichern'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7181089512613925)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7180439374613765)
,p_button_name=>'CANCEL_ORTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7181465329613926)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7180439374613765)
,p_button_name=>'DELETE_ORTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P121_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3463901030498829)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3382908599505471)
,p_button_name=>'STAMMBAUM'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Stammbaum'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:popUp2(''f?p=&APP_ID.:122:&SESSION.:::RP:'',1300,1300);'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6730180630554588)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3382908599505471)
,p_button_name=>'SAVE_PERS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Speichern'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6740184764557486)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3382908599505471)
,p_button_name=>'DELETE_PERS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7200309794717901)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(3414615326408835)
,p_button_name=>'ORTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Orte'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7230902724004835)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(3389832559692140)
,p_button_name=>'FAMILIEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Familien'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9320127935483398)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(9260203009539307)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9330130803491932)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(9260203009539307)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Speichern'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9340158084500129)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(9260203009539307)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9702604222070200)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(3390513990696258)
,p_button_name=>'LIST_BERUFE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6952734765855729)
,p_button_image_alt=>'Liste der Berufe'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3383227197508577)
,p_name=>'P121_PK_PERSON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'ID:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(3299619060618260)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3383417276513177)
,p_name=>'P121_NR_AHNENTAFEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'Nr Ahnentafel:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3383708650517131)
,p_name=>'P121_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'Name:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_tag_attributes=>'style="font-weight:bold;"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3383904337519163)
,p_name=>'P121_VORNAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'Vorname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_tag_attributes=>'style="font-weight:bold;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3384115107529367)
,p_name=>'P121_GESCHLECHT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'Geschlecht:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT ''m\00E4nnlich'' as d, ''m\00E4nnlich'' as r from dual'),
'Union',
'SELECT ''weiblich'', ''weiblich'' from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="font-weight:bold;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3391000510718407)
,p_name=>'P121_TITEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Titel:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3391229180720329)
,p_name=>'P121_ADELSTITEL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Adelstitel:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3391422926723236)
,p_name=>'P121_NAME_1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Name:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3391618181725400)
,p_name=>'P121_VORNAME_1'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Vorname:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3391813437727629)
,p_name=>'P121_RUFNAME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Rufname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3392007183730569)
,p_name=>'P121_GESCHLECHT_1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Geschlecht:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT ''m\00E4nnlich'' as d, ''m\00E4nnlich'' as r from dual'),
'Union',
'SELECT ''weiblich'', ''weiblich'' from dual'))
,p_tag_attributes=>'style="width:196px"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3392321835738965)
,p_name=>'P121_GEBOREN_AM'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'geboren am:'
,p_format_mask=>'DD.MM:YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3392515797741785)
,p_name=>'P121_GESTORBEN_AM'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'gestorben am:'
,p_format_mask=>'DD.MM:YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3392709758744565)
,p_name=>'P121_GEBURTSNAME'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Geburtsname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3392900269748989)
,p_name=>'P121_KOMMENTAR'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'Kommentar:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>154
,p_cMaxlength=>4000
,p_cHeight=>5
,p_colspan=>8
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3412109458344789)
,p_name=>'P121_GEBOREN_IN'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'gestorben in:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ( '' || land || '')'', pk_ort',
'from ort o',
' left join land l on l.pk_land = o.fk_land'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3412830796350093)
,p_name=>'P121_GESTORBEN_IN'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(3389203816683899)
,p_prompt=>'gestorben In:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ( '' || land || '')'', pk_ort',
'from ort o',
' left join land l on l.pk_land = o.fk_land'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6060290814899893)
,p_name=>'P121_BILD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(3382908599505471)
,p_prompt=>'Bild'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT THUMBNAIL FROM BILDER_TAB BT INNER JOIN PERSON_BILD  PB ON BT.ID = PB.FK_BILD',
'WHERE FK_PERSON = :P121_PK_PERSON'))
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7181818732613934)
,p_name=>'P121_PK_ORT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7180439374613765)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7182253686613953)
,p_name=>'P121_ORT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7180439374613765)
,p_prompt=>'Ort'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1020
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7182605635613955)
,p_name=>'P121_LAND'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7180439374613765)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1020
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9290857003563983)
,p_name=>'P121_PK_FAMILIE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(9260203009539307)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9291136905569231)
,p_name=>'P121_FAMIILIE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(9260203009539307)
,p_prompt=>'Famiilie:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9780464370719360)
,p_name=>'P121_ELTERN'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(9779832239707434)
,p_prompt=>'Eltern'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NAME || '', '' || VORNAME || '' ('' || GESCHLECHT || '') - '' || NR_AHNENTAFEL as d ',
', PK_PERSON as r',
'FROM PERSON',
'ORDER BY NAME, VORNAME'))
,p_cHeight=>25
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'MOVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10017480896963664)
,p_name=>'P121_KINDER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(10016646063950139)
,p_prompt=>'Kinder'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NAME || '', '' || VORNAME || '' ('' || GESCHLECHT || '') - '' || NR_AHNENTAFEL as d ',
', PK_PERSON as r',
'FROM PERSON',
'ORDER BY NAME, VORNAME'))
,p_cHeight=>25
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'MOVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10679581396740454)
,p_name=>'P121_GESCHWISTER'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_api.id(10678523054668158)
,p_prompt=>'Geschwister:'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NAME || '', '' || VORNAME || '' ('' || GESCHLECHT || '') - '' || NR_AHNENTAFEL as d ',
', PK_PERSON as r',
'FROM PERSON',
'ORDER BY NAME, VORNAME'))
,p_cHeight=>25
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'MOVE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11067251494527427)
,p_name=>'P121_LEBENSPARTNER'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Lebenspartner'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NAME || '', '' || VORNAME || '' ('' || GESCHLECHT || '') - '' || NR_AHNENTAFEL as d ',
', PK_PERSON as r',
'FROM PERSON',
'ORDER BY NAME, VORNAME'))
,p_cHeight=>10
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11067538393536375)
,p_name=>'P121_STATUS'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Status:'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Status',
'from Lebenspartner',
'Group by status'))
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11067895193545163)
,p_name=>'P121_DATUM_STANDESAMTLICH'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'standesamtlich am:'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11068103228549483)
,p_name=>'P121_STANDESAMT'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Standesamt:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11068481829555525)
,p_name=>'P121_DATUM_KIRCHLICH'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'kirchlich am:'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11068728428560100)
,p_name=>'P121_KIRCHE'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Kirche:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11069047043584378)
,p_name=>'P121_FK_ORT'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Ort:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ( '' || land || '')'', pk_ort',
'from ort o',
' left join land l on l.pk_land = o.fk_land',
'order by ort, land'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11069329942590955)
,p_name=>'P121_KOMM'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(11060531260357096)
,p_prompt=>'Kommentar:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(42955407038310450)
,p_name=>'P7_FAMILIE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8920115021495286)
,p_item_source_plug_id=>wwv_flow_api.id(8920115021495286)
,p_prompt=>'Familie'
,p_source=>'FAMILIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43459943055533201)
,p_name=>'P7_HERKUNFT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8920115021495286)
,p_item_source_plug_id=>wwv_flow_api.id(8920115021495286)
,p_prompt=>'Herkunft'
,p_source=>'HERKUNFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43460020182533202)
,p_name=>'P7_KOMMENTAR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8920115021495286)
,p_item_source_plug_id=>wwv_flow_api.id(8920115021495286)
,p_prompt=>'Kommentar'
,p_source=>'KOMMENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43460150387533203)
,p_name=>'P7_PK_PERSON_FAMILIE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(8920115021495286)
,p_item_source_plug_id=>wwv_flow_api.id(8920115021495286)
,p_prompt=>'Pk Person Familie'
,p_source=>'PK_PERSON_FAMILIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43460259573533204)
,p_name=>'P7_FK_FAMILIE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(8920115021495286)
,p_item_source_plug_id=>wwv_flow_api.id(8920115021495286)
,p_prompt=>'Fk Familie'
,p_source=>'FK_FAMILIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9498163803775920)
,p_tabular_form_region_id=>wwv_flow_api.id(9493716810775912)
,p_validation_name=>'FK_ELTERN must be numeric'
,p_validation_sequence=>30
,p_validation=>'FK_ELTERN'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9497622791775919)
,p_associated_column=>'FK_ELTERN'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9623300504906896)
,p_tabular_form_region_id=>wwv_flow_api.id(9616531328906882)
,p_validation_name=>'FK_ELTERN must be numeric'
,p_validation_sequence=>30
,p_validation=>'FK_ELTERN'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9622870101906895)
,p_associated_column=>'FK_ELTERN'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9660156985984629)
,p_tabular_form_region_id=>wwv_flow_api.id(9652136957984620)
,p_validation_name=>'FK_ELTERN must be numeric'
,p_validation_sequence=>30
,p_validation=>'FK_ELTERN'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9658415989984627)
,p_associated_column=>'FK_ELTERN'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9498519383775920)
,p_tabular_form_region_id=>wwv_flow_api.id(9493716810775912)
,p_validation_name=>'FK_KIND must be numeric'
,p_validation_sequence=>40
,p_validation=>'FK_KIND'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9497622791775919)
,p_associated_column=>'FK_KIND'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9623764521906896)
,p_tabular_form_region_id=>wwv_flow_api.id(9616531328906882)
,p_validation_name=>'FK_KIND must be numeric'
,p_validation_sequence=>40
,p_validation=>'FK_KIND'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9622870101906895)
,p_associated_column=>'FK_KIND'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9658927461984628)
,p_tabular_form_region_id=>wwv_flow_api.id(9652136957984620)
,p_validation_name=>'FK_KIND must be numeric'
,p_validation_sequence=>40
,p_validation=>'FK_KIND'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_api.id(9658415989984627)
,p_associated_column=>'FK_KIND'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9498954169775920)
,p_tabular_form_region_id=>wwv_flow_api.id(9493716810775912)
,p_validation_name=>'CREATION_DATE must be a valid date'
,p_validation_sequence=>50
,p_validation=>'CREATION_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9497622791775919)
,p_associated_column=>'CREATION_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9624196129906896)
,p_tabular_form_region_id=>wwv_flow_api.id(9616531328906882)
,p_validation_name=>'CREATION_DATE must be a valid date'
,p_validation_sequence=>50
,p_validation=>'CREATION_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9622870101906895)
,p_associated_column=>'CREATION_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9659342035984628)
,p_tabular_form_region_id=>wwv_flow_api.id(9652136957984620)
,p_validation_name=>'CREATION_DATE must be a valid date'
,p_validation_sequence=>50
,p_validation=>'CREATION_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9658415989984627)
,p_associated_column=>'CREATION_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9499376808775920)
,p_tabular_form_region_id=>wwv_flow_api.id(9493716810775912)
,p_validation_name=>'MODIFY_DATE must be a valid date'
,p_validation_sequence=>70
,p_validation=>'MODIFY_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9497622791775919)
,p_associated_column=>'MODIFY_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9624599836906897)
,p_tabular_form_region_id=>wwv_flow_api.id(9616531328906882)
,p_validation_name=>'MODIFY_DATE must be a valid date'
,p_validation_sequence=>70
,p_validation=>'MODIFY_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9622870101906895)
,p_associated_column=>'MODIFY_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(9659774035984628)
,p_tabular_form_region_id=>wwv_flow_api.id(9652136957984620)
,p_validation_name=>'MODIFY_DATE must be a valid date'
,p_validation_sequence=>70
,p_validation=>'MODIFY_DATE'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_api.id(9658415989984627)
,p_associated_column=>'MODIFY_DATE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6770119911591496)
,p_name=>'daSavePerson'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6730180630554588)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6770555388591541)
,p_event_id=>wwv_flow_api.id(6770119911591496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_ADELSTITEL,P121_BILD,P121_GEBOREN_AM,P121_GEBOREN_IN,P121_GEBURTSNAME,P121_GESCHLECHT,P121_GESCHLECHT_1,P121_GESTORBEN_AM,P121_GESTORBEN_IN,P121_KOMMENTAR,P121_NAME,P121_NAME_1,P121_NR_AHNENTAFEL,P121_PK_PERSON,P121_RUFNAME,P121_VORNAME,P121_TIT'
||'EL'
,p_attribute_03=>'P121_ADELSTITEL,P121_BILD,P121_GEBOREN_AM,P121_GEBOREN_IN,P121_GEBURTSNAME,P121_GESCHLECHT,P121_GESCHLECHT_1,P121_GESTORBEN_AM,P121_GESTORBEN_IN,P121_KOMMENTAR,P121_NAME,P121_NAME_1,P121_NR_AHNENTAFEL,P121_PK_PERSON,P121_RUFNAME,P121_VORNAME,P121_TIT'
||'EL'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6790278963673377)
,p_event_id=>wwv_flow_api.id(6770119911591496)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'   if :P121_PK_PERSON is null then',
'            :P121_PK_PERSON := seq_pk_person.nextval;',
'    end if;',
'  ',
'  edit_data.p_per_set_person   (',
'                                  :P121_PK_PERSON,',
'                                  :P121_NAME,',
'                                  :P121_VORNAME,',
'                                  :P121_GEBURTSNAME,',
'                                  :P121_RUFNAME,',
'                                  :P121_GESCHLECHT,',
'                                  :P121_GEBOREN_AM,',
'                                  :P121_GESTORBEN_AM,',
'                                  :P121_GEBOREN_IN,',
'                                  :P121_GESTORBEN_IN,',
'                                  :P121_KOMMENTAR,',
'                                  :P121_TITEL,',
'                                  :P121_ADELSTITEL,',
'                                  :P121_NR_AHNENTAFEL,',
'                                  v(''APP_USER'')',
'                              );',
'',
'',
'',
'',
'end;'))
,p_attribute_02=>'P121_PK_PERSON'
,p_attribute_03=>'P121_PK_PERSON'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6800234928675269)
,p_event_id=>wwv_flow_api.id(6770119911591496)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7001793510045939)
,p_event_id=>wwv_flow_api.id(6770119911591496)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.opener.parent.location.reload(true);',
''))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6820180541697270)
,p_name=>'daDeletePerson'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6740184764557486)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6850231152697386)
,p_event_id=>wwv_flow_api.id(6820180541697270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_PK_PERSON'
,p_attribute_03=>'P121_PK_PERSON'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6870270622710431)
,p_event_id=>wwv_flow_api.id(6820180541697270)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  edit_data.p_per_del_person(:P121_PK_PERSON);',
'',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6880218713711815)
,p_event_id=>wwv_flow_api.id(6820180541697270)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7001066359042619)
,p_event_id=>wwv_flow_api.id(6820180541697270)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.opener.parent.location.reload(true);',
'window.close();'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7200894311725374)
,p_name=>'daShowOrte'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7200309794717901)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7201215193725396)
,p_event_id=>wwv_flow_api.id(7200894311725374)
,p_event_result=>'TRUE'
,p_action_sequence=>1
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P121_PK_ORT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7201784371725397)
,p_event_id=>wwv_flow_api.id(7200894311725374)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(3414615326408835)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7202271241725398)
,p_event_id=>wwv_flow_api.id(7200894311725374)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initDialog(''md_Orte'',''Orte'',700,200);',
'showDialog(''md_Orte'');'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7202605164728618)
,p_name=>'daSaveOrt'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7180718918613915)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7203004720728635)
,p_event_id=>wwv_flow_api.id(7202605164728618)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_LAND,P121_ORT,P121_PK_ORT'
,p_attribute_03=>'P121_LAND,P121_ORT,P121_PK_ORT'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7203586351728636)
,p_event_id=>wwv_flow_api.id(7202605164728618)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 03.02.2016',
'--Ortsdaten speichern',
'',
'begin',
'',
unistr('  --Pr\00FCfen, ob eine ID \00FCbergeben wurde'),
'  if :P121_PK_ORT is null then',
'     :P121_PK_ORT := SEQ_PK_ORT.nextval;',
'  end if;',
'',
'  --Daten speichern',
'  edit_data.p_std_set_ort (',
'                                  :P121_PK_ORT,',
'                                  :P121_ORT,',
'                                 :P121_LAND,',
'                                  v(''APP_USER'')',
'                              );',
'',
'end;'))
,p_attribute_02=>'P121_PK_ORT'
,p_attribute_03=>'P121_PK_ORT'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7204017260728637)
,p_event_id=>wwv_flow_api.id(7202605164728618)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7180439374613765)
,p_attribute_01=>'Submit(''Load'');'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7204562913728638)
,p_event_id=>wwv_flow_api.id(7202605164728618)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'Window.opener.parent.location.reload(true);'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7204917608731562)
,p_name=>'daDeleteOrt'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7181465329613926)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7205343713731582)
,p_event_id=>wwv_flow_api.id(7204917608731562)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_PK_ORT'
,p_attribute_03=>'P121_PK_ORT'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7205815821731582)
,p_event_id=>wwv_flow_api.id(7204917608731562)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 03.02.2016',
unistr('--L\00F6schen von Orten'),
'',
'begin',
'',
unistr('   --L\00F6schen von Orten'),
'     edit_data.p_std_del_ort (',
'                                 :P121_PK_ORT',
'                                );',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7206316121731583)
,p_event_id=>wwv_flow_api.id(7204917608731562)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.opener.parent.location.reload(true);',
'window.close;'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7231294846009017)
,p_name=>'daShowFamilien'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7230902724004835)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7231616154009020)
,p_event_id=>wwv_flow_api.id(7231294846009017)
,p_event_result=>'TRUE'
,p_action_sequence=>1
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P121_PK_FAMILIE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7232066330009021)
,p_event_id=>wwv_flow_api.id(7231294846009017)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(3389832559692140)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7232534110009021)
,p_event_id=>wwv_flow_api.id(7231294846009017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initDialog(''md_Familien'',''Familien'',700,200);',
'showDialog(''md_Familien'');'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9702956141073601)
,p_name=>'daShowBerufe'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9702604222070200)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9704353338073606)
,p_event_id=>wwv_flow_api.id(9702956141073601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initDialog(''md_Beruf'',''Liste aller Berufe'',700,200);',
'showDialog(''md_Beruf'');'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9795734617775003)
,p_name=>'daShowEltern'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9796529935781803)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9796118922775006)
,p_event_id=>wwv_flow_api.id(9795734617775003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Eltern'',''Eltern ausw\00E4hlen'',1300,200);'),
'showDialog(''md_Eltern'');'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9822838898359949)
,p_event_id=>wwv_flow_api.id(9795734617775003)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_ELTERN := null;'
,p_attribute_02=>'P121_ELTERN'
,p_attribute_03=>'P121_ELTERN'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9797347345800185)
,p_name=>'daAddElternteil'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9795434751769934)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9797762689800185)
,p_event_id=>wwv_flow_api.id(9797347345800185)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_ELTERN'
,p_attribute_03=>'P121_ELTERN'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9798449693834731)
,p_event_id=>wwv_flow_api.id(9797347345800185)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
unistr('--Elternteil einer Person hinzuf\00FCgen'),
'',
'begin',
'',
'',
unistr('  --ausgew\00E4hlte Elternteile hinzuf\00FCgen'),
'   for i in ( ',
'                    select regexp_substr(:P121_ELTERN,''[^:]+'', 1, level)  Elternteil from dual',
'                         connect by regexp_substr(:P121_ELTERN, ''[^:]+'', 1, level) is not null',
'              ) Loop',
' ',
unistr('                  --Elternteil hinzuf\00FCgen'),
'                    edit_data.p_pb_set_eltern (',
'                                                                 null',
'                                                                , i.elternteil',
'                                                                ,  :P121_PK_PERSON                                 ',
'                                                                , v(''APP_USER'')',
'                              );',
'',
'   end Loop;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9799455579854792)
,p_event_id=>wwv_flow_api.id(9797347345800185)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeDialog(''md_Eltern'');',
'window.opener.parent.location.reaload(true);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10017885139978762)
,p_name=>'daShowKinder'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9988013842917652)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10018258991978764)
,p_event_id=>wwv_flow_api.id(10017885139978762)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Kinder'',''Kinder ausw\00E4hlen'',1300,200);'),
'showDialog(''md_Kinder'');'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10018746257978765)
,p_event_id=>wwv_flow_api.id(10017885139978762)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_KINDER := null;'
,p_attribute_02=>'P121_KINDER'
,p_attribute_03=>'P121_KINDER'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10033349594488234)
,p_name=>'daAddKinder'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10016935098950139)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10033777009488237)
,p_event_id=>wwv_flow_api.id(10033349594488234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_KINDER'
,p_attribute_03=>'P121_KINDER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10034221433488238)
,p_event_id=>wwv_flow_api.id(10033349594488234)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
unistr('--Kinder einer Person hinzuf\00FCgen'),
'',
'begin',
'',
'',
unistr('  --ausgew\00E4hlte Kinder hinzuf\00FCgen'),
'   for i in ( ',
'                    select regexp_substr(:P121_KINDER,''[^:]+'', 1, level)  Kind from dual',
'                         connect by regexp_substr(:P121_KINDER, ''[^:]+'', 1, level) is not null',
'              ) Loop',
' ',
unistr('                  --Elternteil hinzuf\00FCgen'),
'                    edit_data.p_pb_set_eltern (',
'                                                                 null',
'                                                                ,  :P121_PK_PERSON ',
'                                                                , i.Kind                                ',
'                                                                , v(''APP_USER'')',
'                              );',
'',
'   end Loop;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10034708758488238)
,p_event_id=>wwv_flow_api.id(10033349594488234)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeDialog(''md_Kinder'');',
'window.opener.parent.location.reaload(true);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10706498333805609)
,p_name=>'daShowGeschwister'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10622029555591428)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10706875134805625)
,p_event_id=>wwv_flow_api.id(10706498333805609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Geschwister'',''Geschwister ausw\00E4hlen'',1300,200);'),
'showDialog(''md_Geschwister'');'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10707394590805627)
,p_event_id=>wwv_flow_api.id(10706498333805609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_GESCHWISTER := null;'
,p_attribute_02=>'P121_GESCHWISTER'
,p_attribute_03=>'P121_GESCHWISTER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(10710379152853978)
,p_name=>'daAddGeschwister'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10678888803668172)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10710793305853985)
,p_event_id=>wwv_flow_api.id(10710379152853978)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_GESCHWISTER'
,p_attribute_03=>'P121_GESCHWISTER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10711222599853987)
,p_event_id=>wwv_flow_api.id(10710379152853978)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
unistr('--Geschwister einer Person hinzuf\00FCgen'),
'',
'begin',
'',
'',
unistr('  --ausgew\00E4hlte Kinder hinzuf\00FCgen'),
'   for i in ( ',
'                    select regexp_substr(:P121_GESCHWISTER,''[^:]+'', 1, level)  Geschwister from dual',
'                         connect by regexp_substr(:P121_GESCHWISTER, ''[^:]+'', 1, level) is not null',
'              ) Loop',
'',
' ',
unistr('                  --Elternteil hinzuf\00FCgen'),
'                    edit_data.p_pb_set_geschwister (',
'                                                                 null',
'                                                                ,  :P121_PK_PERSON ',
'                                                                , i.Geschwister                          ',
'                                                                , v(''APP_USER'')',
'                              );',
'',
'   end Loop;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(10711708969853988)
,p_event_id=>wwv_flow_api.id(10710379152853978)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeDialog(''md_Geschwister'');',
'window.opener.parent.location.reaload(true);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11062018701381284)
,p_name=>'daShowLebenspartner'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10815085602131675)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11062422131381295)
,p_event_id=>wwv_flow_api.id(11062018701381284)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Lebenspartner'',''Lebenspartner ausw\00E4hlen'',1300,200);'),
'showDialog(''md_Lebenspartner'');'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11062958923381297)
,p_event_id=>wwv_flow_api.id(11062018701381284)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P121_LEBENSPARTNER := null;'
,p_attribute_02=>'P121_LEBENSPARTNER'
,p_attribute_03=>'P121_LEBENSPARTNER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11064412032434344)
,p_name=>'daAddLebenspartner'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(11060841460357122)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11064812629434351)
,p_event_id=>wwv_flow_api.id(11064412032434344)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P121_LEBENSPARTNER,P121_STATUS,P121_DATUM_KIRCHLICH,P121_DATUM_STANDESAMTLICH,P121_FK_ORT,P121_KIRCHE,P121_KIRCHE,P121_STANDESAMT,P121_STATUS'
,p_attribute_03=>'P121_LEBENSPARTNER,P121_STATUS,P121_DATUM_KIRCHLICH,P121_DATUM_STANDESAMTLICH,P121_KIRCHE,P121_STANDESAMT,P121_FK_ORT,P121_KOMMENTAR'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11065399057434353)
,p_event_id=>wwv_flow_api.id(11064412032434344)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
unistr('--Lebenspartner einer Person hinzuf\00FCgen'),
'',
'begin',
'',
'',
unistr('  --ausgew\00E4hlte Lebenspartner hinzuf\00FCgen'),
'   for i in ( ',
'                    select regexp_substr(:P121_LEBENSPARTNER,''[^:]+'', 1, level)  Lebenspartner from dual',
'                         connect by regexp_substr(:P121_LEBENSPARTNER, ''[^:]+'', 1, level) is not null',
'              ) Loop',
'',
' ',
unistr('                  --Lebenspartner hinzuf\00FCgen'),
'                    edit_data.p_pb_set_lebenspartner (',
'                                                                                   null',
'                                                                               ,  :P121_PK_PERSON ',
'                                                                               ,  i.Lebenspartner',
'                                                                               ,   :P121_STATUS',
'                                                                               ,   :P121_DATUM_STANDESAMTLICH',
'                                                                               ,   :P121_STANDESAMT',
'                                                                               ,   :P121_DATUM_KIRCHLICH',
'                                                                               ,   :P121_KIRCHE',
'                                                                               ,   :P121_FK_ORT',
'                                                                               ,   :P121_KOMM                           ',
'                                                                               ,   v(''APP_USER'')',
'                              );',
'',
'   end Loop;',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11065829850434354)
,p_event_id=>wwv_flow_api.id(11064412032434344)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeDialog(''md_Lebenspartner'');',
'window.opener.parent.location.reaload(true);'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8934446212495385)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(8920115021495286)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8931232058495378)
,p_process_success_message=>'#MRU_COUNT# row(s) updated, #MRI_COUNT# row(s) inserted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9499672671775921)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9493716810775912)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9497622791775919)
,p_process_success_message=>'#MRU_COUNT# row(s) updated, #MRI_COUNT# row(s) inserted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9624893226906898)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9616531328906882)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9622870101906895)
,p_process_success_message=>'#MRU_COUNT# row(s) updated, #MRI_COUNT# row(s) inserted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9660882203984630)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9652136957984620)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9658415989984627)
,p_process_success_message=>'#MRU_COUNT# row(s) updated, #MRI_COUNT# row(s) inserted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8934842673495386)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(8920115021495286)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'MULTI_ROW_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'#MRD_COUNT# row(s) deleted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9500055800775921)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9493716810775912)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'MULTI_ROW_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'#MRD_COUNT# row(s) deleted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9625233128906898)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9616531328906882)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'MULTI_ROW_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'#MRD_COUNT# row(s) deleted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9660458823984629)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(9652136957984620)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'ELTERN'
,p_attribute_03=>'PK_ELTERN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'MULTI_ROW_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'#MRD_COUNT# row(s) deleted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9940119222847474)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REMOVE_ELTERN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
'--Elternteil von Personen ',
'',
'begin',
'',
'   --entfernen der markierten Elternteile einer Person',
'    for i in 1 .. Apex_application.g_f01.count Loop',
'             ',
'        edit_data.p_pb_del_eltern(Apex_application.g_f01(i));         ',
'    end Loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9820640397293526)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10056758109746600)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REMOVE_KINDER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
'--Kinder von Personen ',
'',
'begin',
'',
'   --entfernen der markierten Kinder einer Person',
'    for i in 1 .. Apex_application.g_f02.count Loop',
'             ',
'        edit_data.p_pb_del_eltern(Apex_application.g_f02(i));       ',
'        ',
'    end Loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9988425335917653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10708539217828183)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REMOVE_GESCHWISTER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
'--entfernen von Geschwistern von Personen ',
'',
'begin',
'',
'   --entfernen der markierten Geschwister einer Person',
'    for i in 1 .. Apex_application.g_f03.count Loop',
'             ',
'        edit_data.p_pb_del_geschwister(Apex_application.g_f03(i));       ',
'        ',
'    end Loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11063987418413930)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REMOVE_LEBENSPARTNER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 05.02.2016',
'--entfernen von Lebenspartnern von Personen ',
'',
'begin',
'',
'   --entfernen der markierten Lebenspartnern einer Person',
'    for i in 1 .. Apex_application.g_f04.count Loop',
'             ',
'        edit_data.p_pb_del_Lebenspartner(Apex_application.g_f04(i));       ',
'        ',
'    end Loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3410932753271926)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 24.01.2016',
'--LOAD DATA',
'',
'declare',
'',
'begin',
'',
'',
' if :P121_PK_PERSON is not null then',
'    select  NAME',
'    , VORNAME',
'    , GESCHLECHT',
'    , GEBOREN_AM',
'    , GESTORBEN_AM',
'    , FK_GEBURTSORT',
'    , BESCHREIBUNG',
'    , GEBURTSNAME',
'    , TITEL',
'    , ADELSTITEL',
'    , FK_STERBEORT',
'    , RUFNAME',
'    , NR_AHNENTAFEL',
'    , NAME',
'    , VORNAME',
'    , GESCHLECHT',
'  into ',
'         :P121_NAME',
'      ,  :P121_VORNAME',
'      ,  :P121_GESCHLECHT',
'      ,  :P121_GEBOREN_AM',
'      ,  :P121_GESTORBEN_AM',
'      ,  :P121_GEBOREN_IN',
'      ,  :P121_Kommentar',
'      ,  :P121_GEBURTSNAME',
'      ,  :P121_TITEL',
'      ,  :P121_ADELSTITEL',
'      ,  :P121_GESTORBEN_IN',
'      ,  :P121_RUFNAME',
'      ,  :P121_NR_AHNENTAFEL',
'      ,  :P121_NAME_1',
'      ,  :P121_VORNAME_1',
'      ,  :P121_GESCHLECHT_1',
'   from Person',
'   where PK_PERSON = :P121_PK_PERSON ;',
'   ',
'  else',
'  ',
'     :P121_NAME := null;',
'     :P121_VORNAME := null;',
'     :P121_GESCHLECHT := null;',
'     :P121_GEBOREN_AM := null;',
'     :P121_GESTORBEN_AM := null;',
'     :P121_GEBOREN_IN := null;',
'     :P121_Kommentar := null;',
'     :P121_GEBURTSNAME := null;',
'     :P121_TITEL := null;',
'     :P121_ADELSTITEL := null;',
'     :P121_GESTORBEN_IN := null;',
'     :P121_RUFNAME := null;',
'     :P121_NR_AHNENTAFEL := null;',
'     :P121_NAME_1 := null;',
'     :P121_VORNAME_1 := null;',
'     :P121_GESCHLECHT_1 := null;',
'',
' end if;',
'',
'end;'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6950173660843207)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_RESET_PAGINATION'
,p_process_name=>'RP'
,p_attribute_01=>'THIS_PAGE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(42955379648310449)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(8920115021495286)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form test6'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
