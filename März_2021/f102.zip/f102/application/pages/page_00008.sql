prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test7'
,p_alias=>'TEST7'
,p_step_title=>'test7'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210314201038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3462325767462376)
,p_plug_name=>'Personen Stammbaum'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with perso as (select * from person)',
'select perso.pk_person, perso.name, perso.vorname, sta.lev, sta.stamm ',
'from  perso ',
' join table(get_tree.f_get_stamm(perso.pk_person)) sta on perso.pk_person = sta.pers'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_header=>'<div style="Overflow:auto;height:97%:width:97%">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3462405005462376)
,p_name=>'Personen Stammbaum'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>3462405005462376
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3462721531462378)
,p_db_column_name=>'LEV'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Ebene'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LEV'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3462807834462378)
,p_db_column_name=>'STAMM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vorfahren'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'STAMM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3463422224468880)
,p_db_column_name=>'NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3463511511468880)
,p_db_column_name=>'VORNAME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3483702913659079)
,p_db_column_name=>'PK_PERSON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'ID'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_PERSON'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3462906393462551)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'34630'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'LEV:STAMM:NAME:VORNAME:PK_PERSON'
,p_sort_column_1=>'LEV'
,p_sort_direction_1=>'DESC'
,p_break_on=>'PK_PERSON:NAME:VORNAME:0:0:0'
,p_break_enabled_on=>'PK_PERSON:NAME:VORNAME:0:0:0'
);
wwv_flow_api.component_end;
end;
/
