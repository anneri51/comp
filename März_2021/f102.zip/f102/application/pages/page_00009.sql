prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test8'
,p_alias=>'TEST8'
,p_step_title=>'test8'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210314201541'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6556122730743760)
,p_plug_name=>unistr('Personen Daten\00FCberpr\00FCfung')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3295300200618255)
,p_plug_display_sequence=>10
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with pers as (select pk_person, name, vorname, geschlecht,',
'                     pk_person || '' : '' || name || '', '' || vorname as per',
'              from Person',
'',
'),',
'elt as ( select fk_eltern, ',
'',
'                count(*) cnt_kind,',
unistr('                sum(case when  pers.geschlecht = ''m\00E4nnlich'' then 1 else 0 end) as cnt_kind_m,'),
'                sum(case when  pers.geschlecht = ''weiblich'' then 1 else 0 end) as cnt_kind_w,',
'                sum(case when   ((pers.geschlecht <> ''weiblich'' and pers.geschlecht <> ''weiblich'') or pers.geschlecht is null) then 1 else 0 end) as cnt_kind_s',
'          from eltern      ',
'             join pers on eltern.fk_eltern = pers.pk_person',
'          group by fk_eltern',
'',
'),',
'kind_elt as (  select fk_kind , ',
'                 --anzahl',
'                 count(*) cnt_elt, count(*) - 2 cnt_elt_s_i,',
'                 --Person im listagg',
'                 listagg(per, '';'') within group (order by per) as all_elt,',
'                 /*,',
'                 --Vater',
unistr('                 case when pers.geschlecht = ''m\00E4nnlich'' then listagg(per, '';'') within group (order by per) end as vat,'),
'                 --Mutter',
'                  case when pers.geschlecht = ''weiblich'' then listagg(per, '';'') within group (order by per) end as mut,',
'                 --keine Angabe',
'                  case when ((pers.geschlecht <> ''weiblich'' and pers.geschlecht <> ''weiblich'') or pers.geschlecht is null) then listagg(per, '';'') within group (order by per) end as sonst,',
'                 */',
'                 --Anzahl kinder',
'                   sum(cnt_kind) cnt_kind,',
'                   sum(cnt_kind_m) cnt_kind_m,',
'                   sum(cnt_kind_w) cnt_kind_w,',
'                   sum(cnt_kind_s) cnt_kind_s',
'          from eltern             ',
'             join pers on eltern.fk_eltern = pers.pk_person',
'             join elt on elt.fk_eltern = eltern.fk_eltern',
'          group by fk_kind',
'),',
'geschwist as (',
'                select fk_person,',
'                        count(*) cnt_all_ges',
'                from geschwister g',
'                 join pers on pers.pk_person = g.fk_geschwister',
'                 group by fk_person',
'                 ',
'),',
'leb as ( select fk_person,',
'                count(*) cnt_all_leb',
'         from lebenspartner lb',
'           join pers on pers.pk_person = lb.fk_lebenspartner',
'        group by fk_person',
'        )',
'',
'select p.*',
'from pers p',
' left join kind_elt on p.pk_person = kind_elt.fk_kind',
' left join geschwist g on g.fk_person = p.pk_person',
' left join leb lb on lb.fk_person = p.pk_person ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6556262774743760)
,p_name=>unistr('Personen Daten\00FCberpr\00FCfung')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>6556262774743760
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6556651617743767)
,p_db_column_name=>'PK_PERSON'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557065173743769)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557448593743769)
,p_db_column_name=>'VORNAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557819175743769)
,p_db_column_name=>'GESCHLECHT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Geschlecht'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5571770311007712)
,p_db_column_name=>'PER'
,p_display_order=>14
,p_column_identifier=>'O'
,p_column_label=>'Per'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6565654232751459)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'65657'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_PERSON:NAME:VORNAME:GESCHLECHT:PER'
);
wwv_flow_api.component_end;
end;
/
