prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test11'
,p_alias=>'TEST11'
,p_step_title=>'test11'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210315094348'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3362602500279165)
,p_plug_name=>unistr('\00DCbersicht Lebenspartner')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'lp.pk_lebenspartner',
', 	lp1.pk_person		LP1_Pk_person',
',	lp1.NAME		LP1_NAME',
',	lp1.VORNAME		LP1_VORNAME',
',	lp1.GESCHLECHT		LP1_GESCHLECHT',
',	lp1.GEBoren_am		LP1_GEBURTSDATUM',
',	lp1.GESTORBEN_AM		LP1_GESTORBEN_AM',
',	lp1.fk_GEBURTSORT		LP1_GEBURTSORT',
',	lp1.BESCHREIBUNG		LP1_BESCHREIBUNG',
',	lp1.GEBoren_am		LP1_GEBURTSNAME',
',	lp1.TITEL		LP1_TITEL',
',	lp1.ADELSTITEL		LP1_ADELSTITEL',
',	lp1.fk_STERBEORT		LP1_STERBEORT',
',	lp1.RUFNAME		LP1_RUFNAME',
',	lp1.NR_AHNENTAFEL		LP1_NR_AHNENTAFEL',
',	lp2.pk_person	LP2_pk_person',
',	lp2.NAME		LP2_NAME',
',	lp2.VORNAME		LP2_VORNAME',
',	lp2.GESCHLECHT		LP2_GESCHLECHT',
',	lp2.GEBoren_am		LP2_GEBURTSDATUM',
',	lp2.GESTORBEN_AM		LP2_GESTORBEN_AM',
',	lp2.fk_GEBURTSORT		LP2_GEBURTSORT',
',	lp2.BESCHREIBUNG		LP2_BESCHREIBUNG',
',	lp2.GEBURTSNAME		LP2_GEBURTSNAME',
',	lp2.TITEL		LP2_TITEL',
',	lp2.ADELSTITEL		LP2_ADELSTITEL',
',	lp2.fk_STERBEORT		LP2_STERBEORT',
',	lp2.RUFNAME		LP2_RUFNAME',
',	lp2.NR_AHNENTAFEL		LP2_NR_AHNENTAFEL',
',       lp.status',
',       lp.datum_kirchlich',
',       lp.datum_standesamtlich',
',       lp.standesamt',
',       lp.kirche',
',       o.ort',
',       l.land',
'FROM lebenspartner lp',
' join Person lp1 on lp1.pk_person = lp.fk_person',
' join Person lp2 on lp2.pk_person = lp.fk_lebenspartner',
' left join ort o on o.pk_ort = lp.fk_ort',
' left join land l on l.pk_land = o.fK_land'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3362809776279167)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'ANNE'
,p_internal_uid=>3362809776279167
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363425410279170)
,p_db_column_name=>'LP1_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Name<br>(Lebenspartner 1)'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:141:&SESSION.:::RP:P141_PK_LEBENSPARTNERSCHAFT:#PK_LEBENSPARTNERSCHAFT#'',1300,650);'
,p_column_linktext=>'#LP1_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363521453279170)
,p_db_column_name=>'LP1_VORNAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorname<br>(Lebenspartner 1)'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:141:&SESSION.:::RP:P141_PK_LEBENSPARTNERSCHAFT:#PK_LEBENSPARTNER#'',1300,650);'
,p_column_linktext=>'#LP1_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363601146279170)
,p_db_column_name=>'LP1_GESCHLECHT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Geschlecht<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363714481279170)
,p_db_column_name=>'LP1_GEBURTSDATUM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Geburtsdatum<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363804732279170)
,p_db_column_name=>'LP1_GESTORBEN_AM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Gestorben Am<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363917096279170)
,p_db_column_name=>'LP1_GEBURTSORT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Geburtsort<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364027151279170)
,p_db_column_name=>'LP1_BESCHREIBUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beschreibung<br>(Lebenspartner 1)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364232578279170)
,p_db_column_name=>'LP1_TITEL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Titel<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364312556279170)
,p_db_column_name=>'LP1_ADELSTITEL'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Adelstitel<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364430303279170)
,p_db_column_name=>'LP1_STERBEORT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Sterbeort<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364526224279170)
,p_db_column_name=>'LP1_RUFNAME'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Rufname<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364624636279170)
,p_db_column_name=>'LP1_NR_AHNENTAFEL'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Nr Ahnentafel<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364801609279170)
,p_db_column_name=>'LP2_NAME'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Name<br>(Lebenspartner 2)'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:141:&SESSION.:::RP:P141_PK_LEBENSPARTNERSCHAFT:#PK_LEBENSPARTNERSCHAFT#'',1300,650);'
,p_column_linktext=>'#LP2_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3364930461279170)
,p_db_column_name=>'LP2_VORNAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Vorname<br>(Lebenspartner 2)'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:141:&SESSION.:::RP:P141_PK_LEBENSPARTNERSCHAFT:#PK_LEBENSPARTNERSCHAFT#'',1300,650);'
,p_column_linktext=>'#LP2_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365005930279170)
,p_db_column_name=>'LP2_GESCHLECHT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Geschlecht<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365122379279170)
,p_db_column_name=>'LP2_GEBURTSDATUM'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Geburtsdatum<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365201728279170)
,p_db_column_name=>'LP2_GESTORBEN_AM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Gestorben Am<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365301610279171)
,p_db_column_name=>'LP2_GEBURTSORT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Geburtsort<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365409455279171)
,p_db_column_name=>'LP2_BESCHREIBUNG'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Beschreibung<br>(Lebenspartner 2)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365527343279171)
,p_db_column_name=>'LP2_GEBURTSNAME'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Geburtsname<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365623677279171)
,p_db_column_name=>'LP2_TITEL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Titel<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3365722617279171)
,p_db_column_name=>'LP2_ADELSTITEL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Adelstitel<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363028728279169)
,p_db_column_name=>'LP2_STERBEORT'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Sterbeort<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363118756279169)
,p_db_column_name=>'LP2_RUFNAME'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Rufname<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363223916279169)
,p_db_column_name=>'LP2_NR_AHNENTAFEL'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Nr Ahnentafel<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458004650954791)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Status'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'STATUS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458110934954792)
,p_db_column_name=>'DATUM_KIRCHLICH'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Datum Kirchlich'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'DATUM_KIRCHLICH'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458217707954792)
,p_db_column_name=>'DATUM_STANDESAMTLICH'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Datum Standesamtlich'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'DATUM_STANDESAMTLICH'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458318921954792)
,p_db_column_name=>'STANDESAMT'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Standesamt'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'STANDESAMT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458430273954792)
,p_db_column_name=>'KIRCHE'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Kirche'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'KIRCHE'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458519148954792)
,p_db_column_name=>'ORT'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Ort'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'ORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3458613945954792)
,p_db_column_name=>'LAND'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Land'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LAND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3488022883167200)
,p_db_column_name=>'PK_LEBENSPARTNER'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'ID'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:141:&SESSION.:::RP:P141_PK_LEBENSPARTNERSCHAFT:#PK_LEBENSPARTNER#'',1300,650);'
,p_column_linktext=>'#PK_LEBENSPARTNER#'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_LEBENSPARTNER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3488123397167200)
,p_db_column_name=>'LP1_PK_PERSON'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'ID<br>(Lebenspartner 1)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_PK_PERSON'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3488230346167200)
,p_db_column_name=>'LP2_PK_PERSON'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'ID<br>(Lebenspartner 2)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_PK_PERSON'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43460340863533205)
,p_db_column_name=>'LP1_GEBURTSNAME'
,p_display_order=>49
,p_column_identifier=>'AN'
,p_column_label=>'Lp1 Geburtsname'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3365818401279171)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33659'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'PK_LEBENSPARTNER:LP1_PK_PERSON:LP2_PK_PERSON:LP1_NAME:LP1_VORNAME:LP1_GESCHLECHT:LP2_NAME:LP2_VORNAME:LP2_GESCHLECHT:STATUS:DATUM_STANDESAMTLICH:STANDESAMT:DATUM_KIRCHLICH:KIRCHE:ORT:LAND:LP1_GEBURTSDATUM:LP1_GESTORBEN_AM:LP1_GEBURTSORT:LP1_STERBEORT'
||':LP1_RUFNAME:LP1_NR_AHNENTAFEL:LP2_GEBURTSDATUM:LP2_GESTORBEN_AM:LP2_GEBURTSORT:LP2_GEBURTSNAME:LP2_STERBEORT:LP2_RUFNAME:LP2_NR_AHNENTAFEL'
,p_break_on=>'0'
,p_break_enabled_on=>'0'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3370926122375026)
,p_application_user=>'ANNE'
,p_name=>unistr('vollst\00E4ndige Liste')
,p_report_seq=>10
,p_display_rows=>5000
,p_report_columns=>'LP1_NAME:LP1_VORNAME:LP1_GESCHLECHT:LP1_GEBURTSDATUM:LP1_GESTORBEN_AM:LP1_GEBURTSORT:LP1_BESCHREIBUNG:LP1_TITEL:LP1_ADELSTITEL:LP1_STERBEORT:LP1_RUFNAME:LP1_NR_AHNENTAFEL:LP2_NAME:LP2_VORNAME:LP2_GESCHLECHT:LP2_GEBURTSDATUM:LP2_GESTORBEN_AM:LP2_GEBUR'
||'TSORT:LP2_BESCHREIBUNG:LP2_GEBURTSNAME:LP2_TITEL:LP2_ADELSTITEL:LP2_STERBEORT:LP2_RUFNAME:LP2_NR_AHNENTAFEL'
,p_break_on=>'ID:LP1_NAME:LP1_VORNAME:LP2_NAME:LP2_VORNAME:0'
,p_break_enabled_on=>'ID:LP1_NAME:LP1_VORNAME:LP2_NAME:LP2_VORNAME:0'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3368214289279177)
,p_name=>'daShowOrte'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'daShowOrte'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3368520709279178)
,p_event_id=>wwv_flow_api.id(3368214289279177)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Orte'',''Erfassungsmaske f\00FCr neue Orte\00C4);'),
'showDialog(''md_Orte''):'))
);
wwv_flow_api.component_end;
end;
/
