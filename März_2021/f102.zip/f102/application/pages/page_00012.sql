prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test12'
,p_alias=>'TEST12'
,p_step_title=>'test12'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210315105038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3418004047566413)
,p_plug_name=>'Lebenspartnerschaften'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6890681358855702)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_plug_footer=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="text/javascript">',
' apex.jQuery(function() {',
' apex.jQuery("##REGION_STATIC_ID#").tabs();',
' });',
'</script>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3419517169617543)
,p_name=>'Alle Kinder'
,p_parent_plug_id=>wwv_flow_api.id(3418004047566413)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with Kind as (select  fk_Kind',
'              from Eltern ',
'              where fk_Eltern = :P141_PK_LB1',
'              union',
'              select  fk_Kind',
'              from Eltern',
'              where fk_Eltern = :P141_PK_LB2',
'          ),',
' elt as ( select fk_kind, ',
'                 listagg(p1.name || '', '' || p1.vorname || '' ('' || p1.geschlecht || '')'',''; '') within Group (order by p1.geschlecht, p1.name, p1.vorname) as              eltern',
'         from  Eltern e ',
'          join Person p1 on p1.pk_person = e.fk_eltern',
'          group by fk_kind',
'   ),',
'bld as ( select fk_person, id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px,  ',
'  hoehe_px,',
'  null as bild_aktion from Person_bild pb ',
' left join bilder_tab bt on bt.id = pb.fk_bild)',
'select person.*, elt.eltern',
'--, bld_k.vorschau',
'from Kind ',
'  join Person on Kind.fk_kind = person.pk_person',
'  join elt on elt.fk_kind = Kind.fk_kind',
'  left join bld bld_k on bld_k.fk_person = kind.fk_kind',
''))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'TOP_AND_BOTTOM_LEFT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489325693424573)
,p_query_column_id=>1
,p_column_alias=>'PK_PERSON'
,p_column_display_sequence=>1
,p_column_heading=>'ID KIND'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3419909842617545)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'NAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420000519617545)
,p_query_column_id=>3
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>4
,p_column_heading=>'VORNAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420111447617545)
,p_query_column_id=>4
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>5
,p_column_heading=>'GESCHLECHT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460418884533206)
,p_query_column_id=>5
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>15
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420317022617545)
,p_query_column_id=>6
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>6
,p_column_heading=>'GESTORBEN_AM'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489427144424573)
,p_query_column_id=>7
,p_column_alias=>'FK_GEBURTSORT'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420523011617545)
,p_query_column_id=>8
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>7
,p_column_heading=>'BESCHREIBUNG'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420614931617545)
,p_query_column_id=>9
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>8
,p_column_heading=>'GEBURTSNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420722714617545)
,p_query_column_id=>10
,p_column_alias=>'TITEL'
,p_column_display_sequence=>9
,p_column_heading=>'TITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3420809375617545)
,p_query_column_id=>11
,p_column_alias=>'ADELSTITEL'
,p_column_display_sequence=>10
,p_column_heading=>'ADELSTITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489503730424573)
,p_query_column_id=>12
,p_column_alias=>'FK_STERBEORT'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3421022641617545)
,p_query_column_id=>13
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>11
,p_column_heading=>'RUFNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3421106006617545)
,p_query_column_id=>14
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>12
,p_column_heading=>'NR_AHNENTAFEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460541768533207)
,p_query_column_id=>15
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>16
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460624925533208)
,p_query_column_id=>16
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>17
,p_column_heading=>'Created By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460776231533209)
,p_query_column_id=>17
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>18
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460858506533210)
,p_query_column_id=>18
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>19
,p_column_heading=>'Modified By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3459603220122557)
,p_query_column_id=>19
,p_column_alias=>'ELTERN'
,p_column_display_sequence=>2
,p_column_heading=>'Etern'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3422401117679194)
,p_name=>'Kinder Lebenspartner 1'
,p_parent_plug_id=>wwv_flow_api.id(3418004047566413)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.*,',
'  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion',
'',
'from Eltern e',
' join Person p on e.fk_kind = p.pk_person',
' left join Person_bild pb on pb.fk_person = p.pk_person',
' left join bilder_tab bt on bt.id = pb.fk_bild',
'where e.fk_eltern = :P141_PK_LB1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'TOP_AND_BOTTOM_LEFT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489721164426682)
,p_query_column_id=>1
,p_column_alias=>'PK_PERSON'
,p_column_display_sequence=>2
,p_column_heading=>'ID KIND'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3422830314679196)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'NAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3422922514679196)
,p_query_column_id=>3
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>4
,p_column_heading=>'VORNAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423010560679196)
,p_query_column_id=>4
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>7
,p_column_heading=>'GESCHLECHT'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43460920109533211)
,p_query_column_id=>5
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>21
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423210760679196)
,p_query_column_id=>6
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>6
,p_column_heading=>'GESTORBEN_AM'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489825657426682)
,p_query_column_id=>7
,p_column_alias=>'FK_GEBURTSORT'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423427475679196)
,p_query_column_id=>8
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>8
,p_column_heading=>'BESCHREIBUNG'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423528491679196)
,p_query_column_id=>9
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>9
,p_column_heading=>'GEBURTSNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423604673679196)
,p_query_column_id=>10
,p_column_alias=>'TITEL'
,p_column_display_sequence=>10
,p_column_heading=>'TITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423708550679196)
,p_query_column_id=>11
,p_column_alias=>'ADELSTITEL'
,p_column_display_sequence=>11
,p_column_heading=>'ADELSTITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3489925379426682)
,p_query_column_id=>12
,p_column_alias=>'FK_STERBEORT'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3423920892679196)
,p_query_column_id=>13
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>12
,p_column_heading=>'RUFNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3424011506679196)
,p_query_column_id=>14
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>13
,p_column_heading=>'NR_AHNENTAFEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461042248533212)
,p_query_column_id=>15
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>22
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461160804533213)
,p_query_column_id=>16
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>23
,p_column_heading=>'Created By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461240166533214)
,p_query_column_id=>17
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>24
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461317559533215)
,p_query_column_id=>18
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>25
,p_column_heading=>'Modified By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571039042007705)
,p_query_column_id=>19
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571142518007706)
,p_query_column_id=>20
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571255284007707)
,p_query_column_id=>21
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::::'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571366667007708)
,p_query_column_id=>22
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571472617007709)
,p_query_column_id=>23
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571527527007710)
,p_query_column_id=>24
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5571681383007711)
,p_query_column_id=>25
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3424316701683679)
,p_name=>'Lebenspartner 2'
,p_parent_plug_id=>wwv_flow_api.id(3418004047566413)
,p_template=>wwv_flow_api.id(6890681358855702)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.*,',
'  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion',
'from Eltern e',
' join Person p on e.fk_kind = p.pk_Person',
' left join Person_bild pb on pb.fk_person = p.pk_person',
' left join bilder_tab bt on bt.id = pb.fk_bild',
'where e.fk_eltern = :P141_PK_LB2'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(3297014296618256)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'TOP_AND_BOTTOM_LEFT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3490115988429042)
,p_query_column_id=>1
,p_column_alias=>'PK_PERSON'
,p_column_display_sequence=>2
,p_column_heading=>'ID KIND'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3424714255683681)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'NAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3424814865683681)
,p_query_column_id=>3
,p_column_alias=>'VORNAME'
,p_column_display_sequence=>4
,p_column_heading=>'VORNAME'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3424923315683681)
,p_query_column_id=>4
,p_column_alias=>'GESCHLECHT'
,p_column_display_sequence=>6
,p_column_heading=>'GESCHLECHT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461410159533216)
,p_query_column_id=>5
,p_column_alias=>'GEBOREN_AM'
,p_column_display_sequence=>21
,p_column_heading=>'Geboren Am'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425101100683681)
,p_query_column_id=>6
,p_column_alias=>'GESTORBEN_AM'
,p_column_display_sequence=>7
,p_column_heading=>'GESTORBEN_AM'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3490223958429043)
,p_query_column_id=>7
,p_column_alias=>'FK_GEBURTSORT'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425315035683681)
,p_query_column_id=>8
,p_column_alias=>'BESCHREIBUNG'
,p_column_display_sequence=>8
,p_column_heading=>'BESCHREIBUNG'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425416289683681)
,p_query_column_id=>9
,p_column_alias=>'GEBURTSNAME'
,p_column_display_sequence=>9
,p_column_heading=>'GEBURTSNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425501759683681)
,p_query_column_id=>10
,p_column_alias=>'TITEL'
,p_column_display_sequence=>10
,p_column_heading=>'TITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425625459683681)
,p_query_column_id=>11
,p_column_alias=>'ADELSTITEL'
,p_column_display_sequence=>11
,p_column_heading=>'ADELSTITEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3490317353429043)
,p_query_column_id=>12
,p_column_alias=>'FK_STERBEORT'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425803635683681)
,p_query_column_id=>13
,p_column_alias=>'RUFNAME'
,p_column_display_sequence=>12
,p_column_heading=>'RUFNAME'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(3425929994683681)
,p_query_column_id=>14
,p_column_alias=>'NR_AHNENTAFEL'
,p_column_display_sequence=>13
,p_column_heading=>'NR_AHNENTAFEL'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461570380533217)
,p_query_column_id=>15
,p_column_alias=>'CREATION_DATE'
,p_column_display_sequence=>22
,p_column_heading=>'Creation Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461614405533218)
,p_query_column_id=>16
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>23
,p_column_heading=>'Created By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461725586533219)
,p_query_column_id=>17
,p_column_alias=>'MODIFY_DATE'
,p_column_display_sequence=>24
,p_column_heading=>'Modify Date'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(43461807828533220)
,p_query_column_id=>18
,p_column_alias=>'MODIFIED_BY'
,p_column_display_sequence=>25
,p_column_heading=>'Modified By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6290460549205869)
,p_query_column_id=>19
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6290849509205870)
,p_query_column_id=>20
,p_column_alias=>'DATEINAME'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6291227267205870)
,p_query_column_id=>21
,p_column_alias=>'VORSCHAU'
,p_column_display_sequence=>5
,p_column_heading=>'Vorschau'
,p_use_as_row_header=>'N'
,p_column_format=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::::'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6291671405205871)
,p_query_column_id=>22
,p_column_alias=>'BILDGROESSE'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6292042630205871)
,p_query_column_id=>23
,p_column_alias=>'BREITE_PX'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6292498201205871)
,p_query_column_id=>24
,p_column_alias=>'HOEHE_PX'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6292884771205872)
,p_query_column_id=>25
,p_column_alias=>'BILD_AKTION'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3419117671584055)
,p_name=>'P141_PK_LEBENSPARTNERSCHAFT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'ID:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="width:250px"'
,p_tag_attributes=>'style="width:250px"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3421302766621376)
,p_name=>'P141_PK_LB1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Lebenspartner 1:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3421529064624318)
,p_name=>'P141_PK_LB2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Lebenspartner 2:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3426218447690049)
,p_name=>'P141_LB1_NAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Name:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3426413271692493)
,p_name=>'P141_LB1_VORNAME'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Vorname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3426605939695886)
,p_name=>'P141_LB1_GEBURTSNAME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Geburtsname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3427420807704122)
,p_name=>'P141_LB1_RUFNAME'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Rufname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3427614768706961)
,p_name=>'P141_X1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'<b>Lebenspartnerschaft:</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:#CEE3F6;height:15px"'
,p_tag_attributes=>'style="color: #FF0000;"'
,p_colspan=>9
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3429212803738208)
,p_name=>'P141_X2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'<b>Lebenspartner:</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:#CEE3F6;height:15px"'
,p_tag_attributes=>'style="color: #FF0000;"'
,p_colspan=>9
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3430205686741591)
,p_name=>'P141_X3'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'<b>Angaben zur Lebenspartnerschaft:</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:#CEE3F6;height:15px"'
,p_tag_attributes=>'style="color: #FF0000;"'
,p_colspan=>9
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3430830462760499)
,p_name=>'P141_LB1_GESCHLECHT'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Geschlecht:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''m\00E4nnlich'' as d,''m\00E4nnlich'' as r from dual'),
'Union',
'select ''weiblich'', ''weiblich'' from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="width:196px"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3431320110765268)
,p_name=>'P141_LB1_NR_AHNENTAFEL'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Nr. Ahnentafel:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3431824627778310)
,p_name=>'P141_STATUS'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Status:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''verheiratet'' as d, ''verheiratet'' as r from dual',
'Union',
'select ''geschieden'', ''geschieden'' from dual',
'Union',
'select ''getrennt lebend'', ''getrennt lebend'' from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="width:196px"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3432002845788438)
,p_name=>'P141_ORT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'geheiratet in (Ort):'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ('' || land || '')'', pk_ort',
'from ort o',
' left join land l on o.fk_land = l.pk_land',
'order by ort'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="width:196px"'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3432220301795504)
,p_name=>'P141_DT_STANDESAMTLICH'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'standesamtlich am:'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3432426975807623)
,p_name=>'P141_STANDESAMT'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Standesamt:'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Standesamt',
'from lebenspartner',
'Group by standesamt'))
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3432620289810701)
,p_name=>'P141_DT_KIRCHLICH'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'kirchlich am:'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3432815760812880)
,p_name=>'P141_KIRCHE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Kirche:'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Standesamt',
'from lebenspartner',
'Group by standesamt'))
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3433011447814896)
,p_name=>'P141_LB2_NAME'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Name:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3434106702817030)
,p_name=>'P141_LB2_VORNAME'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Vorname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3434332138820484)
,p_name=>'P141_LB2_GEBURTSNAME'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Geburtsname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3434528040822319)
,p_name=>'P141_LB2_RUFNAME'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Rufname:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3434724590823900)
,p_name=>'P141_LB2_GESCHLECHT'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Geschlecht:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''m\00E4nnlich'' as d,''m\00E4nnlich'' as r from dual'),
'Union',
'select ''weiblich'', ''weiblich'' from dual'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="width:196px"'
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3434920061826096)
,p_name=>'P141_LB2_NR_AHNENTAFEL'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Nr. Ahnentafel:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3456626709868506)
,p_name=>'P141_X4'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3466827591882260)
,p_name=>'P141_KOMMENTAR'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_prompt=>'Kommentar:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>170
,p_cMaxlength=>4000
,p_cHeight=>5
,p_colspan=>9
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5570859242007703)
,p_name=>'P141_LB1_BILD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT THUMBNAIL FROM BILDER_TAB BT INNER JOIN PERSON_BILD  PB ON BT.ID = PB.FK_BILD',
'WHERE FK_PERSON = :P141_PK_LB1'))
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5570948116007704)
,p_name=>'P141_LB2_BILD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(3418004047566413)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT THUMBNAIL FROM BILDER_TAB BT INNER JOIN PERSON_BILD  PB ON BT.ID = PB.FK_BILD',
'WHERE FK_PERSON = :P141_PK_LB2'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3457717815939402)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 25.01.2016',
'--LOAD_DATA',
'',
'declare',
'',
'begin',
'',
'  if :P141_PK_LEBENSPARTNERSCHAFT is not null then',
'     select fk_Person, fk_Lebenspartner, Status, o.ort || '' ('' || l.land || '')'', Datum_standesamtlich, Standesamt, Datum_kirchlich, Kirche, kommentar',
'     into :P141_PK_LB1, :P141_PK_LB2, :P141_status, :P141_ort, :P141_dt_standesamtlich, :P141_standesamt, :P141_dt_kirchlich, :P141_Kirche, :P141_Kommentar',
'      from Lebenspartner',
'       left join ort o on o.pk_ort = Lebenspartner.fk_ort',
'       left join land l on l.pk_land = o.fk_land',
'     where Lebenspartner.pk_lebenspartner = :P141_PK_LEBENSPARTnerSChaft;',
'',
'',
'     select Name, Geburtsname, Vorname, Rufname, Geschlecht, nr_ahnentafel     ',
'     into :P141_lb1_name, :P141_lb1_geburtsname, :P141_lb1_vorname, :P141_lb1_rufname, :P141_lb1_geschlecht, :P141_lb1_nr_ahnentafel',
'     from Person',
'     where pk_person = :P141_PK_LB1;',
'',
'     select Name, Geburtsname, Vorname, Rufname, Geschlecht, nr_ahnentafel    ',
'     into :P141_lb2_name, :P141_lb2_geburtsname, :P141_lb2_vorname, :P141_lb2_rufname, :P141_lb2_geschlecht, :P141_lb2_nr_ahnentafel',
'     from Person',
'     where pk_person = :P141_PK_LB2;',
'',
'  end if;',
'',
'end;'))
);
wwv_flow_api.component_end;
end;
/
