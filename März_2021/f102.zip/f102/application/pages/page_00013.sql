prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test13'
,p_alias=>'TEST13'
,p_step_title=>'test13'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210315111432'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3372518062519652)
,p_plug_name=>unistr('\00DCbersicht Geschwister')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'lp.pk_geschwister',
', 	lp1.pk_person		LP1_pk_person',
',	lp1.NAME		LP1_NAME',
',	lp1.VORNAME		LP1_VORNAME',
',	lp1.GESCHLECHT		LP1_GESCHLECHT',
',	lp1.GEBoren_am		LP1_GEBURTSDATUM',
',	lp1.GESTORBEN_AM		LP1_GESTORBEN_AM',
',	lp1.fk_GEBURTSORT		LP1_GEBURTSORT',
',	lp1.BESCHREIBUNG		LP1_BESCHREIBUNG',
',	lp1.GEBURTSNAME		LP1_GEBURTSNAME',
',	lp1.TITEL		LP1_TITEL',
',	lp1.ADELSTITEL		LP1_ADELSTITEL',
',	lp1.fk_STERBEORT		LP1_STERBEORT',
',	lp1.RUFNAME		LP1_RUFNAME',
',	lp1.NR_AHNENTAFEL		LP1_NR_AHNENTAFEL',
',	lp2.pk_person		LP2_pk_person',
',	lp2.NAME		LP2_NAME',
',	lp2.VORNAME		LP2_VORNAME',
',	lp2.GESCHLECHT		LP2_GESCHLECHT',
',	lp2.GEBoren_am		LP2_GEBURTSDATUM',
',	lp2.GESTORBEN_AM		LP2_GESTORBEN_AM',
',	lp2.fk_GEBURTSORT		LP2_GEBURTSORT',
',	lp2.BESCHREIBUNG		LP2_BESCHREIBUNG',
',	lp2.GEBURTSNAME		LP2_GEBURTSNAME',
',	lp2.TITEL		LP2_TITEL',
',	lp2.ADELSTITEL		LP2_ADELSTITEL',
',	lp2.fk_STERBEORT		LP2_STERBEORT',
',	lp2.RUFNAME		LP2_RUFNAME',
',	lp2.NR_AHNENTAFEL		LP2_NR_AHNENTAFEL',
'FROM geschwister lp',
' join person lp1 on lp1.pk_person = lp.fk_person',
' join person lp2 on lp2.pk_person = lp.fk_geschwister'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3372710623519653)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'ANNE'
,p_internal_uid=>3372710623519653
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373311678519654)
,p_db_column_name=>'LP1_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Name<br>(Eltern)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP1_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373425839519654)
,p_db_column_name=>'LP1_VORNAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorname<br>(Eltern)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP1_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373500804519654)
,p_db_column_name=>'LP1_GESCHLECHT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Geschlecht<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373602437519654)
,p_db_column_name=>'LP1_GEBURTSDATUM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Geburtsdatum<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373717057519654)
,p_db_column_name=>'LP1_GESTORBEN_AM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Gestorben Am<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373815034519654)
,p_db_column_name=>'LP1_GEBURTSORT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Geburtsort<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373910571519654)
,p_db_column_name=>'LP1_BESCHREIBUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beschreibung<br>(Eltern)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374024134519654)
,p_db_column_name=>'LP1_GEBURTSNAME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Geburtsname<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374102985519654)
,p_db_column_name=>'LP1_TITEL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Titel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374220265519654)
,p_db_column_name=>'LP1_ADELSTITEL'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Adelstitel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374300054519654)
,p_db_column_name=>'LP1_STERBEORT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Sterbeort<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374418134519655)
,p_db_column_name=>'LP1_RUFNAME'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Rufname<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374508267519655)
,p_db_column_name=>'LP1_NR_AHNENTAFEL'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Nr Ahnentafel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374712430519655)
,p_db_column_name=>'LP2_NAME'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Name<br>(Kind)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP2_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374824418519655)
,p_db_column_name=>'LP2_VORNAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Vorname<br>(Kind)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP2_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3374924448519655)
,p_db_column_name=>'LP2_GESCHLECHT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Geschlecht<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375010445519655)
,p_db_column_name=>'LP2_GEBURTSDATUM'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Geburtsdatum<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375131767519655)
,p_db_column_name=>'LP2_GESTORBEN_AM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Gestorben Am<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375202921519655)
,p_db_column_name=>'LP2_GEBURTSORT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Geburtsort<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375324412519655)
,p_db_column_name=>'LP2_BESCHREIBUNG'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Beschreibung<br>(Kind)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375422514519655)
,p_db_column_name=>'LP2_GEBURTSNAME'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Geburtsname<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375504997519655)
,p_db_column_name=>'LP2_TITEL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Titel<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3375617478519655)
,p_db_column_name=>'LP2_ADELSTITEL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3372911247519653)
,p_db_column_name=>'LP2_STERBEORT'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Sterbeort<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373025007519653)
,p_db_column_name=>'LP2_RUFNAME'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Rufname<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3373103472519653)
,p_db_column_name=>'LP2_NR_AHNENTAFEL'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Nr Ahnentafel<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3492627522560433)
,p_db_column_name=>'PK_GESCHWISTER'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Pk Geschwister'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_GESCHWISTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3492729239560433)
,p_db_column_name=>'LP1_PK_PERSON'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Lp1 Pk Person'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_PK_PERSON'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3492828481560433)
,p_db_column_name=>'LP2_PK_PERSON'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Lp2 Pk Person'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_PK_PERSON'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3375722539519656)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33758'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'PK_GESCHWISTER:LP1_PK_PERSON:LP2_PK_PERSON:LP2_NAME:LP2_VORNAME:LP2_GESCHLECHT:LP2_GEBURTSDATUM:LP2_GESTORBEN_AM:LP2_GEBURTSORT:LP2_BESCHREIBUNG:LP2_GEBURTSNAME:LP2_TITEL:LP2_ADELSTITEL:LP2_STERBEORT:LP2_RUFNAME:LP2_NR_AHNENTAFEL:LP1_NAME:LP1_VORNAME'
||':'
,p_break_on=>'LP1_NAME:LP1_VORNAME:0'
,p_break_enabled_on=>'LP1_NAME:LP1_VORNAME:0'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3378103725519657)
,p_name=>'daShowOrte'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'daShowOrte'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3378422989519657)
,p_event_id=>wwv_flow_api.id(3378103725519657)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('initDialog(''md_Orte'',''Erfassungsmaske f\00FCr neue Orte\00C4);'),
'showDialog(''md_Orte''):'))
);
wwv_flow_api.component_end;
end;
/
