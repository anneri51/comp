prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(6975265871855738)
,p_name=>'test15'
,p_alias=>'TEST15'
,p_step_title=>'test15'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20210315112328'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3318501077443328)
,p_plug_name=>'Orte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PK_ORT',
', ORT',
', LAND',
', CREATED_BY',
', CREATION_DATE',
', MODIFIED_BY',
', MODIFY_DATE',
'FROM ORT o',
' left join land l on l.pk_land  = o.fk_land'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script>',
'',
'// Modal-Dialog initialisieren',
'function initDialog ( pRegId , pTitle , pWidth , pHeight ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( {',
'      autoOpen:   false,',
'      bgiframe:   true,',
'      modal:      false,',
'      minHeight:  pHeight,',
'      width:      pWidth,',
'      minWidth:   pWidth,',
'      title:      pTitle,',
'      resizable: true,',
'      closeOnEscape : true',
'  } )',
'}',
'',
unistr('// setzt die Breite des Dialogs auf (nahezu) genau die f\00FCr den Report ben\00F6tigte Breite'),
'function setzeDialogBreite ( pRegId ) {',
'  var $vRegion  = $( "#" + pRegId );',
'  var vMinWidth = $vRegion.dialog ( "option" , "minWidth" );',
'  var vWidth    = $vRegion.find ( "table[id^=''report_'']" ).width();',
'  //',
'  $vRegion.dialog ( "option" , "width" , Math.max ( vMinWidth , vWidth + 30 ) );',
'}',
'',
'',
'// zeigt die Reports-Region als jQuery-Dialog an',
'function showDialog ( pRegId ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( "open" );',
'  setzeDialogBreite ( pRegId );',
'',
'}',
'',
'',
'// jQuery-Dialog schliessen',
'function closeDialog (pRegId) {',
'  $("#" + pRegId).dialog("close");',
'}',
'</script>'))
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3318612365443328)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'ANNE'
,p_internal_uid=>3318612365443328
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3318912417443331)
,p_db_column_name=>'ORT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Ort'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'ORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3319028513443332)
,p_db_column_name=>'LAND'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Land'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LAND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3470519665615302)
,p_db_column_name=>'PK_ORT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'ID'
,p_column_link=>'javascript:$.event.trigger(''daShowOrte'',''#PK_ORT#'');'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#e2.gif" alt="">'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_ORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004088531076745)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Erstellt von'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004745105076751)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Erstellt am'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7005433309076752)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('Ge\00E4ndert durch')
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7006162922076752)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('Ge\00E4ndert am')
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3319120541443461)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33192'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'PK_ORT:ORT:LAND:CREATED_BY:CREATION_DATE:MODIFIED_BY:MODIFY_DATE:'
,p_sort_column_1=>'ORT'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3319601194466314)
,p_plug_name=>'md_ORT'
,p_region_name=>'md_ORT'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_api.id(3295000409618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3319904000466314)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3319601194466314)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Speichern'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_execute_validations=>'N'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3320204832466315)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3319601194466314)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3320028583466314)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3319601194466314)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>unistr('L\00F6schen')
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_execute_validations=>'N'
,p_button_condition=>'P171_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(3321129775466316)
,p_branch_action=>'f?p=&APP_ID.:171:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3321307289466317)
,p_name=>'P171_PK_ORT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3319601194466314)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>30
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(3299619060618260)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3321500130466324)
,p_name=>'P171_ORT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3319601194466314)
,p_prompt=>'Ort'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1020
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3321703809466325)
,p_name=>'P171_LAND'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3319601194466314)
,p_prompt=>'Land'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>1020
,p_field_template=>wwv_flow_api.id(6951627932855728)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(3322731585493931)
,p_name=>'daShowOrte'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'daShowOrte'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7106931250370139)
,p_event_id=>wwv_flow_api.id(3322731585493931)
,p_event_result=>'TRUE'
,p_action_sequence=>1
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P171_PK_ORT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7107660795377777)
,p_event_id=>wwv_flow_api.id(3322731585493931)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(3319601194466314)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(3323016495493932)
,p_event_id=>wwv_flow_api.id(3322731585493931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'TRIGGERING_ELEMENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'initDialog(''md_ORT'',''Orte'',700,200);',
'showDialog(''md_ORT'');'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7081796594100244)
,p_name=>'daSaveOrt'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(3319904000466314)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7082145479100246)
,p_event_id=>wwv_flow_api.id(7081796594100244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P171_LAND,P171_ORT,P171_PK_ORT'
,p_attribute_03=>'P171_LAND,P171_ORT,P171_PK_ORT'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7090211089205832)
,p_event_id=>wwv_flow_api.id(7081796594100244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 03.02.2016',
'--Ortsdaten speichern',
'',
'begin',
'',
unistr('  --Pr\00FCfen, ob eine ID \00FCbergeben wurde'),
'  if :P171_PK_ORT is null then',
'     :P171_PK_ORT := SEQ_PK_ORT.nextval;',
'  end if;',
'',
'  --Daten speichern',
'  edit_data.p_std_set_ort (',
'                                  :P171_PK_ORT,',
'                                  :P171_ORT,',
'                                 :P171_LAND,',
'                                  v(''APP_USER'')',
'                              );',
'',
'end;'))
,p_attribute_02=>'P171_PK_ORT'
,p_attribute_03=>'P171_PK_ORT'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7090656244209648)
,p_event_id=>wwv_flow_api.id(7081796594100244)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(3319601194466314)
,p_attribute_01=>'Submit(''Load'');'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7091060632217603)
,p_event_id=>wwv_flow_api.id(7081796594100244)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'Window.opener.parent.location.reload(true);'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7108274476501733)
,p_name=>'daDeleteOrt'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(3320028583466314)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7108674102501737)
,p_event_id=>wwv_flow_api.id(7108274476501733)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P171_PK_ORT'
,p_attribute_03=>'P171_PK_ORT'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7109117416524118)
,p_event_id=>wwv_flow_api.id(7108274476501733)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 03.02.2016',
unistr('--L\00F6schen von Orten'),
'',
'begin',
'',
unistr('   --L\00F6schen von Orten'),
'     edit_data.p_std_del_ort (',
'                                 :P171_PK_ORT',
'                                );',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7109555224528788)
,p_event_id=>wwv_flow_api.id(7108274476501733)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.opener.parent.location.reload(true);',
'window.close;'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7109863440539235)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_RESET_PAGINATION'
,p_process_name=>'resetpage'
,p_attribute_01=>'THIS_PAGE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7100710631337837)
,p_process_sequence=>50
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DATA_LOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Anne Richter, 03.02.2016',
'--Daten laden in das Formular Orte',
'',
'begin',
'',
' --Daten laden',
'  if :P171_PK_ORT is not null then',
'',
'     select  ort',
'      , land',
'    into :P171_ORT',
'      , :P171_LAND',
'   from ort o',
'    left join land l on l.pk_land  = o.fk_land',
'     where pk_ort = :P171_PK_ORT;',
'',
'  end if;',
'',
'',
'',
'end;'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3322526772466326)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3320028583466314)
);
wwv_flow_api.component_end;
end;
/
