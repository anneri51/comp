prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>122
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Textanalyse'
,p_alias=>'TEXTANALYSE'
,p_step_title=>'Textanalyse'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42871455341341817)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011130440'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4376773371623621)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4663161116290767)
,p_plug_name=>'Textanalyse'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with txt as (select :P122_New txt  from dual),',
'    ko_zus as ( select fk_main_key, buchungstext, rownum rnr, length(buchungstext) len_buch',
'                from v_kto_konten_zus',
'               ---  where fk_main_key in (1498, 1458) --1458',
'               -- where rownum <= 5',
'                ),',
'     all_obj as (select rownum rnr_obj from all_objects),',
'     zer_buch_text as ( select rnr_obj, fk_main_key, substr(buchungstext, rnr_obj, 1) buchst_text, buchungstext',
'                        from ko_zus, all_obj',
'                       where all_obj.rnr_obj <= ko_zus.len_buch',
'                       ),',
'     zer_vgl as (select rnr_obj, substr(txt.txt, rnr_obj, 1) buchst_vgl',
'                 from  all_obj, txt',
'                 where all_obj.rnr_obj <= length(txt.txt)',
'                ),',
'',
'     erg as ( ',
'                 select buchungstext, zer_vgl.rnr_obj rnr_obj_vgl,zer_buch_text.rnr_obj rnr_obj_text ,  buchst_vgl, buchst_text, ',
'                 case when buchst_text = buchst_vgl then 1 else 0 end erg, ',
'                 case when soundex(buchst_text) = soundex(buchst_vgl) then 1 else 0 end sound_erg,',
'                 case when buchst_text = buchst_vgl then substr(buchungstext,1,zer_buch_text.rnr_obj) end teil_str,txt.txt, fk_main_key',
'                 from zer_buch_text, zer_vgl , txt',
'                 --where fk_main_key=1222',
'   ',
'     ) ',
'     select *',
'     from erg',
'     where erg.erg = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4663235821290767)
,p_name=>'Textanalyse'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13973371061711688
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4663574285290805)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4663945012290811)
,p_db_column_name=>'RNR_OBJ_VGL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Rnr Obj Vgl'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4664274132290813)
,p_db_column_name=>'RNR_OBJ_TEXT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Rnr Obj Text'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4664702701290815)
,p_db_column_name=>'BUCHST_VGL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Buchst Vgl'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4665124369290816)
,p_db_column_name=>'BUCHST_TEXT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Buchst Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4665478511290817)
,p_db_column_name=>'ERG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Erg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4665868559290818)
,p_db_column_name=>'SOUND_ERG'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Sound Erg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4666299877290820)
,p_db_column_name=>'TEIL_STR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Teil Str'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4666703537290821)
,p_db_column_name=>'TXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Txt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4667162315290822)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4667718313351787)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'139779'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSTEXT:RNR_OBJ_VGL:RNR_OBJ_TEXT:BUCHST_VGL:BUCHST_TEXT:ERG:SOUND_ERG:TEIL_STR:TXT:FK_MAIN_KEY'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(4673704603882128)
,p_report_id=>wwv_flow_api.id(4667718313351787)
,p_pivot_columns=>'RNR_OBJ_VGL:BUCHST_VGL'
,p_row_columns=>'FK_MAIN_KEY:BUCHUNGSTEXT'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(4674081829882128)
,p_pivot_id=>wwv_flow_api.id(4673704603882128)
,p_display_seq=>1
,p_function_name=>'MIN'
,p_column_name=>'RNR_OBJ_VGL'
,p_db_column_name=>'PFC1'
,p_column_label=>'rnr'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_sum=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8457808788038036)
,p_plug_name=>'Step 3'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8449690508038022)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8457953037038036)
,p_plug_name=>'Step 3'
,p_parent_plug_id=>wwv_flow_api.id(8457808788038036)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4377021762623623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4376773371623621)
,p_button_name=>'New'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'New'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8459690398038037)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8457808788038036)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8459949077038037)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8457808788038036)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8459856843038037)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8457808788038036)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8461322809038038)
,p_branch_action=>'f?p=&APP_ID.:123:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8459949077038037)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8460628155038037)
,p_branch_action=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8459856843038037)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4376908570623622)
,p_name=>'P122_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4376773371623621)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_main_key || '' '' || buchungstext, buchungstext',
'from v_kto_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8459392378038037)
,p_name=>'P122_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8457953037038036)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(4377098202623624)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(4377021762623623)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4377332961623626)
,p_event_id=>wwv_flow_api.id(4377098202623624)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P122_NEW'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4377259706623625)
,p_event_id=>wwv_flow_api.id(4377098202623624)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
