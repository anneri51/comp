prompt --application/pages/page_00253
begin
--   Manifest
--     PAGE: 00253
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>253
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Vorsteuer_Zuordnung_Lexbuchungen'
,p_alias=>'VORSTEUER_ZUORDNUNG_LEXBUC_253'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Vorsteuer_Zuordnung_Lexbuchungen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201110144225'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(690672609069223)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12954155042723485)
,p_plug_name=>'Lexwarebuchungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,lex.relation) sel,',
'       lex.BELEGDAT,',
'       lex.ABSCHLUSS,',
'       ',
'       lex.BELEG,',
'       lex.BENUTZER,',
'       lex.BETRAGDM,',
'       lex.BETRAGEUR,',
'       lex.BUCHDAT,',
'       lex.NR,',
'       lex.HABENDM,',
'       lex.HABENEUR,',
'       lex.HABEN,',
'       lex.JOUR_DAT,',
'       lex.RELATION,',
'       lex.SOLLDM,',
'       lex.SOLLEUR,',
'       lex.SOLL,',
'       lex.SPERRE,',
'       lex.STAPEL,',
'       lex.STATUS,',
'       lex.STATUS_DAT,',
'       lex.UST_H_DM,',
'       lex.UST_H_EUR,',
'       lex.UST_HABEN,',
'       lex.UST_S_DM,',
'       lex.UST_S_EUR,',
'       lex.UST_SOLL,',
'       lex.UST_DM,',
'       lex.UST_EUR,',
'       lex.UST,',
'       lex.UST_KTO,',
'       lex.UST_KTO_H,',
'       lex.UST_KTO_S,',
'       lex.UST_PROZ,',
'       lex.UST_TEXT,',
'       lex.PERIODE,',
'       lex.BELEGNR,',
'       lex.BUCHUNGSTEXT,',
'       lex.BETRAG,',
'       lex.WHRG,',
'       lex.SOLLKTO,',
'       lex.HABENKTO,',
'       lex.ZUSATZANG,',
'       lex.NOTIZ,',
'       lex.KST,',
'       lex.KTR,',
'       lex.JAHR,',
'       lex.JAHR_BELEG,',
'       sel_lex_relation selected,',
'       lg,',
'       lex.fk_std_lex_storno,',
'       lex.fk_lex_belegdat,',
'       lex.fk_lex_jourdat,',
'       arb1.monat, ',
'       fk_lex_relation_main,',
'       ktpl1.kontenunterart ktpl1_kontenunterart,',
'       ktpl1.kontenkategorie ktpl1_kontenkategorie,',
'       ktpl1.kontenbezeichnung ktpl1_kontenbezeichnung,',
'       ktpl2.kontenunterart ktpl2_kontenunterart,',
'       ktpl2.kontenkategorie ktpl2_kontenkategorie,',
'       ktpl2.kontenbezeichnung ktpl2_kontenbezeichnung,',
'       lex.fk_steu_steuer_voranmldg',
'       ',
'  from T_LEX_LONG lex',
'    left join (',
'                    select ',
'                        fk_lex_relation,listagg(relkto.fk_main_key || '' '' || Kontotyp,'','') within group (order by relkto.fk_main_key  ) lg',
'                     from t_rel_lex_kto_bel relkto',
'                         left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                    where fk_lex_relation <> ''0''      ',
'                    group by  fk_lex_relation',
'              ) relkto on lex.relation = relkto.fk_lex_relation',
'   left join t_bas_kal_arbeitstage arb1 on arb1.pk_bas_kal_arbeitstage = lex.fk_lex_belegdat',
'   left join t_bas_kal_arbeitstage arb2 on arb2.pk_bas_kal_arbeitstage = lex.fk_lex_jourdat',
'   left join t_lex_kontenplan ktpl1 on ktpl1.konto_nummer = lex.habenkto',
'   left join t_lex_kontenplan ktpl2 on ktpl2.konto_nummer = lex.sollkto',
' where  (  fk_lex_relation = :P253_FK_lex_relation        or :P253_fk_lex_relation is null) ',
'      and (fk_lex_relation_main = :P253_Fk_lex_relation_main or :p253_fk_lex_relation_main is null )',
'      and (lex.jahr = :P253_Jahr or :P253_jahr is null)',
'      and (lex.periode = :P253_Monat or :P253_monat is null)',
'      and (lex.ust_kto = :P253_Ust_kto or :P253_ust_kto is null)',
'      and (lex.fk_steu_steuer_voranmldg = :P253_fk_steu_steuer_voranmldg or :P253_fk_steu_steuer_voranmldg  is null)',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12954171537723485)
,p_name=>'lex_modal'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>22264306778144406
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12954637341723493)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12955046984723494)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12955437378723494)
,p_db_column_name=>'BELEG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12955829953723495)
,p_db_column_name=>'BENUTZER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12956205791723496)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12956616183723497)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12956989898723498)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12957445467723498)
,p_db_column_name=>'NR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12957800851723499)
,p_db_column_name=>'HABENDM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12958192374723500)
,p_db_column_name=>'HABENEUR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12958609727723501)
,p_db_column_name=>'HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12958977065723501)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12959368780723502)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12959766150723503)
,p_db_column_name=>'SOLLDM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12960222375723503)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12960631087723504)
,p_db_column_name=>'SOLL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12960994876723504)
,p_db_column_name=>'SPERRE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12961400685723505)
,p_db_column_name=>'STAPEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12961810603723505)
,p_db_column_name=>'STATUS'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12962214358723506)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12962636771723506)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12963034517723507)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12963456224723507)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12963822509723508)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12964166657723508)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12964641173723509)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12965003633723509)
,p_db_column_name=>'UST_DM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12965390521723510)
,p_db_column_name=>'UST_EUR'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12965767452723510)
,p_db_column_name=>'UST'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12966199902723511)
,p_db_column_name=>'UST_KTO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12966571065723511)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12967027782723512)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12967462540723512)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12967843916723513)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968182787723513)
,p_db_column_name=>'PERIODE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12968636454723514)
,p_db_column_name=>'BELEGNR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969032200723514)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969425253723514)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12969834123723515)
,p_db_column_name=>'WHRG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12970216357723515)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12970577765723516)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12970987949723517)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12971384422723517)
,p_db_column_name=>'NOTIZ'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12971808684723517)
,p_db_column_name=>'KST'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12972200364723518)
,p_db_column_name=>'KTR'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12972660652723518)
,p_db_column_name=>'JAHR'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12973036131723519)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8211199531291195)
,p_db_column_name=>'SEL'
,p_display_order=>57
,p_column_identifier=>'AV'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8211573757291198)
,p_db_column_name=>'SELECTED'
,p_display_order=>67
,p_column_identifier=>'AW'
,p_column_label=>'Selected'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301113160210169)
,p_db_column_name=>'LG'
,p_display_order=>77
,p_column_identifier=>'AX'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622344438507571)
,p_db_column_name=>'FK_LEX_BELEGDAT'
,p_display_order=>97
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622428747507572)
,p_db_column_name=>'FK_LEX_JOURDAT'
,p_display_order=>107
,p_column_identifier=>'BA'
,p_column_label=>'Fk Lex Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622495929507573)
,p_db_column_name=>'MONAT'
,p_display_order=>117
,p_column_identifier=>'BB'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622623328507574)
,p_db_column_name=>'FK_LEX_RELATION_MAIN'
,p_display_order=>127
,p_column_identifier=>'BC'
,p_column_label=>'Fk Lex Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622682134507575)
,p_db_column_name=>'KTPL1_KONTENUNTERART'
,p_display_order=>137
,p_column_identifier=>'BD'
,p_column_label=>'Ktpl1 Kontenunterart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622787855507576)
,p_db_column_name=>'KTPL1_KONTENKATEGORIE'
,p_display_order=>147
,p_column_identifier=>'BE'
,p_column_label=>'Ktpl1 Kontenkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622959927507577)
,p_db_column_name=>'KTPL1_KONTENBEZEICHNUNG'
,p_display_order=>157
,p_column_identifier=>'BF'
,p_column_label=>'Ktpl1 Kontenbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623066491507578)
,p_db_column_name=>'KTPL2_KONTENUNTERART'
,p_display_order=>167
,p_column_identifier=>'BG'
,p_column_label=>'Ktpl2 Kontenunterart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623107258507579)
,p_db_column_name=>'KTPL2_KONTENKATEGORIE'
,p_display_order=>177
,p_column_identifier=>'BH'
,p_column_label=>'Ktpl2 Kontenkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623276891507580)
,p_db_column_name=>'KTPL2_KONTENBEZEICHNUNG'
,p_display_order=>187
,p_column_identifier=>'BI'
,p_column_label=>'Ktpl2 Kontenbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(689297450069209)
,p_db_column_name=>'FK_STEU_STEUER_VORANMLDG'
,p_display_order=>197
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21604132344589507)
,p_db_column_name=>'FK_STD_LEX_STORNO'
,p_display_order=>207
,p_column_identifier=>'BK'
,p_column_label=>'Fk Std Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12973729494744628)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'222839'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:SEL:PERIODE:RELATION:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:KST:KTR:JAHR_BELEG:BELEGDAT:ABSCHLUSS:BELEG:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H_D'
||'M:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:ZUSATZANG:NOTIZ:SELECTED:LG::FK_LEX_BELEGDAT:FK_LEX_JOURDAT:MONAT:FK_LEX_RELATION_MAIN:KTPL1_KONTENUNTERART:KTPL1_KONTENKATEGORIE:KTPL1'
||'_KONTENBEZEICHNUNG:KTPL2_KONTENUNTERART:KTPL2_KONTENKATEGORIE:KTPL2_KONTENBEZEICHNUNG:FK_STEU_STEUER_VORANMLDG:FK_STD_LEX_STORNO'
,p_sort_column_1=>'BELEGNR'
,p_sort_direction_1=>'ASC'
,p_break_on=>'JAHR:MONAT'
,p_break_enabled_on=>'JAHR:MONAT'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48666181223916700)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_name=>'storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_LEX_STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>5
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48666653356916700)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STATUS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48667071587916702)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("STATUS" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48664597196916695)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48665032102916697)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SELECTED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"SELECTED" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48665417945916697)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'contains'
,p_expr=>'6680'
,p_condition_sql=>'upper("SOLLKTO") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 6680  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48665831146916699)
,p_report_id=>wwv_flow_api.id(12973729494744628)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27006325239970350)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(690672609069223)
,p_button_name=>'6_set_fk_beleg_datum'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Fk Beleg Datum'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20889637313551849)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(690672609069223)
,p_button_name=>'7_set_fk_journal_datum'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Fk Journal Datum'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13556933168839675)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253:P253_FK_RELATION,P253_FK_RELATION_MAIN:,'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(688044307069197)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(690672609069223)
,p_button_name=>'5_set_fk_steu_steuer_voranmdg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'5 Set Fk Steu Steuer Voranmdg'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39970072725104086)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(687919243069196)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(690672609069223)
,p_button_name=>'5_unset_fk_steu_steuer_voranmdg_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'unSet Fk Steu Steuer Voranmdg'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40000416028172633)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'add_inp_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'add_inp_beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39979976241118650)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'create_kasse_from_lex'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create Kasse From Lex'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8211131364291194)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'Datensatzauswahl'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Datensatzauswahl'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8211680243291199)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'Datendeselektion'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Datendeselektion'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15055658576097987)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'set_storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Storno'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15055717579097988)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(12954155042723485)
,p_button_name=>'reset_storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Reset Storno'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(687912369069195)
,p_name=>'P253_FK_STEU_STEUER_VORANMLDG_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(690672609069223)
,p_prompt=>'Fk Steu Steuer Voranmldg'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_steu_steuer_voranmldg || '' '' || meldemonat ||  '' '' || sendedatum , pk_steu_steuer_voranmldg',
'from t_steu_steuer_voranmldg'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(689378298069210)
,p_name=>'P253_FK_STEU_STEUER_VORANMLDG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(690672609069223)
,p_prompt=>'Fk Steu Steuer Voranmldg'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_steu_steuer_voranmldg || '' '' || meldemonat ||  '' '' || sendedatum , pk_steu_steuer_voranmldg',
'from t_steu_steuer_voranmldg'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(690373069069220)
,p_name=>'P253_UST_KTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(690672609069223)
,p_prompt=>'UST_KTO'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(690474898069221)
,p_name=>'P253_MONAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(690672609069223)
,p_prompt=>'Monat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(690545714069222)
,p_name=>'P253_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(690672609069223)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13365548432959902)
,p_name=>'P253_FK_LEX_RELATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12954155042723485)
,p_prompt=>'Fk Lex Relation'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13365596004959903)
,p_name=>'P253_FK_LEX_RELATION_MAIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12954155042723485)
,p_prompt=>'FK_RELATION_MAIN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39970356011108069)
,p_name=>'P253_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12954155042723485)
,p_prompt=>'<b>Pk Abl Ordner Page</b>'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number || '' ('' || pk_abl_ordner_page || '')'' d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40458506209191691)
,p_name=>'P253_PK_REL_LEX_KTO_BEL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12954155042723485)
,p_prompt=>'Pk Rel Lex Kto Bel'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_rel_lex_kto_bel || '': '' || fk_lex_relation || '' '' || fk_inp_belege_all || '' '' || fk_main_key d , pk_rel_lex_kto_bel',
'from t_rel_lex_kto_bel',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39626273958207995)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P253_PK_ABL_ORDNER_PAGE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39626323776207996)
,p_event_id=>wwv_flow_api.id(39626273958207995)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(40000416028172633)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8211414472291197)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_Set_Selection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set sel = 1 where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8211131364291194)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8211737620291200)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_Set_deselect'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set sel = null where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8211680243291199)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15055844364097989)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Set_storno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set fk_lex_storno = 1 where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15055658576097987)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15055915432097990)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_reset_storno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set fk_lex_storno = 0 where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15055717579097988)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39980149023121570)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_create_kasse_from_lex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     p_create_kas_on_lex (apex_application.g_f01(i) );',
'    end if;',
'    end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39979976241118650)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40000669429175758)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_add_inp_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_jahr number;',
' v_pk_inp_belege_all number;',
'begin',
'',
'',
' ',
' ',
'   for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'        select jahr',
'         into v_jahr',
'         from t_lex_long',
'         where relation =  apex_application.g_f01(i);',
'         ',
'         v_pk_inp_belege_all := inp_belege_all_seq.nextval;',
'         ',
'',
'         p_add_inp_belege_from_lex ( v_pk_inp_belege_all, :P253_PK_ABL_ORDNER_PAGE, v_jahr, apex_application.g_f01(i)) ;',
'         ',
'         update t_rel_lex_kto_bel set fk_inp_belege_all =  v_pk_inp_belege_all where pk_rel_lex_kto_bel = :P253_PK_REL_LEX_KTO_BEL;',
'         commit;',
'    end if;',
'    end loop;',
'    ',
'    ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(40000416028172633)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(688225360069199)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_Set_FK_steu_steuer_voranmldg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set fk_steu_steuer_voranmldg = :P253_FK_STEU_STEUER_VORANMLDG_1 where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(688044307069197)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(688136155069198)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_UnSet_FK_steu_steuer_voranmldg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      update  t_lex_long set fk_steu_steuer_voranmldg = null where relation  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(687919243069196)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27006239235970349)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_set_fk_beleg_datum'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'/*',
'        merge into t_lex_long t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'        relation',
'',
'        from (select * from t_lex_long where belegdat is not null and fk_lex_belegdat is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.belegdat,1,10), ''YYYY-MM-DD'')= arb.datum ',
'         ) t2 on (t1.relation = t2.relation)',
'        when matched then',
'        update set t1.fk_lex_belegdat =  t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        */',
'               merge into t_lex_long t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'        relation',
'',
'        from (select * from t_lex_long where belegdat is not null and fk_lex_belegdat is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.belegdat,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.relation = t2.relation)',
'        when matched then',
'        update set t1.fk_lex_belegdat =  t2.pk_bas_kal_arbeitstage;',
'        commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(20889504398551848)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_set_fk_beleg_datum_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'        merge into t_lex_long t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'        relation',
'',
'        from (select * from t_lex_long where BUCHDAT is not null and fk_lex_jourDAT is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.BUCHDAT,1,10), ''YYYY-MM-DD'')= arb.datum ',
'         ) t2 on (t1.relation = t2.relation)',
'        when matched then',
'        update set t1.fk_lex_jourDAT =  t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        /*',
'               merge into t_lex_long t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'        relation',
'',
'        from (select * from t_lex_long where BUCHDAT is not null and fk_lex_jourDAT is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.BUCHDAT,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.relation = t2.relation)',
'        when matched then',
'        update set t1.fk_lex_jourDAT =  t2.pk_bas_kal_arbeitstage;',
'        commit;',
'        */',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(20889637313551849)
);
wwv_flow_api.component_end;
end;
/
