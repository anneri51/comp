prompt --application/pages/page_00221
begin
--   Manifest
--     PAGE: 00221
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>221
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'lexware'
,p_alias=>'LEXWARE_221'
,p_step_title=>'lexware'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011154143'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8561369311672049)
,p_plug_name=>'lexware_kto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct BELEGDATUM,',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       lex.BUCHUNGSTEXT buchtext,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLUESSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRAEGER,',
'       BUCHUNGSBETRAG_EURO,',
'       kto.WAEHRUNG kto_waehrung,',
'       lex.ZUSATZANGABEN,',
'       lex.ok,',
'       kto.*,',
'       round(kto."Betrag",2) wert,',
'       apex_item.checkbox2(1, pk_lex,''CHECKED'') sel_ok,',
'       case when    STEUERSCHLUESSEL= 8 then ''7'' ',
'            when    STEUERSCHLUESSEL = 9 then ''19''',
'            else null',
'       end mwst,',
'       inv.pk_inv_inventar,',
'       inv.inventar,',
'       pr.pk_proj_projekt,',
'       pr.projekt,',
'       storno,',
'       pk_lex,',
'       lex_sum.sum_betrag - abs(round(kto."Betrag",2)) diff,',
'       lex.bemerkungen,',
'       konten.bezeichnung,',
'       lex.fk_imp_ba_bel ,',
'       lex_sum.sum_betrag',
'  from T_LEX lex',
'        left join v_kto_konten_zus kto on kto.fk_main_key= lex.fk_main_key',
'        left join t_rel_inv_inventar_zahlung invzahl on kto.fk_main_key = invzahl.fk_main_key',
'        left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar',
'        left join t_rel_proj_project_payment przahl on przahl.fk_main_key = kto.fk_main_key',
'        left join t_proj_projekt pr on pr.pk_proj_projekt = przahl.fk_proj_projekt',
'        left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'        left join (select sum(buchungsbetrag) sum_betrag, fk_main_key from t_lex where storno is null or storno = 0 group by fk_main_key ) lex_sum on lex_sum.fk_main_key = kto.fk_main_key',
'where (pk_lex =nvl(:P221_PK_LEX,0) or :P221_PK_LEX is null) and (belegnummer = nvl(:P221_Belegnummer,0) or :P221_Belegnummer is null) and (lex.fk_main_key = nvl(:P221_fk_main_key,0) or :P221_fk_main_key is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8561539926672049)
,p_name=>'lexware'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17871675167092970
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8561801418672068)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8562201920672072)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8562664429672073)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8563059932672074)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8563365487672075)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8563829218672075)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8564187414672076)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8564630186672077)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8565037523672078)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8565817835672079)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8566640513672079)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8567425227672080)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8304971574059329)
,p_db_column_name=>'BUCHTEXT'
,p_display_order=>25
,p_column_identifier=>'P'
,p_column_label=>'Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8568656727716980)
,p_db_column_name=>'OK'
,p_display_order=>35
,p_column_identifier=>'Q'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8568683385716981)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>45
,p_column_identifier=>'R'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8568774922716982)
,p_db_column_name=>'ID'
,p_display_order=>55
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8568869005716983)
,p_db_column_name=>'Buchungstag'
,p_display_order=>65
,p_column_identifier=>'T'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8569023979716984)
,p_db_column_name=>'Betrag'
,p_display_order=>75
,p_column_identifier=>'U'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8569921967716993)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>165
,p_column_identifier=>'AD'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8569981613716994)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>175
,p_column_identifier=>'AE'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570113372716995)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>185
,p_column_identifier=>'AF'
,p_column_label=>'Bucht tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570238536716996)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>195
,p_column_identifier=>'AG'
,p_column_label=>'Bucht monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570309521716997)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>205
,p_column_identifier=>'AH'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570427982716998)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>215
,p_column_identifier=>'AI'
,p_column_label=>'Bucht datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570527496716999)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>225
,p_column_identifier=>'AJ'
,p_column_label=>'Wertt tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570638761717000)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>235
,p_column_identifier=>'AK'
,p_column_label=>'Wertt monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570666681717001)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>245
,p_column_identifier=>'AL'
,p_column_label=>'Wertt jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8570833887717002)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>255
,p_column_identifier=>'AM'
,p_column_label=>'Wertt datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571162397717005)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>285
,p_column_identifier=>'AP'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571240263717006)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>295
,p_column_identifier=>'AQ'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571274781717007)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>305
,p_column_identifier=>'AR'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571763650717011)
,p_db_column_name=>'WERT'
,p_display_order=>325
,p_column_identifier=>'AT'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571815302717012)
,p_db_column_name=>'MWST'
,p_display_order=>335
,p_column_identifier=>'AU'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8571972120717014)
,p_db_column_name=>'INVENTAR'
,p_display_order=>355
,p_column_identifier=>'AW'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8572241028717016)
,p_db_column_name=>'PROJEKT'
,p_display_order=>375
,p_column_identifier=>'AY'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8572286636717017)
,p_db_column_name=>'SEL_OK'
,p_display_order=>385
,p_column_identifier=>'AZ'
,p_column_label=>'Sel ok <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8572409887717018)
,p_db_column_name=>'STORNO'
,p_display_order=>395
,p_column_identifier=>'BA'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8572534795717019)
,p_db_column_name=>'PK_LEX'
,p_display_order=>405
,p_column_identifier=>'BB'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8573443017717028)
,p_db_column_name=>'DIFF'
,p_display_order=>415
,p_column_identifier=>'BC'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8573557006717029)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>425
,p_column_identifier=>'BD'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8668641298254995)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>435
,p_column_identifier=>'BE'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9091248348602786)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>455
,p_column_identifier=>'BG'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9091639509602790)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>465
,p_column_identifier=>'BH'
,p_column_label=>'Sum betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802552568550064)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>475
,p_column_identifier=>'BI'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802627750550065)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>485
,p_column_identifier=>'BJ'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802687442550066)
,p_db_column_name=>'KTO_WAEHRUNG'
,p_display_order=>495
,p_column_identifier=>'BK'
,p_column_label=>'Kto Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802837192550067)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>505
,p_column_identifier=>'BL'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802890806550068)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>515
,p_column_identifier=>'BM'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803071925550069)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>525
,p_column_identifier=>'BN'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803107371550070)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>535
,p_column_identifier=>'BO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803239212550071)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>545
,p_column_identifier=>'BP'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803291516550072)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>555
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803420785550073)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>565
,p_column_identifier=>'BR'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803574828550074)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>575
,p_column_identifier=>'BS'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803647275550075)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>585
,p_column_identifier=>'BT'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803772239550076)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>595
,p_column_identifier=>'BU'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803874071550077)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>605
,p_column_identifier=>'BV'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50803957443550078)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>615
,p_column_identifier=>'BW'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804060961550079)
,p_db_column_name=>'IBAN'
,p_display_order=>625
,p_column_identifier=>'BX'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804101631550080)
,p_db_column_name=>'BANK'
,p_display_order=>635
,p_column_identifier=>'BY'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804192479550081)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>645
,p_column_identifier=>'BZ'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804348761550082)
,p_db_column_name=>'TBL'
,p_display_order=>655
,p_column_identifier=>'CA'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804391619550083)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>665
,p_column_identifier=>'CB'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804540337550084)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>675
,p_column_identifier=>'CC'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8568053334674460)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'178782'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_EURO:ZUSATZANGABE'
||'N:ID:VERWENDUNGSZWECK:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX::BEMERKUNGEN:BEZEICHNUNG:FK_IMP_BA_BEL:SUM_BETRAG:STEUERSCHLUESSEL:KOSTENTRAEGER:KTO_WAEHRUNG:WAEHRUNGSBETRAG:FREMDWAEHRUNG:FK'
||'_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:FK_KTO_BANKKONTO:KTO_BEZEICHNUNG:IBAN:BANK:DATUM_LEX_BUCHUNG_OK:TBL:PK_INV_INVENTAR:PK_PROJ_PROJEKT'
,p_break_on=>'SOLLKONTO'
,p_break_enabled_on=>'SOLLKONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8664737220248627)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8665111044248627)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8665562914248628)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8665895547248628)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8666314073248629)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8663115822248624)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKONTO'
,p_operator=>'='
,p_expr=>'1710'
,p_condition_sql=>'"HABENKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8663563430248625)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'is null'
,p_condition_sql=>'"KATEGORIE" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8663894506248626)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8664266670248626)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'='
,p_expr=>'6110'
,p_condition_sql=>'"SOLLKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8666715136248630)
,p_report_id=>wwv_flow_api.id(8568053334674460)
,p_name=>'Row text contains ''7.5'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'7.5'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9232221949170297)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Belegnummer'
,p_report_seq=>10
,p_report_alias=>'185424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:VERWENDUNGSZWECK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_'
||'EURO:ZUSATZANGABEN:ID:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX:BEMERKUNGEN:BEZEICHNUNG:BUCHT_DATUM:WERTT_DATUM:WERTT_JAHR:WERTT_MONAT:WERTT_TAG'
,p_sort_column_1=>'BELEGNUMMER'
,p_sort_direction_1=>'ASC'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9684045565096810)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9684365942096811)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9684782520096811)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9685233002096812)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9685587409096812)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>unistr('Steuerschl\00FCssel')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('STEUERSCHL\00DCSSEL')
,p_operator=>'is not null'
,p_condition_sql=>unistr(' (case when ("STEUERSCHL\00DCSSEL" is not null) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#EDEDED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9686033634096812)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9683212680096809)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'='
,p_expr=>'1251'
,p_condition_sql=>'"FK_MAIN_KEY" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9683655633096810)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"STORNO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9686464351096813)
,p_report_id=>wwv_flow_api.id(9232221949170297)
,p_name=>'Row text contains ''Fehlbuchung'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Fehlbuchung'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8601607277580721)
,p_application_user=>'ANNE'
,p_name=>'ABGLEICH'
,p_report_seq=>10
,p_report_columns=>'KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:MWST:SOLLKONTO:HABENKONTO:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:OK:ID:VERWENDUNGSZWECK:BUCHT_T'
||'AG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag'
,p_break_on=>'SOLLKONTO'
,p_break_enabled_on=>'SOLLKONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8607214069627458)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSTEXT'
,p_operator=>'='
,p_expr=>'Storno'
,p_condition_sql=>' (case when ("BUCHUNGSTEXT" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8607269470627458)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8607432724627458)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8606921463627457)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEGNUMMER'
,p_operator=>'contains'
,p_expr=>'32'
,p_condition_sql=>'upper("BELEGNUMMER") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 32  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8606972583627457)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKONTO'
,p_operator=>'='
,p_expr=>'1710'
,p_condition_sql=>'"HABENKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8607104329627457)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8607535718627458)
,p_report_id=>wwv_flow_api.id(8601607277580721)
,p_name=>'Row text contains ''32'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'32'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8691191025494428)
,p_application_user=>'ANNE'
,p_name=>'nach Konten'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_EURO:ZUSATZANGABE'
||'N:ID:VERWENDUNGSZWECK:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX::BEMERKUNGEN:BEZEICHNUNG'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691863545494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691963153494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691971911494430)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8692161464494430)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8692227295494430)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691347859494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEGNUMMER'
,p_operator=>'contains'
,p_expr=>'19'
,p_condition_sql=>'upper("BELEGNUMMER") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 19  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691452611494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKONTO'
,p_operator=>'='
,p_expr=>'1710'
,p_condition_sql=>'"HABENKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691521349494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'is null'
,p_condition_sql=>'"KATEGORIE" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691582015494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8691714615494429)
,p_report_id=>wwv_flow_api.id(8691191025494428)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'='
,p_expr=>'6110'
,p_condition_sql=>'"SOLLKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8839942980923735)
,p_application_user=>'ANNE'
,p_name=>'sort nach Belegnummer'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'SEL_OK:OK:KATEGORIE:KOSTENSTELLE:BELEGNUMMER:FK_MAIN_KEY:BELEGDATUM:Buchungstag:BUCHUNGSDATUM:BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHTEXT:BUCHUNGSBETRAG:WERT:DIFF:MWST:SOLLKONTO:HABENKONTO:INVENTAR:PROJEKT:BUCHUNGSBETRAG_EURO:ZUSATZANGABE'
||'N:ID:VERWENDUNGSZWECK:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:Betrag:STORNO:PK_LEX:BEMERKUNGEN:BEZEICHNUNG:BUCHT_DATUM:WERTT_DATUM:WERTT_JAHR:WERTT_MONAT:WERTT_TAG'
,p_sort_column_1=>'BELEGNUMMER'
,p_sort_direction_1=>'ASC'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053705184677791)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_name=>'Storno1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHTEXT'
,p_operator=>'contains'
,p_expr=>'Storno'
,p_condition_sql=>' (case when (upper("BUCHTEXT") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053772394677791)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053944729677791)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9054030854677791)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9054153845677791)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_name=>'Storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORNO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STORNO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F0AE9E'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053187182677789)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEGNUMMER'
,p_operator=>'contains'
,p_expr=>'139'
,p_condition_sql=>'upper("BELEGNUMMER") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 139  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053357318677790)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKONTO'
,p_operator=>'='
,p_expr=>'1710'
,p_condition_sql=>'"HABENKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053436751677790)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'is null'
,p_condition_sql=>'"KATEGORIE" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053497104677790)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9053601073677790)
,p_report_id=>wwv_flow_api.id(8839942980923735)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'='
,p_expr=>'6110'
,p_condition_sql=>'"SOLLKONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8572765466717022)
,p_plug_name=>'Kategorie'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct kto.kategorie,',
'sollkto,',
'bezeichnung,',
'--, lex. fk_main_key, kto.fk_main_key, pk_lex, fk_imp_ba_bel',
'ok',
'  from T_LEX_long lex',
'   left join t_rel_lex_kto_bel relbel on relbel.fk_lex_relation = lex.relation',
'   left join v_kto_konten_zus kto on kto.fk_main_Key= relbel.fk_main_key',
'   left join t_lex_kontenplan_konten konten on to_char(konten.konten_nr_ext) = to_char(lex.sollkto)',
'where (fk_std_lex_storno is null or fk_std_lex_storno <> 1)',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8572868558717023)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17883003799137944
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8572998742717024)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21205022422752709)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21207205138752731)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21207367412752732)
,p_db_column_name=>'OK'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8640481828782086)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179507'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KATEGORIE:SOLLKTO:BEZEICHNUNG'
,p_break_on=>'SOLLKONTO:BEZEICHNUNG:0:0:0:0'
,p_break_enabled_on=>'SOLLKONTO:BEZEICHNUNG:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21336106265445394)
,p_report_id=>wwv_flow_api.id(8640481828782086)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21335769199445393)
,p_report_id=>wwv_flow_api.id(8640481828782086)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKONTO'
,p_operator=>'!='
,p_expr=>'1700'
,p_condition_sql=>'"SOLLKONTO" != to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8667152669254980)
,p_plug_name=>'sollkonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct Kontotyp,',
'sollkonto,',
'bezeichnung,',
'ok',
'  from T_LEX lex',
'   left join v_kto_konten_zus kto on kto.fk_buchung_steuer= lex.belegnummer',
'   left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'where (storno is null or storno <> 1) and (sollkonto between 1700 and 1900)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8667255993254981)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17977391233675902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8667366967254983)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8667561299254984)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8667623142254985)
,p_db_column_name=>'OK'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802334761550062)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8677560939268442)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179877'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SOLLKONTO:BEZEICHNUNG:OK:KONTOTYP'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8667695441254986)
,p_plug_name=>'habenkonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct Kontotyp,',
'habenkonto,',
'',
'ok',
'  from T_LEX lex',
'   left join v_kto_konten_zus kto on kto.fk_buchung_steuer= lex.belegnummer',
'   left join t_lex_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'where (storno is null or storno <> 1) and (habenkonto between 1700 and 1900)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8667768847254987)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17977904087675908
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8668210659254991)
,p_db_column_name=>'OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8668494065254994)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50802408472550063)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8678107996268451)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'179883'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:HABENKONTO:KONTOTYP'
,p_break_on=>'HABENKONTO'
,p_break_enabled_on=>'HABENKONTO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8683702457448104)
,p_report_id=>wwv_flow_api.id(8678107996268451)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8849544929026999)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9560243603288090)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9091727107602791)
,p_plug_name=>'lexware_bel'
,p_parent_plug_id=>wwv_flow_api.id(9560243603288090)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct BELEGDATUM',
',',
'       BUCHUNGSDATUM,',
'       BUCHUNGSPERIODE,',
'       BELEGNUMMERNKREIS,',
'       BELEGNUMMER,',
'       lex.BUCHUNGSTEXT buchtext,',
'       BUCHUNGSBETRAG,',
'       SOLLKONTO,',
'       HABENKONTO,',
'       STEUERSCHLueSSEL,',
'       KOSTENSTELLE,',
'       KOSTENTRaeGER,',
'       BUCHUNGSBETRAG_EURO,',
'       lex.WaeHRUNG waehrung_lex,',
'       lex.ZUSATZANGABEN,',
'       lex.ok,',
'       ---',
'       ''Beleg'' art',
'       ,',
' kto.FK_kto_BUCHUNG,',
'null ID,',
' kto.DATUM,',
'kto.BETRAG,',
' kto.WaeHRUNG',
' ,',
'kto.WaeHRUNG_BETRAG,',
'null Fremdwaehrung,',
' kto.BEZEICHNUNG,',
'null FK_bas_Kat_Kategorie,',
'null FK_STD_VERW_Verwendungszweck,',
'null fk_STD_KTO_kontotyp,',
'null fk_BAS_KAL_buchungstag,',
'null fk_BAS_KAL_wertstellung,',
' kto.VERWENDUNGSZWECK,',
'null Kategorie,',
'null bucht_tag,',
'null bucht_monat,',
'null bucht_jahr,',
'null bucht_datum,',
'null wertt_tag,',
'null wertt_monat,',
'null wertt_jahr,',
'null wertt_datum,',
'null kontotyp,',
'null fk_KTO_vorgang,',
'null wiederholung,',
'null naechste_zahlung,',
'null fk_buchung_steuer,',
'kto.ART art2',
',',
' kto.PK_IMP_BA_ALLG_BEL,',
' kto.KENNZEICHEN,',
' kto.DATUM_VERGEHEN,',
'',
' kto.FK_BAS_KAL_ARBEITSTAG,',
' kto.ZAHLUNGSART,',
' kto.STEUERSATZ,',
' kto.MWST_BETRAG,',
' kto.NETTO,',
' kto.FK_INV_INVENTAR,',
' kto.FK_PROJ_PROJEKT,',
'       ',
'       ---',
'',
'     --  round(kto.Betrag,2) wert,',
'       apex_item.checkbox2(2, pk_lex) sel_ok,',
'       case when    STEUERSCHLUESSEL = 8 then ''7'' ',
'            when    STEUERSCHLUESSEL = 9 then ''19''',
'            else null',
'       end mwst,',
'       inv.pk_INV_inventar,',
'       inv.inventar,',
'       pr.pk_PROJ_projekt,',
'       pr.projekt,',
'       storno,',
'       pk_lex,',
'     --  lex_sum.sum_betrag - abs(round(kto.Betrag,2)) diff,',
'       lex.bemerkungen,',
'       konten.bezeichnung kto_bezeichnung,',
'       lex.fk_imp_ba_bel ,',
'       lex_sum.sum_betrag',
'       ',
'  from ',
'        T_LEX lex',
'        ',
'        left join v_imp_bel_zus kto on kto.fk_imp_ba_bel= lex.fk_imp_ba_bel',
'        left join t_rel_INV_inventar_zahlung invzahl on kto.fk_KTO_buchung = invzahl.fk_main_key',
'        left join t_INV_inventare inv on inv.pk_INV_inventar = invzahl.fk_INV_inventar',
'        left join t_rel_PROJ_projeCt_PAYMENT przahl on przahl.fk_main_key = kto.fk_KTO_buchung',
'        left join t_PROJ_projekt pr on pr.pk_PROJ_projekt = przahl.fk_PROJ_projekt',
'        left join t_LEX_kontenplan_konten konten on konten.konten_nr_ext = lex.sollkonto',
'        left join (select sum(buchungsbetrag) sum_betrag, fk_main_key from t_lex where storno is null or storno = 0 group by fk_main_key ) lex_sum on lex_sum.fk_main_key = kto.fk_KTO_buchung',
'where (pk_lex =nvl(:P221_PK_LEX,0) or :P221_PK_LEX is null) and (belegnummer = nvl(:P221_Belegnummer,0) or :P221_Belegnummer is null) and (lex.fk_main_key = nvl(:P221_fk_main_key,0) or :P221_fk_main_key is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9092004417602794)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18402139658023715
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9092148313602795)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9092517489602799)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9092626941602800)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>60
,p_column_identifier=>'C'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9093736713602811)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>170
,p_column_identifier=>'D'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094097200602815)
,p_db_column_name=>'MWST'
,p_display_order=>210
,p_column_identifier=>'F'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094291734602817)
,p_db_column_name=>'INVENTAR'
,p_display_order=>230
,p_column_identifier=>'H'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094472476602819)
,p_db_column_name=>'PROJEKT'
,p_display_order=>250
,p_column_identifier=>'J'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094580415602820)
,p_db_column_name=>'SEL_OK'
,p_display_order=>260
,p_column_identifier=>'K'
,p_column_label=>'Sel ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094669466602821)
,p_db_column_name=>'BUCHUNGSDATUM'
,p_display_order=>270
,p_column_identifier=>'L'
,p_column_label=>'Buchungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094787981602822)
,p_db_column_name=>'STORNO'
,p_display_order=>280
,p_column_identifier=>'M'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9094934102602823)
,p_db_column_name=>'PK_LEX'
,p_display_order=>290
,p_column_identifier=>'N'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9095076104602825)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>310
,p_column_identifier=>'P'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9095201953602826)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>320
,p_column_identifier=>'Q'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9095346570602827)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>330
,p_column_identifier=>'R'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9095403604602828)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>340
,p_column_identifier=>'S'
,p_column_label=>'Sum betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9095485415602829)
,p_db_column_name=>'BUCHUNGSPERIODE'
,p_display_order=>350
,p_column_identifier=>'T'
,p_column_label=>'Buchungsperiode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9141426497381580)
,p_db_column_name=>'BELEGNUMMERNKREIS'
,p_display_order=>360
,p_column_identifier=>'U'
,p_column_label=>'Belegnummernkreis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9141552243381581)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>370
,p_column_identifier=>'V'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9141760352381583)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>390
,p_column_identifier=>'W'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9141799065381584)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>400
,p_column_identifier=>'X'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9141865744381585)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>410
,p_column_identifier=>'Y'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9142146111381587)
,p_db_column_name=>'KOSTENSTELLE'
,p_display_order=>430
,p_column_identifier=>'AA'
,p_column_label=>'Kostenstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9142361370381589)
,p_db_column_name=>'BUCHUNGSBETRAG_EURO'
,p_display_order=>450
,p_column_identifier=>'AC'
,p_column_label=>'Buchungsbetrag Euro'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9142518102381591)
,p_db_column_name=>'ZUSATZANGABEN'
,p_display_order=>470
,p_column_identifier=>'AE'
,p_column_label=>'Zusatzangaben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9142646696381592)
,p_db_column_name=>'BUCHTEXT'
,p_display_order=>480
,p_column_identifier=>'AF'
,p_column_label=>'Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9142757107381593)
,p_db_column_name=>'OK'
,p_display_order=>490
,p_column_identifier=>'AG'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9143724319381603)
,p_db_column_name=>'WAEHRUNG_LEX'
,p_display_order=>500
,p_column_identifier=>'AH'
,p_column_label=>'Waehrung lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9143981966381606)
,p_db_column_name=>'ID'
,p_display_order=>530
,p_column_identifier=>'AK'
,p_column_label=>'Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9144071550381607)
,p_db_column_name=>'DATUM'
,p_display_order=>540
,p_column_identifier=>'AL'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9144981563381616)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>630
,p_column_identifier=>'AU'
,p_column_label=>'Bucht tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145157542381617)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>640
,p_column_identifier=>'AV'
,p_column_label=>'Bucht monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145178829381618)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>650
,p_column_identifier=>'AW'
,p_column_label=>'Bucht jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145287767381619)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>660
,p_column_identifier=>'AX'
,p_column_label=>'Bucht datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145386885381620)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>670
,p_column_identifier=>'AY'
,p_column_label=>'Wertt tag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145555789381621)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>680
,p_column_identifier=>'AZ'
,p_column_label=>'Wertt monat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145624659381622)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>690
,p_column_identifier=>'BA'
,p_column_label=>'Wertt jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145726790381623)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>700
,p_column_identifier=>'BB'
,p_column_label=>'Wertt datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145846856381624)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>710
,p_column_identifier=>'BC'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9145990896381626)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>730
,p_column_identifier=>'BE'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146155287381627)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>740
,p_column_identifier=>'BF'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146216724381628)
,p_db_column_name=>'ART'
,p_display_order=>750
,p_column_identifier=>'BG'
,p_column_label=>'Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146321640381629)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>760
,p_column_identifier=>'BH'
,p_column_label=>'Pk imp ba allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146365070395180)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>770
,p_column_identifier=>'BI'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146476905395181)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>780
,p_column_identifier=>'BJ'
,p_column_label=>'Datum vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146721361395183)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>800
,p_column_identifier=>'BL'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146857672395184)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>810
,p_column_identifier=>'BM'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9146923889395185)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>820
,p_column_identifier=>'BN'
,p_column_label=>'Mwst betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9147008579395186)
,p_db_column_name=>'NETTO'
,p_display_order=>830
,p_column_identifier=>'BO'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9147296419395189)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>860
,p_column_identifier=>'BR'
,p_column_label=>'Kto bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9528533590256728)
,p_db_column_name=>'BETRAG'
,p_display_order=>870
,p_column_identifier=>'BS'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9559223643288080)
,p_db_column_name=>'ART2'
,p_display_order=>890
,p_column_identifier=>'BU'
,p_column_label=>'Art2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804670888550085)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>900
,p_column_identifier=>'BV'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804710649550086)
,p_db_column_name=>'KOSTENTRAEGER'
,p_display_order=>910
,p_column_identifier=>'BW'
,p_column_label=>'Kostentraeger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804865784550087)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>920
,p_column_identifier=>'BX'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50804881522550088)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>930
,p_column_identifier=>'BY'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805063206550089)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>940
,p_column_identifier=>'BZ'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805178693550090)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>950
,p_column_identifier=>'CA'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805225952550091)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>960
,p_column_identifier=>'CB'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805378847550092)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>970
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805418827550093)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>980
,p_column_identifier=>'CD'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805525196550094)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>990
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805657477550095)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>1000
,p_column_identifier=>'CF'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805699053550096)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>1010
,p_column_identifier=>'CG'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805811589550097)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>1020
,p_column_identifier=>'CH'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50805882001550098)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>1030
,p_column_identifier=>'CI'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806059124550099)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>1040
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806100827550100)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>1050
,p_column_identifier=>'CK'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806184342550101)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>1060
,p_column_identifier=>'CL'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9176530620398347)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'184867'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGDATUM:VERWENDUNGSZWECK:KATEGORIE:WIEDERHOLUNG:MWST:INVENTAR:PROJEKT:SEL_OK:BUCHUNGSDATUM:STORNO:PK_LEX:BEMERKUNGEN:BEZEICHNUNG:FK_IMP_BA_BEL:SUM_BUCHUNGSPERIODE:BELEGNUMMERNKREIS:BELEGNUMMER:BUCHUNGSSOLLKONTO:HABENKONTO:KOSTENSTELLE:BUCHUNGSBETR'
||'AG_EURO:ZUSATZANGABEN:BUCHTEXT:OK_LEX:ID:DATUM:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:KONTOTYP:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:ART:PK_IMP_BA_ALLG_BEL:KENNZEICHEN:DATUM_VERGEHEN:ZAHLUNGSART:STEUERS'
||'ATZ:MWST_NETTO:KTO_BEZEICHNUNG:BETRAG:ART2:STEUERSCHLUESSEL:KOSTENTRAEGER:FK_KTO_BUCHUNG:WAEHRUNG:WAEHRUNG_BETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_KT'
||'O_VORGANG:FK_BAS_KAL_ARBEITSTAG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:PK_INV_INVENTAR:PK_PROJ_PROJEKT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9177420156446761)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'buch'
,p_report_seq=>10
,p_report_alias=>'184876'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:SEL_OK:ART:PK_LEX:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BELEGNUMMER:VERWENDUNGSZWECK:BEZEICHNUNG:BUCHTEXT:DATUM:BELEGDATUM:BUCHUNGSDATUM:BUCHUNGSBETRAG:BETRAG:STEUERSATZ:KATEGORIE:HABENKONTO:ZAHLUNGSART:KOSTENSTELLE:PROJEKT:INVENTAR:STORNO:BEMERKUNGEN:'
||'BELEGNUMMERNKREIS:SOLLKONTO:BUCHUNGSBETRAG_EURO:ZUSATZANGABEN:WAEHRUNG_LEX:ID:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:KONTOTYP:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:KENNZEICHEN:DATUM_VERGEHEN:KTO_BEZEICH'
||'NUNG:WIEDERHOLUNG:ART2:MWST'
,p_break_on=>'SOLLKONTO:KTO_BEZEICHNUNG'
,p_break_enabled_on=>'SOLLKONTO:KTO_BEZEICHNUNG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9687493238118874)
,p_report_id=>wwv_flow_api.id(9177420156446761)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9687087323118874)
,p_report_id=>wwv_flow_api.id(9177420156446761)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8571519442717009)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8561369311672049)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8852534124027029)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8561369311672049)
,p_button_name=>'back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Back'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:219:&SESSION.::&DEBUG.:RP:P219_BELEGNUMMER,P219_FK_BUCHUNG,P219_PK_LEX,P219_FK_MAIN_KEY:,,,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8572626798717020)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8561369311672049)
,p_button_name=>'Storno'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Storno'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8849822046027002)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8849544929026999)
,p_button_name=>'RESET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Reset filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8850592536027010)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(8849544929026999)
,p_button_name=>'SET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9091830709602792)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(9091727107602791)
,p_button_name=>'OK_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ok_PK'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9091872003602793)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(9091727107602791)
,p_button_name=>'Storno_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Storno_PK'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9668931460377355)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(9560243603288090)
,p_button_name=>'Belegzuordnung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Belegzuordnung'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8849594484027000)
,p_name=>'P221_PK_LEX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8849544929026999)
,p_prompt=>'Pk lex'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8849695879027001)
,p_name=>'P221_BELEGNUMMER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8849544929026999)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Belegnummer'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9091375505602788)
,p_name=>'P221_FK_MAIN_KEY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8849544929026999)
,p_prompt=>'Fk main key'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9668578134375152)
,p_name=>'P221_FK_IMP_BA_BEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(9560243603288090)
,p_prompt=>'Fk imp ba bel'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select art || '' '' || fk_imp_ba_bel || '' '' || datum || '' '' || bezeichnung || '' '' || betrag, fk_imp_ba_bel',
'from v_imp_bel_zus',
'where instr(bezeichnung, :P219_Buchungstext)>0 or :P219_Buchungstext is null'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8849963336027003)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8849822046027002)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8850054270027004)
,p_event_id=>wwv_flow_api.id(8849963336027003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8850137539027005)
,p_event_id=>wwv_flow_api.id(8849963336027003)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8851274165027017)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8850592536027010)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8851446978027018)
,p_event_id=>wwv_flow_api.id(8851274165027017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_03=>'P221_PK_LEX,P221_BELEGNUMMER'
,p_attribute_04=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8851508275027019)
,p_event_id=>wwv_flow_api.id(8851274165027017)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8571658940717010)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_lex set ok =1, datum_ok = sysdate where pk_lex = apex_application.g_f01(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8571519442717009)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9560089394288089)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'      update t_lex set ok =1, datum_ok = sysdate where pk_lex = apex_application.g_f02(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9091830709602792)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8572721274717021)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Storno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_lex set storno =1 where pk_lex = apex_application.g_f01(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8572626798717020)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9560289288288091)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Storno_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'      update t_lex set storno =1 where pk_lex = apex_application.g_f02(i) ;',
'      commit;',
'     end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9091872003602793)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9669149605380259)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_kontotyp varchar2(400 char);',
' v_cnt number;',
'begin',
'  ',
'',
'',
'   for i in 1..apex_application.g_f02.count loop',
'   ',
'     if apex_application.g_f02(i) is not null then',
'     ',
'        insert into test select 1, apex_application.g_f02(i),1 from dual; commit;',
'     ',
'        ',
'            insert into test select i, apex_application.g_f02(i), :P219_fk_buchung from dual; commit;',
'   ',
'            update t_lex set fk_imp_ba_bel =  :P221_fk_imp_ba_bel where pk_lex  = apex_application.g_f02(i) ;',
'           commit;',
'     ',
'     end if;',
'   ',
'   end loop;',
'   ',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9668931460377355)
);
wwv_flow_api.component_end;
end;
/
