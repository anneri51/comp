prompt --application/shared_components/navigation/lists/list_loc_add_location
begin
--   Manifest
--     LIST: List - LOC - Add Location
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(7300864954999350)
,p_name=>'List - LOC - Add Location'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25565110713976868)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Step 1 (Land)'
,p_list_item_link_target=>'f?p=&APP_ID.:268:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25565462391979590)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Step 2 (Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:270:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25565743735982466)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Step 3 (PLZ Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:271:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25566074012987625)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Step 4 (Strasse)'
,p_list_item_link_target=>'f?p=&APP_ID.:274:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25566301993989993)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Step 5 (Location)'
,p_list_item_link_target=>'f?p=&APP_ID.:275:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25566627401992016)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Step 6 (Location / Beleg)'
,p_list_item_link_target=>'f?p=&APP_ID.:276:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
