prompt --application/pages/page_00174
begin
--   Manifest
--     PAGE: 00174
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>174
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Buchung'
,p_alias=>'BUCHUNG'
,p_step_title=>'Buchung'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200930101715'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4226407966773328)
,p_plug_name=>'Buchung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_kto_KONT_BUCH_KONT_BUCH,',
'       FK_kto_KONTO_BUCH1,',
'       FK_kto_KONTO_BUCH2,',
'       CREATED_BY,',
'       CREATED_AT,',
'       MODIFIED_BY,',
'       MODIFIED_AT,',
'       BEMERKUNG,',
'       VON_FK_MAIN_KEY,',
'       VON_ID,',
'       VON_BUCHUNGSTAG,',
'       VON_BETRAG,',
'       VON_BUCHUNGSTEXT,',
'       VON_FK_bas_kat_KATEGORIE,',
'       VON_FK_bas_verw_VERWENDUNGSZWECK,',
'       VON_FK_std_kto_KONTOTYP,',
'       VON_FK_bas_kal_BUCHUNGSTAG,',
'       VON_FK_bas_kal_WERTSTELLUNG,',
'       VON_KONTOTYP,',
'       VON_KATEGORIE,',
'       VON_VERWENDUNGSZWECK,',
'       NACH_FK_MAIN_KEY,',
'       NACH_ID,',
'       NACH_BUCHUNGSTAG,',
'       NACH_BETRAG,',
'       NACH_BUCHUNGSTEXT,',
'       NACH_FK_bas_kat_KATEGORIE,',
'       NACH_FK_bas_verw_VERWENDUNGSZWECK,',
'       NACH_FK_std_kto_KONTOTYP,',
'       NACH_FK_bas_kal_BUCHUNGSTAG,',
'       NACH_FK_bas_kal_WERTSTELLUNG,',
'       NACH_KONTOTYP,',
'       NACH_KATEGORIE,',
'       NACH_VERWENDUNGSZWECK',
'  from V_kto_BUCHUNG'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(4226497369773328)
,p_name=>'Buchung'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13536632610194249
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4228053654773405)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4228456382773406)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4228846097773406)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4229195855773407)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4229635467773407)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4229983018773408)
,p_db_column_name=>'VON_FK_MAIN_KEY'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Von Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4230367911773409)
,p_db_column_name=>'VON_ID'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Von Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4230854285773409)
,p_db_column_name=>'VON_BUCHUNGSTAG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Von Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4231650875773410)
,p_db_column_name=>'VON_BUCHUNGSTEXT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Von Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4234016421773411)
,p_db_column_name=>'VON_KONTOTYP'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Von Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4234379903773412)
,p_db_column_name=>'VON_KATEGORIE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Von Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4234823888773412)
,p_db_column_name=>'VON_VERWENDUNGSZWECK'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Von Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4235222856773413)
,p_db_column_name=>'NACH_FK_MAIN_KEY'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Nach Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4235577359773413)
,p_db_column_name=>'NACH_ID'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Nach Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4236019618773413)
,p_db_column_name=>'NACH_BUCHUNGSTAG'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Nach Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4236799780773414)
,p_db_column_name=>'NACH_BUCHUNGSTEXT'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Nach Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4239195863773418)
,p_db_column_name=>'NACH_KONTOTYP'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Nach Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4239618360773418)
,p_db_column_name=>'NACH_KATEGORIE'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Nach Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4240040982773419)
,p_db_column_name=>'NACH_VERWENDUNGSZWECK'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Nach Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991041646139004)
,p_db_column_name=>'PK_REL_KTO_KONT_BUCH_KONT_BUCH'
,p_display_order=>44
,p_column_identifier=>'AI'
,p_column_label=>'Pk Rel Kto Kont Buch Kont Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991176579139005)
,p_db_column_name=>'FK_KTO_KONTO_BUCH1'
,p_display_order=>54
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Kto Konto Buch1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991185907139006)
,p_db_column_name=>'FK_KTO_KONTO_BUCH2'
,p_display_order=>64
,p_column_identifier=>'AK'
,p_column_label=>'Fk Kto Konto Buch2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991293932139007)
,p_db_column_name=>'VON_BETRAG'
,p_display_order=>74
,p_column_identifier=>'AL'
,p_column_label=>'Von Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991446593139008)
,p_db_column_name=>'VON_FK_BAS_KAT_KATEGORIE'
,p_display_order=>84
,p_column_identifier=>'AM'
,p_column_label=>'Von Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991534595139009)
,p_db_column_name=>'VON_FK_BAS_VERW_VERWENDUNGSZWECK'
,p_display_order=>94
,p_column_identifier=>'AN'
,p_column_label=>'Von Fk Bas Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49991621176139010)
,p_db_column_name=>'VON_FK_STD_KTO_KONTOTYP'
,p_display_order=>104
,p_column_identifier=>'AO'
,p_column_label=>'Von Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50056541416207261)
,p_db_column_name=>'VON_FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>114
,p_column_identifier=>'AP'
,p_column_label=>'Von Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50056639505207262)
,p_db_column_name=>'VON_FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>124
,p_column_identifier=>'AQ'
,p_column_label=>'Von Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50056728095207263)
,p_db_column_name=>'NACH_BETRAG'
,p_display_order=>134
,p_column_identifier=>'AR'
,p_column_label=>'Nach Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50056792319207264)
,p_db_column_name=>'NACH_FK_BAS_KAT_KATEGORIE'
,p_display_order=>144
,p_column_identifier=>'AS'
,p_column_label=>'Nach Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50056907783207265)
,p_db_column_name=>'NACH_FK_BAS_VERW_VERWENDUNGSZWECK'
,p_display_order=>154
,p_column_identifier=>'AT'
,p_column_label=>'Nach Fk Bas Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50057013585207266)
,p_db_column_name=>'NACH_FK_STD_KTO_KONTOTYP'
,p_display_order=>164
,p_column_identifier=>'AU'
,p_column_label=>'Nach Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50057135527207267)
,p_db_column_name=>'NACH_FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>174
,p_column_identifier=>'AV'
,p_column_label=>'Nach Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50057267644207268)
,p_db_column_name=>'NACH_FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>184
,p_column_identifier=>'AW'
,p_column_label=>'Nach Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4240459241774613)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135506'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VON_KONTOTYP:NACH_KONTOTYP:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:BEMERKUNG:VON_FK_MAIN_KEY:VON_ID:VON_BUCHUNGSTAG:VON_BUCHUNGSTEXT:VON_KATEGORIE:VON_VERWENDUNGSZWECK:NACH_FK_MAIN_KEY:NACH_ID:NACH_BUCHUNGSTAG:NACH_BUCHUNGSTEXT:NACH_KATEGORIE:N'
||'ACH_VERWENDUNGSZWECK::PK_REL_KTO_KONT_BUCH_KONT_BUCH:FK_KTO_KONTO_BUCH1:FK_KTO_KONTO_BUCH2:VON_FK_BAS_KAT_KATEGORIE:VON_FK_BAS_VERW_VERWENDUNGSZWECK:VON_FK_STD_KTO_KONTOTYP:VON_FK_BAS_KAL_BUCHUNGSTAG:VON_FK_BAS_KAL_WERTSTELLUNG:NACH_FK_BAS_KAT_KATEGO'
||'RIE:NACH_FK_BAS_VERW_VERWENDUNGSZWECK:NACH_FK_STD_KTO_KONTOTYP:NACH_FK_BAS_KAL_BUCHUNGSTAG:NACH_FK_BAS_KAL_WERTSTELLUNG'
);
wwv_flow_api.component_end;
end;
/
