prompt --application/pages/page_00327
begin
--   Manifest
--     PAGE: 00327
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>327
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Verpflegungsmehraufwand'
,p_alias=>'VERPFLEGUNGSMEHRAUFWAND1'
,p_step_title=>'Verpflegungsmehraufwand'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011155815'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11853777714973931)
,p_plug_name=>'Verpflegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12603533081709588)
,p_plug_name=>'Buchungsvorgabe'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13767612602091891)
,p_plug_name=>'Buchung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ll.relation, ll.habenkto, ll.sollkto, ll.betrag, ll.buchungstext, ll.nr, ll.belegnr, ll.belegdat',
'from t_rel_lex_kto_bel ktobel',
' left join t_lex_long ll on ktobel.fk_lex_relation = ll.relation',
'where fk_inp_belege_all = :P327_fk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13767921835091894)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP,:P329_FK_BAS_KAL_ARBEITSTAG,P329_FK_BAS_KAL_ARBEITSTAG:,'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>15208241110483434
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804127727389865)
,p_db_column_name=>'RELATION'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804255188389866)
,p_db_column_name=>'HABENKTO'
,p_display_order=>20
,p_column_identifier=>'V'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804286557389867)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804415762389868)
,p_db_column_name=>'BETRAG'
,p_display_order=>40
,p_column_identifier=>'X'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804520476389869)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>50
,p_column_identifier=>'Y'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804672856389870)
,p_db_column_name=>'NR'
,p_display_order=>60
,p_column_identifier=>'Z'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804734017389871)
,p_db_column_name=>'BELEGNR'
,p_display_order=>70
,p_column_identifier=>'AA'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13804860084389872)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13824851913419289)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'152652'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RELATION:HABENKTO:SOLLKTO:BETRAG:BUCHUNGSTEXT:NR:BELEGNR:BELEGDAT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14137848836709504)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(7149260507999280)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7266704574999328)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25405055492476981)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,',
'       FK_STEU_STEUER_VERPFL_MEHRAUFWD,',
'       DATUM_VERPFL_MEHRAUFWD,',
'       FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD,',
'       DESCR,',
'       COMM,',
'       FK_ADR_ORT,',
'       "FK_STD_VERPFL_FRUEHSTUECK",',
'       FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL,',
'       FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE,',
'       FK_STD_STEU_VERPFL_STATUS_VP_VOLL,',
'       FK_STD_STEU_VERPFL_STATUS_VP_TEIL,',
'       FK_STD_STEU_VERPFL_STATUS_VP_KUERZ,',
'       FK_STD_STEU_VERPFL_STATUS_UEP,',
'       FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS,',
'      FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL,',
'       FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ,',
'       CREATION_DATE,',
'       MODIFY_DATE,',
'             FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL+',
'        FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL+',
'       FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ+',
'      FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE gesamt,',
'       arb.*,',
'       case when arb.wochentag = ''Sonntag'' or arb.wochentag = ''Samstag'' then 1 else 0 end we,',
'       bel_src.inp,',
'       bel_ort.ort, ',
'       bel_std.std',
'  from T_STEU_STEUER_VERPFL_MEHRAUFWD_DET det',
'    left join t_bas_kal_arbeitstage arb on det.FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD = arb.pk_bas_kal_arbeitstage',
'    left join (',
'                     select fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET, listagg(''<b>'' || pk_inp_belege_all || ''</b>'' || '' - '' || bezeichnung, ''<br>'') within group (order by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET) inp ',
'                from  t_rel_steU_steuer_verpfl_beleg_src bel left join t_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all group by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'              ) bel_src on bel_src.fK_STEU_STEUER_VERPFL_MEHRAUFWD_DET = det.PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'    left join  (',
'    ',
'         select fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET, listagg(ort, '','') within group (order by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET) ort',
'                from  t_rel_steU_steuer_verpfl_beleg_ort bel left join t_adr_ort ort on bel.fk_adr_ort = ort.pk_adr_ort group by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'    )  bel_ort on bel_ort.fK_STEU_STEUER_VERPFL_MEHRAUFWD_DET = det.PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'    left join  (',
'    ',
'                select fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET, listagg(jahr || '' / '' || projekt || '' / '' || bezeichnung || '' / '' || std.von || '' - '' || std.bis, '','') within group (order by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET) std',
'                from  t_rel_steu_steuer_verpfl_beleg_src bel ',
'                   left join (select * from t_inp_belege_all) std on std.pk_inp_belege_all = bel.fk_proj_stundenzettel',
'                    left join t_proj_projekt proj on std.fk_proj_projekt  = proj.pk_proj_projekt',
'                group by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'    )  bel_std on bel_std.fK_STEU_STEUER_VERPFL_MEHRAUFWD_DET= det.PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'                      ',
'      ',
' where fk_STEU_STEUER_VERPFL_MEHRAUFWD = :P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(25405351355476981)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP,:P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,P329_FK_BAS_KAL_ARBEITSTAG:#PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET#,#FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>26845670630868521
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12104363937111278)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12105089825111280)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12051489872567878)
,p_db_column_name=>'DESCR'
,p_display_order=>57
,p_column_identifier=>'M'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12052587676567889)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>167
,p_column_identifier=>'X'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12603378480709586)
,p_db_column_name=>'GESAMT'
,p_display_order=>177
,p_column_identifier=>'Y'
,p_column_label=>'Gesamt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16352876624670578)
,p_db_column_name=>'DATUM'
,p_display_order=>197
,p_column_identifier=>'AA'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353269234670582)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>237
,p_column_identifier=>'AE'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353350574670583)
,p_db_column_name=>'TAG'
,p_display_order=>247
,p_column_identifier=>'AF'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353436008670584)
,p_db_column_name=>'MONAT'
,p_display_order=>257
,p_column_identifier=>'AG'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353481546670585)
,p_db_column_name=>'JAHR'
,p_display_order=>267
,p_column_identifier=>'AH'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353606194670586)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>277
,p_column_identifier=>'AI'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353739471670587)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>287
,p_column_identifier=>'AJ'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353862638670588)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>297
,p_column_identifier=>'AK'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16353883084670589)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>307
,p_column_identifier=>'AL'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16354042265670590)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>317
,p_column_identifier=>'AM'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16354093743670591)
,p_db_column_name=>'WE'
,p_display_order=>327
,p_column_identifier=>'AN'
,p_column_label=>'We'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16354899646670599)
,p_db_column_name=>'INP'
,p_display_order=>337
,p_column_identifier=>'AO'
,p_column_label=>'Inp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16355025508670600)
,p_db_column_name=>'ORT'
,p_display_order=>347
,p_column_identifier=>'AP'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16601555963482375)
,p_db_column_name=>'STD'
,p_display_order=>357
,p_column_identifier=>'AQ'
,p_column_label=>'Std'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410254619282129)
,p_db_column_name=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>367
,p_column_identifier=>'AR'
,p_column_label=>'Pk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410394990282130)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_display_order=>377
,p_column_identifier=>'AS'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410464077282131)
,p_db_column_name=>'DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>387
,p_column_identifier=>'AT'
,p_column_label=>'Datum Verpfl Mehraufwd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410593541282132)
,p_db_column_name=>'FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>397
,p_column_identifier=>'AU'
,p_column_label=>'Fk Bas Kal Datum Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410639700282133)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>407
,p_column_identifier=>'AV'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410700308282134)
,p_db_column_name=>'FK_STD_VERPFL_FRUEHSTUECK'
,p_display_order=>417
,p_column_identifier=>'AW'
,p_column_label=>'Fk Std Verpfl Fruehstueck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410892349282135)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_display_order=>427
,p_column_identifier=>'AX'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13410941258282136)
,p_db_column_name=>'FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_display_order=>437
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Verpfl Uebernachtungspauschale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411019712282137)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_display_order=>447
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411196463282138)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_display_order=>457
,p_column_identifier=>'BA'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411276297282139)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_display_order=>467
,p_column_identifier=>'BB'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411326366282140)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_UEP'
,p_display_order=>477
,p_column_identifier=>'BC'
,p_column_label=>'Fk Std Steu Verpfl Status Uep'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411448100282141)
,p_db_column_name=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_display_order=>487
,p_column_identifier=>'BD'
,p_column_label=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411545069282142)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_display_order=>497
,p_column_identifier=>'BE'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411695043282143)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_display_order=>507
,p_column_identifier=>'BF'
,p_column_label=>'Fk Std Verpfl Verpflegunspauschale Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411777847282144)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>517
,p_column_identifier=>'BG'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411888281282145)
,p_db_column_name=>'FK_STD_KAL_ARBEITSTAG'
,p_display_order=>527
,p_column_identifier=>'BH'
,p_column_label=>'Fk Std Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13411990600282146)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>537
,p_column_identifier=>'BI'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13412008576282147)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>547
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13412166133282148)
,p_db_column_name=>'KALENDERWOCHE'
,p_display_order=>557
,p_column_identifier=>'BK'
,p_column_label=>'Kalenderwoche'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(25459445578701834)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135462'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FEIERTAG:INP:STD:ORT:COMM:CREATION_DATE:DESCR:GESAMT:MODIFY_DATE:DATUM:TAG:MONAT:JAHR:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:WOCHENTAG:WE::PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_STEU_STEUER_VERPFL_MEHRAUFWD:DATUM_VERPFL_MEHRAUFWD:FK_BAS_KAL_DA'
||'TUM_VERPFL_MEHRAUFWD:FK_ADR_ORT:FK_STD_VERPFL_FRUEHSTUECK:FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL:FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE:FK_STD_STEU_VERPFL_STATUS_VP_VOLL:FK_STD_STEU_VERPFL_STATUS_VP_TEIL:FK_STD_STEU_VERPFL_STATUS_VP_KUERZ:FK_STD_STE'
||'U_VERPFL_STATUS_UEP:FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS:FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL:FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ:PK_BAS_KAL_ARBEITSTAGE:FK_STD_KAL_ARBEITSTAG:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:KALENDERWOCHE'
,p_sort_column_1=>'DATUM_VERPFMWED'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>unistr('FK_VERPFLEGUNGSPAUSCHALE_VOLL:FK_VERPFLEGUNGSPAUSCHALE_TEIL:FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ:FK_\00DCBERNACHTUNGSPAUSCHALE:GESAMT')
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16631719743669131)
,p_report_id=>wwv_flow_api.id(25459445578701834)
,p_name=>'Gesamt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'GESAMT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("GESAMT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0DCE0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16632120723669133)
,p_report_id=>wwv_flow_api.id(25459445578701834)
,p_name=>'we'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("WE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E0E0DD'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34045634842740043)
,p_plug_name=>'Lex_buchung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34042840484740016)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(34045634842740043)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,pk_STEU_STEUER_VERPFL_MEHRAUFWD_DET ) sel,',
'    det.*,',
'',
'       bel.PK_REL_steu_steuer_VERPFL_BELEG_SRC,',
'       bel.FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,',
'       bel.FK_INP_BELEGE_ALL,',
'       bel.FK_PROJ_STUNDENZETTEL,',
'       bel.COMM bel_comm,',
'       bel.FK_STD_STEU_STATUS bel_fk_status,',
'',
'      inp.pk_inp_belege_all,',
'      inp.bel_datum,',
'      inp.bezeichnung,',
'      case when inp.pk_inp_belege_all = :P327_fK_INP_BELEGE_ALL then 1 else 0 end inp_bel,',
'      inppos.bezeichnung pos_bezeichnung,',
'      ll.habenkto,',
'      ll.sollkto,',
'      ll.ust_kto,',
'      ',
unistr('      case when inp.fk_bas_kat_kategorie = 314 or inppos.fk_bas_kat_kategorie = 314 then 1 else 0 end fr\00FCh,'),
'      case when inp.fk_bas_kat_kategorie = 42 then 1 else 0 end rest,',
'      ',
'      case when  kat.FK_bas_kat_Oberkategorie = 694 and  katpos.FK_bas_kat_Oberkategorie = 694 then 1 else 0 end hotel,',
'      case when FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL>0 or  FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL>0 then 1 else 0 end verpf,',
'      case when (FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL>0 or  FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL>0)  and inp.fk_bas_kat_kategorie = 42 and sollkto = 6642 then 1 ',
'           when (FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL>0 or  FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL>0 ) and inp.fk_bas_kat_kategorie = 42 and sollkto <> 6642 then 2 ',
'           else 0 end chk_buch',
'   ',
'from T_STEU_STEUER_VERPFL_MEHRAUFWD_DET det ',
'   left join T_REL_steu_steuer_VERPFL_BEleG_SRC bel on bel.fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET = det.pk_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'   left join v_inp_belege_all inp on bel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_inp_belege_pos_all inppos on inppos.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_rel_lex_kto_bel relbel on relbel.fk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation  = relbel.fk_lex_relation ',
'   left join t_bas_kat_kategorie katpos on katpos.pk_bas_kat_kategorie = inppos.fk_bas_kat_kategorie',
'   left join t_bas_kat_kategorie katposob on katposob.pk_bas_kat_kategorie = katpos.FK_bas_kat_Oberkategorie',
'   left join t_bas_kat_kategorie kat on kat.pk_bas_kat_kategorie = inp.fk_bas_kat_kategorie',
'',
' where det.FK_STEU_STEUER_VERPFL_MEHRAUFWD = :P327_PK_VERPFLEGUNGSMEHRAUFWAND'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(34043038340740018)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>35483357616131558
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16344541196572122)
,p_db_column_name=>'COMM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16344947987572122)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16345366774572122)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16346931119572124)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16347361150572125)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16347741575572125)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16348136214572125)
,p_db_column_name=>'INP_BEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Inp Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16348489658572127)
,p_db_column_name=>'POS_BEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pos Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16348882856572127)
,p_db_column_name=>'HABENKTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16349289456572127)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16349746345572128)
,p_db_column_name=>'UST_KTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16262228736776400)
,p_db_column_name=>'DESCR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351174029670561)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351274013670562)
,p_db_column_name=>'BEL_COMM'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Bel Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351355309670563)
,p_db_column_name=>'BEL_FK_STATUS'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bel Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351432396670564)
,p_db_column_name=>unistr('FR\00DCH')
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>unistr('Fr\00FCh')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351538651670565)
,p_db_column_name=>'REST'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Rest'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351587883670566)
,p_db_column_name=>'HOTEL'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Hotel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351779571670567)
,p_db_column_name=>'VERPF'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Verpf'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351819522670568)
,p_db_column_name=>'CHK_BUCH'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Chk Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16351962938670569)
,p_db_column_name=>'SEL'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13412204569282149)
,p_db_column_name=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Pk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13412300816282150)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491590330014401)
,p_db_column_name=>'DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Datum Verpfl Mehraufwd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491680009014402)
,p_db_column_name=>'FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Datum Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491722942014403)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491809052014404)
,p_db_column_name=>'FK_STD_VERPFL_FRUEHSTUECK'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Std Verpfl Fruehstueck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13491910333014405)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492089226014406)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492158938014407)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk Std Verpfl Verpflegunspauschale Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492253397014408)
,p_db_column_name=>'FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Std Verpfl Uebernachtungspauschale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492315019014409)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492430251014410)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492532747014411)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492644866014412)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_UEP'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Std Steu Verpfl Status Uep'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492789369014413)
,p_db_column_name=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492847703014414)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13492971029014415)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13493010535014416)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(34126337779477865)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'177904'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>unistr('BEL_DATUM:VERPF:COMM:FK_INP_BELEGE_ALL:CHK_BUCH:CREATION_DATE:PK_INP_BELEGE_ALL:BEZEICHNUNG:INP_BEL:POS_BEZEICHNUNG:HABENKTO:SOLLKTO:UST_KTO:DESCR:MODIFY_DATE:BEL_COMM:BEL_FK_STATUS:FR\00DCH:REST:HOTEL::SEL:PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_STEU_STE')
||'UER_VERPFL_MEHRAUFWD:DATUM_VERPFL_MEHRAUFWD:FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD:FK_ADR_ORT:FK_STD_VERPFL_FRUEHSTUECK:FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL:FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL:FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ:FK_STD_VERPF'
||'L_UEBERNACHTUNGSPAUSCHALE:FK_STD_STEU_VERPFL_STATUS_VP_VOLL:FK_STD_STEU_VERPFL_STATUS_VP_TEIL:FK_STD_STEU_VERPFL_STATUS_VP_KUERZ:FK_STD_STEU_VERPFL_STATUS_UEP:FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERP'
||'FL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL'
,p_sort_column_1=>'SOLLKTO'
,p_sort_direction_1=>'ASC'
,p_break_on=>'BEL_DATUM'
,p_break_enabled_on=>'BEL_DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16382611440978313)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHK_BUCH'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHK_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#558555'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16382990938978314)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'nok_buch'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHK_BUCH'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("CHK_BUCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16383439072978314)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>unistr('fr\00FCh')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('FR\00DCH')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("FR\00DCH" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16383822131978314)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'hotel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HOTEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("HOTEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16384208502978314)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'rest'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'REST'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("REST" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B6CBE0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16384672842978316)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'buch'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SOLLKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B6BDB6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16385014551978316)
,p_report_id=>wwv_flow_api.id(34126337779477865)
,p_name=>'verpf'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERPF'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERPF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0E0E0'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12052747935567890)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(25405055492476981)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create Verpflegungsmehraufwd Det'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP,:P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD,P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:&P327_PK_VERPFLEGUNGSMEHRAUFWAND.,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13767774202091892)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13767612602091891)
,p_button_name=>'Create_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP,:P329_FK_STEU_STEUER_VERPFL_MEHRAUFWD,P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:&P327_PK_VERPFLEGUNGSMEHRAUFWAND.,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16352032177670570)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(34042840484740016)
,p_button_name=>'del_verpfl_det'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'del_verpfl_det'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13767820448091893)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13767612602091891)
,p_button_name=>'Select_inp_belege_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11918666163231356)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'Create_inp_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create Inp Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12052939242567892)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'Update_date'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Date'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12168096881478928)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(25405055492476981)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12172795871567658)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'Select_inp_belege'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Select Inp Belege'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:338:&SESSION.::&DEBUG.:RP:P338_FK_ARBEITSTAG,P338_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P330_FK_AREITSTAG.,&P330_FK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11918284048229656)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11860109968973967)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11858893771973963)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11860571850973967)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11859763663973966)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11853777714973931)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(11860801182973967)
,p_branch_action=>'f?p=&APP_ID.:326:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11855624496973956)
,p_name=>'P327_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11856053213973956)
,p_name=>'P327_FK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || nachname || '' '' || vorname || '' ('' || fK_kon_person || '') '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from t_inp_belege_all inp',
'  left join t_kon_person pers on pers.pk_kon_person = inp.fk_kon_person'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11856472275973958)
,p_name=>'P327_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11918021901227883)
,p_name=>'P327_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603449006709587)
,p_name=>'P327_BUCHUNGSVORGABE_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12603533081709588)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Verpflegungsmehraufwand '' ||  to_char(to_date(',
'                    ''01.'' || nvl(:P327_fk_monat,1) || ''.1900''',
'                ,''DD.MM.YYYY'') ,''MON'')',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Buchungsvorgabe Text'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603675877709589)
,p_name=>'P327_BUCHUNGSVORGABE_DATUM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12603533081709588)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select to_date(',
'                    ''01.''|| ',
'                    case when :P327_fk_monat = 12 then 1 else (nvl(:P327_fk_monat,1)+1) end || ''.'' ||  ',
'                    case when :P327_fk_monat = 12 then nvl(:P327_fk_jahr,1900) + 1 else to_number(nvl(:P327_fk_jahr,1900))  end',
'                    --else nvl(:P327_fk_jahr,1900) end',
'                ,''DD.MM.YYYY'')-1  ',
'from dual'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Buchungsvorgabe Datum'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603744813709590)
,p_name=>'P327_BETRAG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12603533081709588)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'     select sum(',
'              FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL+',
'     FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL+',
'       "FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ"+',
'       "FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE") gesamt',
'  from   T_STEU_STEUER_VERPFL_MEHRAUFWD_DET',
'',
' where FK_STEU_STEUER_VERPFL_MEHRAUFWD= :P327_PK_Verpflegungsmehraufwand'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603835791709591)
,p_name=>'P327_SOLLKONTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(12603533081709588)
,p_item_default=>'6674'
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12603971154709592)
,p_name=>'P327_HABENKONTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(12603533081709588)
,p_item_default=>'2180'
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13409774941282124)
,p_name=>'P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Pk Steu Steuer Verpfl Mehraufwd'
,p_source=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13409861649282125)
,p_name=>'P327_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Monat'
,p_source=>'MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13409986068282126)
,p_name=>'P327_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Jahr'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13410002462282127)
,p_name=>'P327_FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_source=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group  = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13410152378282128)
,p_name=>'P327_FK_STEU_STEUER_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Fk Steu Steuer Monat'
,p_source=>'FK_STEU_STEUER_MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select jahr || '' '' || monat || '' '' || faelligkeitsdatum d, pk_steu_steuer_monat',
'from t_steu_steuer_monat'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14071529263269723)
,p_name=>'P327_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14071621281269724)
,p_name=>'P327_FK_KON_PERSON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11853777714973931)
,p_item_source_plug_id=>wwv_flow_api.id(11853777714973931)
,p_prompt=>'Fk Kon Person'
,p_source=>'FK_KON_PERSON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_KON_PERSON'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nachname || '' '' || vorname || '' ('' || geburtsdatum || '')'' d, pk_kon_person',
'from t_kon_person'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11861757654973974)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(11853777714973931)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Verpflegungsmehraufwand'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11717579328412480)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create_inp_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'insert into t_inp_belege_ALL (',
'',
'bel_datum,',
'bezeichnung,',
'--brutto_betrag,',
'fk_std_inp_STATUS,',
'--fk_Kategorie,',
'--fk_verwendungszweck,',
'fk_abl_ordner_page,',
'comm_sonstiges,',
'create_at,',
'modify_at',
')',
'select ',
'''01.''|| monat||''.''|| jahr bt,',
'''Verpflegungsmehraufwand'' || '' '' || monat || '' '' || jahr,',
'--abs("Betrag") Betrag,',
'6 Status,',
'--"FK_Kategorie" ,',
'--"FK_Verwendungszweck",',
':P327_FK_ABL_ORDNER_PAGE,',
'''erstellt aus Verpflegungsmehraufwand '' ,',
'sysdate,',
'sysdate',
'from T_STEU_STEUER_VERPFL_MEHRAUFWD; -- &P321_FK_MAIN_KEY.;',
'commit;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11918666163231356)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12053071008567893)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Datum'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'merge into T_STEU_STEUER_VERPFL_MEHRAUFWD_det t1',
'  using (',
'        select pk_bas_kal_arbeitstage, ',
'        pk_STEU_STEUER_VERPFL_MEHRAUFWD_det',
'',
'        from (select * from T_STEU_STEUER_VERPFL_MEHRAUFWD_det where DATUM_VERPFL_MEHRAUFWD is not null and FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD is null) bel,',
'          t_bas_kal_arbeitstage arb',
'        where  to_date(substr(bel.DATUM_VERPFL_MEHRAUFWD,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_STEU_STEUER_VERPFL_MEHRAUFWD_det = t2.pk_STEU_STEUER_VERPFL_MEHRAUFWD_det)',
'        when matched then',
'        update set t1.FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD= t2.pk_bas_kal_arbeitstage;',
'        commit;',
'  end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12052939242567892)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16352154321670571)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'del_verpf_det'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'       delete from T_STEU_STEUER_VERPFL_MEHRAUFWD_DET where pk_STEU_STEUER_VERPFL_MEHRAUFWD_DET = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16352032177670570)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11861364582973974)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11853777714973931)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Verpflegungsmehraufwand'
);
wwv_flow_api.component_end;
end;
/
