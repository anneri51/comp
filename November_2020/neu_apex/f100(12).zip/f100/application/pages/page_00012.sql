prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'PROJEKT'
,p_alias=>'PROJEKT'
,p_step_title=>'PROJEKT'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200822100529'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(330549734758652)
,p_plug_name=>'Projektliste'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with jr_ as (select obj.*, rownum, 1950 + rownum jr from all_objects obj),',
'pr_ as (select jr_.*, proj.*, row_number() over (partition by pk_proj_projekt order by jr_.jr) rnr from jr_ left join t_proj_projekt proj on jr_.jr between substr(to_char(proj.von,''DD.MM.RRRR''),7,4) and substr(to_char(proj.bis,''DD.MM.RRRR''),7,4))',
'select ',
'    pr."PK_PROJ_PROJEKT", ',
'    pr."FK_KON_AUFTRAGGEBER",',
'    pr."FK_KON_PROJEKTPARTNER_1",',
'    pr."FK_KON_PROJEKTPARTNER_2",',
'    pr."FK_KON_PROJEKTPARTNER_3",',
'    pr."VON",',
'    pr."BIS",',
'    pr."AKTUELLER_STUNDENSATZ",',
'    pr."PSP_ELEMENT",',
'    pr."CREATED_BY",',
'    pr."CREATED_AT",',
'    pr."MODIFIED_BY",',
'    pr."MODIFIED_AT",',
'    pr.RECHNUNG_GESTELLT,',
'    pr.ZAHLUNG_ABGESCHLOSSEN,',
'    pr.BELEGE_ZUGEORDNET,',
'    pr.KM_GERECHNET,',
'    pr.PROJEKT_ABGESCHLOSSEN,',
'    prart.std_name projekt_art,',
'    length(pr.bild6) bild6,',
'    length(pr.bild7) bild7,',
'    substr(pr.von,7,2) von_jahr,',
'    substr(pr.bis,7,2) bis_jahr,',
'    --pr_.jr,',
'    pr1_.project_years, ',
'    pr.projektinhalte,',
'    pr.tools,',
'    pr.techn,',
'    pr.other,',
'    pr.referenzen,',
'    pr.flg_proj_referenzprojekt,',
'    pr.abschlussnote,',
'    pr.descr,',
'    pr.comm,',
'    pr.position,',
'    ''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':273:'' || V(''APP_SESSION'') || ''::NO:RP:P273_PK_PROJ_PROJEKT,P273_PROJEKT,P273_VON,P273_BIS:'' || pr.PK_PROJ_PROJEKT || '','' || pr.projekt || '','' || pr.von || '','' || pr.bis, P_C'
||'HECKSUM_TYPE => ''SESSION'') || ''">'' || Projekt || ''</a>''projekt',
'from (select * from "T_PROJ_PROJEKT"  where pk_proj_projekt = :P12_PK_proj_PROJEKT or :P12_PK_proj_PROJEKT is null) pr',
' left join (select * from t_std where fk_std_group = 523) prart on pr.fk_std_proj_projekt_art = prart.std_value',
' --left join pr_ on   pr_.pk_proj_projekt = pr.pk_proj_projekt',
' left join (select pk_proj_projekt, listagg(nvl(pr_.jr,0),'','') within group (order by pr_.pk_proj_projekt) project_years from pr_   where pr_.rnr <= 20 group by pk_proj_projekt) pr1_ on pr1_.pk_proj_projekt = pr.pk_proj_projekt',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(330819099758652)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:13:P13_PK_PROJEKT:#PK_PROJEKT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>9640954340179573
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(332496285758659)
,p_db_column_name=>'PROJEKT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Projekt'
,p_column_html_expression=>'<a href=''javascript:apex.navigation.dialog(''''''f?p=&APP_ID.:273:&SESSION.:::::'''''')''>#PROJEKT#</a>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(332921788758660)
,p_db_column_name=>'VON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(333353114758661)
,p_db_column_name=>'BIS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(333692081758661)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(334148717758662)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Psp Element'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(334486332758662)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(334889003758663)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(335315811758664)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(335760507758665)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5576907245533794)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Rechnung gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5577010409533795)
,p_db_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Zahlung abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5577149896533796)
,p_db_column_name=>'BELEGE_ZUGEORDNET'
,p_display_order=>43
,p_column_identifier=>'P'
,p_column_label=>'Belege zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5577180714533797)
,p_db_column_name=>'KM_GERECHNET'
,p_display_order=>53
,p_column_identifier=>'Q'
,p_column_label=>'Km gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5577327925533798)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>63
,p_column_identifier=>'R'
,p_column_label=>'Projekt abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7941151054463092)
,p_db_column_name=>'PROJEKT_ART'
,p_display_order=>73
,p_column_identifier=>'S'
,p_column_label=>'Projekt art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2587701224249009)
,p_db_column_name=>'BILD6'
,p_display_order=>83
,p_column_identifier=>'U'
,p_column_label=>'Bild6'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_PROJEKT:BILD6:PK_PROJEKT::::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2587849655249010)
,p_db_column_name=>'BILD7'
,p_display_order=>93
,p_column_identifier=>'V'
,p_column_label=>'Bild7'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_PROJEKT:BILD7:PK_PROJEKT::::::attachment::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3359150162738462)
,p_db_column_name=>'VON_JAHR'
,p_display_order=>103
,p_column_identifier=>'W'
,p_column_label=>'Von Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3359278969738463)
,p_db_column_name=>'BIS_JAHR'
,p_display_order=>113
,p_column_identifier=>'X'
,p_column_label=>'Bis Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3359619929738467)
,p_db_column_name=>'PROJECT_YEARS'
,p_display_order=>123
,p_column_identifier=>'AA'
,p_column_label=>'Project Years'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738299863482865)
,p_db_column_name=>'PROJEKTINHALTE'
,p_display_order=>133
,p_column_identifier=>'AB'
,p_column_label=>'Projektinhalte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738390146482866)
,p_db_column_name=>'TOOLS'
,p_display_order=>143
,p_column_identifier=>'AC'
,p_column_label=>'Tools'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738509612482867)
,p_db_column_name=>'TECHN'
,p_display_order=>153
,p_column_identifier=>'AD'
,p_column_label=>'Techn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738665692482868)
,p_db_column_name=>'OTHER'
,p_display_order=>163
,p_column_identifier=>'AE'
,p_column_label=>'Other'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738777731482869)
,p_db_column_name=>'REFERENZEN'
,p_display_order=>173
,p_column_identifier=>'AF'
,p_column_label=>'Referenzen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3738916363482871)
,p_db_column_name=>'ABSCHLUSSNOTE'
,p_display_order=>193
,p_column_identifier=>'AH'
,p_column_label=>'Abschlussnote'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3739028717482872)
,p_db_column_name=>'DESCR'
,p_display_order=>203
,p_column_identifier=>'AI'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3739169488482873)
,p_db_column_name=>'COMM'
,p_display_order=>213
,p_column_identifier=>'AJ'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3739240067482874)
,p_db_column_name=>'POSITION'
,p_display_order=>223
,p_column_identifier=>'AK'
,p_column_label=>'Position'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45388642263053879)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>233
,p_column_identifier=>'AO'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45388759072053880)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>243
,p_column_identifier=>'AP'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45388848224053881)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>253
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45388919427053882)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>263
,p_column_identifier=>'AR'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389027721053883)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_3'
,p_display_order=>273
,p_column_identifier=>'AS'
,p_column_label=>'Fk Kon Projektpartner 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389224598053885)
,p_db_column_name=>'FLG_PROJ_REFERENZPROJEKT'
,p_display_order=>283
,p_column_identifier=>'AU'
,p_column_label=>'Flg Proj Referenzprojekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(337963308759250)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'96481'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PROJEKT_ART:PROJEKT:VON:BIS:ABSCHLUSSNOTE:BILD6:BILD7:DESCR:COMM:POSITION:PROJEKTINHALTE:TOOLS:TECHN:OTHER:REFERENZEN:VON_JAHR:BIS_JAHR:PROJECT_YEARS:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:RECHNUNG_GESTELLT:ZA'
||'HLUNG_ABGESCHLOSSEN:BELEGE_ZUGEORDNET:KM_GERECHNET:PROJEKT_ABGESCHLOSSEN:PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2:FK_KON_PROJEKTPARTNER_3:FLG_PROJ_REFERENZPROJEKT'
,p_sort_column_1=>'VON'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3768912219386227)
,p_report_id=>wwv_flow_api.id(337963308759250)
,p_name=>'Zahlung_abgeschlossen'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("PROJEKT_ABGESCHLOSSEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#C5EDC5'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3769297007386228)
,p_report_id=>wwv_flow_api.id(337963308759250)
,p_name=>'zahlung_abgeschlossen'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZAHLUNG_ABGESCHLOSSEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11261400999747228)
,p_application_user=>'ANNE'
,p_name=>'2018'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'PROJEKT_ART:PROJEKT:VON:BIS:ABSCHLUSSNOTE:BILD6:BILD7:DESCR:COMM:POSITION:PROJEKTINHALTE:TOOLS:TECHN:OTHER:REFERENZEN:VON_JAHR:BIS_JAHR:PROJECT_YEARS:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:RECHNUNG_GESTELLT:ZA'
||'HLUNG_ABGESCHLOSSEN:BELEGE_ZUGEORDNET:KM_GERECHNET:PROJEKT_ABGESCHLOSSEN'
,p_sort_column_1=>'VON'
,p_sort_direction_1=>'ASC'
,p_break_on=>'PK_PROJEKT:PROJEKT'
,p_break_enabled_on=>'PK_PROJEKT:PROJEKT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11262506725781199)
,p_report_id=>wwv_flow_api.id(11261400999747228)
,p_name=>'Zahlung_abgeschlossen'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("PROJEKT_ABGESCHLOSSEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#C5EDC5'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11262649398781199)
,p_report_id=>wwv_flow_api.id(11261400999747228)
,p_name=>'zahlung_abgeschlossen'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZAHLUNG_ABGESCHLOSSEN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11262324223781199)
,p_report_id=>wwv_flow_api.id(11261400999747228)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PROJECT_YEARS'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"PROJECT_YEARS" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''2018''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11262463454781199)
,p_report_id=>wwv_flow_api.id(11261400999747228)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PROJEKT_ART'
,p_operator=>'in'
,p_expr=>unistr('Arbeit - Festanstellung,Arbeit - Selbst\00E4ndigkeit')
,p_condition_sql=>'"PROJEKT_ART" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>unistr('#APXWS_COL_NAME# #APXWS_OP_NAME# ''Arbeit - Festanstellung, Arbeit - Selbst\00E4ndigkeit''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3120472767866589)
,p_plug_name=>'steuerlich'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select proj.*,',
'auftr.PK_KON_GESCHAEFTSPARTNER	auftr_PK_KON_GESCHAEFTSPA,',
'auftr.GESCHAEFTSPARTNER	auftr_GESCHAEFTSPARTN,',
'auftr.FK_BAS_KON_GESCHAEFTSPARTNERTYP	auftr_FK_BAS_KON_GESCHAEFTSPA,',
'auftr.PK_ADR_ADRESSE	auftr_PK_ADR_ADRESSE,',
'auftr.STRASSE	auftr_STRASSE,',
'auftr.HSNR	auftr_HSNR,',
'auftr.PLZ	auftr_PLZ,',
'auftr.ORT	auftr_ORT,',
'auftr.LAND	auftr_LAND,',
'auftr.BESCHREIBUNG	auftr_BESCHREIBUNG,',
'projp1.PK_KON_GESCHAEFTSPARTNER	projp1_PK_KON_GESCHAEFTSPARTNER,',
'projp1.GESCHAEFTSPARTNER	projp1_GESCHAEFTSPARTNER,',
'projp1.FK_BAS_KON_GESCHAEFTSPARTNERTYP	projp1_FK_BAS_KON_GESCHAEFTSPARTNER_TYP,',
'projp1.PK_ADR_ADRESSE	projp1_PK_ADR_ADRESSE,',
'projp1.STRASSE	projp1_STRASSE,',
'projp1.HSNR	projp1_HSNR,',
'projp1.PLZ	projp1_PLZ,',
'projp1.ORT	projp1_ORT,',
'projp1.LAND	projp1_LAND,',
'projp1.BESCHREIBUNG	projp1_BESCHREIBUNG,',
'projp2.PK_KON_GESCHAEFTSPARTNER	projp2_PK_KON_GESCHAEFTSPARTNER,',
'projp2.GESCHAEFTSPARTNER	projp2_GESCHAEFTSPARTNER,',
'projp2.FK_BAS_KON_GESCHAEFTSPARTNERTYP	projp2_FK_BAS_KON_GESCHAEFTSPARTNER_TYP,',
'projp2.PK_ADR_ADRESSE	projp2_PK_aDR_ADRESSE,',
'projp2.STRASSE	projp2_STRASSE,',
'projp2.HSNR	projp2_HSNR,',
'projp2.PLZ	projp2_PLZ,',
'projp2.ORT	projp2_ORT,',
'projp2.LAND	projp2_LAND,',
'projp2.BESCHREIBUNG	projp2_BESCHREIBUNG',
'',
'from ',
'(',
'    select ',
'    2017 Jahr,',
'    "PK_PROJ_PROJEKT", ',
'    "FK_KON_AUFTRAGGEBER",',
'    "FK_KON_PROJEKTPARTNER_1",',
'    "FK_KON_PROJEKTPARTNER_2",',
'    "PROJEKT",',
'    case when "VON" < to_date(''01.01.2017'',''DD.MM.YYYY'') then  to_date(''01.01.2017'',''DD.MM.YYYY'') else "VON" end "VON",',
'    case when "BIS" > to_date(''31.12.2017'',''DD.MM.YYYY'') then  to_date(''31.12.2017'',''DD.MM.YYYY'') else "BIS" end "BIS",',
'    "AKTUELLER_STUNDENSATZ",',
'    "PSP_ELEMENT",',
'    "CREATED_BY",',
'    "CREATED_AT",',
'    "MODIFIED_BY",',
'    "MODIFIED_AT"',
'    from T_PROJ_PROJEKT',
'    where bis >= to_date(''01.01.2017'', ''DD.MM.YYYY'') and von <= to_date(''31.12.2017'', ''DD.MM.YYYY'')',
'    union',
'    select ',
'    2018 Jahr,',
'    "PK_PROJ_PROJEKT", ',
'    "FK_KON_AUFTRAGGEBER",',
'    "FK_KON_PROJEKTPARTNER_1",',
'    "FK_KON_PROJEKTPARTNER_2",',
'    "PROJEKT",',
'    case when "VON" < to_date(''01.01.2018'',''DD.MM.YYYY'') then  to_date(''01.01.2018'',''DD.MM.YYYY'') else "VON" end "VON",',
'    case when "BIS" > to_date(''31.12.2018'',''DD.MM.YYYY'') then  to_date(''31.12.2018'',''DD.MM.YYYY'') else "BIS" end "BIS",',
'    "AKTUELLER_STUNDENSATZ",',
'    "PSP_ELEMENT",',
'    "CREATED_BY",',
'    "CREATED_AT",',
'    "MODIFIED_BY",',
'    "MODIFIED_AT"',
'    from T_PROJ_PROJEKT',
'    where bis >= to_date(''01.01.2018'', ''DD.MM.YYYY'') and von <= to_date(''31.12.2018'', ''DD.MM.YYYY'')',
' ) proj',
' left join v_kon_geschaeftspartner auftr on auftr.pk_kon_geschaeftspartner = proj."FK_KON_AUFTRAGGEBER"',
' left join v_kon_geschaeftspartner projp1 on projp1.pk_kon_geschaeftspartner = proj."FK_KON_PROJEKTPARTNER_1"',
' left join v_kon_geschaeftspartner projp2 on projp2.pk_kon_geschaeftspartner = proj."FK_KON_PROJEKTPARTNER_2"',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3120642422866590)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>12430777663287511
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121162964866595)
,p_db_column_name=>'PROJEKT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121212541866596)
,p_db_column_name=>'VON'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121351512866597)
,p_db_column_name=>'BIS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121440497866598)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Aktueller stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121539131866599)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Psp element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121572249866600)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121671680866601)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121841159866602)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3121948485866603)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122061250866604)
,p_db_column_name=>'JAHR'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122220292866606)
,p_db_column_name=>'AUFTR_GESCHAEFTSPARTN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Auftr geschaeftspartn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122495434866609)
,p_db_column_name=>'AUFTR_STRASSE'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Auftr strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122578998866610)
,p_db_column_name=>'AUFTR_HSNR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Auftr hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122760758866611)
,p_db_column_name=>'AUFTR_PLZ'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Auftr plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122810843866612)
,p_db_column_name=>'AUFTR_ORT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Auftr ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3122940800866613)
,p_db_column_name=>'AUFTR_LAND'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Auftr land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123029894866614)
,p_db_column_name=>'AUFTR_BESCHREIBUNG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Auftr beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123535270866619)
,p_db_column_name=>'PROJP1_STRASSE'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Projp1 strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123572729866620)
,p_db_column_name=>'PROJP1_HSNR'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Projp1 hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123670962866621)
,p_db_column_name=>'PROJP1_PLZ'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Projp1 plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123840429866622)
,p_db_column_name=>'PROJP1_ORT'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Projp1 ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3123923028866623)
,p_db_column_name=>'PROJP1_LAND'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Projp1 land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3124043596866624)
,p_db_column_name=>'PROJP1_BESCHREIBUNG'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Projp1 beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3124557429866629)
,p_db_column_name=>'PROJP2_STRASSE'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Projp2 strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3657421495780780)
,p_db_column_name=>'PROJP2_HSNR'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Projp2 hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3657468224780781)
,p_db_column_name=>'PROJP2_PLZ'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Projp2 plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3657647123780782)
,p_db_column_name=>'PROJP2_ORT'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Projp2 ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3657667132780783)
,p_db_column_name=>'PROJP2_LAND'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Projp2 land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3657862810780784)
,p_db_column_name=>'PROJP2_BESCHREIBUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Projp2 beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389334502053886)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389384086053887)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389564049053888)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389633872053889)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389695823053890)
,p_db_column_name=>'AUFTR_PK_KON_GESCHAEFTSPA'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Auftr Pk Kon Geschaeftspa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389802972053891)
,p_db_column_name=>'AUFTR_FK_BAS_KON_GESCHAEFTSPA'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Auftr Fk Bas Kon Geschaeftspa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389901971053892)
,p_db_column_name=>'AUFTR_PK_ADR_ADRESSE'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Auftr Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45389990823053893)
,p_db_column_name=>'PROJP1_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Projp1 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390157594053894)
,p_db_column_name=>'PROJP1_GESCHAEFTSPARTNER'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Projp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390244703053895)
,p_db_column_name=>'PROJP1_FK_BAS_KON_GESCHAEFTSPARTNER_TYP'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Projp1 Fk Bas Kon Geschaeftspartner Typ'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390290319053896)
,p_db_column_name=>'PROJP1_PK_ADR_ADRESSE'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Projp1 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390386165053897)
,p_db_column_name=>'PROJP2_PK_KON_GESCHAEFTSPARTNER'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Projp2 Pk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390507161053898)
,p_db_column_name=>'PROJP2_GESCHAEFTSPARTNER'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Projp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390679938053899)
,p_db_column_name=>'PROJP2_FK_BAS_KON_GESCHAEFTSPARTNER_TYP'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Projp2 Fk Bas Kon Geschaeftspartner Typ'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45390778242053900)
,p_db_column_name=>'PROJP2_PK_ADR_ADRESSE'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Projp2 Pk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3655841561464567)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'129660'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:JAHR:AUFTR_GESCHAEFTSPARTN:AUFTR_STRASSE:AUFTR_HSNR:AUFTR_PLZ:AUFTR_ORT:AUFTR_LAND:AUFTR_BESCHREIBUNG:PROJP1_STRASSE:PROJP1_HSNR:PROJP1_PLZ:PROJP1_ORT:PRO'
||'JP1_LAND:PROJP1_BESCHREIBUNG:PROJP2_STRASSE:PROJP2_HSNR:PROJP2_PLZ:PROJP2_ORT:PROJP2_LAND:PROJP2_BESCHREIBUNG:PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2:AUFTR_PK_KON_GESCHAEFTSPA:AUFTR_FK_BAS_KON_GESCHAEFTSPA:'
||'AUFTR_PK_ADR_ADRESSE:PROJP1_PK_KON_GESCHAEFTSPARTNER:PROJP1_GESCHAEFTSPARTNER:PROJP1_FK_BAS_KON_GESCHAEFTSPARTNER_TYP:PROJP1_PK_ADR_ADRESSE:PROJP2_PK_KON_GESCHAEFTSPARTNER:PROJP2_GESCHAEFTSPARTNER:PROJP2_FK_BAS_KON_GESCHAEFTSPARTNER_TYP:PROJP2_PK_ADR'
||'_ADRESSE'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3740143819482883)
,p_plug_name=>'Projektliste'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(45465528466025968)
,p_plug_name=>'Projektliste'
,p_parent_plug_id=>wwv_flow_api.id(3740143819482883)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with jr_ as (select obj.*, rownum, 1950 + rownum jr from all_objects obj),',
'pr_ as (select jr_.*, proj.*, row_number() over (partition by pk_proj_projekt order by jr_.jr) rnr from jr_ left join t_proj_projekt proj on jr_.jr between substr(to_char(proj.von,''DD.MM.RRRR''),7,4) and substr(to_char(proj.bis,''DD.MM.RRRR''),7,4))',
'select ',
'    pr."PK_PROJ_PROJEKT", ',
'    pr."FK_KON_AUFTRAGGEBER",',
'    pr."FK_KON_PROJEKTPARTNER_1",',
'    pr."FK_KON_PROJEKTPARTNER_2",',
'    pr."FK_KON_PROJEKTPARTNER_3",',
'    pr."VON",',
'    pr."BIS",',
'    pr."AKTUELLER_STUNDENSATZ",',
'    pr."PSP_ELEMENT",',
'    pr."CREATED_BY",',
'    pr."CREATED_AT",',
'    pr."MODIFIED_BY",',
'    pr."MODIFIED_AT",',
'    pr.RECHNUNG_GESTELLT,',
'    pr.ZAHLUNG_ABGESCHLOSSEN,',
'    pr.BELEGE_ZUGEORDNET,',
'    pr.KM_GERECHNET,',
'    pr.PROJEKT_ABGESCHLOSSEN,',
'    prart.std_name projekt_art,',
'    length(pr.bild6) bild6,',
'    length(pr.bild7) bild7,',
'    substr(pr.von,7,2) von_jahr,',
'    substr(pr.bis,7,2) bis_jahr,',
'    --pr_.jr,',
'    pr1_.project_years, ',
'    pr.projektinhalte,',
'    pr.tools,',
'    pr.techn,',
'    pr.other,',
'    pr.referenzen,',
'    pr.flg_proj_referenzprojekt,',
'    pr.abschlussnote,',
'    pr.descr,',
'    pr.comm,',
'    pr.position,',
'    ''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':273:'' || V(''APP_SESSION'') || ''::NO:RP:P273_PK_proj_PROJEKT,P273_PROJEKT,P273_VON,P273_BIS:'' || pr.PK_proj_PROJEKT || '','' || pr.projekt || '','' || pr.von || '','' || pr.bis, P_C'
||'HECKSUM_TYPE => ''SESSION'') || ''">'' || Projekt || ''</a>''projekt',
'from (select * from "T_PROJ_PROJEKT"  where pk_proj_projekt = :P12_PK_PROJ_PROJEKT or :P12_PK_PROJ_PROJEKT is null',
'     ) pr',
' left join (select * from t_std where fk_std_group = 523) prart on pr.fk_std_proj_projekt_art = prart.std_value',
' --left join pr_ on   pr_.pk_projekt = pr.pk_projekt',
' left join (select pk_proj_projekt, listagg(nvl(pr_.jr,0),'','') within group (order by pr_.pk_proj_projekt) project_years from pr_   where pr_.rnr <= 20 group by pk_proj_projekt) pr1_ on pr1_.pk_proj_projekt = pr.pk_proj_projekt',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(45465595278025969)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:13:P13_PK_PROJ_PROJEKT:#PK_PROJ_PROJEKT##PK_PROJEKT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>46905914553417509
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45465845364025971)
,p_db_column_name=>'PROJEKTINHALTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Projektinhalte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45465909476025972)
,p_db_column_name=>'TOOLS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tools'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466011960025973)
,p_db_column_name=>'TECHN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Techn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466159300025974)
,p_db_column_name=>'OTHER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Other'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466212766025975)
,p_db_column_name=>'REFERENZEN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Referenzen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466307531025976)
,p_db_column_name=>'ABSCHLUSSNOTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Abschlussnote'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466428297025977)
,p_db_column_name=>'DESCR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466493486025978)
,p_db_column_name=>'COMM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466605252025979)
,p_db_column_name=>'POSITION'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Position'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466738493025980)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466848082025981)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45466951418025982)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467043656025983)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467142965025984)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_3'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Kon Projektpartner 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467216151025985)
,p_db_column_name=>'FLG_PROJ_REFERENZPROJEKT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Flg Proj Referenzprojekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467317445025986)
,p_db_column_name=>'PROJEKT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Projekt'
,p_column_html_expression=>'<a href=''javascript:apex.navigation.dialog(''''''f?p=&APP_ID.:273:&SESSION.:::::'''''')''>#PROJEKT#</a>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467450439025987)
,p_db_column_name=>'VON'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467573860025988)
,p_db_column_name=>'BIS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467641213025989)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467764864025990)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Psp Element'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467854645025991)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45467887521025992)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468030843025993)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468173088025994)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468240363025995)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Rechnung gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468289396025996)
,p_db_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Zahlung abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468441514025997)
,p_db_column_name=>'BELEGE_ZUGEORDNET'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Belege zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468486634025998)
,p_db_column_name=>'KM_GERECHNET'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Km gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45468591353025999)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Projekt abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543354856570178)
,p_db_column_name=>'PROJEKT_ART'
,p_display_order=>310
,p_column_identifier=>'BF'
,p_column_label=>'Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543409348570179)
,p_db_column_name=>'BILD6'
,p_display_order=>320
,p_column_identifier=>'BG'
,p_column_label=>'Bild6'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543538967570180)
,p_db_column_name=>'BILD7'
,p_display_order=>330
,p_column_identifier=>'BH'
,p_column_label=>'Bild7'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543667567570181)
,p_db_column_name=>'VON_JAHR'
,p_display_order=>340
,p_column_identifier=>'BI'
,p_column_label=>'Von Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543727758570182)
,p_db_column_name=>'BIS_JAHR'
,p_display_order=>350
,p_column_identifier=>'BJ'
,p_column_label=>'Bis Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45543877616570183)
,p_db_column_name=>'PROJECT_YEARS'
,p_display_order=>360
,p_column_identifier=>'BK'
,p_column_label=>'Project Years'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(45540854566557138)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'469812'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJEKTINHALTE:TOOLS:TECHN:OTHER:REFERENZEN:ABSCHLUSSNOTE:DESCR:COMM:POSITION:PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2:FK_KON_PROJEKTPARTNER_3:FLG_PROJ_REFERENZPROJEKT:PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:P'
||'SP_ELEMENT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:RECHNUNG_GESTELLT:ZAHLUNG_ABGESCHLOSSEN:BELEGE_ZUGEORDNET:KM_GERECHNET:PROJEKT_ABGESCHLOSSEN67:FK_STD_PROJ_FK_LEHR_LEHRGANG:PROJEKT_ART:VON_JAHR:BIS_JAHR:PROJECT_YEARS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(45469263930026005)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18465968487563915)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(45469263930026005)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::P13_PK_PROJ_PROJEKT:'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3740267016482884)
,p_name=>'P12_PK_PROJ_PROJEKT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(45469263930026005)
,p_prompt=>'PK_PROJ_PROJEKT'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(45465347479025966)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(330549734758652)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(45465422054025967)
,p_event_id=>wwv_flow_api.id(45465347479025966)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_PK_PROJ_PROJEKT'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13557068243839676)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_kasse_rel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' declare ',
'  v_seq_kas number;',
'  v_fk_main_key_kas number;',
'  v_relation varchar(4000 char);',
' begin',
' ',
' --v_relation selektieren',
'    v_relation:= ''2018/152/0'';',
' ',
' --neue Kassenbuchung erzeugen - aus Lex_Buchung',
'   select KAS_KASSE_SEQ.nextval',
'   into v_seq_kas',
'   from dual;',
' ',
' ',
' insert into kas_kasse (pk_kas_kasse,datum, buchungstext, betrag, jahr, comm) ',
' select v_seq_kas,belegdatum, buchungstext,nvl(sollbetrag_eur,0) - nvl(habenbetrag_eur,0) , jahr, fk_relation from imp_kontenblatt_2018 where fk_relation = 	v_relation and kontonummer = ''01600'';',
'commit;',
'',
'',
'--Kassenbuchung updaten (Arbeitstag, Kontonummer, kontotyp, fk_main_key)',
'update Kas_Kasse set FK_MAIN_KEY = KTO_KONTO_SEQ.nextval where fk_main_key is null;',
'   ',
'merge into kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from kas_kasse kas',
' left join v_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'    ',
'merge into kas_kasse t1',
'  using (',
'        select pk_arbeitstage, ',
'       pk_kas_kasse',
'',
'        from (select * from kas_kasse where datum is not null and fk_arbeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kas_kasse = t2.pk_kas_kasse)',
'        when matched then',
'        update set t1.fk_arbeitstag= t2.pk_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update kas_kasse set fk_konto = 61 where fk_konto is null;',
'   update kas_kasse set fk_kontotyp = 6 where fk_kontotyp is null;',
'   update kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'   ',
'  --Kassenbuchung - Lexwarebuchung zuordnen ',
'   select fk_main_key',
'   into  v_fk_main_key_kas',
'   from kas_kasse',
'   where instr(comm, v_relation)>0;',
'   ',
'   insert into t_rel_lex_kto_bel (fk_main_key, fk_relation)',
'   select v_fk_main_key_kas, v_relation',
'   from dual;',
'   commit;',
'end;',
'',
'',
'',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
