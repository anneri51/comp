prompt --application/pages/page_00082
begin
--   Manifest
--     PAGE: 00082
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>82
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 8'
,p_alias=>'STEP-83'
,p_step_title=>'Step 8'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <meta name="viewport" content="initial-scale=1.0, width=device-width" />',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-core.js"',
'  type="text/javascript" charset="utf-8"></script>',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-service.js"',
'  type="text/javascript" charset="utf-8"></script>'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var v_ctr_lat = document.getElementById(''P82_CTR_LAT'').value;',
'var v_ctr_lng = document.getElementById(''P82_CTR_LNG'').value;',
'',
'var v_wp0_str =''geo!55.1120423728813,8.68340740740811'';',
'var v_wp1_str =''geo!57.5309916298853,13.3846220493377'';',
'var v_wp2_str =''geo!59.5309916298853,13.3846220493377'';',
'',
'',
'',
'// Instantiate a map and platform object:',
'var platform = new H.service.Platform({',
'  ''app_id'': ''hU8C4hi5HZZAA29CN1h5'',',
'  ''app_code'': ''no8qak0DOkDF8O_oi1xqaw''',
'});',
'',
'',
'',
'// Retrieve the target element for the map:',
'var targetElement = document.getElementById(''mapContainer'');',
'',
'// Get the default map types from the platform object:',
'var defaultLayers = platform.createDefaultLayers();',
'',
'// Instantiate the map:',
'var map = new H.Map(',
'  document.getElementById(''mapContainer''),',
'  defaultLayers.normal.map,',
'  {',
'  zoom: 8,',
'  center: { lat:  v_ctr_lat, lng: v_ctr_lng }',
'  });',
'',
'',
'',
'// Create the parameters for the routing request:',
'var routingParameters = {',
'  // The routing mode:',
'  ''mode'': ''fastest;car'',',
'  // The start point of the route:',
'   ''waypoint0'': v_wp0_str,',
'  // The end point of the route:',
'  ''waypoint1'':  v_wp1_str,',
'      ',
'  // To retrieve the shape of the route we choose the route',
'  // representation mode ''display''',
'  ''representation'': ''display''',
'};',
'',
'var routingParameters1 = {',
'  // The routing mode:',
'  ''mode'': ''fastest;car'',',
'  // The start point of the route:',
'   ''waypoint0'': v_wp1_str,',
'  // The end point of the route:',
'  ''waypoint1'':  v_wp2_str,',
'  // To retrieve the shape of the route we choose the route',
'  // representation mode ''display''',
'  ''representation'': ''display''',
'};',
'',
'',
'',
'// Define a callback function to process the routing response:',
'var onResult = function(result) {',
'  var route,',
'    routeShape,',
'    startPoint,',
'    endPoint,',
'    linestring;',
'  if(result.response.route) {',
'  // Pick the first route from the response:',
'  route = result.response.route[0];',
'  // Pick the route''s shape:',
'  routeShape = route.shape;',
'      ',
'',
'',
'  // Create a linestring to use as a point source for the route line',
'  linestring = new H.geo.LineString();',
'',
'',
'  // Push all the points in the shape into the linestring:',
'  routeShape.forEach(function(point) {',
'    var parts = point.split('','');',
'    linestring.pushLatLngAlt(parts[0], parts[1]);',
'  });',
'',
'      ',
'    ',
'      ',
'  // Retrieve the mapped positions of the requested waypoints:',
'  startPoint = route.waypoint[0].mappedPosition;',
'  endPoint = route.waypoint[1].mappedPosition;',
'',
'    ',
'',
'',
'  // Create a polyline to display the route:',
'  routeLine = new H.map.Polyline(linestring, {',
'    style: { strokeColor: ''blue'', lineWidth: 10 }',
'  });',
'',
'',
'      ',
'',
'',
'',
'  }',
'};',
'',
'// Get an instance of the routing service:',
'var router = platform.getRoutingService();',
'',
'// Call calculateRoute() with the routing parameters,',
'// the callback and an error callback function (called if a',
'// communication error occurs):',
'',
'',
'',
'',
'router.calculateRoute(routingParameters, onResult,',
'  function(error) {',
'    alert(error.message);',
'  });',
'',
'alert(',
'    lng: startPoint.longitude',
');',
'  // Create a marker for the start point:',
'  startMarker = new H.map.Marker({',
'    lat: startPoint.latitude,',
'    lng: startPoint.longitude',
'  });',
'     ',
'',
'  // Create a marker for the end point:',
'  endMarker = new H.map.Marker({',
'    lat: endPoint.latitude,',
'    lng: endPoint.longitude',
'  });',
'',
'',
'  // Add the route polyline and the two markers to the map:',
'  map.addObjects([routeLine, startMarker, endMarker]);',
'',
'',
'',
'  ',
'',
'  // Set the map''s viewport to make the whole route visible:',
'  map.setViewBounds(routeLine.getBounds());',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200822164216'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8130861801214180)
,p_plug_name=>'Step 8'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8101658331214164)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8130963833214180)
,p_plug_name=>'Step 8'
,p_parent_plug_id=>wwv_flow_api.id(8130861801214180)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33902366831511453)
,p_plug_name=>'Route'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'width="50"'
,p_plug_display_point=>'BODY'
,p_plug_source=>' <div style="width: 640px; height: 480px" id="mapContainer">test2</div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'font-size:24px;'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8132696093214181)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8130861801214180)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8132965958214181)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8130861801214180)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8132851118214181)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8130861801214180)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8134382728214182)
,p_branch_action=>'f?p=&APP_ID.:83:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8132965958214181)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8133669292214181)
,p_branch_action=>'f?p=&APP_ID.:81:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8132851118214181)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1741759305364786)
,p_name=>'P82_CTR_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33902366831511453)
,p_prompt=>'Ctr lat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1742085875364786)
,p_name=>'P82_CTR_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33902366831511453)
,p_prompt=>'Ctr lng'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8132328593214181)
,p_name=>'P82_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8130963833214180)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1742502505364787)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :P82_CTR_LAT := 54.13;',
'  :P82_CTR_LNG := 10.13;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
