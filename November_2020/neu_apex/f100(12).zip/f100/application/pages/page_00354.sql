prompt --application/pages/page_00354
begin
--   Manifest
--     PAGE: 00354
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>354
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15355311479107672)
,p_plug_name=>'calc_ausl_steuer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with betr as (select replace(:P354_x,''%2C'','','') betr from dual)',
'select ',
'                                    round((betr*1.5/100),2) Betrag_15,',
'                                    round((betr*1.75/100),2) Betrag_175,',
'                                    round(betr*100/1.5,2) betrag_100_15,',
'                                   round(betr*100/1.75,2) betrag_100_175,',
'                                 betr',
'                             from betr'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15355389633107672)
,p_name=>'calc_ausl_steuer'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>16795708908499212
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15355862451107680)
,p_db_column_name=>'BETRAG_15'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Betrag 15'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15356212904107695)
,p_db_column_name=>'BETRAG_175'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Betrag 175'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15356632140107695)
,p_db_column_name=>'BETRAG_100_15'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Betrag 100 15'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15357004974107695)
,p_db_column_name=>'BETRAG_100_175'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Betrag 100 175'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15219761007119285)
,p_db_column_name=>'BETR'
,p_display_order=>14
,p_column_identifier=>'G'
,p_column_label=>'Betr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15359979563139867)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'168003'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BETR:BETRAG_100_15:BETRAG_100_175:BETRAG_15:BETRAG_175:'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15219339290119281)
,p_name=>'P354_X'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15355311479107672)
,p_prompt=>'X'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
