prompt --application/pages/page_00038
begin
--   Manifest
--     PAGE: 00038
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>38
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Inventar'
,p_alias=>'INVENTAR2'
,p_step_title=>'Inventar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200915194452'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6788683473304616)
,p_plug_name=>'Inventar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    inv."PK_INV_INVENTAR", ',
'    "INVENTAR",',
'    "ANSCHAFFUNGSDATUM",',
'    "ANSCHAFFUNGSJAHR",',
'    "ABSCHREIBUNGSDAUER",',
'  anschaffungswert,',
'    inv."CREATED_BY",',
'    inv."CREATED_AT",',
'    inv."MODIFIED_BY",',
'    inv."MODIFIED_AT",',
'    PREIS_NETTO,',
'    MWST,',
'   -- mwst_satz,',
'    PREIS_BRUTTO,',
'    inv.COMM,',
'    LIZENZNUMMER,',
'    ANFORDERUNGSCODE,',
'    FK_bas_INV_INVENTARTYP,',
'    KFZ_KENNZEICHEN,',
'    FAHRGESTELLNR,',
'    BEMERKUNGEN,',
'    ABGANGSJAHR,',
'    ABGANGSDATUM,',
'    ABGANGSWERT,',
'    verw.std_value FK_BAS_STD_VERWENDUNGSZWECK,',
'    GWG,',
'    RESTBUCHWERT_2017,',
'     RESTBUCHWERT_2018,',
'      RESTBUCHWERT_2019,',
'       RESTBUCHWERT_2020,',
'    ABGANGSGRUND,',
'    MAC_ADRESSE,',
'    SERIENNUMMER,',
'    length(bild) bild,',
'    case when anschaffungsjahr is null or anschaffungsjahr <2017 then ''(a) <b>vor 2017</b>''',
'         when anschaffungsjahr = 2017 then ''(b) in <b>2017</b>''',
'         when anschaffungsjahr = 2018 then ''(c) in <b>2018</b>''',
'         when anschaffungsjahr = 2019 then ''(d) in <b>2019</b>''',
'    end zugang,',
'    case when (anschaffungsjahr is null or anschaffungsjahr <2017) and (abgangsjahr <= 2017) then ''(a) <b>vor 2017</b>'' ',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2017 ) then ''(b1) <b>2017</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2018) then ''(b2) <b>2017 - 2018</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2019)  then ''(b3) <b>2017 - 2019</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr is null)  then ''(b4) <b>2017 - 2019</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr = 2018) then ''(c1) in <b>2018</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr = 2019) then ''(c2) in <b>2018 - 2019</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr is null) then ''(c3) in <b>2018 - 2019</b>''',
'         when anschaffungsjahr = 2019 and (abgangsjahr = 2019 ) then ''(d1) in <b>2019</b>''',
'         when anschaffungsjahr = 2019 and (abgangsjahr is null) then ''(d1) in <b>2019</b>''',
'    end periode,',
'    case when (anschaffungsjahr is null or anschaffungsjahr < 2017) and (abgangsjahr <2017) then ''(a) <b>bis 2017</b>'' ',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2017) then ''(b) in <b>2017</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2018) and (abgangsjahr = 2018) then ''(c) in <b>2018</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2019) and (abgangsjahr = 2019) then ''(d) in <b>2019</b>''',
'         else ''(z) <b>kein Abgang</b>''',
'    end abgang,',
'    invtyp.inventartyp,',
'    inv.geraetename,',
'    el.einzel_GWG,',
'    inv.ok,',
'    inv.ok_bemerkungen,',
'    verw.std_name verwendungszweck,',
'    case ',
'         when gwg = 1 then ''GWG''',
'         when gwg = 2 then ''kein GWG''',
'         when gwg = 3 then ''unsicher''',
'         when gwg = 0 then ''Keine Angabe''',
'         else ''unbekannt''',
'     end gwg_ja_nein,',
'     length(inv.inv_bild) inv_bild,',
'     inv.FK_BAS_STEU_STEUER_SATZ,',
'     inv.fk_kon_hersteller,',
'     vtm.baureihe,',
'     vtm.modell_no',
'from T_INV_INVENTARE inv',
' left join t_bas_inv_inventartyp invtyp on inv.fk_bas_inv_inventartyp = invtyp.pk_bas_inv_inventartyp',
' left join (',
'      select pk_inv_inventar, listagg(''('' || pk_inv_sub_elektronik || '') <b>'' || bezeichnung, ''</b><br>===<br>'') within group (order by bezeichnung) einzel_GWG',
'  from t_inv_inventare inv',
'   join t_inv_sub_elektronik el on inv.pk_inv_inventar = el.fk_Inv_inventar',
'where instr(inventar, ''GWG'')>0',
'group by pk_inv_inventar',
' ',
' ) el on el.pk_inv_inventar = inv.pk_inv_inventar',
' left join (select * from t_std where fk_std_group = 9) verw on verw.std_value = inv.fk_std_verw_verwendungszweck',
' left join  v_typ_modell vtm on vtm.pk_rel_typ_hersteller_baureihe_modell = inv.fk_rel_typ_hersteller_baureihe_modell',
'',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6789072596304617)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::P39_PK_INV_INVENTAR:#PK_INV_INVENTAR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6789072596304617
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6789500194304640)
,p_db_column_name=>'INVENTAR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Inventar'
,p_column_link=>'f?p=&APP_ID.:455:&SESSION.::&DEBUG.::P455_PK_INV_INVENTAR:#PK_INV_INVENTAR#'
,p_column_linktext=>'#INVENTAR#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6789963824304642)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6790311661304642)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6790701642304643)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6791525028304644)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6791949855304645)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6792399248304645)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6792739767304646)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481076615829910)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Preis netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481209628829911)
,p_db_column_name=>'MWST'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481459511829913)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481473399829914)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481581350829915)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481742233829916)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481944346829918)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>100
,p_column_identifier=>'S'
,p_column_label=>'Kfz kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481970871829919)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>110
,p_column_identifier=>'T'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7260371093439903)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>120
,p_column_identifier=>'U'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7260532107439904)
,p_db_column_name=>'BILD'
,p_display_order=>130
,p_column_identifier=>'V'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_INVENTARE:BILD:PK_INVENTAR::::::inline::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7679657851003304)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>140
,p_column_identifier=>'W'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7679749016003305)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>150
,p_column_identifier=>'X'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7679816716003306)
,p_db_column_name=>'ABGANGSDATUM'
,p_display_order=>160
,p_column_identifier=>'Y'
,p_column_label=>'Abgangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7679937057003307)
,p_db_column_name=>'ABGANGSWERT'
,p_display_order=>170
,p_column_identifier=>'Z'
,p_column_label=>'Abgangswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680141304003309)
,p_db_column_name=>'GWG'
,p_display_order=>190
,p_column_identifier=>'AB'
,p_column_label=>'Gwg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680254409003310)
,p_db_column_name=>'RESTBUCHWERT_2017'
,p_display_order=>200
,p_column_identifier=>'AC'
,p_column_label=>'Restbuchwert 2017'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680351875003311)
,p_db_column_name=>'ABGANGSGRUND'
,p_display_order=>210
,p_column_identifier=>'AD'
,p_column_label=>'Abgangsgrund'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680464051003312)
,p_db_column_name=>'MAC_ADRESSE'
,p_display_order=>220
,p_column_identifier=>'AE'
,p_column_label=>'Mac adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680464981003313)
,p_db_column_name=>'SERIENNUMMER'
,p_display_order=>230
,p_column_identifier=>'AF'
,p_column_label=>'Seriennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680601780003314)
,p_db_column_name=>'ZUGANG'
,p_display_order=>240
,p_column_identifier=>'AG'
,p_column_label=>'Zugang'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680679526003315)
,p_db_column_name=>'PERIODE'
,p_display_order=>250
,p_column_identifier=>'AH'
,p_column_label=>'Periode'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7680845414003316)
,p_db_column_name=>'ABGANG'
,p_display_order=>260
,p_column_identifier=>'AI'
,p_column_label=>'Abgang'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7761064894751585)
,p_db_column_name=>'INVENTARTYP'
,p_display_order=>270
,p_column_identifier=>'AJ'
,p_column_label=>'Inventartyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7829053696929983)
,p_db_column_name=>'EINZEL_GWG'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Einzel gwg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7829087501929984)
,p_db_column_name=>'OK'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7829224943929985)
,p_db_column_name=>'OK_BEMERKUNGEN'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Ok bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11546036103825628)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11593979639016480)
,p_db_column_name=>'GWG_JA_NEIN'
,p_display_order=>330
,p_column_identifier=>'AQ'
,p_column_label=>'Gwg ja nein'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1671035227869962)
,p_db_column_name=>'INV_BILD'
,p_display_order=>340
,p_column_identifier=>'AS'
,p_column_label=>'Inv Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:T_INVENTARE:INV_BILD:PK_INVENTAR::::::::'
,p_static_id=>'inv_bild'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46622561797847977)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>350
,p_column_identifier=>'AT'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46622657756847978)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>360
,p_column_identifier=>'AU'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46622731398847979)
,p_db_column_name=>'FK_BAS_STD_VERWENDUNGSZWECK'
,p_display_order=>370
,p_column_identifier=>'AV'
,p_column_label=>'Fk Bas Std Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46622790065847980)
,p_db_column_name=>'GERAETENAME'
,p_display_order=>380
,p_column_identifier=>'AW'
,p_column_label=>'Geraetename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16770897131036907)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>390
,p_column_identifier=>'AX'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16770946620036908)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>400
,p_column_identifier=>'AY'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16771001159036909)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>410
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16771111817036910)
,p_db_column_name=>'ANSCHAFFUNGSWERT'
,p_display_order=>420
,p_column_identifier=>'BA'
,p_column_label=>'Anschaffungswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17426579682179731)
,p_db_column_name=>'FK_KON_HERSTELLER'
,p_display_order=>430
,p_column_identifier=>'BB'
,p_column_label=>'Fk Kon Hersteller'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17426612365179732)
,p_db_column_name=>'BAUREIHE'
,p_display_order=>440
,p_column_identifier=>'BC'
,p_column_label=>'Baureihe'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17426707283179733)
,p_db_column_name=>'MODELL_NO'
,p_display_order=>450
,p_column_identifier=>'BD'
,p_column_label=>'Modell No'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6793837304306841)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'67939'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GWG_JA_NEIN:OK:PK_INV_INVENTAR:ZUGANG:ABGANG:INVENTAR:EINZEL_GWG:INVENTARTYP:FK_KON_HERSTELLER:PREIS_NETTO:MWST:PREIS_BRUTTO:VERWENDUNGSZWECK:ANSCHAFFUNGSDATUM:ABGANGSDATUM:ABSCHREIBUNGSDAUER:ABGANGSGRUND:ANSCHAFFUNGSJAHR:ABGANGSJAHR:ANSCHAFFUNGSWERT'
||':ABGANGSWERT:RESTBUCHWERT_2017:RESTBUCHWERT_2018:RESTBUCHWERT_2019:RESTBUCHWERT_2020:BEMERKUNGEN:COMM:SERIENNUMMER:FAHRGESTELLNR:PERIODE:GERAETENAME:GWG:KFZ_KENNZEICHEN:LIZENZNUMMER:ANFORDERUNGSCODE:MAC_ADRESSE:OK_BEMERKUNGEN:FK_BAS_STEU_STEUER_SATZ:'
||'CREATED_AT:CREATED_BY:MODIFIED_AT:MODIFIED_BY:FK_BAS_STD_VERWENDUNGSZWECK:FK_BAS_INV_INVENTARTYP::BAUREIHE:MODELL_NO'
,p_sort_column_1=>'ZUGANG'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PERIODE'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'ABGANG'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'PK_INVENTAR'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'GWG:0:0:0:0:GWG_JA_NEIN'
,p_break_enabled_on=>'0:0:0:0:GWG_JA_NEIN'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17458317629393284)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'Abgang'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ABGANG'
,p_operator=>'does not contain'
,p_expr=>'(z)'
,p_condition_sql=>' (case when (upper("ABGANG") not like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''(z)''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17458713557393284)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'GWG'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'GWG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("GWG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#EDE6ED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17459169551393285)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'GWG?'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'GWG'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("GWG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#BDBDBD'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17459569218393285)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#C5FCED'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17459913839393285)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'Zugang'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUGANG'
,p_operator=>'contains'
,p_expr=>'in'
,p_condition_sql=>' (case when (upper("ZUGANG") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''in''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17457916814393283)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ANSCHAFFUNGSJAHR'
,p_operator=>'='
,p_expr=>'2017'
,p_condition_sql=>'"ANSCHAFFUNGSJAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17460361178393286)
,p_report_id=>wwv_flow_api.id(6793837304306841)
,p_name=>'Row text contains ''wohn'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'wohn'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(46685790845145010)
,p_plug_name=>'Inventar'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7186264232999294)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inv.* ,      case when anschaffungsjahr is null or anschaffungsjahr <2017 then ''(a) <b>vor 2017</b>''',
'         when anschaffungsjahr = 2017 then ''(b) in <b>2017</b>''',
'         when anschaffungsjahr = 2018 then ''(c) in <b>2018</b>''',
'         when anschaffungsjahr = 2019 then ''(d) in <b>2019</b>''',
'    end zugang,',
'    case when (anschaffungsjahr is null or anschaffungsjahr <2017) and (abgangsjahr <= 2017) then ''(a) <b>vor 2017</b>'' ',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2017 ) then ''(b1) <b>2017</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2018) then ''(b2) <b>2017 - 2018</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2019)  then ''(b3) <b>2017 - 2019</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr is null)  then ''(b4) <b>2017 - 2019</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr = 2018) then ''(c1) in <b>2018</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr = 2019) then ''(c2) in <b>2018 - 2019</b>''',
'         when anschaffungsjahr = 2018 and (abgangsjahr is null) then ''(c3) in <b>2018 - 2019</b>''',
'         when anschaffungsjahr = 2019 and (abgangsjahr = 2019 ) then ''(d1) in <b>2019</b>''',
'         when anschaffungsjahr = 2019 and (abgangsjahr is null) then ''(d1) in <b>2019</b>''',
'    end periode,',
'    case when (anschaffungsjahr is null or anschaffungsjahr < 2017) and (abgangsjahr <2017) then ''(a) <b>bis 2017</b>'' ',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2017) and (abgangsjahr = 2017) then ''(b) in <b>2017</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2018) and (abgangsjahr = 2018) then ''(c) in <b>2018</b>''',
'         when (anschaffungsjahr is null or anschaffungsjahr <= 2019) and (abgangsjahr = 2019) then ''(d) in <b>2019</b>''',
'         else ''(z) <b>kein Abgang</b>''',
'    end abgang,',
'        case ',
'         when gwg = 1 then ''GWG''',
'         when gwg = 2 then ''kein GWG''',
'         when gwg = 3 then ''unsicher''',
'         when gwg = 0 then ''Keine Angabe''',
'         else ''unbekannt''',
'     end gwg_ja_nein,',
'     length(inv.inv_bild) inv_bild_1',
'from t_inv_inventare inv'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(46753199240346662)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::P39_PK_INV_INVENTAR:#PK_INV_INVENTAR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>48193518515738202
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46753323185346663)
,p_db_column_name=>'GWG'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Gwg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46753396797346664)
,p_db_column_name=>'RESTBUCHWERT_2017'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Restbuchwert 2017'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46753493237346665)
,p_db_column_name=>'ABGANGSGRUND'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Abgangsgrund'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46753606836346666)
,p_db_column_name=>'MAC_ADRESSE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Mac adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46753682445346667)
,p_db_column_name=>'SERIENNUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Seriennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46754336915346673)
,p_db_column_name=>'OK'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46754480339346674)
,p_db_column_name=>'OK_BEMERKUNGEN'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Ok bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46754874058346678)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>160
,p_column_identifier=>'H'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46754943461346679)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>170
,p_column_identifier=>'I'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755082368346681)
,p_db_column_name=>'GERAETENAME'
,p_display_order=>190
,p_column_identifier=>'J'
,p_column_label=>'Geraetename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755277858346682)
,p_db_column_name=>'INVENTAR'
,p_display_order=>200
,p_column_identifier=>'K'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755314801346683)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>210
,p_column_identifier=>'L'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755465434346684)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>220
,p_column_identifier=>'M'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755576983346685)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>230
,p_column_identifier=>'N'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755642694346686)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>240
,p_column_identifier=>'O'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755756151346687)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>250
,p_column_identifier=>'P'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755813780346688)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>260
,p_column_identifier=>'Q'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46755976148346689)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>270
,p_column_identifier=>'R'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756030826346690)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>280
,p_column_identifier=>'S'
,p_column_label=>'Preis netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756124699346691)
,p_db_column_name=>'MWST'
,p_display_order=>290
,p_column_identifier=>'T'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756267340346692)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>300
,p_column_identifier=>'U'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756313633346693)
,p_db_column_name=>'COMM'
,p_display_order=>310
,p_column_identifier=>'V'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756456280346694)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>320
,p_column_identifier=>'W'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756513697346695)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>330
,p_column_identifier=>'X'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756631344346696)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>340
,p_column_identifier=>'Y'
,p_column_label=>'Kfz kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756752052346697)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>350
,p_column_identifier=>'Z'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46756787157346698)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>360
,p_column_identifier=>'AA'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757079744346700)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>380
,p_column_identifier=>'AB'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757090978346701)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>390
,p_column_identifier=>'AC'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757202259346702)
,p_db_column_name=>'ABGANGSDATUM'
,p_display_order=>400
,p_column_identifier=>'AD'
,p_column_label=>'Abgangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757340293346703)
,p_db_column_name=>'ABGANGSWERT'
,p_display_order=>410
,p_column_identifier=>'AE'
,p_column_label=>'Abgangswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757483887346705)
,p_db_column_name=>'BILD'
,p_display_order=>430
,p_column_identifier=>'AG'
,p_column_label=>'Bild'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757689586346707)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>450
,p_column_identifier=>'AI'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757809073346708)
,p_db_column_name=>'INV_BILD'
,p_display_order=>460
,p_column_identifier=>'AJ'
,p_column_label=>'Inv Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46757911199346709)
,p_db_column_name=>'ANSCHAFFUNGSWERT'
,p_display_order=>470
,p_column_identifier=>'AK'
,p_column_label=>'Anschaffungswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46758078298346710)
,p_db_column_name=>'ZUGANG'
,p_display_order=>480
,p_column_identifier=>'AL'
,p_column_label=>'Zugang'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46770482728360661)
,p_db_column_name=>'PERIODE'
,p_display_order=>490
,p_column_identifier=>'AM'
,p_column_label=>'Periode'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46770631880360662)
,p_db_column_name=>'ABGANG'
,p_display_order=>500
,p_column_identifier=>'AN'
,p_column_label=>'Abgang'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46770715895360663)
,p_db_column_name=>'GWG_JA_NEIN'
,p_display_order=>510
,p_column_identifier=>'AO'
,p_column_label=>'Gwg Ja Nein'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46770834885360664)
,p_db_column_name=>'INV_BILD_1'
,p_display_order=>520
,p_column_identifier=>'AP'
,p_column_label=>'Inv Bild 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46771200733360668)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>530
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46771314335360669)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>540
,p_column_identifier=>'AR'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14645990155961104)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>550
,p_column_identifier=>'AS'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(46769882878350439)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'482103'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GWG:MAC_ADRESSE:SERIENNUMMER:OK:OK_BEMERKUNGEN:PK_INV_INVENTAR:FK_BAS_INV_INVENTARTYP:GERAETENAME:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:PREIS_NETTO:MWST:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHRGEST'
||'ELLNR:RESTBUCHWERT_2018:BILD:RESTBUCHWERT_2019:INV_BILD:ANSCHAFFUNGSWERT:ZUGANG:PERIODE:ABGANG:GWG_JA_NEIN:INV_BILD_1:FK_BAS_STEU_STEUER_SATZ:RESTBUCHWERT_2020:FK_STD_VERW_VERWENDUNGSZWECK:ABGANGSDATUM:ABGANGSGRUND:ABGANGSJAHR:ABGANGSWERT:BEMERKUNGEN'
||':RESTBUCHWERT_2017:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(46753137635346661)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(46685790845145010)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6793113158304646)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6788683473304616)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(25667172978571647)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6788683473304616)
,p_button_name=>'CREATE_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Neu'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:455:&SESSION.::&DEBUG.:455::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7933893173409927)
,p_branch_name=>'Go To Page 39'
,p_branch_action=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7933121258409927)
,p_branch_name=>'Go To Page 37'
,p_branch_action=>'f?p=&APP_ID.:37:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.component_end;
end;
/
