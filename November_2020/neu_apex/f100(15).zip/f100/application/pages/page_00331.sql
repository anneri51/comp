prompt --application/pages/page_00331
begin
--   Manifest
--     PAGE: 00331
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>331
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Vorsteueranmeldung_Monate'
,p_alias=>'VORSTEUERANMELDUNG_MONATE'
,p_step_title=>'Vorsteueranmeldung_Monate'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200910202249'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11931025434474294)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'apex_item.checkbox2(1,pk_steu_steuer_monat) sel,',
'stm.PK_steu_STEUER_MONAT,',
'       stm.MONAT,',
'       stm.JAHR,',
'       stm.FAELLIGKEITSDATUM,',
'       stm.FK_std_steu_STATUS,',
'       stm.DATUM_OK,',
'       stm.FK_bas_kal_FAELLIGKEITSTAG,',
'       arb.wochentag,',
'       FK_BAS_KAL_STEUER_JAHR,',
'       std_name status,',
'       meld.meldung',
'  from T_steu_STEUER_MONAT stm',
'    left join t_bas_kal_arbeitstage arb on stm.fk_bas_kal_faelligkeitstag = arb.pk_bas_kal_arbeitstage',
'    left join (select * from t_std where fk_std_group = 342) std on std.std_value = stm.fk_std_steu_status',
'    left join (   ',
'   select fk_steu_steuer_monat,',
'        listagg( ''<b> '' || pk_steu_steuer_voranmldg || ''</b>'' ||  '' - ('' || case when umsatzstvorauszlg_ueberschuss >0 then ''<b><span style="background-color:#E0B9AF">'' else   ''<b><span style="background-color:lightgreen">'' end || umsatzstvorauszlg_u'
||'eberschuss * -1 || ''</span></b>)  - '' || sendedatum || '' - '' || std_name, chr(13) || ''//'') within group (order by FK_STD_STEU_TYPE_STEUERVORANMELDG desc, pk_steu_steuer_voranmldg desc) meldung',
'   from t_steu_steuer_voranmldg stva',
'     left join (select * from t_std where fk_std_group = 343) std on std.std_value = stva.FK_STD_STEU_TYPE_STEUERVORANMELDG',
'   group by fk_steu_steuer_monat',
'  ',
'    ) meld on meld.fk_steu_steuer_monat = stm.pk_steu_steuer_monat',
'   '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11931431104474294)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:332:&SESSION.::&DEBUG.:RP,:P332_PK_STEU_STEUER_MONAT:#PK_STEU_STEUER_MONAT#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13371750379865834
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11931916081474297)
,p_db_column_name=>'MONAT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11932370907474297)
,p_db_column_name=>'JAHR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11932737321474297)
,p_db_column_name=>'FAELLIGKEITSDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Faelligkeitsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11933522808474297)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11717769259412482)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18026193056728080)
,p_db_column_name=>'SEL'
,p_display_order=>46
,p_column_identifier=>'J'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18026321275728081)
,p_db_column_name=>'STATUS'
,p_display_order=>56
,p_column_identifier=>'K'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027750002728095)
,p_db_column_name=>'MELDUNG'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Meldung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14835618272222440)
,p_db_column_name=>'PK_STEU_STEUER_MONAT'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Pk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14835751613222441)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>86
,p_column_identifier=>'N'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14835871878222442)
,p_db_column_name=>'FK_BAS_KAL_FAELLIGKEITSTAG'
,p_display_order=>96
,p_column_identifier=>'O'
,p_column_label=>'Fk Bas Kal Faelligkeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14835935360222443)
,p_db_column_name=>'FK_BAS_KAL_STEUER_JAHR'
,p_display_order=>106
,p_column_identifier=>'P'
,p_column_label=>'Fk Bas Kal Steuer Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11968928863675969)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134093'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:MONAT:FAELLIGKEITSDATUM:WOCHENTAG:FK_DATUM_OK::SEL:STATUS:MELDUNG:PK_STEU_STEUER_MONAT:FK_STD_STEU_STATUS:FK_BAS_KAL_FAELLIGKEITSTAG:FK_BAS_KAL_STEUER_JAHR'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'MONAT'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18106487416819681)
,p_report_id=>wwv_flow_api.id(11968928863675969)
,p_name=>'erl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'erledigt'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''erledigt''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D5EDD5'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18106978192819683)
,p_report_id=>wwv_flow_api.id(11968928863675969)
,p_name=>'in Bearbeitung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'in Bearbeitung'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''in Bearbeitung''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18025982491728078)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18026750057728085)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(18025982491728078)
,p_button_name=>'set_fk_faelligkeitstag'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Fk Faelligkeitstag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18026119812728079)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(18025982491728078)
,p_button_name=>'set_status'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Status'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18026484053728083)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(18025982491728078)
,p_button_name=>'set_fk_steuer_jahr'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Fk Steuer Jahr'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11934709704474302)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11931025434474294)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:332:&SESSION.::&DEBUG.:332'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18026412160728082)
,p_name=>'P331_FK_STEU_STEUER_JAHR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(18025982491728078)
,p_prompt=>'Fk Steu Steuer Jahr'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select jahr, pk_steu_steuer_jahr',
'from t_steu_steuer_jahr',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18074005543876170)
,p_name=>'P331_FK_STD_STEU_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18025982491728078)
,p_prompt=>'Fk Std Steu Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 342'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18076174590888322)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update T_STEUER_MONAT set fk_status = :P331_fk_status where pk_steuer_monat =   apex_application.g_f01(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18026119812728079)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18026593023728084)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_set_fK_steuer_jahr'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      update T_STEUER_MONAT set fk_steuer_jahr = :P331_fk_steuer_jahr where pk_steuer_monat =   apex_application.g_f01(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18026484053728083)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18026875653728086)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_set_fk_faelligkeitstag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'merge into t_steuer_monat t1',
'  using (',
'        select distinct pk_arbeitstage, ',
'       pk_steuer_monat',
'',
'        from (select * from t_steuer_monat where faelligkeitsdatum is not null and fk_faelligkeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.faelligkeitsdatum,1,10), ''DD.MM.YY'')= arb.datum ',
'         ) t2 on (',
'         t1.pk_steuer_monat = t2.pk_steuer_monat',
'         ',
'         ',
'        )',
'        when matched then',
'        update set t1.fk_faelligkeitstag= t2.pk_arbeitstage;',
'        commit;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18026750057728085)
);
wwv_flow_api.component_end;
end;
/
