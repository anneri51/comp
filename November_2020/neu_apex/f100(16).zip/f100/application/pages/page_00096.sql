prompt --application/pages/page_00096
begin
--   Manifest
--     PAGE: 00096
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>96
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 4'
,p_alias=>'STEP-45'
,p_step_title=>'Step 4'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200823113823'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8315530811927174)
,p_plug_name=>'Step 4'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8303117678927148)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8315692517927174)
,p_plug_name=>'Step 4'
,p_parent_plug_id=>wwv_flow_api.id(8315530811927174)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12840966840612762)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_KTO_KONTO_BUCH", ',
'"FK_KTO_BANKKONTO",',
'"Buchungstag" "BUCHUNGSTAG",',
'"Wertstellung" "WERTSTELLUNG",',
'"Umsatzart" "UMSATZART",',
'dbms_lob.substr("Buchungstext",4000,1) "BUCHUNGSTEXT",',
'round(BETRAG,2) "BETRAG",',
' "WAEHRUNG",',
'"Auftraggeberkonto" "AUFTRAGGEBERKONTO",',
'"Bankleitzahl Auftraggeberkonto" "BANKLEITZAHL_AUFTRAGGEBERKONTO",',
'"IBAN Auftraggeberkonto" "IBAN_AUFTRAGGEBERKONTO",',
'FK_BAS_KAT_KONTO_BUCH,',
'FK_STD_VERW_Verwendungszweck FK_STD_VERW_VERWENDUNGSZWECK,',
'FK_STD_KTO_Kontotyp,',
'"FK_KTO_KONTO_AUSZUG",',
'"Bemerkungen" "BEMERKUNGEN",',
'"LFD_SUMME",',
'"Beleg" "BELEG",',
'"Unternehmen" "UNTERNEHMEN",',
'"Betrag Ursprung" "BETRAG_URSPRUNG",',
'Waehrung_ursprung,',
'"Belastete Kreditkarte" "BELASTETE_KREDITKARTE",',
'"Kategorie" "KATEGORIE",',
'"Wertstellungsmonat" "WERTSTELLUNGSMONAT",',
'"Datum" "DATUM",',
'"Uhrzeit" "UHRZEIT",',
'"Zeitzone" "ZEITZONE",',
'"Name" "NAME",',
'"Typ" "TYP",',
'"Status" "STATUS",',
'"Brutto" "BRUTTO",',
' "GEBUEHR",',
'"Netto" "NETTO",',
'"Absender_Email" "ABSENDER_EMAIL",',
'Empfaenger_Email,',
'"Transaktionscode" "TRANSAKTIONSCODE",',
'"Lieferadresse" "LIEFERADRESSE",',
'"Adress-Status" "ADRESS-STATUS",',
'"Artikelbezeichnung" "ARTIKELBEZEICHNUNG",',
'"Artikelnummer" "ARTIKELNUMMER",',
'"Versand_Bearbeitungsgeb" "VERSAND_BEARBEITUNGSGEB",',
'"Versicherungsbetrag" "VERSICHERUNGSBETRAG",',
'"Umsatzsteuer" "UMSATZSTEUER",',
'"Option 1 Name" "OPTION_1_NAME",',
'"Option 1 Wert" "OPTION_1_WERT",',
'"Option 2 Name" "OPTION_2_NAME",',
'"Option 2 Wert" "OPTION_2_WERT",',
'zugehoeriger_Transaktionscode,',
'"Rechnungsnummer" "RECHNUNGSNUMMER",',
'"Zollnummer" "ZOLLNUMMER",',
'"Anzahl" "ANZAHL",',
'"Empfangsnummer" "EMPFANGSNUMMER",',
'"Guthaben" "GUTHABEN",',
'"Adresszeile 1" "ADRESSZEILE_1",',
'"Adresszusatz" "ADRESSZUSATZ",',
'"Ort" "ORT",',
'"Bundesland" "BUNDESLAND",',
'"PLZ",',
'"Land" "LAND",',
'"Telefon" "TELEFON",',
'"Betreff" "BETREFF",',
'"Hinweis" "HINWEIS",',
'Laendervorwahl,',
'"Auswirkung_Guthaben" "AUSWIRKUNG_GUTHABEN",',
'"OLD_ID",',
'"FK_STD_KTO_SRC"',
'from T_KTO_KONTO_BUCH ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12841320163612763)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_PK_KONTO_BUCH:#PK_KTO_KONTO_BUCH##PK_KONTO_BUCH#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>22151455404033684
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1863992530519167)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1864374006519168)
,p_db_column_name=>'WERTSTELLUNG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1864855238519168)
,p_db_column_name=>'UMSATZART'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1865252658519169)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1867232520519171)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1869217549519174)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1869649157519174)
,p_db_column_name=>'LFD_SUMME'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Lfd Summe'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1870050255519175)
,p_db_column_name=>'BELEG'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1870411522519176)
,p_db_column_name=>'UNTERNEHMEN'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1872029454519177)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1873157549519179)
,p_db_column_name=>'DATUM'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1873496731519179)
,p_db_column_name=>'UHRZEIT'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1873890971519179)
,p_db_column_name=>'ZEITZONE'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Zeitzone'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1874291446519180)
,p_db_column_name=>'NAME'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1874714066519180)
,p_db_column_name=>'TYP'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1875143297519181)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1876724348519182)
,p_db_column_name=>'ABSENDER_EMAIL'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Absender Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1877481896519183)
,p_db_column_name=>'TRANSAKTIONSCODE'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Transaktionscode'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1877920353519185)
,p_db_column_name=>'LIEFERADRESSE'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Lieferadresse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1878352347519185)
,p_db_column_name=>'ADRESS-STATUS'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Adress-Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1878719198519186)
,p_db_column_name=>'ARTIKELBEZEICHNUNG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1879142453519186)
,p_db_column_name=>'ARTIKELNUMMER'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Artikelnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1879502672519187)
,p_db_column_name=>'VERSAND_BEARBEITUNGSGEB'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Versand Bearbeitungsgeb'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1879915945519187)
,p_db_column_name=>'VERSICHERUNGSBETRAG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Versicherungsbetrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1880286094519187)
,p_db_column_name=>'UMSATZSTEUER'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1881025694519188)
,p_db_column_name=>'OPTION_1_NAME'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Option 1 Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1881407287519189)
,p_db_column_name=>'OPTION_1_WERT'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Option 1 Wert'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1881845917519189)
,p_db_column_name=>'OPTION_2_NAME'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Option 2 Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1882174828519190)
,p_db_column_name=>'OPTION_2_WERT'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Option 2 Wert'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1882986508519190)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1883368976519191)
,p_db_column_name=>'ZOLLNUMMER'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Zollnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1883849042519191)
,p_db_column_name=>'ANZAHL'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Anzahl'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1884179497519192)
,p_db_column_name=>'EMPFANGSNUMMER'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Empfangsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1885004958519192)
,p_db_column_name=>'ADRESSZEILE_1'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Adresszeile 1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1885389001519193)
,p_db_column_name=>'ADRESSZUSATZ'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Adresszusatz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1885842710519193)
,p_db_column_name=>'ORT'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1886192831519194)
,p_db_column_name=>'BUNDESLAND'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Bundesland'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1886607297519194)
,p_db_column_name=>'PLZ'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1887060826519194)
,p_db_column_name=>'LAND'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1887453067519195)
,p_db_column_name=>'TELEFON'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1887773027519195)
,p_db_column_name=>'BETREFF'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Betreff'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1888245006519195)
,p_db_column_name=>'HINWEIS'
,p_display_order=>62
,p_column_identifier=>'BJ'
,p_column_label=>'Hinweis'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1889331898519196)
,p_db_column_name=>'AUSWIRKUNG_GUTHABEN'
,p_display_order=>64
,p_column_identifier=>'BL'
,p_column_label=>'Auswirkung Guthaben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1889702844519197)
,p_db_column_name=>'OLD_ID'
,p_display_order=>65
,p_column_identifier=>'BM'
,p_column_label=>'Old Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190306279681087)
,p_db_column_name=>'BETRAG'
,p_display_order=>86
,p_column_identifier=>'BP'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190408486681088)
,p_db_column_name=>'AUFTRAGGEBERKONTO'
,p_display_order=>96
,p_column_identifier=>'BQ'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190465792681089)
,p_db_column_name=>'BANKLEITZAHL_AUFTRAGGEBERKONTO'
,p_display_order=>106
,p_column_identifier=>'BR'
,p_column_label=>'Bankleitzahl auftraggeberkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190792960681092)
,p_db_column_name=>'BETRAG_URSPRUNG'
,p_display_order=>136
,p_column_identifier=>'BU'
,p_column_label=>'Betrag ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190953983681093)
,p_db_column_name=>'BELASTETE_KREDITKARTE'
,p_display_order=>146
,p_column_identifier=>'BV'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2190994605681094)
,p_db_column_name=>'WERTSTELLUNGSMONAT'
,p_display_order=>156
,p_column_identifier=>'BW'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2191156605681095)
,p_db_column_name=>'BRUTTO'
,p_display_order=>166
,p_column_identifier=>'BX'
,p_column_label=>'Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2191199081681096)
,p_db_column_name=>'NETTO'
,p_display_order=>176
,p_column_identifier=>'BY'
,p_column_label=>'Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2191296902681097)
,p_db_column_name=>'GUTHABEN'
,p_display_order=>186
,p_column_identifier=>'BZ'
,p_column_label=>'Guthaben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48146823145418086)
,p_db_column_name=>'PK_KTO_KONTO_BUCH'
,p_display_order=>196
,p_column_identifier=>'CA'
,p_column_label=>'Pk Kto Konto Buch'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48146958859418087)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>206
,p_column_identifier=>'CB'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147067388418088)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>216
,p_column_identifier=>'CC'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147162717418089)
,p_db_column_name=>'FK_BAS_KAT_KONTO_BUCH'
,p_display_order=>226
,p_column_identifier=>'CD'
,p_column_label=>'Fk Bas Kat Konto Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147232551418090)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>236
,p_column_identifier=>'CE'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147281691418091)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>246
,p_column_identifier=>'CF'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147463469418092)
,p_db_column_name=>'FK_KTO_KONTO_AUSZUG'
,p_display_order=>256
,p_column_identifier=>'CG'
,p_column_label=>'Fk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147488936418093)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>266
,p_column_identifier=>'CH'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147610580418094)
,p_db_column_name=>'GEBUEHR'
,p_display_order=>276
,p_column_identifier=>'CI'
,p_column_label=>'Gebuehr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147710790418095)
,p_db_column_name=>'EMPFAENGER_EMAIL'
,p_display_order=>286
,p_column_identifier=>'CJ'
,p_column_label=>'Empfaenger Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147863175418096)
,p_db_column_name=>'ZUGEHOERIGER_TRANSAKTIONSCODE'
,p_display_order=>296
,p_column_identifier=>'CK'
,p_column_label=>'Zugehoeriger Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48147966490418097)
,p_db_column_name=>'LAENDERVORWAHL'
,p_display_order=>306
,p_column_identifier=>'CL'
,p_column_label=>'Laendervorwahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48148014053418098)
,p_db_column_name=>'FK_STD_KTO_SRC'
,p_display_order=>316
,p_column_identifier=>'CM'
,p_column_label=>'Fk Std Kto Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2205193587945353)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'115154'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSTAG:WERTSTELLUNG:UMSATZART:BUCHUNGSTEXT:BANKLEITZAHL_IBAN_FK_KATEGORIE:BEMERKUNGEN:LFD_SUMME:BELEG:UNTERNEHMEN_URSPRUNG:KATEGORIE:DATUM:UHRZEIT:ZEITZONE:NAME:TYP:STATUS:ABSENDER_EMAIL:TRANSAKTIONSCODE:LIEFERADRESSE:ADRESS-STATUS:ARTIKELBEZEIC'
||'HNUNG:ARTIKELNUMMER:VERSAND_BEARBEITUNGSGEB:VERSICHERUNGSUMSATZSTEUER:OPTION_1_NAME:OPTION_1_WERT:OPTION_2_NAME:OPTION_2_WERT:RECHNUNGSNUMMER:ZOLLNUMMER:ANZAHL:EMPFANGSNUMMER:ADRESSZEILE_1:ADRESSZUSATZ:ORT:BUNDESLAND:PLZ:LAND:TELEFON:BETREFF:HINWEIS:'
||'AUSWIRKUNG_OLD_ID:PK_KTO_KONTO_BUCH:FK_KTO_BANKKONTO:WAEHRUNG:FK_BAS_KAT_KONTO_BUCH:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_KTO_KONTO_AUSZUG:WAEHRUNG_URSPRUNG:GEBUEHR:EMPFAENGER_EMAIL:ZUGEHOERIGER_TRANSAKTIONSCODE:LAENDERVORWAHL:FK_STD_KT'
||'O_SRC'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2220423024992376)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Wertstellung'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'115306'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WERTSTELLUNG:UMSATZART:BUCHUNGSTEXT:BETRAG:BEMERKUNGEN:LFD_SUMME:BELEG:KATEGORIE:DATUM:UHRZEIT:ZEITZONE:NAME:TYP:STATUS:ABSENDER_EMAIL:TRANSAKTIONSCODE:LIEFERADRESSE:ADRESS-STATUS:ARTIKELBEZEICHNUNG:ARTIKELNUMMER:VERSAND_BEARBEITUNGSGEB:OPTION_1_NAME'
||':OPTION_1_WERT:OPTION_2_NAME:OPTION_2_WERT:RECHNUNGSNUMMER:ZOLLNUMMER:ANZAHL:EMPFANGSNUMMER:ADRESSZEILE_1:ADRESSZUSATZ:ORT:BUNDESLAND:PLZ:LAND:TELEFON:BETREFF:HINWEIS'
,p_break_on=>'FK_KONTO:WERTSTELLUNG:0:0:0:0'
,p_break_enabled_on=>'FK_KONTO:WERTSTELLUNG:0:0:0:0'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2221145606012115)
,p_application_user=>'ANNE'
,p_name=>'Pivot - nach Wertstellung'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_columns=>'WERTSTELLUNG:UMSATZART:BUCHUNGSTEXT:BANKLEITZAHL_IBAN_FK_KATEGORIE:BEMERKUNGEN:LFD_SUMME:BELEG:UNTERNEHMEN_URSPRUNG:KATEGORIE:DATUM:UHRZEIT:ZEITZONE:NAME:TYP:STATUS:ABSENDER_EMAIL:TRANSAKTIONSCODE:LIEFERADRESSE:ADRESS-STATUS:ARTIKELBEZEICHNUNG:ARTIKE'
||'LNUMMER:VERSAND_BEARBEITUNGSGEB:VERSICHERUNGSUMSATZSTEUER:OPTION_1_NAME:OPTION_1_WERT:OPTION_2_NAME:OPTION_2_WERT:RECHNUNGSNUMMER:ZOLLNUMMER:ANZAHL:EMPFANGSNUMMER:ADRESSZEILE_1:ADRESSZUSATZ:ORT:BUNDESLAND:PLZ:LAND:TELEFON:BETREFF:HINWEIS:AUSWIRKUNG_O'
||'LD_ID'
,p_break_on=>'FK_KONTO:0:0:0:0'
,p_break_enabled_on=>'FK_KONTO:0:0:0:0'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(2221939380021926)
,p_report_id=>wwv_flow_api.id(2221145606012115)
,p_pivot_columns=>'FK_KONTO'
,p_row_columns=>'KATEGORIE:WERTSTELLUNG'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(2222021161021928)
,p_pivot_id=>wwv_flow_api.id(2221939380021926)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'BETRAG'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_pivot_sort(
 p_id=>wwv_flow_api.id(2222066975021928)
,p_pivot_id=>wwv_flow_api.id(2221939380021926)
,p_sort_seq=>1
,p_sort_column_name=>'WERTSTELLUNG'
,p_sort_direction=>'ASC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8317302158927175)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8315530811927174)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8317622752927175)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8315530811927174)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8317527877927175)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8315530811927174)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1890534482519197)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12840966840612762)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:97:&SESSION.::&DEBUG.:67:P97_PK_KTO_KONTO_BUCH:'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8319041820927176)
,p_branch_action=>'f?p=&APP_ID.:97:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8317622752927175)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8318344811927175)
,p_branch_action=>'f?p=&APP_ID.:95:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8317527877927175)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8317014095927175)
,p_name=>'P96_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8315692517927174)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
