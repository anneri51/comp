prompt --application/pages/page_00370
begin
--   Manifest
--     PAGE: 00370
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>370
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'steuer_monat_todo'
,p_alias=>'STEUER_MONAT_TODO'
,p_step_title=>'steuer_monat_todo'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200910203407'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18224021035983072)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select todo.PK_steu_STEUER_MONAT_TODO,',
'       todo.FK_steu_STEUER_MONAT,',
'       todo.FK_steu_TODO_GRP,',
'       todo.DATUM_OK,',
'       todo.TODO,',
'       todo.FK_std_steu_STATUS,',
'       todo.CREATION_DATE,',
'       todo_grp.todo todo_grp_name,',
'       std2.std_name thema,',
'       apex_item.checkbox2(2, pk_steu_steuer_monat_todo) sel,',
'       monat, ',
'       jahr',
'  from T_steu_STEUER_MONAT_TODO todo',
'    left join t_steu_steuer_jahr_todo_grp todo_grp on todo.fk_steu_todo_grp = todo_grp.pk_steu_steuer_jahr_todo_grp',
'    left join (select * from t_std where fk_std_group = 301) std2 on todo_grp.fk_std_steu_thema_jaehrlich = std2.std_value',
'    left join t_steu_steuer_monat stm on stm.pk_steu_steuer_monat = todo.fk_steu_steuer_monat',
' where fk_steu_steuer_monat = :P370_fk_steu_steuer_monat or :P370_fk_steu_steuer_monat is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18224213992983074)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:RP:P375_PK_STEUER_MONAT_TODO:#PK_STEUER_MONAT_TODO##PK_STEUER_JAHR_TODO#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>19664533268374614
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18224620546983078)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18224697884983079)
,p_db_column_name=>'TODO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18280309199295064)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18280458350295065)
,p_db_column_name=>'TODO_GRP_NAME'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Todo Grp Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18280731081295068)
,p_db_column_name=>'THEMA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18280821844295069)
,p_db_column_name=>'SEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18281236606295073)
,p_db_column_name=>'MONAT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18281281097295074)
,p_db_column_name=>'JAHR'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999373473848063)
,p_db_column_name=>'PK_STEU_STEUER_MONAT_TODO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Pk Steu Steuer Monat Todo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999459115848064)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999550133848065)
,p_db_column_name=>'FK_STEU_TODO_GRP'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Steu Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999644440848066)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18272633390131864)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197130'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_STEUER_FK_TODO_GRP:DATUM_OK:TODO:CREATION_DATE:TODO_GRP_NAME:THEMA:SEL:MONAT:JAHR:PK_STEU_STEUER_MONAT_TODO:FK_STEU_STEUER_MONAT:FK_STEU_TODO_GRP:FK_STD_STEU_STATUS'
,p_sort_column_1=>'TODO_GRP_NAME'
,p_sort_direction_1=>'ASC'
,p_break_on=>'THEMA'
,p_break_enabled_on=>'THEMA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18313740321856983)
,p_report_id=>wwv_flow_api.id(18272633390131864)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18224883566983081)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_steu_STEUER_MONAT,',
'       MONAT,',
'       JAHR,',
'       FAELLIGKEITSDATUM,',
'       FK_std_steu_STATUS,',
'       DATUM_OK,',
'    FK_BAS_KAL_FAELLIGKEITSTAG',
'  from T_steu_STEUER_MONAT'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18225103263983083)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:370:&SESSION.::&DEBUG.:RP,:P370_FK_STEU_STEUER_MONAT:#PK_STEU_STEUER_MONAT#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>19665422539374623
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18225540873983087)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227257532983104)
,p_db_column_name=>'MONAT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227379311983105)
,p_db_column_name=>'JAHR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227457713983106)
,p_db_column_name=>'FAELLIGKEITSDATUM'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Faelligkeitsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665615235795110)
,p_db_column_name=>'PK_STEU_STEUER_MONAT'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'Pk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999110416848061)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52999225635848062)
,p_db_column_name=>'FK_BAS_KAL_FAELLIGKEITSTAG'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'Fk Bas Kal Faelligkeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18272020854131855)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197124'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_OK:MONAT:JAHR:FAELLIGKEITSDATUM:PK_STEU_STEUER_MONAT:FK_STD_STEU_STATUS:FK_BAS_KAL_FAELLIGKEITSTAG'
,p_sort_column_1=>'MONAT'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18287829643331702)
,p_report_id=>wwv_flow_api.id(18272020854131855)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18225849615983090)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18246922079098377)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       apex_item.checkbox2(1, pk_steu_steuer_jahr_todo_grp) sel,',
'       todo_grp.PK_steu_STEUER_JAHR_TODO_GRP,',
'       todo_grp.TODO,',
'       todo_grp.FK_std_steu_THEMA_DAUERHAFT,',
'       todo_grp.CREATION_DATE,',
'       todo_grp.FK_std_steu_THEMA_MONATLICH,',
'       todo_grp.FK_std_steu_THEMA_JAeHRLICH,',
'       todo_grp.STEUERBERATER_INVOLVIERT,',
'       todo_grp.FINANZAMT_INVOLVIERT,',
'       todo_grp.STEUERBERATER_EMPFAENGER,',
'       todo_grp.STEUERBERATER_SENDER,',
'       todo_grp.FINANZAMT_EMPFaeNGER,',
'       todo_grp.FINANZAMT_SENDER,',
'       case when pk_steu_steuer_jahr_todo_grp = FK_steu_TODO_GRP then 1 else 0 end zuord',
'  from T_steu_STEUER_JAHR_TODO_GRP todo_grp',
'     left join (select * from t_steu_steuer_monat_todo where fk_steu_steuer_monat = :P370_fk_steu_steuer_monat) stm_todo on todo_grp.pk_steu_steuer_jahr_todo_grp = stm_todo.FK_steu_TODO_GRP'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18247297336098377)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:RP:P375_PK_STEUER_JAHR_TODO:\#PK_STEUER_JAHR_TODO#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>19687616611489917
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18248986443098386)
,p_db_column_name=>'TODO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18226222887983094)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>35
,p_column_identifier=>'I'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18226560120983097)
,p_db_column_name=>'STEUERBERATER_INVOLVIERT'
,p_display_order=>65
,p_column_identifier=>'L'
,p_column_label=>'Steuerberater Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18226673302983098)
,p_db_column_name=>'FINANZAMT_INVOLVIERT'
,p_display_order=>75
,p_column_identifier=>'M'
,p_column_label=>'Finanzamt Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18226783993983100)
,p_db_column_name=>'STEUERBERATER_SENDER'
,p_display_order=>95
,p_column_identifier=>'O'
,p_column_label=>'Steuerberater Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227074154983102)
,p_db_column_name=>'FINANZAMT_SENDER'
,p_display_order=>115
,p_column_identifier=>'Q'
,p_column_label=>'Finanzamt Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227732340983109)
,p_db_column_name=>'SEL'
,p_display_order=>125
,p_column_identifier=>'R'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18227862436983110)
,p_db_column_name=>'ZUORD'
,p_display_order=>135
,p_column_identifier=>'S'
,p_column_label=>'Zuord'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665052238795104)
,p_db_column_name=>'PK_STEU_STEUER_JAHR_TODO_GRP'
,p_display_order=>145
,p_column_identifier=>'T'
,p_column_label=>'Pk Steu Steuer Jahr Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665088835795105)
,p_db_column_name=>'FK_STD_STEU_THEMA_DAUERHAFT'
,p_display_order=>155
,p_column_identifier=>'U'
,p_column_label=>'Fk Std Steu Thema Dauerhaft'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665217236795106)
,p_db_column_name=>'FK_STD_STEU_THEMA_MONATLICH'
,p_display_order=>165
,p_column_identifier=>'V'
,p_column_label=>'Fk Std Steu Thema Monatlich'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665378390795107)
,p_db_column_name=>'FK_STD_STEU_THEMA_JAEHRLICH'
,p_display_order=>175
,p_column_identifier=>'W'
,p_column_label=>'Fk Std Steu Thema Jaehrlich'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665478117795108)
,p_db_column_name=>'STEUERBERATER_EMPFAENGER'
,p_display_order=>185
,p_column_identifier=>'X'
,p_column_label=>'Steuerberater Empfaenger'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52665499653795109)
,p_db_column_name=>'FINANZAMT_EMPFAENGER'
,p_display_order=>195
,p_column_identifier=>'Y'
,p_column_label=>'Finanzamt Empfaenger'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18251384551119564)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'196918'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TODO:CREATION_DATE:STEUERBERATER_INVOLVIERT:FINANZAMT_INVOLVIERT:STEUERBERATER_SENDER:FINANZAMT_SENDER:SEL:ZUORD:PK_STEU_STEUER_JAHR_TODO_GRP:FK_STD_STEU_THEMA_DAUERHAFT:FK_STD_STEU_THEMA_MONATLICH:FK_STD_STEU_THEMA_JAEHRLICH:STEUERBERATER_EMPFAENGER'
||':FINANZAMT_EMPFAENGER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18288731943348786)
,p_report_id=>wwv_flow_api.id(18251384551119564)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_THEMA_DAUERHAFT'
,p_operator=>'is not null'
,p_condition_sql=>'"FK_THEMA_DAUERHAFT" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18289150378348788)
,p_report_id=>wwv_flow_api.id(18251384551119564)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_THEMA_MONATLICH'
,p_operator=>'is not null'
,p_condition_sql=>'"FK_THEMA_MONATLICH" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18224096039983073)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18224021035983072)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:375'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18225007973983082)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18224883566983081)
,p_button_name=>'CREATE_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:375'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18280041609295061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18225849615983090)
,p_button_name=>'Add_todos'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Add Todos'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18280913310295070)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(18224021035983072)
,p_button_name=>'remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Remove'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18281619020295077)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(18224021035983072)
,p_button_name=>'set_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Datum Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18281704839295078)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(18224021035983072)
,p_button_name=>'set_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Datum Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18281856484295079)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(18224021035983072)
,p_button_name=>'set_status'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set status'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18250673897098391)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(18246922079098377)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:375:&SESSION.::&DEBUG.:375'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18225940615983091)
,p_name=>'P370_FK_STEU_STEUER_MONAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18225849615983090)
,p_prompt=>'Fk Steu Steuer Monat'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  faelligkeitsdatum || '' ('' || monat || ''/'' || jahr || '') - '' || std_name d, pk_steu_steuer_monat',
'from t_steu_steuer_monat stm',
'  left join (select * from t_std where fk_std_group = 342 ) std on std.std_value = stm.fk_std_steu_status',
'order by jahr desc, monat desc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18314253189888936)
,p_name=>'P370_FK_STD_STEU_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(18225849615983090)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fK_std_group = 321'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18280132394295062)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_add_todos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'    ',
'        insert into t_steuer_monat_todo (',
'FK_STEUER_MONAT,',
'FK_TODO_GRP,',
'TODO,',
'CREATION_DATE)',
'    values (',
'      :P370_FK_Steuer_monat,',
'        apex_application.g_f01(i),',
'        ''Neu'',',
'        sysdate',
'    );',
'    ',
'    commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18280041609295061)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18281070924295071)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_remove_todo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'  ',
' delete from t_steuer_monat_todo where pk_steuer_monat_todo = apex_application.g_f02(i);',
' commit;',
'    ',
'   ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18280913310295070)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18281417370295075)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_set_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'  ',
'        update t_steuer_monat_todo set datum_ok = sysdate where pk_steuer_monat_todo = apex_application.g_f02(i);',
'         commit;',
'    ',
'   ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18281619020295077)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18281501887295076)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_set_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'  ',
'        update t_steuer_monat_todo set datum_ok = null where pk_steuer_monat_todo = apex_application.g_f02(i);',
'         commit;',
'    ',
'   ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18281704839295078)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18281973919295080)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'  ',
'        update t_steuer_monat_todo set fk_status = :P370_FK_status where pk_steuer_monat_todo = apex_application.g_f02(i);',
'         commit;',
'    ',
'   ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18281856484295079)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18281087507295072)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' null;',
' --1_add_todos: 1',
' --2_remove_todo: 2',
'',
' ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
