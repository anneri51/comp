prompt --application/pages/page_00266
begin
--   Manifest
--     PAGE: 00266
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>266
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Projekt'
,p_alias=>'PROJEKTLISTE'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Projekt'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200829122953'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2765357047626219)
,p_plug_name=>'Projekt'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pr."PK_PROJ_PROJEKT", ',
'    pr."FK_KON_AUFTRAGGEBER",',
'    pr."FK_KON_PROJEKTPARTNER_1",',
'    pr."FK_KON_PROJEKTPARTNER_2",',
'    pr."PROJEKT",',
'    pr."VON",',
'    pr."BIS",',
'    pr."AKTUELLER_STUNDENSATZ",',
'    pr."PSP_ELEMENT",',
'    pr."CREATED_BY",',
'    pr."CREATED_AT",',
'    pr."MODIFIED_BY",',
'    pr."MODIFIED_AT",',
'    pr.RECHNUNG_GESTELLT,',
'    pr.ZAHLUNG_ABGESCHLOSSEN,',
'    pr.BELEGE_ZUGEORDNET,',
'    pr.KM_GERECHNET,',
'    pr.PROJEKT_ABGESCHLOSSEN,',
'    prart.std_name projekt_art,',
'    case when :P266_SEL_DATE between to_date(to_char(von,''DD.MM.YYYY''),''DD.MM.YYYY'') and to_date(to_char(bis,''DD.MM.YYYY''),''DD.MM.YYYY'') then 1 else 0 end match_time',
' -- case when   to_date(to_char(bis,''DD.MM.YYYY''),''DD.MM.YYYY'')> to_date(''01.01.'' || substr(:P266_SEL_DATE, 7,4)) and to_date(to_char(von,''DD.MM.YYYY''),''DD.MM.YYYY'')  < to_date(''31.12.'' ||substr(:P266_SEL_DATE, 7,4)) then 1 else 0 end same_year,',
' --   case when  to_date(to_char(bis,''DD.MM.YYYY''),''DD.MM.YYYY'')> to_date(''01.'' || substr(:P266_SEL_DATE, 4,7)) and to_date(to_char(von,''DD.MM.YYYY''),''DD.MM.YYYY'')  < to_date(''31.'' || substr(:P266_SEL_DATE, 4,7)) then 1 else 0 end same_month,',
'--  case when :P266_sel_date is not null then to_date(:P266_sel_date,''DD.MM.YYYY'') - to_date(to_char(von,''DD.MM.YYYY''),''DD.MM.YYYY'') end diff_start,',
'--   case when :P266_sel_date is not null then  to_date(to_char(bis,''DD.MM.YYYY''),''DD.MM.YYYY'')  -to_date(:P266_sel_date,''DD.MM.YYYY'') end diff_end  ,',
'--    row_number() over (partition by :P266_sEL_DATE ORDER BY (  to_date(:P266_sel_date,''DD.MM.YYYY'') - to_date(to_char(von,''DD.MM.YYYY''),''DD.MM.YYYY''))) rnr_diff_von    ,   ',
'--   row_number() over (partition by :P266_sEL_DATE ORDER BY ( to_date(to_char(bis,''DD.MM.YYYY''),''DD.MM.YYYY'')  -to_date(:P266_sel_date,''DD.MM.YYYY''))) rnr_diff_bis',
'                                                                                            ',
'                                                                                            ',
'from T_proj_PROJEKT   pr',
' left join (select * from t_std where fk_std_group = 523) prart on pr.fk_std_proj_projekt_art = prart.std_value'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2765388714626219)
,p_name=>'Projekt'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>4205707990017759
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2767419786626252)
,p_db_column_name=>'PROJEKT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2767876229626253)
,p_db_column_name=>'VON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2768210983626253)
,p_db_column_name=>'BIS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2768639805626253)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2769053636626255)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Psp Element'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2769406180626255)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2769803410626255)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2770249239626256)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2770645072626256)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2771033386626256)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2771442181626258)
,p_db_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2771834646626258)
,p_db_column_name=>'BELEGE_ZUGEORDNET'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2772205523626258)
,p_db_column_name=>'KM_GERECHNET'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Km Gerechnet'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2772624824626258)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2773020672626260)
,p_db_column_name=>'PROJEKT_ART'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Projekt Art'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3363105870738502)
,p_db_column_name=>'MATCH_TIME'
,p_display_order=>29
,p_column_identifier=>'T'
,p_column_label=>'Match Time'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433109103411498)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>39
,p_column_identifier=>'U'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433203065411499)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>49
,p_column_identifier=>'V'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433327868411500)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>59
,p_column_identifier=>'W'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52433458781411501)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>69
,p_column_identifier=>'X'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2774125545822405)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'42145'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:RECHNUNG_GESTELLT:ZAHLUNG_ABGESCHLOSSEN:BELEGE_ZUGEORDNET:KM_GERECHNET:PROJEKT_ABGESCHLOSSEN:PROJEKT_ART:MATCH_TIME:PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK'
||'_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3361961473738490)
,p_plug_name=>'Eingabe'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3362166914738492)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3361961473738490)
,p_button_name=>'Set_Date'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Date'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3362022947738491)
,p_name=>'P266_SEL_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3361961473738490)
,p_prompt=>'Sel Date'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
