prompt --application/pages/page_00151
begin
--   Manifest
--     PAGE: 00151
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>151
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Zusammenhang_LEX'
,p_alias=>'ZUSAMMENHANG_LEX1'
,p_step_title=>'Zusammenhang_LEX'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200920054201'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2271993787758112)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2600323997074906)
,p_plug_name=>'Relation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_rel_lex_kto_bel rel',
'  left join t_inp_belege_all inp on rel.fk_inp_belege_all = inp.pk_inp_belege_all',
'where fk_inp_belege_all = :P151_PK_INP_BELEGE_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Relation'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2600445247074907)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7215864252273542
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600501963074908)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.::P252_PK_REL_LEX_KTO_BEL:#PK_REL_LEX_KTO_BEL#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600625910074909)
,p_db_column_name=>'FK_LEX_OLD'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600772558074910)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600797708074911)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600910795074912)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2601059357074913)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_PK_INP_BELEGE_ALL:#FK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2601177037074914)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2601205850074915)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638643236143166)
,p_db_column_name=>'OK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638712128143167)
,p_db_column_name=>'OK_DATUM'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ok Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638845384143168)
,p_db_column_name=>'COMM'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2638952050143169)
,p_db_column_name=>'FK_REL_LEX_KTO_BEL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639037888143170)
,p_db_column_name=>'FK_INP_BELEGE_POS_ALL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639113206143171)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639275065143172)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639366795143173)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639427981143174)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639569778143175)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639607552143176)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639741952143177)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639846002143178)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639971512143179)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2639983145143180)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640114207143181)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640225565143182)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640282724143183)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640407980143184)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640539573143185)
,p_db_column_name=>'VON'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640606246143186)
,p_db_column_name=>'BIS'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640749054143187)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640803031143188)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2640944424143189)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641066222143190)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641168217143191)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641207744143192)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641320841143193)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641478628143194)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641508254143195)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641599615143196)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641750398143197)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641784966143198)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2641891178143199)
,p_db_column_name=>'BELEG'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642066475143200)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642105171143201)
,p_db_column_name=>'LITER'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642234397143202)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642353386143203)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642425636143204)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642509649143205)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642623804143206)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642707352143207)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642812845143208)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642885766143209)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2642983473143210)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643144344143211)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643235968143212)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643297747143213)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643389268143214)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643565280143215)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643634069143266)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643759759143267)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643869316143268)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2643931579143269)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644004296143270)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644170439143271)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644225173143272)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644347125143273)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644454219143274)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644491395143275)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644614144143276)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644762289143277)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644851702143278)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2644900208143279)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645020151143280)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645157387143281)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645207355143282)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645348440143283)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645442672143284)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645532095143285)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645635014143286)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645744594143287)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645866272143288)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645951583143289)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2645999261143290)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646146074143291)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646195426143292)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646290819143293)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646420376143294)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646486584143295)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646602600143296)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646723587143297)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646804725143298)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2646907177143299)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647072481143300)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647159605143301)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647220036143302)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647303159143303)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647390223143304)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647542374143305)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647640900143306)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647681338143307)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Modify At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647825092143308)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Modify By'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2647948267143309)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648074798143310)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648164456143311)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648218517143312)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648343298143313)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648457067143314)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648490716143315)
,p_db_column_name=>'FK_INT_INTERNET_APP'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Fk Int Internet App'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648645176143266)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648723594143267)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648822888143268)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648915785143269)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2648982952143270)
,p_db_column_name=>'DUMMY'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649170417143271)
,p_db_column_name=>'STORNIERT'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Storniert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649250017143272)
,p_db_column_name=>'FK_ADR_ADRESSE_SCHNELL'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Fk Adr Adresse Schnell'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649354094143273)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649424923143274)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649544884143275)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649628347143276)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649714714143277)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649851541143278)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2649907416143279)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2650057140143280)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2650148958143281)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2650197303143282)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2650286517143283)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2650476337143284)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2693043411159091)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'73085'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_LEX_KTO_BEL:FK_LEX_OLD:FK_LEX_RELATION:FK_MAIN_KEY:FK_IMP_BA_BEL:FK_INP_BELEGE_ALL:CREATED_AT:MODIFIED_AT:OK:OK_DATUM:COMM:FK_REL_LEX_KTO_BEL:FK_INP_BELEGE_POS_ALL:PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_'
||'KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUMMER:BEZEICHNUNG:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_WAEHRUNG:STEUE'
||'RNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:F'
||'K_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG'
||'_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_ZAHLUNGSSTATUS:COMM_VERGEHEN:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUN'
||'KTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:FK_C'
||'ALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STD_INP_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_INT_INTERNET_APP:FK_C'
||'ONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_KON_GESCHAEFTSPARTNER:DUMMY:STORNIERT:FK_ADR_ADRESSE_SCHNELL:FK_LEX_RELATION_SRC:FK_MAIN_KEY_SRC:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:VERG_DATUM_RECHTSKRA'
||'FT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZEICHEN:VERG_TATBESTANDSNUMMER:FK_VER_VERTRAG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8610647630483578)
,p_plug_name=>'Step 5'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8594016681483570)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8610747971483578)
,p_plug_name=>'Step 5'
,p_parent_plug_id=>wwv_flow_api.id(8610647630483578)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14186615856489801)
,p_plug_name=>'Lex_check'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2489209813028370)
,p_plug_name=>'Lex_check'
,p_parent_plug_id=>wwv_flow_api.id(14186615856489801)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="background-color:blue"'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INP_BELEGE_ALL,',
'       FK_LEX_BUCHUNG,',
'       FK_BAS_KAT_KATEGORIE,',
'       FK_BAS_KAL_ARBEITSTAG,',
'       FK_KTO_BUCHUNG,',
'       FK_STD_KTO_ZAHLUNGSART,',
'       FK_STD_VERW_VERWENDUNGSZWECK,',
'       FK_INV_INVENTAR,',
'       FK_PROJ_PROJEKT,',
'       BELEGNUMMER,',
'       BEZEICHNUNG,',
'       FK_ADR_LAND,',
'       FK_ADR_CITY,',
'       BEL_DATUM,',
'       VON,',
'       BIS,',
'       NETTO_BETRAG,',
'       FK_BAS_STEU_STEUER_SATZ,',
'       MWST_BETRAG,',
'       BRUTTO_BETRAG,',
'       FK_BAS_MON_WAEHRUNG,',
'       STEUERNUMMER,',
'       FK_BAS_MON_UMRECHNUNGSKURS,',
'       COMM_REST_BELEG,',
'       COMM_TEL_BELEG,',
'       COMM_PRODUKTE,',
'       COMM_BEGRUENDUNG,',
'       COMM_SONSTIGES,',
'       BELEG,',
'       ZAHLUNGSBELEG,',
'       LITER,',
'       ZAPFSAEULE,',
'       FK_LOC_LOCATION,',
'       PERSOENLICH_VOR_ORT,',
'       BELEG_UHRZEIT,',
'       VON_UHRZEIT,',
'       BIS_UHRZEIT,',
'       FK_BAS_KAL_VON_ARBEITSTAG,',
'       FK_BAS_KAL_BIS_ARBEITSTAG,',
'       COMM_ADRESSE,',
'       TANKSTELLEN_NR,',
'       BRUTTO_BETRAG_INCL_TRINKG,',
'       COMM_PARKTICKET,',
'       FRMDW_NETTO_BETRAG,',
'       FK_BAS_MON_FRMDW,',
'       FK_BAS_MON_FRMDW_MWST_SATZ,',
'       FRMDW_MWST_BETRAG,',
'       FRMDW_BRUTTO_BETRAG,',
'       FRMDW_BRUTTO_INCL_TRINKG,',
'       MWST_BETRAG_EUR,',
'       BRUTTO_BETRAG_EUR,',
'       BRUTTO_INCL_TRINKG_EUR,',
'       NETTO_BETRAG_EUR,',
'       PREIS_PRO_MENGE,',
'       MENGENEINHEIT,',
'       LA_DATUM,',
'       FK_LA_KONTO,',
'       FK_LA_WDH,',
'       FK_STD_INP_ZAHLUNGSSTATUS,',
'       COMM_VERGEHEN,',
'       VERG_BEHOERDE,',
'       VERG_CNT_PUNKTE,',
'       FK_BEL_BELEG_ABLAGE,',
'       FK_ABL_ORDNER_PAGE,',
'       VERG_CNT_PUNKTE_GESCHAETZT,',
'       VERG_PUNKTE_VON,',
'       VERG_PUNKTE_BIS,',
'       FK_LOC_LOCATION_VERG,',
'       FK_IMP_BA_BEL_OLD,',
'       VERG_GESCHW_IST,',
'       VERG_GESCHW_SOLL,',
'       VERG_GESCHW_UEBER_GRZ,',
'       VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,',
'       VERG_CODE_BUSSGELD,',
'       VERG_DESCR_BUSSGELD,',
'       GEZAHLT_AM,',
'       WEBSEITE,',
'       KUNDENNUMMER,',
'       FK_REAL_BELEG_EXIST,',
'       FK_CALC_STATE,',
'       FK_CALC_STATE_EUR,',
'       FK_CALC_STATE_FRMDW,',
'       FK_STD_INP_STATUS,',
'       DATUM_VERGEHEN,',
'       CREATE_AT,',
'       CREATE_BY,',
'       MODIFY_AT,',
'       MODIFY_BY,',
'       DATUM_ORT_OK,',
'       DATUM_ADDRESSE_OK,',
'       DATUM_BUSSGELD_OK,',
'       DATUM_BELEG_POS_OK,',
'       DATUM_BUCHUNG_OK,',
'       DATUM_VERPFL_BEL_OK,',
'       FK_INT_INTERNET_APP,',
'       FK_CONTR_DUPL_STATUS,',
'       DATUM_DUPL_OK,',
'       DUPL_BEMERKUNG,',
'       FK_KON_GESCHAEFTSPARTNER,',
'       DUMMY,',
'       STORNIERT,',
'       FK_ADR_ADRESSE_SCHNELL,',
'       FK_LEX_RELATION_SRC,',
'       FK_MAIN_KEY_SRC,',
'       FK_STD_CONTR_STATUS_KAT,',
'       FK_STD_CONTR_STATUS_VERW,',
'       DATUM_STATUS_VERW,',
'       DATUM_STATUS_KAT,',
'       VERG_DATUM_RECHTSKRAFT,',
'       VERG_DATUM_TILGUNG,',
'       VERG_NUMMER_FLENS,',
'       VERG_AKTENZEICHEN,',
'       VERG_TATBESTANDSNUMMER,',
'       FK_VER_VERTRAG',
'  from T_INP_BELEGE_ALL inp',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag',
'  where arb.jahr = :P151_Jahr'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Lex_check'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2489349674028370)
,p_name=>'Lex_check'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7104768679227005
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2489733820028383)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2490122290028389)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2490559905028389)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2490927881028389)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2491347384028390)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2491737548028390)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2492138811028390)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2492522200028390)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2492892825028390)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2493327115028391)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2493734718028391)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2494179344028391)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2494514127028391)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2494965469028391)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2495302722028391)
,p_db_column_name=>'VON'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2495719663028392)
,p_db_column_name=>'BIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2496092472028392)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2496559727028392)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2496921110028392)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2497341151028393)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2497756212028393)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2498158049028393)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2498508840028393)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2500942602028395)
,p_db_column_name=>'LITER'
,p_display_order=>31
,p_column_identifier=>'AC'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2501343967028395)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>32
,p_column_identifier=>'AD'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2501692011028395)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>33
,p_column_identifier=>'AE'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2502112575028395)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>34
,p_column_identifier=>'AF'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2502523139028395)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>35
,p_column_identifier=>'AG'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2502882704028396)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>36
,p_column_identifier=>'AH'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2503330361028396)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>37
,p_column_identifier=>'AI'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2503725145028396)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>38
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2504163451028396)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>39
,p_column_identifier=>'AK'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2504529597028396)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>40
,p_column_identifier=>'AL'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2504901151028397)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>41
,p_column_identifier=>'AM'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2505311692028397)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>42
,p_column_identifier=>'AN'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2506169143028397)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>44
,p_column_identifier=>'AP'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2506570229028398)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>45
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2506922382028398)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>46
,p_column_identifier=>'AR'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2507314502028398)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>47
,p_column_identifier=>'AS'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2507720492028399)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>48
,p_column_identifier=>'AT'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2508129197028399)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>49
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2508504359028399)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>50
,p_column_identifier=>'AV'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2508907782028399)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>51
,p_column_identifier=>'AW'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2509374467028399)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>52
,p_column_identifier=>'AX'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2509707260028400)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>53
,p_column_identifier=>'AY'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2510095846028400)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>54
,p_column_identifier=>'AZ'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2510535274028400)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>55
,p_column_identifier=>'BA'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2510926103028400)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>56
,p_column_identifier=>'BB'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2511301675028401)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>57
,p_column_identifier=>'BC'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2511682083028401)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>58
,p_column_identifier=>'BD'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2512104288028401)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>59
,p_column_identifier=>'BE'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2512973997028401)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>61
,p_column_identifier=>'BG'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2513327932028402)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>62
,p_column_identifier=>'BH'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2513773780028402)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>63
,p_column_identifier=>'BI'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2514153771028403)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>64
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2514498829028403)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>65
,p_column_identifier=>'BK'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2514964464028403)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>66
,p_column_identifier=>'BL'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2515286093028403)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>67
,p_column_identifier=>'BM'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2515718643028404)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>68
,p_column_identifier=>'BN'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2516084567028404)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>69
,p_column_identifier=>'BO'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2516552707028404)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>70
,p_column_identifier=>'BP'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2516904092028404)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>71
,p_column_identifier=>'BQ'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2517288159028404)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>72
,p_column_identifier=>'BR'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2517775333028405)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>73
,p_column_identifier=>'BS'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2518142760028406)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>74
,p_column_identifier=>'BT'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2518533092028406)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>75
,p_column_identifier=>'BU'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2518896205028406)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>76
,p_column_identifier=>'BV'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2519306208028406)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>77
,p_column_identifier=>'BW'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2519742436028406)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>78
,p_column_identifier=>'BX'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2520175245028407)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>79
,p_column_identifier=>'BY'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2520541258028407)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>80
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2520931403028407)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>81
,p_column_identifier=>'CA'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2521342234028407)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>82
,p_column_identifier=>'CB'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2521736690028407)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>83
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2522128697028408)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>84
,p_column_identifier=>'CD'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2522495707028408)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>85
,p_column_identifier=>'CE'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2522886862028408)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>86
,p_column_identifier=>'CF'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2523374560028408)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>87
,p_column_identifier=>'CG'
,p_column_label=>'Modify At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2523723471028408)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>88
,p_column_identifier=>'CH'
,p_column_label=>'Modify By'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2524135505028409)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>89
,p_column_identifier=>'CI'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2524523353028409)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>90
,p_column_identifier=>'CJ'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2524917419028409)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>91
,p_column_identifier=>'CK'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2525338537028409)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>92
,p_column_identifier=>'CL'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2525774518028410)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>93
,p_column_identifier=>'CM'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2526130156028410)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>94
,p_column_identifier=>'CN'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2526498587028410)
,p_db_column_name=>'FK_INT_INTERNET_APP'
,p_display_order=>95
,p_column_identifier=>'CO'
,p_column_label=>'Fk Int Internet App'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2526941111028410)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>96
,p_column_identifier=>'CP'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2527283894028410)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>97
,p_column_identifier=>'CQ'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2527735151028411)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>98
,p_column_identifier=>'CR'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2528086094028411)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>99
,p_column_identifier=>'CS'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2528506425028411)
,p_db_column_name=>'DUMMY'
,p_display_order=>100
,p_column_identifier=>'CT'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2528979393028411)
,p_db_column_name=>'STORNIERT'
,p_display_order=>101
,p_column_identifier=>'CU'
,p_column_label=>'Storniert'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2529324934028411)
,p_db_column_name=>'FK_ADR_ADRESSE_SCHNELL'
,p_display_order=>102
,p_column_identifier=>'CV'
,p_column_label=>'Fk Adr Adresse Schnell'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2529779562028412)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>103
,p_column_identifier=>'CW'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2530165489028412)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>104
,p_column_identifier=>'CX'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2530491116028412)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>105
,p_column_identifier=>'CY'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2530977909028412)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>106
,p_column_identifier=>'CZ'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2531307649028413)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>107
,p_column_identifier=>'DA'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2531706345028413)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>108
,p_column_identifier=>'DB'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2532180805028413)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>109
,p_column_identifier=>'DC'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2532505523028413)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>110
,p_column_identifier=>'DD'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2532884616028413)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>111
,p_column_identifier=>'DE'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2533326279028414)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>112
,p_column_identifier=>'DF'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2533689277028414)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>113
,p_column_identifier=>'DG'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2534177802028414)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>114
,p_column_identifier=>'DH'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2272249086758114)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>124
,p_column_identifier=>'DI'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2272365179758115)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>134
,p_column_identifier=>'DJ'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536010816039866)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>144
,p_column_identifier=>'DK'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536086639039867)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>154
,p_column_identifier=>'DL'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536270871039868)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>164
,p_column_identifier=>'DM'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536341241039869)
,p_db_column_name=>'BELEG'
,p_display_order=>174
,p_column_identifier=>'DN'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536460494039870)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>184
,p_column_identifier=>'DO'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536552667039871)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>194
,p_column_identifier=>'DP'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536648055039872)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>204
,p_column_identifier=>'DQ'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2693662617159145)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'73091'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUMMER:BEZEICHNUNG:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BET'
||'RAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_WAEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBE'
||'ITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_'
||'BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_ZAHLUNGSSTATUS:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_'
||'IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:'
||'FK_STD_INP_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_INT_INTERNET_APP:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK'
||'_KON_GESCHAEFTSPARTNER:DUMMY:STORNIERT:FK_ADR_ADRESSE_SCHNELL:FK_LEX_RELATION_SRC:FK_MAIN_KEY_SRC:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKT'
||'ENZEICHEN:VERG_TATBESTANDSNUMMER:FK_VER_VERTRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:COMM_PARKTICKET:COMM_VERGEHEN'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14186687574489802)
,p_plug_name=>'Lex_check_ok'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2553515924061989)
,p_plug_name=>'Lex_check_ok'
,p_parent_plug_id=>wwv_flow_api.id(14186687574489802)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>110
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INP_BELEGE_ALL,',
'       FK_LEX_BUCHUNG,',
'       FK_BAS_KAT_KATEGORIE,',
'       FK_BAS_KAL_ARBEITSTAG,',
'       FK_KTO_BUCHUNG,',
'       FK_STD_KTO_ZAHLUNGSART,',
'       FK_STD_VERW_VERWENDUNGSZWECK,',
'       FK_INV_INVENTAR,',
'       FK_PROJ_PROJEKT,',
'       BELEGNUMMER,',
'       BEZEICHNUNG,',
'       FK_ADR_LAND,',
'       FK_ADR_CITY,',
'       BEL_DATUM,',
'       VON,',
'       BIS,',
'       NETTO_BETRAG,',
'       FK_BAS_STEU_STEUER_SATZ,',
'       MWST_BETRAG,',
'       BRUTTO_BETRAG,',
'       FK_BAS_MON_WAEHRUNG,',
'       STEUERNUMMER,',
'       FK_BAS_MON_UMRECHNUNGSKURS,',
'       COMM_REST_BELEG,',
'       COMM_TEL_BELEG,',
'       COMM_PRODUKTE,',
'       COMM_BEGRUENDUNG,',
'       COMM_SONSTIGES,',
'       BELEG,',
'       ZAHLUNGSBELEG,',
'       LITER,',
'       ZAPFSAEULE,',
'       FK_LOC_LOCATION,',
'       PERSOENLICH_VOR_ORT,',
'       BELEG_UHRZEIT,',
'       VON_UHRZEIT,',
'       BIS_UHRZEIT,',
'       FK_BAS_KAL_VON_ARBEITSTAG,',
'       FK_BAS_KAL_BIS_ARBEITSTAG,',
'       COMM_ADRESSE,',
'       TANKSTELLEN_NR,',
'       BRUTTO_BETRAG_INCL_TRINKG,',
'       COMM_PARKTICKET,',
'       FRMDW_NETTO_BETRAG,',
'       FK_BAS_MON_FRMDW,',
'       FK_BAS_MON_FRMDW_MWST_SATZ,',
'       FRMDW_MWST_BETRAG,',
'       FRMDW_BRUTTO_BETRAG,',
'       FRMDW_BRUTTO_INCL_TRINKG,',
'       MWST_BETRAG_EUR,',
'       BRUTTO_BETRAG_EUR,',
'       BRUTTO_INCL_TRINKG_EUR,',
'       NETTO_BETRAG_EUR,',
'       PREIS_PRO_MENGE,',
'       MENGENEINHEIT,',
'       LA_DATUM,',
'       FK_LA_KONTO,',
'       FK_LA_WDH,',
'       FK_STD_INP_ZAHLUNGSSTATUS,',
'       COMM_VERGEHEN,',
'       VERG_BEHOERDE,',
'       VERG_CNT_PUNKTE,',
'       FK_BEL_BELEG_ABLAGE,',
'       FK_ABL_ORDNER_PAGE,',
'       VERG_CNT_PUNKTE_GESCHAETZT,',
'       VERG_PUNKTE_VON,',
'       VERG_PUNKTE_BIS,',
'       FK_LOC_LOCATION_VERG,',
'       FK_IMP_BA_BEL_OLD,',
'       VERG_GESCHW_IST,',
'       VERG_GESCHW_SOLL,',
'       VERG_GESCHW_UEBER_GRZ,',
'       VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,',
'       VERG_CODE_BUSSGELD,',
'       VERG_DESCR_BUSSGELD,',
'       GEZAHLT_AM,',
'       WEBSEITE,',
'       KUNDENNUMMER,',
'       FK_REAL_BELEG_EXIST,',
'       FK_CALC_STATE,',
'       FK_CALC_STATE_EUR,',
'       FK_CALC_STATE_FRMDW,',
'       FK_STD_INP_STATUS,',
'       DATUM_VERGEHEN,',
'       CREATE_AT,',
'       CREATE_BY,',
'       MODIFY_AT,',
'       MODIFY_BY,',
'       DATUM_ORT_OK,',
'       DATUM_ADDRESSE_OK,',
'       DATUM_BUSSGELD_OK,',
'       DATUM_BELEG_POS_OK,',
'       DATUM_BUCHUNG_OK,',
'       DATUM_VERPFL_BEL_OK,',
'       FK_INT_INTERNET_APP,',
'       FK_CONTR_DUPL_STATUS,',
'       DATUM_DUPL_OK,',
'       DUPL_BEMERKUNG,',
'       FK_KON_GESCHAEFTSPARTNER,',
'       DUMMY,',
'       STORNIERT,',
'       FK_ADR_ADRESSE_SCHNELL,',
'       FK_LEX_RELATION_SRC,',
'       FK_MAIN_KEY_SRC,',
'       FK_STD_CONTR_STATUS_KAT,',
'       FK_STD_CONTR_STATUS_VERW,',
'       DATUM_STATUS_VERW,',
'       DATUM_STATUS_KAT,',
'       VERG_DATUM_RECHTSKRAFT,',
'       VERG_DATUM_TILGUNG,',
'       VERG_NUMMER_FLENS,',
'       VERG_AKTENZEICHEN,',
'       VERG_TATBESTANDSNUMMER,',
'       FK_VER_VERTRAG',
'  from T_INP_BELEGE_ALL inp',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag',
'  where arb.jahr = :P151_Jahr and datum_buchung_ok is not null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Lex_check_ok'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2553649215061990)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7169068220260625
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553772251061991)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553848923061992)
,p_db_column_name=>'LITER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553937303061993)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554038417061994)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554122294061995)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554210620061996)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554375959061997)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554408316061998)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554487355061999)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554674518062000)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554766187062001)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554817411062002)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2554963335062003)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555015134062004)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555126847062005)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555224224062006)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555380856062007)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555437469062008)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555497670062009)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555624029062010)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555762856062011)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555803020062012)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555955308062013)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2556014954062014)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2556105463062015)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591304292074766)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591453479074767)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591571711074768)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591679846074769)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591736814074770)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591874010074771)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2591883840074772)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592070817074773)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592142067074774)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592220467074775)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592347189074776)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592415691074777)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592525860074778)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592678664074779)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592722463074780)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592828012074781)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2592882434074782)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593016786074783)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593118649074784)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593234970074785)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593295110074786)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593445629074787)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593489585074788)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593652417074789)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593755989074790)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593867618074791)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2593918526074792)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594063322074793)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594091223074794)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594266336074795)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594372984074796)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594469779074797)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594578828074798)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Modify At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594595449074799)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Modify By'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594684643074800)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594825090074801)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2594895107074802)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595048990074803)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595162675074804)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595202206074805)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595342466074806)
,p_db_column_name=>'FK_INT_INTERNET_APP'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Int Internet App'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595435855074807)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595491822074808)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595615649074809)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595740766074810)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595831714074811)
,p_db_column_name=>'DUMMY'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2595930254074812)
,p_db_column_name=>'STORNIERT'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Storniert'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596013381074813)
,p_db_column_name=>'FK_ADR_ADRESSE_SCHNELL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Fk Adr Adresse Schnell'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596116916074814)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596260840074815)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596290984074866)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596427737074867)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596548116074868)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596653814074869)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596694710074870)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596794659074871)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2596919602074872)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597014241074873)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597120969074874)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597231990074875)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597329982074876)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597385725074877)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597569876074878)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597675708074879)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597707760074880)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597836470074881)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2597974269074882)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598076176074883)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598089266074884)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598205168074885)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598370554074886)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598433748074887)
,p_db_column_name=>'VON'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598525078074888)
,p_db_column_name=>'BIS'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598644020074889)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598717869074890)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598845672074891)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2598945556074892)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599051732074893)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599098121074894)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599277315074895)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599298642074896)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599432398074897)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599555348074898)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599660202074899)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599682949074900)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599819936074901)
,p_db_column_name=>'BELEG'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599971407074902)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2599981355074903)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2600167047074904)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2694948668159177)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'73104'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW'
||':FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:FK_LEX_BUCHUNG:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_IN'
||'P_ZAHLUNGSSTATUS:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOLL:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW'
||'_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_BAS_KAT_KATEGORIE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STD_INP_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_'
||'AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_INT_INTERNET_APP:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_KON_GESCHAEFTSPARTNER:DUMMY:STORNIERT:FK_ADR_ADRESSE_SCHNEL'
||'L:FK_LEX_RELATION_SRC:FK_MAIN_KEY_SRC:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:FK_BAS_KAL_ARBEITSTAG:DATUM_STATUS_VERW:DATUM_STATUS_KAT:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZEICHEN:VERG_TATBESTANDSNUMMER:FK_VE'
||'R_VERTRAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUMMER:BEZEICHNUNG:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_W'
||'AEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:COMM_PARKTICKET:COMM_VERGEHEN'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15289993246623202)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(14186687574489802)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>120
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15290164581623203)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(14186687574489802)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>130
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14186852694489803)
,p_plug_name=>'Lex_check_not_ok'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2536722714039873)
,p_plug_name=>'INP_not_ok'
,p_parent_plug_id=>wwv_flow_api.id(14186852694489803)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_INP_BELEGE_ALL,',
'       FK_LEX_BUCHUNG,',
'       FK_BAS_KAT_KATEGORIE,',
'       FK_BAS_KAL_ARBEITSTAG,',
'       FK_KTO_BUCHUNG,',
'       FK_STD_KTO_ZAHLUNGSART,',
'       FK_STD_VERW_VERWENDUNGSZWECK,',
'       FK_INV_INVENTAR,',
'       FK_PROJ_PROJEKT,',
'       BELEGNUMMER,',
'       BEZEICHNUNG,',
'       FK_ADR_LAND,',
'       FK_ADR_CITY,',
'       BEL_DATUM,',
'       VON,',
'       BIS,',
'       NETTO_BETRAG,',
'       FK_BAS_STEU_STEUER_SATZ,',
'       MWST_BETRAG,',
'       BRUTTO_BETRAG,',
'       FK_BAS_MON_WAEHRUNG,',
'       STEUERNUMMER,',
'       FK_BAS_MON_UMRECHNUNGSKURS,',
'       COMM_REST_BELEG,',
'       COMM_TEL_BELEG,',
'       COMM_PRODUKTE,',
'       COMM_BEGRUENDUNG,',
'       COMM_SONSTIGES,',
'       BELEG,',
'       ZAHLUNGSBELEG,',
'       LITER,',
'       ZAPFSAEULE,',
'       FK_LOC_LOCATION,',
'       PERSOENLICH_VOR_ORT,',
'       BELEG_UHRZEIT,',
'       VON_UHRZEIT,',
'       BIS_UHRZEIT,',
'       FK_BAS_KAL_VON_ARBEITSTAG,',
'       FK_BAS_KAL_BIS_ARBEITSTAG,',
'       COMM_ADRESSE,',
'       TANKSTELLEN_NR,',
'       BRUTTO_BETRAG_INCL_TRINKG,',
'       COMM_PARKTICKET,',
'       FRMDW_NETTO_BETRAG,',
'       FK_BAS_MON_FRMDW,',
'       FK_BAS_MON_FRMDW_MWST_SATZ,',
'       FRMDW_MWST_BETRAG,',
'       FRMDW_BRUTTO_BETRAG,',
'       FRMDW_BRUTTO_INCL_TRINKG,',
'       MWST_BETRAG_EUR,',
'       BRUTTO_BETRAG_EUR,',
'       BRUTTO_INCL_TRINKG_EUR,',
'       NETTO_BETRAG_EUR,',
'       PREIS_PRO_MENGE,',
'       MENGENEINHEIT,',
'       LA_DATUM,',
'       FK_LA_KONTO,',
'       FK_LA_WDH,',
'       FK_STD_INP_ZAHLUNGSSTATUS,',
'       COMM_VERGEHEN,',
'       VERG_BEHOERDE,',
'       VERG_CNT_PUNKTE,',
'       FK_BEL_BELEG_ABLAGE,',
'       FK_ABL_ORDNER_PAGE,',
'       VERG_CNT_PUNKTE_GESCHAETZT,',
'       VERG_PUNKTE_VON,',
'       VERG_PUNKTE_BIS,',
'       FK_LOC_LOCATION_VERG,',
'       FK_IMP_BA_BEL_OLD,',
'       VERG_GESCHW_IST,',
'       VERG_GESCHW_SOLL,',
'       VERG_GESCHW_UEBER_GRZ,',
'       VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,',
'       VERG_CODE_BUSSGELD,',
'       VERG_DESCR_BUSSGELD,',
'       GEZAHLT_AM,',
'       WEBSEITE,',
'       KUNDENNUMMER,',
'       FK_REAL_BELEG_EXIST,',
'       FK_CALC_STATE,',
'       FK_CALC_STATE_EUR,',
'       FK_CALC_STATE_FRMDW,',
'       FK_STD_INP_STATUS,',
'       DATUM_VERGEHEN,',
'       CREATE_AT,',
'       CREATE_BY,',
'       MODIFY_AT,',
'       MODIFY_BY,',
'       DATUM_ORT_OK,',
'       DATUM_ADDRESSE_OK,',
'       DATUM_BUSSGELD_OK,',
'       DATUM_BELEG_POS_OK,',
'       DATUM_BUCHUNG_OK,',
'       DATUM_VERPFL_BEL_OK,',
'       FK_INT_INTERNET_APP,',
'       FK_CONTR_DUPL_STATUS,',
'       DATUM_DUPL_OK,',
'       DUPL_BEMERKUNG,',
'       FK_KON_GESCHAEFTSPARTNER,',
'       DUMMY,',
'       STORNIERT,',
'       FK_ADR_ADRESSE_SCHNELL,',
'       FK_LEX_RELATION_SRC,',
'       FK_MAIN_KEY_SRC,',
'       FK_STD_CONTR_STATUS_KAT,',
'       FK_STD_CONTR_STATUS_VERW,',
'       DATUM_STATUS_VERW,',
'       DATUM_STATUS_KAT,',
'       VERG_DATUM_RECHTSKRAFT,',
'       VERG_DATUM_TILGUNG,',
'       VERG_NUMMER_FLENS,',
'       VERG_AKTENZEICHEN,',
'       VERG_TATBESTANDSNUMMER,',
'       FK_VER_VERTRAG',
'  from T_INP_BELEGE_ALL inp',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag',
'  where arb.jahr = :P151_Jahr and datum_buchung_ok is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'INP_not_ok'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2536785257039874)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.::P151_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>7152204262238509
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536963636039875)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.::P422_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2536999007039876)
,p_db_column_name=>'LITER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537138364039877)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537192413039878)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537296805039879)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537415327039880)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537550798039881)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537604251039882)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537691382039883)
,p_db_column_name=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Bas Kal Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537797557039884)
,p_db_column_name=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Bas Kal Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537886635039885)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2537993092039886)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538113705039887)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538183365039888)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538323686039889)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538396424039890)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538552725039891)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538637550039892)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538692666039893)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538829205039894)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2538900719039895)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539011303039896)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539137914039897)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539275062039898)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539324733039899)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539410163039900)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539578147039901)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539602895039902)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539715496039903)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539804623039904)
,p_db_column_name=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Std Inp Zahlungsstatus'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2539948751039905)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540017687039906)
,p_db_column_name=>'VERG_CNT_PUNKTE'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Verg Cnt Punkte'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540117637039907)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540250149039908)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540349624039909)
,p_db_column_name=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Verg Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540420393039910)
,p_db_column_name=>'VERG_PUNKTE_VON'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Verg Punkte Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540551174039911)
,p_db_column_name=>'VERG_PUNKTE_BIS'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Verg Punkte Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540588637039912)
,p_db_column_name=>'FK_LOC_LOCATION_VERG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Loc Location Verg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540739308039913)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540872296039914)
,p_db_column_name=>'VERG_GESCHW_IST'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Verg Geschw Ist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2540884249039915)
,p_db_column_name=>'VERG_GESCHW_SOLL'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Verg Geschw Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546280826061866)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Verg Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546314418061867)
,p_db_column_name=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546450656061868)
,p_db_column_name=>'VERG_CODE_BUSSGELD'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Verg Code Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546533237061869)
,p_db_column_name=>'VERG_DESCR_BUSSGELD'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Verg Descr Bussgeld'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546666818061870)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546756471061871)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546824909061872)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2546937538061873)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547058461061874)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547136449061875)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547242519061876)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547354445061877)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547447677061878)
,p_db_column_name=>'FK_STD_INP_STATUS'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fk Std Inp Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547504218061879)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547610120061880)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Create At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547694800061881)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547843791061882)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Modify At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2547970963061883)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Modify By'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548023994061884)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548172902061885)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548258301061886)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548288507061887)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548406232061888)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548511973061889)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548658351061890)
,p_db_column_name=>'FK_INT_INTERNET_APP'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Int Internet App'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548688424061891)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548800077061892)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2548915016061893)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549012796061894)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549087429061895)
,p_db_column_name=>'DUMMY'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549240546061896)
,p_db_column_name=>'STORNIERT'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Storniert'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549303061061897)
,p_db_column_name=>'FK_ADR_ADRESSE_SCHNELL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Fk Adr Adresse Schnell'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549403911061898)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549505049061899)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549628053061900)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549692230061901)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549811320061902)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2549907949061903)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550039669061904)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550145997061905)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550215672061906)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550305566061907)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550443158061908)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550569144061909)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550675810061910)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550696823061911)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550865590061912)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:252:P252_FK_INP_BELEGE_ALL,P252_PK_REL_LEX_KTO_BEL:#PK_INP_BELEGE_ALL#,'
,p_column_linktext=>'#FK_STD_KTO_ZAHLUNGSART#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2550945683061913)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551035336061914)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551091701061915)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551270191061966)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551325947061967)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551439449061968)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551560936061969)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551618782061970)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551711540061971)
,p_db_column_name=>'VON'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551829175061972)
,p_db_column_name=>'BIS'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551885072061973)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2551987221061974)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552133249061975)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552264902061976)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552283622061977)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552452295061978)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552562373061979)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552626506061980)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552703866061981)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552791350061982)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552953546061983)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2552988448061984)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553118875061985)
,p_db_column_name=>'BELEG'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553189298061986)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553340566061987)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2553474255061988)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2694222273159161)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'73097'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:BEZEICHNUNG:FK_STD_KTO_ZAHLUNGSART:LITER:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_BAS_KAL_VON_ARBEITSTAG:FK_BAS_KAL_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:'
||'FRMDW_NETTO_BETRAG:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:FK_LEX_BUCHUNG:MENGENEINHEIT:LA_DA'
||'TUM:FK_LA_KONTO:FK_LA_WDH:FK_STD_INP_ZAHLUNGSSTATUS:VERG_BEHOERDE:VERG_CNT_PUNKTE:FK_BEL_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:VERG_CNT_PUNKTE_GESCHAETZT:VERG_PUNKTE_VON:VERG_PUNKTE_BIS:FK_LOC_LOCATION_VERG:FK_IMP_BA_BEL_OLD:VERG_GESCHW_IST:VERG_GESCHW_SOL'
||'L:VERG_GESCHW_UEBER_GRZ:VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL:VERG_CODE_BUSSGELD:VERG_DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_BAS_KAT_KATEGORIE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STD_INP_STATUS:DATUM_V'
||'ERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_INT_INTERNET_APP:FK_CONTR_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_KON_GESCHAEFTSPARTNER:DU'
||'MMY:STORNIERT:FK_ADR_ADRESSE_SCHNELL:FK_LEX_RELATION_SRC:FK_MAIN_KEY_SRC:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:FK_BAS_KAL_ARBEITSTAG:DATUM_STATUS_VERW:DATUM_STATUS_KAT:VERG_DATUM_RECHTSKRAFT:VERG_DATUM_TILGUNG:VERG_NUMMER_FLENS:VERG_AKTENZ'
||'EICHEN:VERG_TATBESTANDSNUMMER:FK_VER_VERTRAG:FK_KTO_BUCHUNG:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:BELEGNUMMER:FK_ADR_LAND:FK_ADR_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_BAS_STEU_STEUER_SATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_BAS_MON_W'
||'AEHRUNG:STEUERNUMMER:FK_BAS_MON_UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGRUENDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:COMM_PARKTICKET:COMM_VERGEHEN:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17111721340844778)
,p_report_id=>wwv_flow_api.id(2694222273159161)
,p_name=>'not_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_INP_BELEGE_ALL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_INP_BELEGE_ALL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15289820607623200)
,p_plug_name=>'LEX_NOT_OK'
,p_parent_plug_id=>wwv_flow_api.id(14186852694489803)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>110
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_LEX_LONG'
,p_query_where=>'jahr = :P151_jahr and datum_ok is null'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'LEX_NOT_OK'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15290211702623204)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19905630707821839
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290372564623205)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290395293623206)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290573676623207)
,p_db_column_name=>'BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290639659623208)
,p_db_column_name=>'BENUTZER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290694503623209)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290876043623210)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15290942831623211)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15291024924623212)
,p_db_column_name=>'NR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15291129791623213)
,p_db_column_name=>'HABENDM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15291229718623214)
,p_db_column_name=>'HABENEUR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15291358691623215)
,p_db_column_name=>'HABEN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343115466904866)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343220168904867)
,p_db_column_name=>'RELATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343327834904868)
,p_db_column_name=>'SOLLDM'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343455261904869)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343543038904870)
,p_db_column_name=>'SOLL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343669840904871)
,p_db_column_name=>'SPERRE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343704825904872)
,p_db_column_name=>'STAPEL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343819717904873)
,p_db_column_name=>'STATUS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15343903797904874)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344066087904875)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344109460904876)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344273327904877)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344358941904878)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344384885904879)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344559963904880)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344593685904881)
,p_db_column_name=>'UST_DM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344735102904882)
,p_db_column_name=>'UST_EUR'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344849501904883)
,p_db_column_name=>'UST'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344973391904884)
,p_db_column_name=>'UST_KTO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15344990913904885)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345088971904886)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345191163904887)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345373036904888)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345447152904889)
,p_db_column_name=>'PERIODE'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345549573904890)
,p_db_column_name=>'BELEGNR'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345599703904891)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345689491904892)
,p_db_column_name=>'BETRAG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345868079904893)
,p_db_column_name=>'WHRG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15345911671904894)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346053028904895)
,p_db_column_name=>'HABENKTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346152456904896)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346196945904897)
,p_db_column_name=>'NOTIZ'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346299266904898)
,p_db_column_name=>'KST'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346434564904899)
,p_db_column_name=>'KTR'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346528129904900)
,p_db_column_name=>'JAHR'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346680137904901)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346698831904902)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346816494904903)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15346898521904904)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347050728904905)
,p_db_column_name=>'FK_STD_OK_STATE'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Std Ok State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347142126904906)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347259650904907)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347341619904908)
,p_db_column_name=>'SEL_LEX_RELATION'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Sel Lex Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347451448904909)
,p_db_column_name=>'FK_LEX_RELATION_MAIN'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fk Lex Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347560998904910)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347585049904911)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347756931904912)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347867000904913)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347898197904914)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15347990151904915)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348148717904866)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348259930904867)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348332024904868)
,p_db_column_name=>'FK_STEU_STEUER_VORANMLDG'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Steu Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348478902904869)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348566069904870)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348616297904871)
,p_db_column_name=>'FK_LEX_BELEGDAT'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Fk Lex Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348729282904872)
,p_db_column_name=>'FK_LEX_JOURDAT'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Fk Lex Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348880500904873)
,p_db_column_name=>'OK_ALL'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Ok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348913475904874)
,p_db_column_name=>'NOK_ALL'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Nok All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15348986653904875)
,p_db_column_name=>'BEMERKUNG_ALL'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Bemerkung All'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349092352904876)
,p_db_column_name=>'DATUM_ALL_OK'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Datum All Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349184206904877)
,p_db_column_name=>'DATUM_ALL_NOK'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Datum All Nok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349322144904878)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15388061412918014)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'200035'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGDAT:ABSCHLUSS:BELEG:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:RELATION:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H'
||unistr(':UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_STD_OK_STATE:FK_LEX_LONG_ZUS_RELATION:\00DCBERGABEDATUM_AN_STB:SEL_LEX_RELATION:FK_LEX')
||unistr('_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_CONTR_DUPL_STATUS:FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMLDG:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:FK_LEX_BELEGDAT:FK_LEX_JOURDAT:OK_ALL:NOK_A')
||'LL:BEMERKUNG_ALL:DATUM_ALL_OK:DATUM_ALL_NOK:STEUERSCHLUESSEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15289940198623201)
,p_plug_name=>'kto_buch'
,p_parent_plug_id=>wwv_flow_api.id(14186852694489803)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>120
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'V_KTO_KONTEN_ZUS'
,p_query_where=>'bucht_jahr = :P151_Jahr and datum_lex_buchung_ok  is null'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'kto_buch'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15349401981904879)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19964820987103514
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349542159904880)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349640604904881)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349707652904882)
,p_db_column_name=>'Buchungstag'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349825085904883)
,p_db_column_name=>'Betrag'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15349925821904884)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350005627904885)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350163217904886)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350202217904887)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350351661904888)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350453080904889)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350491836904890)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350608558904891)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350691824904892)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350815065904893)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15350921394904894)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351046785904895)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351173448904896)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351190373904897)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351283795904898)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351440778904899)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351579367904900)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351610579904901)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351735944904902)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351823068904903)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15351931348904904)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352074611904905)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352117761904906)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352235983904907)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352374094904908)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352455989904909)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352548341904910)
,p_db_column_name=>'IBAN'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352600656904911)
,p_db_column_name=>'BANK'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352748844904912)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15352859722904913)
,p_db_column_name=>'TBL'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15388582695918032)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'200041'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MAIN_KEY:ID:Buchungstag:Betrag:WAEHRUNG:FREMDWAEHRUNGSBETRAG:FREMDWAEHRUNG:BUCHUNGSTEXT:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT'
||'_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:KONTOTYP:FK_KTO_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BANKKONTO:KTO_BEZEICHNUNG:IBAN:BANK:DATUM_LEX_BUCHUNG_OK:TBL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(84702701958344068)
,p_plug_name=>'relation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select src, ok_nok,  cnt cnt, jahr',
'from (',
'select ''ll'' src, case when datum_ok is not null then 1 else 0 end ok_nok, count(*) cnt, jahr',
'from t_lex_long',
'group by case when datum_ok is not null then 1 else 0 end, jahr',
'union',
'select ''zus'', case when datum_lex_buchung_ok is not null then 1 else 0 end, count(*), bucht_jahr',
'from v_kto_konten_zus zus',
'  --   join t_rel_konto_auszug_gir ktogir on ktogir.fk_main_key = zus.fk_main_key',
'group by case when datum_lex_buchung_ok is not null then 1 else 0 end,  bucht_jahr',
'union',
'select ''inp'', case when datum_buchung_ok is not null then 1 else 0 end, count(*), ord.jahr',
'',
'from t_inp_belege_all inp',
'  left join t_abl_ordner_page ord_pg on inp.fk_abl_ordner_page = ord_pg.pk_abl_ordner_page',
'  left join t_abl_ordner ord on ord.pk_abl_ordner = ord_pg.fk_abl_ordner',
'  ',
'',
'group by case when datum_buchung_ok is not null then 1 else 0 end,  ord.jahr',
')',
'where jahr = :P151_jahr',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(84702736453344069)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:RP:P386_PK_REL_KTO_BEL_LEX,P386_PK_INP_BELEGE_ALL,P386_FK_MAIN_KEY,P386_RELATION,P386_PK_INP_BELEGE_ALL_1,P386_FK_MAIN_KEY_1,P386_RELATION_1:#PK_REL_LEX_KTO_BEL#,#FK_INP_BELEGE_ALL#,#FK_MAIN_KEY#,#FK_RELATION#,&P38'
||'6_PK_INP_BELEGE_ALL_1.,&P386_FK_MAIN_KEY_1.,&P386_RELATION_1.'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>89318155458542704
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2793920558670580)
,p_db_column_name=>'SRC'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2794332484670581)
,p_db_column_name=>'OK_NOK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ok Nok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2794730739670582)
,p_db_column_name=>'JAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2795095025670582)
,p_db_column_name=>'CNT'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(84857941595401653)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'74109'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SRC:OK_NOK:JAHR'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(84866707030499311)
,p_report_id=>wwv_flow_api.id(84857941595401653)
,p_pivot_columns=>'JAHR:SRC'
,p_row_columns=>'OK_NOK'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(2796252385670588)
,p_pivot_id=>wwv_flow_api.id(84866707030499311)
,p_display_seq=>1
,p_function_name=>'MAX'
,p_column_name=>'CNT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_sum=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1946694674588407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2271993787758112)
,p_button_name=>'Crreate_Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Crreate Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.::P252_PK_REL_LEX_KTO_BEL,P252_FK_INP_BELEGE_ALL:,&P151_PK_INP_BELEGE_ALL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8612409570483578)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8610647630483578)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8612742237483579)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8610647630483578)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8612664574483579)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8610647630483578)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8614123642483579)
,p_branch_action=>'f?p=&APP_ID.:152:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8612742237483579)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8613437635483579)
,p_branch_action=>'f?p=&APP_ID.:150:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8612664574483579)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2272143392758113)
,p_name=>'P151_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2271993787758112)
,p_item_default=>'2019'
,p_prompt=>'JAHR'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2019;2019,2018;2018,2017;2017'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2600202253074905)
,p_name=>'P151_PK_INP_BELEGE_ALL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2271993787758112)
,p_prompt=>'Pk Inp Belege All'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8612150068483578)
,p_name=>'P151_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8610747971483578)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
