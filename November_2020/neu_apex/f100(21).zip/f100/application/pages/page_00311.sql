prompt --application/pages/page_00311
begin
--   Manifest
--     PAGE: 00311
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>311
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9672619453814967)
,p_plug_name=>'Kontoauszug_Abstimmung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select Zus.Fk_Main_Key,',
'      Id,',
'       ',
'       "Buchungstag",',
'       round("Betrag",2)  "Betrag",',
unistr('       "W\00E4hrung",'),
unistr('       "Fremdw\00E4hrungsbetrag",'),
unistr('       "Fremdw\00E4hrung",'),
'       zus.Buchungstext,',
'       "FK_Kategorie",',
'       "FK_Verwendungszweck",',
'       "FK_Kontotyp",',
'       Fk_Buchungstag,',
'       Fk_Wertstellung,',
'       zus.Verwendungszweck,',
'       zus.Kategorie,',
'       Bucht_Tag,',
'       Bucht_Monat,',
'       Bucht_Jahr,',
'       Bucht_Datum,',
'       Wertt_Tag,',
'       Wertt_Monat,',
'       Wertt_Jahr,',
'       Wertt_Datum,',
'       "Kontotyp",',
'       Fk_Vorgang,',
'       Wiederholung,',
'       Naechste_Zahlung,',
'       Fk_Buchung_Steuer,',
'       zus.Fk_Konto,',
'       Kto_Bezeichnung,',
'       Iban,',
'       Bank       ,',
'       buch,',
'       buch_status,',
'       buch_storno,',
'       inp_bel_status,',
'       bel_status,',
'       pg',
'      ,    Ktoaus.Fk_Jahr || '' '' || Ktoaus.Fk_Monat || ''/'' || Ktoaus.Fk_Monat || '' '' || Ktoaus.std_name || '' '' ||  Anfangsdatum || '' '' || Enddatum || '' ('' || Anfangsbetrag ||  '' - '' || Endbetrag ||   '') '' || Nvl(Endbetrag - Anfangsbetrag,0)  Ktoaus',
'      ,   Fk_Konto_Auszug,',
'      ktobel.Betrag rel_betrag,',
'      sum_Betrag,',
'      sum_sollbetrag,',
'      sum_habenbetrag,',
'      sum_diff',
'      ,',
'      round(abs(  "Betrag")-abs(sum_Betrag),0) diff,',
'      fk_lex_konto,',
'      case when instr(buch,fk_lex_konto)>0 then 1 else 0 end fk_lex_konto_in,',
'      case when fk_main_key_bankkonto is not null then 1 else 0 end bar_auszahlung,',
'      fk_main_key_bankkonto,',
'      kas.fk_main_key kas_fk_main_key,',
'      kas.betrag kas_betrag,',
'      case when pk_rel_kont_buch_kont_buch is not null then 1 else 0 end ueberweisung,',
'     relkto.kontotyp',
'  From V_Konten_Zus Zus',
'  Left Join  (',
'                    select ',
'                            fk_main_key , ',
'                            listagg ( kontonummer || ''/'' || gegenkonto || '' ('' ||  ok || '')'' ||  case when rnr1=1 then  chr(10) || chr(10) || '':'' || Buchungsnummer || '' '' || buchungstext || '' '' || fk_relation end  ,chr(10)) within group (order by fk_'
||'main_key) buch,',
'                            listagg ( case when rnr1=1 then  Buchungsnummer  ||  '' ('' ||  ok || '')'' end ,chr(10)) within group (order by fk_main_key) buch_status,',
'                            listagg ( case when rnr1=1 then  Buchungsnummer  || '' ('' ||  buchungsstatus || '')'' end  ,chr(10)) within group (order by fk_main_key) buch_storno,',
'                            listagg ( case when rnr=1 then pk_inp_belege_all || '' '' || Inp_Bel_Status end,'','') within group  (order by fk_main_key) inp_bel_status,',
'                            listagg ( case when rnr=1 then  pk_inp_belege_all || '' '' || Bel_Status end,'','') within group  (order by fk_main_key) bel_status,',
'                            listagg ( case when rnr=1 then  pk_inp_belege_all || '' '' || Ordner_Page end,'','') within group  (order by fk_main_key) pg,',
'                            listagg ( case when rnr1 = 1 then fk_relation || '' '' || Betrag end , '','')   within group  (order by fk_main_key) Betrag,                          ',
'                            sum(case when rnr1 = 1 and status is null then Betrag else 0 end)    sum_Betrag,',
'                            sum(case when rnr1 = 1 and status is null then solleur else 0 end)    sum_sollBetrag,',
'                            sum(case when rnr1 = 1 and status is null then   habeneur else 0 end)    sum_habenBetrag,',
'                            sum(case when rnr1 = 1 and status is null then diff else 0 end) sum_diff',
'                    from (',
'                             select a.*,  ',
'                                    row_number() over (partition by fk_main_key order by fk_main_key, jahr, buchungsnummer desc, belegnummer desc) rnr,',
'                                    row_number() over (partition by fk_main_key, fk_relation order by fk_main_key, jahr, buchungsnummer desc, belegnummer desc) rnr1,',
'                                    row_number() over (partition by fk_main_key,  pk_inp_belege_all order by pk_inp_belege_all) rnr2',
'                                   ',
'                             from (',
'                                     Select   Kto.Buchungsnummer,  Kto.Buchungsstatus, Kto.Ok,Kto.Jahr , Kto.Buchungstext, kto.kontonummer, kto.gegenkonto, Std_Status.Std_Name Inp_Bel_Status, Std_Bel.Std_Name Bel_Status , pg.Ordner_Page, kto.belegnum'
||'mer, relbel.fk_main_key,',
'                                        bel.pk_inp_belege_all, relbel.fk_relation, ll.Betrag, ll.habeneur, ll.solleur, ll.status, case when status is null then case when to_number(kontonummer) = to_number(ll.sollkto) then  ll.betrag else -ll.betrag e'
||'nd end diff',
'                                     From Imp_Kontenblatt_2018  Kto',
'                                       Left Join T_Rel_Lex_Kto_Bel relBel On Instr(Kto.Jahr || ''/'' || Kto.Buchungsnummer|| ''/0'', relBel.Fk_Relation)>0',
'                                       Left Join T_Lex_Long Ll On relBel.Fk_Relation = Ll.Relation',
'                                       left join inp_belege_all bel on bel.pk_inp_belege_all = relbel.fk_inp_belege_all',
'                                       Left Join (Select * From T_Std Where Fk_Std_Group = 101) Std_Status On Std_Status.Std_Value = Bel.Fk_Status',
'                                       Left Join (Select * From T_Std Where Fk_Std_Group = 27) Std_Bel On Std_Bel.Std_Value = Bel.Fk_Real_Beleg_Exist',
'                                       Left Join V_Ordner_Ablage_Page Pg On Pg.Pk_Abl_Ordner_Page = Bel.Fk_Abl_Ordner_Page',
'                                     Where relbel.Fk_Main_Key Is Not Null',
'                                    /* Group By ',
'                                         Kto.Buchungsnummer,  Kto.Buchungsstatus, Kto.Ok,Kto.Jahr , Kto.Buchungstext, kto.kontonummer, kto.gegenkonto, relbel.fk_relation, ',
'                                         relbel.Fk_Main_Key, kto.belegnummer,bel.Pk_Inp_Belege_All, bel.Fk_Status, bel.Fk_Abl_Ordner_Page,bel.Fk_Real_Beleg_Exist , Std_Status.Std_Name , Std_Bel.Std_Name , pg.Ordner_Page, relbel.fk_relation, ll.Betrag',
'                                        , ll.habeneur, ll.solleur, ll.status',
'                                   */',
'                             ) a',
'                     ) where rnr <=20',
'                     group by fk_main_key',
'               ) Ktobel On Ktobel.Fk_Main_Key = Zus.Fk_Main_Key',
'   Left Join T_Rel_Konto_Auszug_Gir Gir On Gir.Fk_Main_Key = Zus.Fk_Main_Key',
'   Left Join (Select Fk_Jahr, Fk_Monat, Anfangsdatum, Enddatum, Anfangsbetrag, Endbetrag, Pk_Konto_Auszug, std_name From T_Konto_Auszug ktoaus left join (select * from  t_std where fk_std_group = 181) std on ktoaus.fk_konto_auszug_type = std.std_valu'
||'e ) Ktoaus On Ktoaus.Pk_Konto_Auszug = Gir.Fk_Konto_Auszug',
'   left join (select * from t_lex_bank_konto where valid = 1) kto on zus.fk_konto = kto.fk_bank_konto and trunc(zus."Buchungstag") between valid_from and valid_to',
'   left join kas_kasse kas on kas.fk_main_key_bankkonto = zus.fk_main_key',
'   left join  ( ',
'               select kto.* , zus1."Kontotyp" || ''/'' || zus1.fk_main_key || '' ('' || round(zus1."Betrag",2) || '')'' || chr(10) || zus2."Kontotyp" || ''/'' || zus2.fk_main_key || '' ('' || round(zus2."Betrag",2) || '')'' kontotyp',
'               from t_rel_kont_buch_kont_buch kto',
'                   left join v_konten_zus zus1 on kto.fk_konto_buch1 = zus1.fk_main_key',
'                   left join v_konten_zus zus2 on kto.fk_konto_buch2 = zus2.fk_main_key',
'               where fk_type = 1',
'      ) relkto on relkto.fk_konto_buch1 = zus.fk_main_key  or relkto.fk_konto_buch2 = zus.fk_main_key',
'where pk_konto_auszug = :P311_PK_KONTO_AUSZUG_SEL or :P311_PK_KONTO_AUSZUG_SEL is null',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9672753106814967)
,p_name=>'Kontoauszug_Abstimmung'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11113072382206507
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9673575871815000)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9673949560815000)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9674322052815000)
,p_db_column_name=>'Betrag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9674763279815002)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9675139856815002)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9675508718815002)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9675886189815002)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9676273037815003)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9676678181815003)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9677024258815003)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9677415144815005)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9677845645815005)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9678244296815005)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9678671022815006)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679016727815006)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679421317815006)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679789634815006)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9680202279815008)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9680644151815008)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9681048770815008)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9681410542815010)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9681865358815010)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9682181720815010)
,p_db_column_name=>'Kontotyp'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9682620871815011)
,p_db_column_name=>'FK_VORGANG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fk Vorgang'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9683038417815011)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9683409241815011)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9683847159815013)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9684254530815013)
,p_db_column_name=>'FK_KONTO'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Fk Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9684581159815013)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9685034816815014)
,p_db_column_name=>'IBAN'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9685413366815014)
,p_db_column_name=>'BANK'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9691552741820306)
,p_db_column_name=>'BUCH'
,p_display_order=>42
,p_column_identifier=>'AG'
,p_column_label=>'Buch'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9691603352820307)
,p_db_column_name=>'BUCH_STATUS'
,p_display_order=>52
,p_column_identifier=>'AH'
,p_column_label=>'Buch Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9691681473820308)
,p_db_column_name=>'BUCH_STORNO'
,p_display_order=>62
,p_column_identifier=>'AI'
,p_column_label=>'Buch Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9691837256820309)
,p_db_column_name=>'INP_BEL_STATUS'
,p_display_order=>72
,p_column_identifier=>'AJ'
,p_column_label=>'Inp Bel Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9691976764820310)
,p_db_column_name=>'BEL_STATUS'
,p_display_order=>82
,p_column_identifier=>'AK'
,p_column_label=>'Bel Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9922980838290161)
,p_db_column_name=>'PG'
,p_display_order=>92
,p_column_identifier=>'AL'
,p_column_label=>'Pg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923154918290162)
,p_db_column_name=>'KTOAUS'
,p_display_order=>102
,p_column_identifier=>'AM'
,p_column_label=>'Ktoaus'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923190888290163)
,p_db_column_name=>'FK_KONTO_AUSZUG'
,p_display_order=>112
,p_column_identifier=>'AN'
,p_column_label=>'Fk Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923485216290166)
,p_db_column_name=>'SUM_SOLLBETRAG'
,p_display_order=>142
,p_column_identifier=>'AQ'
,p_column_label=>'Sum Sollbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923611964290167)
,p_db_column_name=>'SUM_HABENBETRAG'
,p_display_order=>152
,p_column_identifier=>'AR'
,p_column_label=>'Sum Habenbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923750118290168)
,p_db_column_name=>'SUM_DIFF'
,p_display_order=>162
,p_column_identifier=>'AS'
,p_column_label=>'Sum Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9923887262290170)
,p_db_column_name=>'DIFF'
,p_display_order=>172
,p_column_identifier=>'AT'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8303499199210193)
,p_db_column_name=>'FK_LEX_KONTO'
,p_display_order=>182
,p_column_identifier=>'AU'
,p_column_label=>'Fk Lex Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8304018550210198)
,p_db_column_name=>'FK_LEX_KONTO_IN'
,p_display_order=>192
,p_column_identifier=>'AV'
,p_column_label=>'Fk Lex Konto In'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10347877646308571)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>202
,p_column_identifier=>'AW'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348614792308579)
,p_db_column_name=>'BAR_AUSZAHLUNG'
,p_display_order=>222
,p_column_identifier=>'AY'
,p_column_label=>'Bar Auszahlung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348708797308580)
,p_db_column_name=>'FK_MAIN_KEY_BANKKONTO'
,p_display_order=>232
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Main Key Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348793163308581)
,p_db_column_name=>'KAS_FK_MAIN_KEY'
,p_display_order=>242
,p_column_identifier=>'BA'
,p_column_label=>'Kas Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10348924904308582)
,p_db_column_name=>'KAS_BETRAG'
,p_display_order=>252
,p_column_identifier=>'BB'
,p_column_label=>'Kas Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10349116313308584)
,p_db_column_name=>'UEBERWEISUNG'
,p_display_order=>262
,p_column_identifier=>'BC'
,p_column_label=>'Ueberweisung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351554134308608)
,p_db_column_name=>'REL_BETRAG'
,p_display_order=>272
,p_column_identifier=>'BD'
,p_column_label=>'Rel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351610855308609)
,p_db_column_name=>'SUM_BETRAG'
,p_display_order=>282
,p_column_identifier=>'BE'
,p_column_label=>'Sum Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10570112007317605)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>292
,p_column_identifier=>'BF'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9694026781986085)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'111344'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>unistr('FK_KONTO_AUSZUG:KTOAUS:Kontotyp:ID:FK_MAIN_KEY:BUCHUNGSTEXT:Buchungstag:Betrag:DIFF:FK_LEX_KONTO_IN:REL_BETRAG:BUCH:W\00E4hrung:BAR_AUSZAHLUNG:KAS_FK_MAIN_KEY:KAS_BETRAG:UEBERWEISUNG:KONTOTYP:Fremdw\00E4hrungsbetrag:FK_Kategorie:FK_Verwendungszweck:FK_Kontot')
||'yp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:VERWENDUNGSZWECK:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:FK_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:IBAN:BANK:BUCH_STATUS:BUCH_STORNO:INP_BEL_STATUS:BEL_STATUS:PG:SUM_SOLLBETRAG:SUM_HABENBETRAG:FK_LEX_KONTO:FK_MAI'
||'N_KEY_BANKKONTO:FK_BUCHUNG_STEUER:'
,p_sort_column_1=>'Buchungstag'
,p_sort_direction_1=>'ASC'
,p_break_on=>'FK_KONTO_AUSZUG:KTOAUS:0:0:0:0'
,p_break_enabled_on=>'FK_KONTO_AUSZUG:KTOAUS:0:0:0:0'
,p_sum_columns_on_break=>'Betrag:SUM_DIFF:DIFF'
,p_count_columns_on_break=>'FK_MAIN_KEY:ID'
,p_count_distnt_col_on_break=>'FK_MAIN_KEY:ID'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21763190243674625)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>'Barauszahlung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BAR_AUSZAHLUNG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BAR_AUSZAHLUNG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#827D82'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21763646068674625)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>'realer Beleg nicht vorhanden'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BEL_STATUS'
,p_operator=>'contains'
,p_expr=>'Beleg: Realer Beleg nicht vorhanden'
,p_condition_sql=>' (case when (upper("BEL_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Beleg: Realer Beleg nicht vorhanden''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21764013721674625)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCH_STATUS'
,p_operator=>'contains'
,p_expr=>'(2)'
,p_condition_sql=>' (case when (upper("BUCH_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''(2)''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21765263545674627)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>unistr('zu Pr\00FCfen')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'INP_BEL_STATUS'
,p_operator=>'contains'
,p_expr=>unistr('zu pr\00FCfen')
,p_condition_sql=>' (case when (upper("INP_BEL_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>unistr('#APXWS_COL_NAME# #APXWS_OP_NAME# ''zu pr\00FCfen''  ')
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21765640966674627)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>unistr('\00DCberweisung_Kto')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("KONTOTYP" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B8B6B8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21766036208674628)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>unistr('\00FCberweisung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'UEBERWEISUNG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("UEBERWEISUNG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#BFBBBF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21764436077674627)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>'diff_0'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#A6A4A6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21764839656674627)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_name=>'fk_lex_false'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_KONTO_IN'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("FK_LEX_KONTO_IN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21760007655674620)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21760429041674622)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21760824957674622)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_MONAT'
,p_operator=>'='
,p_expr=>'5'
,p_condition_sql=>'"BUCHT_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21761204416674624)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>'"DIFF" != to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21761618350674624)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KONTO'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>'"FK_KONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21762062314674624)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KONTO_AUSZUG'
,p_operator=>'='
,p_expr=>'21'
,p_condition_sql=>'"FK_KONTO_AUSZUG" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21762474291674624)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_KONTO_IN'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_LEX_KONTO_IN" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21762818142674625)
,p_report_id=>wwv_flow_api.id(9694026781986085)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Kreditkarte'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Kreditkarte''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11245856342570731)
,p_application_user=>'ANNE'
,p_name=>unistr('Anne Richter Bankgeb\00FChren')
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>unistr('FK_KONTO_AUSZUG:KTOAUS:Kontotyp:ID:FK_MAIN_KEY:BUCHUNGSTEXT:Buchungstag:Betrag:DIFF:FK_LEX_KONTO_IN:REL_BETRAG:BUCH:W\00E4hrung:BAR_AUSZAHLUNG:KAS_FK_MAIN_KEY:KAS_BETRAG:UEBERWEISUNG:KONTOTYP:Fremdw\00E4hrungsbetrag:FK_Kategorie:FK_Verwendungszweck:FK_Kontot')
||'yp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:VERWENDUNGSZWECK:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:FK_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:IBAN:BANK:BUCH_STATUS:BUCH_STORNO:INP_BEL_STATUS:BEL_STATUS:PG:SUM_SOLLBETRAG:SUM_HABENBETRAG:FK_LEX_KONTO:FK_MAI'
||'N_KEY_BANKKONTO:FK_BUCHUNG_STEUER:'
,p_sort_column_1=>'Buchungstag'
,p_sort_direction_1=>'ASC'
,p_break_on=>'FK_KONTO_AUSZUG:KTOAUS:0:0:0:0'
,p_break_enabled_on=>'FK_KONTO_AUSZUG:KTOAUS:0:0:0:0'
,p_sum_columns_on_break=>'Betrag:SUM_DIFF:DIFF'
,p_count_columns_on_break=>'FK_MAIN_KEY:ID'
,p_count_distnt_col_on_break=>'FK_MAIN_KEY:ID'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246704524570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>'Barauszahlung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BAR_AUSZAHLUNG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BAR_AUSZAHLUNG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#827D82'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246781540570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>'realer Beleg nicht vorhanden'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BEL_STATUS'
,p_operator=>'contains'
,p_expr=>'Beleg: Realer Beleg nicht vorhanden'
,p_condition_sql=>' (case when (upper("BEL_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Beleg: Realer Beleg nicht vorhanden''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246915715570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCH_STATUS'
,p_operator=>'contains'
,p_expr=>'(2)'
,p_condition_sql=>' (case when (upper("BUCH_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''(2)''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11247269729570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>unistr('zu Pr\00FCfen')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'INP_BEL_STATUS'
,p_operator=>'contains'
,p_expr=>unistr('zu pr\00FCfen')
,p_condition_sql=>' (case when (upper("INP_BEL_STATUS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>unistr('#APXWS_COL_NAME# #APXWS_OP_NAME# ''zu pr\00FCfen''  ')
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11247299221570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>unistr('\00DCberweisung_Kto')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("KONTOTYP" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B8B6B8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11247408346570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>unistr('\00FCberweisung')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'UEBERWEISUNG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("UEBERWEISUNG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#BFBBBF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11247076217570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>'diff_0'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#A6A4A6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11247138663570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_name=>'fk_lex_false'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_KONTO_IN'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("FK_LEX_KONTO_IN" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>21
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11245960935570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246061287570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_MONAT'
,p_operator=>'='
,p_expr=>'5'
,p_condition_sql=>'"BUCHT_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246147212570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>'"DIFF" != to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246227864570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KONTO'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>'"FK_KONTO" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246303966570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_KONTO_AUSZUG'
,p_operator=>'='
,p_expr=>'21'
,p_condition_sql=>'"FK_KONTO_AUSZUG" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246397338570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_KONTO_IN'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_LEX_KONTO_IN" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246551835570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'in'
,p_expr=>unistr('Bank - Bankgeb\00FChren,Bank - Bankgeb\00FChren Ausland,Bargeld - Auszahlung')
,p_condition_sql=>'"KATEGORIE" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#, #APXWS_EXPR_VAL3#)'
,p_condition_display=>unistr('#APXWS_COL_NAME# #APXWS_OP_NAME# ''Bank - Bankgeb\00FChren, Bank - Bankgeb\00FChren Ausland, Bargeld - Auszahlung''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11246655965570733)
,p_report_id=>wwv_flow_api.id(11245856342570731)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Kreditkarte'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Kreditkarte''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10350701014308600)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22471172901483253)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>3
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_konto_auszug, ',
'listagg(case when jr = 1 then bucht_jahr || '' ('' || sb || '')'' end ,'''') within group (order by fk_jahr) vj,',
'listagg(case when jr = 2 then bucht_jahr || '' ('' || sb || '')''  end ,'''') within group (order by fk_jahr) aj, ',
'listagg(case when jr = 3 then bucht_jahr || '' ('' || sb || '')'' end ,'''') within group (order by fk_jahr) fj,',
'iban,',
'fk_monat,',
'Kontotyp,',
'fk_jahr,',
'case when pk_konto_auszug = :P311_PK_KONTO_AUSzUG_SEL then 1 else 0 end sel,',
'style_vj,',
'style_aj,',
'style_fj',
'from (',
'select round(sum("Betrag"),2) sb  , ',
'    bucht_jahr, ',
'    pk_konto_auszug, ',
'    fk_jahr, ',
'    case when fk_jahr = bucht_jahr +1 then 1 when fk_jahr = bucht_jahr then 2 when fk_jahr = bucht_jahr -1 then 3 else 0 end jr, ',
'    case when datum_ok_vorjahr is not null then ''background-color:lightgreen'' end style_vj,',
'    case when  datum_ok_aktuelles_jahr is not null then ''background-color:lightgreen'' end  style_aj, ',
'    case when datum_ok_folgejahr is not null then ''background-color:lightgreen'' end style_fj,',
'    fk_monat, ',
'    iban,',
'    "Kontotyp" Kontotyp',
'from (',
'select *',
'from t_konto_auszug kto',
'--where pk_konto_auszug = 381',
') ktoaus',
'left join t_rel_konto_auszug_gir gir on gir.fk_konto_auszug = ktoaus.pk_konto_auszug',
'left join v_konten_zus zus on zus.fk_main_key = gir.fk_main_key',
'--left join t_bankkonto kto on kto.pk_bankkonto = ktoaus.fk_konto',
'--left join ',
'group by bucht_jahr, pk_konto_auszug, fk_jahr,  fk_monat, iban, "Kontotyp", datum_ok_vorjahr, datum_ok_aktuelles_jahr, datum_ok_folgejahr',
')',
'group by pk_konto_auszug, iban,',
'fk_monat,',
'Kontotyp,',
'fk_jahr,',
'style_vj,',
'style_aj,',
'style_fj'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22471288071483253)
,p_name=>'ir_test'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP:P311_PK_KONTO_AUSZUG_SEL:#PK_KONTO_AUSZUG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>23911607346874793
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10517365677546924)
,p_db_column_name=>'PK_KONTO_AUSZUG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Konto Auszug'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10517758559546925)
,p_db_column_name=>'VJ'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Vj'
,p_column_html_expression=>'<span style="#STYLE_VJ#">#VJ#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10518127561546927)
,p_db_column_name=>'AJ'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Aj'
,p_column_html_expression=>'<span style="#STYLE_AJ#">#AJ#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10518544350546928)
,p_db_column_name=>'FJ'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fj'
,p_column_html_expression=>'<span style="#STYLE_FJ#">#FJ#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10518927396546930)
,p_db_column_name=>'IBAN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10519370939546931)
,p_db_column_name=>'FK_MONAT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10519768738546931)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351066039308603)
,p_db_column_name=>'FK_JAHR'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Fk Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351104876308604)
,p_db_column_name=>'SEL'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351279302308605)
,p_db_column_name=>'STYLE_VJ'
,p_display_order=>37
,p_column_identifier=>'J'
,p_column_label=>'Style Vj'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351379608308606)
,p_db_column_name=>'STYLE_AJ'
,p_display_order=>47
,p_column_identifier=>'K'
,p_column_label=>'Style Aj'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10351413685308607)
,p_db_column_name=>'STYLE_FJ'
,p_display_order=>57
,p_column_identifier=>'L'
,p_column_label=>'Style Fj'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10522789999566508)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'119632'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'FK_JAHR:KONTOTYP:PK_KONTO_AUSZUG:VJ:AJ:FJ:IBAN:FK_MONAT:'
,p_sort_column_1=>'FK_MONAT'
,p_sort_direction_1=>'ASC'
,p_break_on=>'FK_JAHR'
,p_break_enabled_on=>'FK_JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35513305863134999)
,p_report_id=>wwv_flow_api.id(10522789999566508)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35512097498134997)
,p_report_id=>wwv_flow_api.id(10522789999566508)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"FK_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35512579935134997)
,p_report_id=>wwv_flow_api.id(10522789999566508)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"KONTOTYP" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35512940963134999)
,p_report_id=>wwv_flow_api.id(10522789999566508)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP'
,p_operator=>'='
,p_expr=>'Kreditkarte'
,p_condition_sql=>'"KONTOTYP" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Kreditkarte''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10350934692308602)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10350701014308600)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Reset'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP,311:P311_PK_KONTO_AUSZUG_SEL:'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10350852763308601)
,p_name=>'P311_PK_KONTO_AUSZUG_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10350701014308600)
,p_prompt=>'Pk Konto Auszug Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
