prompt --application/pages/page_00346
begin
--   Manifest
--     PAGE: 00346
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>346
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(38304357888694899)
,p_plug_name=>'ir_test'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ll as  (',
'                select distinct  ll.*, std.std_name',
'                from   t_lex_long ll               ',
'                  left join (select * from t_std where fk_std_group = 261) std on std.std_value = ll.fk_lex_storno',
'                where sollkto = 1460 or habenkto = 1460',
'),',
'det as (',
'        select ',
'    ',
'           1 sort, ',
'           ll.jahr bas_jahr,',
'           lexlex.PK_REL_LEX_LEX,',
'           lexlex.FK_BELEGNR1,',
'           lexlex.FK_BELEGNR2,',
'           lexlex.CREATED_BY,',
'           lexlex.CREATED_AT,',
'           lexlex.MODIFIED_BY,',
'           lexlex.MODIFIED_AT,',
'           lexlex.BEMERKUNG,',
'           lexlex.datum_ok,',
'           ---',
'           ll1.relation ll1_relation,',
'',
'',
'           ll1.habenkto habenkto1,       ',
'           ll1.sollkto sollkto1,',
'           ll1.belegdat belegdat1,',
'           ll1.fk_lex_storno fk_lex_storno1,',
'',
'           ---',
'           zus1.fk_main_key fk_main_key11,',
'           zus1."Betrag" betrag1,',
'           zus1.buchungstext buchungstext1,',
'           zus1.kategorie kategorie1,',
'           zus1."FK_Kontotyp" fk_kontotyp1,',
'           zus1.fk_konto fk_konto1,',
'           zus1."Kontotyp" kontotyp1,',
'           zus1."Buchungstag" buchungstag1,',
'           zus1.Bucht_tag bucht_tag1,',
'           zus1.bucht_monat bucht_monat1,',
'           zus1.bucht_jahr bucht_jahr1,',
'    ',
'           std1.std_name std_name1',
'  from ll ',
'    join T_REL_LEX_LEX lexlex on ll.relation = lexlex.fk_relation1 ',
'    left join t_lex_long ll1 on lexlex.fk_relation1 = ll1.fk_relation_main',
'    left join t_rel_lex_kto_bel  ktobel1 on ktobel1.fk_relation = lexlex.fk_relation1',
'    left join v_konten_zus zus1 on zus1.fk_main_key = ktobel1.fk_main_key',
'    left join t_lex_long ll2 on lexlex.fk_relation2 = ll2.fk_relation_main',
'    left join t_rel_lex_kto_bel ktobel2 on ktobel2.fk_relation = lexlex.fk_relation2',
'    left join v_konten_zus zus2 on zus2.fk_main_key = ktobel2.fk_main_key',
'    left join (select * from t_std where fk_std_group = 261) std1 on std1.std_value = ll1.fk_lex_storno',
'  union',
'  select ',
'           2 sort,',
'           ll.jahr bas_jahr,',
'           lexlex.PK_REL_LEX_LEX,',
'           lexlex.FK_BELEGNR1,',
'           lexlex.FK_BELEGNR2,',
'           lexlex.CREATED_BY,',
'           lexlex.CREATED_AT,',
'           lexlex.MODIFIED_BY,',
'           lexlex.MODIFIED_AT,',
'           lexlex.BEMERKUNG,',
'           lexlex.datum_ok,',
'           ---',
'',
'           ll2.relation ll2_relation,',
'',
'',
'',
'',
'           ll2.habenkto habenkto2,',
'           ll2.sollkto sollkto2,',
'           ll2.belegdat,',
'           ll2.fk_lex_storno fk_lex_storno2,',
'           ---',
'',
'           ---',
'           zus2.fk_main_key fk_main_key12,',
'           zus2."Betrag" betrag2,',
'           zus2.buchungstext buchungstext2,',
'           zus2.kategorie kategorie2,',
'           zus2."FK_Kontotyp" fk_kontotyp2,',
'           zus2.fk_konto fk_konto2,',
'           zus2."Kontotyp" kontotyp2,',
'           zus2."Buchungstag",',
'           zus2.Bucht_tag,',
'           zus2.bucht_monat,',
'           zus2.bucht_jahr,',
'          ',
'           std2.std_name std_name2',
'          ',
'  from ll ',
'    join T_REL_LEX_LEX lexlex on  ll.relation = lexlex.fk_relation2',
'    ',
'    left join t_lex_long ll1 on lexlex.fk_relation1 = ll1.fk_relation_main',
'    left join t_rel_lex_kto_bel  ktobel1 on ktobel1.fk_relation = lexlex.fk_relation1',
'    left join v_konten_zus zus1 on zus1.fk_main_key = ktobel1.fk_main_key',
'    left join t_lex_long ll2 on lexlex.fk_relation2 = ll2.fk_relation_main',
'    left join t_rel_lex_kto_bel ktobel2 on ktobel2.fk_relation = lexlex.fk_relation2',
'    left join v_konten_zus zus2 on zus2.fk_main_key = ktobel2.fk_main_key',
'    left join (select * from t_std where fk_std_group = 261) std2 on std2.std_value = ll2.fk_lex_storno',
'  ',
' ) ',
' select  ll.habenkto, ll.sollkto, ll.relation, ll.belegdat, ll.betrag, ll.status, ll.std_name, det.*, apex_item.checkbox2(1, ll.relation) sel1, apex_item.checkbox2(2, ll.relation) sel2 ,  apex_item.checkbox2(3, det.pk_rel_lex_lex) sel_all',
' from ll',
'   left join det  on ll.relation =  det.ll1_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(38304473058694899)
,p_name=>'ir_test'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39744792334086439
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13290393742844552)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>10
,p_column_identifier=>'AE'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13290705287844560)
,p_db_column_name=>'FK_BELEGNR1'
,p_display_order=>20
,p_column_identifier=>'AF'
,p_column_label=>'Fk Belegnr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13291135197844561)
,p_db_column_name=>'FK_BELEGNR2'
,p_display_order=>30
,p_column_identifier=>'AG'
,p_column_label=>'Fk Belegnr2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13291493197844561)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>40
,p_column_identifier=>'AH'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13291947946844561)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>50
,p_column_identifier=>'AI'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13292362999844561)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>60
,p_column_identifier=>'AJ'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13292719106844563)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>70
,p_column_identifier=>'AK'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13293097456844563)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>80
,p_column_identifier=>'AL'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13293533650844563)
,p_db_column_name=>'LL1_RELATION'
,p_display_order=>90
,p_column_identifier=>'AM'
,p_column_label=>'Ll1 Relation'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP:P253_FK_RELATION:#RELATION#'
,p_column_linktext=>'#LL1_RELATION#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13294360240844564)
,p_db_column_name=>'HABENKTO1'
,p_display_order=>110
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13294739992844564)
,p_db_column_name=>'SOLLKTO1'
,p_display_order=>120
,p_column_identifier=>'AP'
,p_column_label=>'Sollkto1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13295925394844566)
,p_db_column_name=>'FK_MAIN_KEY11'
,p_display_order=>150
,p_column_identifier=>'AS'
,p_column_label=>'Fk Main Key11'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13296313906844566)
,p_db_column_name=>'BETRAG1'
,p_display_order=>160
,p_column_identifier=>'AT'
,p_column_label=>'Betrag1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13296769054844566)
,p_db_column_name=>'BUCHUNGSTEXT1'
,p_display_order=>170
,p_column_identifier=>'AU'
,p_column_label=>'Buchungstext1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13297120188844567)
,p_db_column_name=>'KATEGORIE1'
,p_display_order=>180
,p_column_identifier=>'AV'
,p_column_label=>'Kategorie1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13297556452844567)
,p_db_column_name=>'FK_KONTOTYP1'
,p_display_order=>190
,p_column_identifier=>'AW'
,p_column_label=>'Fk Kontotyp1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13297977311844567)
,p_db_column_name=>'FK_KONTO1'
,p_display_order=>200
,p_column_identifier=>'AX'
,p_column_label=>'Fk Konto1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13298282333844569)
,p_db_column_name=>'KONTOTYP1'
,p_display_order=>210
,p_column_identifier=>'AY'
,p_column_label=>'Kontotyp1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13253774735882566)
,p_db_column_name=>'SORT'
,p_display_order=>290
,p_column_identifier=>'BG'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13257710399882606)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>690
,p_column_identifier=>'CU'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13257803549882607)
,p_db_column_name=>'HABENKTO'
,p_display_order=>700
,p_column_identifier=>'CV'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13362947068959876)
,p_db_column_name=>'RELATION'
,p_display_order=>710
,p_column_identifier=>'CW'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP:P253_FK_RELATION:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13363140018959878)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>720
,p_column_identifier=>'CX'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13363630945959883)
,p_db_column_name=>'BETRAG'
,p_display_order=>730
,p_column_identifier=>'DC'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13363731074959884)
,p_db_column_name=>'BELEGDAT1'
,p_display_order=>740
,p_column_identifier=>'DD'
,p_column_label=>'Belegdat1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13363795494959885)
,p_db_column_name=>'BUCHUNGSTAG1'
,p_display_order=>750
,p_column_identifier=>'DE'
,p_column_label=>'Buchungstag1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13363946873959886)
,p_db_column_name=>'BUCHT_TAG1'
,p_display_order=>760
,p_column_identifier=>'DF'
,p_column_label=>'Bucht Tag1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364003242959887)
,p_db_column_name=>'BUCHT_MONAT1'
,p_display_order=>770
,p_column_identifier=>'DG'
,p_column_label=>'Bucht Monat1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364169740959888)
,p_db_column_name=>'BUCHT_JAHR1'
,p_display_order=>780
,p_column_identifier=>'DH'
,p_column_label=>'Bucht Jahr1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364202120959889)
,p_db_column_name=>'SEL1'
,p_display_order=>790
,p_column_identifier=>'DI'
,p_column_label=>'Sel1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364313778959890)
,p_db_column_name=>'SEL2'
,p_display_order=>800
,p_column_identifier=>'DJ'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364642074959893)
,p_db_column_name=>'STATUS'
,p_display_order=>810
,p_column_identifier=>'DK'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364682893959894)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>820
,p_column_identifier=>'DL'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13364781205959895)
,p_db_column_name=>'SEL_ALL'
,p_display_order=>830
,p_column_identifier=>'DM'
,p_column_label=>'Sel All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13556652710839672)
,p_db_column_name=>'FK_LEX_STORNO1'
,p_display_order=>840
,p_column_identifier=>'DN'
,p_column_label=>'Fk Lex Storno1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13556742939839673)
,p_db_column_name=>'STD_NAME'
,p_display_order=>850
,p_column_identifier=>'DO'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13556851957839674)
,p_db_column_name=>'STD_NAME1'
,p_display_order=>860
,p_column_identifier=>'DP'
,p_column_label=>'Std Name1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19093526232978582)
,p_db_column_name=>'BAS_JAHR'
,p_display_order=>870
,p_column_identifier=>'DQ'
,p_column_label=>'Bas Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26360876423760451)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'147418'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_REL_LEX_LEX:SEL_ALL:SEL1:SEL2:KATEGORIE1:KONTOTYP1:SOLLKTO:HABENKTO:BELEGDAT:BETRAG:RELATION:STATUS:STD_NAME:BUCHUNGSTEXT1:BEMERKUNG:BETRAG1:CREATED_AT:CREATED_BY:FK_BELEGNR1:FK_BELEGNR2:FK_KONTOTYP1:FK_KONTO1:FK_MAIN_KEY11:HABENKTO1:LL1_RELATION:'
||'MODIFIED_AT:MODIFIED_BY:SOLLKTO1:SORT:BELEGDAT1:BUCHUNGSTAG1:BUCHT_TAG1:BUCHT_MONAT1:BUCHT_JAHR1:DATUM_OK:FK_LEX_STORNO1::STD_NAME1:BAS_JAHR'
,p_sort_column_1=>'BELEGDAT'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'BETRAG'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PK_REL_LEX_LEX'
,p_break_enabled_on=>'PK_REL_LEX_LEX'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13581531530970966)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#4FA64F'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13581911313970966)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'habenkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'not in'
,p_expr=>'1460'
,p_condition_sql=>' (case when ("HABENKTO" not in (#APXWS_EXPR_VAL1#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1460  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13582347048970966)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'sel_rel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL1'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL1" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4E2FF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13582746011970967)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'sel_rel1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4E2FF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13583162180970967)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'sel_all'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL_ALL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL_ALL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#EBEBEB'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13583522782970967)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'sollkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'not in'
,p_expr=>'1460'
,p_condition_sql=>' (case when ("SOLLKTO" not in (#APXWS_EXPR_VAL1#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1460  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13583937893970967)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STATUS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(13584325126970969)
,p_report_id=>wwv_flow_api.id(26360876423760451)
,p_name=>'storno2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STD_NAME'
,p_operator=>'='
,p_expr=>'storniert'
,p_condition_sql=>' (case when ("STD_NAME" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''storniert''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13365345859959900)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Update'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13600480672968791)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8304174078210199)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'Lex_long'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Lex Long'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13364542236959892)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'New_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Relation'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13364971872959896)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'sel_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Set_ok'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13365266263959899)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(38304357888694899)
,p_button_name=>'sel_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Set_nok'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13451502427356792)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New Relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      for j in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(j) is not null then',
'    ',
'      insert into t_rel_lex_lex (fk_relation1, fk_relation2, created_at) values (apex_application.g_f01(i), apex_application.g_f02(j), sysdate);',
'       commit;',
'       ',
'           end if;',
'    end loop;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13364542236959892)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13365062321959897)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    ',
'    ',
'      update t_rel_lex_lex set datum_ok = sysdate where pk_rel_lex_lex = apex_application.g_f03(i);',
'       commit;',
'  ',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13364971872959896)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13365131717959898)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    ',
'    ',
'      update t_rel_lex_lex set datum_ok = null where pk_rel_lex_lex = apex_application.g_f03(i);',
'       commit;',
'  ',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13365266263959899)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13365423784959901)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13365345859959900)
);
wwv_flow_api.component_end;
end;
/
