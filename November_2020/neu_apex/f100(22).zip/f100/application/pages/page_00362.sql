prompt --application/pages/page_00362
begin
--   Manifest
--     PAGE: 00362
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>362
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14914199112516649)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select td.PK_STEUER_JAHR_TODO,',
'       td.FK_JAHR,',
'       td.TODO  todo_descr,',
'       td.FK_TODO_GRP,',
'       td.DATUM_OK,',
'       std3.std_name status,',
'       tdgrp.*',
'  from T_STEUER_JAHR_TODO td',
'   left join (select PK_STEUER_JAHR_TODO_GRP,',
'       TODO,',
'       ',
'       CREATION_DATE, ',
'       std.std_name thema_dauerhaft,',
'       std1.std_name thema_monatlich,',
unistr('       std2.std_name thema_j\00E4hrlich,'),
'       nvl(nvl(std.std_name, std1.std_name), std2.std_name) thema,',
'       nvl(nvl(std.sort, std1.sort), std2.sort) sort,',
'       steuerberater_involviert,',
unistr('       steuerberater_empf\00E4nger,'),
'       steuerberater_sender,',
'       finanzamt_involviert,',
unistr('       finanzamt_empf\00E4nger,'),
'       finanzamt_sender',
'              ',
'  from T_STEUER_JAHR_TODO_GRP tdgrp',
'    left join (select * from t_std where fk_std_group = 301) std on tdgrp.fk_thema_dauerhaft = std.std_value',
'      left join (select * from t_std where fk_std_group = 301) std1 on tdgrp.fk_thema_monatlich = std1.std_value',
unistr('        left join (select * from t_std where fk_std_group = 301) std2 on tdgrp.fk_thema_j\00E4hrlich = std2.std_value) tdgrp on tdgrp.pk_steuer_jahr_todo_grp = td.fk_todo_grp'),
'          left join (select * from t_std where fk_std_group = 321) std3 on td.fk_status = std3.std_value'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14914669384516649)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:363:&SESSION.::&DEBUG.:RP:P363_PK_STEUER_JAHR_TODO:\#PK_STEUER_JAHR_TODO#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>16354988659908189
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14914763857516653)
,p_db_column_name=>'PK_STEUER_JAHR_TODO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Steuer Jahr Todo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14915041840516661)
,p_db_column_name=>'FK_JAHR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14915439130516661)
,p_db_column_name=>'TODO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14875473947356762)
,p_db_column_name=>'FK_TODO_GRP'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Fk Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878236294356790)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878399611356792)
,p_db_column_name=>'PK_STEUER_JAHR_TODO_GRP'
,p_display_order=>43
,p_column_identifier=>'G'
,p_column_label=>'Pk Steuer Jahr Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878516167356793)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>53
,p_column_identifier=>'H'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878635940356794)
,p_db_column_name=>'THEMA_DAUERHAFT'
,p_display_order=>63
,p_column_identifier=>'I'
,p_column_label=>'Thema Dauerhaft'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878780146356795)
,p_db_column_name=>'THEMA_MONATLICH'
,p_display_order=>73
,p_column_identifier=>'J'
,p_column_label=>'Thema Monatlich'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878782975356796)
,p_db_column_name=>unistr('THEMA_J\00C4HRLICH')
,p_display_order=>83
,p_column_identifier=>'K'
,p_column_label=>unistr('Thema J\00E4hrlich')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14878962866356797)
,p_db_column_name=>'THEMA'
,p_display_order=>93
,p_column_identifier=>'L'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879016915356798)
,p_db_column_name=>'SORT'
,p_display_order=>103
,p_column_identifier=>'M'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879149073356799)
,p_db_column_name=>'STEUERBERATER_INVOLVIERT'
,p_display_order=>113
,p_column_identifier=>'N'
,p_column_label=>'Steuerberater Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879271022356800)
,p_db_column_name=>unistr('STEUERBERATER_EMPF\00C4NGER')
,p_display_order=>123
,p_column_identifier=>'O'
,p_column_label=>unistr('Steuerberater Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879350813356801)
,p_db_column_name=>'STEUERBERATER_SENDER'
,p_display_order=>133
,p_column_identifier=>'P'
,p_column_label=>'Steuerberater Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879466273356802)
,p_db_column_name=>'FINANZAMT_INVOLVIERT'
,p_display_order=>143
,p_column_identifier=>'Q'
,p_column_label=>'Finanzamt Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879553531356803)
,p_db_column_name=>unistr('FINANZAMT_EMPF\00C4NGER')
,p_display_order=>153
,p_column_identifier=>'R'
,p_column_label=>unistr('Finanzamt Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879674760356804)
,p_db_column_name=>'FINANZAMT_SENDER'
,p_display_order=>163
,p_column_identifier=>'S'
,p_column_label=>'Finanzamt Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14879868272356806)
,p_db_column_name=>'TODO_DESCR'
,p_display_order=>173
,p_column_identifier=>'U'
,p_column_label=>'Todo Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14987457520531361)
,p_db_column_name=>'STATUS'
,p_display_order=>183
,p_column_identifier=>'V'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14919843527518611)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'163602'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_JAHR:THEMA:TODO:PK_STEUER_JAHR_TODO:DATUM_OK:PK_STEUER_JAHR_TODO_GRP:SORT:STEUERBERATER_INVOLVIERT:STEUERBERATER_EMPF\00C4NGER:STEUERBERATER_SENDER:FINANZAMT_INVOLVIERT:FINANZAMT_EMPF\00C4NGER:FINANZAMT_SENDER:TODO_DESCR:CREATION_DATE:FK_TODO_GRP:THEMA_DA')
||unistr('UERHAFT:THEMA_J\00C4HRLICH:THEMA_MONATLICH::STATUS')
,p_break_on=>'THEMA:FK_JAHR'
,p_break_enabled_on=>'THEMA:FK_JAHR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14994061710919220)
,p_report_id=>wwv_flow_api.id(14919843527518611)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14994478674919222)
,p_report_id=>wwv_flow_api.id(14919843527518611)
,p_name=>'in Bearbeitung'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'in Bearbeitung'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''in Bearbeitung''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14993638018919220)
,p_report_id=>wwv_flow_api.id(14919843527518611)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"FK_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14916587964516677)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14914199112516649)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:363:&SESSION.::&DEBUG.:363'
);
wwv_flow_api.component_end;
end;
/
