prompt --application/pages/page_00373
begin
--   Manifest
--     PAGE: 00373
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>373
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'inp_beleg_all_vergl'
,p_alias=>'INP_BELEG_ALL_VERGL'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'inp_beleg_all_vergl'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200921004013'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17300552212528027)
,p_plug_name=>'TRGT'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17381100044530993)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33887423820020397)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_rel_steu_steuer_verpfl_beleg_src',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(33887513396020398)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>35327832671411938
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18024925010728067)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18025086371728069)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18025308484728071)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396313024261205)
,p_db_column_name=>'PK_REL_STEU_STEUER_VERPFL_BELEG_SRC'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Pk Rel Steu Steuer Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396414117261206)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>90
,p_column_identifier=>'S'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396483558261207)
,p_db_column_name=>'FK_PROJ_STUNDENZETTEL'
,p_display_order=>100
,p_column_identifier=>'T'
,p_column_label=>'Fk Proj Stundenzettel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396639404261208)
,p_db_column_name=>'FK_STD_STEU_STATUS'
,p_display_order=>110
,p_column_identifier=>'U'
,p_column_label=>'Fk Std Steu Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(33906335158363590)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'194762'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_INP_BELEGE_ALL:COMM:CREATION_DATE:PK_REL_STEU_STEUER_VERPFL_BELEG_SRC:FK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_PROJ_STUNDENZETTEL:FK_STD_STEU_STATUS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37564889443953477)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_inp_belege_pos_all',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(37565044974953478)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39005364250345018
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37565331710953481)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37566760776953495)
,p_db_column_name=>'PK_INP_BELEGE_POS_ALL'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37566793029953496)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37567581870953504)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37567726924953505)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37567994229953508)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37568109393953509)
,p_db_column_name=>'VON'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37568220534953510)
,p_db_column_name=>'BIS'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37601464614343761)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37601649789343763)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37601710576343764)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37601902540343766)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37601989600343767)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602105248343768)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602267781343769)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602336806343770)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>290
,p_column_identifier=>'AA'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602562189343772)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>310
,p_column_identifier=>'AC'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602672734343773)
,p_db_column_name=>'BELEG'
,p_display_order=>320
,p_column_identifier=>'AD'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602711520343774)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>330
,p_column_identifier=>'AE'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37602837043343775)
,p_db_column_name=>'LITER'
,p_display_order=>340
,p_column_identifier=>'AF'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603060240343777)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>360
,p_column_identifier=>'AH'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603123036343778)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>370
,p_column_identifier=>'AI'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603275629343779)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>380
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603337757343780)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>390
,p_column_identifier=>'AK'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603599692343783)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>420
,p_column_identifier=>'AN'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603758632343784)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>430
,p_column_identifier=>'AO'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603806716343785)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AP'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37603903941343786)
,p_db_column_name=>'DATUM_OK_BUCH'
,p_display_order=>450
,p_column_identifier=>'AQ'
,p_column_label=>'Datum Ok Buch'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3299050708218013)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3299166725218014)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3299250015218015)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392401593261166)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392489018261167)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392597618261168)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392739455261169)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392840457261170)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3392974068261171)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393042609261172)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393125114261173)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393270246261174)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393296517261175)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393405468261176)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393487777261177)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393608339261178)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393766874261179)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393793439261180)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3393933863261181)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394024299261182)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394115464261183)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(37752695882225545)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'391931'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_INP_BELEGE_ALL:PK_INP_BELEGE_POS_ALL:FK_LEX_BUCHUNG:BELEGNUMMER:BEZEICHNUNG:BEL_DATUM:VON:BIS:NETTO_BETRAG:MWST_BETRAG:BRUTTO_BETRAG:STEUERNUMMER:UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER'
||':FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FRMDW_NETTO_BETRAG:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:DATUM_OK_BUCH:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDU'
||'NGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:COMM_BEGRUENDUNG:ZAPFSAEULE:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:FK_STD_CONTR_STATUS_KAT:FK_STD_CO'
||'NTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37565799569953486)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_inp_belege_pos_all',
'where fk_inp_belege_all = :P373_PK_INP_BELEGE_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(37565915174953487)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39006234450345027
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37566255607953490)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37604210173343789)
,p_db_column_name=>'PK_INP_BELEGE_POS_ALL'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Pk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37604282718343790)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>50
,p_column_identifier=>'I'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605081821343798)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>130
,p_column_identifier=>'Q'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605181355343799)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'R'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605517819343802)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>170
,p_column_identifier=>'U'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605680042343803)
,p_db_column_name=>'VON'
,p_display_order=>180
,p_column_identifier=>'V'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605701881343804)
,p_db_column_name=>'BIS'
,p_display_order=>190
,p_column_identifier=>'W'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37605803198343805)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'X'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37606029646343807)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>220
,p_column_identifier=>'Z'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37606171069343808)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>230
,p_column_identifier=>'AA'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37606371991343810)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>250
,p_column_identifier=>'AC'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37622960087346461)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>260
,p_column_identifier=>'AD'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623011132346462)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>270
,p_column_identifier=>'AE'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623136015346463)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>280
,p_column_identifier=>'AF'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623240454346464)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>290
,p_column_identifier=>'AG'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623427452346466)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>310
,p_column_identifier=>'AI'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623560393346467)
,p_db_column_name=>'BELEG'
,p_display_order=>320
,p_column_identifier=>'AJ'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623605101346468)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>330
,p_column_identifier=>'AK'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623688310346469)
,p_db_column_name=>'LITER'
,p_display_order=>340
,p_column_identifier=>'AL'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37623931764346471)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>360
,p_column_identifier=>'AN'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624045939346472)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>370
,p_column_identifier=>'AO'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624171610346473)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>380
,p_column_identifier=>'AP'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624267575346474)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>390
,p_column_identifier=>'AQ'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624503469346477)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>420
,p_column_identifier=>'AT'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624673570346478)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>430
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624731127346479)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>440
,p_column_identifier=>'AV'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37624852518346480)
,p_db_column_name=>'DATUM_OK_BUCH'
,p_display_order=>450
,p_column_identifier=>'AW'
,p_column_label=>'Datum Ok Buch'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394265174261184)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>460
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394318336261185)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>470
,p_column_identifier=>'BA'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394468978261186)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>480
,p_column_identifier=>'BB'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394517408261187)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>490
,p_column_identifier=>'BC'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394611544261188)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>500
,p_column_identifier=>'BD'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394779103261189)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>510
,p_column_identifier=>'BE'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394787057261190)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>520
,p_column_identifier=>'BF'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3394881536261191)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>530
,p_column_identifier=>'BG'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395053110261192)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>540
,p_column_identifier=>'BH'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395179133261193)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>550
,p_column_identifier=>'BI'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395223850261194)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>560
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395352473261195)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>570
,p_column_identifier=>'BK'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395441864261196)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>580
,p_column_identifier=>'BL'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395504738261197)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>590
,p_column_identifier=>'BM'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395643720261198)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>600
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395764023261199)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>610
,p_column_identifier=>'BO'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395797678261200)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>620
,p_column_identifier=>'BP'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395885187261201)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>630
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3395990739261202)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>640
,p_column_identifier=>'BR'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396163783261203)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>650
,p_column_identifier=>'BS'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3396197790261204)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>660
,p_column_identifier=>'BT'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(37753334236225558)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'391937'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_INP_BELEGE_ALL:PK_INP_BELEGE_POS_ALL:FK_LEX_BUCHUNG:BELEGNUMMER:BEZEICHNUNG:BEL_DATUM:VON:BIS:NETTO_BETRAG:MWST_BETRAG:BRUTTO_BETRAG:STEUERNUMMER:UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER'
||':FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FRMDW_NETTO_BETRAG:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:DATUM_OK_BUCH:FK_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDU'
||'NGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:COMM_BEGRUENDUNG:ZAPFSAEULE:FK_BAS_MON_FRMDW:FK_BAS_MON_FRMDW_MWST_SATZ:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:FK_STD_CONTR_STATUS_KAT:FK_STD_CO'
||'NTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37711815754079768)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from table(getCompinpbelegeall3 (:P373_SRC_PK_INP_BELEGE_ALL , :P373_TRGT_PK_INP_BELEGE_ALL))'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(37711950424079769)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,:P252_FK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>39152269699471309
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37712763511079777)
,p_db_column_name=>'SEL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38738994318712106)
,p_db_column_name=>'SUM1'
,p_display_order=>110
,p_column_identifier=>'CS'
,p_column_label=>'Sum1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38739155719712107)
,p_db_column_name=>'NR_ROW'
,p_display_order=>120
,p_column_identifier=>'CT'
,p_column_label=>'Nr Row'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38739268802712108)
,p_db_column_name=>'ERG'
,p_display_order=>130
,p_column_identifier=>'CU'
,p_column_label=>'Erg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38739358473712109)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>140
,p_column_identifier=>'CV'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38739384534712110)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>150
,p_column_identifier=>'CW'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854485103467661)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>160
,p_column_identifier=>'CX'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854642862467662)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>170
,p_column_identifier=>'CY'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854681939467663)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>180
,p_column_identifier=>'CZ'
,p_column_label=>'Fk Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854866663467664)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>190
,p_column_identifier=>'DA'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854930926467665)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>200
,p_column_identifier=>'DB'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38854998604467666)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>210
,p_column_identifier=>'DC'
,p_column_label=>'Fk Inventar'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855143836467667)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>220
,p_column_identifier=>'DD'
,p_column_label=>'Fk Projekt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855193481467668)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>230
,p_column_identifier=>'DE'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855306429467669)
,p_db_column_name=>'RNR'
,p_display_order=>240
,p_column_identifier=>'DF'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855414798467670)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>250
,p_column_identifier=>'DG'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855575775467671)
,p_db_column_name=>'FK_LAND'
,p_display_order=>260
,p_column_identifier=>'DH'
,p_column_label=>'Fk Land'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855668149467672)
,p_db_column_name=>'FK_CITY'
,p_display_order=>270
,p_column_identifier=>'DI'
,p_column_label=>'Fk City'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855773116467673)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>280
,p_column_identifier=>'DJ'
,p_column_label=>'Bel Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855874849467674)
,p_db_column_name=>'VON'
,p_display_order=>290
,p_column_identifier=>'DK'
,p_column_label=>'Von'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38855931418467675)
,p_db_column_name=>'BIS'
,p_display_order=>300
,p_column_identifier=>'DL'
,p_column_label=>'Bis'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856052033467676)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>310
,p_column_identifier=>'DM'
,p_column_label=>'Netto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856146325467677)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>320
,p_column_identifier=>'DN'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856241662467678)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>330
,p_column_identifier=>'DO'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856366700467679)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>340
,p_column_identifier=>'DP'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856422038467680)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>350
,p_column_identifier=>'DQ'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856557048467681)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>360
,p_column_identifier=>'DR'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856666127467682)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>370
,p_column_identifier=>'DS'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856723375467683)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>380
,p_column_identifier=>'DT'
,p_column_label=>'Comm Rest Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856808073467684)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>390
,p_column_identifier=>'DU'
,p_column_label=>'Comm Tel Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856916183467685)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>400
,p_column_identifier=>'DV'
,p_column_label=>'Comm Produkte'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38856992978467686)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>410
,p_column_identifier=>'DW'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857138805467687)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>420
,p_column_identifier=>'DX'
,p_column_label=>'Comm Sonstiges'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857270103467688)
,p_db_column_name=>'BELEG'
,p_display_order=>430
,p_column_identifier=>'DY'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857306518467689)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>440
,p_column_identifier=>'DZ'
,p_column_label=>'Zahlungsbeleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857465907467690)
,p_db_column_name=>'LITER'
,p_display_order=>450
,p_column_identifier=>'EA'
,p_column_label=>'Liter'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857504409467691)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>460
,p_column_identifier=>'EB'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857634871467692)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>470
,p_column_identifier=>'EC'
,p_column_label=>'Fk Location'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857767231467693)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>480
,p_column_identifier=>'ED'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857790930467694)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>490
,p_column_identifier=>'EE'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38857958438467695)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>500
,p_column_identifier=>'EF'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858010211467696)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>510
,p_column_identifier=>'EG'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858085569467697)
,p_db_column_name=>'FK_VON_ARBEITSTAG'
,p_display_order=>520
,p_column_identifier=>'EH'
,p_column_label=>'Fk Von Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858226680467698)
,p_db_column_name=>'FK_BIS_ARBEITSTAG'
,p_display_order=>530
,p_column_identifier=>'EI'
,p_column_label=>'Fk Bis Arbeitstag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858329764467699)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>540
,p_column_identifier=>'EJ'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858477556467700)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>550
,p_column_identifier=>'EK'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858520278467701)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>560
,p_column_identifier=>'EL'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858599274467702)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>570
,p_column_identifier=>'EM'
,p_column_label=>'Comm Parkticket'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858763815467703)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>580
,p_column_identifier=>'EN'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858830657467704)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>590
,p_column_identifier=>'EO'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858915214467705)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>600
,p_column_identifier=>'EP'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38858992794467706)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>610
,p_column_identifier=>'EQ'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38859146679467707)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>620
,p_column_identifier=>'ER'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38859184100467708)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>630
,p_column_identifier=>'ES'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38859318518467709)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>640
,p_column_identifier=>'ET'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38859461155467710)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>650
,p_column_identifier=>'EU'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38873857543605161)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>660
,p_column_identifier=>'EV'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38873972763605162)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>670
,p_column_identifier=>'EW'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874011715605163)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>680
,p_column_identifier=>'EX'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874099836605164)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>690
,p_column_identifier=>'EY'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874273889605165)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>700
,p_column_identifier=>'EZ'
,p_column_label=>'La Datum'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874333863605166)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>710
,p_column_identifier=>'FA'
,p_column_label=>'Fk La Konto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874461754605167)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>720
,p_column_identifier=>'FB'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874545371605168)
,p_db_column_name=>'FK_ZAHLSTATUS'
,p_display_order=>730
,p_column_identifier=>'FC'
,p_column_label=>'Fk Zahlstatus'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874596048605169)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>740
,p_column_identifier=>'FD'
,p_column_label=>'Comm Vergehen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874704502605170)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>750
,p_column_identifier=>'FE'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874832126605171)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>760
,p_column_identifier=>'FF'
,p_column_label=>'Cnt Punkte'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38874964730605172)
,p_db_column_name=>'FK_BELEG_ABLAGE'
,p_display_order=>770
,p_column_identifier=>'FG'
,p_column_label=>'Fk Beleg Ablage'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875022504605173)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>780
,p_column_identifier=>'FH'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875124526605174)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>790
,p_column_identifier=>'FI'
,p_column_label=>'Cnt Punkte Geschaetzt'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875261531605175)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>800
,p_column_identifier=>'FJ'
,p_column_label=>'Punkte Von'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875349933605176)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>810
,p_column_identifier=>'FK'
,p_column_label=>'Punkte Bis'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875464807605177)
,p_db_column_name=>'FK_LOCATION_VERG'
,p_display_order=>820
,p_column_identifier=>'FL'
,p_column_label=>'Fk Location Verg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875494179605178)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>830
,p_column_identifier=>'FM'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875598608605179)
,p_db_column_name=>'GESCHW_IST'
,p_display_order=>840
,p_column_identifier=>'FN'
,p_column_label=>'Geschw Ist'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875727605605180)
,p_db_column_name=>'GESCHW_SOLL'
,p_display_order=>850
,p_column_identifier=>'FO'
,p_column_label=>'Geschw Soll'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875823538605181)
,p_db_column_name=>'GESCHW_UEBER_GRZ'
,p_display_order=>860
,p_column_identifier=>'FP'
,p_column_label=>'Geschw Ueber Grz'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38875902257605182)
,p_db_column_name=>'GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>870
,p_column_identifier=>'FQ'
,p_column_label=>'Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876067993605183)
,p_db_column_name=>'CODE_BUSSGELD'
,p_display_order=>880
,p_column_identifier=>'FR'
,p_column_label=>'Code Bussgeld'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876170422605184)
,p_db_column_name=>'DESCR_BUSSGELD'
,p_display_order=>890
,p_column_identifier=>'FS'
,p_column_label=>'Descr Bussgeld'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876187147605185)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>900
,p_column_identifier=>'FT'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876341678605186)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>910
,p_column_identifier=>'FU'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876463024605187)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>920
,p_column_identifier=>'FV'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876539143605188)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>930
,p_column_identifier=>'FW'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876581096605189)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>940
,p_column_identifier=>'FX'
,p_column_label=>'Fk Calc State'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876714258605190)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>950
,p_column_identifier=>'FY'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876785453605191)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>960
,p_column_identifier=>'FZ'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38876976096605192)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>970
,p_column_identifier=>'GA'
,p_column_label=>'Fk Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877009340605193)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>980
,p_column_identifier=>'GB'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877163641605194)
,p_db_column_name=>'CREATE_AT'
,p_display_order=>990
,p_column_identifier=>'GC'
,p_column_label=>'Create At'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877236660605195)
,p_db_column_name=>'CREATE_BY'
,p_display_order=>1000
,p_column_identifier=>'GD'
,p_column_label=>'Create By'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877360100605196)
,p_db_column_name=>'MODIFY_AT'
,p_display_order=>1010
,p_column_identifier=>'GE'
,p_column_label=>'Modify At'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877399423605197)
,p_db_column_name=>'MODIFY_BY'
,p_display_order=>1020
,p_column_identifier=>'GF'
,p_column_label=>'Modify By'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877487546605198)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>1030
,p_column_identifier=>'GG'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877613789605199)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>1040
,p_column_identifier=>'GH'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877750118605200)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>1050
,p_column_identifier=>'GI'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877803977605201)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>1060
,p_column_identifier=>'GJ'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38877938297605202)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>1070
,p_column_identifier=>'GK'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878070681605203)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>1080
,p_column_identifier=>'GL'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878114077605204)
,p_db_column_name=>'FK_INTERNET_APP'
,p_display_order=>1090
,p_column_identifier=>'GM'
,p_column_label=>'Fk Internet App'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878243220605205)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>1100
,p_column_identifier=>'GN'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878291606605206)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>1110
,p_column_identifier=>'GO'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878469807605207)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>1120
,p_column_identifier=>'GP'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878571785605208)
,p_db_column_name=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_display_order=>1130
,p_column_identifier=>'GQ'
,p_column_label=>unistr('Fk Gesch\00E4ftspartner')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878633007605209)
,p_db_column_name=>'DUMMY'
,p_display_order=>1140
,p_column_identifier=>'GR'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878736191605210)
,p_db_column_name=>'STORNIERT'
,p_display_order=>1150
,p_column_identifier=>'GS'
,p_column_label=>'Storniert'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878814208605161)
,p_db_column_name=>'FK_ADRESSE_SCHNELL'
,p_display_order=>1160
,p_column_identifier=>'GT'
,p_column_label=>'Fk Adresse Schnell'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38878925828605162)
,p_db_column_name=>'SEL_PK_INP_BELEGE_ALL'
,p_display_order=>1170
,p_column_identifier=>'GU'
,p_column_label=>'Sel Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5548394010927605)
,p_db_column_name=>'FK_LEX_RELATION_SRC'
,p_display_order=>1180
,p_column_identifier=>'GV'
,p_column_label=>'Fk Lex Relation Src'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5549317679927614)
,p_db_column_name=>'VERG_AKTENZEICHEN'
,p_display_order=>1270
,p_column_identifier=>'HE'
,p_column_label=>'Verg Aktenzeichen'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185185373489787)
,p_db_column_name=>'FK_MAIN_KEY_SRC'
,p_display_order=>1280
,p_column_identifier=>'HH'
,p_column_label=>'Fk Main Key Src'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185334007489788)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>1290
,p_column_identifier=>'HI'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185398548489789)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>1300
,p_column_identifier=>'HJ'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185517676489790)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>1310
,p_column_identifier=>'HK'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185666184489791)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>1320
,p_column_identifier=>'HL'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185759903489792)
,p_db_column_name=>'VERG_DATUM_RECHTSKRAFT'
,p_display_order=>1330
,p_column_identifier=>'HM'
,p_column_label=>'Verg Datum Rechtskraft'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185852510489793)
,p_db_column_name=>'VERG_DATUM_TILGUNG'
,p_display_order=>1340
,p_column_identifier=>'HN'
,p_column_label=>'Verg Datum Tilgung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14185910169489794)
,p_db_column_name=>'VERG_NUMMER_FLENS'
,p_display_order=>1350
,p_column_identifier=>'HO'
,p_column_label=>'Verg Nummer Flens'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14186002450489795)
,p_db_column_name=>'VERG_TATBESTANDSNUMMER'
,p_display_order=>1360
,p_column_identifier=>'HP'
,p_column_label=>'Verg Tatbestandsnummer'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14186110402489796)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>1370
,p_column_identifier=>'HQ'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(38149971457865242)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'395903'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('SUM1:SEL:NR_ROW:ERG:FK_PROJEKTNUMMER:RNR:BEZEICHNUNG:FK_LAND:FK_CITY:BEL_DATUM:VON:BIS:NETTO_BETRAG:FK_STEUERSATZ:MWST_BETRAG:BRUTTO_BETRAG:FK_WAEHRUNG:STEUERNUMMER:FK_UMRECHNUNGSKURS:COMM_REST_COMM_TEL_COMM_PRODUKTE:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BE')
||unistr('LEG:ZAHLUNGSBELEG:LITER:ZAPFS\00C4ULE:FK_LOCATION:PERS\00D6NLICH_VOR_ORT:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UHRZEIT:FK_VON_ARBEITSTAG:FK_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_FRMDW:FK_FRMDW_MWST')
||'_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_ZAHLSTATUS:COMM_VERGEHEN:VERG_BEHOERDE:CNT_'
||'PUNKTE:FK_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BIS:FK_LOCATION_VERG:FK_IMP_BA_BEL_OLD:GESCHW_IST:GESCHW_SOLL:GESCHW_UEBER_GRZ:GESCHW_UEBER_GRZ_ABZGL_MESSTOL:CODE_BUSSGELD:DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUM'
||'MER:FK_REAL_BELEG_EXIST:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FK_STATUS:DATUM_VERGEHEN:CREATE_AT:CREATE_BY:MODIFY_AT:MODIFY_BY:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK:FK_I'
||unistr('NTERNET_APP:FK_DUPL_STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_GESCH\00C4FTSPARTNER:DUMMY:STORNIERT:FK_ADRESSE_SCHNELL:SEL_PK_INP_BELEGE_ALL:FK_LEX_RELATION_SRC:VERG_AKTENZEICHEN')
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(38853308104423920)
,p_report_id=>wwv_flow_api.id(38149971457865242)
,p_name=>'erg'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ERG'
,p_operator=>'='
,p_expr=>'erg'
,p_condition_sql=>' (case when ("ERG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''erg''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D4D4D4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(38853730365423922)
,p_report_id=>wwv_flow_api.id(38149971457865242)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SUM1'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("SUM1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(38854125550423922)
,p_report_id=>wwv_flow_api.id(38149971457865242)
,p_name=>'nok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SUM1'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("SUM1" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(38852921451423920)
,p_report_id=>wwv_flow_api.id(38149971457865242)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ERG'
,p_operator=>'='
,p_expr=>'erg'
,p_condition_sql=>'"ERG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''erg''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(55051948228420385)
,p_plug_name=>'Src'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17381876472531000)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(17381100044530993)
,p_button_name=>'Select'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Select'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19724744476495775)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(55051948228420385)
,p_button_name=>'Delete_old'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete Old'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17371239213528075)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(17300552212528027)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17369985768528072)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(17300552212528027)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17371638083528075)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(17300552212528027)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17370817902528074)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(17300552212528027)
,p_button_name=>'DELETE_new'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete New'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P373_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(17382286619531005)
,p_branch_name=>'Go To Page 373'
,p_branch_action=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP,:P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1,P373_SRC_PK_INP_BELEGE_ALL,P373_TRGT_PK_INP_BELEGE_ALL:&P373_TRGT_PK_INP_BELEGE_ALL.,&P373_SRC_PK_INP_BELEGE_ALL.,&P373_SRC_PK_INP_BELEGE_ALL.,&P373_TRGT_PK_INP_BELEGE_ALL.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(17381876472531000)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2650820413143288)
,p_name=>'P373_1_PK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>1 Pk</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2650976405143289)
,p_name=>'P373_3_ALTER_BELEG'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>3_ALTER_BELEG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2650992782143290)
,p_name=>'P373_4_ARBEITSTAG'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>4_ARBEITSTAG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651101660143291)
,p_name=>'P373_7_PREIS'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>7_PREIS</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651242694143292)
,p_name=>'P373_16_BUSSGELD'
,p_item_sequence=>1510
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>16_BUSSGELD</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651363325143293)
,p_name=>'P373_9_STEUER'
,p_item_sequence=>950
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>9_STEUER</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651424336143294)
,p_name=>'P373_10_ZAHLUNG'
,p_item_sequence=>980
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>10_ZAHLUNG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651535057143295)
,p_name=>'P373_18_LOCATION'
,p_item_sequence=>1890
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>18_LOCATION</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651592299143296)
,p_name=>'P373_12_LEXWARE'
,p_item_sequence=>1190
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>12_LEXWARE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651710504143297)
,p_name=>'P373_6_MENGE'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>6_MENGE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651796533143298)
,p_name=>'P373_21_CHECK'
,p_item_sequence=>2200
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>21 Check</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2651904335143299)
,p_name=>'P373_20_CHANGE'
,p_item_sequence=>2110
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>20_CHANGE</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652073818143300)
,p_name=>'P373_19_COMM'
,p_item_sequence=>1940
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>19_COMM</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652159927143301)
,p_name=>'P373_14_ABLAGE'
,p_item_sequence=>1390
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>14_ABLAGE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652274954143302)
,p_name=>'P373_8_CALC'
,p_item_sequence=>880
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>8_CALC</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652322386143303)
,p_name=>'P373_2_BELEG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>2_BELEG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652398130143304)
,p_name=>'P373_13_KATEGORIE'
,p_item_sequence=>1230
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>13_Kategorie</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652545965143305)
,p_name=>'P373_5_STATUS'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>5_Status</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652622096143306)
,p_name=>'P373_11_LASTSCHRIFT'
,p_item_sequence=>1120
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>11_LASTSCHRIFT</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652692010143307)
,p_name=>'P373_15_TANK'
,p_item_sequence=>1440
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>15_TANK</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652851567143308)
,p_name=>'P373_17_ADRESSE'
,p_item_sequence=>1830
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'<b>17_ADRESSE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2652937635143309)
,p_name=>'P373_1_PK_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>1 Pk</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2653051752143310)
,p_name=>'P373_2_BELEG_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>2_BELEG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2653180412143311)
,p_name=>'P373_3_ALTER_BELEG_1'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>3_ALTER_BELEG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2653254826143312)
,p_name=>'P373_4_ARBEITSTAG_1'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>4_ARBEITSTAG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179167886397698)
,p_name=>'P373_FK_BAS_KAT_KATEGORIE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1230
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Kat Kategorie 1'
,p_source=>'FK_BAS_KAT_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179267856397699)
,p_name=>'P373_FK_BAS_KAL_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Kal Arbeitstag 1'
,p_source=>'FK_BAS_KAL_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179301915397700)
,p_name=>'P373_FK_KTO_BUCHUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1090
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kto Buchung 1'
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179469308397701)
,p_name=>'P373_FK_STD_KTO_ZAHLUNGSART_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Kto Zahlungsart 1'
,p_source=>'FK_STD_KTO_ZAHLUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179566034397702)
,p_name=>'P373_FK_STD_VERW_VERWENDUNGSZWECK_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1250
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Verw Verwendungszweck 1'
,p_source=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179672932397703)
,p_name=>'P373_FK_INV_INVENTAR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1350
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Inv Inventar 1'
,p_source=>'FK_INV_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179751920397704)
,p_name=>'P373_FK_PROJ_PROJEKT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1330
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Proj Projekt 1'
,p_source=>'FK_PROJ_PROJEKT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179842126397705)
,p_name=>'P373_FK_ADR_LAND_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1880
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Adr Land 1'
,p_source=>'FK_ADR_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3179927436397706)
,p_name=>'P373_FK_ADR_CITY_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1900
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Adr City 1'
,p_source=>'FK_ADR_CITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180062161397707)
,p_name=>'P373_FK_BAS_STEU_STEUER_SATZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Steu Steuer Satz 1'
,p_source=>'FK_BAS_STEU_STEUER_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180097148397708)
,p_name=>'P373_FK_BAS_MON_WAEHRUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Waehrung 1'
,p_source=>'FK_BAS_MON_WAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180275139397709)
,p_name=>'P373_FK_BAS_MON_UMRECHNUNGSKURS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>770
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Umrechnungskurs 1'
,p_source=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180353325397710)
,p_name=>'P373_COMM_BEGRUENDUNG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2110
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Begruendung 1'
,p_source=>'COMM_BEGRUENDUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180448944397711)
,p_name=>'P373_ZAPFSAEULE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1460
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Zapfsaeule 1'
,p_source=>'ZAPFSAEULE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180549048397712)
,p_name=>'P373_FK_LOC_LOCATION_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1950
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Loc Location 1'
,p_source=>'FK_LOC_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180591908397713)
,p_name=>'P373_PERSOENLICH_VOR_ORT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1970
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Persoenlich Vor Ort 1'
,p_source=>'PERSOENLICH_VOR_ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180743431397714)
,p_name=>'P373_FK_BAS_KAL_VON_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Kal Von Arbeitstag 1'
,p_source=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3180849759397715)
,p_name=>'P373_FK_BAS_KAL_BIS_ARBEITSTAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Kal Bis Arbeitstag 1'
,p_source=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3256606964202166)
,p_name=>'P373_FK_BAS_MON_FRMDW_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Frmdw 1'
,p_source=>'FK_BAS_MON_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3256747777202167)
,p_name=>'P373_FK_BAS_MON_FRMDW_MWST_SATZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>670
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Frmdw Mwst Satz 1'
,p_source=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3256812007202168)
,p_name=>'P373_FK_STD_INP_ZAHLUNGSSTATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1020
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Inp Zahlungsstatus 1'
,p_source=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3256968575202169)
,p_name=>'P373_VERG_CNT_PUNKTE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1770
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Cnt Punkte 1'
,p_source=>'VERG_CNT_PUNKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257036455202170)
,p_name=>'P373_FK_BEL_BELEG_ABLAGE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1410
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bel Beleg Ablage 1'
,p_source=>'FK_BEL_BELEG_ABLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257127619202171)
,p_name=>'P373_VERG_CNT_PUNKTE_GESCHAETZT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1790
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Cnt Punkte Geschaetzt 1'
,p_source=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257227071202172)
,p_name=>'P373_VERG_PUNKTE_VON_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1810
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Punkte Von 1'
,p_source=>'VERG_PUNKTE_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257342970202173)
,p_name=>'P373_VERG_PUNKTE_BIS_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1830
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Punkte Bis 1'
,p_source=>'VERG_PUNKTE_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257401785202174)
,p_name=>'P373_FK_LOC_LOCATION_VERG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1850
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Loc Location Verg 1'
,p_source=>'FK_LOC_LOCATION_VERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257490016202175)
,p_name=>'P373_VERG_GESCHW_IST_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1690
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Geschw Ist 1'
,p_source=>'VERG_GESCHW_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257625662202176)
,p_name=>'P373_VERG_GESCHW_SOLL_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1710
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Geschw Soll 1'
,p_source=>'VERG_GESCHW_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257751291202177)
,p_name=>'P373_VERG_GESCHW_UEBER_GRZ_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1750
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Geschw Ueber Grz 1'
,p_source=>'VERG_GESCHW_UEBER_GRZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257832606202178)
,p_name=>'P373_VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1730
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Geschw Ueber Grz Abzgl Messtol 1'
,p_source=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3257889597202179)
,p_name=>'P373_VERG_CODE_BUSSGELD_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1550
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Code Bussgeld 1'
,p_source=>'VERG_CODE_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258038438202180)
,p_name=>'P373_VERG_DESCR_BUSSGELD_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1570
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Descr Bussgeld 1'
,p_source=>'VERG_DESCR_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258131577202181)
,p_name=>'P373_FK_STD_INP_STATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Inp Status 1'
,p_source=>'FK_STD_INP_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258229729202182)
,p_name=>'P373_FK_INT_INTERNET_APP_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1290
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Int Internet App 1'
,p_source=>'FK_INT_INTERNET_APP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258360373202183)
,p_name=>'P373_FK_CONTR_DUPL_STATUS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2360
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Contr Dupl Status 1'
,p_source=>'FK_CONTR_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258426429202184)
,p_name=>'P373_FK_KON_GESCHAEFTSPARTNER_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1270
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kon Geschaeftspartner 1'
,p_source=>'FK_KON_GESCHAEFTSPARTNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258504993202185)
,p_name=>'P373_DUMMY_!'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Dummy !'
,p_source=>'DUMMY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258628764202186)
,p_name=>'P373_STORNIERT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Storniert 1'
,p_source=>'STORNIERT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258761822202187)
,p_name=>'P373_FK_ADR_ADRESSE_SCHNELL_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1920
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Adr Adresse Schnell 1'
,p_source=>'FK_ADR_ADRESSE_SCHNELL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258787669202188)
,p_name=>'P373_FK_LEX_RELATION_SRC_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1190
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Lex Relation Src 1'
,p_source=>'FK_LEX_RELATION_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3258912334202189)
,p_name=>'P373_FK_MAIN_KEY_SRC_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1060
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Main Key Src 1'
,p_source=>'FK_MAIN_KEY_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259046197202190)
,p_name=>'P373_FK_STD_CONTR_STATUS_KAT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2380
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Contr Status Kat 1'
,p_source=>'FK_STD_CONTR_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259104142202191)
,p_name=>'P373_FK_STD_CONTR_STATUS_VERW_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2390
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Contr Status Verw 1'
,p_source=>'FK_STD_CONTR_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259259746202192)
,p_name=>'P373_DATUM_STATUS_VERW_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Status Verw 1'
,p_source=>'DATUM_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259339023202193)
,p_name=>'P373_DATUM_STATUS_KAT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Status Kat 1'
,p_source=>'DATUM_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259399568202194)
,p_name=>'P373_VERG_DATUM_RECHTSKRAFT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1590
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Datum Rechtskraft 1'
,p_source=>'VERG_DATUM_RECHTSKRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259504803202195)
,p_name=>'P373_VERG_DATUM_TILGUNG_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1610
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Datum Tilgung 1'
,p_source=>'VERG_DATUM_TILGUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259656922202196)
,p_name=>'P373_VERG_NUMMER_FLENS_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1630
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Nummer Flens 1'
,p_source=>'VERG_NUMMER_FLENS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259766057202197)
,p_name=>'P373_VERG_AKTENZEICHEN_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1670
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Aktenzeichen 1'
,p_source=>'VERG_AKTENZEICHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259830569202198)
,p_name=>'P373_VERG_TATBESTANDSNUMMER_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1650
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Tatbestandsnummer 1'
,p_source=>'VERG_TATBESTANDSNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3259942471202199)
,p_name=>'P373_FK_VER_VERTRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1370
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Ver Vertrag 1'
,p_source=>'FK_VER_VERTRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260138043202201)
,p_name=>'P373_FK_BAS_KAL_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_source=>'FK_BAS_KAL_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260271301202202)
,p_name=>'P373_MODIFY_AT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2170
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260310465202203)
,p_name=>'P373_FK_STD_KTO_ZAHLUNGSART'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Kto Zahlungsart'
,p_source=>'FK_STD_KTO_ZAHLUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260433000202204)
,p_name=>'P373_FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1260
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Verw Verwendungszweck'
,p_source=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260575378202205)
,p_name=>'P373_FK_INV_INVENTAR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1360
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Inv Inventar'
,p_source=>'FK_INV_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260661953202206)
,p_name=>'P373_FK_PROJ_PROJEKT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1340
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Proj Projekt'
,p_source=>'FK_PROJ_PROJEKT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260748793202207)
,p_name=>'P373_FK_ADR_LAND'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1860
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Adr Land'
,p_source=>'FK_ADR_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260876828202208)
,p_name=>'P373_FK_ADR_CITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1840
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Adr City'
,p_source=>'FK_ADR_CITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3260884987202209)
,p_name=>'P373_FK_BAS_STEU_STEUER_SATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Steu Steuer Satz'
,p_source=>'FK_BAS_STEU_STEUER_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261011211202210)
,p_name=>'P373_FK_BAS_MON_WAEHRUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>740
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Mon Waehrung'
,p_source=>'FK_BAS_MON_WAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261132244202211)
,p_name=>'P373_FK_BAS_MON_UMRECHNUNGSKURS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Mon Umrechnungskurs'
,p_source=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261232503202212)
,p_name=>'P373_COMM_BEGRUENDUNG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2090
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Begruendung'
,p_source=>'COMM_BEGRUENDUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261377610202213)
,p_name=>'P373_ZAPFSAEULE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1470
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Zapfsaeule'
,p_source=>'ZAPFSAEULE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261470371202214)
,p_name=>'P373_FK_LOC_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1900
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Loc Location'
,p_source=>'FK_LOC_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3261524116202215)
,p_name=>'P373_PERSOENLICH_VOR_ORT1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1920
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Persoenlich Vor Ort1'
,p_source=>'PERSOENLICH_VOR_ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289345748208166)
,p_name=>'P373_FK_BAS_KAL_VON_ARBEITSTAG1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Kal Von Arbeitstag1'
,p_source=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289439141208167)
,p_name=>'P373_FK_BAS_KAL_BIS_ARBEITSTAG1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Kal Bis Arbeitstag1'
,p_source=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289509851208168)
,p_name=>'P373_FK_BAS_MON_FRMDW1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Mon Frmdw1'
,p_source=>'FK_BAS_MON_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289663944208169)
,p_name=>'P373_FK_BAS_MON_FRMDW_MWST_SATZ1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>680
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Mon Frmdw Mwst Satz1'
,p_source=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289714359208170)
,p_name=>'P373_FK_STD_INP_ZAHLUNGSSTATUS1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1030
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Inp Zahlungsstatus1'
,p_source=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289827693208171)
,p_name=>'P373_VERG_CNT_PUNKTE1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1730
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Cnt Punkte1'
,p_source=>'VERG_CNT_PUNKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3289946666208172)
,p_name=>'P373_FK_BEL_BELEG_ABLAGE1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1420
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bel Beleg Ablage1'
,p_source=>'FK_BEL_BELEG_ABLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290038930208173)
,p_name=>'P373_VERG_CNT_PUNKTE_GESCHAETZT1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1750
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Cnt Punkte Geschaetzt1'
,p_source=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290128405208174)
,p_name=>'P373_VERG_PUNKTE_VON1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1770
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Punkte Von1'
,p_source=>'VERG_PUNKTE_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290239092208175)
,p_name=>'P373_VERG_PUNKTE_BIS1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1790
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Punkte Bis1'
,p_source=>'VERG_PUNKTE_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290317963208176)
,p_name=>'P373_FK_LOC_LOCATION_VERG1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1810
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Loc Location Verg1'
,p_source=>'FK_LOC_LOCATION_VERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290480990208177)
,p_name=>'P373_VERG_GESCHW_IST1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1650
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Geschw Ist1'
,p_source=>'VERG_GESCHW_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290520224208178)
,p_name=>'P373_VERG_GESCHW_SOLL1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1670
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Geschw Soll1'
,p_source=>'VERG_GESCHW_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290659532208179)
,p_name=>'P373_VERG_GESCHW_UEBER_GRZ1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1710
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Geschw Ueber Grz1'
,p_source=>'VERG_GESCHW_UEBER_GRZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290712248208180)
,p_name=>'P373_VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1690
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Geschw Ueber Grz Abzgl Messtol1'
,p_source=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290866779208181)
,p_name=>'P373_VERG_CODE_BUSSGELD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1560
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Code Bussgeld1'
,p_source=>'VERG_CODE_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290973020208182)
,p_name=>'P373_VERG_DESCR_BUSSGELD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1580
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Descr Bussgeld1'
,p_source=>'VERG_DESCR_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3290998724208183)
,p_name=>'P373_FK_STD_INP_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Inp Status'
,p_source=>'FK_STD_INP_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291096832208184)
,p_name=>'P373_FK_INT_INTERNET_APP1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1300
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Int Internet App1'
,p_source=>'FK_INT_INTERNET_APP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291203379208185)
,p_name=>'P373_FK_CONTR_DUPL_STATUS1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2350
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Contr Dupl Status1'
,p_source=>'FK_CONTR_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291290507208186)
,p_name=>'P373_FK_KON_GESCHAEFTSPARTNER1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1280
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Kon Geschaeftspartner1'
,p_source=>'FK_KON_GESCHAEFTSPARTNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291415200208187)
,p_name=>'P373_DUMMY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Dummy'
,p_source=>'DUMMY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291527551208188)
,p_name=>'P373_STORNIERT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Storniert'
,p_source=>'STORNIERT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291617283208189)
,p_name=>'P373_FK_ADR_ADRESSE_SCHNELL1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1880
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Adr Adresse Schnell1'
,p_source=>'FK_ADR_ADRESSE_SCHNELL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291758627208190)
,p_name=>'P373_FK_LEX_RELATION_SRC1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1200
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Lex Relation Src1'
,p_source=>'FK_LEX_RELATION_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291876649208191)
,p_name=>'P373_FK_MAIN_KEY_SRC1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1070
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Main Key Src1'
,p_source=>'FK_MAIN_KEY_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3291943032208192)
,p_name=>'P373_FK_STD_CONTR_STATUS_KAT1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2390
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Contr Status Kat1'
,p_source=>'FK_STD_CONTR_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292040312208193)
,p_name=>'P373_FK_STD_CONTR_STATUS_VERW1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2400
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Std Contr Status Verw1'
,p_source=>'FK_STD_CONTR_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292087008208194)
,p_name=>'P373_DATUM_STATUS_VERW1'
,p_source_data_type=>'DATE'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Status Verw1'
,p_source=>'DATUM_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292266532208195)
,p_name=>'P373_DATUM_STATUS_KAT1'
,p_source_data_type=>'DATE'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Status Kat1'
,p_source=>'DATUM_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292347189208196)
,p_name=>'P373_VERG_DATUM_RECHTSKRAFT1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1600
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Datum Rechtskraft1'
,p_source=>'VERG_DATUM_RECHTSKRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292478739208197)
,p_name=>'P373_VERG_DATUM_TILGUNG1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1610
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Datum Tilgung1'
,p_source=>'VERG_DATUM_TILGUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292561222208198)
,p_name=>'P373_VERG_NUMMER_FLENS1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1620
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Nummer Flens1'
,p_source=>'VERG_NUMMER_FLENS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292603911208199)
,p_name=>'P373_VERG_AKTENZEICHEN1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1640
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Aktenzeichen1'
,p_source=>'VERG_AKTENZEICHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292706070208200)
,p_name=>'P373_VERG_TATBESTANDSNUMMER1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1630
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Tatbestandsnummer1'
,p_source=>'VERG_TATBESTANDSNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292880944208201)
,p_name=>'P373_FK_VER_VERTRAG1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1380
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Ver Vertrag1'
,p_source=>'FK_VER_VERTRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3292960990208202)
,p_name=>'P373_FK_BAS_KAT_KATEGORIE1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1240
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Bas Kat Kategorie1'
,p_source=>'FK_BAS_KAT_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293010624208203)
,p_name=>'P373_BELEGNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Belegnummer'
,p_source=>'BELEGNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>128
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293156714208204)
,p_name=>'P373_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293192192208205)
,p_name=>'P373_BEL_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Bel Datum'
,p_source=>'BEL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293309156208206)
,p_name=>'P373_VON'
,p_source_data_type=>'DATE'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Von'
,p_source=>'VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293451497208207)
,p_name=>'P373_BIS'
,p_source_data_type=>'DATE'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Bis'
,p_source=>'BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293547556208208)
,p_name=>'P373_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Netto Betrag'
,p_source=>'NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293651692208209)
,p_name=>'P373_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>560
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Mwst Betrag'
,p_source=>'MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293779212208210)
,p_name=>'P373_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>600
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Brutto Betrag'
,p_source=>'BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293861526208211)
,p_name=>'P373_STEUERNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>960
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Steuernummer'
,p_source=>'STEUERNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3293881689208212)
,p_name=>'P373_COMM_REST_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1950
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Rest Beleg'
,p_source=>'COMM_REST_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294040358208213)
,p_name=>'P373_COMM_TEL_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1970
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Tel Beleg'
,p_source=>'COMM_TEL_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294159907208214)
,p_name=>'P373_COMM_PRODUKTE'
,p_source_data_type=>'CLOB'
,p_item_sequence=>1990
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Produkte'
,p_source=>'COMM_PRODUKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294222562208215)
,p_name=>'P373_COMM_SONSTIGES'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2070
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Sonstiges'
,p_source=>'COMM_SONSTIGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294337982217966)
,p_name=>'P373_BELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Beleg'
,p_source=>'BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294448997217967)
,p_name=>'P373_ZAHLUNGSBELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>1050
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Zahlungsbeleg'
,p_source=>'ZAHLUNGSBELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294502936217968)
,p_name=>'P373_LITER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1490
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Liter'
,p_source=>'LITER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294628811217969)
,p_name=>'P373_BELEG_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Beleg Uhrzeit'
,p_source=>'BELEG_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294702394217970)
,p_name=>'P373_VON_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Von Uhrzeit'
,p_source=>'VON_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294825079217971)
,p_name=>'P373_BIS_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Bis Uhrzeit'
,p_source=>'BIS_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3294972426217972)
,p_name=>'P373_COMM_ADRESSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2010
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Adresse'
,p_source=>'COMM_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295013812217973)
,p_name=>'P373_TANKSTELLEN_NR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1450
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Tankstellen Nr'
,p_source=>'TANKSTELLEN_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295125137217974)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>620
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Brutto Betrag Incl Trinkg'
,p_source=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295280347217975)
,p_name=>'P373_COMM_PARKTICKET'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2050
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Parkticket'
,p_source=>'COMM_PARKTICKET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295366077217976)
,p_name=>'P373_FRMDW_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>640
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Frmdw Netto Betrag'
,p_source=>'FRMDW_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295388235217977)
,p_name=>'P373_FRMDW_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>660
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Frmdw Mwst Betrag'
,p_source=>'FRMDW_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295525392217978)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>700
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Frmdw Brutto Betrag'
,p_source=>'FRMDW_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295600875217979)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>720
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Frmdw Brutto Incl Trinkg'
,p_source=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295758556217980)
,p_name=>'P373_MWST_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>820
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Mwst Betrag Eur'
,p_source=>'MWST_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295788368217981)
,p_name=>'P373_BRUTTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>840
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Brutto Betrag Eur'
,p_source=>'BRUTTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3295908950217982)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>860
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Brutto Incl Trinkg Eur'
,p_source=>'BRUTTO_INCL_TRINKG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296038825217983)
,p_name=>'P373_NETTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>800
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Netto Betrag Eur'
,p_source=>'NETTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296137497217984)
,p_name=>'P373_PREIS_PRO_MENGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Preis Pro Menge'
,p_source=>'PREIS_PRO_MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296251391217985)
,p_name=>'P373_MENGENEINHEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Mengeneinheit'
,p_source=>'MENGENEINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296286190217986)
,p_name=>'P373_LA_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>1170
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'La Datum'
,p_source=>'LA_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296434184217987)
,p_name=>'P373_FK_LA_KONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1150
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk La Konto'
,p_source=>'FK_LA_KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296549369217988)
,p_name=>'P373_FK_LA_WDH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1130
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk La Wdh'
,p_source=>'FK_LA_WDH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296586753217989)
,p_name=>'P373_COMM_VERGEHEN'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2030
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Comm Vergehen'
,p_source=>'COMM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296726561217990)
,p_name=>'P373_VERG_BEHOERDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1520
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Verg Behoerde'
,p_source=>'VERG_BEHOERDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296815760217991)
,p_name=>'P373_FK_ABL_ORDNER_PAGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1400
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Abl Ordner Page'
,p_source=>'FK_ABL_ORDNER_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296937713217992)
,p_name=>'P373_FK_IMP_BA_BEL_OLD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Imp Ba Bel Old'
,p_source=>'FK_IMP_BA_BEL_OLD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3296993503217993)
,p_name=>'P373_GEZAHLT_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>990
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Gezahlt Am'
,p_source=>'GEZAHLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297116889217994)
,p_name=>'P373_WEBSEITE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1320
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Webseite'
,p_source=>'WEBSEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297241219217995)
,p_name=>'P373_KUNDENNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Kundennummer'
,p_source=>'KUNDENNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297285881217996)
,p_name=>'P373_FK_REAL_BELEG_EXIST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Real Beleg Exist'
,p_source=>'FK_REAL_BELEG_EXIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297450644217997)
,p_name=>'P373_FK_CALC_STATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>890
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Calc State'
,p_source=>'FK_CALC_STATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297565147217998)
,p_name=>'P373_FK_CALC_STATE_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>910
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Calc State Eur'
,p_source=>'FK_CALC_STATE_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297680549217999)
,p_name=>'P373_FK_CALC_STATE_FRMDW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>930
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Calc State Frmdw'
,p_source=>'FK_CALC_STATE_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297698933218000)
,p_name=>'P373_DATUM_VERGEHEN'
,p_source_data_type=>'DATE'
,p_item_sequence=>1540
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Vergehen'
,p_source=>'DATUM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297782958218001)
,p_name=>'P373_CREATE_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>2120
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Create At'
,p_source=>'CREATE_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297881472218002)
,p_name=>'P373_CREATE_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2140
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Create By'
,p_source=>'CREATE_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3297984566218003)
,p_name=>'P373_MODIFY_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>2160
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Modify At'
,p_source=>'MODIFY_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298157011218004)
,p_name=>'P373_MODIFY_BY'
,p_source_data_type=>'DATE'
,p_item_sequence=>2180
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Modify By'
,p_source=>'MODIFY_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298207497218005)
,p_name=>'P373_DATUM_ORT_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2210
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298360827218006)
,p_name=>'P373_DATUM_ADDRESSE_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2230
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298407943218007)
,p_name=>'P373_DATUM_BUSSGELD_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2250
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298573019218008)
,p_name=>'P373_DATUM_BELEG_POS_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2270
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298612892218009)
,p_name=>'P373_DATUM_BUCHUNG_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2290
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298701120218010)
,p_name=>'P373_DATUM_VERPFL_BEL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2310
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_source=>'DATUM_VERPFL_BEL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298842533218011)
,p_name=>'P373_DATUM_DUPL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>2330
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Datum Dupl Ok'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3298947598218012)
,p_name=>'P373_DUPL_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2370
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3396766362261209)
,p_name=>'P373_DATUM_DUPL_OK_FLG'
,p_item_sequence=>2340
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3396849256261210)
,p_name=>'P373_FK_DUPL_STATUS_FLG'
,p_item_sequence=>2360
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3396902087261211)
,p_name=>'P373_FK_INTERNET_APP_FLG'
,p_item_sequence=>1310
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3397070400261212)
,p_name=>'P373_DATUM_VERPFL_BEL_OK_FLG'
,p_item_sequence=>2320
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3397171582261213)
,p_name=>'P373_DATUM_BUCHUNG_OK_FLG'
,p_item_sequence=>2300
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3397230873261214)
,p_name=>'P373_DATUM_BELEG_POS_OK_FLG'
,p_item_sequence=>2280
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3397316703261215)
,p_name=>'P373_DATUM_BUSSGELD_OK_FLG'
,p_item_sequence=>2260
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859385364639866)
,p_name=>'P373_DATUM_ADDRESSE_OK_FLG'
,p_item_sequence=>2240
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859520032639867)
,p_name=>'P373_DATUM_ORT_OK_FLG'
,p_item_sequence=>2220
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859588074639868)
,p_name=>'P373_MODIFY_BY_FLG'
,p_item_sequence=>2190
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859799439639870)
,p_name=>'P373_CREATE_BY_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2150
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859976366639871)
,p_name=>'P373_CREATE_AT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2130
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3859995423639872)
,p_name=>'P373_DATUM_VERGEHEN_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1550
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860135575639873)
,p_name=>'P373_FK_STATUS_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860219625639874)
,p_name=>'P373_FK_CALC_STATE_FRMDW_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>940
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860331351639875)
,p_name=>'P373_FK_CALC_STATE_EUR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>920
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860389760639876)
,p_name=>'P373_FK_CALC_STATE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>900
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860485018639877)
,p_name=>'P373_FK_REAL_BELEG_EXIST_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860625335639878)
,p_name=>'P373_KUNDENNUMMER_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860759962639879)
,p_name=>'P373_WEBSEITE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1330
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860819471639880)
,p_name=>'P373_GEZAHLT_AM_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3860882040639881)
,p_name=>'P373_DESCR_BUSSGELD_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1590
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861060084639882)
,p_name=>'P373_CODE_BUSSGELD_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1570
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861094188639883)
,p_name=>'P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1700
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861224082639884)
,p_name=>'P373_GESCHW_UEBER_GRZ_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1720
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861308844639885)
,p_name=>'P373_GESCHW_SOLL_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1680
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861404607639886)
,p_name=>'P373_GESCHW_IST_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1660
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861578877639887)
,p_name=>'P373_FK_IMP_BA_BEL_OLD_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861659682639888)
,p_name=>'P373_FK_LOCATION_VERG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1820
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861752021639889)
,p_name=>'P373_PUNKTE_BIS_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1800
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861821750639890)
,p_name=>'P373_PUNKTE_VON_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1780
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3861977113639891)
,p_name=>'P373_CNT_PUNKTE_GESCHAETZT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1760
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862073721639892)
,p_name=>'P373_FK_ABL_ORDNER_PAGE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1410
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862122211639893)
,p_name=>'P373_FK_BELEG_ABLAGE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1430
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862246948639894)
,p_name=>'P373_CNT_PUNKTE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1740
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862298272639895)
,p_name=>'P373_VERG_BEHOERDE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1530
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862407042639896)
,p_name=>'P373_COMM_VERGEHEN_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2040
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862496969639897)
,p_name=>'P373_FK_ZAHLSTATUS_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1040
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862645760639898)
,p_name=>'P373_FK_LA_WDH_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1140
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862776677639899)
,p_name=>'P373_FK_LA_KONTO_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1160
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862845846639900)
,p_name=>'P373_LA_DATUM_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1180
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3862892749639901)
,p_name=>'P373_MENGENEINHEIT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863035103639902)
,p_name=>'P373_PREIS_PRO_MENGE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863104163639903)
,p_name=>'P373_NETTO_BETRAG_EUR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>810
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863260135639904)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>870
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863292645639905)
,p_name=>'P373_BRUTTO_BETRAG_EUR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>850
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863419358639906)
,p_name=>'P373_MWST_BETRAG_EUR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>830
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863558471639907)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863638158639908)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>710
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863756457639909)
,p_name=>'P373_FRMDW_MWST_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>670
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863811929639910)
,p_name=>'P373_FK_FRMDW_MWST_SATZ_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>690
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3863951964639911)
,p_name=>'P373_FK_FRMDW_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>770
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3864054931639912)
,p_name=>'P373_FRMDW_NETTO_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>650
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3864091605639913)
,p_name=>'P373_COMM_PARKTICKET_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2060
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3864222645639914)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>630
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3864289406639915)
,p_name=>'P373_TANKSTELLEN_NR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1460
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5544517361927566)
,p_name=>'P373_COMM_ADRESSE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2020
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5544758676927568)
,p_name=>'P373_FK_BIS_ARBEITSTAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5544853024927569)
,p_name=>'P373_FK_VON_ARBEITSTAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5544889296927570)
,p_name=>'P373_BIS_UHRZEIT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545017164927571)
,p_name=>'P373_VON_UHRZEIT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545142136927572)
,p_name=>'P373_BELEG_UHRZEIT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545200862927573)
,p_name=>'P373_PERSOENLICH_VOR_ORT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1930
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545342933927574)
,p_name=>'P373_FK_LOCATION_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1910
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545385817927575)
,p_name=>'P373_ZAPFSAEULE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1480
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545544562927576)
,p_name=>'P373_LITER_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1500
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545643834927577)
,p_name=>'P373_ZAHLUNGSBELEG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1060
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545710654927578)
,p_name=>'P373_BELEG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545857279927579)
,p_name=>'P373_COMM_SONSTIGES_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2080
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5545905578927580)
,p_name=>'P373_COMM_BEGRUENDUNG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2100
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546004117927581)
,p_name=>'P373_COMM_PRODUKTE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2000
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546085889927582)
,p_name=>'P373_COMM_TEL_BELEG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1980
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546196839927583)
,p_name=>'P373_COMM_REST_BELEG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1960
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546337768927584)
,p_name=>'P373_FK_UMRECHNUNGSKURS_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546418779927585)
,p_name=>'P373_STEUERNUMMER_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>970
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546556785927586)
,p_name=>'P373_FK_WAEHRUNG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546675076927587)
,p_name=>'P373_BRUTTO_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546740625927588)
,p_name=>'P373_MWST_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546870757927589)
,p_name=>'P373_FK_STEUERSATZ_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>590
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5546941741927590)
,p_name=>'P373_NETTO_BETRAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547059677927591)
,p_name=>'P373_BIS_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547129209927592)
,p_name=>'P373_VON_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547185884927593)
,p_name=>'P373_BEL_DATUM_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547377133927594)
,p_name=>'P373_FK_CITY_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1850
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547424509927595)
,p_name=>'P373_FK_LAND_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1870
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547529683927596)
,p_name=>'P373_BEZEICHNUNG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547583288927597)
,p_name=>'P373_BELEGNUMMER_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547715730927598)
,p_name=>'P373_FK_PROJEKT_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1350
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547857656927599)
,p_name=>'P373_FK_INVENTAR_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1370
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547926266927600)
,p_name=>'P373_FK_VERWENDUNGSZWECK_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1270
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5547993694927601)
,p_name=>'P373_FK_ZAHLUNGSART_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1020
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5548167596927602)
,p_name=>'P373_FK_BUCHUNG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1080
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5548197610927603)
,p_name=>'P373_FK_ARBEITSTAG_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5548295865927604)
,p_name=>'P373_FK_KATEGORIE_FLG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1250
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790545897270768)
,p_name=>'P373_5_STATUS_1'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>5_Status</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790617517270769)
,p_name=>'P373_6_MENGE_1'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>6_MENGE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790746645270770)
,p_name=>'P373_7_PREIS_1'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>7_PREIS</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790795845270771)
,p_name=>'P373_8_CALC_1'
,p_item_sequence=>870
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>8_CALC</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790902168270772)
,p_name=>'P373_9_STEUER_1'
,p_item_sequence=>940
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>9_STEUER</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6790994154270773)
,p_name=>'P373_10_ZAHLUNG_1'
,p_item_sequence=>970
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>10_ZAHLUNG</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791111672270774)
,p_name=>'P373_11_LASTSCHRIFT_1'
,p_item_sequence=>1110
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>11_LASTSCHRIFT</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791350259270776)
,p_name=>'P373_NEW_1_1_1_2_1_2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P373_BEZEICHNUNG_1'
,p_display_when_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_icon_css_classes=>'fa-times-square'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791467965270777)
,p_name=>'P373_NEW_1_1_1_2_1_2_1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P373_BEZEICHNUNG_FLG'
,p_display_when_type=>'ITEM_IS_NULL_OR_ZERO'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_icon_css_classes=>'fa-remove'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791517713270778)
,p_name=>'P373_NEW_1_1_1_2_1_3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P373_BEZEICHNUNG_FLG'
,p_display_when2=>'2'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_icon_css_classes=>'fa-check-circle'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791597009270779)
,p_name=>'P373_12_LEXWARE_1'
,p_item_sequence=>1180
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>12_LEXWARE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791716119270780)
,p_name=>'P373_13_KATEGORIE_1'
,p_item_sequence=>1220
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>13_Kategorie</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6791880091270781)
,p_name=>'P373_14_ABLAGE_1'
,p_item_sequence=>1380
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>14_ABLAGE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6792140445270784)
,p_name=>'P373_15_TANK_1'
,p_item_sequence=>1430
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>15_TANK</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6792194854270785)
,p_name=>'P373_16_BUSSGELD_1'
,p_item_sequence=>1500
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>16_BUSSGELD</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6793673638270799)
,p_name=>'P373_17_ADRESSE_1'
,p_item_sequence=>1870
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>17_ADRESSE</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6793703878270800)
,p_name=>'P373_18_LOCATION_1'
,p_item_sequence=>1940
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>18_LOCATION</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6793856025270801)
,p_name=>'P373_19_COMM_1'
,p_item_sequence=>1990
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>19_COMM</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6793915806270802)
,p_name=>'P373_20_CHANGE_1'
,p_item_sequence=>2120
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>20_CHANGE</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6794029395270803)
,p_name=>'P373_21_CHECK_1'
,p_item_sequence=>2210
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'<b>21 Check</b>'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14184883130489784)
,p_name=>'P373_FK_KTO_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1100
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kto Buchung 1'
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14185079999489785)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1_1_1_1'
,p_item_sequence=>1100
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14185133700489786)
,p_name=>'P373_FK_BUCHUNG_FLG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1110
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17300813154528028)
,p_name=>'P373_PK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'ID ZIel'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17301182239528033)
,p_name=>'P373_FK_LEX_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1210
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_item_source_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>'Fk Lex Buchung'
,p_source=>'FK_LEX_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17381211993530994)
,p_name=>'P373_TRGT_PK_INP_BELEGE_ALL'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(17381100044530993)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG d, pk_inp_belege_all',
'from t_inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17382607043531008)
,p_name=>'P373_FK_LEX_BUCHUNG_1_FLG'
,p_item_sequence=>1210
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Lex Buchung'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'4'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17382739161531009)
,p_name=>'P373_FK_KATEGORIE_1_FLG'
,p_item_sequence=>1240
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kategorie'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17382853519531010)
,p_name=>'P373_NEW_1_1'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'FK_BAS_KAL_ARBEITSTAG_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17455653833556972)
,p_name=>'P373_PK_INP_BELEGE_ALL_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'ID SRC'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17456054141556972)
,p_name=>'P373_FK_LEX_BUCHUNG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1200
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Lex Buchung'
,p_source=>'FK_LEX_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17459233658556975)
,p_name=>'P373_BELEGNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Belegnummer'
,p_source=>'BELEGNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17459631673556975)
,p_name=>'P373_BEZEICHNUNG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17460804871556975)
,p_name=>'P373_BEL_DATUM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bel Datum'
,p_source=>'BEL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17461249080556975)
,p_name=>'P373_VON_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Von'
,p_source=>'VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17461601911556975)
,p_name=>'P373_BIS_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bis'
,p_source=>'BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17462001239556977)
,p_name=>'P373_NETTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Netto Betrag'
,p_source=>'NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17462863482556977)
,p_name=>'P373_MWST_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Mwst Betrag'
,p_source=>'MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17463245499556977)
,p_name=>'P373_BRUTTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>590
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Brutto Betrag'
,p_source=>'BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17463990995556977)
,p_name=>'P373_STEUERNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>950
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Steuernummer'
,p_source=>'STEUERNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17464785334556977)
,p_name=>'P373_COMM_REST_BELEG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2000
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Rest Beleg'
,p_source=>'COMM_REST_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17465201013556978)
,p_name=>'P373_COMM_TEL_BELEG_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2020
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Tel Beleg'
,p_source=>'COMM_TEL_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17465610128556978)
,p_name=>'P373_COMM_PRODUKTE_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2040
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Produkte'
,p_source=>'COMM_PRODUKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17466460044556978)
,p_name=>'P373_COMM_SONSTIGES_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2100
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Sonstiges'
,p_source=>'COMM_SONSTIGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17466810962556978)
,p_name=>'P373_BELEG_1'
,p_source_data_type=>'BLOB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Beleg'
,p_source=>'BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17467204313556978)
,p_name=>'P373_ZAHLUNGSBELEG_1'
,p_source_data_type=>'BLOB'
,p_item_sequence=>1040
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Zahlungsbeleg'
,p_source=>'ZAHLUNGSBELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17467667284556978)
,p_name=>'P373_LITER_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1480
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Liter'
,p_source=>'LITER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17469252551556980)
,p_name=>'P373_BELEG_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Beleg Uhrzeit'
,p_format_mask=>'HH24:MI:SS'
,p_source=>'BELEG_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17469591373556980)
,p_name=>'P373_VON_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Von Uhrzeit'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_source=>'VON_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17470017971556980)
,p_name=>'P373_BIS_UHRZEIT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bis Uhrzeit'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_source=>'BIS_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17471279902556980)
,p_name=>'P373_COMM_ADRESSE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2060
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Adresse'
,p_source=>'COMM_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17471590943556981)
,p_name=>'P373_TANKSTELLEN_NR_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1440
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Tankstellen Nr'
,p_source=>'TANKSTELLEN_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17472024197556981)
,p_name=>'P373_BRUTTO_BETRAG_INCL_TRINKG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Brutto Betrag Incl Trinkg'
,p_source=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17472446589556981)
,p_name=>'P373_COMM_PARKTICKET_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2090
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Parkticket'
,p_source=>'COMM_PARKTICKET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17472856903556981)
,p_name=>'P373_FRMDW_NETTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>630
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Frmdw Netto Betrag'
,p_source=>'FRMDW_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17473999876556981)
,p_name=>'P373_FRMDW_MWST_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>650
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Frmdw Mwst Betrag'
,p_source=>'FRMDW_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17474405214556981)
,p_name=>'P373_FRMDW_BRUTTO_BETRAG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>690
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Frmdw Brutto Betrag'
,p_source=>'FRMDW_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17474853637556983)
,p_name=>'P373_FRMDW_BRUTTO_INCL_TRINKG_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>710
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Frmdw Brutto Incl Trinkg'
,p_source=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17475209621556983)
,p_name=>'P373_MWST_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>810
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Mwst Betrag Eur'
,p_source=>'MWST_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17475673169556983)
,p_name=>'P373_BRUTTO_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>830
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Brutto Betrag Eur'
,p_source=>'BRUTTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17475989379556983)
,p_name=>'P373_BRUTTO_INCL_TRINKG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>850
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Brutto Incl Trinkg Eur'
,p_source=>'BRUTTO_INCL_TRINKG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17476454879556983)
,p_name=>'P373_NETTO_BETRAG_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Netto Betrag Eur'
,p_source=>'NETTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17476853308556983)
,p_name=>'P373_PREIS_PRO_MENGE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Preis Pro Menge'
,p_source=>'PREIS_PRO_MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17477278506556983)
,p_name=>'P373_MENGENEINHEIT_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Mengeneinheit'
,p_source=>'MENGENEINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17477656802556983)
,p_name=>'P373_LA_DATUM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1160
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'La Datum'
,p_source=>'LA_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17478018625556985)
,p_name=>'P373_FK_LA_KONTO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1140
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk La Konto'
,p_source=>'FK_LA_KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17478467637556985)
,p_name=>'P373_FK_LA_WDH_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1120
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk La Wdh'
,p_source=>'FK_LA_WDH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17479276072556985)
,p_name=>'P373_COMM_VERGEHEN_1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2080
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Comm Vergehen'
,p_source=>'COMM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17479586175556985)
,p_name=>'P373_VERG_BEHOERDE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1510
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Verg Behoerde'
,p_source=>'VERG_BEHOERDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17480852695556985)
,p_name=>'P373_FK_ABL_ORDNER_PAGE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1390
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Abl Ordner Page'
,p_source=>'FK_ABL_ORDNER_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17482855935556986)
,p_name=>'P373_FK_IMP_BA_BEL_OLD_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Imp Ba Bel Old'
,p_source=>'FK_IMP_BA_BEL_OLD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17485621126556988)
,p_name=>'P373_GEZAHLT_AM_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>980
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Gezahlt Am'
,p_source=>'GEZAHLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17486023790556988)
,p_name=>'P373_WEBSEITE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1310
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Webseite'
,p_source=>'WEBSEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17486405597556988)
,p_name=>'P373_KUNDENNUMMER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Kundennummer'
,p_source=>'KUNDENNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17486879437556988)
,p_name=>'P373_FK_REAL_BELEG_EXIST_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Real Beleg Exist'
,p_source=>'FK_REAL_BELEG_EXIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17487220575556988)
,p_name=>'P373_FK_CALC_STATE_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>880
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Calc State'
,p_source=>'FK_CALC_STATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17487646735556988)
,p_name=>'P373_FK_CALC_STATE_EUR_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>900
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Calc State Eur'
,p_source=>'FK_CALC_STATE_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17488037144556988)
,p_name=>'P373_FK_CALC_STATE_FRMDW_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>920
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Calc State Frmdw'
,p_source=>'FK_CALC_STATE_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17488836861556989)
,p_name=>'P373_DATUM_VERGEHEN_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>1530
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Vergehen'
,p_source=>'DATUM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17489270016556989)
,p_name=>'P373_CREATE_AT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2130
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Create At'
,p_source=>'CREATE_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17489613930556989)
,p_name=>'P373_CREATE_BY_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2150
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Create By'
,p_source=>'CREATE_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17490001798556989)
,p_name=>'P373_MODIFY_AT_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2170
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Modify At'
,p_source=>'MODIFY_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17490387019556989)
,p_name=>'P373_MODIFY_BY_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2190
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Modify By'
,p_source=>'MODIFY_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17490801039556989)
,p_name=>'P373_DATUM_ORT_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2220
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17491226137556989)
,p_name=>'P373_DATUM_ADDRESSE_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2240
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17491601545556989)
,p_name=>'P373_DATUM_BUSSGELD_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2260
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17492010435556989)
,p_name=>'P373_DATUM_BELEG_POS_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2280
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17492473251556989)
,p_name=>'P373_DATUM_BUCHUNG_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2300
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17492849073556991)
,p_name=>'P373_DATUM_VERPFL_BEL_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2320
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_source=>'DATUM_VERPFL_BEL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17494060011556991)
,p_name=>'P373_DATUM_DUPL_OK_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2340
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Datum Dupl Ok'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17494451006556991)
,p_name=>'P373_DUPL_BEMERKUNG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2370
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17526392970576458)
,p_name=>'P373_SRC_PK_INP_BELEGE_ALL'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(17381100044530993)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG d, pk_inp_belege_all',
'from t_inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745101030661010)
,p_name=>'P373_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2400
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Monat'
,p_source=>'MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745207583661011)
,p_name=>'P373_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2410
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Jahr'
,p_source=>'JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745325748661012)
,p_name=>'P373_GEZEICHNET_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2420
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Gezeichnet Am'
,p_source=>'GEZEICHNET_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745405985661013)
,p_name=>'P373_FK_KON_GEZEICHNET_VON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2430
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kon Gezeichnet Von'
,p_source=>'FK_KON_GEZEICHNET_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745597441661014)
,p_name=>'P373_AZ_STUNDENZAHL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2440
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Az Stundenzahl'
,p_source=>'AZ_STUNDENZAHL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745632094661015)
,p_name=>'P373_GENEHMIGT_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2450
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Genehmigt Am'
,p_source=>'GENEHMIGT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745759729661016)
,p_name=>'P373_EINGEREICHT_AM_PP_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2460
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Eingereicht Am Pp 1'
,p_source=>'EINGEREICHT_AM_PP_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745809950661017)
,p_name=>'P373_EINGEREICHT_AM_PP_2'
,p_source_data_type=>'DATE'
,p_item_sequence=>2470
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Eingereicht Am Pp 2'
,p_source=>'EINGEREICHT_AM_PP_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17745955174661018)
,p_name=>'P373_BESTAETIGUNG_AM_PP_1'
,p_source_data_type=>'DATE'
,p_item_sequence=>2480
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bestaetigung Am Pp 1'
,p_source=>'BESTAETIGUNG_AM_PP_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746060974661019)
,p_name=>'P373_BESTAETIGUNG_AM_PP_2'
,p_source_data_type=>'DATE'
,p_item_sequence=>2490
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bestaetigung Am Pp 2'
,p_source=>'BESTAETIGUNG_AM_PP_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746187254661020)
,p_name=>'P373_FK_KON_PERSON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2500
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kon Person'
,p_source=>'FK_KON_PERSON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746209241661021)
,p_name=>'P373_AZ_UEBERSTUNDEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2510
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Az Ueberstunden'
,p_source=>'AZ_UEBERSTUNDEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746396051661022)
,p_name=>'P373_AZ_SOLLSTUNDEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2520
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Az Sollstunden'
,p_source=>'AZ_SOLLSTUNDEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746437916087261)
,p_name=>'P373_NEW_1_1_1'
,p_item_sequence=>680
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746440355661023)
,p_name=>'P373_AZ_FAHRZEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2530
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Az Fahrzeit'
,p_source=>'AZ_FAHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746510075661024)
,p_name=>'P373_FK_STD_REISE_FAHRZEIT_EINHEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2540
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Reise Fahrzeit Einheit'
,p_source=>'FK_STD_REISE_FAHRZEIT_EINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746515737087262)
,p_name=>'P373_NEW_1_1_1_1'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'FK_STD_INP_STATUS_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746664073087263)
,p_name=>'P373_NEW_1_1_1_1_1'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'fk_bas_kal_bis_arbeitstag_flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746681300661025)
,p_name=>'P373_FK_WORK_STUNDENSATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2550
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Work Stundensatz'
,p_source=>'FK_WORK_STUNDENSATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746723842087264)
,p_name=>'P373_NEW_1_1_1_1_1_1'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'FK_BAS_KAL_VON_ARBEITSTAG_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746736974661026)
,p_name=>'P373_FK_WORK_STUNDENSATZ_UEBERSTUNDEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2560
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Work Stundensatz Ueberstunden'
,p_source=>'FK_WORK_STUNDENSATZ_UEBERSTUNDEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746782217087265)
,p_name=>'P373_NEW_1_1_1_2'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'BIS_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746887849661027)
,p_name=>'P373_FK_WORK_STUNDENSATZ_WOCHENENDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2570
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Work Stundensatz Wochenende'
,p_source=>'FK_WORK_STUNDENSATZ_WOCHENENDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746947378087266)
,p_name=>'P373_NEW_1_1_1_2_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P373_BEZEICHNUNG_1'
,p_display_when_type=>'ITEM_IS_NULL_OR_ZERO'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_icon_css_classes=>'fa-check-circle'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17746956968661028)
,p_name=>'P373_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2580
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747028618661029)
,p_name=>'P373_ERSTELLT_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2590
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Erstellt Am'
,p_source=>'ERSTELLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747053004087267)
,p_name=>'P373_NEW_1_1_1_2_1_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Belegnummer_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747144141087268)
,p_name=>'P373_NEW_1_1_1_2_1_1_1'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747172653661030)
,p_name=>'P373_FK_WF_WORKFLOW_STEP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2600
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Wf Workflow Step'
,p_source=>'FK_WF_WORKFLOW_STEP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747255806661031)
,p_name=>'P373_FK_WF_WORKFLOW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2610
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Wf Workflow'
,p_source=>'FK_WF_WORKFLOW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747280262087269)
,p_name=>'P373_NEW_1_1_1_2_2'
,p_item_sequence=>740
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747283665087270)
,p_name=>'P373_NEW_1_1_1_2_2_1'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'BEL_DATUM_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747333141661032)
,p_name=>'P373_FK_WORK_STUNDENSATZ_FAHRZEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2620
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Work Stundensatz Fahrzeit'
,p_source=>'FK_WORK_STUNDENSATZ_FAHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747382373087271)
,p_name=>'P373_NEW_1_1_1_2_2_1_1'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Von_flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747446821661033)
,p_name=>'P373_SOLL_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2630
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Soll Netto Betrag'
,p_source=>'SOLL_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747553294087272)
,p_name=>'P373_NEW_1_1_1_2_2_1_1_1'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747588560087273)
,p_name=>'P373_NEW_1_1_1_2_3'
,p_item_sequence=>1260
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747591486661034)
,p_name=>'P373_SOLL_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2640
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Soll Mwst Betrag'
,p_source=>'SOLL_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747657920661035)
,p_name=>'P373_SOLL_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2650
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Soll Brutto Betrag'
,p_source=>'SOLL_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747741493661036)
,p_name=>'P373_FK_BAS_STEU_STEUER_SATZ_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2660
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Steu Steuer Satz Soll'
,p_source=>'FK_BAS_STEU_STEUER_SATZ_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747745971087274)
,p_name=>'P373_NEW_1_1_1_2_3_1'
,p_item_sequence=>960
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747800214661037)
,p_name=>'P373_FK_BAS_MON_WAEHRUNG_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2670
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Waehrung Soll'
,p_source=>'FK_BAS_MON_WAEHRUNG_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747819543087275)
,p_name=>'P373_NEW_1_1_1_2_3_1_1'
,p_item_sequence=>600
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747946825087276)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1'
,p_item_sequence=>560
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17747948226661038)
,p_name=>'P373_FK_BAS_MON_UMRECHNUNGSKURS_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2680
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Bas Mon Umrechnungskurs Soll'
,p_source=>'FK_BAS_MON_UMRECHNUNGSKURS_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748031281087277)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1_1'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748036465661039)
,p_name=>'P373_MENGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2690
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Menge'
,p_source=>'MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748150353087278)
,p_name=>'P373_NEW_1_1_1_2_3_1_1_1_1_1'
,p_item_sequence=>1070
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748173412661040)
,p_name=>'P373_FK_STD_INP_MENGE_EINHEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2700
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Inp Menge Einheit'
,p_source=>'FK_STD_INP_MENGE_EINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748223180087279)
,p_name=>'P373_NEW_1_1_1_2_4'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748247067661041)
,p_name=>'P373_ANZAHL_ZUGEHOERIGE_REAL_BELEGE_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2710
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Anzahl Zugehoerige Real Belege Soll'
,p_source=>'ANZAHL_ZUGEHOERIGE_REAL_BELEGE_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748344852087280)
,p_name=>'P373_NEW_1_1_1_2_3_2'
,p_item_sequence=>1540
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748373954661042)
,p_name=>'P373_ANZAHL_ZUGEHOERIGE_REAL_BELEGE_IST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2720
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Anzahl Zugehoerige Real Belege Ist'
,p_source=>'ANZAHL_ZUGEHOERIGE_REAL_BELEGE_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748402193087281)
,p_name=>'P373_NEW_1_1_1_2_3_2_1'
,p_item_sequence=>1520
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748425671661043)
,p_name=>'P373_FK_KON_PERSON_GEZAHLT_VON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2730
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Kon Person Gezahlt Von'
,p_source=>'FK_KON_PERSON_GEZAHLT_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748534599087282)
,p_name=>'P373_NEW_1_1_1_2_3_2_1_1'
,p_item_sequence=>1300
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748549668661044)
,p_name=>'P373_FK_STD_INP_BELEGART'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2740
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Inp Belegart'
,p_source=>'FK_STD_INP_BELEGART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748584345087283)
,p_name=>'P373_NEW_1_1_1_2_3_2_1_1_1'
,p_item_sequence=>1420
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748672709661045)
,p_name=>'P373_FK_ADR_RECHNUNGSADRESSE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2750
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Adr Rechnungsadresse'
,p_source=>'FK_ADR_RECHNUNGSADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748725258087284)
,p_name=>'P373_NEW_1_1_1_2_3_2_2'
,p_item_sequence=>1050
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748754558661046)
,p_name=>'P373_FK_ADR_LIEFERADRESSE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2760
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Adr Lieferadresse'
,p_source=>'FK_ADR_LIEFERADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748786877087285)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'BELEG_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748800134661047)
,p_name=>'P373_RECHNUNGSDATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2770
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Rechnungsdatum'
,p_source=>'RECHNUNGSDATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748923305087286)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1'
,p_item_sequence=>1580
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17748987108661048)
,p_name=>'P373_LIEFERDATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2780
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Lieferdatum'
,p_source=>'LIEFERDATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749027341087287)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749062145661049)
,p_name=>'P373_BESTELLDATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>2790
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Bestelldatum'
,p_source=>'BESTELLDATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749108262087288)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_1'
,p_item_sequence=>1560
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749145151661050)
,p_name=>'P373_ANLAGEN'
,p_source_data_type=>'CLOB'
,p_item_sequence=>2800
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Anlagen'
,p_source=>'ANLAGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749199984087289)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'VON_UHRZEIT_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749313880087290)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Beleg_uhrzeit_flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749452506087291)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1_1'
,p_item_sequence=>1320
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749493842087292)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_1_1_1'
,p_item_sequence=>1030
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749631345087293)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2'
,p_item_sequence=>1600
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749723294087294)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1'
,p_item_sequence=>1450
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749786946087295)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1_1'
,p_item_sequence=>1960
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749956267087296)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_1_1_1'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'bis_uhrzeit_flg'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17749998987087297)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2'
,p_item_sequence=>1620
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750151560087298)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1'
,p_item_sequence=>640
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750231690087299)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1'
,p_item_sequence=>1360
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750363500087300)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1_1'
,p_item_sequence=>620
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750427476087301)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_1_1_1_1'
,p_item_sequence=>2070
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750572347087302)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2'
,p_item_sequence=>700
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750627769087303)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1'
,p_item_sequence=>720
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750690737087304)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_1'
,p_item_sequence=>660
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750854424087305)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_1_1'
,p_item_sequence=>1640
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17750957955087306)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'MENGENEINHEIT_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17751066714087307)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'PREIS_PRO_MENGE_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17751138508087308)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1'
,p_item_sequence=>800
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17751181354087309)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1'
,p_item_sequence=>860
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17751374960087310)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1_1'
,p_item_sequence=>840
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17914831720145461)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_1_1_1_1_1'
,p_item_sequence=>820
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17914969023145462)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2'
,p_item_sequence=>1660
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915010196145463)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1'
,p_item_sequence=>1170
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915110118145464)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1'
,p_item_sequence=>1150
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915258402145465)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1_1'
,p_item_sequence=>1340
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915335863145466)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_1_1_1_1'
,p_item_sequence=>1130
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915386718145467)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2'
,p_item_sequence=>1720
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915516507145468)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1'
,p_item_sequence=>1700
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915672403145469)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1'
,p_item_sequence=>1470
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915777529145470)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1_1'
,p_item_sequence=>1490
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915795164145471)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_1_1_1_1'
,p_item_sequence=>1680
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17915919850145472)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'FK_IMP_BA_BEL_OLD_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916077249145473)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1'
,p_item_sequence=>1780
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916152167145474)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1_1'
,p_item_sequence=>1760
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916189064145475)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_1_1_1'
,p_item_sequence=>1740
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916347372145476)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2'
,p_item_sequence=>1840
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916463825145477)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_1'
,p_item_sequence=>1820
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916488183145478)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_1_1'
,p_item_sequence=>1800
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916609454145479)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2'
,p_item_sequence=>1400
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916761715145480)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1'
,p_item_sequence=>990
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916794582145481)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1'
,p_item_sequence=>1890
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17916895819145482)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>1910
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917060274145483)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>1860
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917155013145484)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2'
,p_item_sequence=>1280
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917195833145485)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1'
,p_item_sequence=>910
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917329543145486)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>890
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917458834145487)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'FK_REAL_BELEG_EXIST_FLG'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917557083145488)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>930
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917676463145489)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_1_1_1_1_1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Kundennummer_FLG'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_icon_css_classes=>'fa-check-circle'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917778958145490)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2'
,p_item_sequence=>2200
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917797541145491)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2160
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17917892492145492)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2140
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918006042145493)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2180
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918106648145494)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>1930
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918220330145495)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2330
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918366975145496)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2270
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918395210145497)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2290
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918532487145498)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1_1'
,p_item_sequence=>2250
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918618185145499)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_1_1_1_1'
,p_item_sequence=>2230
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918719820145500)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2010
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918839907145501)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2310
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17918973319145502)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>1980
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17919052918145503)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2'
,p_item_sequence=>2030
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17919134732145504)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2_1'
,p_item_sequence=>2050
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17919251641145505)
,p_name=>'P373_NEW_1_1_1_2_3_2_2_1_1_1_2_2_2_2_1_2_2_2_2_2_2_2_2_2_2_2_1_1'
,p_item_sequence=>2350
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Arbeitstag'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:ja;1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18413913456947901)
,p_name=>'P373_FK_STEU_STEUER_JAHR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2810
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Steu Steuer Jahr'
,p_source=>'FK_STEU_STEUER_JAHR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18414039410947902)
,p_name=>'P373_FK_STEU_STEUER_MONAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2820
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Steu Steuer Monat'
,p_source=>'FK_STEU_STEUER_MONAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18414122149947903)
,p_name=>'P373_FK_STD_STEU_STEUERERKLAERUNG_ANLAGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2830
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Fk Std Steu Steuererklaerung Anlage'
,p_source=>'FK_STD_STEU_STEUERERKLAERUNG_ANLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18414267733947904)
,p_name=>'P373_ETIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>2840
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Etin'
,p_source=>'ETIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1020
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18414332088947905)
,p_name=>'P373_IDENTIFIKATIONSNUMMER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>2850
,p_item_plug_id=>wwv_flow_api.id(55051948228420385)
,p_item_source_plug_id=>wwv_flow_api.id(55051948228420385)
,p_prompt=>'Identifikationsnummer'
,p_source=>'IDENTIFIKATIONSNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19724897179495777)
,p_name=>'P373_FK_LEX_BUCHUNG_FLG'
,p_item_sequence=>1220
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19923501215926674)
,p_name=>'P373_FK_GESCHAEFTSPARTNER_FLG'
,p_item_sequence=>1290
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20022895406948073)
,p_name=>'P373_DUPL_BEMERKUNG_FLG'
,p_item_sequence=>2380
,p_item_plug_id=>wwv_flow_api.id(17300552212528027)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''abweichend'', 1 from dual',
'union',
'select ''ok'', 2 from dual'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'3'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20023331800948077)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P373_FK_LEX_BUCHUNG_FLG'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20023404504948078)
,p_event_id=>wwv_flow_api.id(20023331800948077)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P373_FK_LEX_BUCHUNG_FLG'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17372477776528075)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(17300552212528027)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19724798014495776)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  delete from t_inp_belege_all where pk_inp_belege_all = :P373_SRC_PK_INP_BELEGE_ALL;',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19724744476495775)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15352943604904914)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete_new'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  delete from t_inp_belege_all where pk_inp_belege_all = :P373_PK_INP_BELEGE_ALL;',
'  commit;',
'end; '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17370817902528074)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15353027697904915)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete_old'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  delete from t_inp_belege_all where pk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1;',
'  commit;',
'end; '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(19724744476495775)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17382541389531007)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize form Create Form_SRC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' --1 - SRC-Belege Daten laden',
'',
'  if :P373_PK_INP_BELEGE_ALL_1 is not null then',
'  ',
'  select',
'',
'            FK_LEX_BUCHUNG	,',
'            FK_BAS_KAT_KATEGORIE	,',
'            FK_BAS_KAL_ARBEITSTAG	,',
'            FK_KTO_BUCHUNG	,',
'            FK_STD_KTO_ZAHLUNGSART	,',
'            FK_STD_VERW_VERWENDUNGSZWECK	,',
'            FK_INV_INVENTAR	,',
'            FK_PROJ_PROJEKT	,',
'            BELEGNUMMER	,',
'            BEZEICHNUNG	,',
'            FK_ADR_LAND	,',
'            FK_ADR_CITY	,',
'            BEL_DATUM	,',
'            VON	,',
'            BIS	,',
'            NETTO_BETRAG	,',
'            FK_BAS_STEU_STEUER_SATZ	,',
'            MWST_BETRAG	,',
'            BRUTTO_BETRAG	,',
'            FK_BAS_MON_WAEHRUNG	,',
'            STEUERNUMMER	,',
'            FK_BAS_MON_UMRECHNUNGSKURS	,',
'            COMM_REST_BELEG	,',
'            COMM_TEL_BELEG	,',
'            COMM_PRODUKTE	,',
'            "COMM_BEGRUENDUNG"	,',
'            COMM_SONSTIGES	,',
'            BELEG	,',
'            ZAHLUNGSBELEG	,',
'            LITER	,',
'            ZAPFSAEULE	,',
'            FK_LOC_LOCATION	,',
'            PERSOENLICH_VOR_ORT	,',
'            to_char(BELEG_UHRZEIT,''DD.MM.YYYY HH24:MI:SS'')	,',
'            to_char(VON_UHRZEIT,''DD.MM.YYYY HH24:MI:SS'')	,',
'            to_char(BIS_UHRZEIT	,''DD.MM.YYYY HH24:MI:SS''),',
'            FK_BAS_KAL_VON_ARBEITSTAG	,',
'            FK_BAS_KAL_BIS_ARBEITSTAG	,',
'            COMM_ADRESSE	,',
'            TANKSTELLEN_NR	,',
'            BRUTTO_BETRAG_INCL_TRINKG	,',
'            COMM_PARKTICKET	,',
'            FRMDW_NETTO_BETRAG	,',
'            FK_BAS_MON_FRMDW	,',
'            FK_BAS_MON_FRMDW_MWST_SATZ	,',
'            FRMDW_MWST_BETRAG	,',
'            FRMDW_BRUTTO_BETRAG	,',
'            FRMDW_BRUTTO_INCL_TRINKG	,',
'            MWST_BETRAG_EUR	,',
'            BRUTTO_BETRAG_EUR	,',
'            BRUTTO_INCL_TRINKG_EUR	,',
'            NETTO_BETRAG_EUR	,',
'            PREIS_PRO_MENGE	,',
'            MENGENEINHEIT	,',
'            LA_DATUM	,',
'            FK_LA_KONTO	,',
'            FK_LA_WDH	,',
'            FK_STD_INP_ZAHLUNGSSTATUS	,',
'            COMM_VERGEHEN	,',
'            VERG_BEHOERDE	,',
'            VERG_CNT_PUNKTE	,',
'            FK_BEL_BELEG_ABLAGE	,',
'            FK_ABL_ORDNER_PAGE	,',
'            VERG_CNT_PUNKTE_GESCHAETZT	,',
'            VERG_PUNKTE_VON	,',
'            VERG_PUNKTE_BIS	,',
'            FK_LOC_LOCATION_VERG	,',
'            FK_IMP_BA_BEL_OLD	,',
'            VERG_GESCHW_IST	,',
'            VERG_GESCHW_SOLL	,',
'            VERG_GESCHW_UEBER_GRZ	,',
'            VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL	,',
'            VERG_CODE_BUSSGELD	,',
'            VERG_DESCR_BUSSGELD	,',
'            GEZAHLT_AM	,',
'            WEBSEITE	,',
'            KUNDENNUMMER	,',
'            FK_REAL_BELEG_EXIST	,',
'            FK_CALC_STATE	,',
'            FK_CALC_STATE_EUR	,',
'            FK_CALC_STATE_FRMDW	,',
'            FK_STD_INP_STATUS	,',
'            DATUM_VERGEHEN	,',
'            CREATE_AT	,',
'            CREATE_BY	,',
'            MODIFY_AT	,',
'            MODIFY_BY	,',
'            DATUM_ORT_OK	,',
'            DATUM_ADDRESSE_OK	,',
'            DATUM_BUSSGELD_OK	,',
'            DATUM_BELEG_POS_OK	,',
'            DATUM_BUCHUNG_OK	,',
'            DATUM_VERPFL_BEL_OK	,',
'            FK_INT_INTERNET_APP	,',
'            FK_CONTR_DUPL_STATUS	,',
'            DATUM_DUPL_OK	,',
'            DUPL_BEMERKUNG	,',
'            FK_KON_GESCHAEFTSPARTNER	 ,',
'            DUMMY,',
'            STORNIERT,',
'            FK_ADR_ADRESSE_SCHNELL,',
'            FK_LEX_RELATION_SRC,',
'            FK_MAIN_KEY_SRC,',
'            FK_STD_CONTR_STATUS_KAT,',
'            FK_STD_CONTR_STATUS_VERW,',
'            DATUM_STATUS_VERW,',
'            DATUM_STATUS_KAT,',
'            VERG_DATUM_RECHTSKRAFT,',
'            VERG_DATUM_TILGUNG,',
'            VERG_NUMMER_FLENS,',
'            VERG_AKTENZEICHEN,',
'            VERG_TATBESTANDSNUMMER,',
'            FK_VER_VERTRAG',
'        Into',
'        :P373_FK_LEX_BUCHUNG_1,',
'        :P373_FK_bAS_KAT_KATEGORIE_1,',
'        :P373_FK_BAS_KAL_ARBEITSTAG_1,',
'        :P373_FK_KTO_BUCHUNG_1,',
'        :P373_FK_STD_KTO_ZAHLUNGSART_1,',
'        :P373_FK_STD_VERW_VERWENDUNGSZWECK_1,',
'        :P373_FK_INV_INVENTAR_1,',
'        :P373_FK_PROJ_PROJEKT_1,',
'        :P373_BELEGNUMMER_1,',
'        :P373_BEZEICHNUNG_1,',
'        :P373_FK_ADR_LAND_1,',
'        :P373_FK_ADR_CITY_1,',
'        :P373_BEL_DATUM_1,',
'        :P373_VON_1,',
'        :P373_BIS_1,',
'        :P373_NETTO_BETRAG_1,',
'        :P373_FK_BAS_STEU_STEUER_SATZ_1,',
'        :P373_MWST_BETRAG_1,',
'        :P373_BRUTTO_BETRAG_1,',
'        :P373_FK_BAS_MON_WAEHRUNG_1,',
'        :P373_STEUERNUMMER_1,',
'        :P373_FK_BAS_MON_UMRECHNUNGSKURS_1,',
'        :P373_COMM_REST_BELEG_1,',
'        :P373_COMM_TEL_BELEG_1,',
'        :P373_COMM_PRODUKTE_1,',
'        :P373_COMM_BEGRUENDUNG_1,',
'        :P373_COMM_SONSTIGES_1,',
'        :P373_BELEG_1,',
'        :P373_ZAHLUNGSBELEG_1,',
'        :P373_LITER_1,',
'        :P373_ZAPFSAEULE_1,',
'        :P373_FK_LOC_LOCATION_1,',
'        :P373_PERSOENLICH_VOR_ORT_1,',
'        :P373_BELEG_UHRZEIT_1,',
'        :P373_VON_UHRZEIT_1,',
'        :P373_BIS_UHRZEIT_1,',
'        :P373_FK_BAS_KAL_VON_ARBEITSTAG_1,',
'        :P373_FK_BAS_KAL_BIS_ARBEITSTAG_1,',
'        :P373_COMM_ADRESSE_1,',
'        :P373_TANKSTELLEN_NR_1,',
'        :P373_BRUTTO_BETRAG_INCL_TRINKG_1,',
'        :P373_COMM_PARKTICKET_1,',
'        :P373_FRMDW_NETTO_BETRAG_1,',
'        :P373_FK_BAS_MON_FRMDW_1,',
'        :P373_FK_BAS_MON_FRMDW_MWST_SATZ_1,',
'        :P373_FRMDW_MWST_BETRAG_1,',
'        :P373_FRMDW_BRUTTO_BETRAG_1,',
'        :P373_FRMDW_BRUTTO_INCL_TRINKG_1,',
'        :P373_MWST_BETRAG_EUR_1,',
'        :P373_BRUTTO_BETRAG_EUR_1,',
'        :P373_BRUTTO_INCL_TRINKG_EUR_1,',
'        :P373_NETTO_BETRAG_EUR_1,',
'        :P373_PREIS_PRO_MENGE_1,',
'        :P373_MENGENEINHEIT_1,',
'        :P373_LA_DATUM_1,',
'        :P373_FK_LA_KONTO_1,',
'        :P373_FK_LA_WDH_1,',
'        :P373_FK_STD_INP_ZAHLUNGSSTATUS_1,',
'        :P373_COMM_VERGEHEN_1,',
'        :P373_VERG_BEHOERDE_1,',
'        :P373_VERG_CNT_PUNKTE_1,',
'        :P373_FK_BEL_BELEG_ABLAGE_1,',
'        :P373_FK_ABL_ORDNER_PAGE_1,',
'        :P373_VERG_CNT_PUNKTE_GESCHAETZT_1,',
'        :P373_VERG_PUNKTE_VON_1,',
'        :P373_VERG_PUNKTE_BIS_1,',
'        :P373_FK_LOC_LOCATION_VERG_1,',
'        :P373_FK_IMP_BA_BEL_OLD_1,',
'        :P373_VERG_GESCHW_IST_1,',
'        :P373_VERG_GESCHW_SOLL_1,',
'        :P373_VERG_GESCHW_UEBER_GRZ_1,',
'        :P373_VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,',
'        :P373_VERG_CODE_BUSSGELD_1,',
'        :P373_VERG_DESCR_BUSSGELD_1,',
'        :P373_GEZAHLT_AM_1,',
'        :P373_WEBSEITE_1,',
'        :P373_KUNDENNUMMER_1,',
'        :P373_FK_REAL_BELEG_EXIST_1,',
'        :P373_FK_CALC_STATE_1,',
'        :P373_FK_CALC_STATE_EUR_1,',
'        :P373_FK_CALC_STATE_FRMDW_1,',
'        :P373_FK_STD_INP_STATUS_1,',
'        :P373_DATUM_VERGEHEN_1,',
'        :P373_CREATE_AT_1,',
'        :P373_CREATE_BY_1,',
'        :P373_MODIFY_AT_1,',
'        :P373_MODIFY_BY_1,',
'        :P373_DATUM_ORT_OK_1,',
'        :P373_DATUM_ADDRESSE_OK_1,',
'        :P373_DATUM_BUSSGELD_OK_1,',
'        :P373_DATUM_BELEG_POS_OK_1,',
'        :P373_DATUM_BUCHUNG_OK_1,',
'        :P373_DATUM_VERPFL_BEL_OK_1,',
'        :P373_FK_INT_INTERNET_APP_1,',
'        :P373_FK_CONTR_DUPL_STATUS_1,',
'        :P373_DATUM_DUPL_OK_1,',
'        :P373_DUPL_BEMERKUNG_1,',
'        :P373_FK_KON_GESCHAEFTSPARTNER_1,',
'        :P373_DUMMY,',
'        :P373_STORNIERT,',
'        :P373_FK_ADR_ADRESSE_SCHNELL,',
'        :P373_FK_LEX_RELATION_SRC_1,',
'        :P373_FK_MAIN_KEY_SRC,',
'        :P373_FK_STD_CONTR_STATUS_KAT,',
'        :P373_FK_STD_CONTR_STATUS_VERW,',
'        :P373_DATUM_STATUS_VERW,',
'        :P373_DATUM_STATUS_KAT,',
'        :P373_VERG_DATUM_RECHTSKRAFT,        ',
'        :P373_VERG_DATUM_TILGUNG,',
'        :P373_VERG_NUMMER_FLENS,',
'        :P373_VERG_AKTENZEICHEN,',
'        :P373_VERG_TATBESTANDSNUMMER,',
'        :P373_FK_VER_VERTRAG',
'from T_inp_belege_all ',
'  where Pk_inp_belege_all = :P373_PK_INP_BELEGE_ALL_1;',
'end if;',
'  ',
'',
'',
'end;'))
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17372034633528075)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(17300552212528027)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form_TRGT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14186341140489798)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Compare_SRC_TRGT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P373_PK_INP_BELEGE_ALL_1 is not null and :P373_PK_INP_BELEGE_ALL is not null then   --2 - Abgleich SRC-Beleg mit Ziel-Beleg',
'select',
'--fk_lex_buchung',
'case when nvl(:P373_FK_LEX_BUCHUNG,0) =  nvl(:P373_FK_LEX_BUCHUNG_1,0) and :P373_lex_buchung is not null then ''1:2''',
'when nvl(:P373_FK_LEX_BUCHUNG,0) =  nvl(:P373_FK_LEX_BUCHUNG_1,0) and :P373_lex_buchung is null then ''1''',
'when :P373_LEX_BUCHUNG is not null then ''0:2'' else ''0'' end,',
'--fk_kategorie',
'case when nvl(:P373_FK_KATEGORIE,0) =  nvl(:P373_FK_KATEGORIE_1,0) and :P373_fk_kategorie is not null then ''1:2''',
'when nvl(:P373_FK_kategorie,0) =  nvl(:P373_FK_kategorie_1,0) and :P373_fk_kategorie is null then ''1''',
'when :P373_fk_kateogrie is not null then ''0:2'' else ''0'' end,',
'--fk_arbeitstag',
'case when nvl(:P373_FK_arbeitstag,0) =  nvl(:P373_FK_arbeitstag_1,0) and :P373_FK_arbeitstag is not null then ''1:2''',
'when nvl(:P373_FK_arbeitstag,0) =  nvl(:P373_FK_arbeitstag_1,0) and :P373_FK_arbeitstag is null then ''1''',
'when :P373_FK_arbeitstag is not null then ''0:2'' else ''0'' end,',
'--fk_buchung',
'case when nvl(:P373_FK_buchung,0) =  nvl(:P373_FK_buchung_1,0) and :P373_FK_buchung is not null then ''1:2''',
'when nvl(:P373_FK_buchung,0) =  nvl(:P373_FK_buchung_1,0) and :P373_FK_buchung is null then ''1''',
'when :P373_FK_buchung is not null then ''0:2'' else ''0'' end,',
'--fk_zahlungsart',
'case when nvl(:P373_FK_zahlungsart,0) =  nvl(:P373_FK_zahlungsart_1,0) and :P373_FK_zahlungsart is not null then ''1:2''',
'when nvl(:P373_FK_zahlungsart,0) =  nvl(:P373_FK_zahlungsart_1,0) and :P373_FK_zahlungsart is null then ''1''',
'when :P373_FK_zahlungsart is not null then ''0:2''  else ''0'' end,',
'--fk_verwendungszweck',
'case when nvl(:P373_FK_verwendungszweck,0) =  nvl(:P373_FK_verwendungszweck_1,0) and :P373_FK_verwendungszweck is not null then ''1:2''',
'when nvl(:P373_FK_verwendungszweck,0) =  nvl(:P373_FK_verwendungszweck_1,0) and :P373_FK_verwendungszweck is null then ''1''',
'when :P373_FK_verwendungszweck is not null then ''0:2'' else ''0'' end,',
'--fk-inventar',
'case when nvl(:P373_FK_INVENTAR,0) = nvl(:P373_FK_INVENTAR_1,0) and :P373_FK_INVENTAR is not null then ''1:2''',
'when nvl(:P373_FK_INVENTAR,0) =  nvl(:P373_FK_INVENTAR_1,0) and :P373_FK_INVENTAR is null then ''1''',
'when :P373_FK_INVENTAR is not null then ''0:2'' else ''0'' end,',
'--fk_projekt',
'case when nvl(:P373_FK_PROJEKT,0) = nvl(:P373_FK_PROJEKT_1,0) and :P373_FK_PROJEKT is not null then ''1:2''',
'when nvl(:P373_FK_PROJEKT,0) =  nvl(:P373_FK_PROJEKT_1,0) and :P373_FK_PROJEKT is null then ''1''',
'when :P373_FK_PROJEKT is not null then ''0:2''  else ''0'' end,',
'--belegnummer',
'case when nvl(:P373_BELEGNUMMER,0) = nvl(:P373_BELEGNUMMER_1,0) and :P373_BELEGNUMMER is not null then ''1:2''',
'when nvl(:P373_BELEGNUMMER,0) =  nvl(:P373_BELEGNUMMER_1,0) and :P373_BELEGNUMMER is null then ''1''',
'when :P373_BELEGNUMMER is not null then ''0:2'' else ''0'' end,',
'--bezeichnung',
'case when nvl(:P373_BEZEICHNUNG,0) = nvl(:P373_BEZEICHNUNG_1,0) and :P373_BEZEICHNUNG is not null then ''1:2''',
'when nvl(:P373_BEZEICHNUNG,0) =  nvl(:P373_BEZEICHNUNG_1,0) and :P373_BEZEICHNUNG is null then ''1''',
'when :P373_BEZEICHNUNG is not null then ''0:2'' else ''0'' end,',
'--fk_land',
'case when nvl(:P373_FK_LAND,0) = nvl(:P373_FK_LAND_1,0) and :P373_FK_LAND is not null then ''1:2''',
'when nvl(:P373_FK_LAND,0) =  nvl(:P373_FK_LAND_1,0) and :P373_FK_LAND is null then ''1''',
'when :P373_FK_LAND is not null then ''0:2'' else ''0'' end,',
'--fk_city',
'case when nvl(:P373_FK_CITY,0) = nvl(:P373_FK_CITY_1,0) and :P373_FK_CITY is not null then ''1:2''',
'when nvl(:P373_FK_CITY,0) =  nvl(:P373_FK_CITY_1,0) and :P373_FK_CITY is null then ''1''',
'when :P373_FK_CITY is not null then ''0:2'' else ''0'' end,',
'--bel_datum',
'case when nvl(:P373_BEL_DATUM,0) = nvl(:P373_BEL_DATUM_1,0) and :P373_BEL_DATUM is not null then ''1:2''',
'when nvl(:P373_BEL_DATUM,0) =  nvl(:P373_BEL_DATUM_1,0) and :P373_BEL_DATUM is null then ''1''',
'when :P373_BEL_DATUM is not null then ''0:2'' else ''0'' end,',
'--von',
'case when nvl(:P373_VON,0) = nvl(:P373_VON_1,0) and :P373_VON is not null then ''1:2''',
'when nvl(:P373_VON,0) =  nvl(:P373_VON_1,0) and :P373_VON is null then ''1''',
'when :P373_VON is not null then ''0:2'' else ''0'' end,',
'--bis',
'case when nvl(:P373_BIS,0) = nvl(:P373_BIS_1,0)  and :P373_BIS is not null then ''1:2''',
'when nvl(:P373_BIS,0) =  nvl(:P373_BIS_1,0) and :P373_BIS is null then ''1''',
'when :P373_BIS is not null then ''0:2'' else ''0'' end,',
'--netto_betrag',
'case when nvl(:P373_NETTO_BETRAG,0) = nvl(:P373_NETTO_BETRAG_1,0)  and :P373_NETTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_NETTO_BETRAG,0) =  nvl(:P373_NETTO_BETRAG_1,0) and :P373_NETTO_BETRAG is null then ''1''',
'when :P373_NETTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_steuersatz',
'case when nvl(:P373_FK_STEUERSATZ,0) = nvl(:P373_FK_STEUERSATZ_1,0)  and :P373_FK_STEUERSATZ is not null then ''1:2''',
'when nvl(:P373_FK_STEUERSATZ,0) =  nvl(:P373_FK_STEUERSATZ_1,0) and :P373_FK_STEUERSATZ is null then ''1''',
'when :P373_FK_STEUERSATZ is not null then ''0:2''  else ''0'' end,',
'--mwst_betrag',
'case when nvl(:P373_MWST_BETRAG,0) = nvl(:P373_MWST_BETRAG_1,0)  and :P373_MWST_BETRAG is not null then ''1:2''',
'when nvl(:P373_MWST_BETRAG,0) =  nvl(:P373_MWST_BETRAG_1,0) and :P373_MWST_BETRAG is null then ''1''',
'when :P373_MWST_BETRAG is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag',
'case when nvl(:P373_BRUTTO_BETRAG,0) = nvl(:P373_BRUTTO_BETRAG_1,0) and :P373_BRUTTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG,0) =  nvl(:P373_BRUTTO_BETRAG_1,0) and :P373_BRUTTO_BETRAG is null then ''1''',
'when :P373_BRUTTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_waehrung',
'case when nvl(:P373_FK_WAEHRUNG,0) = nvl(:P373_FK_WAEHRUNG_1,0)  and :P373_FK_WAEHRUNG is not null then ''1:2''',
'when nvl(:P373_FK_WAEHRUNG,0) =  nvl(:P373_FK_WAEHRUNG_1,0) and :P373_FK_WAEHRUNG is null then ''1''',
'when :P373_FK_WAEHRUNG is not null then ''0:2'' else ''0'' end,',
'--steuernummer',
'case when nvl(:P373_STEUERNUMMER,0) = nvl(:P373_STEUERNUMMER_1,0)  and :P373_STEUERNUMMER is not null then ''1:2''',
'when nvl(:P373_STEUERNUMMER,0) =  nvl(:P373_STEUERNUMMER_1,0) and :P373_STEUERNUMMER is null then ''1''',
'when :P373_STEUERNUMMER is not null then ''0:2'' else ''0'' end,',
'--fk_umrechnungskurs',
'case when nvl(:P373_FK_UMRECHNUNGSKURS,0) = nvl(:P373_FK_UMRECHNUNGSKURS_1,0)  and :P373_FK_UMRECHNUNGSKURS is not null then ''1:2''',
'when nvl(:P373_FK_UMRECHNUNGSKURS,0) =  nvl(:P373_FK_UMRECHNUNGSKURS_1,0) and :P373_FK_UMRECHNUNGSKURS is null then ''1''',
'when :P373_FK_UMRECHNUNGSKURS is not null then ''0:2'' else ''0'' end,',
'--comm_rest_beleg',
'case when nvl(:P373_COMM_REST_BELEG,0) = nvl(:P373_COMM_REST_BELEG_1,0) and :P373_COMM_REST_BELEG is not null then ''1:2''',
'when nvl(:P373_COMM_REST_BELEG,0) =  nvl(:P373_COMM_REST_BELEG_1,0) and :P373_COMM_REST_BELEG is null then ''1''',
'when :P373_COMM_REST_BELEG is not null then ''0:2'' else ''0'' end,',
'--comm_tel_beleg',
'case when nvl(:P373_COMM_TEL_BELEG,0) = nvl(:P373_COMM_TEL_BELEG_1,0)  and :P373_COMM_TEL_BELEG is not null then ''1:2''',
'when nvl(:P373_COMM_TEL_BELEG,0) =  nvl(:P373_COMM_TEL_BELEG_1,0) and :P373_COMM_TEL_BELEG is null then ''1''',
'when :P373_COMM_TEL_BELEG is not null then ''0:2'' else ''0'' end,',
'--comm_produkte',
'case when nvl(:P373_COMM_PRODUKTE,0) = nvl(:P373_COMM_PRODUKTE_1,0)  and :P373_COMM_PRODUKTE is not null then ''1:2''',
'when nvl(:P373_COMM_PRODUKTE,0) =  nvl(:P373_COMM_PRODUKTE_1,0) and :P373_COMM_PRODUKTE is null then ''1''',
'when :P373_COMM_PRODUKTE is not null then ''0:2'' else ''0'' end,',
unistr('--comm_begr\00FCndung'),
'case when nvl(:P373_COMM_BEGRUENDUNG,0) = nvl(:P373_COMM_BEGRUENDUNG_1,0)  and :P373_COMM_BEGRUENDUNG is not null then ''1:2''',
'when nvl(:P373_COMM_BEGRUENDUNG,0) =  nvl(:P373_COMM_BEGRUENDUNG_1,0) and :P373_COMM_BEGRUENDUNG is null then ''1''',
'when :P373_COMM_BEGRUENDUNG is not null then ''0:2'' else ''0'' end,',
'--comm_sonstiges',
'case when nvl(:P373_COMM_SONSTIGES,0) = nvl(:P373_COMM_SONSTIGES_1,0)  and :P373_COMM_SONSTIGES is not null then ''1:2''',
'when nvl(:P373_COMM_SONSTIGES,0) =  nvl(:P373_COMM_SONSTIGES_1,0) and :P373_COMM_SONSTIGES is null then ''1''',
'when :P373_COMM_SONSTIGES is not null then ''0:2'' else ''0'' end,',
'--beleg',
'case when nvl(:P373_BELEG,0) = nvl(:P373_BELEG_1,0)  and :P373_BELEG is not null then ''1:2''',
'when nvl(:P373_BELEG,0) =  nvl(:P373_BELEG_1,0) and :P373_BELEG is null then ''1''',
'when :P373_BELEG is not null then ''0:2'' else ''0'' end,',
'--zahlungsbeleg',
'case when nvl(:P373_ZAHLUNGSBELEG,0) = nvl(:P373_ZAHLUNGSBELEG_1,0)  and :P373_ZAHLUNGSBELEG is not null then ''1:2''',
'when nvl(:P373_ZAHLUNGSBELEG,0) =  nvl(:P373_ZAHLUNGSBELEG_1,0) and :P373_ZAHLUNGSBELEG is null then ''1''',
'when :P373_ZAHLUNGSBELEG is not null then ''0:2'' else ''0'' end,',
'--liter',
'case when nvl(:P373_LITER,0) = nvl(:P373_LITER_1,0) and :P373_LITER is not null then ''1:2''',
'when nvl(:P373_LITER,0) =  nvl(:P373_LITER_1,0) and :P373_LITER is null then ''1''',
'when :P373_LITER is not null then ''0:2'' else ''0'' end,',
unistr('--zapfs\00F6ule'),
'case when nvl(:P373_ZAPFSAEULE,0) = nvl(:P373_ZAPFSAEULE_1,0)  and :P373_ZAPFSAEULE is not null then ''1:2''',
'when nvl(:P373_ZAPFSAEULE,0) =  nvl(:P373_ZAPFSAEULE_1,0) and :P373_ZAPFSAEULE is null then ''1''',
'when :P373_ZAPFSAEULE is not null then ''0:2'' else ''0'' end,',
'--fk-location',
'case when nvl(:P373_FK_LOCATION,0) = nvl(:P373_FK_LOCATION_1,0)  and :P373_FK_LOCATION is not null then ''1:2''',
'when nvl(:P373_FK_LOCATION,0) =  nvl(:P373_FK_LOCATION_1,0) and :P373_FK_LOCATION is null then ''1''',
'when :P373_FK_LOCATION is not null then ''0:2'' else ''0'' end,',
unistr('--pers\00F6nlich_vor_ort'),
'case when nvl(:P373_PERSOENLICH_VOR_ORT,0) = nvl(:P373_PERSOENLICH_VOR_ORT_1,0)  and :P373_PERSOENLICH_VOR_ORT is not null then ''1:2''',
'when nvl(:P373_PERSOENLICH_VOR_ORT,0) =  nvl(:P373_PERSOENLICH_VOR_ORT_1,0) and :P373_PERSOENLICH_VOR_ORT is null then ''1''',
'when :P373_PERSOENLICH_VOR_ORT is not null then ''0:2'' else ''0'' end,',
'--beleg_uhrzeit',
' case when nvl(:P373_BELEG_UHRZEIT,0) = nvl(:P373_BELEG_UHRZEIT_1,0)  and :P373_BELEG_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_BELEG_UHRZEIT,0) =  nvl(:P373_BELEG_UHRZEIT_1,0) and :P373_BELEG_UHRZEIT is null then ''1''',
'when :P373_BELEG_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--von_uhrzeit',
'case when nvl(:P373_VON_UHRZEIT,0) = nvl(:P373_VON_UHRZEIT_1,0)  and :P373_VON_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_VON_UHRZEIT,0) =  nvl(:P373_VON_UHRZEIT_1,0) and :P373_VON_UHRZEIT is null then ''1''',
'when :P373_VON_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--bis_uhrzeit',
'case when nvl(:P373_BIS_UHRZEIT,0) = nvl(:P373_BIS_UHRZEIT_1,0)  and :P373_BIS_UHRZEIT is not null then ''1:2''',
'when nvl(:P373_BIS_UHRZEIT,0) =  nvl(:P373_BIS_UHRZEIT_1,0) and :P373_BIS_UHRZEIT is null then ''1''',
'when :P373_BIS_UHRZEIT is not null then ''0:2'' else ''0'' end,',
'--fk_von_arbeitstag',
'case when nvl(:P373_FK_VON_ARBEITSTAG,0) = nvl(:P373_FK_VON_ARBEITSTAG_1,0) and :P373_FK_VON_ARBEITSTAG is not null then ''1:2''',
'when nvl(:P373_FK_VON_ARBEITSTAG,0) =  nvl(:P373_FK_VON_ARBEITSTAG_1,0) and :P373_FK_VON_ARBEITSTAG is null then ''1''',
'when :P373_FK_VON_ARBEITSTAG is not null then ''0:2'' else ''0'' end,',
'--fk_bis_arbeitstag',
'case when nvl(:P373_FK_BIS_ARBEITSTAG,0) = nvl(:P373_FK_BIS_ARBEITSTAG_1,0) and :P373_FK_BIS_ARBEITSTAG is not null then ''1:2''',
'when nvl(:P373_FK_BIS_ARBEITSTAG,0) =  nvl(:P373_FK_BIS_ARBEITSTAG_1,0) and :P373_FK_BIS_ARBEITSTAG is null then ''1''',
'when :P373_FK_BIS_ARBEITSTAG is not null then ''0:2'' else ''0'' end,',
'--comm_addresse',
'case when nvl(:P373_COMM_ADRESSE,0) = nvl(:P373_COMM_ADRESSE_1,0)  and :P373_COMM_ADRESSE is not null then ''1:2''',
'when nvl(:P373_COMM_ADRESSE,0) =  nvl(:P373_COMM_ADRESSE_1,0) and :P373_COMM_ADRESSE is null then ''1''',
'when :P373_COMM_ADRESSE is not null then ''0:2'' else ''0'' end,',
'--tankstelllen_nr',
'case when nvl(:P373_TANKSTELLEN_NR,0) = nvl(:P373_TANKSTELLEN_NR_1,0)  and :P373_TANKSTELLEN_NR is not null then ''1:2''',
'when nvl(:P373_TANKSTELLEN_NR,0) =  nvl(:P373_TANKSTELLEN_NR_1,0) and :P373_TANKSTELLEN_NR is null then ''1''',
'when :P373_TANKSTELLEN_NR is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag_incl_trinkg',
'case when nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG,0) = nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG_1,0) and :P373_BRUTTO_BETRAG_INCL_TRINKG is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG,0) =  nvl(:P373_BRUTTO_BETRAG_INCL_TRINKG_1,0) and :P373_BRUTTO_BETRAG_INCL_TRINKG is null then ''1''',
'when :P373_BRUTTO_BETRAG_INCL_TRINKG is not null then ''0:2'' else ''0'' end,',
'--comm_parkticket',
'case when nvl(:P373_COMM_PARKTICKET,0) = nvl(:P373_COMM_PARKTICKET_1,0)  and :P373_COMM_PARKTICKET is not null then ''1:2''',
'when nvl(:P373_COMM_PARKTICKET,0) =  nvl(:P373_COMM_PARKTICKET_1,0) and :P373_COMM_PARKTICKET is null then ''1''',
'when :P373_COMM_PARKTICKET is not null then ''0:2'' else ''0'' end,',
'--frmdw_netto_betrag',
'case when nvl(:P373_FRMDW_NETTO_BETRAG,0) = nvl(:P373_FRMDW_NETTO_BETRAG_1,0)  and :P373_FRMDW_NETTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_NETTO_BETRAG,0) =  nvl(:P373_FRMDW_NETTO_BETRAG_1,0) and :P373_FRMDW_NETTO_BETRAG is null then ''1''',
'when :P373_FRMDW_NETTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--fk_frmdw',
'case when nvl(:P373_FK_FRMDW,0) = nvl(:P373_FK_FRMDW_1,0)  and :P373_FK_FRMDW is not null then ''1:2''',
'when nvl(:P373_FK_FRMDW,0) =  nvl(:P373_FK_FRMDW_1,0) and :P373_FK_FRMDW is null then ''1''',
'when :P373_FK_FRMDW is not null then ''0:2'' else ''0'' end,',
'---fk_frmdw_mwst_satz',
'case when nvl(:P373_FK_FRMDW_MWST_SATZ,0) = nvl(:P373_FK_FRMDW_MWST_SATZ_1,0)  and :P373_FK_FRMDW_MWST_SATZ is not null then ''1:2''',
'when nvl(:P373_FK_FRMDW_MWST_SATZ,0) =  nvl(:P373_FK_FRMDW_MWST_SATZ_1,0) and :P373_FK_FRMDW_MWST_SATZ is null then ''1''',
'when :P373_FK_FRMDW_MWST_SATZ is not null then ''0:2'' else ''0'' end,',
'--frmdw_mwst_betrag',
'case when nvl(:P373_FRMDW_MWST_BETRAG,0) = nvl(:P373_FRMDW_MWST_BETRAG_1,0)  and :P373_FRMDW_MWST_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_MWST_BETRAG,0) =  nvl(:P373_FRMDW_MWST_BETRAG_1,0) and :P373_FRMDW_MWST_BETRAG is null then ''1''',
'when :P373_FRMDW_MWST_BETRAG is not null then ''0:2'' else ''0'' end,',
'--frmdw_brutto_betrag',
'case when nvl(:P373_FRMDW_BRUTTO_BETRAG,0) = nvl(:P373_FRMDW_BRUTTO_BETRAG_1,0)   and :P373_FRMDW_BRUTTO_BETRAG is not null then ''1:2''',
'when nvl(:P373_FRMDW_BRUTTO_BETRAG,0) =  nvl(:P373_FRMDW_BRUTTO_BETRAG_1,0) and :P373_FRMDW_BRUTTO_BETRAG is null then ''1''',
'when :P373_FRMDW_BRUTTO_BETRAG is not null then ''0:2'' else ''0'' end,',
'--frmdw_brutto_inkl_trinkg',
'case when nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG,0) = nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG_1,0)   and :P373_FRMDW_BRUTTO_INCL_TRINKG is not null then ''1:2''',
'when nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG,0) =  nvl(:P373_FRMDW_BRUTTO_INCL_TRINKG_1,0) and :P373_FRMDW_BRUTTO_INCL_TRINKG is null then ''1''',
'when :P373_FRMDW_BRUTTO_INCL_TRINKG is not null then ''0:2'' else ''0'' end,',
'--mwst_betrag_eur',
'case when nvl(:P373_MWST_BETRAG_EUR,0) = nvl(:P373_MWST_BETRAG_EUR_1,0)  and :P373_MWST_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_MWST_BETRAG_EUR,0) =  nvl(:P373_MWST_BETRAG_EUR_1,0) and :P373_MWST_BETRAG_EUR is null then ''1''',
'when :P373_MWST_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'--brutto_betrag_eur',
'case when nvl(:P373_BRUTTO_BETRAG_EUR,0) = nvl(:P373_BRUTTO_BETRAG_EUR_1,0)   and :P373_BRUTTO_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_BRUTTO_BETRAG_EUR,0) =  nvl(:P373_BRUTTO_BETRAG_EUR_1,0) and :P373_BRUTTO_BETRAG_EUR is null then ''1''',
'when :P373_BRUTTO_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'---brutto_inkl_trink_eur',
'case when nvl(:P373_BRUTTO_INCL_TRINKG_EUR,0) = nvl(:P373_BRUTTO_INCL_TRINKG_EUR_1,0)   and :P373_BRUTTO_INCL_TRINKG_EUR is not null then ''1:2''',
'when nvl(:P373_BRUTTO_INCL_TRINKG_EUR,0) =  nvl(:P373_BRUTTO_INCL_TRINKG_EUR_1,0) and :P373_BRUTTO_INCL_TRINKG_EUR is null then ''1''',
'when :P373_BRUTTO_INCL_TRINKG_EUR is not null then ''0:2'' else ''0'' end,',
'--netto_betrag_eur',
'case when nvl(:P373_NETTO_BETRAG_EUR,0) = nvl(:P373_NETTO_BETRAG_EUR_1,0)   and :P373_NETTO_BETRAG_EUR is not null then ''1:2''',
'when nvl(:P373_NETTO_BETRAG_EUR,0) =  nvl(:P373_NETTO_BETRAG_EUR_1,0) and :P373_NETTO_BETRAG_EUR is null then ''1''',
'when :P373_NETTO_BETRAG_EUR is not null then ''0:2'' else ''0'' end,',
'--preis_pro_menge',
'case when nvl(:P373_PREIS_PRO_MENGE,0) = nvl(:P373_PREIS_PRO_MENGE_1,0)  and :P373_PREIS_PRO_MENGE is not null then ''1:2''',
'when nvl(:P373_PREIS_PRO_MENGE,0) =  nvl(:P373_PREIS_PRO_MENGE_1,0) and :P373_PREIS_PRO_MENGE is null then ''1''',
'when :P373_PREIS_PRO_MENGE is not null then ''0:2'' else ''0'' end,',
'--mengeneinheit',
'case when nvl(:P373_MENGENEINHEIT,0) = nvl(:P373_MENGENEINHEIT_1,0)   and :P373_MENGENEINHEIT is not null then ''1:2''',
'when nvl(:P373_MENGENEINHEIT,0) =  nvl(:P373_MENGENEINHEIT_1,0) and :P373_MENGENEINHEIT is null then ''1''',
'when :P373_MENGENEINHEIT is not null then ''0:2'' else ''0'' end,',
'--la_datum',
'case when nvl(:P373_LA_DATUM,0) = nvl(:P373_LA_DATUM_1,0)   and :P373_LA_DATUM is not null then ''1:2''',
'when nvl(:P373_LA_DATUM,0) =  nvl(:P373_LA_DATUM_1,0) and :P373_LA_DATUM is null then ''1''',
'when :P373_LA_DATUM is not null then ''0:2'' else ''0'' end,',
'--fk_la_konto',
'case when nvl(:P373_FK_LA_KONTO,0) = nvl(:P373_FK_LA_KONTO_1,0)  and :P373_FK_LA_KONTO is not null then ''1:2''',
'when nvl(:P373_FK_LA_KONTO,0) =  nvl(:P373_FK_LA_KONTO_1,0) and :P373_FK_LA_KONTO is null then ''1''',
'when :P373_FK_LA_KONTO is not null then ''0:2'' else ''0'' end,',
'--fk_la_wdh',
'case when nvl(:P373_FK_LA_WDH,0) = nvl(:P373_FK_LA_WDH_1,0)   and :P373_FK_LA_WDH is not null then ''1:2''',
'when nvl(:P373_FK_LA_WDH,0) =  nvl(:P373_FK_LA_WDH_1,0) and :P373_FK_LA_WDH is null then ''1''',
'when :P373_FK_LA_WDH is not null then ''0:2'' else ''0'' end,',
'--fk_zahlstatus',
'case when nvl(:P373_FK_ZAHLSTATUS,0) = nvl(:P373_FK_ZAHLSTATUS_1,0)  and :P373_FK_ZAHLSTATUS is not null then ''1:2''',
'when nvl(:P373_FK_ZAHLSTATUS,0) =  nvl(:P373_FK_ZAHLSTATUS_1,0) and :P373_FK_ZAHLSTATUS is null then ''1''',
'when :P373_FK_ZAHLSTATUS is not null then ''0:2'' else ''0'' end,',
'--comm_vergehen',
'case when nvl(:P373_COMM_VERGEHEN,0) = nvl(:P373_COMM_VERGEHEN_1,0)   and :P373_COMM_VERGEHEN is not null then ''1:2''',
'when nvl(:P373_COMM_VERGEHEN,0) =  nvl(:P373_COMM_VERGEHEN_1,0) and :P373_COMM_VERGEHEN is null then ''1''',
'when :P373_COMM_VERGEHEN is not null then ''0:2'' else ''0'' end,',
unistr('--verg_beh\00F6rden'),
'case when nvl(:P373_VERG_BEHOERDE,0) = nvl(:P373_VERG_BEHOERDE_1,0)   and :P373_VERG_BEHOERDE is not null then ''1:2''',
'when nvl(:P373_VERG_BEHOERDE,0) =  nvl(:P373_VERG_BEHOERDE_1,0) and :P373_VERG_BEHOERDE is null then ''1''',
'when :P373_VERG_BEHOERDE is not null then ''0:2'' else ''0'' end,',
'--cnt_punkte',
'case when nvl(:P373_CNT_PUNKTE,0) = nvl(:P373_CNT_PUNKTE_1,0)   and :P373_CNT_PUNKTE is not null then ''1:2''',
'when nvl(:P373_CNT_PUNKTE,0) =  nvl(:P373_CNT_PUNKTE_1,0) and :P373_CNT_PUNKTE is null then ''1''',
'when :P373_CNT_PUNKTE is not null then ''0:2'' else ''0'' end,',
'--fk_belege_ablage',
'case when nvl(:P373_FK_BELEG_ABLAGE,0) = nvl(:P373_FK_BELEG_ABLAGE_1,0)   and :P373_FK_BELEG_ABLAGE is not null then ''1:2''',
'when nvl(:P373_FK_BELEG_ABLAGE,0) =  nvl(:P373_FK_BELEG_ABLAGE_1,0) and :P373_FK_BELEG_ABLAGE is null then ''1''',
'when :P373_FK_BELEG_ABLAGE is not null then ''0:2'' else ''0'' end,',
'--fk_abl_ordner_page',
'case when nvl(:P373_FK_ABL_ORDNER_PAGE,0) = nvl(:P373_FK_ABL_ORDNER_PAGE_1,0)   and :P373_FK_ABL_ORDNER_PAGE is not null then ''1:2''',
'when nvl(:P373_FK_ABL_ORDNER_PAGE,0) =  nvl(:P373_FK_ABL_ORDNER_PAGE_1,0) and :P373_FK_ABL_ORDNER_PAGE is null then ''1''',
'when :P373_FK_ABL_ORDNER_PAGE is not null then ''0:2'' else ''0'' end,',
'--cnt_punkte_gescchaetzt',
'case when nvl(:P373_CNT_PUNKTE_GESCHAETZT,0) = nvl(:P373_CNT_PUNKTE_GESCHAETZT_1,0)   and :P373_CNT_PUNKTE_GESCHAETZT is not null then ''1:2''',
'when nvl(:P373_CNT_PUNKTE_GESCHAETZT,0) =  nvl(:P373_CNT_PUNKTE_GESCHAETZT_1,0) and :P373_CNT_PUNKTE_GESCHAETZT is null then ''1''',
'when :P373_CNT_PUNKTE_GESCHAETZT is not null then ''0:2'' else ''0'' end,',
'--punkte_von',
'case when nvl(:P373_PUNKTE_VON,0) = nvl(:P373_PUNKTE_VON_1,0)   and :P373_PUNKTE_VON is not null then ''1:2''',
'when nvl(:P373_PUNKTE_VON,0) =  nvl(:P373_PUNKTE_VON_1,0) and :P373_PUNKTE_VON is null then ''1''',
'when :P373_PUNKTE_VON is not null then ''0:2'' else ''0'' end,',
'--punkte_bis',
'case when nvl(:P373_PUNKTE_BIS,0) = nvl(:P373_PUNKTE_BIS_1,0)   and :P373_PUNKTE_BIS is not null then ''1:2''',
'when nvl(:P373_PUNKTE_BIS,0) =  nvl(:P373_PUNKTE_BIS_1,0) and :P373_PUNKTE_BIS is null then ''1''',
'when :P373_PUNKTE_BIS is not null then ''0:2'' else ''0'' end,',
'--fk_location_verg',
'case when nvl(:P373_FK_LOCATION_VERG,0) = nvl(:P373_FK_LOCATION_VERG_1,0)   and :P373_FK_LOCATION_VERG is not null then ''1:2''',
'when nvl(:P373_FK_LOCATION_VERG,0) =  nvl(:P373_FK_LOCATION_VERG_1,0) and :P373_FK_LOCATION_VERG is null then ''1''',
'when :P373_FK_LOCATION_VERG is not null then ''0:2'' else ''0'' end,',
'--fk_inp_bel_old',
'case when nvl(:P373_FK_IMP_BA_BEL_OLD,0) = nvl(:P373_FK_IMP_BA_BEL_OLD_1,0)   and :P373_FK_IMP_BA_BEL_OLD is not null then ''1:2''',
'when nvl(:P373_FK_IMP_BA_BEL_OLD,0) =  nvl(:P373_FK_IMP_BA_BEL_OLD_1,0) and :P373_FK_IMP_BA_BEL_OLD is null then ''1''',
'when :P373_FK_IMP_BA_BEL_OLD is not null then ''0:2'' else ''0'' end,',
'--geschw_ist',
'case when nvl(:P373_GESCHW_IST,0) = nvl(:P373_GESCHW_IST_1,0)   and :P373_GESCHW_IST is not null then ''1:2''',
'when nvl(:P373_GESCHW_IST,0) =  nvl(:P373_GESCHW_IST_1,0) and :P373_GESCHW_IST is null then ''1''',
'when :P373_GESCHW_IST is not null then ''0:2'' else ''0'' end,',
'--geschw_soll',
'case when nvl(:P373_GESCHW_SOLL,0) = nvl(:P373_GESCHW_SOLL_1,0)  and :P373_GESCHW_SOLL is not null then ''1:2''',
'when nvl(:P373_GESCHW_SOLL,0) =  nvl(:P373_GESCHW_SOLL_1,0) and :P373_GESCHW_SOLL is null then ''1''',
'when :P373_GESCHW_SOLL is not null then ''0:2'' else ''0'' end,',
'--geschw_ueber_grz',
'case when nvl(:P373_GESCHW_UEBER_GRZ,0) = nvl(:P373_GESCHW_UEBER_GRZ_1,0)   and :P373_GESCHW_UEBER_GRZ is not null then ''1:2''',
'when nvl(:P373_GESCHW_UEBER_GRZ,0) =  nvl(:P373_GESCHW_UEBER_GRZ_1,0) and :P373_GESCHW_UEBER_GRZ is null then ''1''',
'when :P373_GESCHW_UEBER_GRZ is not null then ''0:2'' else ''0'' end,',
'--geschw_ueber_grz_abzgl_messstol',
'case when nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,0) = nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,0)   and :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is not null then ''1:2''',
'when nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL,0) =  nvl(:P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_1,0) and :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is null then ''1''',
'when :P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL is not null then ''0:2'' else ''0'' end,',
'--code-bussgeld',
'case when nvl(:P373_CODE_BUSSGELD,0) = nvl(:P373_CODE_BUSSGELD_1,0)   and :P373_CODE_BUSSGELD is not null then ''1:2''',
'when nvl(:P373_CODE_BUSSGELD,0) =  nvl(:P373_CODE_BUSSGELD_1,0) and :P373_CODE_BUSSGELD is null then ''1''',
'when :P373_CODE_BUSSGELD is not null then ''0:2'' else ''0'' end,',
'---descr_bussgeld',
'case when nvl(:P373_DESCR_BUSSGELD,0) = nvl(:P373_DESCR_BUSSGELD_1,0)  and :P373_DESCR_BUSSGELD is not null then ''1:2''',
'when nvl(:P373_DESCR_BUSSGELD,0) =  nvl(:P373_DESCR_BUSSGELD_1,0) and :P373_DESCR_BUSSGELD is null then ''1''',
'when :P373_DESCR_BUSSGELD is not null then ''0:2'' else ''0'' end,',
'--gezahlt_am',
'case when nvl(:P373_GEZAHLT_AM,0) = nvl(:P373_GEZAHLT_AM_1,0)   and :P373_GEZAHLT_AM is not null then ''1:2''',
'when nvl(:P373_GEZAHLT_AM,0) =  nvl(:P373_GEZAHLT_AM_1,0) and :P373_GEZAHLT_AM is null then ''1''',
'when :P373_GEZAHLT_AM is not null then ''0:2'' else ''0'' end,',
'--webseite',
'case when nvl(:P373_WEBSEITE,0) = nvl(:P373_WEBSEITE_1,0)   and :P373_WEBSEITE is not null then ''1:2''',
'when nvl(:P373_WEBSEITE,0) =  nvl(:P373_WEBSEITE_1,0) and :P373_WEBSEITE is null then ''1''',
'when :P373_WEBSEITE is not null then ''0:2'' else ''0'' end,',
'--kundennummer',
'case when nvl(:P373_KUNDENNUMMER,0) = nvl(:P373_KUNDENNUMMER_1,0)   and :P373_KUNDENNUMMER is not null then ''1:2''',
'when nvl(:P373_KUNDENNUMMER,0) =  nvl(:P373_KUNDENNUMMER_1,0) and :P373_KUNDENNUMMER is null then ''1''',
'when :P373_KUNDENNUMMER is not null then ''0:2'' else ''0'' end,',
'--fk_real_beleg_exist',
'case when nvl(:P373_FK_REAL_BELEG_EXIST,0) = nvl(:P373_FK_REAL_BELEG_EXIST_1,0)   and :P373_FK_REAL_BELEG_EXIST is not null then ''1:2''',
'when nvl(:P373_FK_REAL_BELEG_EXIST,0) =  nvl(:P373_FK_REAL_BELEG_EXIST_1,0) and :P373_FK_REAL_BELEG_EXIST is null then ''1''',
'when :P373_FK_REAL_BELEG_EXIST is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state',
'case when nvl(:P373_FK_CALC_STATE,0) = nvl(:P373_FK_CALC_STATE_1,0)   and :P373_FK_CALC_STATE is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE,0) =  nvl(:P373_FK_CALC_STATE_1,0) and :P373_FK_CALC_STATE is null then ''1''',
'when :P373_FK_CALC_STATE is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state_eur',
'case when nvl(:P373_FK_CALC_STATE_EUR,0) = nvl(:P373_FK_CALC_STATE_EUR_1,0)   and :P373_FK_CALC_STATE_EUR is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE_EUR,0) =  nvl(:P373_FK_CALC_STATE_EUR_1,0) and :P373_FK_CALC_STATE_EUR is null then ''1''',
'when :P373_FK_CALC_STATE_EUR is not null then ''0:2'' else ''0'' end,',
'--fk_calc_state_frmdw',
'case when nvl(:P373_FK_CALC_STATE_FRMDW,0) = nvl(:P373_FK_CALC_STATE_FRMDW_1,0)   and :P373_FK_CALC_STATE_FRMDW is not null then ''1:2''',
'when nvl(:P373_FK_CALC_STATE_FRMDW,0) =  nvl(:P373_FK_CALC_STATE_FRMDW_1,0) and :P373_FK_CALC_STATE_FRMDW is null then ''1''',
'when :P373_FK_CALC_STATE_FRMDW is not null then ''0:2'' else ''0'' end,',
'--fk_status',
'case when nvl(:P373_FK_STATUS,0) = nvl(:P373_FK_STATUS_1,0)   and :P373_FK_STATUS is not null then ''1:2''',
'when nvl(:P373_FK_STATUS,0) =  nvl(:P373_FK_STATUS_1,0) and :P373_FK_STATUS is null then ''1''',
'when :P373_FK_STATUS is not null then ''0:2'' else ''0'' end,',
'---datum_vergehen',
'case when nvl(:P373_DATUM_VERGEHEN,0) = nvl(:P373_DATUM_VERGEHEN_1,0)   and :P373_DATUM_VERGEHEN is not null then ''1:2''',
'when nvl(:P373_DATUM_VERGEHEN,0) =  nvl(:P373_DATUM_VERGEHEN_1,0) and :P373_DATUM_VERGEHEN is null then ''1''',
'when :P373_DATUM_VERGEHEN is not null then ''0:2'' else ''0'' end,',
'--create_at',
'case when nvl(:P373_CREATE_AT,0) = nvl(:P373_CREATE_AT_1,0)   and :P373_CREATE_AT is not null then ''1:2''',
'when nvl(:P373_CREATE_AT,0) =  nvl(:P373_CREATE_AT_1,0) and :P373_CREATE_AT is null then ''1''',
'when :P373_CREATE_AT is not null then ''0:2'' else ''0'' end,',
'--create_by',
'case when nvl(:P373_CREATE_BY,0) = nvl(:P373_CREATE_BY_1,0)   and :P373_CREATE_BY is not null then ''1:2''',
'when nvl(:P373_CREATE_BY,0) =  nvl(:P373_CREATE_BY_1,0) and :P373_CREATE_BY is null then ''1''',
'when :P373_CREATE_BY is not null then ''0:2'' else ''0'' end,',
'--modify_at',
'case when nvl(:P373_MODIFY_AT,0) = nvl(:P373_MODIFY_AT_1,0)   and :P373_MODIFY_AT is not null then ''1:2''',
'when nvl(:P373_MODIFY_AT,0) =  nvl(:P373_MODIFY_AT_1,0) and :P373_MODIFY_AT is null then ''1''',
'when :P373_MODIFY_AT is not null then ''0:2'' else ''0'' end,',
'--modify_by',
'case when nvl(:P373_MODIFY_BY,0) = nvl(:P373_MODIFY_BY_1,0)   and :P373_MODIFY_BY is not null then ''1:2''',
'when nvl(:P373_MODIFY_BY,0) =  nvl(:P373_MODIFY_BY_1,0) and :P373_MODIFY_BY is null then ''1''',
'when :P373_MODIFY_BY is not null then ''0:2'' else ''0'' end,',
'--datum_ort_ok',
'case when nvl(:P373_DATUM_ORT_OK,0) = nvl(:P373_DATUM_ORT_OK_1,0)  and :P373_DATUM_ORT_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_ORT_OK,0) =  nvl(:P373_DATUM_ORT_OK_1,0) and :P373_DATUM_ORT_OK is null then ''1''',
'when :P373_DATUM_ORT_OK is not null then ''0:2'' else ''0'' end,',
'--datum_addresse_ok',
'case when nvl(:P373_DATUM_ADDRESSE_OK,''01.01.1900'') = nvl(:P373_DATUM_ADDRESSE_OK_1,''01.01.1900'')   and :P373_DATUM_ADDRESSE_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_ADDRESSE_OK,0) =  nvl(:P373_DATUM_ADDRESSE_OK_1,0) and :P373_DATUM_ADDRESSE_OK is null then ''1''',
'when :P373_DATUM_ADDRESSE_OK is not null then ''0:2'' else ''0'' end,',
'--datum_bussgeld_ok',
'case when nvl(:P373_DATUM_BUSSGELD_OK,''01.01.1900'') = nvl(:P373_DATUM_BUSSGELD_OK_1,''01.01.1900'')   and :P373_DATUM_BUSSGELD_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BUSSGELD_OK,0) =  nvl(:P373_DATUM_BUSSGELD_OK_1,0) and :P373_DATUM_BUSSGELD_OK is null then ''1''',
'when :P373_DATUM_BUSSGELD_OK is not null then ''0:2'' else ''0'' end,',
'--datum_beleg_pos_ok',
'case when nvl(:P373_DATUM_BELEG_POS_OK,''01.01.1900'') = nvl(:P373_DATUM_BELEG_POS_OK_1,''01.01.1900'')   and :P373_DATUM_BELEG_POS_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BELEG_POS_OK,0) =  nvl(:P373_DATUM_BELEG_POS_OK_1,0) and :P373_DATUM_BELEG_POS_OK is null then ''1''',
'when :P373_DATUM_BELEG_POS_OK is not null then ''0:2'' else ''0'' end,',
'--datum_buchung_ok',
'case when nvl(:P373_DATUM_BUCHUNG_OK,''01.01.1900'') = nvl(:P373_DATUM_BUCHUNG_OK_1,''01.01.1900'')   and :P373_DATUM_BUCHUNG_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_BUCHUNG_OK,0) =  nvl(:P373_DATUM_BUCHUNG_OK_1,0) and :P373_DATUM_BUCHUNG_OK is null then ''1''',
'when :P373_DATUM_BUCHUNG_OK is not null then ''0:2'' else ''0'' end,',
'--datum_verpfl_bel_ok',
'case when nvl(:P373_DATUM_VERPFL_BEL_OK,''01.01.1900'') = nvl(:P373_DATUM_VERPFL_BEL_OK_1,''01.01.1900'')   and :P373_DATUM_VERPFL_BEL_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_VERPFL_BEL_OK,0) =  nvl(:P373_DATUM_VERPFL_BEL_OK_1,0) and :P373_DATUM_VERPFL_BEL_OK is null then ''1''',
'when :P373_DATUM_VERPFL_BEL_OK is not null then ''0:2'' else ''0'' end,',
'--fk_internet_app',
'case when nvl(:P373_FK_INTERNET_APP,0) = nvl(:P373_FK_INTERNET_APP_1,0)   and :P373_FK_INTERNET_APP is not null then ''1:2''',
'when nvl(:P373_FK_INTERNET_APP,0) =  nvl(:P373_FK_INTERNET_APP_1,0) and :P373_FK_INTERNET_APP is null then ''1''',
'when :P373_FK_INTERNET_APP is not null then ''0:2'' else ''0'' end,',
'--fk_dupl_status',
'case when nvl(:P373_FK_DUPL_STATUS,0) = nvl(:P373_FK_DUPL_STATUS_1,0)   and :P373_FK_DUPL_STATUS is not null then ''1:2''',
'when nvl(:P373_FK_DUPL_STATUS,0) =  nvl(:P373_FK_DUPL_STATUS_1,0) and :P373_FK_DUPL_STATUS is null then ''1''',
'when :P373_FK_DUPL_STATUS is not null then ''0:2'' else ''0'' end,',
'--datum_dupl_ok',
'case when nvl(:P373_DATUM_DUPL_OK,''01.01.1900'') = nvl(:P373_DATUM_DUPL_OK_1,''01.01.1900'')   and :P373_DATUM_DUPL_OK is not null then ''1:2''',
'when nvl(:P373_DATUM_DUPL_OK,0) =  nvl(:P373_DATUM_DUPL_OK_1,0) and :P373_DATUM_DUPL_OK is null then ''1''',
'when :P373_DATUM_DUPL_OK is not null then ''0:2'' else ''0'' end,',
'--dupl_buchung',
'case when nvl(:P373_DUPL_BEMERKUNG,0) = nvl(:P373_DUPL_BEMERKUNG_1,0)   and :P373_DUPL_BEMERKUNG is not null then ''1:2''',
'when nvl(:P373_DUPL_BEMERKUNG,0) =  nvl(:P373_DUPL_BEMERKUNG_1,0) and :P373_DUPL_BEMERKUNG is null then ''1''',
'when :P373_DUPL_BEMERKUNG is not null then ''0:2'' else ''0'' end,',
'--fk_gechaeftspartner',
'case when nvl(:P373_FK_GESCHAEFTSPARTNER,0) = nvl(:P373_FK_GESCHAEFTSPARTNER_1,0)   and :P373_FK_GESCHAEFTSPARTNER is not null then ''1:2''',
'when nvl(:P373_FK_GESCHAEFTSPARTNER,0) =  nvl(:P373_FK_GESCHAEFTSPARTNER_1,0) and :P373_FK_GESCHAEFTSPARTNER is null then ''1''',
'when :P373_FK_GESCHAEFTSPARTNER is not null then ''0:2'' else ''0'' end              ',
'Into',
':P373_FK_LEX_BUCHUNG_FLG,',
':P373_FK_KATEGORIE_FLG,             ',
':P373_FK_ARBEITSTAG_FLG,',
':P373_FK_BUCHUNG_FLG,',
':P373_FK_ZAHLUNGSART_FLG,                ',
':P373_FK_VERWENDUNGSZWECK_flg,',
' :P373_FK_INVENTAR_FLG,',
':P373_FK_PROJEKT_FLG,',
':P373_BELEGNUMMER_FLG,',
':P373_BEZEICHNUNG_FLG,',
':P373_FK_LAND_FLG,',
':P373_FK_CITY_FLG,',
':P373_BEL_DATUM_FLG,',
':P373_VON_FLG,',
':P373_BIS_FLG,',
':P373_NETTO_BETRAG_FLG,',
':P373_FK_STEUERSATZ_FLG,',
':P373_MWST_BETRAG_FLG,',
':P373_BRUTTO_BETRAG_FLG,',
':P373_FK_WAEHRUNG_FLG,',
':P373_STEUERNUMMER_FLG,',
':P373_FK_UMRECHNUNGSKURS_FLG,',
':P373_COMM_REST_BELEG_FLG,',
':P373_COMM_TEL_BELEG_FLG,',
':P373_COMM_PRODUKTE_FLG,',
':P373_COMM_BEGRUENDUNG_FLG,',
':P373_COMM_SONSTIGES_FLG,',
':P373_BELEG_FLG,',
':P373_ZAHLUNGSBELEG_FLG,',
':P373_LITER_FLG,',
':P373_ZAPFSAEULE_FLG,',
':P373_FK_LOCATION_FLG,',
':P373_PERSOENLICH_VOR_ORT_FLG,',
':P373_BELEG_UHRZEIT_FLG,',
':P373_VON_UHRZEIT_FLG,',
':P373_BIS_UHRZEIT_FLG,',
':P373_FK_VON_ARBEITSTAG_FLG,',
':P373_FK_BIS_ARBEITSTAG_FLG,',
':P373_COMM_ADRESSE_FLG,',
':P373_TANKSTELLEN_NR_FLG,',
':P373_BRUTTO_BETRAG_INCL_TRINKG_FLG,',
':P373_COMM_PARKTICKET_FLG,',
':P373_FRMDW_NETTO_BETRAG_FLG,',
':P373_FK_FRMDW_FLG,',
':P373_FK_FRMDW_MWST_SATZ_FLG,',
':P373_FRMDW_MWST_BETRAG_FLG,',
':P373_FRMDW_BRUTTO_BETRAG_FLG,',
':P373_FRMDW_BRUTTO_INCL_TRINKG_FLG,',
':P373_MWST_BETRAG_EUR_FLG,',
':P373_BRUTTO_BETRAG_EUR_FLG,',
':P373_BRUTTO_INCL_TRINKG_EUR_FLG,',
':P373_NETTO_BETRAG_EUR_FLG,',
':P373_PREIS_PRO_MENGE_FLG,',
':P373_MENGENEINHEIT_FLG,',
':P373_LA_DATUM_FLG,',
':P373_FK_LA_KONTO_FLG,',
':P373_FK_LA_WDH_FLG,',
':P373_FK_ZAHLSTATUS_FLG,',
':P373_COMM_VERGEHEN_FLG,',
':P373_VERG_BEHOERDE_FLG,',
':P373_CNT_PUNKTE_FLG,',
':P373_FK_BELEG_ABLAGE_FLG,',
':P373_FK_ABL_ORDNER_PAGE_FLG,',
':P373_CNT_PUNKTE_GESCHAETZT_FLG,',
':P373_PUNKTE_VON_FLG,',
':P373_PUNKTE_BIS_FLG,',
':P373_FK_LOCATION_VERG_FLG,',
':P373_FK_IMP_BA_BEL_OLD_FLG,',
':P373_GESCHW_IST_FLG,',
':P373_GESCHW_SOLL_FLG,',
':P373_GESCHW_UEBER_GRZ_FLG,',
':P373_GESCHW_UEBER_GRZ_ABZGL_MESSTOL_FLG,',
':P373_CODE_BUSSGELD_FLG,',
':P373_DESCR_BUSSGELD_FLG,',
':P373_GEZAHLT_AM_FLG,',
':P373_WEBSEITE_FLG,',
':P373_KUNDENNUMMER_FLG,',
':P373_FK_REAL_BELEG_EXIST_FLG,',
':P373_FK_CALC_STATE_FLG,',
':P373_FK_CALC_STATE_EUR_FLG,',
':P373_FK_CALC_STATE_FRMDW_FLG,',
':P373_FK_STATUS_FLG,',
':P373_DATUM_VERGEHEN_FLG,',
':P373_CREATE_AT_FLG,',
':P373_CREATE_BY_FLG,',
':P373_MODIFY_AT_FLG,',
':P373_MODIFY_BY_FLG,',
':P373_DATUM_ORT_OK_FLG,',
':P373_DATUM_ADDRESSE_OK_FLG,',
':P373_DATUM_BUSSGELD_OK_FLG,',
':P373_DATUM_BELEG_POS_OK_FLG,',
':P373_DATUM_BUCHUNG_OK_FLG,',
':P373_DATUM_VERPFL_BEL_OK_FLG,',
':P373_FK_INTERNET_APP_FLG,',
':P373_FK_DUPL_STATUS_FLG,',
':P373_DATUM_DUPL_OK_FLG,',
':P373_DUPL_BEMERKUNG_FLG,',
':P373_FK_GESCHAEFTSPARTNER_FLG               ',
'from dual;',
'end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
