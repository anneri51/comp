prompt --application/pages/page_00349
begin
--   Manifest
--     PAGE: 00349
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>349
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13559786728839704)
,p_plug_name=>'kontenabgleich1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all,',
'datum_ort_ok,',
'datum_addresse_ok,',
'datum_bussgeld_ok,',
'datum_beleg_pos_ok,',
'datum_buchung_ok,',
'DATum_VERPFL_BEL_OK',
'from t_inp_belege_all',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13559942379839705)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:349:&SESSION.::&DEBUG.:RP:P349_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15000261655231245
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559983128839706)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13737868423422863)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13737925536422864)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13738044729422865)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13738130483422866)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13738269998422867)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13764891252091864)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13746475382479805)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'151868'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13703436865351113)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28813800716061712)
,p_plug_name=>'kontenabgleich'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all,',
'apex_item.checkbox2(1, sysdate) dat_all,',
'apex_item.checkbox2(2,1,1,1) dat_ort_ok,',
'apex_item.checkbox2(3,sysdate) dat_addr_ok,',
'apex_item.checkbox2(4,sysdate) dat_buss_ok,',
'apex_item.checkbox2(5,1,1,1) dat_belegpos_ok,',
'apex_item.checkbox2(6,1,1,1) dat_buch_ok,',
'apex_item.checkbox2(7,sysdate) dat_verpfl_bel_ok',
'from t_inp_belege_all',
'where pk_inp_belege_all =:P349_pk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(28813835677061712)
,p_name=>'kontenabgleich'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>30254154952453252
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559134330839697)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559218984839698)
,p_db_column_name=>'DAT_ALL'
,p_display_order=>20
,p_column_identifier=>'V'
,p_column_label=>'Dat All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559378929839699)
,p_db_column_name=>'DAT_ORT_OK'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'Dat Ort Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559451413839700)
,p_db_column_name=>'DAT_ADDR_OK'
,p_display_order=>40
,p_column_identifier=>'X'
,p_column_label=>'Dat Addr Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559541882839701)
,p_db_column_name=>'DAT_BUSS_OK'
,p_display_order=>50
,p_column_identifier=>'Y'
,p_column_label=>'Dat Buss Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559673068839702)
,p_db_column_name=>'DAT_BELEGPOS_OK'
,p_display_order=>60
,p_column_identifier=>'Z'
,p_column_label=>'Dat Belegpos Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559715793839703)
,p_db_column_name=>'DAT_BUCH_OK'
,p_display_order=>70
,p_column_identifier=>'AA'
,p_column_label=>'Dat Buch Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13764865066091863)
,p_db_column_name=>'DAT_VERPFL_BEL_OK'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Dat Verpfl Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(28818034806065504)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'151596'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_INP_BELEGE_ALL:DAT_ALL:DAT_ORT_OK:DAT_ADDR_OK:DAT_BUSS_OK:DAT_BELEGPOS_OK:DAT_BUCH_OK:DAT_VERPFL_BEL_OK'
,p_count_columns_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13738423168422869)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(28813800716061712)
,p_button_name=>'Set_dates'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Set Dates'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13709126346351141)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(13703436865351113)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P349_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13707920973351136)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13703436865351113)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13709533789351141)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(13703436865351113)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P349_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13708703203351141)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(13703436865351113)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P349_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13703730784351117)
,p_name=>'P349_PK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_prompt=>'New'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13704115439351127)
,p_name=>'P349_DATUM_ORT_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13704529402351131)
,p_name=>'P349_DATUM_ADDRESSE_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13704911667351131)
,p_name=>'P349_DATUM_BUSSGELD_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13705337416351131)
,p_name=>'P349_DATUM_BELEG_POS_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13705720892351133)
,p_name=>'P349_DATUM_BUCHUNG_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_item_source_plug_id=>wwv_flow_api.id(13703436865351113)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13764741433091862)
,p_name=>'P349_DATUM_VERPFL_BEL_OK'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(13703436865351113)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13710343211351144)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(13703436865351113)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13738653629422871)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_dates'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'--1 - set all dates',
'for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_inp_belege_all set datum_ort_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'      update t_inp_belege_all set datum_addresse_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'            ',
'      update t_inp_belege_all set datum_bussgeld_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'      ',
'                  ',
'      update t_inp_belege_all set datum_beleg_pos_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'     update t_inp_belege_all set datum_buchung_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'   end if;',
' end loop;',
' ',
' ',
' ',
'--2 - set all dates',
'for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'            update t_inp_belege_all set datum_ort_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'            commit;',
'    ',
'   end if;',
' end loop;',
' ',
' ',
' ',
'--3 - set all dates',
'for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'      ',
'            ',
'      update t_inp_belege_all set datum_addresse_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'      ',
'    ',
'   end if;',
' end loop;',
' ',
' ',
'-- 4- set all dates',
'for i in 1..apex_application.g_f04.count loop',
'    if apex_application.g_f04(i) is not null then',
'      ',
'                ',
'      update t_inp_belege_all set datum_bussgeld_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'   end if;',
' end loop;',
' ',
' ',
'--5 - set all dates',
'for i in 1..apex_application.g_f05.count loop',
'    if apex_application.g_f05(i) is not null then',
'      ',
'          update t_inp_belege_all set datum_beleg_pos_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'   end if;',
' end loop;',
' ',
' ',
'--6 - set all dates',
'for i in 1..apex_application.g_f06.count loop',
'    if apex_application.g_f06(i) is not null then',
'           update t_inp_belege_all set datum_buchung_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'    ',
'   end if;',
' end loop;',
' ',
' --7 - set all dates',
'for i in 1..apex_application.g_f07.count loop',
'    if apex_application.g_f07(i) is not null then',
'           update t_inp_belege_all set datum_verpfl_bel_ok = sysdate  where pk_inp_belege_all = :p349_pk_inp_belege_all;',
'      commit;',
'    ',
'   end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(13738423168422869)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(13709971441351144)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(13703436865351113)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.component_end;
end;
/
