prompt --application/pages/page_00328
begin
--   Manifest
--     PAGE: 00328
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>328
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Verpflegungsmehraufwand_Detail'
,p_alias=>'VERPFLEGUNGSMEHRAUFWAND_DETAIL'
,p_step_title=>'Verpflegungsmehraufwand_Detail'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011155803'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11886883399075031)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET,',
'       FK_STEU_STEUER_VERPFL_MEHRAUFWD,',
'       DATUM_VERPFL_MEHRAUFWD,',
'       FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD,',
'       DESCR,',
'       COMM,',
'       FK_ADR_ORT,',
'       FK_STD_VERPFL_FRUEHSTUECK,',
'       FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL,',
'       FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL,',
'       FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ,',
'       FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE,',
'       FK_STD_STEU_VERPFL_STATUS_VP_VOLL,',
'       FK_STD_STEU_VERPFL_STATUS_VP_TEIL,',
'       FK_STD_STEU_VERPFL_STATUS_VP_KUERZ,',
'       FK_STD_STEU_VERPFL_STATUS_UEP,',
'       FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS,',
'       CREATION_DATE,',
'       MODIFY_DATE,',
'       relort.lg',
'  from T_STEU_STEUER_VERPFL_MEHRAUFWD_DET det',
'    left join (select fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET, listagg(pk_adr_ort || '' '' || ort || '' (''|| land || '')'' || FK_STD_STEU_AUSWAERTS, '' / '') lg',
'               from T_REL_STEU_STEUER_VERPFL_BELEG_ORT relort left join t_adr_ort ort on relort.fk_adr_ort = ort.pk_adr_ort left join t_adr_land la on la.pk_adr_land = ort.fk_adr_land',
'               group by fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET) relort on relort.fk_STEU_STEUER_VERPFL_MEHRAUFWD_DET = det.pk_STEU_STEUER_VERPFL_MEHRAUFWD_DET'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11887365030075031)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:RP,:P329_PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:#PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13327684305466571
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11889366524075053)
,p_db_column_name=>'COMM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11894092740075058)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13493120662014417)
,p_db_column_name=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_display_order=>88
,p_column_identifier=>'AA'
,p_column_label=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548255680332009)
,p_db_column_name=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET'
,p_display_order=>98
,p_column_identifier=>'AB'
,p_column_label=>'Pk Steu Steuer Verpfl Mehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548340600332010)
,p_db_column_name=>'FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_display_order=>108
,p_column_identifier=>'AC'
,p_column_label=>'Fk Steu Steuer Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548451459332011)
,p_db_column_name=>'DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>118
,p_column_identifier=>'AD'
,p_column_label=>'Datum Verpfl Mehraufwd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548567856332012)
,p_db_column_name=>'FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD'
,p_display_order=>128
,p_column_identifier=>'AE'
,p_column_label=>'Fk Bas Kal Datum Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548652813332013)
,p_db_column_name=>'DESCR'
,p_display_order=>138
,p_column_identifier=>'AF'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548798983332014)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>148
,p_column_identifier=>'AG'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548851554332015)
,p_db_column_name=>'FK_STD_VERPFL_FRUEHSTUECK'
,p_display_order=>158
,p_column_identifier=>'AH'
,p_column_label=>'Fk Std Verpfl Fruehstueck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13548999217332016)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_display_order=>168
,p_column_identifier=>'AI'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549068221332017)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_display_order=>178
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Std Verpfl Verpflegungspauschale Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549123275332018)
,p_db_column_name=>'FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ'
,p_display_order=>188
,p_column_identifier=>'AK'
,p_column_label=>'Fk Std Verpfl Verpflegunspauschale Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549259318332019)
,p_db_column_name=>'FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE'
,p_display_order=>198
,p_column_identifier=>'AL'
,p_column_label=>'Fk Std Verpfl Uebernachtungspauschale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549323533332020)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_VOLL'
,p_display_order=>208
,p_column_identifier=>'AM'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Voll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549435791332021)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_TEIL'
,p_display_order=>218
,p_column_identifier=>'AN'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549541477332022)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_VP_KUERZ'
,p_display_order=>228
,p_column_identifier=>'AO'
,p_column_label=>'Fk Std Steu Verpfl Status Vp Kuerz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549612741332023)
,p_db_column_name=>'FK_STD_STEU_VERPFL_STATUS_UEP'
,p_display_order=>238
,p_column_identifier=>'AP'
,p_column_label=>'Fk Std Steu Verpfl Status Uep'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549700693332024)
,p_db_column_name=>'MODIFY_DATE'
,p_display_order=>248
,p_column_identifier=>'AQ'
,p_column_label=>'Modify Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13549836798332025)
,p_db_column_name=>'LG'
,p_display_order=>258
,p_column_identifier=>'AR'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12121463922155061)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135618'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMM:CREATION_DATE:FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS:PK_STEU_STEUER_VERPFL_MEHRAUFWD_DET:FK_STEU_STEUER_VERPFL_MEHRAUFWD:DATUM_VERPFL_MEHRAUFWD:FK_BAS_KAL_DATUM_VERPFL_MEHRAUFWD:DESCR:FK_ADR_ORT:FK_STD_VERPFL_FRUEHSTUECK:FK_STD_VERPFL_VERPFLEGUNGSP'
||'AUSCHALE_VOLL:FK_STD_VERPFL_VERPFLEGUNGSPAUSCHALE_TEIL:FK_STD_VERPFL_VERPFLEGUNSPAUSCHALE_KUERZ:FK_STD_VERPFL_UEBERNACHTUNGSPAUSCHALE:FK_STD_STEU_VERPFL_STATUS_VP_VOLL:FK_STD_STEU_VERPFL_STATUS_VP_TEIL:FK_STD_STEU_VERPFL_STATUS_VP_KUERZ:FK_STD_STEU_V'
||'ERPFL_STATUS_UEP:MODIFY_DATE:LG'
,p_sort_column_1=>'DATUM_VERPFL_MEHRAUFWD'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR:FK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_break_enabled_on=>'JAHR:FK_STEU_STEUER_VERPFL_MEHRAUFWD'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11895690398075086)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11886883399075031)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:329:&SESSION.::&DEBUG.:329'
);
wwv_flow_api.component_end;
end;
/
