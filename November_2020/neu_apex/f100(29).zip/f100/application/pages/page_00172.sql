prompt --application/pages/page_00172
begin
--   Manifest
--     PAGE: 00172
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>172
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kontenzus'
,p_alias=>'KONTENZUS'
,p_step_title=>'Kontenzus'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869195534312536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011145311'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3950848482341037)
,p_plug_name=>'Kontenzus'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  kto.FK_MAIN_KEY, ',
'  ID, ',
'  "Buchungstag", ',
'  round(kto."Betrag",2) "Betrag", ',
'  KTO.Waehrung, ',
'  round(Fremdwaehrungsbetrag,2) Fremdwaehrungsbetrag, ',
'  Fremdwaehrung, ',
'  BUCHUNGSTEXT, ',
'  FK_BAS_KAT_Kategorie, ',
'  KTO.FK_std_verw_Verwendungszweck kto_fk_std_verw_verwendungszweck, ',
'  fk_std_kto_kontotyp, ',
'  fk_bas_kal_buchungstag, ',
'  fk_bas_kal_wertstellung, ',
'  VERWENDUNGSZWECK, ',
'  kto.KATEGORIE, ',
'  BUCHT_TAG, ',
'  BUCHT_MONAT, ',
'  BUCHT_JAHR, ',
'  BUCHT_DATUM, ',
'  WERTT_TAG, ',
'  WERTT_MONAT, ',
'  WERTT_JAHR,',
'  WERTT_DATUM, ',
'  Kontotyp, ',
'  case when kto1.fk_kto_konto_buch1 is not null or kto2.fk_kto_konto_buch2 is not null then 1 else 0 end zuordnung,  ',
'  case when  bel.fk_kto_buchung is not null or ',
'             aut.fk_kto_buchung is not null or',
'             bus.fk_kto_buchung is not null or',
'             car.fk_kto_buchung is not null or',
'             co.fk_kto_buchung is not null or',
'             el.fk_kto_buchung is not null or',
'             gr.fk_kto_buchung is not null or',
'             hz.fk_kto_buchung is not null or',
'             ho.fk_kto_buchung is not null or',
'             kfz.fk_kto_buchung is not null or',
'             kk.fk_kto_buchung is not null or',
'             ot.fk_kto_buchung is not null or',
'             pa.fk_kto_buchung is not null or',
'        --  sb.fk_kto_buchung is not null or',
'             ta.fk_kto_buchung is not null or',
'             te.fk_kto_buchung is not null or',
'             rreza.fk_main_key is not null or',
'             tel1.fk_kto_buchung is not null or',
'             tel2.fk_kto_buchung is not null or',
'             tel3.fk_kto_buchung is not null or',
'             tel4.fk_kto_buchung is not null or',
'             pp.fk_KTO_vorgang is not null',
'      then 1 else 0 end zuord_bel,',
'  case when bel.fk_kto_buchung is not null then 1 else 0 end zuord_allg_bel,',
'  case when aut.fk_kto_buchung is not null then 1 else 0 end zuord_aut,',
'  case when bus.fk_kto_buchung is not null then 1 else 0 end zuord_bus,',
'  case when car.fk_kto_buchung is not null then 1 else 0 end zuord_car,',
'  case when co.fk_kto_buchung is not  null then 1 else 0 end zuord_co,',
'  case when el.fk_kto_buchung is not null then 1 else 0 end zuord_el,',
'  case when gr.fk_kto_buchung is not null then 1 else 0 end zuord_gr,',
'  case when hz.fk_kto_buchung is not null then 1 else 0 end zuord_hz,',
'  case when ho.fk_kto_buchung is not null then 1 else 0 end zuord_ho,',
'  case when kfz.fk_kto_buchung is not null then 1 else 0 end zuord_kfz,',
'  case when kk.fk_kto_buchung is not  null then 1 else 0 end zuord_kk,',
'  case when ot.fk_kto_buchung is not null then 1 else 0  end zuord_ot,',
'  case when pa.fk_kto_buchung is not null then 1 else 0 end zuord_pa,',
'  case when tel1.fk_kto_buchung is not null then 1 else 0 end zuord_tel1,',
'  case when tel2.fk_kto_buchung is not null then 1 else 0 end zuord_tel2,',
'--  case when sb.fk_kto_buchung is  not null then 1 else 0 end zuord_sb,',
'  case when ta.fk_kto_buchung is not null then 1 else 0 end zuord_ta,',
'  case when te.fk_kto_buchung is not null then 1 else 0 end zuord_te  ,',
'  case when rreza.fk_main_key is not null then 1 else 0 end zuord_re,',
'  case when tel3.fk_kto_buchung is not null then 1 else 0 end zuord_tel3,',
'  case when tel4.fk_kto_buchung is not null then 1 else 0 end zuord_tel4,',
'  rreza.cnt_re,',
'  rreza.rel_teil sum_rel_teil, ',
'  case when lo.fk_main_key is not null then 1 else 0 end zuord_lo,',
'  pp.fk_KTO_vorgang paypal_vorg,',
'  case when fk_std_kto_kontotyp = 1 then ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_ID:'' || ID || chr(39) || ''> '' || nvl(Buchungstext ,''<<--keine Angabe-->>'') || ''</a>''',
'       when fk_std_kto_kontotyp = 2 then ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_ID:'' || ID || chr(39) || ''>'' || nvl(Buchungstext,''<<--keine Angabe-->>'') || ''</a>''',
'       when fk_std_kto_kontotyp = 4 then ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_ID:'' || ID || chr(39) ||  ''>'' || nvl(Buchungstext , ''<<--keine Angabe-->>'') || ''</a>''',
'       when fk_std_kto_kontotyp = 3 then ''<a href=''''f?p=&APP_ID.:86:&SESSION.::NO:RP:P86_ID:'' || ID || chr(39) || ''>'' || nvl(Buchungstext, ''<<--keine Angabe-->>'') || ''</a>''',
'  end link_Buchung,',
'  inv.*,',
'  fk_buchung_steuer,',
'  kto.fk_kto_vorgang',
'from V_kto_KONTEN_ZUS kto',
'  left join (',
'             select fk_kto_vorgang , fk_main_key , art, bezeichnung, "Name", "Artikelbezeichnung"',
'            from t_kto_paypal pp',
'             join v_imp_bel_zus bzus on pp.fk_main_key = bzus.fk_kto_buchung',
'            group by fk_kto_vorgang , fk_main_key, art, bezeichnung, "Name", "Artikelbezeichnung"',
'           ) pp on pp.fk_kto_vorgang = kto.fk_kto_vorgang ',
' left join (select fk_kto_konto_buch1 from t_rel_kto_kont_buch_kont_buch group by fk_kto_konto_buch1) kto1 on kto.fk_main_key = kto1.fk_kto_konto_buch1',
' left join (select fk_kto_konto_buch2 from t_rel_kto_kont_buch_kont_buch group by fk_kto_konto_buch2) kto2 on kto.fk_main_key = kto2.fk_kto_konto_buch2',
' left join (select fk_kto_buchung from imp_ba_allg_bel group by fk_kto_buchung) bel on bel.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_car_auto_ersatzteile group by fk_kto_buchung) aut on aut.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_bussgelder group by fk_kto_buchung) bus on bus.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_car_auto_vermietung group by fk_kto_buchung ) car on car.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_coworking group by fk_kto_buchung) co on co.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_inv_sub_elektronik group by fk_kto_buchung) el on el.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_grenzbelege group by fk_kto_buchung) gr on gr.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_abr_en_heizungsabrechnung group by fk_kto_buchung) hz on hz.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_re_sub_hotelrechnungen group by fk_kto_buchung) ho on ho.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_car_auto_versicherung group by fk_kto_buchung) kfz on kfz.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_bei_kk_krankenkasse_det group by fk_kto_buchung) kk on kk.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_oeffentl_tickets group by fk_kto_buchung) ot on ot.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_parktickets group by fk_kto_buchung) pa on pa.fk_kto_buchung = kto.fk_main_key',
' --left join (select fk_kto_buchung from imp_ba_sonstige_belege group by fk_kto_buchung) sb on sb.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from imp_ba_tankstelle group by fk_kto_buchung) ta on ta.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_kto_buchung from t_tex_textilreinigung group by fk_kto_buchung) te on te.fk_kto_buchung = kto.fk_main_key',
' left join (select fk_main_key, count(*) cnt_re, sum(relevanter_teilbetrag) rel_teil from t_reL_re_rechnung_zahlung group by fk_main_key) rreza on rreza.fk_main_key = kto.fk_main_key',
' left join t_imp_tel_mobilcom_rech tel1 on tel1.fk_kto_buchung = kto.fk_main_key',
' left join t_imp_tel_mobilcom_rech_ov tel2 on tel2.fk_kto_buchung = kto.fk_main_key',
' left join t_imp_tel_vodafone tel3 on tel3.fk_kto_buchung = kto.fk_main_key',
' left join (',
'            select kto.fk_main_key',
'            from t_steu_steuer_lohnsteuerkarte lo',
'              left join t_rel_steu_steuer_lohn_zahlung loz on lo.pk_steu_steuer_lohnsteuerkarte  = loz.fk_steu_steuer_lohnsteuerkarte',
'              left join v_kto_konten_zus kto on kto.fk_main_key = loz.fk_main_key',
'            ) lo on lo.fk_main_key = kto.fk_main_key',
'left join t_imp_tel_o2 tel4  on tel4.fk_kto_buchung = kto.fk_main_key',
'left join t_rel_inv_inventar_zahlung invzahl on kto.fk_main_key = invzahl.fk_main_key',
'left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3950963831341037)
,p_name=>'Kontenzus'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13261099071761958
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3951265069341047)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3951732590341049)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3952144302341050)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3952898661341051)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3876504376528511)
,p_db_column_name=>'Betrag'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3878104783528527)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>180
,p_column_identifier=>'AA'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113446102257411)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>220
,p_column_identifier=>'AE'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113536484257412)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>230
,p_column_identifier=>'AF'
,p_column_label=>'Bucht tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113589427257413)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>240
,p_column_identifier=>'AG'
,p_column_label=>'Bucht monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113725107257414)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>250
,p_column_identifier=>'AH'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113844533257415)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>260
,p_column_identifier=>'AI'
,p_column_label=>'Bucht datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4113909092257416)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>270
,p_column_identifier=>'AJ'
,p_column_label=>'Wertt tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4114000837257417)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>280
,p_column_identifier=>'AK'
,p_column_label=>'Wertt monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4114124983257418)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Wertt jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4114199751257419)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Wertt datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069530599641320)
,p_db_column_name=>'ZUORDNUNG'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Zuordnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069582927641321)
,p_db_column_name=>'ZUORD_ALLG_BEL'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'Zuord allg bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069700082641322)
,p_db_column_name=>'ZUORD_BEL'
,p_display_order=>340
,p_column_identifier=>'AQ'
,p_column_label=>'Zuord bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069863562641323)
,p_db_column_name=>'ZUORD_AUT'
,p_display_order=>350
,p_column_identifier=>'AR'
,p_column_label=>'Zuord aut'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069931455641324)
,p_db_column_name=>'ZUORD_BUS'
,p_display_order=>360
,p_column_identifier=>'AS'
,p_column_label=>'Zuord bus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5069991948641325)
,p_db_column_name=>'ZUORD_CAR'
,p_display_order=>370
,p_column_identifier=>'AT'
,p_column_label=>'Zuord car'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5070096964641326)
,p_db_column_name=>'ZUORD_CO'
,p_display_order=>380
,p_column_identifier=>'AU'
,p_column_label=>'Zuord co'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5070240286641327)
,p_db_column_name=>'ZUORD_EL'
,p_display_order=>390
,p_column_identifier=>'AV'
,p_column_label=>'Zuord el'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5070291531641328)
,p_db_column_name=>'ZUORD_GR'
,p_display_order=>400
,p_column_identifier=>'AW'
,p_column_label=>'Zuord gr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5070446190641329)
,p_db_column_name=>'ZUORD_HZ'
,p_display_order=>410
,p_column_identifier=>'AX'
,p_column_label=>'Zuord hz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5188621446986780)
,p_db_column_name=>'ZUORD_HO'
,p_display_order=>420
,p_column_identifier=>'AY'
,p_column_label=>'Zuord ho'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5188699113986781)
,p_db_column_name=>'ZUORD_KFZ'
,p_display_order=>430
,p_column_identifier=>'AZ'
,p_column_label=>'Zuord kfz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5188863357986782)
,p_db_column_name=>'ZUORD_KK'
,p_display_order=>440
,p_column_identifier=>'BA'
,p_column_label=>'Zuord kk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5188920800986783)
,p_db_column_name=>'ZUORD_OT'
,p_display_order=>450
,p_column_identifier=>'BB'
,p_column_label=>'Zuord ot'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5188988387986784)
,p_db_column_name=>'ZUORD_PA'
,p_display_order=>460
,p_column_identifier=>'BC'
,p_column_label=>'Zuord pa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5189147732986785)
,p_db_column_name=>'ZUORD_TA'
,p_display_order=>470
,p_column_identifier=>'BD'
,p_column_label=>'Zuord ta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5189234216986786)
,p_db_column_name=>'ZUORD_TE'
,p_display_order=>480
,p_column_identifier=>'BE'
,p_column_label=>'Zuord te'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5429326431463418)
,p_db_column_name=>'CNT_RE'
,p_display_order=>490
,p_column_identifier=>'BF'
,p_column_label=>'Cnt re'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5429370548463419)
,p_db_column_name=>'SUM_REL_TEIL'
,p_display_order=>500
,p_column_identifier=>'BG'
,p_column_label=>'Sum rel teil'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5429547838463420)
,p_db_column_name=>'ZUORD_RE'
,p_display_order=>510
,p_column_identifier=>'BH'
,p_column_label=>'Zuord re'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5499969772827204)
,p_db_column_name=>'ZUORD_TEL1'
,p_display_order=>520
,p_column_identifier=>'BI'
,p_column_label=>'Zuord tel1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5575756750533782)
,p_db_column_name=>'ZUORD_TEL2'
,p_display_order=>530
,p_column_identifier=>'BJ'
,p_column_label=>'Zuord tel2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5689590374356187)
,p_db_column_name=>'ZUORD_TEL3'
,p_display_order=>540
,p_column_identifier=>'BK'
,p_column_label=>'Zuord tel3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5811192005831085)
,p_db_column_name=>'ZUORD_LO'
,p_display_order=>550
,p_column_identifier=>'BL'
,p_column_label=>'Zuord lo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5812596965831099)
,p_db_column_name=>'ZUORD_TEL4'
,p_display_order=>560
,p_column_identifier=>'BM'
,p_column_label=>'Zuord tel4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5934681867874611)
,p_db_column_name=>'PAYPAL_VORG'
,p_display_order=>570
,p_column_identifier=>'BN'
,p_column_label=>'Paypal vorg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6245390904367888)
,p_db_column_name=>'LINK_BUCHUNG'
,p_display_order=>580
,p_column_identifier=>'BO'
,p_column_label=>'Link buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7833638286930029)
,p_db_column_name=>'INVENTAR'
,p_display_order=>600
,p_column_identifier=>'BQ'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881052378545680)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>610
,p_column_identifier=>'BR'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881084149545681)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>620
,p_column_identifier=>'BS'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881181798545682)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>630
,p_column_identifier=>'BT'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881276841545683)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>640
,p_column_identifier=>'BU'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881394470545684)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>650
,p_column_identifier=>'BV'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881522142545685)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>660
,p_column_identifier=>'BW'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881648479545686)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>670
,p_column_identifier=>'BX'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881704500545687)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>680
,p_column_identifier=>'BY'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881767280545688)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>690
,p_column_identifier=>'BZ'
,p_column_label=>'Preis netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7881939392545689)
,p_db_column_name=>'MWST'
,p_display_order=>700
,p_column_identifier=>'CA'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882084491545691)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>720
,p_column_identifier=>'CC'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882257810545692)
,p_db_column_name=>'COMM'
,p_display_order=>730
,p_column_identifier=>'CD'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882313217545693)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>740
,p_column_identifier=>'CE'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882441510545694)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>750
,p_column_identifier=>'CF'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882604275545696)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>770
,p_column_identifier=>'CH'
,p_column_label=>'Kfz kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882680753545697)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>780
,p_column_identifier=>'CI'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7882837738545698)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>790
,p_column_identifier=>'CJ'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883053984545700)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>810
,p_column_identifier=>'CL'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883072142545701)
,p_db_column_name=>'ABGANGSDATUM'
,p_display_order=>820
,p_column_identifier=>'CM'
,p_column_label=>'Abgangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883235756545702)
,p_db_column_name=>'ABGANGSWERT'
,p_display_order=>830
,p_column_identifier=>'CN'
,p_column_label=>'Abgangswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883380494545704)
,p_db_column_name=>'GWG'
,p_display_order=>850
,p_column_identifier=>'CP'
,p_column_label=>'Gwg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883511186545705)
,p_db_column_name=>'RESTBUCHWERT_2017'
,p_display_order=>860
,p_column_identifier=>'CQ'
,p_column_label=>'Restbuchwert 2017'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883622255545706)
,p_db_column_name=>'ABGANGSGRUND'
,p_display_order=>870
,p_column_identifier=>'CR'
,p_column_label=>'Abgangsgrund'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883722610545707)
,p_db_column_name=>'MAC_ADRESSE'
,p_display_order=>880
,p_column_identifier=>'CS'
,p_column_label=>'Mac adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883841921545708)
,p_db_column_name=>'SERIENNUMMER'
,p_display_order=>890
,p_column_identifier=>'CT'
,p_column_label=>'Seriennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7883980981545710)
,p_db_column_name=>'OK'
,p_display_order=>910
,p_column_identifier=>'CV'
,p_column_label=>'Ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884079084545711)
,p_db_column_name=>'OK_BEMERKUNGEN'
,p_display_order=>920
,p_column_identifier=>'CW'
,p_column_label=>'Ok bemerkungen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301438241059293)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>930
,p_column_identifier=>'CX'
,p_column_label=>'Fk buchung steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(99061715470961)
,p_db_column_name=>'BILD'
,p_display_order=>950
,p_column_identifier=>'CZ'
,p_column_label=>'Bild'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(99123143470962)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>960
,p_column_identifier=>'DA'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934749072886909)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>970
,p_column_identifier=>'DB'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49934835637886910)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>980
,p_column_identifier=>'DC'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49986714268138961)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>990
,p_column_identifier=>'DD'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49986862078138962)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>1000
,p_column_identifier=>'DE'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49986916581138963)
,p_db_column_name=>'KTO_FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>1010
,p_column_identifier=>'DF'
,p_column_label=>'Kto Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987063306138964)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>1020
,p_column_identifier=>'DG'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987164129138965)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>1030
,p_column_identifier=>'DH'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987214793138966)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>1040
,p_column_identifier=>'DI'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987376794138967)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>1050
,p_column_identifier=>'DJ'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987451714138968)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>1060
,p_column_identifier=>'DK'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987495551138969)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>1070
,p_column_identifier=>'DL'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987587821138970)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>1080
,p_column_identifier=>'DM'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987721464138971)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>1090
,p_column_identifier=>'DN'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987836617138972)
,p_db_column_name=>'GERAETENAME'
,p_display_order=>1100
,p_column_identifier=>'DO'
,p_column_label=>'Geraetename'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49987944117138973)
,p_db_column_name=>'INV_BILD'
,p_display_order=>1110
,p_column_identifier=>'DP'
,p_column_label=>'Inv Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49988055571138974)
,p_db_column_name=>'ANSCHAFFUNGSWERT'
,p_display_order=>1120
,p_column_identifier=>'DQ'
,p_column_label=>'Anschaffungswert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49988088942138975)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>1130
,p_column_identifier=>'DR'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49988194976138976)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>1140
,p_column_identifier=>'DS'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3955358057341711)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'132655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'LINK_BUCHUNG:FK_MAIN_KEY:ID:Buchungstag:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:Betrag:ZUORDNUNG:ZUORD_ALLG_BEL:ZUORD_BEL:ZUORD_AUT:ZUORD_BUS:ZUORD_CAR:ZUORD_CO'
||':ZUORD_EL:ZUORD_GR:ZUORD_HZ:ZUORD_HO:ZUORD_KFZ:ZUORD_KK:ZUORD_OT:ZUORD_PA:ZUORD_TA:ZUORD_TE:CNT_RE:SUM_REL_TEIL:ZUORD_RE:ZUORD_TEL1:ZUORD_TEL2:ZUORD_TEL3:ZUORD_LO:ZUORD_TEL4:PAYPAL_VORG:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:R'
||'ESTBUCHWERT_2018:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PREIS_NETTO:MWST:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHRGESTELLNR:BEMERKUNGEN:ABGANGSJAHR:ABGANGSDATUM:ABGANGSWERT:GWG:RESTBUCHWERT_2017:ABGANGSGRUND:MAC_ADRE'
||'SSE:SERIENNUMMER:OK:OK_BEMERKUNGEN::FK_BUCHUNG_STEUER:RESTBUCHWERT_2019:WAEHRUNGSBETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:KTO_FK_STD_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:PK_INV_INVENTAR:FK_BAS_STEU_STEUER_SATZ:FK_BAS_INV_INVEN'
||'TARTYP:FK_STD_VERW_VERWENDUNGSZWECK:GERAETENAME:INV_BILD:ANSCHAFFUNGSWERT:RESTBUCHWERT_2020:FK_KTO_VORGANG'
,p_sort_column_1=>'Betrag'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7917757103560133)
,p_report_id=>wwv_flow_api.id(3955358057341711)
,p_name=>'zugeordnete_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7918067074560134)
,p_report_id=>wwv_flow_api.id(3955358057341711)
,p_name=>'zuord_lo'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_LO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_LO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7918505614560135)
,p_report_id=>wwv_flow_api.id(3955358057341711)
,p_name=>'zuord_re'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_RE'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("ZUORD_RE" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7917302090560131)
,p_report_id=>wwv_flow_api.id(3955358057341711)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERWENDUNGSZWECK'
,p_operator=>'='
,p_expr=>unistr('Gesch\00E4ftlich')
,p_condition_sql=>'"VERWENDUNGSZWECK" = #APXWS_EXPR#'
,p_condition_display=>unistr('#APXWS_COL_NAME# = ''Gesch\00E4ftlich''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3967794247378530)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Kontotyp'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'132780'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_MAIN_KEY:ID:Buchungstag:BUCHUNGSTEXT:FK_FK_Verwendungszweck:FK_FK_BUCHUNGSFK_WERTSTELLUNG:FK_ARBEITSFK_WOCHENENDE:FK_FEIERFEIERTAG:VERWENDUNGSZWECK:W\00E4hrungsbetrag:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_J')
||'AHR:WERTT_DATUM:ZUORDNUNG:ZUORD_ALLG_BEL:ZUORD_BEL:ZUORD_AUT:ZUORD_BUS:ZUORD_CAR:ZUORD_CO:ZUORD_EL:ZUORD_GR:ZUORD_HZ:ZUORD_HO:ZUORD_KFZ:ZUORD_KK:ZUORD_OT:ZUORD_PA:ZUORD_TA:ZUORD_TE:CNT_RE:SUM_REL_TEIL:ZUORD_RE:ZUORD_TEL1:ZUORD_TEL2:ZUORD_TEL3:ZUORD_L'
||'O:ZUORD_TEL4:PAYPAL_VORG:LINK_BUCHUNG:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:RESTBUCHWERT_2018:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PREIS_NETTO:MWST:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHR'
||'GESTELLNR:BEMERKUNGEN:ABGANGSJAHR:ABGANGSDATUM:ABGANGSWERT:GWG:RESTBUCHWERT_2017:ABGANGSGRUND:MAC_ADRESSE:SERIENNUMMER:OK:OK_BEMERKUNGEN:FK_BUCHUNG_STEUER'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(5207609350997941)
,p_report_id=>wwv_flow_api.id(3967794247378530)
,p_pivot_columns=>'FK_Kontotyp'
,p_row_columns=>'ZUORD_BEL'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(5208000373997942)
,p_pivot_id=>wwv_flow_api.id(5207609350997941)
,p_display_seq=>1
,p_function_name=>'COUNT'
,p_column_name=>'FK_MAIN_KEY'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8354896111969008)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Buchung'
,p_report_seq=>10
,p_report_alias=>'176651'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'LINK_BUCHUNG:Buchungstag:BUCHUNGSTEXT:FK_MAIN_KEY:Betrag:VERWENDUNGSZWECK:KATEGORIE:FK_BUCHUNG_STEUER'
,p_sort_column_1=>'Betrag'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8384683756844947)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_name=>'zugeordnete_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8385120072844948)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_name=>'zuord_lo'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_LO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_LO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8385558740844948)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_name=>'zuord_re'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_RE'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("ZUORD_RE" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8383494283844944)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2017'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8383873960844945)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Betrag'
,p_operator=>'contains'
,p_expr=>'29.95'
,p_condition_sql=>'upper("Betrag") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 29.95  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8384334464844946)
,p_report_id=>wwv_flow_api.id(8354896111969008)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERWENDUNGSZWECK'
,p_operator=>'='
,p_expr=>unistr('Gesch\00E4ftlich')
,p_condition_sql=>'"VERWENDUNGSZWECK" = #APXWS_EXPR#'
,p_condition_display=>unistr('#APXWS_COL_NAME# = ''Gesch\00E4ftlich''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8263495279430117)
,p_application_user=>'ANNE'
,p_name=>'Buchung'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'LINK_BUCHUNG:Buchungstag:BUCHUNGSTEXT:FK_MAIN_KEY:Betrag:VERWENDUNGSZWECK:FK_BUCHUNG_STEUER'
,p_sort_column_1=>'Betrag'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8354616896967322)
,p_report_id=>wwv_flow_api.id(8263495279430117)
,p_name=>'zugeordnete_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_BEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_BEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8354685325967322)
,p_report_id=>wwv_flow_api.id(8263495279430117)
,p_name=>'zuord_lo'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_LO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_LO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8354799212967322)
,p_report_id=>wwv_flow_api.id(8263495279430117)
,p_name=>'zuord_re'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_RE'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("ZUORD_RE" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#59A859'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8354414882967322)
,p_report_id=>wwv_flow_api.id(8263495279430117)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2017'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8354547698967322)
,p_report_id=>wwv_flow_api.id(8263495279430117)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERWENDUNGSZWECK'
,p_operator=>'='
,p_expr=>unistr('Gesch\00E4ftlich')
,p_condition_sql=>'"VERWENDUNGSZWECK" = #APXWS_EXPR#'
,p_condition_display=>unistr('#APXWS_COL_NAME# = ''Gesch\00E4ftlich''  ')
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6069905273111923)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6069967431111924)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6069905273111923)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'New'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:188:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8785179399211941)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3950848482341037)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8785310860211941)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(3950848482341037)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8785485808211941)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3950848482341037)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'BELOW_BOX'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8786891851211942)
,p_branch_action=>'f?p=&APP_ID.:173:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8785485808211941)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8786186315211942)
,p_branch_action=>'f?p=&APP_ID.:171:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8785310860211941)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8784841271211941)
,p_name=>'P172_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3950848482341037)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
