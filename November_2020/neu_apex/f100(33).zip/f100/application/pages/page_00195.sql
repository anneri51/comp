prompt --application/pages/page_00195
begin
--   Manifest
--     PAGE: 00195
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>195
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Buchung Verwendungszweck'
,p_alias=>'BUCHUNGVERWENDUNGSZWECK_195'
,p_step_title=>'Buchung Verwendungszweck'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011151146'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23071584922512075)
,p_plug_name=>'Buchung_Verwendungszweck'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct',
'      apex_item.checkbox2(1, kto.fk_main_key) sel,',
'      apex_item.checkbox2(2, kto.fk_main_key || '','' || kto.FK_std_kto_kontotyp) sel2,',
'      ''<b>'' || kto.Verwendungszweck || ''</b>'' || '' <i>''|| kto.Kategorie || ''</i> '' || kto."BUCHUNGSTEXT" as title, ',
'      kto.fk_main_Key,',
'      ckz.fk_std_contr_status verw_fk_std_contr_status,',
'      ckz1.fk_std_contr_status kat_fk_std_contr_status,',
'      auslgeb.jkey,',
'      auslgeb.fk_main_key auslgeb_fk_main_key,',
'      auslgeb.Verwendungszweck auslgeb_Verw,',
'      auslgeb.Kategorie auslgeb_kat,',
'      auslgeb.buchungstext auslgeb_Buchungstext,',
'      case when ckz.fk_std_contr_status =1 then ''OK'' else ''NOK'' end contr_verw,',
'      case when ckz1.fk_std_contr_status =1 then ''OK'' else ''NOK'' end contr_kat,',
'      kto.Kontotyp,',
'      round(kto."Betrag",2) Wert,',
'      kto."Buchungstag",',
'      case when kto.FK_std_kto_kontotyp = 1 then ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_ID:'' || kto.ID || chr(39) || ''> '' || nvl(kto.Buchungstext ,''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 2 then ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_ID:'' || kto.ID || chr(39) || ''>'' || nvl(kto.Buchungstext,''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 4 then ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_ID:'' || kto.ID || chr(39) ||  ''>'' || nvl(kto.Buchungstext , ''<<--keine Angabe-->>'') || ''</a>''',
'       when kto.FK_std_kto_kontotyp = 3 then ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_ID:'' || kto.fk_kto_vorgang || chr(39) || ''>'' || nvl(kto.Buchungstext, ''<<--keine Angabe-->>'') || ''</a>''',
'  end link_Buchung,',
'  kto.wiederholung,',
'  kto.naechste_Zahlung,',
'  kto.naechste_zahlung - kto."Buchungstag" diff,',
'  kto.Waehrung,',
'  kto.Fremdwaehrung,',
'  kto.Fremdwaehrungsbetrag,',
'  kto.bucht_jahr,',
'  inv.pk_inv_inventar,',
'  inv.inventar,',
'  inv.anschaffungsjahr,',
'  inv.abgangsjahr,',
'  inv.preis_brutto,',
'  pr.pk_proj_projekt,',
'  pr.projekt,',
'  pr.von,',
'  pr.bis,',
'  kto.fk_kto_vorgang,',
'  belgr.cnt_bel,',
'  lex.belegnummer,',
'  lex.pk_lex,',
'  lex.buchungstext buchtxt,',
'  lex.sollkonto,',
'  lex.habenkonto,',
'  lex.ok,',
'  lex.datum_ok,',
'  lex.storno,',
'  kto.bucht_monat,',
'  kto.fk_bas_kat_kategorie,',
'  kto.fk_std_verw_verwendungszweck',
'from v_kto_konten_zus kto',
' left join (select * from t_contr_Kategorie_zahlung where Kontrollzweck = ''Verwendungszweck'') ckz on kto.fk_main_key = ckz.fk_main_key',
' left join (select * from t_contr_Kategorie_zahlung where Kontrollzweck = ''Kategorie'') ckz1 on kto.fk_main_key = ckz1.fk_main_key',
' left join (',
'             select kto1.*,  round(kto1."Betrag",2) wert, kto2.fk_main_key jkey',
'             from v_kto_konten_zus kto1',
'                join t_rel_kto_kont_buch_kont_buch relkto on kto1.fk_main_key = relkto.fk_kto_konto_buch1 or kto1.fk_main_key = relkto.fk_kto_konto_buch2',
'                join v_kto_konten_zus kto2 on  kto2.fk_main_key = relkto.fk_kto_konto_buch1 or kto2.fk_main_key = relkto.fk_kto_konto_buch2',
unistr('             where instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0 '),
'             union',
'             select kto2.*,   round(kto2."Betrag",2) wert, kto1.fk_main_key jkey',
'             from v_kto_konten_zus kto1',
'               join t_rel_kto_kont_buch_kont_buch relkto on kto1.fk_main_key = relkto.fk_kto_konto_buch1 or kto1.fk_main_key = relkto.fk_kto_konto_buch2',
'               join v_kto_konten_zus kto2 on  kto2.fk_main_key = relkto.fk_kto_konto_buch1 or kto2.fk_main_key = relkto.fk_kto_konto_buch2',
unistr('             where instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0  '),
'           ) auslgeb on auslgeb.jkey = kto.fk_main_key and auslgeb.fk_main_key <> kto.fk_main_key',
'left join t_rel_inv_inventar_zahlung invzahl on kto.fk_main_key = invzahl.fk_main_key',
'left join t_inv_inventare inv on inv.pk_inv_inventar = invzahl.fk_inv_inventar',
'left join t_rel_proj_project_payment przahl on przahl.fk_main_key = kto.fk_main_key',
'left join t_proj_projekt pr on pr.pk_proj_projekt = przahl.fk_proj_projekt',
'left join (select count(*) cnt_bel, fk_kto_buchung from v_imp_bel_zus group by fk_kto_buchung) belgr on belgr.fk_kto_buchung = kto.fk_main_key',
'left join (select * from t_lex where ok = 1 and storno =0) lex on lex.fk_main_key = kto.fk_main_key',
'order by 1',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(23036446402571843)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:RP:P203_FK_BUCHUNG:#FK_MAIN_KEY#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>32346581642992764
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7097325051331167)
,p_db_column_name=>'TITLE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7097755325331170)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7098142944331172)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'fk_main_key <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7099695105331176)
,p_db_column_name=>'WERT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7100125450331177)
,p_db_column_name=>'Buchungstag'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7100495955331177)
,p_db_column_name=>'SEL2'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'fk_main_key, konto_typ  <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7047801415518521)
,p_db_column_name=>'CONTR_VERW'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Contr verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7047871467518522)
,p_db_column_name=>'CONTR_KAT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Contr kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7047992940518523)
,p_db_column_name=>'JKEY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Jkey'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7048111593518524)
,p_db_column_name=>'AUSLGEB_FK_MAIN_KEY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Auslgeb fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7048166319518525)
,p_db_column_name=>'AUSLGEB_VERW'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Auslgeb verw'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7048281797518526)
,p_db_column_name=>'AUSLGEB_KAT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Auslgeb kat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7048365749518527)
,p_db_column_name=>'AUSLGEB_BUCHUNGSTEXT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Auslgeb buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7182053274389180)
,p_db_column_name=>'LINK_BUCHUNG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Link buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7182198411389182)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7182270188389183)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Naechste zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884290493545713)
,p_db_column_name=>'INVENTAR'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884404140545714)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884493870545715)
,p_db_column_name=>'ABGANGSJAHR'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Abgangsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884577364545716)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884810593545718)
,p_db_column_name=>'PROJEKT'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7884905223545719)
,p_db_column_name=>'VON'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7885055306545720)
,p_db_column_name=>'BIS'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7942194480463103)
,p_db_column_name=>'CNT_BEL'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Cnt bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8848758290026991)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8848772354026992)
,p_db_column_name=>'PK_LEX'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Pk lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8848930639026993)
,p_db_column_name=>'BUCHTXT'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Buchtxt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8849049110026994)
,p_db_column_name=>'SOLLKONTO'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Sollkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8849148218026995)
,p_db_column_name=>'HABENKONTO'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Habenkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8849247533026996)
,p_db_column_name=>'OK'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8849338538026997)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Datum ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8849454856026998)
,p_db_column_name=>'STORNO'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10322744181821780)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Bucht jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7002906352079583)
,p_db_column_name=>'DIFF'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Diff'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7003027501079584)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280358292707966)
,p_db_column_name=>'VERW_FK_STD_CONTR_STATUS'
,p_display_order=>480
,p_column_identifier=>'AX'
,p_column_label=>'Verw Fk Std Contr Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280401656707967)
,p_db_column_name=>'KAT_FK_STD_CONTR_STATUS'
,p_display_order=>490
,p_column_identifier=>'AY'
,p_column_label=>'Kat Fk Std Contr Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280514371707968)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>500
,p_column_identifier=>'AZ'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280592189707969)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>510
,p_column_identifier=>'BA'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280701365707970)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>520
,p_column_identifier=>'BB'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280880538707971)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>530
,p_column_identifier=>'BC'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50280921490707972)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>540
,p_column_identifier=>'BD'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281043571707973)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>550
,p_column_identifier=>'BE'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281111660707974)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>560
,p_column_identifier=>'BF'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281258032707975)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>570
,p_column_identifier=>'BG'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281341277707976)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>580
,p_column_identifier=>'BH'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7934886597410933)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Inventar'
,p_report_seq=>10
,p_report_alias=>'172451'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:TITLE:FK_MAIN_KEY:WERT:Buchungstag::CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:PROJEKT:VON:BIS:CNT'
||'_BEL:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO:BUCHT_JAHR'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
,p_break_on=>'PK_INVENTAR:INVENTAR:PREIS_BRUTTO:0:0:0'
,p_break_enabled_on=>'PK_INVENTAR:INVENTAR:PREIS_BRUTTO:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7935665499410935)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7936096859410935)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7936520167410936)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7935270377410934)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7936899251410937)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_name=>'Row text contains ''149'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'149'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7937306040410937)
,p_report_id=>wwv_flow_api.id(7934886597410933)
,p_name=>'Row text contains ''privat'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'privat'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7977665647197075)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Projekt'
,p_report_seq=>10
,p_report_alias=>'172879'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:BUCHT_JAHR:TITLE:FK_MAIN_KEY:CNT_BEL:WERT:Buchungstag:CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:P'
||'ROJEKT:VON:BIS:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
,p_break_on=>'PK_PROJEKT:PROJEKT:0:0:0:0'
,p_break_enabled_on=>'PK_PROJEKT:PROJEKT:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10330948612840454)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_name=>'anzahl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_BEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CNT_BEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D4CDD4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10331293995840456)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10331681678840459)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10332160990840461)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10329308991840446)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'='
,p_expr=>'379'
,p_condition_sql=>'"FK_MAIN_KEY" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10329756446840447)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_VORGANG'
,p_operator=>'='
,p_expr=>'31'
,p_condition_sql=>'"FK_VORGANG" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10330092736840450)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PK_PROJEKT'
,p_operator=>'is null'
,p_condition_sql=>'"PK_PROJEKT" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10330513948840452)
,p_report_id=>wwv_flow_api.id(7977665647197075)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(23076957237575542)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'164110'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:TITLE:FK_MAIN_KEY:WERT:Buchungstag::CONTR_VERW:CONTR_KAT:JKEY:AUSLGEB_FK_MAIN_KEY:AUSLGEB_VERW:AUSLGEB_KAT:AUSLGEB_BUCHUNGSTEXT:LINK_BUCHUNG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:INVENTAR:ANSCHAFFUNGSJAHR:ABGANGSJAHR:PREIS_BRUTTO:PROJEKT:VON:BIS:CNT'
||'_BEL:BELEGNUMMER:PK_LEX:BUCHTXT:SOLLKONTO:HABENKONTO:OK:DATUM_OK:STORNO:BUCHT_JAHR:BUCHT_MONAT:VERW_FK_STD_CONTR_STATUS:KAT_FK_STD_CONTR_STATUS:KONTOTYP:WAEHRUNG:FREMDWAEHRUNG:FREMDWAEHRUNGSBETRAG:PK_INV_INVENTAR:PK_PROJ_PROJEKT:FK_KTO_VORGANG:FK_BAS'
||'_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TITLE'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40854313666381583)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40854759924381586)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_name=>'UPD_VERW_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40855085621381588)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_name=>'Verwend'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VERW_FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40853136960381580)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40853555914381580)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'is null'
,p_condition_sql=>'"FK_Kategorie" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(40853953215381581)
,p_report_id=>wwv_flow_api.id(23076957237575542)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'VERW_FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"VERW_FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23453268511270471)
,p_plug_name=>unistr('Kategorie \00E4ndern')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7104395129331203)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(23071584922512075)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7293835883770584)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'Update_Kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7105094341331234)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'Update_Verwendungszweck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update verwendungszweck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7182840371389188)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'Update_Wiederholung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update wiederholung'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7182938250389189)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7183445709389194)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung_1')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7678930179003297)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'Insert_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Insert inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9559769802288086)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'remove_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'remove inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7941354974463094)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'Insert_Projekt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Insert Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10322986068821783)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(23453268511270471)
,p_button_name=>'remove_Projekt_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Remove Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7103668846331197)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(23071584922512075)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7103987499331203)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(23071584922512075)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7047440369518517)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(23071584922512075)
,p_button_name=>'OK_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Ok'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7105514028331235)
,p_name=>'P195_FK_STD_VERW_VERWENDUNGSZWECK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'Fk verwendungszweck'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value ',
'from t_std',
'where fk_std_group = 9'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7182662190389186)
,p_name=>'P195_WIEDERHOLUNG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'Wiederholung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC:',
unistr('"j\00E4hrlich";"j\00E4hrlich",'),
unistr('"halbj\00E4hrlich";"halbj\00E4hrlich",'),
unistr('"viertelj\00E4hrlich";"viertelj\00E4hrlich",'),
'"monatlich";"monatlich",',
'einmalig;einmalig'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7182742959389187)
,p_name=>'P195_NAECHSTE_ZAHLUNG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>unistr('N\00E4chste zahlung')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7293563152768338)
,p_name=>'P195_FK_BAS_KAT_KATEGORIE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAT_KATEGORIE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7678824521003296)
,p_name=>'P195_FK_INV_INVENTAR'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr, pk_inv_inventar',
'from t_inv_inventare'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7679159636003299)
,p_name=>'P195_DESCR1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'fk_main_key, konrotsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7679234105003300)
,p_name=>'P195_DESCR1_1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7679322332003301)
,p_name=>'P195_DESCR1_2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7679452797003302)
,p_name=>'P195_DESCR1_3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7679475975003303)
,p_name=>'P195_DESCR1_4'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'fk_main_key'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightgreen"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7941184917463093)
,p_name=>'P195_FK_PROJ_PROJEKT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(23453268511270471)
,p_prompt=>'Fk projekt'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || von || '' - '' || bis || '')''  ,Pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7106688640331291)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6665465143760118)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7107219891331298)
,p_event_id=>wwv_flow_api.id(7106688640331291)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(23071584922512075)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7107481977331299)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(7103987499331203)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7107972497331299)
,p_event_id=>wwv_flow_api.id(7107481977331299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(23071584922512075)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7105910749331288)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select apex_application.g_f01(i),',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7104395129331203)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7047557776518518)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select apex_application.g_f01(i),',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7047440369518517)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7106352991331290)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Verwendungszweck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
'       update KTO_Paypal  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
'       update KTO_Tagesgeldkonto  set "FK_Verwendungszweck" = :P195_FK_VERWENDUNGSZWECK where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7105094341331234)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7182432813389184)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Wiederholung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
'       update KTO_Paypal  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
'       update KTO_Tagesgeldkonto  set Wiederholung = :P195_Wiederholung where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7182840371389188)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7182473228389185)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_naechste_Zahlung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
unistr('       update "KTO_Girokonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
unistr('       update "KTO_Kreditkarte"  set N\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
unistr('       update "KTO_Paypal"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
unistr('       update "KTO_Tagesgeldkonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7182938250389189)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7183348980389193)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_naechste_Zahlung_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'       p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7183445709389194)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7293985529773022)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set "FK_Kategorie" = :P195_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set "FK_Kategorie" = :P195_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7293835883770584)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7679021652003298)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'   insert into t_rel_inventar_zahlung',
'   (',
'     fk_inventar,',
'     fk_main_key',
'   )',
'   select to_number(:P195_fk_inventar),',
'    apex_application.g_f01(i)',
'   from dual;',
'   commit;',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7678930179003297)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9560011246288088)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_inventar_zahlung where fk_inventar = to_number(:P195_fk_inventar) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(9559769802288086)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7941382027463095)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'   insert into t_rel_Projekt_zahlung',
'   (',
'     fk_projekt,',
'     fk_main_key',
'   )',
'   select to_number(:P195_fk_projekt),',
'    apex_application.g_f01(i)',
'   from dual;',
'   commit;',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7941354974463094)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10322913103821782)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_projekt_zahlung where fk_projekt = to_number(:P195_fk_projekt) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10322986068821783)
);
wwv_flow_api.component_end;
end;
/
