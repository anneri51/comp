prompt --application/pages/page_00307
begin
--   Manifest
--     PAGE: 00307
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>307
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>unistr('Belege\00FCbersicht_IR')
,p_alias=>unistr('BELEGE\00DCBERSICHT_IR99')
,p_step_title=>unistr('Belege\00FCbersicht_IR')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20201011160438'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8210851045291191)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8239996912302116)
,p_plug_name=>unistr('Belege\00FCbersicht_IR')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    apex_item.checkbox2(1,  inp_bel."PK_INP_BELEGE_ALL") sel,',
'    inp_bel."PK_INP_BELEGE_ALL", ',
'    inp_bel."FK_LEX_BUCHUNG",',
'    inp_bel."FK_KATEGORIE",',
'    inp_bel."FK_ARBEITSTAG",',
'    inp_bel."FK_BUCHUNG",',
'    inp_bel."FK_ZAHLUNGSART",',
'    inp_bel."FK_VERWENDUNGSZWECK",',
'    inp_bel."FK_INVENTAR",',
'    inp_bel."FK_PROJEKT",',
'    inp_bel."BELEGNUMMER",',
'    inp_bel."BEZEICHNUNG",',
'    inp_bel."FK_LAND",',
'    inp_bel."FK_CITY",',
'    inp_bel."BEL_DATUM",',
'    inp_bel."VON",',
'    inp_bel."BIS",',
'    inp_bel."NETTO_BETRAG",',
'    inp_bel."FK_STEUERSATZ",',
'    inp_bel."MWST_BETRAG",',
'    inp_bel."BRUTTO_BETRAG",',
'    inp_bel."FK_WAEHRUNG",',
'    inp_bel."STEUERNUMMER",',
'    inp_bel."FK_UMRECHNUNGSKURS",',
'    dbms_lob.substr(inp_bel."COMM_REST_BELEG",4000,1) "COMM_REST_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_TEL_BELEG",4000,1) "COMM_TEL_BELEG",',
'    dbms_lob.substr(inp_bel."COMM_PRODUKTE",4000,1) "COMM_PRODUKTE",',
unistr('    dbms_lob.substr(inp_bel."COMM_BEGR\00DCNDUNG",4000,1) "COMM_BEGR\00DCNDUNG",'),
'    dbms_lob.substr(inp_bel."COMM_SONSTIGES",4000,1) "COMM_SONSTIGES",',
'    dbms_lob.getlength("BELEG") "BELEG",',
'    dbms_lob.getlength("ZAHLUNGSBELEG") "ZAHLUNGSBELEG",',
'    inp_bel."LITER",',
unistr('    inp_bel."ZAPFS\00C4ULE",'),
'    inp_bel.FK_LOCATION,',
unistr('    inp_bel.PERS\00D6NLICH_VOR_ORT,'),
'    inp_bel.fk_beleg_ablage,',
'    abl_ord.jahr jahr_ordner,',
'    abl_ord.ordner_name,',
'    abl_ord_p.page_number,',
'  --  inp_bel.cnt_punkte,',
' --   inp_bel.cnt_punkte_geschaetzt,',
' --   inp_bel.punkte_von,',
'--    inp_bel.punkte_bis,',
'    inv.inventar,',
'     kat."Kategorie",',
'     pr.projekt,',
'     verw.verwendungszweck,',
'   --  bel.cnt_lex,',
'     inp_bel.FK_IMP_BA_BEL_OLD,',
'     inp_bel.fk_status,',
'     inp_bel.fk_zahlstatus,',
'   --  cnt_rel,',
'   --  cnt_rel_det,',
'    -- det,',
'     ''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':273:'' || V(''APP_SESSION'') || ''::NO:RP:P273_PK_PROJEKT,P273_PK_LOCATION,P273_PK_INP_BELEGE_ALL:'' || inp_bel.fk_projekt || '','' || inp_bel.fk_location || '','' ||  pk_inp_belege'
||'_all , P_CHECKSUM_TYPE => ''SESSION'') || ''">'' || fk_location || ''</a>'' fk_location1,',
'     vloc.ort,',
'     vloc.strasse,',
'     vloc.hsnr,',
'     vloc.land,',
'     vloc.ort loc_ort,',
'  fk_relation,',
'  wdh.std_name wiederholung',
'from "INP_BELEGE_ALL" inp_bel',
'  left join t_abl_ordner_page abl_ord_p on inp_bel.fk_abl_ordner_page = abl_ord_p.pk_abl_ordner_page',
'  left join t_abl_ordner abl_ord on abl_ord_p.fk_abl_ordner = abl_ord.pk_abl_ordner',
'  left join t_inventare inv on inp_bel.fk_inventar = inv.pk_inventar',
'  left join t_projekt pr on pr.pk_projekt = inp_bel.fk_projekt',
'  left join t_konto_buch_kat kat on kat.pk_konto_buch_kat = inp_bel.fk_kategorie',
'  left join t_verwendungszweck verw on verw.pk_verwendungszweck = inp_bel.fk_verwendungszweck',
'  left join v_location vloc on vloc.pk_location = inp_bel.fk_location',
'  --left join (select fk_inp_belege_all , case when count(*)  >0 then 1 else 0 end cnt_lex from  T_REL_LEX_KTO_BEL group by fk_inp_belege_all ) bel on inp_bel.pk_inp_belege_all = bel.fk_inp_belege_all ',
'  /*',
'  left join ( ',
'                    select fk_inp_belege_all',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) cnt_rel,',
'                     sum(case when fk_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) cnt_rel_det,',
'                     listagg( ''('' || rnr || ''/'' || det_cnt_rel_det || '') ok: '' || det_sum_rel,'', - '') within group ( order by fk_inp_belege_all) det',
'                     ',
'                     ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      left join (',
'                          select fk_inp_belege_all det',
'                          --, pk_rel_lex_kto_bel det1',
'                    ,',
'                    sum(case when pk_rel_lex_kto_bel is not null then 1 else 0 end) det_cnt_rel,',
'                     sum(case when fk_relation is not null then 1 else 0 end) + ',
'                     sum(case when fk_main_key is not null then 1 else 0 end) +',
'                     sum(case when fk_imp_ba_bel is not null then 1 else 0 end) +',
'                     sum(case when fk_inp_belege_all is not null then 1 else 0 end) det_cnt_rel_det,',
'                     row_number() over (partition by  fk_inp_belege_all order by fk_inp_belege_all) rnr,',
'                    sum(case when fk_relation is not null then 1 else 0 end) det_sum_rel',
'                     ',
'                     ',
'                    from t_rel_lex_kto_bel relbel',
'                      group by fk_inp_belege_all, pk_rel_lex_kto_bel',
'                      ',
'                      ) relbel_det on relbel_det.det = relbel.fk_inp_belege_all',
'                    group by fk_inp_belege_all',
'                    ',
'           ) ktobel on inp_bel.pk_inp_belege_all = ktobel.fk_inp_belege_all',
'           */',
'left join t_rel_lex_kto_bel  kto on inp_bel.pk_inp_belege_all = kto.fk_inp_belege_all',
'left join (select std_name, std_value',
'from t_std',
'where fk_std_group = 23) wdh on wdh.std_value = inp_bel.fk_la_wdh',
'--where instr(fk_relation,:P307_new)>0',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8240085955302116)
,p_name=>unistr('Belege\00FCbersicht_IR')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>9680405230693656
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8240576571302150)
,p_db_column_name=>'SEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8240956924302153)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8241380441302153)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8241696443302153)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8242168183302155)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8242541620302155)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8242909089302155)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8243295636302155)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8243754337302156)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8244114802302156)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8244548188302156)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8244939690302158)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8245283034302158)
,p_db_column_name=>'FK_LAND'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8245776919302158)
,p_db_column_name=>'FK_CITY'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8246173531302160)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8246486922302160)
,p_db_column_name=>'VON'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8246969668302160)
,p_db_column_name=>'BIS'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8247359334302161)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8247765882302161)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8248173660302161)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8248531416302163)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8248958931302163)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8249345002302164)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8249738416302164)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8250086584302164)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Comm Rest Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8250516416302166)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Comm Tel Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8250938082302166)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Comm Produkte'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8251379893302166)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8251757244302167)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Comm Sonstiges'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8252138426302167)
,p_db_column_name=>'BELEG'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Beleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8252562310302167)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Zahlungsbeleg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8252910775302169)
,p_db_column_name=>'LITER'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8253332499302169)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8253737102302170)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8254157716302170)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8254533773302170)
,p_db_column_name=>'FK_BELEG_ABLAGE'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Beleg Ablage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8254964591302172)
,p_db_column_name=>'JAHR_ORDNER'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Jahr Ordner'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8255301908302172)
,p_db_column_name=>'ORDNER_NAME'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Ordner Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8255757448302172)
,p_db_column_name=>'PAGE_NUMBER'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Page Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8257693413302175)
,p_db_column_name=>'INVENTAR'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8258085771302175)
,p_db_column_name=>'Kategorie'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8258558559302177)
,p_db_column_name=>'PROJEKT'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8258894525302177)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8259745954302178)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8260162785302178)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8260511416302178)
,p_db_column_name=>'FK_ZAHLSTATUS'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Fk Zahlstatus'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8262090431302181)
,p_db_column_name=>'FK_LOCATION1'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Fk Location1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8262550839302181)
,p_db_column_name=>'ORT'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8262948326302183)
,p_db_column_name=>'STRASSE'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8263377657302183)
,p_db_column_name=>'HSNR'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8263776576302183)
,p_db_column_name=>'LAND'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8264149389302185)
,p_db_column_name=>'LOC_ORT'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Loc Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8210647478291189)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>70
,p_column_identifier=>'BI'
,p_column_label=>'Fk Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8210763052291190)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>80
,p_column_identifier=>'BJ'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8264547779305395)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'97049'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_RELATION:BELEG:BEL_DATUM:BELEGNUMMER:BEZEICHNUNG:BIS:BRUTTO_BETRAG:COMM_BEGR\00DCNDUNG:COMM_PRODUKTE:COMM_REST_BELEG:COMM_SONSTIGES:COMM_TEL_BELEG:FK_ARBEITSTAG:FK_BELEG_ABLAGE:FK_BUCHUNG:FK_CITY:FK_IMP_BA_BEL_OLD:FK_INVENTAR:FK_KATEGORIE:FK_LAND:FK_L')
||'EX_BUCHUNG:FK_LOCATION:FK_LOCATION1:FK_PROJEKT:FK_STATUS:FK_STEUERSATZ:FK_UMRECHNUNGSKURS:FK_VERWENDUNGSZWECK:FK_WAEHRUNG:FK_ZAHLSTATUS:FK_ZAHLUNGSART:HSNR:INVENTAR:JAHR_ORDNER:Kategorie:LAND:LITER:LOC_ORT:MWST_BETRAG:NETTO_BETRAG:ORDNER_NAME:ORT:PAG'
||unistr('E_NUMBER:PERS\00D6NLICH_VOR_ORT:PK_INP_BELEGE_ALL:PROJEKT:SEL:STEUERNUMMER:STRASSE:VERWENDUNGSZWECK:VON:ZAHLUNGSBELEG:ZAPFS\00C4ULE:WIEDERHOLUNG:')
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8281991458850680)
,p_report_id=>wwv_flow_api.id(8264547779305395)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_RELATION'
,p_operator=>'contains'
,p_expr=>'697'
,p_condition_sql=>'upper("FK_RELATION") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''697''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8282433263850681)
,p_report_id=>wwv_flow_api.id(8264547779305395)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR_ORDNER'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR_ORDNER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8282783388850681)
,p_report_id=>wwv_flow_api.id(8264547779305395)
,p_name=>'Row text contains ''697'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'697'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8210925018291192)
,p_name=>'P307_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8210851045291191)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
