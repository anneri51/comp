prompt --application/shared_components/navigation/breadcrumbs/kontoauszug
begin
--   Manifest
--     MENU: Kontoauszug
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(19505524428620584)
,p_name=>'Kontoauszug'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(19505871481623776)
,p_parent_id=>0
,p_short_name=>unistr('Kontoauszug \00DCbersicht')
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:::'
,p_page_id=>94
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(19506074994626208)
,p_parent_id=>wwv_flow_api.id(19505871481623776)
,p_short_name=>'Kontoauszug'
,p_link=>'f?p=&APP_ID.:95:&SESSION.::&DEBUG.:::'
,p_page_id=>95
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(19506256287628381)
,p_parent_id=>wwv_flow_api.id(19505871481623776)
,p_short_name=>'Kontoauszug bearbeiten'
,p_link=>'f?p=&APP_ID.:431:&SESSION.::&DEBUG.:::'
,p_page_id=>431
);
wwv_flow_api.component_end;
end;
/
