prompt --application/shared_components/user_interface/lovs/lov_fk_main_key_buchung
begin
--   Manifest
--     LOV_FK_MAIN_KEY_BUCHUNG
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(19571730356068619)
,p_lov_name=>'LOV_FK_MAIN_KEY_BUCHUNG'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'from v_kto_konten_zus'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
