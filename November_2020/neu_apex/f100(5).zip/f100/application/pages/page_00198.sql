prompt --application/pages/page_00198
begin
--   Manifest
--     PAGE: 00198
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>198
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Buchung_Kategorie'
,p_step_title=>'Buchung_Kategorie'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200622124052'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6665115183760115)
,p_plug_name=>'Buchung_Kategorie'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'      apex_item.checkbox2(1, kto.fk_main_key) sel,',
'      apex_item.checkbox2(2, kto.fk_main_key || '','' || kto.FK_std_kto_Kontotyp) sel2,',
'      ''<b>'' || Kategorie || ''</b>'' || '' '' || "BUCHUNGSTEXT" as title, ',
'      kto.fk_main_Key,',
'      fk_std_contr_status,',
'      case when ckz.fk_std_contr_status =1 then ''OK'' else ''NOK'' end contr,',
'      Kontotyp,',
'      round("Betrag",2) Wert,',
'      "Buchungstag",',
'      bucht_jahr,',
'      bucht_monat,',
'      bucht_tag,',
'      Kategorie,',
'      kto.FK_std_kto_Kontotyp',
'from V_kto_KONTEN_ZUS kto',
' left join t_contr_Kategorie_zahlung ckz on kto.fk_main_key = ckz.fk_main_key',
'order by 1',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6629976663819883)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15940111904240804
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630098004819884)
,p_db_column_name=>'TITLE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630200212819885)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630340737819886)
,p_db_column_name=>'SEL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630506801819888)
,p_db_column_name=>'CONTR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Contr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6730088037156729)
,p_db_column_name=>'WERT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6867860120995480)
,p_db_column_name=>'Buchungstag'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7047179796518515)
,p_db_column_name=>'SEL2'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7002432440079578)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7002518780079579)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7002654444079580)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7002711751079581)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281791768707981)
,p_db_column_name=>'FK_STD_CONTR_STATUS'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Fk Std Contr Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50281953468707982)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50282072712707983)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6670487498823582)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'159807'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:TITLE:FK_MAIN_KEY:WERT:CONTR:Buchungstag::BUCHT_JAHR:BUCHT_MONAT:BUCHT_TAG:KATEGORIE:FK_STD_CONTR_STATUS:KONTOTYP:FK_STD_KTO_KONTOTYP'
,p_sort_column_1=>'TITLE'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7089221207964647)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CONTR'
,p_operator=>'='
,p_expr=>'OK'
,p_condition_sql=>' (case when ("CONTR" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''OK''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7089635988964647)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_name=>'OK_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7090009004964648)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_name=>'UPD_KAT_SEL'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7088417096964645)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_STATUS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7088845248964646)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STATUS'
,p_operator=>'is null'
,p_condition_sql=>'"FK_STATUS" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7090368589964649)
,p_report_id=>wwv_flow_api.id(6670487498823582)
,p_name=>'Row text contains ''Restaurant'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Restaurant'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7046798772518511)
,p_plug_name=>unistr('Kategorie \00E4ndern')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6630592950819889)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6665115183760115)
,p_button_name=>'OK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7047061789518513)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7046798772518511)
,p_button_name=>'Update_Kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Update kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6665465143760118)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6665115183760115)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6666772711760124)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6665115183760115)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7046933119518512)
,p_name=>'P198_FK_KATEGORIE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7046798772518511)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_konto_buch',
'from t_bas_kat_konto_buch',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6665915252760121)
,p_name=>'CONTRACT_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6665465143760118)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6666439431760123)
,p_event_id=>wwv_flow_api.id(6665915252760121)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6665115183760115)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6667211757760124)
,p_name=>'EXPAND_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6666772711760124)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6667721364760125)
,p_event_id=>wwv_flow_api.id(6667211757760124)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6665115183760115)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6630727623819890)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status',
'      )',
'      select apex_application.g_f01(i),',
'      1',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7047098498518514)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
'       update KTO_Girokonto  set "FK_Kategorie" = :P198_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
'       update KTO_Kreditkarte  set "FK_Kategorie" = :P198_FK_Kategorie where  fk_main_key = v_fk_main_key;',
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
