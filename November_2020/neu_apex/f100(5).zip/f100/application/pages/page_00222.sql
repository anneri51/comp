prompt --application/pages/page_00222
begin
--   Manifest
--     PAGE: 00222
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>222
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kontrolle'
,p_step_title=>'Kontrolle'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42901582232549956)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200623090757'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9019647245002269)
,p_plug_name=>'Kontrolle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_CONTR_KONTROLLE,',
'       JAHR,',
'       KONTO,',
'       FINALISIERUNGSDATUM,',
'       BELEGDAT,',
'       BUCHDAT,',
'       PERIODE,',
'      -- BELEGNUMMERNKREIS,',
'       BELEGNR,',
'       BUCHUNGSTEXT,',
'    --   BUCHUNGSBETRAG,',
'       SOLLKTO,',
'       HABENKTO,',
'       STEUERSCHLUESSEL,',
'       Kst,',
'       Ktr,',
'       betrag,',
'   --    WAEHRUNG,',
'     --  ZUSATZANGABEN,',
'      -- OK,',
'       fk_lex_STORNO,',
'       relation,',
'       BEMERKUNGEN,',
'       DATUM_OK',
'  from V_CONTR_KONTROLLE'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9019706655002269)
,p_name=>'Kontrolle'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18329841895423190
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9020560218002284)
,p_db_column_name=>'JAHR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9020879006002285)
,p_db_column_name=>'KONTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9021267650002285)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9023708185002287)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9028917342002294)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9029364205002295)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806335862550102)
,p_db_column_name=>'PK_CONTR_KONTROLLE'
,p_display_order=>34
,p_column_identifier=>'Y'
,p_column_label=>'Pk Contr Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806419605550103)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>44
,p_column_identifier=>'Z'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806562374550104)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>54
,p_column_identifier=>'AA'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806633612550105)
,p_db_column_name=>'PERIODE'
,p_display_order=>64
,p_column_identifier=>'AB'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806737840550106)
,p_db_column_name=>'BELEGNR'
,p_display_order=>74
,p_column_identifier=>'AC'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806816280550107)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>84
,p_column_identifier=>'AD'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50806924540550108)
,p_db_column_name=>'HABENKTO'
,p_display_order=>94
,p_column_identifier=>'AE'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50807071841550109)
,p_db_column_name=>'STEUERSCHLUESSEL'
,p_display_order=>104
,p_column_identifier=>'AF'
,p_column_label=>'Steuerschluessel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50807178862550110)
,p_db_column_name=>'KST'
,p_display_order=>114
,p_column_identifier=>'AG'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50890300931158761)
,p_db_column_name=>'KTR'
,p_display_order=>124
,p_column_identifier=>'AH'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50890453457158762)
,p_db_column_name=>'BETRAG'
,p_display_order=>134
,p_column_identifier=>'AI'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50890547542158763)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>144
,p_column_identifier=>'AJ'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50890596731158764)
,p_db_column_name=>'RELATION'
,p_display_order=>154
,p_column_identifier=>'AK'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9029679967002960)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'183399'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:KONTO:FINALISIERUNGSDATUMUM:BUCHUNGSBELEGNUMMERNKREIS:BUCHUNGSTEXT:BUCHUNGSSOLLKONTO:BEMERKUNGEN:DATUM_OK:PK_CONTR_KONTROLLE:BELEGDAT:BUCHDAT:PERIODE:BELEGNR:SOLLKTO:HABENKTO:STEUERSCHLUESSEL:KST:KTR:BETRAG:FK_LEX_STORNO:RELATION'
,p_break_on=>'KONTO'
,p_break_enabled_on=>'KONTO'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(9030781187018577)
,p_report_id=>wwv_flow_api.id(9029679967002960)
,p_pivot_columns=>'OK:STORNO'
,p_row_columns=>'KONTO:FINALISIERUNGSDATUM'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(9031174802018577)
,p_pivot_id=>wwv_flow_api.id(9030781187018577)
,p_display_seq=>1
,p_function_name=>'COUNT'
,p_column_name=>'PK_LEX'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9061310142326461)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Pivot'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'183715'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:KONTO:FINALISIERUNGSDATUM:BUCHUNGSTEXT:BEMERKUNGEN:DATUM_OK'
,p_break_on=>'KONTO'
,p_break_enabled_on=>'KONTO'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(50920454319177330)
,p_report_id=>wwv_flow_api.id(9061310142326461)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'KONTO:FINALISIERUNGSDATUM'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(50920875493177331)
,p_pivot_id=>wwv_flow_api.id(50920454319177330)
,p_display_seq=>1
,p_function_name=>'COUNT'
,p_column_name=>'BELEGNR'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.component_end;
end;
/
