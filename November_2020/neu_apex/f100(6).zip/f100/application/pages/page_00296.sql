prompt --application/pages/page_00296
begin
--   Manifest
--     PAGE: 00296
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>296
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Zugeordnete_Buchung'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Zugeordnete_Buchung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42875355428359647)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090057'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3640298779291383)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3640573647291385)
,p_plug_name=>'Buchungsinformationen'
,p_parent_plug_id=>wwv_flow_api.id(3640298779291383)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_LEX_KTO_BEL,',
'       BELEGDAT,',
'       LEX_BELEG,',
'       BETRAGEUR,',
'       BUCHDAT,',
'       NR,',
'       HABENEUR,',
'       JOUR_DAT,',
'       RELATION,',
'       SOLLEUR,',
'       SOLL,',
'       v_rel_lex.UST,',
'       v_rel_lex.UST_KTO,',
'       v_rel_lex.UST_KTO_H,',
'       v_rel_lex.UST_KTO_S,',
'       PERIODE,',
'       BELEGNR,',
'       BUCHUNGSTEXT,',
'       BETRAG,',
'       WHRG,',
'       SOLLKTO,',
'       HABENKTO,',
'       KST,',
'       KTR,',
'       JAHR,',
'       ABL_ORD_JAHR,',
'       ABL_ORD_J_PAGE_NUMBER,',
'       ABL_ORD_ORDNER_NAME,',
'       ABL_ORD_PAGE_NUMBER,',
'       ABL_ORD_PK_ABL_ORDNER,',
'       ABL_ORD_PK_ABL_ORDNER_PAGE,',
'       ARB_BIS_DATUM,',
'       ARB_BIS_FK_ARBEITSTAG,',
'       ARB_BIS_JAHR,',
'       ARB_BIS_MONAT,',
'       ARB_BIS_TAG,',
'       ARB_DATUM,',
'       ARB_FK_ARBEITSTAG,',
'       ARB_JAHR,',
'       ARB_MONAT,',
'       ARB_TAG,',
'       ARB_VON_DATUM,',
'       ARB_VON_JAHR,',
'       ARB_VON_MONAT,',
'       ARB_VON_TAG,',
'       BANK,',
'       BEL_DATUM,',
'       BELEG,',
'       BELEGNUMMER,',
'       BELEG_UHRZEIT,',
'       BEL_EX_NAME,',
'       BEL_EX_VALUE,',
'       BEZEICHNUNG,',
'       BIS,',
'       BIS_UHRZEIT,',
'       BRUTTO_BETRAG,',
'       BRUTTO_BETRAG_EUR,',
'       BRUTTO_BETRAG_INCL_TRINKG,',
'       BRUTTO_INCL_TRINKG_EUR,',
'       CI_LAND,',
'       CI_PK_LAND,',
'       CNT_PUNKTE,',
'       CNT_PUNKTE_GESCHAETZT,',
'       FK_CITY,',
'       FK_FRMDW,',
'       FK_FRMDW_MWST_SATZ,',
'       FK_IMP_BA_BEL_OLD,',
'       FK_INVENTAR,',
'       FK_KATEGORIE,',
'       FK_LA_KONTO,',
'       FK_LAND,',
'       FK_LA_WDH,',
'       FK_LEX_BUCHUNG,',
'       FK_LOCATION,',
'       FK_LOCATION_VERG,',
'       FK_PROJEKT,',
'       FK_REAL_BELEG_EXIST,',
'       FK_STATUS,',
'       FK_STEUERSATZ,',
'       FK_UMRECHNUNGSKURS,',
'       FK_VERWENDUNGSZWECK,',
'       FK_VON_ARBEITSTAG,',
'       FK_WAEHRUNG,',
'       FK_ZAHLUNGSART,',
'       FRMDW_BRUTTO_BETRAG,',
'       FRMDW_BRUTTO_INCL_TRINKG,',
'       FRMDW_MWST_BETRAG,',
'       FRMDW_NETTO_BETRAG,',
'       IBAN,',
'       INP_BEL_ALL_JAHR,',
'       KTOKAT_KATEGORIE,',
'       KUNDENNUMMER,',
'       LA_DATUM,',
'       LAND,',
'       LA_WDH_NAME,',
'       LA_WDH_VALUE,',
'       LITER,',
'       MENGENEINHEIT,',
'       MWST_BETRAG,',
'       MWST_BETRAG_EUR,',
'       NETTO_BETRAG,',
'       NETTO_BETRAG_EUR,',
'       ORT,',
unistr('       "PERS\00D6NLICH_VOR_ORT",'),
'       PK_BANK,',
'       PK_BANKKONTO,',
'       PK_INP_BELEGE_ALL,',
'       PK_KONTO_BUCH_KAT,',
'       PK_LAND,',
'       PK_ORT,',
'       PK_VERWENDUNGSZWECK,',
'       PK_WAEHRUNG,',
'       PREIS_PRO_MENGE,',
'       PROJ_AUFT_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_AUFT_GESCHAEFTSPARTNER,',
'       PROJ_AUFT_GESCHAEFTSPARTNERTYP,',
'       PROJ_AUFT_PK_GESCHAEFTSPARTNER,',
'       PROJ_AUFT_PK_REL_GP_KONT,',
'       PROJ_BIS,',
'       PROJ_FK_AUFTRAGGEBER,',
'       PROJ_FK_PROJEKTPARTNER_1,',
'       PROJ_FK_PROJEKTPARTNER_2,',
'       PROJ_KM_GERECHNET,',
'       PROJ_PK_PROJEKT,',
'       PROJ_PP1_BESCHREIBUNG,',
'       PROJ_PP1_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP1_GESCHAEFTSPARTNER,',
'       PROJ_PP1_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP1_PK_REL_GP_KONT,',
'       PROJ_PP2_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP2_GESCHAEFTSPARTNER,',
'       PROJ_PP2_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP2_PK_GESCHAEFTSPARTNER,',
'       PROJ_PP2_PK_REL_GP_KONT,',
'       PROJ_PROJEKT,',
'       PROJ_PROJEKT_ABGESCHLOSSEN,',
'       PROJ_PROJEKT_ART,',
'       PROJ_PSP_ELEMENT,',
'       PROJ_RECHNUNG_GESTELLT,',
'       PROJ_VON,',
'       PROJ_ZAHLUNG_ABGESCHLOSSEN,',
'       PUNKTE_BIS,',
'       PUNKTE_VON,',
'       STA_NAME,',
'       STA_VALUE,',
'       STEUERNUMMER,',
'       STEU_FRMD_LAND,',
'       STEU_FRMD_PK_LAND,',
'       STEU_FRMD_PK_STEUERSATZ,',
'       STEU_FRMD_STEUERSATZ,',
'       STEU_FRMD_ZUS_ST,',
'       STEU_LAND,',
'       STEU_PK_LAND,',
'       STEU_PK_STEUERSATZ,',
'       STEU_STEUERSATZ,',
'       STEU_ZUS_ST,',
'       TANKSTELLEN_NR,',
'       VBEL_ART,',
'       VBEL_BETRAG,',
'       VBEL_BEZEICHNUNG,',
'       VBEL_DATUM,',
'       VBEL_DATUM_VERGEHEN,',
'       VBEL_FK_ARBEITSTAG,',
'       VBEL_FK_BUCHUNG,',
'       VBEL_FK_IMP_BA_BEL,',
'       VBEL_FK_INVENTAR,',
'       VBEL_FK_KATEGORIE,',
'       VBEL_FK_PROJEKT,',
'       VBEL_INVENTAR,',
'       VBEL_KATEGORIE,',
'       VBEL_KENNZEICHEN,',
'       VBEL_MWST_BETRAG,',
'       VBEL_NETTO,',
'       VBEL_PK_IMP_BA_ALLG_BEL,',
'       VBEL_PROJEKT,',
'       VBEL_STEUERSATZ,',
'       VBEL_VERWENDUNGSZWECK,',
unistr('       "VBEL_W\00C4HRUNG",'),
unistr('       "VBEL_W\00C4HRUNG_BETRAG",'),
'       VBEL_ZAHLUNGSART,',
'       VERWENDUNGSZWECK,',
'       VLOC_ADR,',
'       VLOC_BESCHREIBUNG,',
'       VLOC_FK_ADRESSE,',
'       VLOC_FK_LOCATION_TYPE,',
'       VLOC_HSNR,',
'       VLOC_LAND,',
'       VLOC_LOCATION,',
'       VLOC_LOCATION_TYPE,',
'       VLOC_ORT,',
'       VLOC_PK_LOCATION,',
'       VLOC_PLZ,',
'       VLOC_POSTFACH,',
'       VLOC_STRASSE,',
'       VLOC_VERG_ADR,',
'       VLOC_VERG_BESCHREIBUNG,',
'       VLOC_VERG_FK_ADRESSE,',
'       VLOC_VERG_FK_LOCATION_TYPE,',
'       VLOC_VERG_HSNR,',
'       VLOC_VERG_LAND,',
'       VLOC_VERG_LOCATION,',
'       VLOC_VERG_LOCATION_TYPE,',
'       VLOC_VERG_ORT,',
'       VLOC_VERG_PK_LOCATION,',
'       VLOC_VERG_PLZ,',
'       VLOC_VERG_POSTFACH,',
'       VLOC_VERG_STRASSE,',
'       VON,',
'       VON_UHRZEIT,',
'       WAEHRUNG,',
'       WAEHRUNG_LANG,',
'       ZAHL_ART_NAME,',
'       ZAHL_ART_VAL,',
'       ZAHLUNGSBELEG,',
unistr('       "ZAPFS\00C4ULE",'),
'       FK_MAIN_KEY,',
'       KTO_ID,',
'       "Buchungstag",',
'       KTO_BETRAG,',
unistr('       "W\00E4hrung",'),
unistr('       "Fremdw\00E4hrungsbetrag",'),
unistr('       "Fremdw\00E4hrung",'),
'       KTO_BUCHUNGSTEXT,',
'       "FK_Kategorie",',
'       "FK_Verwendungszweck",',
'       "FK_Kontotyp",',
'       FK_BUCHUNGSTAG,',
'       FK_WERTSTELLUNG,',
'       KTO_VERWENDUNGSZWECK,',
'       KTO_KATEGORIE,',
'       BUCHT_TAG,',
'       BUCHT_MONAT,',
'       BUCHT_JAHR,',
'       BUCHT_DATUM,',
'       WERTT_TAG,',
'       WERTT_MONAT,',
'       WERTT_JAHR,',
'       WERTT_DATUM,',
'       "Kontotyp",',
'       FK_VORGANG,',
'       WIEDERHOLUNG,',
'       NAECHSTE_ZAHLUNG,',
'       FK_BUCHUNG_STEUER,',
'       FK_IMP_BA_BEL,',
'       FK_REL_LEX_KTO_BEL,',
'       STATUS,',
'       FK_ZAHLSTATUS,',
'       FK_INP_BELEGE_POS_ALL,',
'       kto1.KONTENBEZEICHNUNG sl_KONTENBEZEICHNUNG,',
'kto1.KONTENKATEGORIE sl_kontenkategorie,',
'kto1.KONTENUNTERART sl_kontenunterart,',
'kto1.ZUORDNUNG_EUE sl_zuordnung_eue,',
' kto2.KONTENBEZEICHNUNG hb_KONTENBEZEICHNUNG,',
'kto2.KONTENKATEGORIE hb_kontenkategorie,',
'kto2.KONTENUNTERART hb_kontenunterart,',
'kto2.ZUORDNUNG_EUE hb_zuordnung_eue',
'  from V_REL_LEX',
'    left join t_lex_kontenplan kto1 on kto1.konto_nummer = v_rel_lex.sollkto',
'    left join t_lex_kontenplan kto2 on kto2.konto_nummer = v_rel_lex.habenkto',
' where fk_main_key = :P296_fk_main_key1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3640838703291388)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>5081157978682928
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3640962882291389)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3640996198291390)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641085736291391)
,p_db_column_name=>'LEX_BELEG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Lex Beleg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641269735291392)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641340867291393)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641399582291394)
,p_db_column_name=>'NR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641505926291395)
,p_db_column_name=>'HABENEUR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641633001291396)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641717102291397)
,p_db_column_name=>'RELATION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641817058291398)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3641891199291399)
,p_db_column_name=>'SOLL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642011246291400)
,p_db_column_name=>'UST'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642165235291401)
,p_db_column_name=>'UST_KTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642243204291402)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642297142291403)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642398812291404)
,p_db_column_name=>'PERIODE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642508216291405)
,p_db_column_name=>'BELEGNR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642653760291406)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642699107291407)
,p_db_column_name=>'BETRAG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642806338291408)
,p_db_column_name=>'WHRG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3642936389291409)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3643024732291410)
,p_db_column_name=>'HABENKTO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557119619174661)
,p_db_column_name=>'KST'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557279441174662)
,p_db_column_name=>'KTR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557377941174663)
,p_db_column_name=>'JAHR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557460858174664)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557530086174665)
,p_db_column_name=>'ABL_ORD_J_PAGE_NUMBER'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Abl Ord J Page Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557668022174666)
,p_db_column_name=>'ABL_ORD_ORDNER_NAME'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Abl Ord Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557709791174667)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557820009174668)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Abl Ord Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6557899305174669)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558031337174670)
,p_db_column_name=>'ARB_BIS_DATUM'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Arb Bis Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558121861174671)
,p_db_column_name=>'ARB_BIS_FK_ARBEITSTAG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Arb Bis Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558256610174672)
,p_db_column_name=>'ARB_BIS_JAHR'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Arb Bis Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558317167174673)
,p_db_column_name=>'ARB_BIS_MONAT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Arb Bis Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558470595174674)
,p_db_column_name=>'ARB_BIS_TAG'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Arb Bis Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558490182174675)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558642834174676)
,p_db_column_name=>'ARB_FK_ARBEITSTAG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Arb Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558756810174677)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558879542174678)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6558976990174679)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559004905174680)
,p_db_column_name=>'ARB_VON_DATUM'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Arb Von Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559107561174681)
,p_db_column_name=>'ARB_VON_JAHR'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Arb Von Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559202795174682)
,p_db_column_name=>'ARB_VON_MONAT'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Arb Von Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559292142174683)
,p_db_column_name=>'ARB_VON_TAG'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Arb Von Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559413017174684)
,p_db_column_name=>'BANK'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559541617174685)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559614492174686)
,p_db_column_name=>'BELEG'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559705641174687)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559785624174688)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6559953114174689)
,p_db_column_name=>'BEL_EX_NAME'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Bel Ex Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560032834174690)
,p_db_column_name=>'BEL_EX_VALUE'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Bel Ex Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560179642174691)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560238618174692)
,p_db_column_name=>'BIS'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560370080174693)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560386285174694)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560490674174695)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560645704174696)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560704923174697)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560803568174698)
,p_db_column_name=>'CI_LAND'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Ci Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6560887290174699)
,p_db_column_name=>'CI_PK_LAND'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Ci Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561048237174700)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561091656174701)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561206838174702)
,p_db_column_name=>'FK_CITY'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561300155174703)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561382898174704)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561503641174705)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561617406174706)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561701127174707)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561862806174708)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6561903671174709)
,p_db_column_name=>'FK_LAND'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562017389174710)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562167940174661)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562244566174662)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562303969174663)
,p_db_column_name=>'FK_LOCATION_VERG'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562427458174664)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562514260174665)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562606323174666)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562715825174667)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562801694174668)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6562940234174669)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563011834174670)
,p_db_column_name=>'FK_VON_ARBEITSTAG'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Fk Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563115244174671)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563262098174672)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563313140174673)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563402644174674)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563481296174675)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563591742174676)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563750802174677)
,p_db_column_name=>'IBAN'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563811980174678)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6563945141174679)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564027444174680)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564161142174681)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564181237174682)
,p_db_column_name=>'LAND'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564374677174683)
,p_db_column_name=>'LA_WDH_NAME'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'La Wdh Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564422815174684)
,p_db_column_name=>'LA_WDH_VALUE'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'La Wdh Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564487182174685)
,p_db_column_name=>'LITER'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564617941174686)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564778802174687)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564787980174688)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6564925601174689)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565000024174690)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565172712174691)
,p_db_column_name=>'ORT'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565199683174692)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565290083174693)
,p_db_column_name=>'PK_BANK'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Pk Bank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565445480174694)
,p_db_column_name=>'PK_BANKKONTO'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Pk Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565537229174695)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565667978174696)
,p_db_column_name=>'PK_KONTO_BUCH_KAT'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Pk Konto Buch Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565768560174697)
,p_db_column_name=>'PK_LAND'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565834866174698)
,p_db_column_name=>'PK_ORT'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Pk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6565919603174699)
,p_db_column_name=>'PK_VERWENDUNGSZWECK'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Pk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566033985174700)
,p_db_column_name=>'PK_WAEHRUNG'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Pk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566115442174701)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566219809174702)
,p_db_column_name=>'PROJ_AUFT_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Proj Auft Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566286015174703)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNER'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Proj Auft Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566455260174704)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNERTYP'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Proj Auft Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566527782174705)
,p_db_column_name=>'PROJ_AUFT_PK_GESCHAEFTSPARTNER'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Proj Auft Pk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566662431174706)
,p_db_column_name=>'PROJ_AUFT_PK_REL_GP_KONT'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Proj Auft Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566756638174707)
,p_db_column_name=>'PROJ_BIS'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Proj Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566829247174708)
,p_db_column_name=>'PROJ_FK_AUFTRAGGEBER'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Proj Fk Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566965250174709)
,p_db_column_name=>'PROJ_FK_PROJEKTPARTNER_1'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Proj Fk Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6566984191174710)
,p_db_column_name=>'PROJ_FK_PROJEKTPARTNER_2'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Proj Fk Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567103069174661)
,p_db_column_name=>'PROJ_KM_GERECHNET'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Proj Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567258811174662)
,p_db_column_name=>'PROJ_PK_PROJEKT'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Proj Pk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567357988174663)
,p_db_column_name=>'PROJ_PP1_BESCHREIBUNG'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Proj Pp1 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567405611174664)
,p_db_column_name=>'PROJ_PP1_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Proj Pp1 Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567574737174665)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNER'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Proj Pp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567661849174666)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNERTYP'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Proj Pp1 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567702018174667)
,p_db_column_name=>'PROJ_PP1_PK_REL_GP_KONT'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Proj Pp1 Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567849344174668)
,p_db_column_name=>'PROJ_PP2_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Proj Pp2 Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6567908231174669)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNER'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Proj Pp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568026933174670)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNERTYP'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Proj Pp2 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568082922174671)
,p_db_column_name=>'PROJ_PP2_PK_GESCHAEFTSPARTNER'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Proj Pp2 Pk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568257888174672)
,p_db_column_name=>'PROJ_PP2_PK_REL_GP_KONT'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Proj Pp2 Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568375285174673)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568434099174674)
,p_db_column_name=>'PROJ_PROJEKT_ABGESCHLOSSEN'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Proj Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568548150174675)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568672189174676)
,p_db_column_name=>'PROJ_PSP_ELEMENT'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Proj Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568716776174677)
,p_db_column_name=>'PROJ_RECHNUNG_GESTELLT'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Proj Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568876207174678)
,p_db_column_name=>'PROJ_VON'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Proj Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6568908055174679)
,p_db_column_name=>'PROJ_ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Proj Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569037467174680)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569167849174681)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569268389174682)
,p_db_column_name=>'STA_NAME'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Sta Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569342643174683)
,p_db_column_name=>'STA_VALUE'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Sta Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569447018174684)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569521254174685)
,p_db_column_name=>'STEU_FRMD_LAND'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Steu Frmd Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569609252174686)
,p_db_column_name=>'STEU_FRMD_PK_LAND'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Steu Frmd Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569686316174687)
,p_db_column_name=>'STEU_FRMD_PK_STEUERSATZ'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Steu Frmd Pk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569785139174688)
,p_db_column_name=>'STEU_FRMD_STEUERSATZ'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Steu Frmd Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569964156174689)
,p_db_column_name=>'STEU_FRMD_ZUS_ST'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Steu Frmd Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6569988631174690)
,p_db_column_name=>'STEU_LAND'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Steu Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570175326174691)
,p_db_column_name=>'STEU_PK_LAND'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Steu Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570267611174692)
,p_db_column_name=>'STEU_PK_STEUERSATZ'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Steu Pk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570335453174693)
,p_db_column_name=>'STEU_STEUERSATZ'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Steu Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570395738174694)
,p_db_column_name=>'STEU_ZUS_ST'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Steu Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570506414174695)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570680176174696)
,p_db_column_name=>'VBEL_ART'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Vbel Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570716100174697)
,p_db_column_name=>'VBEL_BETRAG'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Vbel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570787640174698)
,p_db_column_name=>'VBEL_BEZEICHNUNG'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Vbel Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6570886304174699)
,p_db_column_name=>'VBEL_DATUM'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Vbel Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571049839174700)
,p_db_column_name=>'VBEL_DATUM_VERGEHEN'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Vbel Datum Vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571135892174701)
,p_db_column_name=>'VBEL_FK_ARBEITSTAG'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Vbel Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571188926174702)
,p_db_column_name=>'VBEL_FK_BUCHUNG'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Vbel Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571356734174703)
,p_db_column_name=>'VBEL_FK_IMP_BA_BEL'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Vbel Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571422897174704)
,p_db_column_name=>'VBEL_FK_INVENTAR'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Vbel Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571575042174705)
,p_db_column_name=>'VBEL_FK_KATEGORIE'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Vbel Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571638362174706)
,p_db_column_name=>'VBEL_FK_PROJEKT'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Vbel Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571728767174707)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571864490174708)
,p_db_column_name=>'VBEL_KATEGORIE'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Vbel Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6571945128174709)
,p_db_column_name=>'VBEL_KENNZEICHEN'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Vbel Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572001298174710)
,p_db_column_name=>'VBEL_MWST_BETRAG'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Vbel Mwst Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572084208174661)
,p_db_column_name=>'VBEL_NETTO'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Vbel Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572228429174662)
,p_db_column_name=>'VBEL_PK_IMP_BA_ALLG_BEL'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Vbel Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572324799174663)
,p_db_column_name=>'VBEL_PROJEKT'
,p_display_order=>1750
,p_column_identifier=>'FS'
,p_column_label=>'Vbel Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572445893174664)
,p_db_column_name=>'VBEL_STEUERSATZ'
,p_display_order=>1760
,p_column_identifier=>'FT'
,p_column_label=>'Vbel Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572571113174665)
,p_db_column_name=>'VBEL_VERWENDUNGSZWECK'
,p_display_order=>1770
,p_column_identifier=>'FU'
,p_column_label=>'Vbel Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572602689174666)
,p_db_column_name=>unistr('VBEL_W\00C4HRUNG')
,p_display_order=>1780
,p_column_identifier=>'FV'
,p_column_label=>unistr('Vbel W\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572757068174667)
,p_db_column_name=>unistr('VBEL_W\00C4HRUNG_BETRAG')
,p_display_order=>1790
,p_column_identifier=>'FW'
,p_column_label=>unistr('Vbel W\00E4hrung Betrag')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572861678174668)
,p_db_column_name=>'VBEL_ZAHLUNGSART'
,p_display_order=>1800
,p_column_identifier=>'FX'
,p_column_label=>'Vbel Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6572885848174669)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>1810
,p_column_identifier=>'FY'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573035568174670)
,p_db_column_name=>'VLOC_ADR'
,p_display_order=>1820
,p_column_identifier=>'FZ'
,p_column_label=>'Vloc Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573178940174671)
,p_db_column_name=>'VLOC_BESCHREIBUNG'
,p_display_order=>1830
,p_column_identifier=>'GA'
,p_column_label=>'Vloc Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573224337174672)
,p_db_column_name=>'VLOC_FK_ADRESSE'
,p_display_order=>1840
,p_column_identifier=>'GB'
,p_column_label=>'Vloc Fk Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573377649174673)
,p_db_column_name=>'VLOC_FK_LOCATION_TYPE'
,p_display_order=>1850
,p_column_identifier=>'GC'
,p_column_label=>'Vloc Fk Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573472329174674)
,p_db_column_name=>'VLOC_HSNR'
,p_display_order=>1860
,p_column_identifier=>'GD'
,p_column_label=>'Vloc Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573496251174675)
,p_db_column_name=>'VLOC_LAND'
,p_display_order=>1870
,p_column_identifier=>'GE'
,p_column_label=>'Vloc Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573626721174676)
,p_db_column_name=>'VLOC_LOCATION'
,p_display_order=>1880
,p_column_identifier=>'GF'
,p_column_label=>'Vloc Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573743557174677)
,p_db_column_name=>'VLOC_LOCATION_TYPE'
,p_display_order=>1890
,p_column_identifier=>'GG'
,p_column_label=>'Vloc Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573863239174678)
,p_db_column_name=>'VLOC_ORT'
,p_display_order=>1900
,p_column_identifier=>'GH'
,p_column_label=>'Vloc Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6573893372174679)
,p_db_column_name=>'VLOC_PK_LOCATION'
,p_display_order=>1910
,p_column_identifier=>'GI'
,p_column_label=>'Vloc Pk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574003741174680)
,p_db_column_name=>'VLOC_PLZ'
,p_display_order=>1920
,p_column_identifier=>'GJ'
,p_column_label=>'Vloc Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574171985174681)
,p_db_column_name=>'VLOC_POSTFACH'
,p_display_order=>1930
,p_column_identifier=>'GK'
,p_column_label=>'Vloc Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574237443174682)
,p_db_column_name=>'VLOC_STRASSE'
,p_display_order=>1940
,p_column_identifier=>'GL'
,p_column_label=>'Vloc Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574344981174683)
,p_db_column_name=>'VLOC_VERG_ADR'
,p_display_order=>1950
,p_column_identifier=>'GM'
,p_column_label=>'Vloc Verg Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574465228174684)
,p_db_column_name=>'VLOC_VERG_BESCHREIBUNG'
,p_display_order=>1960
,p_column_identifier=>'GN'
,p_column_label=>'Vloc Verg Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574554497174685)
,p_db_column_name=>'VLOC_VERG_FK_ADRESSE'
,p_display_order=>1970
,p_column_identifier=>'GO'
,p_column_label=>'Vloc Verg Fk Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574621437174686)
,p_db_column_name=>'VLOC_VERG_FK_LOCATION_TYPE'
,p_display_order=>1980
,p_column_identifier=>'GP'
,p_column_label=>'Vloc Verg Fk Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574706116174687)
,p_db_column_name=>'VLOC_VERG_HSNR'
,p_display_order=>1990
,p_column_identifier=>'GQ'
,p_column_label=>'Vloc Verg Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574820048174688)
,p_db_column_name=>'VLOC_VERG_LAND'
,p_display_order=>2000
,p_column_identifier=>'GR'
,p_column_label=>'Vloc Verg Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6574926636174689)
,p_db_column_name=>'VLOC_VERG_LOCATION'
,p_display_order=>2010
,p_column_identifier=>'GS'
,p_column_label=>'Vloc Verg Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575028495174690)
,p_db_column_name=>'VLOC_VERG_LOCATION_TYPE'
,p_display_order=>2020
,p_column_identifier=>'GT'
,p_column_label=>'Vloc Verg Location Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575127505174691)
,p_db_column_name=>'VLOC_VERG_ORT'
,p_display_order=>2030
,p_column_identifier=>'GU'
,p_column_label=>'Vloc Verg Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575242347174692)
,p_db_column_name=>'VLOC_VERG_PK_LOCATION'
,p_display_order=>2040
,p_column_identifier=>'GV'
,p_column_label=>'Vloc Verg Pk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575298339174693)
,p_db_column_name=>'VLOC_VERG_PLZ'
,p_display_order=>2050
,p_column_identifier=>'GW'
,p_column_label=>'Vloc Verg Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575453636174694)
,p_db_column_name=>'VLOC_VERG_POSTFACH'
,p_display_order=>2060
,p_column_identifier=>'GX'
,p_column_label=>'Vloc Verg Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575542240174695)
,p_db_column_name=>'VLOC_VERG_STRASSE'
,p_display_order=>2070
,p_column_identifier=>'GY'
,p_column_label=>'Vloc Verg Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575641954174696)
,p_db_column_name=>'VON'
,p_display_order=>2080
,p_column_identifier=>'GZ'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575741008174697)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>2090
,p_column_identifier=>'HA'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575808476174698)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>2100
,p_column_identifier=>'HB'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6575938076174699)
,p_db_column_name=>'WAEHRUNG_LANG'
,p_display_order=>2110
,p_column_identifier=>'HC'
,p_column_label=>'Waehrung Lang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576035768174700)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>2120
,p_column_identifier=>'HD'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576154316174701)
,p_db_column_name=>'ZAHL_ART_VAL'
,p_display_order=>2130
,p_column_identifier=>'HE'
,p_column_label=>'Zahl Art Val'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576249971174702)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>2140
,p_column_identifier=>'HF'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576351738174703)
,p_db_column_name=>unistr('ZAPFS\00C4ULE')
,p_display_order=>2150
,p_column_identifier=>'HG'
,p_column_label=>unistr('Zapfs\00E4ule')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576461808174704)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>2160
,p_column_identifier=>'HH'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576496773174705)
,p_db_column_name=>'KTO_ID'
,p_display_order=>2170
,p_column_identifier=>'HI'
,p_column_label=>'Kto Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576601988174706)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2180
,p_column_identifier=>'HJ'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576722353174707)
,p_db_column_name=>'KTO_BETRAG'
,p_display_order=>2190
,p_column_identifier=>'HK'
,p_column_label=>'Kto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576866703174708)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>2200
,p_column_identifier=>'HL'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6576938532174709)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>2210
,p_column_identifier=>'HM'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577056417174710)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>2220
,p_column_identifier=>'HN'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577094166174661)
,p_db_column_name=>'KTO_BUCHUNGSTEXT'
,p_display_order=>2230
,p_column_identifier=>'HO'
,p_column_label=>'Kto Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577263721174662)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>2240
,p_column_identifier=>'HP'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577293795174663)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>2250
,p_column_identifier=>'HQ'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577475060174664)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>2260
,p_column_identifier=>'HR'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577552226174665)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>2270
,p_column_identifier=>'HS'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577613308174666)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>2280
,p_column_identifier=>'HT'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577695135174667)
,p_db_column_name=>'KTO_VERWENDUNGSZWECK'
,p_display_order=>2290
,p_column_identifier=>'HU'
,p_column_label=>'Kto Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577831674174668)
,p_db_column_name=>'KTO_KATEGORIE'
,p_display_order=>2300
,p_column_identifier=>'HV'
,p_column_label=>'Kto Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6577979728174669)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>2310
,p_column_identifier=>'HW'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578054778174670)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>2320
,p_column_identifier=>'HX'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578093734174671)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>2330
,p_column_identifier=>'HY'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578213716174672)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>2340
,p_column_identifier=>'HZ'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578373571174673)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>2350
,p_column_identifier=>'IA'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578417395174674)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>2360
,p_column_identifier=>'IB'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578483646174675)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>2370
,p_column_identifier=>'IC'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578668373174676)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>2380
,p_column_identifier=>'ID'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578696668174677)
,p_db_column_name=>'Kontotyp'
,p_display_order=>2390
,p_column_identifier=>'IE'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578859343174678)
,p_db_column_name=>'FK_VORGANG'
,p_display_order=>2400
,p_column_identifier=>'IF'
,p_column_label=>'Fk Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6578946512174679)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>2410
,p_column_identifier=>'IG'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579038620174680)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>2420
,p_column_identifier=>'IH'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579179121174681)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>2430
,p_column_identifier=>'II'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579217091174682)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>2440
,p_column_identifier=>'IJ'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579307819174683)
,p_db_column_name=>'FK_REL_LEX_KTO_BEL'
,p_display_order=>2450
,p_column_identifier=>'IK'
,p_column_label=>'Fk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579415222174684)
,p_db_column_name=>'STATUS'
,p_display_order=>2460
,p_column_identifier=>'IL'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579578220174685)
,p_db_column_name=>'FK_ZAHLSTATUS'
,p_display_order=>2470
,p_column_identifier=>'IM'
,p_column_label=>'Fk Zahlstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579637565174686)
,p_db_column_name=>'FK_INP_BELEGE_POS_ALL'
,p_display_order=>2480
,p_column_identifier=>'IN'
,p_column_label=>'Fk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6682537775191909)
,p_db_column_name=>'SL_KONTENBEZEICHNUNG'
,p_display_order=>2490
,p_column_identifier=>'IO'
,p_column_label=>'Sl Kontenbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6682591681191910)
,p_db_column_name=>'SL_KONTENKATEGORIE'
,p_display_order=>2500
,p_column_identifier=>'IP'
,p_column_label=>'Sl Kontenkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781448545367161)
,p_db_column_name=>'SL_KONTENUNTERART'
,p_display_order=>2510
,p_column_identifier=>'IQ'
,p_column_label=>'Sl Kontenunterart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781535619367162)
,p_db_column_name=>'SL_ZUORDNUNG_EUE'
,p_display_order=>2520
,p_column_identifier=>'IR'
,p_column_label=>'Sl Zuordnung Eue'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781598602367163)
,p_db_column_name=>'HB_KONTENBEZEICHNUNG'
,p_display_order=>2530
,p_column_identifier=>'IS'
,p_column_label=>'Hb Kontenbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781714094367164)
,p_db_column_name=>'HB_KONTENKATEGORIE'
,p_display_order=>2540
,p_column_identifier=>'IT'
,p_column_label=>'Hb Kontenkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781816934367165)
,p_db_column_name=>'HB_KONTENUNTERART'
,p_display_order=>2550
,p_column_identifier=>'IU'
,p_column_label=>'Hb Kontenunterart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6781932725367166)
,p_db_column_name=>'HB_ZUORDNUNG_EUE'
,p_display_order=>2560
,p_column_identifier=>'IV'
,p_column_label=>'Hb Zuordnung Eue'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6776013505261495)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'82164'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_LEX_KTO_BEL:BELEGDAT:LEX_BELEG:BETRAGEUR:BUCHDAT:NR:BELEGNUMMER:BETRAG:RELATION:SOLLKTO:HABENKTO:INP_BEL_ALL_JAHR:JAHR:Kontotyp:KST:KTR::SL_KONTENBEZEICHNUNG:SL_KONTENKATEGORIE:SL_KONTENUNTERART:SL_ZUORDNUNG_EUE:HB_KONTENBEZEICHNUNG:HB_KONTENK'
||'ATEGORIE:HB_KONTENUNTERART:HB_ZUORDNUNG_EUE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3640642101291386)
,p_plug_name=>'Beleginformationen'
,p_parent_plug_id=>wwv_flow_api.id(3640298779291383)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v_inp.PK_INP_BELEGE_ALL,',
'       FK_LEX_BUCHUNG,',
'       FK_KATEGORIE,',
'       FK_ARBEITSTAG,',
'       FK_BUCHUNG,',
'       FK_ZAHLUNGSART,',
'       v_inp.FK_VERWENDUNGSZWECK,',
'       v_inp.FK_INVENTAR,',
'       v_inp.FK_PROJEKT,',
'       v_inp.BELEGNUMMER,',
'       v_inp.BEZEICHNUNG,',
'       v_inp.FK_LAND,',
'       v_inp.FK_CITY,',
'       v_inp.BEL_DATUM,',
'       v_inp.VON,',
'       v_inp.BIS,',
'       v_inp.NETTO_BETRAG,',
'       v_inp.FK_STEUERSATZ,',
'       v_inp.MWST_BETRAG,',
'       v_inp.BRUTTO_BETRAG,',
'       v_inp.FK_WAEHRUNG,',
'       v_inp.STEUERNUMMER,',
'       v_inp.FK_UMRECHNUNGSKURS,',
'       COMM_REST_BELEG,',
'       COMM_TEL_BELEG,',
'       COMM_PRODUKTE,',
unistr('       "COMM_BEGR\00DCNDUNG",'),
'       COMM_SONSTIGES,',
'       BELEG,',
'       ZAHLUNGSBELEG,',
'',
'       FK_LOCATION,',
unistr('       "PERS\00D6NLICH_VOR_ORT",'),
'       BELEG_UHRZEIT,',
'       VON_UHRZEIT,',
'       BIS_UHRZEIT,',
'       FK_VON_ARBEITSTAG,',
'       FK_BIS_ARBEITSTAG,',
'       COMM_ADRESSE,',
'       TANKSTELLEN_NR,',
'       BRUTTO_BETRAG_INCL_TRINKG,',
'       COMM_PARKTICKET,',
'       FRMDW_NETTO_BETRAG,',
'       FK_FRMDW,',
'       FK_FRMDW_MWST_SATZ,',
'       FRMDW_MWST_BETRAG,',
'       FRMDW_BRUTTO_BETRAG,',
'       FRMDW_BRUTTO_INCL_TRINKG,',
'       MWST_BETRAG_EUR,',
'       BRUTTO_BETRAG_EUR,',
'       BRUTTO_INCL_TRINKG_EUR,',
'       NETTO_BETRAG_EUR,',
'       PREIS_PRO_MENGE,',
'       MENGENEINHEIT,',
'       LA_DATUM,',
'       FK_LA_KONTO,',
'       FK_LA_WDH,',
'       v_inp.FK_STATUS,',
'       COMM_VERGEHEN,',
'       VERG_BEHOERDE,',
'       CNT_PUNKTE,',
'       FK_BELEG_ABLAGE,',
'       FK_ABL_ORDNER_PAGE,',
'       CNT_PUNKTE_GESCHAETZT,',
'       PUNKTE_VON,',
'       PUNKTE_BIS,',
'       FK_LOCATION_VERG,',
'       FK_IMP_BA_BEL_OLD,',
'       GESCHW_IST,',
'       GESCHW_SOLL,',
'       GESCHW_UEBER_GRZ,',
'       GESCHW_UEBER_GRZ_ABZGL_MESSTOL,',
'       CODE_BUSSGELD,',
'       DESCR_BUSSGELD,',
'       GEZAHLT_AM,',
'       WEBSEITE,',
'       KUNDENNUMMER,',
'       FK_REAL_BELEG_EXIST,',
'       ZAHL_ART_VAL,',
'       ZAHL_ART_NAME,',
'       LA_WDH_VALUE,',
'       LA_WDH_NAME,',
'       STA_VALUE,',
'       STA_NAME,',
'       BEL_EX_VALUE,',
'       BEL_EX_NAME,',
'       PROJ_PK_PROJEKT,',
'       PROJ_FK_AUFTRAGGEBER,',
'       PROJ_FK_PROJEKTPARTNER_1,',
'       PROJ_FK_PROJEKTPARTNER_2,',
'       PROJ_PROJEKT,',
'       PROJ_VON,',
'       PROJ_BIS,',
'       PROJ_AKTUELLER_STUNDENSATZ,',
'       PROJ_PSP_ELEMENT,',
'       PROJ_CREATED_BY,',
'       PROJ_CREATED_AT,',
'       PROJ_MODIFIED_BY,',
'       PROJ_MODIFIED_AT,',
'       PROJ_RECHNUNG_GESTELLT,',
'       PROJ_ZAHLUNG_ABGESCHLOSSEN,',
'       PROJ_BELEGE_ZUGEORDNET,',
'       PROJ_KM_GERECHNET,',
'       PROJ_PROJEKT_ABGESCHLOSSEN,',
'       PROJ_PROJEKT_ART,',
'       PROJ_AUFT_PK_GESCHAEFTSPARTNER,',
'       PROJ_AUFT_GESCHAEFTSPARTNER,',
'       PROJ_AUFT_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_AUFT_PK_ADRESSE,',
'       PROJ_AUFT_STRASSE,',
'       PROJ_AUFT_HSNR,',
'       PROJ_AUFT_PLZ,',
'       PROJ_AUFT_ORT,',
'       PROJ_AUFT_LAND,',
'       PROJ_AUFT_BESCHREIBUNG,',
'       PROJ_AUFT_PK_REL_GP_KONT,',
'       PROJ_AUFT_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP1_PK_GESCHAEFTSPARTNER,',
'       PROJ_PP1_GESCHAEFTSPARTNER,',
'       PROJ_PP1_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP1_PK_ADRESSE,',
'       PROJ_PP1_STRASSE,',
'       PROJ_PP1_HSNR,',
'       PROJ_PP1_PLZ,',
'       PROJ_PP1_ORT,',
'       PROJ_PP1_LAND,',
'       PROJ_PP1_BESCHREIBUNG,',
'       PROJ_PP1_PK_REL_GP_KONT,',
'       PROJ_PP1_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP2_PK_GESCHAEFTSPARTNER,',
'       PROJ_PP2_GESCHAEFTSPARTNER,',
'       PROJ_PP2_FK_GESCHAEFTSPARTNERTYP,',
'       PROJ_PP2_PK_ADRESSE,',
'       PROJ_PP2_STRASSE,',
'       PROJ_PP2_HSNR,',
'       PROJ_PP2_PLZ,',
'       PROJ_PP2_ORT,',
'       PROJ_PP2_LAND,',
'       PROJ_PP2_BESCHREIBUNG,',
'       PROJ_PP2_PK_REL_GP_KONT,',
'       PROJ_PP2_GESCHAEFTSPARTNERTYP,',
'       PK_VERWENDUNGSZWECK,',
'       VERWENDUNGSZWECK,',
'       PK_KONTO_BUCH_KAT,',
'       KTOKAT_KATEGORIE,',
'       KTOKAT_NEU_ALT,',
'       KTOKAT_FK_OBERKATEGORIE,',
'       KTOKAT_VALID,',
'       ARB_PK_ARBEITSTAGE,',
'       ARB_DATUM,',
'       ARB_FK_ARBEITSTAG,',
'       ARB_FK_WOCHENENDE,',
'       ARB_FK_FEIERTAG,',
'       ARB_FEIERTAG,',
'       ARB_TAG,',
'       ARB_MONAT,',
'       ARB_JAHR,',
'       ARB_VON_PK_ARBEITSTAGE,',
'       ARB_VON_DATUM,',
'       ARB_VON_FK_ARBEITSTAG,',
'       ARB_VON_FK_WOCHENENDE,',
'       ARB_VON_FK_FEIERTAG,',
'       ARB_VON_FEIERTAG,',
'       ARB_VON_TAG,',
'       ARB_VON_MONAT,',
'       ARB_VON_JAHR,',
'       ARB_BIS_PK_ARBEITSTAGE,',
'       ARB_BIS_DATUM,',
'       ARB_BIS_FK_ARBEITSTAG,',
'       ARB_BIS_FK_WOCHENENDE,',
'       ARB_BIS_FK_FEIERTAG,',
'       ARB_BIS_FEIERTAG,',
'       ARB_BIS_TAG,',
'       ARB_BIS_MONAT,',
'       ARB_BIS_JAHR,',
'       PK_LAND,',
'       LAND,',
'       PK_ORT,',
'       ORT,',
'       CI_PK_LAND,',
'       CI_LAND,',
'       STEU_STEUERSATZ,',
'       STEU_LAND,',
'       STEU_PK_LAND,',
'       STEU_PK_STEUERSATZ,',
'       v_inp.STEU_ZUS_ST,',
'       v_inp.STEU_FRMD_STEUERSATZ,',
'       v_inp.STEU_FRMD_LAND,',
'       STEU_FRMD_PK_LAND,',
'       STEU_FRMD_PK_STEUERSATZ,',
'       STEU_FRMD_ZUS_ST,',
'       PK_WAEHRUNG,',
'       WAEHRUNG,',
'       WAEHRUNG_LANG,',
'       v_inp.COMM,',
'       ABL_ORD_J_PAGE_NUMBER,',
'       ABL_ORD_PK_ABL_ORDNER_PAGE,',
'       ABL_ORD_PAGE_NUMBER,',
'       ABL_ORD_JAHR,',
'       ABL_ORD_ORDNER_NAME,',
'       ABL_ORD_PK_ABL_ORDNER,',
'       VBEL_ART,',
'       VBEL_FK_IMP_BA_BEL,',
'       VBEL_PK_IMP_BA_ALLG_BEL,',
'       VBEL_BEZEICHNUNG,',
'       VBEL_KENNZEICHEN,',
'       VBEL_DATUM,',
'       VBEL_DATUM_VERGEHEN,',
'       VBEL_FK_ARBEITSTAG,',
'       VBEL_FK_BUCHUNG,',
'       VBEL_BETRAG,',
unistr('       "VBEL_W\00C4HRUNG",'),
'       VBEL_STEUERSATZ,',
'       VBEL_MWST_BETRAG,',
'       VBEL_NETTO,',
'       VBEL_ZAHLUNGSART,',
'       VBEL_BILD,',
'       VBEL_BILD1,',
'       VBEL_VERWENDUNGSZWECK,',
'       VBEL_FK_INVENTAR,',
'       VBEL_FK_PROJEKT,',
unistr('       "VBEL_W\00C4HRUNG_BETRAG",'),
'       VBEL_FK_KATEGORIE,',
'       VBEL_KATEGORIE,',
'       VBEL_PROJEKT,',
'       VBEL_INVENTAR,',
'       VBEL_FK_BELEG_ABLAGE,',
'       IBAN,',
'       PK_BANKKONTO,',
'       BANK,',
'       PK_BANK,',
'',
'       inv.inventar,',
'       v_inp.INP_BEL_ALL_JAHR,',
'       FK_ZAHLSTATUS,',
'       BELEG_STATUS',
'  from V_INP_BELEGE_ALL v_inp',
'    join t_rel_lex_kto_bel kto_bel on v_inp.pk_inp_belege_all = kto_bel.fk_inp_belege_all',
'    left join t_inventare inv on inv.pk_inventar = v_inp.fk_inventar',
'  where kto_bel.fk_main_key = :P296_fk_main_key1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6579683328174687)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>8020002603566227
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579880529174688)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579934654174689)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6579982805174690)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580103761174691)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580230083174692)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580346965174693)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580395540174694)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580493873174695)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580593007174696)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580717291174697)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580845041174698)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580929591174699)
,p_db_column_name=>'FK_LAND'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6580995334174700)
,p_db_column_name=>'FK_CITY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581157039174701)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581257995174702)
,p_db_column_name=>'VON'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581322139174703)
,p_db_column_name=>'BIS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581472422174704)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581524332174705)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581611635174706)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581714294174707)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581849457174708)
,p_db_column_name=>'FK_WAEHRUNG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6581956415174709)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6582049594174710)
,p_db_column_name=>'FK_UMRECHNUNGSKURS'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6657706734191761)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6657868848191762)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6657913895191763)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658026662191764)
,p_db_column_name=>unistr('COMM_BEGR\00DCNDUNG')
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>unistr('Comm Begr\00FCndung')
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658177305191765)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658217264191766)
,p_db_column_name=>'BELEG'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658348252191767)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658611979191770)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658700454191771)
,p_db_column_name=>unistr('PERS\00D6NLICH_VOR_ORT')
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>unistr('Pers\00F6nlich Vor Ort')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658847676191772)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6658899786191773)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659024945191774)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659134442191775)
,p_db_column_name=>'FK_VON_ARBEITSTAG'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Von Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659241370191776)
,p_db_column_name=>'FK_BIS_ARBEITSTAG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Bis Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659321911191777)
,p_db_column_name=>'COMM_ADRESSE'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Comm Adresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659433783191778)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659573067191779)
,p_db_column_name=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Brutto Betrag Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659629390191780)
,p_db_column_name=>'COMM_PARKTICKET'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Comm Parkticket'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659729353191781)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659860689191782)
,p_db_column_name=>'FK_FRMDW'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6659907420191783)
,p_db_column_name=>'FK_FRMDW_MWST_SATZ'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660019191191784)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660122639191785)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660200800191786)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660288603191787)
,p_db_column_name=>'MWST_BETRAG_EUR'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Mwst Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660444110191788)
,p_db_column_name=>'BRUTTO_BETRAG_EUR'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Brutto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660492402191789)
,p_db_column_name=>'BRUTTO_INCL_TRINKG_EUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Brutto Incl Trinkg Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660671152191790)
,p_db_column_name=>'NETTO_BETRAG_EUR'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Netto Betrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660689539191791)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Preis Pro Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660834438191792)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6660935580191793)
,p_db_column_name=>'LA_DATUM'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'La Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661053713191794)
,p_db_column_name=>'FK_LA_KONTO'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Fk La Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661151209191795)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661209115191796)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661309758191797)
,p_db_column_name=>'COMM_VERGEHEN'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Comm Vergehen'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661399944191798)
,p_db_column_name=>'VERG_BEHOERDE'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Verg Behoerde'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661505398191799)
,p_db_column_name=>'CNT_PUNKTE'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Cnt Punkte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661667375191800)
,p_db_column_name=>'FK_BELEG_ABLAGE'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661724976191801)
,p_db_column_name=>'FK_ABL_ORDNER_PAGE'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661851589191802)
,p_db_column_name=>'CNT_PUNKTE_GESCHAETZT'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Cnt Punkte Geschaetzt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661965324191803)
,p_db_column_name=>'PUNKTE_VON'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Punkte Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662080322191804)
,p_db_column_name=>'PUNKTE_BIS'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Punkte Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662089182191805)
,p_db_column_name=>'FK_LOCATION_VERG'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Fk Location Verg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662254328191806)
,p_db_column_name=>'FK_IMP_BA_BEL_OLD'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Imp Ba Bel Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662321438191807)
,p_db_column_name=>'GESCHW_IST'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Geschw Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662437182191808)
,p_db_column_name=>'GESCHW_SOLL'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Geschw Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662492488191809)
,p_db_column_name=>'GESCHW_UEBER_GRZ'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Geschw Ueber Grz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662672841191810)
,p_db_column_name=>'GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Geschw Ueber Grz Abzgl Messtol'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662779632191761)
,p_db_column_name=>'CODE_BUSSGELD'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Code Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662856759191762)
,p_db_column_name=>'DESCR_BUSSGELD'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Descr Bussgeld'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6662939249191763)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663003497191864)
,p_db_column_name=>'WEBSEITE'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663171968191865)
,p_db_column_name=>'KUNDENNUMMER'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663246211191866)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663286671191867)
,p_db_column_name=>'ZAHL_ART_VAL'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Zahl Art Val'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663456380191868)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663484161191869)
,p_db_column_name=>'LA_WDH_VALUE'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'La Wdh Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663632125191870)
,p_db_column_name=>'LA_WDH_NAME'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'La Wdh Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663685714191871)
,p_db_column_name=>'STA_VALUE'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Sta Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663854703191872)
,p_db_column_name=>'STA_NAME'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Sta Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6663952465191873)
,p_db_column_name=>'BEL_EX_VALUE'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Bel Ex Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664067127191874)
,p_db_column_name=>'BEL_EX_NAME'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Bel Ex Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664091924191875)
,p_db_column_name=>'PROJ_PK_PROJEKT'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Proj Pk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664232623191876)
,p_db_column_name=>'PROJ_FK_AUFTRAGGEBER'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Proj Fk Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664356114191877)
,p_db_column_name=>'PROJ_FK_PROJEKTPARTNER_1'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Proj Fk Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664420070191878)
,p_db_column_name=>'PROJ_FK_PROJEKTPARTNER_2'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Proj Fk Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664547090191879)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664651611191880)
,p_db_column_name=>'PROJ_VON'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Proj Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664686893191881)
,p_db_column_name=>'PROJ_BIS'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Proj Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664835418191882)
,p_db_column_name=>'PROJ_AKTUELLER_STUNDENSATZ'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Proj Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6664898898191883)
,p_db_column_name=>'PROJ_PSP_ELEMENT'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Proj Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665022809191884)
,p_db_column_name=>'PROJ_CREATED_BY'
,p_display_order=>970
,p_column_identifier=>'CS'
,p_column_label=>'Proj Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665179557191885)
,p_db_column_name=>'PROJ_CREATED_AT'
,p_display_order=>980
,p_column_identifier=>'CT'
,p_column_label=>'Proj Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665198013191886)
,p_db_column_name=>'PROJ_MODIFIED_BY'
,p_display_order=>990
,p_column_identifier=>'CU'
,p_column_label=>'Proj Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665364070191887)
,p_db_column_name=>'PROJ_MODIFIED_AT'
,p_display_order=>1000
,p_column_identifier=>'CV'
,p_column_label=>'Proj Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665474630191888)
,p_db_column_name=>'PROJ_RECHNUNG_GESTELLT'
,p_display_order=>1010
,p_column_identifier=>'CW'
,p_column_label=>'Proj Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665487728191889)
,p_db_column_name=>'PROJ_ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>1020
,p_column_identifier=>'CX'
,p_column_label=>'Proj Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665606911191890)
,p_db_column_name=>'PROJ_BELEGE_ZUGEORDNET'
,p_display_order=>1030
,p_column_identifier=>'CY'
,p_column_label=>'Proj Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665685912191891)
,p_db_column_name=>'PROJ_KM_GERECHNET'
,p_display_order=>1040
,p_column_identifier=>'CZ'
,p_column_label=>'Proj Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665782768191892)
,p_db_column_name=>'PROJ_PROJEKT_ABGESCHLOSSEN'
,p_display_order=>1050
,p_column_identifier=>'DA'
,p_column_label=>'Proj Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6665919828191893)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>1060
,p_column_identifier=>'DB'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666053834191894)
,p_db_column_name=>'PROJ_AUFT_PK_GESCHAEFTSPARTNER'
,p_display_order=>1070
,p_column_identifier=>'DC'
,p_column_label=>'Proj Auft Pk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666146417191895)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNER'
,p_display_order=>1080
,p_column_identifier=>'DD'
,p_column_label=>'Proj Auft Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666231828191896)
,p_db_column_name=>'PROJ_AUFT_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1090
,p_column_identifier=>'DE'
,p_column_label=>'Proj Auft Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666311174191897)
,p_db_column_name=>'PROJ_AUFT_PK_ADRESSE'
,p_display_order=>1100
,p_column_identifier=>'DF'
,p_column_label=>'Proj Auft Pk Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666384114191898)
,p_db_column_name=>'PROJ_AUFT_STRASSE'
,p_display_order=>1110
,p_column_identifier=>'DG'
,p_column_label=>'Proj Auft Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666553257191899)
,p_db_column_name=>'PROJ_AUFT_HSNR'
,p_display_order=>1120
,p_column_identifier=>'DH'
,p_column_label=>'Proj Auft Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666598821191900)
,p_db_column_name=>'PROJ_AUFT_PLZ'
,p_display_order=>1130
,p_column_identifier=>'DI'
,p_column_label=>'Proj Auft Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666766581191901)
,p_db_column_name=>'PROJ_AUFT_ORT'
,p_display_order=>1140
,p_column_identifier=>'DJ'
,p_column_label=>'Proj Auft Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666836478191902)
,p_db_column_name=>'PROJ_AUFT_LAND'
,p_display_order=>1150
,p_column_identifier=>'DK'
,p_column_label=>'Proj Auft Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6666968810191903)
,p_db_column_name=>'PROJ_AUFT_BESCHREIBUNG'
,p_display_order=>1160
,p_column_identifier=>'DL'
,p_column_label=>'Proj Auft Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667003431191904)
,p_db_column_name=>'PROJ_AUFT_PK_REL_GP_KONT'
,p_display_order=>1170
,p_column_identifier=>'DM'
,p_column_label=>'Proj Auft Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667155691191905)
,p_db_column_name=>'PROJ_AUFT_GESCHAEFTSPARTNERTYP'
,p_display_order=>1180
,p_column_identifier=>'DN'
,p_column_label=>'Proj Auft Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667262704191906)
,p_db_column_name=>'PROJ_PP1_PK_GESCHAEFTSPARTNER'
,p_display_order=>1190
,p_column_identifier=>'DO'
,p_column_label=>'Proj Pp1 Pk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667324840191907)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNER'
,p_display_order=>1200
,p_column_identifier=>'DP'
,p_column_label=>'Proj Pp1 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667410462191908)
,p_db_column_name=>'PROJ_PP1_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1210
,p_column_identifier=>'DQ'
,p_column_label=>'Proj Pp1 Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667576070191909)
,p_db_column_name=>'PROJ_PP1_PK_ADRESSE'
,p_display_order=>1220
,p_column_identifier=>'DR'
,p_column_label=>'Proj Pp1 Pk Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667629427191910)
,p_db_column_name=>'PROJ_PP1_STRASSE'
,p_display_order=>1230
,p_column_identifier=>'DS'
,p_column_label=>'Proj Pp1 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667736606191861)
,p_db_column_name=>'PROJ_PP1_HSNR'
,p_display_order=>1240
,p_column_identifier=>'DT'
,p_column_label=>'Proj Pp1 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667781660191862)
,p_db_column_name=>'PROJ_PP1_PLZ'
,p_display_order=>1250
,p_column_identifier=>'DU'
,p_column_label=>'Proj Pp1 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6667930097191863)
,p_db_column_name=>'PROJ_PP1_ORT'
,p_display_order=>1260
,p_column_identifier=>'DV'
,p_column_label=>'Proj Pp1 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668003903191864)
,p_db_column_name=>'PROJ_PP1_LAND'
,p_display_order=>1270
,p_column_identifier=>'DW'
,p_column_label=>'Proj Pp1 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668168788191865)
,p_db_column_name=>'PROJ_PP1_BESCHREIBUNG'
,p_display_order=>1280
,p_column_identifier=>'DX'
,p_column_label=>'Proj Pp1 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668218021191866)
,p_db_column_name=>'PROJ_PP1_PK_REL_GP_KONT'
,p_display_order=>1290
,p_column_identifier=>'DY'
,p_column_label=>'Proj Pp1 Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668306169191867)
,p_db_column_name=>'PROJ_PP1_GESCHAEFTSPARTNERTYP'
,p_display_order=>1300
,p_column_identifier=>'DZ'
,p_column_label=>'Proj Pp1 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668444007191868)
,p_db_column_name=>'PROJ_PP2_PK_GESCHAEFTSPARTNER'
,p_display_order=>1310
,p_column_identifier=>'EA'
,p_column_label=>'Proj Pp2 Pk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668527864191869)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNER'
,p_display_order=>1320
,p_column_identifier=>'EB'
,p_column_label=>'Proj Pp2 Geschaeftspartner'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668633396191870)
,p_db_column_name=>'PROJ_PP2_FK_GESCHAEFTSPARTNERTYP'
,p_display_order=>1330
,p_column_identifier=>'EC'
,p_column_label=>'Proj Pp2 Fk Geschaeftspartnertyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668741467191871)
,p_db_column_name=>'PROJ_PP2_PK_ADRESSE'
,p_display_order=>1340
,p_column_identifier=>'ED'
,p_column_label=>'Proj Pp2 Pk Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668857257191872)
,p_db_column_name=>'PROJ_PP2_STRASSE'
,p_display_order=>1350
,p_column_identifier=>'EE'
,p_column_label=>'Proj Pp2 Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6668980563191873)
,p_db_column_name=>'PROJ_PP2_HSNR'
,p_display_order=>1360
,p_column_identifier=>'EF'
,p_column_label=>'Proj Pp2 Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669000956191874)
,p_db_column_name=>'PROJ_PP2_PLZ'
,p_display_order=>1370
,p_column_identifier=>'EG'
,p_column_label=>'Proj Pp2 Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669168412191875)
,p_db_column_name=>'PROJ_PP2_ORT'
,p_display_order=>1380
,p_column_identifier=>'EH'
,p_column_label=>'Proj Pp2 Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669242961191876)
,p_db_column_name=>'PROJ_PP2_LAND'
,p_display_order=>1390
,p_column_identifier=>'EI'
,p_column_label=>'Proj Pp2 Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669341639191877)
,p_db_column_name=>'PROJ_PP2_BESCHREIBUNG'
,p_display_order=>1400
,p_column_identifier=>'EJ'
,p_column_label=>'Proj Pp2 Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669404842191878)
,p_db_column_name=>'PROJ_PP2_PK_REL_GP_KONT'
,p_display_order=>1410
,p_column_identifier=>'EK'
,p_column_label=>'Proj Pp2 Pk Rel Gp Kont'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669571575191879)
,p_db_column_name=>'PROJ_PP2_GESCHAEFTSPARTNERTYP'
,p_display_order=>1420
,p_column_identifier=>'EL'
,p_column_label=>'Proj Pp2 Geschaeftspartnertyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669667465191880)
,p_db_column_name=>'PK_VERWENDUNGSZWECK'
,p_display_order=>1430
,p_column_identifier=>'EM'
,p_column_label=>'Pk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669771811191881)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>1440
,p_column_identifier=>'EN'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669815166191882)
,p_db_column_name=>'PK_KONTO_BUCH_KAT'
,p_display_order=>1450
,p_column_identifier=>'EO'
,p_column_label=>'Pk Konto Buch Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6669961805191883)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>1460
,p_column_identifier=>'EP'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670035114191884)
,p_db_column_name=>'KTOKAT_NEU_ALT'
,p_display_order=>1470
,p_column_identifier=>'EQ'
,p_column_label=>'Ktokat Neu Alt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670097133191885)
,p_db_column_name=>'KTOKAT_FK_OBERKATEGORIE'
,p_display_order=>1480
,p_column_identifier=>'ER'
,p_column_label=>'Ktokat Fk Oberkategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670244216191886)
,p_db_column_name=>'KTOKAT_VALID'
,p_display_order=>1490
,p_column_identifier=>'ES'
,p_column_label=>'Ktokat Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670376558191887)
,p_db_column_name=>'ARB_PK_ARBEITSTAGE'
,p_display_order=>1500
,p_column_identifier=>'ET'
,p_column_label=>'Arb Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670469703191888)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>1510
,p_column_identifier=>'EU'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670544032191889)
,p_db_column_name=>'ARB_FK_ARBEITSTAG'
,p_display_order=>1520
,p_column_identifier=>'EV'
,p_column_label=>'Arb Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670615872191890)
,p_db_column_name=>'ARB_FK_WOCHENENDE'
,p_display_order=>1530
,p_column_identifier=>'EW'
,p_column_label=>'Arb Fk Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670739185191891)
,p_db_column_name=>'ARB_FK_FEIERTAG'
,p_display_order=>1540
,p_column_identifier=>'EX'
,p_column_label=>'Arb Fk Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670807660191892)
,p_db_column_name=>'ARB_FEIERTAG'
,p_display_order=>1550
,p_column_identifier=>'EY'
,p_column_label=>'Arb Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6670972481191893)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>1560
,p_column_identifier=>'EZ'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671026331191894)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>1570
,p_column_identifier=>'FA'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671091203191895)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>1580
,p_column_identifier=>'FB'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671253252191896)
,p_db_column_name=>'ARB_VON_PK_ARBEITSTAGE'
,p_display_order=>1590
,p_column_identifier=>'FC'
,p_column_label=>'Arb Von Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671369270191897)
,p_db_column_name=>'ARB_VON_DATUM'
,p_display_order=>1600
,p_column_identifier=>'FD'
,p_column_label=>'Arb Von Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671404767191898)
,p_db_column_name=>'ARB_VON_FK_ARBEITSTAG'
,p_display_order=>1610
,p_column_identifier=>'FE'
,p_column_label=>'Arb Von Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671542039191899)
,p_db_column_name=>'ARB_VON_FK_WOCHENENDE'
,p_display_order=>1620
,p_column_identifier=>'FF'
,p_column_label=>'Arb Von Fk Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671593249191900)
,p_db_column_name=>'ARB_VON_FK_FEIERTAG'
,p_display_order=>1630
,p_column_identifier=>'FG'
,p_column_label=>'Arb Von Fk Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671718514191901)
,p_db_column_name=>'ARB_VON_FEIERTAG'
,p_display_order=>1640
,p_column_identifier=>'FH'
,p_column_label=>'Arb Von Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671784078191902)
,p_db_column_name=>'ARB_VON_TAG'
,p_display_order=>1650
,p_column_identifier=>'FI'
,p_column_label=>'Arb Von Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6671959886191903)
,p_db_column_name=>'ARB_VON_MONAT'
,p_display_order=>1660
,p_column_identifier=>'FJ'
,p_column_label=>'Arb Von Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672023943191904)
,p_db_column_name=>'ARB_VON_JAHR'
,p_display_order=>1670
,p_column_identifier=>'FK'
,p_column_label=>'Arb Von Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672152087191905)
,p_db_column_name=>'ARB_BIS_PK_ARBEITSTAGE'
,p_display_order=>1680
,p_column_identifier=>'FL'
,p_column_label=>'Arb Bis Pk Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672260287191906)
,p_db_column_name=>'ARB_BIS_DATUM'
,p_display_order=>1690
,p_column_identifier=>'FM'
,p_column_label=>'Arb Bis Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672302148191907)
,p_db_column_name=>'ARB_BIS_FK_ARBEITSTAG'
,p_display_order=>1700
,p_column_identifier=>'FN'
,p_column_label=>'Arb Bis Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672410943191908)
,p_db_column_name=>'ARB_BIS_FK_WOCHENENDE'
,p_display_order=>1710
,p_column_identifier=>'FO'
,p_column_label=>'Arb Bis Fk Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672544791191909)
,p_db_column_name=>'ARB_BIS_FK_FEIERTAG'
,p_display_order=>1720
,p_column_identifier=>'FP'
,p_column_label=>'Arb Bis Fk Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672668808191910)
,p_db_column_name=>'ARB_BIS_FEIERTAG'
,p_display_order=>1730
,p_column_identifier=>'FQ'
,p_column_label=>'Arb Bis Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672748027191861)
,p_db_column_name=>'ARB_BIS_TAG'
,p_display_order=>1740
,p_column_identifier=>'FR'
,p_column_label=>'Arb Bis Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672853192191862)
,p_db_column_name=>'ARB_BIS_MONAT'
,p_display_order=>1750
,p_column_identifier=>'FS'
,p_column_label=>'Arb Bis Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6672963337191863)
,p_db_column_name=>'ARB_BIS_JAHR'
,p_display_order=>1760
,p_column_identifier=>'FT'
,p_column_label=>'Arb Bis Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673008194191864)
,p_db_column_name=>'PK_LAND'
,p_display_order=>1770
,p_column_identifier=>'FU'
,p_column_label=>'Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673128575191865)
,p_db_column_name=>'LAND'
,p_display_order=>1780
,p_column_identifier=>'FV'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673252654191866)
,p_db_column_name=>'PK_ORT'
,p_display_order=>1790
,p_column_identifier=>'FW'
,p_column_label=>'Pk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673339768191867)
,p_db_column_name=>'ORT'
,p_display_order=>1800
,p_column_identifier=>'FX'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673393294191868)
,p_db_column_name=>'CI_PK_LAND'
,p_display_order=>1810
,p_column_identifier=>'FY'
,p_column_label=>'Ci Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673487503191869)
,p_db_column_name=>'CI_LAND'
,p_display_order=>1820
,p_column_identifier=>'FZ'
,p_column_label=>'Ci Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673625035191870)
,p_db_column_name=>'STEU_STEUERSATZ'
,p_display_order=>1830
,p_column_identifier=>'GA'
,p_column_label=>'Steu Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673718064191871)
,p_db_column_name=>'STEU_LAND'
,p_display_order=>1840
,p_column_identifier=>'GB'
,p_column_label=>'Steu Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673819125191872)
,p_db_column_name=>'STEU_PK_LAND'
,p_display_order=>1850
,p_column_identifier=>'GC'
,p_column_label=>'Steu Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6673919596191873)
,p_db_column_name=>'STEU_PK_STEUERSATZ'
,p_display_order=>1860
,p_column_identifier=>'GD'
,p_column_label=>'Steu Pk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674053540191874)
,p_db_column_name=>'STEU_ZUS_ST'
,p_display_order=>1870
,p_column_identifier=>'GE'
,p_column_label=>'Steu Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674114917191875)
,p_db_column_name=>'STEU_FRMD_STEUERSATZ'
,p_display_order=>1880
,p_column_identifier=>'GF'
,p_column_label=>'Steu Frmd Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674205208191876)
,p_db_column_name=>'STEU_FRMD_LAND'
,p_display_order=>1890
,p_column_identifier=>'GG'
,p_column_label=>'Steu Frmd Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674287645191877)
,p_db_column_name=>'STEU_FRMD_PK_LAND'
,p_display_order=>1900
,p_column_identifier=>'GH'
,p_column_label=>'Steu Frmd Pk Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674478270191878)
,p_db_column_name=>'STEU_FRMD_PK_STEUERSATZ'
,p_display_order=>1910
,p_column_identifier=>'GI'
,p_column_label=>'Steu Frmd Pk Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674561549191879)
,p_db_column_name=>'STEU_FRMD_ZUS_ST'
,p_display_order=>1920
,p_column_identifier=>'GJ'
,p_column_label=>'Steu Frmd Zus St'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674589103191880)
,p_db_column_name=>'PK_WAEHRUNG'
,p_display_order=>1930
,p_column_identifier=>'GK'
,p_column_label=>'Pk Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674778479191881)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>1940
,p_column_identifier=>'GL'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674864566191882)
,p_db_column_name=>'WAEHRUNG_LANG'
,p_display_order=>1950
,p_column_identifier=>'GM'
,p_column_label=>'Waehrung Lang'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674897682191883)
,p_db_column_name=>'COMM'
,p_display_order=>1960
,p_column_identifier=>'GN'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6674987489191884)
,p_db_column_name=>'ABL_ORD_J_PAGE_NUMBER'
,p_display_order=>1970
,p_column_identifier=>'GO'
,p_column_label=>'Abl Ord J Page Number'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675148981191885)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>1980
,p_column_identifier=>'GP'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675251370191886)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>1990
,p_column_identifier=>'GQ'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675336083191887)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>2000
,p_column_identifier=>'GR'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675436669191888)
,p_db_column_name=>'ABL_ORD_ORDNER_NAME'
,p_display_order=>2010
,p_column_identifier=>'GS'
,p_column_label=>'Abl Ord Ordner Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675480955191889)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER'
,p_display_order=>2020
,p_column_identifier=>'GT'
,p_column_label=>'Abl Ord Pk Abl Ordner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675653534191890)
,p_db_column_name=>'VBEL_ART'
,p_display_order=>2030
,p_column_identifier=>'GU'
,p_column_label=>'Vbel Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675724471191891)
,p_db_column_name=>'VBEL_FK_IMP_BA_BEL'
,p_display_order=>2040
,p_column_identifier=>'GV'
,p_column_label=>'Vbel Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675806691191892)
,p_db_column_name=>'VBEL_PK_IMP_BA_ALLG_BEL'
,p_display_order=>2050
,p_column_identifier=>'GW'
,p_column_label=>'Vbel Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6675954635191893)
,p_db_column_name=>'VBEL_BEZEICHNUNG'
,p_display_order=>2060
,p_column_identifier=>'GX'
,p_column_label=>'Vbel Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676015180191894)
,p_db_column_name=>'VBEL_KENNZEICHEN'
,p_display_order=>2070
,p_column_identifier=>'GY'
,p_column_label=>'Vbel Kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676123053191895)
,p_db_column_name=>'VBEL_DATUM'
,p_display_order=>2080
,p_column_identifier=>'GZ'
,p_column_label=>'Vbel Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676228943191896)
,p_db_column_name=>'VBEL_DATUM_VERGEHEN'
,p_display_order=>2090
,p_column_identifier=>'HA'
,p_column_label=>'Vbel Datum Vergehen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676333445191897)
,p_db_column_name=>'VBEL_FK_ARBEITSTAG'
,p_display_order=>2100
,p_column_identifier=>'HB'
,p_column_label=>'Vbel Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676399936191898)
,p_db_column_name=>'VBEL_FK_BUCHUNG'
,p_display_order=>2110
,p_column_identifier=>'HC'
,p_column_label=>'Vbel Fk Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676561881191899)
,p_db_column_name=>'VBEL_BETRAG'
,p_display_order=>2120
,p_column_identifier=>'HD'
,p_column_label=>'Vbel Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676641536191900)
,p_db_column_name=>unistr('VBEL_W\00C4HRUNG')
,p_display_order=>2130
,p_column_identifier=>'HE'
,p_column_label=>unistr('Vbel W\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676775295191901)
,p_db_column_name=>'VBEL_STEUERSATZ'
,p_display_order=>2140
,p_column_identifier=>'HF'
,p_column_label=>'Vbel Steuersatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676842739191902)
,p_db_column_name=>'VBEL_MWST_BETRAG'
,p_display_order=>2150
,p_column_identifier=>'HG'
,p_column_label=>'Vbel Mwst Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6676899779191903)
,p_db_column_name=>'VBEL_NETTO'
,p_display_order=>2160
,p_column_identifier=>'HH'
,p_column_label=>'Vbel Netto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677029316191904)
,p_db_column_name=>'VBEL_ZAHLUNGSART'
,p_display_order=>2170
,p_column_identifier=>'HI'
,p_column_label=>'Vbel Zahlungsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677173695191905)
,p_db_column_name=>'VBEL_BILD'
,p_display_order=>2180
,p_column_identifier=>'HJ'
,p_column_label=>'Vbel Bild'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677185488191906)
,p_db_column_name=>'VBEL_BILD1'
,p_display_order=>2190
,p_column_identifier=>'HK'
,p_column_label=>'Vbel Bild1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677286252191907)
,p_db_column_name=>'VBEL_VERWENDUNGSZWECK'
,p_display_order=>2200
,p_column_identifier=>'HL'
,p_column_label=>'Vbel Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677410098191908)
,p_db_column_name=>'VBEL_FK_INVENTAR'
,p_display_order=>2210
,p_column_identifier=>'HM'
,p_column_label=>'Vbel Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677494664191909)
,p_db_column_name=>'VBEL_FK_PROJEKT'
,p_display_order=>2220
,p_column_identifier=>'HN'
,p_column_label=>'Vbel Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677680078191910)
,p_db_column_name=>unistr('VBEL_W\00C4HRUNG_BETRAG')
,p_display_order=>2230
,p_column_identifier=>'HO'
,p_column_label=>unistr('Vbel W\00E4hrung Betrag')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677758402191861)
,p_db_column_name=>'VBEL_FK_KATEGORIE'
,p_display_order=>2240
,p_column_identifier=>'HP'
,p_column_label=>'Vbel Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677826931191862)
,p_db_column_name=>'VBEL_KATEGORIE'
,p_display_order=>2250
,p_column_identifier=>'HQ'
,p_column_label=>'Vbel Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6677971952191863)
,p_db_column_name=>'VBEL_PROJEKT'
,p_display_order=>2260
,p_column_identifier=>'HR'
,p_column_label=>'Vbel Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678032762191864)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>2270
,p_column_identifier=>'HS'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678088962191865)
,p_db_column_name=>'VBEL_FK_BELEG_ABLAGE'
,p_display_order=>2280
,p_column_identifier=>'HT'
,p_column_label=>'Vbel Fk Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678278310191866)
,p_db_column_name=>'IBAN'
,p_display_order=>2290
,p_column_identifier=>'HU'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678308335191867)
,p_db_column_name=>'PK_BANKKONTO'
,p_display_order=>2300
,p_column_identifier=>'HV'
,p_column_label=>'Pk Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678445815191868)
,p_db_column_name=>'BANK'
,p_display_order=>2310
,p_column_identifier=>'HW'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6678577698191869)
,p_db_column_name=>'PK_BANK'
,p_display_order=>2320
,p_column_identifier=>'HX'
,p_column_label=>'Pk Bank'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6682229724191906)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>2690
,p_column_identifier=>'JI'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6682344102191907)
,p_db_column_name=>'FK_ZAHLSTATUS'
,p_display_order=>2700
,p_column_identifier=>'JJ'
,p_column_label=>'Fk Zahlstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6682469318191908)
,p_db_column_name=>'BELEG_STATUS'
,p_display_order=>2710
,p_column_identifier=>'JK'
,p_column_label=>'Beleg Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782015198367167)
,p_db_column_name=>'INVENTAR'
,p_display_order=>2720
,p_column_identifier=>'JL'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6776643484262325)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'82170'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_INVENTAR:INVENTAR:PROJ_PROJEKT:PK_INP_BELEGE_ALL:BELEGNUMMER:BEZEICHNUNG:BEL_DATUM:VON:BIS:BRUTTO_BETRAG:COMM_REST_BELEG:COMM_TEL_BELEG:COMM_PRODUKTE:COMM_BEGR\00DCNDUNG:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:FK_LOCATION:PERS\00D6NLICH_VOR_ORT:BELEG_UHRZEIT:V')
||'ON_UHRZEIT:BIS_UHRZEIT:FK_VON_ARBEITSTAG:FK_BIS_ARBEITSTAG:COMM_ADRESSE:TANKSTELLEN_NR:BRUTTO_BETRAG_INCL_TRINKG:COMM_PARKTICKET:FRMDW_NETTO_BETRAG:FK_FRMDW:FK_FRMDW_MWST_SATZ:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:MWST_BETRAG'
||'_EUR:BRUTTO_BETRAG_EUR:BRUTTO_INCL_TRINKG_EUR:NETTO_BETRAG_EUR:PREIS_PRO_MENGE:MENGENEINHEIT:LA_DATUM:FK_LA_KONTO:FK_LA_WDH:FK_STATUS:COMM_VERGEHEN:VERG_BEHOERDE:CNT_PUNKTE:FK_BELEG_ABLAGE:FK_ABL_ORDNER_PAGE:CNT_PUNKTE_GESCHAETZT:PUNKTE_VON:PUNKTE_BI'
||'S:FK_LOCATION_VERG:FK_IMP_BA_BEL_OLD:GESCHW_IST:GESCHW_SOLL:GESCHW_UEBER_GRZ:GESCHW_UEBER_GRZ_ABZGL_MESSTOL:CODE_BUSSGELD:DESCR_BUSSGELD:GEZAHLT_AM:WEBSEITE:KUNDENNUMMER:FK_REAL_BELEG_EXIST:ZAHL_ART_VAL:ZAHL_ART_NAME:LA_WDH_VALUE:LA_WDH_NAME:STA_VALU'
||'E:STA_NAME:BEL_EX_VALUE:BEL_EX_NAME:PROJ_PK_PROJEKT:PROJ_FK_AUFTRAGGEBER:PROJ_FK_PROJEKTPARTNER_1:PROJ_FK_PROJEKTPARTNER_2:PROJ_VON:PROJ_BIS:PROJ_AKTUELLER_STUNDENSATZ:PROJ_PSP_ELEMENT:PROJ_CREATED_BY:PROJ_CREATED_AT:PROJ_MODIFIED_BY:PROJ_MODIFIED_AT'
||':PROJ_RECHNUNG_GESTELLT:PROJ_ZAHLUNG_ABGESCHLOSSEN:PROJ_BELEGE_ZUGEORDNET:PROJ_KM_GERECHNET:PROJ_PROJEKT_ABGESCHLOSSEN:PROJ_PROJEKT_ART:PROJ_AUFT_PK_GESCHAEFTSPARTNER:PROJ_AUFT_GESCHAEFTSPARTNER:PROJ_AUFT_FK_GESCHAEFTSPARTNERTYP:PROJ_AUFT_PK_ADRESSE:'
||'PROJ_AUFT_STRASSE:PROJ_AUFT_HSNR:PROJ_AUFT_PLZ:PROJ_AUFT_ORT:PROJ_AUFT_LAND:PROJ_AUFT_BESCHREIBUNG:PROJ_AUFT_PK_REL_GP_KONT:PROJ_AUFT_GESCHAEFTSPARTNERTYP:PROJ_PP1_PK_GESCHAEFTSPARTNER:PROJ_PP1_GESCHAEFTSPARTNER:PROJ_PP1_FK_GESCHAEFTSPARTNERTYP:PROJ_'
||'PP1_PK_ADRESSE:PROJ_PP1_STRASSE:PROJ_PP1_HSNR:PROJ_PP1_PLZ:PROJ_PP1_ORT:PROJ_PP1_LAND:PROJ_PP1_BESCHREIBUNG:PROJ_PP1_PK_REL_GP_KONT:PROJ_PP1_GESCHAEFTSPARTNERTYP:PROJ_PP2_PK_GESCHAEFTSPARTNER:PROJ_PP2_GESCHAEFTSPARTNER:PROJ_PP2_FK_GESCHAEFTSPARTNERTY'
||'P:PROJ_PP2_PK_ADRESSE:PROJ_PP2_STRASSE:PROJ_PP2_HSNR:PROJ_PP2_PLZ:PROJ_PP2_ORT:PROJ_PP2_LAND:PROJ_PP2_BESCHREIBUNG:PROJ_PP2_PK_REL_GP_KONT:PROJ_PP2_GESCHAEFTSPARTNERTYP:PK_VERWENDUNGSZWECK:VERWENDUNGSZWECK:PK_KONTO_BUCH_KAT:KTOKAT_KATEGORIE:KTOKAT_NE'
||'U_ALT:KTOKAT_FK_OBERKATEGORIE:KTOKAT_VALID:ARB_PK_ARBEITSTAGE:ARB_DATUM:ARB_FK_ARBEITSTAG:ARB_FK_WOCHENENDE:ARB_FK_FEIERTAG:ARB_FEIERTAG:ARB_TAG:ARB_MONAT:ARB_JAHR:ARB_VON_PK_ARBEITSTAGE:ARB_VON_DATUM:ARB_VON_FK_ARBEITSTAG:ARB_VON_FK_WOCHENENDE:ARB_V'
||'ON_FK_FEIERTAG:ARB_VON_FEIERTAG:ARB_VON_TAG:ARB_VON_MONAT:ARB_VON_JAHR:ARB_BIS_PK_ARBEITSTAGE:ARB_BIS_DATUM:ARB_BIS_FK_ARBEITSTAG:ARB_BIS_FK_WOCHENENDE:ARB_BIS_FK_FEIERTAG:ARB_BIS_FEIERTAG:ARB_BIS_TAG:ARB_BIS_MONAT:ARB_BIS_JAHR:PK_LAND:LAND:PK_ORT:OR'
||'T:CI_PK_LAND:CI_LAND:STEU_STEUERSATZ:STEU_LAND:STEU_PK_LAND:STEU_PK_STEUERSATZ:STEU_ZUS_ST:STEU_FRMD_STEUERSATZ:STEU_FRMD_LAND:STEU_FRMD_PK_LAND:STEU_FRMD_PK_STEUERSATZ:STEU_FRMD_ZUS_ST:PK_WAEHRUNG:WAEHRUNG:WAEHRUNG_LANG:COMM:ABL_ORD_J_PAGE_NUMBER:AB'
||'L_ORD_PK_ABL_ORDNER_PAGE:ABL_ORD_PAGE_NUMBER:ABL_ORD_JAHR:ABL_ORD_ORDNER_NAME:ABL_ORD_PK_ABL_ORDNER:VBEL_ART:VBEL_FK_IMP_BA_BEL:VBEL_PK_IMP_BA_ALLG_BEL:VBEL_BEZEICHNUNG:VBEL_KENNZEICHEN:VBEL_DATUM:VBEL_DATUM_VERGEHEN:VBEL_FK_ARBEITSTAG:VBEL_FK_BUCHUN'
||unistr('G:VBEL_BETRAG:VBEL_W\00C4HRUNG:VBEL_STEUERSATZ:VBEL_MWST_BETRAG:VBEL_NETTO:VBEL_ZAHLUNGSART:VBEL_BILD:VBEL_BILD1:VBEL_VERWENDUNGSZWECK:VBEL_W\00C4HRUNG_BETRAG:VBEL_FK_KATEGORIE:VBEL_KATEGORIE:VBEL_PROJEKT:VBEL_FK_BELEG_ABLAGE:IBAN:PK_BANKKONTO:BANK:PK_BANK:I')
||'NP_BEL_ALL_JAHR:FK_ZAHLSTATUS:BELEG_STATUS:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6782306081367170)
,p_plug_name=>'Berechnung'
,p_parent_plug_id=>wwv_flow_api.id(3640298779291383)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  --fk_Main_key, "Betrag", ',
'zus.*,',
'--,',
'--,',
'replace(substr(Buchungstext,1,4),''.'','','') d,',
'--, count(*)',
'round(("Betrag" * 100 /(100 + replace(substr(Buchungstext,1,4),''.'','','')))/(1-(100/(100 + replace(substr(Buchungstext,1,4),''.'','','')))),2) calc',
'from v_konten_zus zus',
'where instr(Buchungstext,''AUSLANDSEINSATZENTGELT'')>0 and  replace(substr(Buchungstext,1,4),''.'','','') ! = ''giro''',
'and fk_main_key = :P296_fk_main_key1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6782462761367171)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>8222782036758711
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782525003367172)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782665714367173)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782681169367174)
,p_db_column_name=>'Buchungstag'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782856845367175)
,p_db_column_name=>'Betrag'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6782893892367176)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783033084367177)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783169144367178)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783260452367179)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783357196367180)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783443780367181)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783565050367182)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783655933367183)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783709980367184)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783822972367185)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783937085367186)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6783985713367187)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784135066367188)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784208521367189)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784325106367190)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784417685367191)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784518074367192)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784632237367193)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784744491367194)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784815153367195)
,p_db_column_name=>'Kontotyp'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784965150367196)
,p_db_column_name=>'FK_VORGANG'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fk Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6784981419367197)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6785152572367198)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6785205615367199)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6785314144367200)
,p_db_column_name=>'IBAN'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6785417969367201)
,p_db_column_name=>'D'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'D'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6785553720367202)
,p_db_column_name=>'CALC'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Calc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6809478362523086)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'82498'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_MAIN_KEY:ID:Buchungstag:Betrag:W\00E4hrung:Fremdw\00E4hrungsbetrag:Fremdw\00E4hrung:BUCHUNGSTEXT:FK_Kategorie:FK_Verwendungszweck:FK_Kontotyp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERT')
||'T_MONAT:WERTT_JAHR:WERTT_DATUM:Kontotyp:FK_VORGANG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:IBAN:D:CALC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19549813591325301)
,p_plug_name=>'Kontobuchungszuordnungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_KONT_BUCH_KONT_BUCH'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19723663676495764)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(19549813591325301)
,p_button_name=>'del'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Del'
,p_button_position=>'BELOW_BOX'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19723754090495765)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(19549813591325301)
,p_button_name=>'ins'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'New'
,p_button_position=>'BELOW_BOX'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19723847898495766)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(19549813591325301)
,p_button_name=>'upd'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Upd'
,p_button_position=>'BELOW_BOX'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6819529076639206)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(3640298779291383)
,p_button_name=>'Insert'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Insert'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3640459520291384)
,p_name=>'P296_FK_MAIN_KEY1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3640298779291383)
,p_prompt=>'Fk Main Key1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6820281609639210)
,p_name=>'P296_FK_MAIN_KEY2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(3640298779291383)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6820770676639211)
,p_name=>'P296_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3640298779291383)
,p_item_default=>unistr('Zuordnung Auslandsgeb\00FChr')
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19549995791325303)
,p_name=>'P296_PK_REL_KONT_BUCH_KONT_BUCH'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Pk Rel Kont Buch Kont Buch'
,p_source=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550088714325304)
,p_name=>'P296_FK_KONTO_BUCH1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Fk Konto Buch1'
,p_source=>'FK_KONTO_BUCH1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550202866325305)
,p_name=>'P296_FK_KONTO_BUCH2'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Fk Konto Buch2'
,p_source=>'FK_KONTO_BUCH2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550319921325306)
,p_name=>'P296_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550441300325307)
,p_name=>'P296_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550482361325308)
,p_name=>'P296_MODIFIED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Modified By'
,p_source=>'MODIFIED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550676409325309)
,p_name=>'P296_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19550754932325310)
,p_name=>'P296_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19723338625495761)
,p_name=>'P296_FK_BUCHUNGSVORGANG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Fk Buchungsvorgang'
,p_source=>'FK_BUCHUNGSVORGANG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(19723421646495762)
,p_name=>'P296_FK_TYPE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(19549813591325301)
,p_item_source_plug_id=>wwv_flow_api.id(19549813591325301)
,p_prompt=>'Fk Type'
,p_source=>'FK_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6821157898640897)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' insert into t_rel_kont_buch_kont_buch',
' (',
' ',
'  fk_konto_buch1,',
'     fk_konto_buch2,',
'     bemerkung',
' )',
' select :P296_FK_MAiN_KEY1,',
' :P296_FK_MAIN_KEY2,',
' :P296_Text',
' from dual;',
' commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(6819529076639206)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19723506494495763)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(19549813591325301)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'New'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19549967875325302)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(19549813591325301)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Zugeordnete_Buchung'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
