prompt --application/pages/page_00353
begin
--   Manifest
--     PAGE: 00353
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>353
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'storno'
,p_step_title=>'storno'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090610'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15010626296037382)
,p_plug_name=>'storno'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto.*,',
'       rellex.pk_rel_lex_lex,',
'       rellex.fk_relation1,',
'       rellex.fk_relation2,',
'       rellex.datum_ok rellex_datum_ok       ,',
'       rellex.fk_rel_type_lex_lex,',
'       std_name ',
'       ',
'  from imp_kontenblatt_2018 kto',
'   left join t_rel_lex_lex rellex on kto.fk_relation = rellex.fk_relation1 or kto.fk_relation = rellex.fk_relation2',
'    left join (select * from t_std where fk_std_group = 281) std on std.std_value = rellex.fk_rel_type_lex_lex',
' where buchungsstatus = 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15010736960037383)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>16451056235428923
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15011110610037387)
,p_db_column_name=>'UST'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15011963561037395)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>120
,p_column_identifier=>'B'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15012659135037402)
,p_db_column_name=>'KST'
,p_display_order=>190
,p_column_identifier=>'C'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15012685154037403)
,p_db_column_name=>'KTR'
,p_display_order=>200
,p_column_identifier=>'D'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15012868348037404)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'E'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15013184221037408)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'F'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15048556234090566)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>330
,p_column_identifier=>'G'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15048582290090567)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>340
,p_column_identifier=>'H'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15048797770090569)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>360
,p_column_identifier=>'I'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051308424090594)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>610
,p_column_identifier=>'J'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051432152090595)
,p_db_column_name=>'FK_RELATION1'
,p_display_order=>620
,p_column_identifier=>'K'
,p_column_label=>'Fk Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051519769090596)
,p_db_column_name=>'FK_RELATION2'
,p_display_order=>630
,p_column_identifier=>'L'
,p_column_label=>'Fk Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051652450090597)
,p_db_column_name=>'RELLEX_DATUM_OK'
,p_display_order=>640
,p_column_identifier=>'M'
,p_column_label=>'Rellex Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051724647090598)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>650
,p_column_identifier=>'N'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051828255090599)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>660
,p_column_identifier=>'O'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15051958400090600)
,p_db_column_name=>'KONTOBEZEICHNUNG'
,p_display_order=>670
,p_column_identifier=>'P'
,p_column_label=>'Kontobezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052063695090601)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>680
,p_column_identifier=>'Q'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052110647090602)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>690
,p_column_identifier=>'R'
,p_column_label=>'Belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052276420090603)
,p_db_column_name=>'GEGENKONTO'
,p_display_order=>700
,p_column_identifier=>'S'
,p_column_label=>'Gegenkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052380185090604)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>710
,p_column_identifier=>'T'
,p_column_label=>'Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052402106090605)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>720
,p_column_identifier=>'U'
,p_column_label=>'Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052504892090606)
,p_db_column_name=>'USTKONTO'
,p_display_order=>730
,p_column_identifier=>'V'
,p_column_label=>'Ustkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052594193090607)
,p_db_column_name=>'OK'
,p_display_order=>740
,p_column_identifier=>'W'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052749074090608)
,p_db_column_name=>'SOLLBETRAG_EUR1'
,p_display_order=>750
,p_column_identifier=>'X'
,p_column_label=>'Sollbetrag Eur1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052862617090609)
,p_db_column_name=>'ID'
,p_display_order=>760
,p_column_identifier=>'Y'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15052957446090610)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>770
,p_column_identifier=>'Z'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053073227097961)
,p_db_column_name=>'FK_BELEGDATUM'
,p_display_order=>780
,p_column_identifier=>'AA'
,p_column_label=>'Fk Belegdatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053103379097962)
,p_db_column_name=>'FK_PROJEKT'
,p_display_order=>790
,p_column_identifier=>'AB'
,p_column_label=>'Fk Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053225171097963)
,p_db_column_name=>'FK_GESCHAEFTSPARTNER'
,p_display_order=>800
,p_column_identifier=>'AC'
,p_column_label=>'Fk Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053317703097964)
,p_db_column_name=>'FK_INVENTAR'
,p_display_order=>810
,p_column_identifier=>'AD'
,p_column_label=>'Fk Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053403208097965)
,p_db_column_name=>'FK_LOCATION'
,p_display_order=>820
,p_column_identifier=>'AE'
,p_column_label=>'Fk Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053488093097966)
,p_db_column_name=>'FK_KATEGORIE'
,p_display_order=>830
,p_column_identifier=>'AF'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053646660097967)
,p_db_column_name=>'FK_VERWENDUNGSZWECK'
,p_display_order=>840
,p_column_identifier=>'AG'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053735154097968)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>850
,p_column_identifier=>'AH'
,p_column_label=>'Fk Relation'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_FK_RELATION1,P308_FK_RELATION1_REL:#FK_RELATION#,#FK_RELATION#'
,p_column_linktext=>'#FK_RELATION#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053830798097969)
,p_db_column_name=>'FK_RELATION_SUB'
,p_display_order=>860
,p_column_identifier=>'AI'
,p_column_label=>'Fk Relation Sub'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15053926688097970)
,p_db_column_name=>'DATUM_STEUER_OK'
,p_display_order=>870
,p_column_identifier=>'AJ'
,p_column_label=>'Datum Steuer Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054023448097971)
,p_db_column_name=>'SPLIT_NR_MAN'
,p_display_order=>880
,p_column_identifier=>'AK'
,p_column_label=>'Split Nr Man'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054122864097972)
,p_db_column_name=>'DATUM_SPLIT_OK'
,p_display_order=>890
,p_column_identifier=>'AL'
,p_column_label=>'Datum Split Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054210738097973)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>900
,p_column_identifier=>'AM'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054544647097976)
,p_db_column_name=>'FK_REL_TYPE_LEX_LEX'
,p_display_order=>910
,p_column_identifier=>'AN'
,p_column_label=>'Fk Rel Type Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054765743097978)
,p_db_column_name=>'STD_NAME'
,p_display_order=>920
,p_column_identifier=>'AO'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15071611927132319)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'165120'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'UST:BUCHUNGSTEXT:KST:KTR:JAHR:DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:DUPL_BEMERKUNG:PK_REL_LEX_LEX:FK_RELATION1:FK_RELATION2:RELLEX_DATUM_OK:BUCHUNGSNUMMER:KONTONUMMER:KONTOBEZEICHNUNG:BELEGDATUM:BELEGNUMMER:GEGENKONTO:SOLLBETRAG_EUR:HABENBETRAG_EUR:USTKON'
||'TO:OK:SOLLBETRAG_EUR1:ID:BUCHUNGSSTATUS:FK_BELEGDATUM:FK_PROJEKT:FK_GESCHAEFTSPARTNER:FK_INVENTAR:FK_LOCATION:FK_KATEGORIE:FK_VERWENDUNGSZWECK:FK_RELATION:FK_RELATION_SUB:DATUM_STEUER_OK:SPLIT_NR_MAN:DATUM_SPLIT_OK:DATUM_DUPL_OK:FK_REL_TYPE_LEX_LEX:S'
||'TD_NAME'
,p_break_on=>'PK_REL_LEX_LEX:0:0:0:0:0'
,p_break_enabled_on=>'PK_REL_LEX_LEX:0:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15123257280045230)
,p_report_id=>wwv_flow_api.id(15071611927132319)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RELLEX_DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("RELLEX_DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15123668483045231)
,p_report_id=>wwv_flow_api.id(15071611927132319)
,p_name=>'not_relevant'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STD_NAME'
,p_operator=>'!='
,p_expr=>'keine Angabe'
,p_condition_sql=>' (case when ("STD_NAME" != #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != ''keine Angabe''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B3B3B3'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15021327985058910)
,p_plug_name=>'storno'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select BELEGDAT,',
'       ABSCHLUSS,',
'       BELEG,',
'       BENUTZER,',
'       BETRAGDM,',
'       BETRAGEUR,',
'       BUCHDAT,',
'       NR,',
'       HABENDM,',
'       HABENEUR,',
'       HABEN,',
'       JOUR_DAT,',
'       RELATION,',
'       SOLLDM,',
'       SOLLEUR,',
'       SOLL,',
'       SPERRE,',
'       STAPEL,',
'       STATUS,',
'       STATUS_DAT,',
'       UST_H_DM,',
'       UST_H_EUR,',
'       UST_HABEN,',
'       UST_S_DM,',
'       UST_S_EUR,',
'       UST_SOLL,',
'       UST_DM,',
'       UST_EUR,',
'       UST,',
'       UST_KTO,',
'       UST_KTO_H,',
'       UST_KTO_S,',
'       UST_PROZ,',
'       UST_TEXT,',
'       PERIODE,',
'       BELEGNR,',
'       BUCHUNGSTEXT,',
'       BETRAG,',
'       WHRG,',
'       SOLLKTO,',
'       HABENKTO,',
'       ZUSATZANG,',
'       NOTIZ,',
'       KST,',
'       KTR,',
'       JAHR,',
'       JAHR_BELEG,',
'       BEMERKUNGEN,',
'       LAST_UPDATE_DATE,',
'       ll.DATUM_OK,',
'       FK_OK_STATE,',
'       FK_LEX_LONG_ZUS_RELATION,',
unistr('       "\00DCBERGABEDATUM_AN_STB",'),
'       SEL,',
'       FK_RELATION_MAIN,',
'       STEUER_DATUM_OK,',
'       SPLIT_NR,',
'       FLG_SPLIT_BUCH,',
'       FK_LEX_STORNO,',
'   ',
'       DUPL_BEMERKUNG,',
'       rellex.pk_rel_lex_lex,',
'       rellex.fk_relation1,',
'       rellex.fk_relation2,',
'       rellex.datum_ok rellex_datum_ok,',
'       rellex.fk_rel_type_lex_lex,',
'       std_name',
'  from T_LEX_LONG ll',
'   left join t_rel_lex_lex rellex on ll.relation = rellex.fk_relation1 or ll.relation = rellex.fk_relation2',
'   left join (select * from t_std where fk_std_group = 281) std on std.std_value = rellex.fk_rel_type_lex_lex',
' where  fk_lex_storno = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(15021434469058910)
,p_name=>'storno'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_PK_REL_LEX_LEX:#PK_REL_LEX_LEX#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>16461753744450450
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15021788127058924)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15022191898058930)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15022624708058930)
,p_db_column_name=>'BELEG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15023019152058931)
,p_db_column_name=>'BENUTZER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15023423792058931)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15023791704058931)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15024187979058931)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15024641764058933)
,p_db_column_name=>'NR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP:P253_FK_RELATION,P253_FK_RELATION_MAIN:#RELATION#,#FK_RELATION_MAIN#'
,p_column_linktext=>'#NR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15025069074058933)
,p_db_column_name=>'HABENDM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15025441460058933)
,p_db_column_name=>'HABENEUR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15025788264058933)
,p_db_column_name=>'HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15026229589058935)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15026680254058935)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_FK_RELATION1,P308_FK_RELATION1_REL,P308_FK_REL_TYPE_LEX_LEX,P308_DATUM_OK:#RELATION#,#RELATION#,2,&P353_AKT_DATUM.'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15027066125058935)
,p_db_column_name=>'SOLLDM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15027388718058935)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15027837945058936)
,p_db_column_name=>'SOLL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15028266210058936)
,p_db_column_name=>'SPERRE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15028601791058936)
,p_db_column_name=>'STAPEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15029022535058938)
,p_db_column_name=>'STATUS'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15029417142058938)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15029788063058938)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15030258361058938)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15030597638058938)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15031054717058939)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15031445584058939)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15031836831058939)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15032215853058939)
,p_db_column_name=>'UST_DM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15032629404058941)
,p_db_column_name=>'UST_EUR'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15033026921058941)
,p_db_column_name=>'UST'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15033438528058941)
,p_db_column_name=>'UST_KTO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15033825551058941)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15034274060058942)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15034623182058942)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15034983010058942)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15035399202058942)
,p_db_column_name=>'PERIODE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15035805346058944)
,p_db_column_name=>'BELEGNR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#BELEGNR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15036217521058944)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15036588129058944)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15037070534058944)
,p_db_column_name=>'WHRG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15037463925058945)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15037847079058945)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15038189059058945)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15038667274058945)
,p_db_column_name=>'NOTIZ'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15039061818058947)
,p_db_column_name=>'KST'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15039464962058947)
,p_db_column_name=>'KTR'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15039808172058947)
,p_db_column_name=>'JAHR'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15040202506058947)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15040635716058949)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15040991549058949)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15041465202058949)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15041783431058949)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15042225478058950)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15042636961058950)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15042988286058950)
,p_db_column_name=>'SEL'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15043414465058950)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Fk Relation Main'
,p_column_link=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP:P253_FK_RELATION,P253_FK_RELATION_MAIN:#RELATION#,#FK_RELATION_MAIN#'
,p_column_linktext=>'#FK_RELATION_MAIN#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15043794534058950)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15044256483058952)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15044625930058952)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15045021060058952)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15045867698058952)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15010251234037378)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>71
,p_column_identifier=>'BJ'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15010305945037379)
,p_db_column_name=>'FK_RELATION1'
,p_display_order=>81
,p_column_identifier=>'BK'
,p_column_label=>'Fk Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15010467357037380)
,p_db_column_name=>'FK_RELATION2'
,p_display_order=>91
,p_column_identifier=>'BL'
,p_column_label=>'Fk Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15010514317037381)
,p_db_column_name=>'RELLEX_DATUM_OK'
,p_display_order=>101
,p_column_identifier=>'BM'
,p_column_label=>'Rellex Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054465531097975)
,p_db_column_name=>'FK_REL_TYPE_LEX_LEX'
,p_display_order=>111
,p_column_identifier=>'BN'
,p_column_label=>'Fk Rel Type Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054594902097977)
,p_db_column_name=>'STD_NAME'
,p_display_order=>121
,p_column_identifier=>'BO'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(15071008053132217)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'165114'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_RELATION_MAIN:BELEGNR:PK_REL_LEX_LEX:BELEGDAT:ABSCHLUSS:BELEG:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:RELATION:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_S'
||unistr('OLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:\00DCBERGABEDATUM_AN')
||'_STB:SEL:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DUPL_BEMERKUNG:FK_RELATION1:FK_RELATION2:RELLEX_DATUM_OK:FK_REL_TYPE_LEX_LEX:STD_NAME:'
,p_break_on=>'FK_RELATION_MAIN:0:0:0:0:0'
,p_break_enabled_on=>'FK_RELATION_MAIN:0:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15120958021922974)
,p_report_id=>wwv_flow_api.id(15071008053132217)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RELLEX_DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("RELLEX_DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15121357934922975)
,p_report_id=>wwv_flow_api.id(15071008053132217)
,p_name=>'not_relevant'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STD_NAME'
,p_operator=>'!='
,p_expr=>'Storno'
,p_condition_sql=>' (case when ("STD_NAME" != #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != ''Storno''  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#E0E0E0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(15120507969922974)
,p_report_id=>wwv_flow_api.id(15071008053132217)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15056006305097991)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15056180348097992)
,p_name=>'P353_AKT_DATUM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15056006305097991)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Akt Datum'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
