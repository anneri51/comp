prompt --application/pages/page_00377
begin
--   Manifest
--     PAGE: 00377
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>377
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'dupl_lex_buch'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'dupl_lex_buch'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42901582232549956)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090908'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18282249631295083)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18440521193321463)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18486811084101661)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_duplikat_check_kontrolle'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18486927026101662)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19927246301493202
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18489060710101683)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18489470119101687)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18490686697101700)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>380
,p_column_identifier=>'C'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18495889132101702)
,p_db_column_name=>'PK_DUPLIKAT_CHECK_KONTROLLE'
,p_display_order=>390
,p_column_identifier=>'D'
,p_column_label=>'Pk Duplikat Check Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496005677101703)
,p_db_column_name=>'FK_DUPLKAT_TYPE'
,p_display_order=>400
,p_column_identifier=>'E'
,p_column_label=>'Fk Duplkat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496163186101704)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>410
,p_column_identifier=>'F'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496198967101705)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>420
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496326936101706)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>430
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496400703101707)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>440
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496503203101708)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>450
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496582888101709)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>460
,p_column_identifier=>'K'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18496754974101710)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>470
,p_column_identifier=>'L'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18516149792113577)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'199565'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:FK_STEUER_MONAT:PK_DUPLIKAT_CHECK_KONTROLLE:FK_DUPLKAT_TYPE:FK_DUPLIKAT_CHECK_STATUS:DATUM_OK:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:'
,p_sort_column_1=>'FK_DUPLKAT_TYPE'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR:FK_STEUER_MONAT'
,p_break_enabled_on=>'JAHR:FK_STEUER_MONAT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18521685757172578)
,p_report_id=>wwv_flow_api.id(18516149792113577)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18522173167172580)
,p_report_id=>wwv_flow_api.id(18516149792113577)
,p_name=>'all'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'='
,p_expr=>'999'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18522571999172580)
,p_report_id=>wwv_flow_api.id(18516149792113577)
,p_name=>'inp_bel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'in'
,p_expr=>'1,2'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1, 2  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18522978000172580)
,p_report_id=>wwv_flow_api.id(18516149792113577)
,p_name=>'t_lex'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18523314500172581)
,p_report_id=>wwv_flow_api.id(18516149792113577)
,p_name=>'inp_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18496878906106361)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dpc.*, dp.FK_RELATION1_LEX, ll.betrag',
'from t_duplikat_check dpc',
' left join t_duplikat dp on  dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join t_lex_long ll on ll.relation  = dp.fk_relation1_lex '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18496949355106362)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19937268630497902
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497061359106363)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497089285106364)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497565314106368)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497633484106369)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497731182106370)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497793530106371)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18497901287106372)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18498060134106373)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18498151910106374)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18498230289106375)
,p_db_column_name=>'PK_DUPLIKAT_CHECK'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Pk Duplikat Check'
,p_column_link=>'f?p=&APP_ID.:377:&SESSION.::&DEBUG.:RP:P377_PK_DUPLIKAT_CHECK,P377_FK_TYPE:#PK_DUPLIKAT_CHECK#,#FK_DUPLIKAT_TYPE#'
,p_column_linktext=>'#PK_DUPLIKAT_CHECK#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18498301124106376)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Fk Relation1 Lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18821433590682874)
,p_db_column_name=>'FK_DUPLIKAT_TYPE'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Fk Duplikat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19091989840978567)
,p_db_column_name=>'BETRAG'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18516697855113597)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'199571'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'JAHR:DATUM_OK:FK_DUPLIKAT_CHECK_STATUS:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:PK_DUPLIKAT_CHECK:FK_RELATION1_LEX:FK_DUPLIKAT_TYPE:BETRAG'
,p_sort_column_1=>'PK_DUPLIKAT_CHECK'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'FK_DUPLIKAT_TYPE:PK_DUPLIKAT_CHECK'
,p_break_enabled_on=>'FK_DUPLIKAT_TYPE:PK_DUPLIKAT_CHECK'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19005050019668753)
,p_report_id=>wwv_flow_api.id(18516697855113597)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18501498873106408)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2, pk_duplikat_check) sel,',
'apex_item.checkbox2(3, pk_duplikat) sel2,',
'dpc.*, dp.FK_RELATION1_LEX, ',
'Betrag',
'from t_duplikat_check dpc ',
' left join t_duplikat dp on dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join t_lex_long ll on ll.relation = dp.fk_relation1_lex',
' where Pk_duplikat_check = :P377_PK_duplikat_check'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18501612173106409)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19941931448497949
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18501683562106410)
,p_db_column_name=>'JAHR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820167914682861)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820303889682863)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820463571682864)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820579911682865)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820612858682866)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820716390682867)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820783035682868)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18820898010682869)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18821064778682870)
,p_db_column_name=>'PK_DUPLIKAT_CHECK'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Duplikat Check'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18821109134682871)
,p_db_column_name=>'FK_RELATION1_LEX'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Relation1 Lex'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18821313806682873)
,p_db_column_name=>'SEL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f02''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18821541688682875)
,p_db_column_name=>'FK_DUPLIKAT_TYPE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Duplikat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18822697262682887)
,p_db_column_name=>'SEL2'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18933261664474207)
,p_db_column_name=>'BETRAG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18835231795764406)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'202756'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:SEL2:JAHR:DATUM_OK:FK_DUPLIKAT_CHECK_STATUS:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:PK_DUPLIKAT_CHECK:FK_RELATION1_LEX:FK_DUPLIKAT_TYPE::BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19004397399627578)
,p_report_id=>wwv_flow_api.id(18835231795764406)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19044189187776509)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(6235979950136001)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18321473244385358)
,p_plug_name=>'dupl_lex_buch_selected'
,p_parent_plug_id=>wwv_flow_api.id(19044189187776509)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'                select ',
'                    ll.* ,',
'                    ---duplettencheck',
'                    row_number() over (partition by ll.jahr order by ll.jahr) dupl_jahr,',
'                    row_number() over (partition by monat order by monat) dupl_monat,',
'                    row_number() over (partition by tag order by tag) dupl_tag,',
'                    row_number() over (partition by buchungstext order by buchungstext ) dupl_buchtxt, ',
'                    row_number() over (partition by betrag order by betrag) dupl_betrag,',
'                    row_number() over (partition by habenkto order by habenkto) dupl_habenkto,',
'                    row_number() over (partition by sollkto order by sollkto) dupl_sollkto,',
'                    row_number() over (partition by ust_kto order by ust_kto) dupl_ustkto,',
'                    row_number() over (partition by habeneur order by habeneur) dupl_habeneur,',
'                    row_number() over (partition by solleur order by solleur) dupl_solleur,',
'                    row_number() over (partition by ust_eur order by ust_eur) dupl_usteur,',
'                   arb.monat,',
'                   arb.tag,',
'                   arb.jahr arb_jahr, ',
'                    dp.pk_duplikat,',
'                  dp.datum_ok dp_datum_ok',
'                from (select * from t_lex_long where status is null) ll',
'                 join (select * from t_duplikat where fk_duplikat_check = :P377_PK_duplikat_check) dp  on dp.fk_relation1_lex = ll.relation',
'                  left join t_arbeitstage arb on arb.pk_arbeitstage = ll.fk_belegdat',
'               ',
'                     ',
'    /*',
'    ---1 jahr',
'    ---2 monat',
'    ---3 tag',
'    ---4 buchungstext',
'    ---5 betrag',
'    ---6 habenkto',
'    ---7 sollkto',
'    ---8 ustkto',
'    ---9 habeneur',
'    ---10 solleur',
'    ---11 usteur',
'    ',
'    */',
')',
'select apex_item.checkbox2(1, bas.relation) sel,',
'    apex_item.checkbox2(3, pk_duplikat) sel_pk_dp,',
'    bas.*,',
'    case when dupl_jahr.jahr = bas.Jahr then bas.jahr else 0 end dupl_jahr_mark,',
'    case when dupl_monat.monat = bas.monat then bas.monat else 0 end dupl_monat_mark,',
'    case when dupl_tag.tag = bas.tag then bas.tag else 0 end dupl_tag_mark,',
'    case when dupl_buchtxt.buchungstext = bas.buchungstext then bas.buchungstext else '''' end dupl_buchungstxt_mark,',
'    case when dupl_betrag.betrag = bas.betrag then bas.betrag else 0 end dupl_betrag_mark,',
'    case when dupl_habenkto.habenkto = bas.habenkto then bas.habenkto else 0 end dupl_habenkto_mark,',
'    dupl_sollkto.sollkto  dupl_sollkto_mark, -- case when dupl_sollkto = bas.sollkto then bas.sollkto else 0 end dupl_sollkto_mark,',
'    case when dupl_ustkto.ust_kto = bas.ust_kto then bas.ust_kto else 0 end dupl_ustkto_mark,',
'    case when dupl_habeneur.habeneur = bas.habeneur then bas.habeneur else 0 end dupl_habeneur_mark,',
'    case when dupl_solleur.solleur = bas.solleur then bas.solleur else 0 end dupl_solleur_mark,',
'    case when dupl_usteur.ust_eur = bas.ust_eur then bas.ust_eur else 0 end dupl_ust_eur_mark',
'from bas',
'  left join (select distinct jahr from bas where dupl_jahr >1 ) dupL_jahr on  dupl_jahr.jahr = bas.jahr ',
'  left join (select distinct monat from bas where dupl_monat >1 ) dupL_monat on  dupl_monat.monat = bas.monat ',
'  left join (select distinct tag from bas where dupl_tag >1 ) dupL_tag on  dupl_tag.tag = bas.tag',
'  left join (select distinct buchungstext from bas where dupl_buchtxt >1 ) dupL_buchtxt on  dupl_buchtxt.buchungstext = bas.buchungstext',
'  left join (select distinct betrag from bas where dupl_betrag >1 ) dupL_betrag on  dupl_betrag.betrag= bas.betrag',
'  left join (select distinct habenkto from bas where dupl_habenkto >1 ) dupL_habenkto on  dupl_habenkto.habenkto= bas.habenkto',
'  left join (select distinct sollkto from bas where dupl_sollkto >1 ) dupL_sollkto on  dupl_sollkto.sollkto= bas.sollkto',
'  left join (select distinct ust_kto from bas where dupl_ustkto >1 ) dupL_ustkto on  dupl_ustkto.ust_kto= bas.ust_kto',
'  left join (select distinct habeneur from bas where dupl_habeneur >1 ) dupL_habeneur on  dupl_habeneur.habeneur= bas.habeneur',
'  left join (select distinct solleur from bas where dupl_solleur >1 ) dupL_solleur on  dupl_solleur.solleur= bas.solleur',
'  left join (select distinct ust_eur from bas where dupl_usteur >1 ) dupL_usteur on  dupl_usteur.ust_eur= bas.ust_eur',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18321490556385358)
,p_name=>'dupl_lex_buch'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19761809831776898
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18321900855385360)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18322255131385360)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18322602934385360)
,p_db_column_name=>'BELEG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18323013780385360)
,p_db_column_name=>'BENUTZER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18323439734385360)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18323855947385361)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18324254208385361)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18324641920385361)
,p_db_column_name=>'NR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18325012354385361)
,p_db_column_name=>'HABENDM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18325405692385361)
,p_db_column_name=>'HABENEUR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18325837661385363)
,p_db_column_name=>'HABEN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18326264633385363)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18326594528385363)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:378:&SESSION.::&DEBUG.:RP:P378_FK_RELATION:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18327039210385363)
,p_db_column_name=>'SOLLDM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18327436903385363)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18327879039385364)
,p_db_column_name=>'SOLL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18328208258385364)
,p_db_column_name=>'SPERRE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18328642919385364)
,p_db_column_name=>'STAPEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18329019090385364)
,p_db_column_name=>'STATUS'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18329396001385364)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18329879068385366)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18330192715385366)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18330675820385366)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18331010274385366)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18331460442385366)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18331799872385367)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18332260023385367)
,p_db_column_name=>'UST_DM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18332653833385367)
,p_db_column_name=>'UST_EUR'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18333002038385367)
,p_db_column_name=>'UST'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18333426600385369)
,p_db_column_name=>'UST_KTO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18333817322385369)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18334203667385369)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18334654730385369)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18335034309385369)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18335391988385370)
,p_db_column_name=>'PERIODE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18335861907385370)
,p_db_column_name=>'BELEGNR'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18336219219385370)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18336657299385370)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18337045368385372)
,p_db_column_name=>'WHRG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18337430676385372)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18337818817385372)
,p_db_column_name=>'HABENKTO'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18338245022385372)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18338663995385372)
,p_db_column_name=>'NOTIZ'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18338983451385374)
,p_db_column_name=>'KST'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18339415766385374)
,p_db_column_name=>'KTR'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18339822344385374)
,p_db_column_name=>'JAHR'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18340182875385374)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18340625219385375)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18341009706385375)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18341393360385375)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18341783242385375)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18342271168385377)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18342621331385377)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18343386426385378)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18343858175385378)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18344263280385378)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18344675630385378)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18345059117385380)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18345425163385380)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18345863039385380)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18346206771385380)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>62
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18346633361385381)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>63
,p_column_identifier=>'BK'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18347053121385381)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>64
,p_column_identifier=>'BL'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18347479301385381)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>65
,p_column_identifier=>'BM'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18347831306385383)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>66
,p_column_identifier=>'BN'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283073209295091)
,p_db_column_name=>'DUPL_JAHR'
,p_display_order=>76
,p_column_identifier=>'BO'
,p_column_label=>'Dupl Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283140647295092)
,p_db_column_name=>'DUPL_BUCHTXT'
,p_display_order=>86
,p_column_identifier=>'BP'
,p_column_label=>'Dupl Buchtxt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283251760295093)
,p_db_column_name=>'DUPL_BETRAG'
,p_display_order=>96
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283367545295094)
,p_db_column_name=>'DUPL_HABENKTO'
,p_display_order=>106
,p_column_identifier=>'BR'
,p_column_label=>'Dupl Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283436162295095)
,p_db_column_name=>'DUPL_SOLLKTO'
,p_display_order=>116
,p_column_identifier=>'BS'
,p_column_label=>'Dupl Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283512372295096)
,p_db_column_name=>'DUPL_JAHR_MARK'
,p_display_order=>126
,p_column_identifier=>'BT'
,p_column_label=>'Dupl Jahr Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283605541295097)
,p_db_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_display_order=>136
,p_column_identifier=>'BU'
,p_column_label=>'Dupl Buchungstxt Mark'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283711187295098)
,p_db_column_name=>'DUPL_BETRAG_MARK'
,p_display_order=>146
,p_column_identifier=>'BV'
,p_column_label=>'Dupl Betrag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283818534295099)
,p_db_column_name=>'DUPL_USTKTO'
,p_display_order=>156
,p_column_identifier=>'BW'
,p_column_label=>'Dupl Ustkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18283922148295100)
,p_db_column_name=>'DUPL_HABENEUR'
,p_display_order=>166
,p_column_identifier=>'BX'
,p_column_label=>'Dupl Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284058128295101)
,p_db_column_name=>'DUPL_SOLLEUR'
,p_display_order=>176
,p_column_identifier=>'BY'
,p_column_label=>'Dupl Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284089488295102)
,p_db_column_name=>'FK_BELEGDAT'
,p_display_order=>186
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284256241295103)
,p_db_column_name=>'FK_JOURDAT'
,p_display_order=>196
,p_column_identifier=>'CA'
,p_column_label=>'Fk Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284354356295104)
,p_db_column_name=>'DUPL_MONAT'
,p_display_order=>206
,p_column_identifier=>'CB'
,p_column_label=>'Dupl Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284387761295105)
,p_db_column_name=>'DUPL_TAG'
,p_display_order=>216
,p_column_identifier=>'CC'
,p_column_label=>'Dupl Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284546021295106)
,p_db_column_name=>'MONAT'
,p_display_order=>226
,p_column_identifier=>'CD'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284658824295107)
,p_db_column_name=>'TAG'
,p_display_order=>236
,p_column_identifier=>'CE'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284761650295108)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>246
,p_column_identifier=>'CF'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284793771295109)
,p_db_column_name=>'DUPL_HABENKTO_MARK'
,p_display_order=>256
,p_column_identifier=>'CG'
,p_column_label=>'Dupl Habenkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18284889111295110)
,p_db_column_name=>'DUPL_USTEUR'
,p_display_order=>266
,p_column_identifier=>'CH'
,p_column_label=>'Dupl Usteur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18440346956321461)
,p_db_column_name=>'DUPL_MONAT_MARK'
,p_display_order=>276
,p_column_identifier=>'CI'
,p_column_label=>'Dupl Monat Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18440390476321462)
,p_db_column_name=>'DUPL_TAG_MARK'
,p_display_order=>286
,p_column_identifier=>'CJ'
,p_column_label=>'Dupl Tag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18441093448321469)
,p_db_column_name=>'SEL'
,p_display_order=>296
,p_column_identifier=>'CL'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18441276720321470)
,p_db_column_name=>'SEL_RELATION'
,p_display_order=>306
,p_column_identifier=>'CM'
,p_column_label=>'Sel Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18933336660474208)
,p_db_column_name=>'DUPL_SOLLKTO_MARK'
,p_display_order=>316
,p_column_identifier=>'CN'
,p_column_label=>'Dupl Sollkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18933454704474209)
,p_db_column_name=>'DUPL_USTKTO_MARK'
,p_display_order=>326
,p_column_identifier=>'CO'
,p_column_label=>'Dupl Ustkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18933559619474210)
,p_db_column_name=>'DUPL_HABENEUR_MARK'
,p_display_order=>336
,p_column_identifier=>'CP'
,p_column_label=>'Dupl Habeneur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19008859246671661)
,p_db_column_name=>'DUPL_SOLLEUR_MARK'
,p_display_order=>346
,p_column_identifier=>'CQ'
,p_column_label=>'Dupl Solleur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19008943996671662)
,p_db_column_name=>'DUPL_UST_EUR_MARK'
,p_display_order=>356
,p_column_identifier=>'CR'
,p_column_label=>'Dupl Ust Eur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19091536288978562)
,p_db_column_name=>'PK_DUPLIKAT'
,p_display_order=>376
,p_column_identifier=>'CU'
,p_column_label=>'Pk Duplikat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19091596589978563)
,p_db_column_name=>'SEL_PK_DP'
,p_display_order=>386
,p_column_identifier=>'CV'
,p_column_label=>'Sel Pk Dp'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19091979985978566)
,p_db_column_name=>'DP_DATUM_OK'
,p_display_order=>396
,p_column_identifier=>'CW'
,p_column_label=>'Dp Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18350793381443624)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197912'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:SEL_PK_DP:BELEGDAT:ABSCHLUSS:BUCHDAT:JOUR_DAT:NR:BELEG:RELATION:BETRAGEUR:BETRAGDM:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:HABENDM:HABENEUR:HABEN:SOLLDM:SOLLEUR:SOLL:SPERRE:DUPL_JAHR_MARK:DUPL_MONAT_MARK:DUPL_TAG_MARK:DUPL_BUCHUNGSTXT_MARK:DUPL_BETRA'
||'G_MARK:DUPL_HABENKTO_MARK:DUPL_SOLLKTO_MARK:DUPL_USTKTO_MARK:DUPL_HABENEUR_MARK:DUPL_SOLLEUR_MARK:DUPL_UST_EUR_MARK:STAPEL:STATUS:STATUS_DAT:UST_H_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_P'
||unistr('ROZ:UST_TEXT:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:\00DCBERGABEDATUM_AN_STB:FK_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DU')
||unistr('PL_OK:DUPL_BEMERKUNG:FK_DUPL_STATUS:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:DUPL_JAHR:DUPL_BUCHTXT:DUPL_BETRAG:DUPL_HABENKTO:DUPL_SOLLKTO:DUPL_USTKTO:DUPL_HABENEUR:DUPL_SOLLEUR:FK_BELEGDAT:FK_JOURDAT:TAG:ARB_JAHR:DUPL_USTEUR:SEL_RELATION:DUPL_MONAT')
||':DUPL_TAG:FK_STEUER_MONAT:FK_STEUER_VORANMELDG:MONAT:PK_DUPLIKAT::DP_DATUM_OK'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19136623709700814)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'betr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BETRAG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E0E0E0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19136985618700816)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DP_DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DP_DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19137440817700816)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'bm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_BETRAG_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_BETRAG_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19137789180700816)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'btxtm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_BUCHUNGSTXT_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19138277515700817)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'hem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENEUR_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENEUR_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19138606460700819)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'hbktom'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENKTO_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENKTO_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19139026311700819)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'hkm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_HABENKTO_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_HABENKTO_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19139422229700819)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'jrm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_JAHR_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_JAHR_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19139785574700820)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'mm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_MONAT_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_MONAT_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19140212773700820)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'mnodup'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_MONAT_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_MONAT_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19140608756700820)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'sem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLEUR_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_SOLLEUR_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19141024963700822)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'skom'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLKTO_MARK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DUPL_SOLLKTO_MARK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19141442778700822)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'skm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_SOLLKTO_MARK'
,p_operator=>'is null'
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_SOLLKTO_MARK" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19141811239700822)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'tm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_TAG_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_TAG_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19142260183700824)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'tnodup'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_TAG_MARK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_TAG_MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19142619583700825)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'ukm'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_USTKTO_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_USTKTO_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19143065624700825)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'uem'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUPL_UST_EUR_MARK'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DUPL_UST_EUR_MARK" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19143391853700827)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'habenkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("HABENKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E3E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19143854586700828)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'jahr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("JAHR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#BAB6BA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19144202215700830)
,p_report_id=>wwv_flow_api.id(18350793381443624)
,p_name=>'sollkto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SOLLKTO" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#F0F0F0'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19009021379671663)
,p_plug_name=>'dupl_lex_buch_wo_select'
,p_parent_plug_id=>wwv_flow_api.id(19044189187776509)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'                select ',
'                    ll.* ,',
'                    ---duplettencheck',
'                    row_number() over (partition by ll.jahr order by ll.jahr) dupl_jahr,',
'                    row_number() over (partition by monat order by monat) dupl_monat,',
'                    row_number() over (partition by tag order by tag) dupl_tag,',
'                    row_number() over (partition by buchungstext order by buchungstext ) dupl_buchtxt, ',
'                    row_number() over (partition by betrag order by betrag) dupl_betrag,',
'                    row_number() over (partition by habenkto order by habenkto) dupl_habenkto,',
'                    row_number() over (partition by sollkto order by sollkto) dupl_sollkto,',
'                    row_number() over (partition by ust_kto order by ust_kto) dupl_ustkto,',
'                    row_number() over (partition by habeneur order by habeneur) dupl_habeneur,',
'                    row_number() over (partition by solleur order by solleur) dupl_solleur,',
'                    row_number() over (partition by ust_eur order by ust_eur) dupl_usteur,',
'                   arb.monat,',
'                   arb.tag,',
'                   arb.jahr arb_jahr',
'                from (select * from t_lex_long where status is null) ll',
'                  left join t_arbeitstage arb on arb.pk_arbeitstage = ll.fk_belegdat',
'                where (betrag = replace(:P377_betrag,''%2C'','','')  or :P377_betrag is null)',
'                 and (belegdat= :P377_datum or  :P377_datum is null)',
'                 and (ll.jahr = :P377_jahr or :P377_jahr is null)',
'                     ',
'    /*',
'    ---1 jahr',
'    ---2 monat',
'    ---3 tag',
'    ---4 buchungstext',
'    ---5 betrag',
'    ---6 habenkto',
'    ---7 sollkto',
'    ---8 ustkto',
'    ---9 habeneur',
'    ---10 solleur',
'    ---11 usteur',
'    ',
'    */',
')',
'select apex_item.checkbox2(1, bas.relation) sel,',
'    bas.*,',
'    case when dupl_jahr.jahr = bas.Jahr then bas.jahr else 0 end dupl_jahr_mark,',
'    case when dupl_monat.monat = bas.monat then bas.monat else 0 end dupl_monat_mark,',
'    case when dupl_tag.tag = bas.tag then bas.tag else 0 end dupl_tag_mark,',
'    case when dupl_buchtxt.buchungstext = bas.buchungstext then bas.buchungstext else '''' end dupl_buchungstxt_mark,',
'    case when dupl_betrag.betrag = bas.betrag then bas.betrag else 0 end dupl_betrag_mark,',
'    case when dupl_habenkto.habenkto = bas.habenkto then bas.habenkto else 0 end dupl_habenkto_mark,',
'    dupl_sollkto.sollkto  dupl_sollkto_mark, -- case when dupl_sollkto = bas.sollkto then bas.sollkto else 0 end dupl_sollkto_mark,',
'    case when dupl_ustkto.ust_kto = bas.ust_kto then bas.ust_kto else 0 end dupl_ustkto_mark,',
'    case when dupl_habeneur.habeneur = bas.habeneur then bas.habeneur else 0 end dupl_habeneur_mark,',
'    case when dupl_solleur.solleur = bas.solleur then bas.solleur else 0 end dupl_solleur_mark,',
'    case when dupl_usteur.ust_eur = bas.ust_eur then bas.ust_eur else 0 end dupl_ust_eur_mark',
'from bas',
'  left join (select distinct jahr from bas where dupl_jahr >1 ) dupL_jahr on  dupl_jahr.jahr = bas.jahr ',
'  left join (select distinct monat from bas where dupl_monat >1 ) dupL_monat on  dupl_monat.monat = bas.monat ',
'  left join (select distinct tag from bas where dupl_tag >1 ) dupL_tag on  dupl_tag.tag = bas.tag',
'  left join (select distinct buchungstext from bas where dupl_buchtxt >1 ) dupL_buchtxt on  dupl_buchtxt.buchungstext = bas.buchungstext',
'  left join (select distinct betrag from bas where dupl_betrag >1 ) dupL_betrag on  dupl_betrag.betrag= bas.betrag',
'  left join (select distinct habenkto from bas where dupl_habenkto >1 ) dupL_habenkto on  dupl_habenkto.habenkto= bas.habenkto',
'  left join (select distinct sollkto from bas where dupl_sollkto >1 ) dupL_sollkto on  dupl_sollkto.sollkto= bas.sollkto',
'  left join (select distinct ust_kto from bas where dupl_ustkto >1 ) dupL_ustkto on  dupl_ustkto.ust_kto= bas.ust_kto',
'  left join (select distinct habeneur from bas where dupl_habeneur >1 ) dupL_habeneur on  dupl_habeneur.habeneur= bas.habeneur',
'  left join (select distinct solleur from bas where dupl_solleur >1 ) dupL_solleur on  dupl_solleur.solleur= bas.solleur',
'  left join (select distinct ust_eur from bas where dupl_usteur >1 ) dupL_usteur on  dupl_usteur.ust_eur= bas.ust_eur',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19009130945671664)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>20449450221063204
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009214105671665)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009373795671666)
,p_db_column_name=>'UST_DM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ust Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009385830671667)
,p_db_column_name=>'UST_EUR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Ust Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009573797671668)
,p_db_column_name=>'UST'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009587747671669)
,p_db_column_name=>'UST_KTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009747309671670)
,p_db_column_name=>'UST_KTO_H'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Ust Kto H'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009815222671671)
,p_db_column_name=>'UST_KTO_S'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Ust Kto S'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19009899084671672)
,p_db_column_name=>'UST_PROZ'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Ust Proz'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010029572671673)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010126861671674)
,p_db_column_name=>'PERIODE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Periode'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010232374671675)
,p_db_column_name=>'BELEGNR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010325373671676)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010435568671677)
,p_db_column_name=>'BETRAG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010504109671678)
,p_db_column_name=>'WHRG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Whrg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010671315671679)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010718564671680)
,p_db_column_name=>'HABENKTO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010849188671681)
,p_db_column_name=>'ZUSATZANG'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Zusatzang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010946160671682)
,p_db_column_name=>'NOTIZ'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Notiz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19010996724671683)
,p_db_column_name=>'KST'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011137892671684)
,p_db_column_name=>'KTR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011222522671685)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011371033671686)
,p_db_column_name=>'JAHR_BELEG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Jahr Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011480587671687)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011553541671688)
,p_db_column_name=>'LAST_UPDATE_DATE'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Last Update Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011653010671689)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011688651671690)
,p_db_column_name=>'FK_OK_STATE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Ok State'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011863200671691)
,p_db_column_name=>'FK_LEX_LONG_ZUS_RELATION'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Fk Lex Long Zus Relation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011918864671692)
,p_db_column_name=>'ABSCHLUSS'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Abschluss'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19011993926671693)
,p_db_column_name=>unistr('\00DCBERGABEDATUM_AN_STB')
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('\00DCbergabedatum An Stb')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012155917671694)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012256392671695)
,p_db_column_name=>'STEUER_DATUM_OK'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Steuer Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012367881671696)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012391801671697)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012513726671698)
,p_db_column_name=>'FK_LEX_STORNO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Fk Lex Storno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012665878671699)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012735494671700)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012808591671701)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19012958874671702)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013054879671703)
,p_db_column_name=>'FK_STEUER_VORANMELDG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Fk Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013117629671704)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013256598671705)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013315347671706)
,p_db_column_name=>'DUPL_JAHR'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Dupl Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013419061671707)
,p_db_column_name=>'DUPL_BUCHTXT'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Dupl Buchtxt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013483338671708)
,p_db_column_name=>'DUPL_BETRAG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Dupl Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013605838671709)
,p_db_column_name=>'DUPL_HABENKTO'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Dupl Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19013753442671710)
,p_db_column_name=>'DUPL_SOLLKTO'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Dupl Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039409009776461)
,p_db_column_name=>'DUPL_JAHR_MARK'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Dupl Jahr Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039490737776462)
,p_db_column_name=>'DUPL_BUCHUNGSTXT_MARK'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Dupl Buchungstxt Mark'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039600359776463)
,p_db_column_name=>'DUPL_BETRAG_MARK'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Dupl Betrag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039696427776464)
,p_db_column_name=>'DUPL_USTKTO'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Dupl Ustkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039838138776465)
,p_db_column_name=>'DUPL_HABENEUR'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Dupl Habeneur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19039966812776466)
,p_db_column_name=>'DUPL_SOLLEUR'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Dupl Solleur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040015881776467)
,p_db_column_name=>'FK_BELEGDAT'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Fk Belegdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040174598776468)
,p_db_column_name=>'BELEG'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040249939776469)
,p_db_column_name=>'FK_JOURDAT'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fk Jourdat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040322254776470)
,p_db_column_name=>'DUPL_MONAT'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Dupl Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040426743776471)
,p_db_column_name=>'DUPL_TAG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Dupl Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040501275776472)
,p_db_column_name=>'MONAT'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040668961776473)
,p_db_column_name=>'TAG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040700676776474)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040838168776475)
,p_db_column_name=>'DUPL_HABENKTO_MARK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Dupl Habenkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19040899583776476)
,p_db_column_name=>'DUPL_USTEUR'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Dupl Usteur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041024907776477)
,p_db_column_name=>'DUPL_MONAT_MARK'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Dupl Monat Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041129330776478)
,p_db_column_name=>'DUPL_TAG_MARK'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Dupl Tag Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041219020776479)
,p_db_column_name=>'SEL'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041316314776480)
,p_db_column_name=>'SEL_RELATION'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Sel Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041403235776481)
,p_db_column_name=>'DUPL_SOLLKTO_MARK'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Dupl Sollkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041558350776482)
,p_db_column_name=>'DUPL_USTKTO_MARK'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Dupl Ustkto Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041665523776483)
,p_db_column_name=>'DUPL_HABENEUR_MARK'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Dupl Habeneur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041774823776484)
,p_db_column_name=>'DUPL_SOLLEUR_MARK'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Dupl Solleur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041850744776485)
,p_db_column_name=>'DUPL_UST_EUR_MARK'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Dupl Ust Eur Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19041903374776486)
,p_db_column_name=>'BENUTZER'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Benutzer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042066119776487)
,p_db_column_name=>'BETRAGDM'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Betragdm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042107551776488)
,p_db_column_name=>'BETRAGEUR'
,p_display_order=>740
,p_column_identifier=>'BV'
,p_column_label=>'Betrageur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042215598776489)
,p_db_column_name=>'BUCHDAT'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Buchdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042289100776490)
,p_db_column_name=>'NR'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042424768776491)
,p_db_column_name=>'HABENDM'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Habendm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042538206776492)
,p_db_column_name=>'HABENEUR'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Habeneur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042672251776493)
,p_db_column_name=>'HABEN'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Haben'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042729329776494)
,p_db_column_name=>'JOUR_DAT'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Jour Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042836202776495)
,p_db_column_name=>'RELATION'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Relation'
,p_column_link=>'f?p=&APP_ID.:378:&SESSION.::&DEBUG.:RP:P378_FK_RELATION:#RELATION#'
,p_column_linktext=>'#RELATION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042903189776496)
,p_db_column_name=>'SOLLDM'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Solldm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19042994902776497)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Solleur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043118518776498)
,p_db_column_name=>'SOLL'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043278772776499)
,p_db_column_name=>'SPERRE'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Sperre'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043341690776500)
,p_db_column_name=>'STAPEL'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Stapel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043436613776501)
,p_db_column_name=>'STATUS'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043481508776502)
,p_db_column_name=>'STATUS_DAT'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Status Dat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043607022776503)
,p_db_column_name=>'UST_H_DM'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Ust H Dm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043687146776504)
,p_db_column_name=>'UST_H_EUR'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Ust H Eur'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043822099776505)
,p_db_column_name=>'UST_HABEN'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Ust Haben'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19043915798776506)
,p_db_column_name=>'UST_S_DM'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Ust S Dm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19044045882776507)
,p_db_column_name=>'UST_S_EUR'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Ust S Eur'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19044136229776508)
,p_db_column_name=>'UST_SOLL'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Ust Soll'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19075498821804260)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'205159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BELEGDAT:UST_DM:UST_EUR:UST:UST_KTO:UST_KTO_H:UST_KTO_S:UST_PROZ:UST_TEXT:PERIODE:BELEGNR:BUCHUNGSTEXT:BETRAG:WHRG:SOLLKTO:HABENKTO:ZUSATZANG:NOTIZ:KST:KTR:JAHR:JAHR_BELEG:BEMERKUNGEN:LAST_UPDATE_DATE:DATUM_OK:FK_OK_STATE:FK_LEX_LONG_ZUS_RELATION:ABS'
||unistr('CHLUSS:\00DCBERGABEDATUM_AN_STB:FK_RELATION_MAIN:STEUER_DATUM_OK:SPLIT_NR:FLG_SPLIT_BUCH:FK_LEX_STORNO:DATUM_DUPL_OK:DUPL_BEMERKUNG:FK_DUPL_STATUS:FK_STEUER_MONAT:FK_STEUER_VORANMELDG:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:DUPL_JAHR:DUPL_BUCHTXT:DUPL_')
||'BETRAG:DUPL_HABENKTO:DUPL_SOLLKTO:DUPL_JAHR_MARK:DUPL_BUCHUNGSTXT_MARK:DUPL_BETRAG_MARK:DUPL_USTKTO:DUPL_HABENEUR:DUPL_SOLLEUR:FK_BELEGDAT:BELEG:FK_JOURDAT:DUPL_MONAT:DUPL_TAG:MONAT:TAG:ARB_JAHR:DUPL_HABENKTO_MARK:DUPL_USTEUR:DUPL_MONAT_MARK:DUPL_TAG'
||'_MARK:SEL:SEL_RELATION:DUPL_SOLLKTO_MARK:DUPL_USTKTO_MARK:DUPL_HABENEUR_MARK:DUPL_SOLLEUR_MARK:DUPL_UST_EUR_MARK:BENUTZER:BETRAGDM:BETRAGEUR:BUCHDAT:NR:HABENDM:HABENEUR:HABEN:JOUR_DAT:RELATION:SOLLDM:SOLLEUR:SOLL:SPERRE:STAPEL:STATUS:STATUS_DAT:UST_H'
||'_DM:UST_H_EUR:UST_HABEN:UST_S_DM:UST_S_EUR:UST_SOLL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18282527308295086)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18282249631295083)
,p_button_name=>'set_dupl_Ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Dupl Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18441591503321474)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'Mark_Duplikat'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Mark Duplikat'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18441371585321471)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'New_Duplikatscheck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Duplikatscheck'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18441393105321472)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'add_duplikatsscheck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Duplikatsscheck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18822806806682888)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'remove_duplikat'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'remove_duplikat'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18440697457321465)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'SEt_Type'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Type'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18821795471682878)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'set_dupl_check_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set Dupl Check Datum Ok'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18821957015682879)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'set_dupl_check_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'set_dupl_check_datum_nok'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18440979227321467)
,p_button_sequence=>230
,p_button_plug_id=>wwv_flow_api.id(18440521193321463)
,p_button_name=>'SEt_STatus'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Status'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_column=>5
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18282327239295084)
,p_name=>'P377_JAHR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18282249631295083)
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18282624875295087)
,p_name=>'P377_DATUM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(18282249631295083)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18282867015295089)
,p_name=>'P377_BETRAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(18282249631295083)
,p_item_default=>'select replace(:P377_Betr,''%2C'','','') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Betrag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18440604960321464)
,p_name=>'P377_FK_TYPE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 361'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18440862494321466)
,p_name=>'P377_FK_STATUS'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'fk_status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:keine Angabe;0,ok;1,nok;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18441552064321473)
,p_name=>'P377_FK_DUPLIKATSCHECK'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Duplikatscheck'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_duplikat_check || '' '' || std.std_name d, pk_duplikat_check r',
'from t_duplikat_check dpc',
' left join t_duplikat dp on dpc.pk_duplikat_check = dp.fk_duplikat_check',
' left join (select std_name, std_value',
'from t_std',
'where fk_std_group = 361) std on std.std_value = dpc.FK_DUPLiKAT_TYPE',
'where fk_duplikat_check is null',
'order by pk_duplikat_check desc '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18441777473321475)
,p_name=>'P377_TXT!'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'<b>1 - Mark Duplikat</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18441848211321476)
,p_name=>'P377_TXT2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'<b>2 - Add Duplikatcheck</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18441933914321477)
,p_name=>'P377_TXT!3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'<b>3 - Set Status</b>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442241218321480)
,p_name=>'P377_FK_OBJEKT_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Objekt 1'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442315928321481)
,p_name=>'P377_FK_OBJEKT_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>' Fk Objekt 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442476814321482)
,p_name=>'P377_FK_OBJEKT_3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Objekt 3'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442517051321483)
,p_name=>'P377_FK_OBJEKT_4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Objekt 4'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442588922321484)
,p_name=>'P377_FK_OBJEKT_5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Fk Objekt 5'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18442823423321486)
,p_name=>'P377_FK_OBJEKT_6'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>' '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 381'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18821191951682872)
,p_name=>'P377_PK_DUPLIKAT_CHECK'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(18440521193321463)
,p_prompt=>'Pk Duplikat Check'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'pk_duplikat_check || '' - '' || std_name || datum_ok , pk_duplikat_check',
'from t_duplikat_check dpc',
' left join (select * from t_std where fk_std_group = 361) std on std.std_value = dpc.fk_duplikat_type',
'order by pk_duplikat_check desc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18282963200295090)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' if :P377_betr is not null then',
' ',
' select replace(:P377_Betr,''%2C'','','')  ',
' into :P377_betrag',
' from dual;',
' ',
' end if;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18442068982321478)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_mark_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update t_lex_long  set fk_dupl_status = 1 where relation = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18441591503321474)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18442130628321479)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_new_duplikatscheck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  insert into t_duplikat_check (FK_DUPLiKAT_TYPE, fk_objekt_1, fk_objekt_2, fk_objekt_3, fk_objekt_4, fk_objekt_5,  creation_date)',
'  values (:P377_fk_type, :P377_FK_OBJEKT_1, :P377_FK_OBJEKT_2, :P377_FK_OBJEKT_3 , :P377_FK_OBJEKT_4, :P377_FK_OBJEKT_5, sysdate);',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18441371585321471)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18442912210321487)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_add_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'  insert into t_duplikat (',
'',
'FK_DUPLIKAT_CHECK,',
'FK_DUPL_TYPE,',
'FK_DUPL_STATE,',
'FK_INP_BELEG_ALL1,',
'FK_INP_BELEG_ALL2,',
'FK_RELATION1_LEX,',
'FK_RELATION2_LEX,',
'FK_MAIN_KEY1,',
'FK_MAIN_KEY2,',
'FK_RELATION1_KTBL,',
'FK_RELATION2_KTBL',
'  ',
'  )',
'  values (',
'      ',
'    ',
':P377_FK_DUPLIKATSCHECK,',
':P377_FK_TYPE,',
'null, -- FK_DUPL_STATE,',
'null, --FK_INP_BELEG_ALL1,',
'null, --FK_INP_BELEG_ALL2,',
'apex_application.g_f01(i), ',
'null, --FK_RELATION2_LEX,',
'null, --FK_MAIN_KEY1,',
'null, ---FK_MAIN_KEY2,',
'null, --FK_RELATION1_KTBL,',
'null --FK_RELATION2_KTBL',
'  ',
'  ',
'  ',
'  );',
'  commit;',
'  ',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18441393105321472)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18822529366682885)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_remove_duplikat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'     delete from t_duplikat where pk_duplikat = apex_application.g_f03(i);',
'  commit;',
'  ',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18822806806682888)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18821613330682876)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  --',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    update t_duplikat_check set datum_ok = sysdate where pk_duplikat_check =  apex_application.g_f02(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18821795471682878)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19091702240978564)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_ok_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'     for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    update t_duplikat set datum_ok = sysdate where pk_duplikat =  apex_application.g_f03(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18821795471682878)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18821694994682877)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  --',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    update t_duplikat_check set datum_ok = null where pk_duplikat_check =  apex_application.g_f02(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'   ',
' ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18821957015682879)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(19091832447978565)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_set_status_dupl_check_nok_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'     for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'    update t_duplikat set datum_ok = null where pk_duplikat =  apex_application.g_f03(i) ;',
'    commit;',
' ',
'  end if;',
'   end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18821957015682879)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18822633912682886)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'   --1_mark_duplikat: 1',
'   --2_new_duplikatscheck: --',
'   --3_add_duplikat: 1',
'   --3_remove_duplikat 3',
'   --4_set_status_dupl_check_ok / 4_set_status_dupl_check_nok: 2',
'',
'null;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
