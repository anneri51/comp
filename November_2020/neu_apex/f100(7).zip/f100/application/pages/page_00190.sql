prompt --application/pages/page_00190
begin
--   Manifest
--     PAGE: 00190
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>190
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42875355428359647)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524083837'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6331165586829422)
,p_plug_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum, t1.*',
'from (',
'SELECT',
'',
'     kto.fk_main_key,',
'     id, ',
'     ',
'  ---',
'     TO_CHAR("Buchungstag") "Buchungstag",',
'     ',
'     to_char(nvl(belzus.betrag,round(kto."Betrag",2))) steuergrundbetrag,',
'    ',
'     steuersatz zahl_mwst_satz,',
'     null  zahl_mwst,',
'     netto zahl_nettobetrag,',
' ---',
' ',
'     round(kto."Betrag",2) "Betrag",',
unistr('     "W\00E4hrung",'),
unistr('     round("Fremdw\00E4hrungsbetrag",2) "Fremdw\00E4hrungsbetrag",'),
unistr('     "Fremdw\00E4hrung",'),
'     buchungstext,',
'     "FK_Kategorie",',
'     "FK_Verwendungszweck",',
'     "FK_Kontotyp",',
'     fk_buchungstag,',
'     fk_wertstellung,',
'     verwendungszweck,',
'     kto.kategorie,',
'     bucht_tag,',
'     bucht_monat,',
'     bucht_jahr,',
'     bucht_datum,',
'     wertt_tag,',
'     wertt_monat,',
'     wertt_jahr,',
'     wertt_datum,',
'     "Kontotyp",',
'     rreza.cnt_re,',
'     rreza.rel_teil   sum_rel_teil,',
'     pp.fk_vorgang    paypal_vorg,',
'     CASE',
'         WHEN "FK_Kontotyp" = 1 THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''> ''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN "FK_Kontotyp" = 2 THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN "FK_Kontotyp" = 3 THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN "FK_Kontotyp" = 4 THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'     END link_buchung,',
'     pp."Name",',
'     pp."Artikelbezeichnung",',
'    ',
'     belzus.*,',
'     CASE',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''> ''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'     END link_beleg,',
'     reza.RELEVANTER_TEILBETRAG, ',
'     reza.BEMERKUNG,',
'     re.PK_RECHNUNG, ',
'     re.RECHNUNGSNUMMER, ',
'     re.RECHNUNG, ',
'     re.RECHNUNGSDATUM, ',
'     re.ZEITRAUM_VON, ',
'     re.ZEITRAUM_BIS, ',
'     re.RECHNUNGSBETRAG_NETTO, ',
'     re.FK_STEUERSATZ re_fk_steuersatz, ',
'     re.MWST re_mwst_betrag, ',
'     re.RECHNUNGSBETRAG_BRUTTO, ',
'     re.FK_RECHNUNGSTYP, ',
'     re.FK_ZAHLUNGSART, ',
'     re.SKONTOBETRAG, ',
'     re.SKONTOSATZ, ',
'     re.ZAHLUNG_ABGESCHLOSSEN re_zahlung_abgeschl, ',
'     re.VORSTEUER_BEZAHLT, ',
'     re.STEUERENDABRECHNUNG,',
'     pr.PK_PROJEKT, ',
'     pr.FK_AUFTRAGGEBER, ',
'     pr.FK_PROJEKTPARTNER_1, ',
'     pr.FK_PROJEKTPARTNER_2, ',
'     pr.PROJEKT, ',
'     pr.VON, ',
'     pr.BIS, ',
'     pr.AKTUELLER_STUNDENSATZ, ',
'     pr.PSP_ELEMENT,',
'     pr.RECHNUNG_GESTELLT, ',
'     pr.ZAHLUNG_ABGESCHLOSSEN pr_zahlung_abgeschl, ',
'     pr.PROJEKT_ABGESCHLOSSEN,',
'     inv.PK_INVENTAR, ',
'     inv.INVENTAR, ',
'     inv.ANSCHAFFUNGSDATUM, ',
'     inv.ANSCHAFFUNGSJAHR, ',
'     inv.ABSCHREIBUNGSDAUER, ',
'     inv.RESTBUCHWERT, ',
'     inv.PREIS_NETTO, ',
'     inv.MWST, ',
'     inv.FK_STEUERSATZ, ',
'     inv.PREIS_BRUTTO, ',
'     inv.COMM, ',
'     inv.LIZENZNUMMER, ',
'     inv.ANFORDERUNGSCODE, ',
'     inv.FK_INVENTARTYP, ',
'     inv.KFZ_KENNZEICHEN, ',
'     inv.FAHRGESTELLNR',
'    FROM',
'     v_konten_zus kto',
'     LEFT JOIN (',
'         SELECT',
'             fk_vorgang,',
'             fk_main_key,',
'             art,',
'             bezeichnung,',
'             "Name",',
'             "Artikelbezeichnung"',
'         FROM',
'             "KTO_Paypal" pp',
'             JOIN v_imp_bel_zus bzus ON pp.fk_main_key = bzus.fk_buchung',
'         GROUP BY',
'             fk_vorgang,',
'             fk_main_key,',
'             art,',
'             bezeichnung,',
'             "Name",',
'             "Artikelbezeichnung"',
'     ) pp ON pp.fk_vorgang = kto.fk_vorgang',
'     LEFT JOIN v_imp_bel_zus belzus ON belzus.fk_buchung = kto.fk_main_key',
'     left join t_rel_rechnung_zahlung reza on reza.fk_main_key = kto.fk_main_key',
'     left join t_rechnung re on re.pk_rechnung = reza.fk_rechnung',
'     left join t_projekt pr on pr.pk_Projekt = re.fk_projekt',
'     left join t_rel_inventar_zahlung reinza on reinza.fk_main_key = kto.fk_main_key',
'     left join t_inventare inv on inv.pk_inventar = reinza.fk_inventar',
'     LEFT JOIN (',
'         SELECT',
'             fk_main_key,',
'             COUNT(*) cnt_re,',
'             SUM(relevanter_teilbetrag) rel_teil',
'         FROM',
'             t_rel_rechnung_zahlung',
'         GROUP BY',
'             fk_main_key',
'     ) rreza ON rreza.fk_main_key = kto.fk_main_key',
'     LEFT JOIN (',
'         SELECT',
'             kto.fk_main_key',
'         FROM',
'             t_steuer_lohnsteuerkarte lo',
'             LEFT JOIN t_rel_steuer_lohn_zahl loz ON lo.pk_steuer_lohnsteuerkarte = loz.fk_steuer_lohnsteuerkarte',
'             LEFT JOIN v_konten_zus kto ON kto.fk_main_key = loz.fk_main_key',
'     ) lo ON lo.fk_main_key = kto.fk_main_key',
' UNION',
' SELECT',
' ',
'     NULL fk_main_key,',
'     NULL id,',
'     ',
'     TO_CHAR(belzus.datum) "Buchungstag", ',
'  ---',
'  ',
'     belzus.betrag steuergrundbetrag,',
'     ',
'     belzus.steuersatz,',
'     null mwst,',
'     belzus.netto,',
' ---',
' ',
'     NULL "Betrag",',
unistr('     NULL "W\00E4hrung",'),
unistr('     NULL "Fremdw\00E4hrungsbetrag",'),
unistr('     NULL "Fremdw\00E4hrung",'),
'     NULL buchungstext,',
'     NULL "FK_Kategorie",',
'     NULL "FK_Verwendungszweck",',
'     NULL "FK_Kontotyp",',
'     NULL fk_buchungstag,',
'     NULL fk_wertstellung,',
'     NULL verwendungszweck,',
'     NULL kategorie,',
'     NULL bucht_tag,',
'     NULL bucht_monat,',
'     NULL bucht_jahr,',
'     NULL bucht_datum,',
'     NULL wertt_tag,',
'     NULL wertt_monat,',
'     NULL wertt_jahr,',
'     NULL wertt_datum,',
'     NULL "Kontotyp",',
'     NULL cnt_re,',
'     NULL sum_rel_teil,',
'     NULL paypal_vorg,',
'     NULL link_buchung,',
'     NULL "Name",',
'     NULL "Artikelbezeichnung",',
'     ',
'     belzus.*,',
'     CASE',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''> ''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'     END link_beleg,',
'     null RELEVANTER_TEILBETRAG, ',
'     null BEMERKUNG,',
'     null PK_RECHNUNG, ',
'     null RECHNUNGSNUMMER, ',
'     null RECHNUNG, ',
'     null RECHNUNGSDATUM, ',
'     null ZEITRAUM_VON, ',
'     null ZEITRAUM_BIS, ',
'     null RECHNUNGSBETRAG_NETTO, ',
'     null FK_STEUERSATZ, ',
'     null MWST, ',
'     null RECHNUNGSBETRAG_BRUTTO, ',
'     null FK_RECHNUNGSTYP, ',
'     null FK_ZAHLUNGSART, ',
'     null SKONTOBETRAG, ',
'     null SKONTOSATZ, ',
'     null ZAHLUNG_ABGESCHLOSSEN, ',
'     null VORSTEUER_BEZAHLT, ',
'     null STEUERENDABRECHNUNG,',
'     null PK_PROJEKT, ',
'     null FK_AUFTRAGGEBER, ',
'     null FK_PROJEKTPARTNER_1, ',
'     null FK_PROJEKTPARTNER_2, ',
'     null PROJEKT, ',
'     null VON, ',
'     null BIS, ',
'     null AKTUELLER_STUNDENSATZ, ',
'     null PSP_ELEMENT,',
'     null RECHNUNG_GESTELLT, ',
'     null ZAHLUNG_ABGESCHLOSSEN, ',
'     null PROJEKT_ABGESCHLOSSEN,',
'     inv.PK_INVENTAR, ',
'     inv.INVENTAR, ',
'     inv.ANSCHAFFUNGSDATUM, ',
'     inv.ANSCHAFFUNGSJAHR, ',
'     inv.ABSCHREIBUNGSDAUER, ',
'     inv.RESTBUCHWERT, ',
'     inv.PREIS_NETTO, ',
'     inv.MWST, ',
'     inv.FK_STEUERSATZ, ',
'     inv.PREIS_BRUTTO, ',
'     inv.COMM, ',
'     inv.LIZENZNUMMER, ',
'     inv.ANFORDERUNGSCODE, ',
'     inv.FK_INVENTARTYP, ',
'     inv.KFZ_KENNZEICHEN, ',
'     inv.FAHRGESTELLNR',
'',
' FROM',
'     v_imp_bel_zus belzus',
'     left join t_rel_inventar_zahlung reinza on reinza.fk_imp_ba_bel = belzus.fk_imp_ba_bel',
'     left join t_inventare inv on inv.pk_inventar = reinza.fk_inventar',
' WHERE',
'     belzus.zahlungsart = ''Barzahlung''',
'     ) t1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6331277057829422)
,p_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15641412298250343
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6331703202829426)
,p_db_column_name=>'ROWNUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Rownum'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332147974829427)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332478407829427)
,p_db_column_name=>'ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332886959829428)
,p_db_column_name=>'Buchungstag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Buchungstag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6334870192829432)
,p_db_column_name=>'Betrag'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6335275065829432)
,p_db_column_name=>unistr('W\00E4hrung')
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6335702580829433)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6336128041829434)
,p_db_column_name=>unistr('Fremdw\00E4hrung')
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('Fremdw\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6336548868829435)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6336928059829435)
,p_db_column_name=>'FK_Kategorie'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk Kategorie'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6337329298829436)
,p_db_column_name=>'FK_Verwendungszweck'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Fk Verwendungszweck'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6337720321829437)
,p_db_column_name=>'FK_Kontotyp'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Fk Kontotyp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6338092716829438)
,p_db_column_name=>'FK_BUCHUNGSTAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Fk Buchungstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6338468068829438)
,p_db_column_name=>'FK_WERTSTELLUNG'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Fk Wertstellung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6338930776829439)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6339303811829439)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6339712162829440)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340127182829440)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340495151829441)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340962461829441)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6341356580829442)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6341709714829443)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6342076808829443)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6342518157829444)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6342933963829445)
,p_db_column_name=>'Kontotyp'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6343313066829445)
,p_db_column_name=>'CNT_RE'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Cnt Re'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6343754941829446)
,p_db_column_name=>'SUM_REL_TEIL'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Sum Rel Teil'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344086332829447)
,p_db_column_name=>'PAYPAL_VORG'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Paypal Vorg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344529506829447)
,p_db_column_name=>'LINK_BUCHUNG'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Link Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344957641829448)
,p_db_column_name=>'Name'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6345319537829449)
,p_db_column_name=>'Artikelbezeichnung'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6345728160829451)
,p_db_column_name=>'ART'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Art'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346130626829453)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346488201829454)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346877700829455)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6347301402829457)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6347753486829458)
,p_db_column_name=>'DATUM'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6348072532829459)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6348488305829461)
,p_db_column_name=>'FK_ARBEITSTAG'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Arbeitstag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6348870208829462)
,p_db_column_name=>'FK_BUCHUNG'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Fk Buchung'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6349357485829463)
,p_db_column_name=>'BETRAG'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6349735265829465)
,p_db_column_name=>unistr('W\00C4HRUNG')
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>unistr('W\00E4hrung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350067063829466)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350496165829467)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350873551829468)
,p_db_column_name=>'NETTO'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6351334169829469)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6351678333829470)
,p_db_column_name=>'LINK_BELEG'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Link Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295300001780211)
,p_db_column_name=>'STEUERGRUNDBETRAG'
,p_display_order=>61
,p_column_identifier=>'AZ'
,p_column_label=>'Steuergrundbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295490863780213)
,p_db_column_name=>'RELEVANTER_TEILBETRAG'
,p_display_order=>71
,p_column_identifier=>'BA'
,p_column_label=>'Relevanter teilbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295575820780214)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>81
,p_column_identifier=>'BB'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295673030780215)
,p_db_column_name=>'PK_RECHNUNG'
,p_display_order=>91
,p_column_identifier=>'BC'
,p_column_label=>'Pk rechnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295810590780216)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>101
,p_column_identifier=>'BD'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295881964780217)
,p_db_column_name=>'RECHNUNG'
,p_display_order=>111
,p_column_identifier=>'BE'
,p_column_label=>'Rechnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295998886780218)
,p_db_column_name=>'RECHNUNGSDATUM'
,p_display_order=>121
,p_column_identifier=>'BF'
,p_column_label=>'Rechnungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296078098780219)
,p_db_column_name=>'ZEITRAUM_VON'
,p_display_order=>131
,p_column_identifier=>'BG'
,p_column_label=>'Zeitraum von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296175774780220)
,p_db_column_name=>'ZEITRAUM_BIS'
,p_display_order=>141
,p_column_identifier=>'BH'
,p_column_label=>'Zeitraum bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296346956780221)
,p_db_column_name=>'RECHNUNGSBETRAG_NETTO'
,p_display_order=>151
,p_column_identifier=>'BI'
,p_column_label=>'Rechnungsbetrag netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296412425780222)
,p_db_column_name=>'FK_STEUERSATZ'
,p_display_order=>161
,p_column_identifier=>'BJ'
,p_column_label=>'Fk steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296525340780223)
,p_db_column_name=>'RE_MWST_BETRAG'
,p_display_order=>171
,p_column_identifier=>'BK'
,p_column_label=>'Re mwst betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296594525780224)
,p_db_column_name=>'RECHNUNGSBETRAG_BRUTTO'
,p_display_order=>181
,p_column_identifier=>'BL'
,p_column_label=>'Rechnungsbetrag brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296691180780225)
,p_db_column_name=>'FK_RECHNUNGSTYP'
,p_display_order=>191
,p_column_identifier=>'BM'
,p_column_label=>'Fk rechnungstyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296804040780226)
,p_db_column_name=>'FK_ZAHLUNGSART'
,p_display_order=>201
,p_column_identifier=>'BN'
,p_column_label=>'Fk zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296945033780227)
,p_db_column_name=>'SKONTOBETRAG'
,p_display_order=>211
,p_column_identifier=>'BO'
,p_column_label=>'Skontobetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296986442780228)
,p_db_column_name=>'SKONTOSATZ'
,p_display_order=>221
,p_column_identifier=>'BP'
,p_column_label=>'Skontosatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6297160041780229)
,p_db_column_name=>'RE_ZAHLUNG_ABGESCHL'
,p_display_order=>231
,p_column_identifier=>'BQ'
,p_column_label=>'Re zahlung abgeschl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6358924266383980)
,p_db_column_name=>'VORSTEUER_BEZAHLT'
,p_display_order=>241
,p_column_identifier=>'BR'
,p_column_label=>'Vorsteuer bezahlt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359026035383981)
,p_db_column_name=>'STEUERENDABRECHNUNG'
,p_display_order=>251
,p_column_identifier=>'BS'
,p_column_label=>'Steuerendabrechnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359125743383982)
,p_db_column_name=>'PK_PROJEKT'
,p_display_order=>261
,p_column_identifier=>'BT'
,p_column_label=>'Pk projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359169904383983)
,p_db_column_name=>'FK_AUFTRAGGEBER'
,p_display_order=>271
,p_column_identifier=>'BU'
,p_column_label=>'Fk auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359334060383984)
,p_db_column_name=>'FK_PROJEKTPARTNER_1'
,p_display_order=>281
,p_column_identifier=>'BV'
,p_column_label=>'Fk projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359365606383985)
,p_db_column_name=>'FK_PROJEKTPARTNER_2'
,p_display_order=>291
,p_column_identifier=>'BW'
,p_column_label=>'Fk projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359539607383986)
,p_db_column_name=>'PROJEKT'
,p_display_order=>301
,p_column_identifier=>'BX'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359629713383987)
,p_db_column_name=>'VON'
,p_display_order=>311
,p_column_identifier=>'BY'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359672685383988)
,p_db_column_name=>'BIS'
,p_display_order=>321
,p_column_identifier=>'BZ'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359820153383989)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>331
,p_column_identifier=>'CA'
,p_column_label=>'Aktueller stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359952820383990)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>341
,p_column_identifier=>'CB'
,p_column_label=>'Psp element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360025968383991)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>351
,p_column_identifier=>'CC'
,p_column_label=>'Rechnung gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360134410383992)
,p_db_column_name=>'PR_ZAHLUNG_ABGESCHL'
,p_display_order=>361
,p_column_identifier=>'CD'
,p_column_label=>'Pr zahlung abgeschl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360197545383993)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>371
,p_column_identifier=>'CE'
,p_column_label=>'Projekt abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408693988215313)
,p_db_column_name=>'ZAHL_MWST_SATZ'
,p_display_order=>381
,p_column_identifier=>'CF'
,p_column_label=>'Zahl mwst satz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408794499215314)
,p_db_column_name=>'ZAHL_MWST'
,p_display_order=>391
,p_column_identifier=>'CG'
,p_column_label=>'Zahl mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408951485215315)
,p_db_column_name=>'ZAHL_NETTOBETRAG'
,p_display_order=>401
,p_column_identifier=>'CH'
,p_column_label=>'Zahl nettobetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408978101215316)
,p_db_column_name=>'RE_FK_STEUERSATZ'
,p_display_order=>411
,p_column_identifier=>'CI'
,p_column_label=>'Re fk steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409103961215317)
,p_db_column_name=>'PK_INVENTAR'
,p_display_order=>421
,p_column_identifier=>'CJ'
,p_column_label=>'Pk inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409226227215318)
,p_db_column_name=>'INVENTAR'
,p_display_order=>431
,p_column_identifier=>'CK'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409328829215319)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>441
,p_column_identifier=>'CL'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409450471215320)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>451
,p_column_identifier=>'CM'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409539059215321)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>461
,p_column_identifier=>'CN'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409649330215322)
,p_db_column_name=>'RESTBUCHWERT'
,p_display_order=>471
,p_column_identifier=>'CO'
,p_column_label=>'Restbuchwert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409756720215323)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>481
,p_column_identifier=>'CP'
,p_column_label=>'Preis netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409830396215324)
,p_db_column_name=>'MWST'
,p_display_order=>491
,p_column_identifier=>'CQ'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409921446215325)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>501
,p_column_identifier=>'CR'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409980437215326)
,p_db_column_name=>'COMM'
,p_display_order=>511
,p_column_identifier=>'CS'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6410075838215327)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>521
,p_column_identifier=>'CT'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6410189129215328)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>531
,p_column_identifier=>'CU'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6410357526215329)
,p_db_column_name=>'FK_INVENTARTYP'
,p_display_order=>541
,p_column_identifier=>'CV'
,p_column_label=>'Fk inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6440384718721580)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>551
,p_column_identifier=>'CW'
,p_column_label=>'Kfz kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6440515177721581)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>561
,p_column_identifier=>'CX'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6354441440925365)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'156646'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ROWNUM:FK_MAIN_KEY:ID:Buchungstag_SATZ:Betrag:W\00E4hrung:Fremdw\00E4hrungsbetrag:Fremdw\00E4hrung:BUCHUNGSTEXT:FK_Kategorie:FK_Verwendungszweck:FK_Kontotyp:FK_BUCHUNGSTAG:FK_WERTSTELLUNG:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WE')
||unistr('RTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:Kontotyp:CNT_RE:SUM_REL_TEIL:PAYPAL_VORG:LINK_BUCHUNG:Name:Artikelbezeichnung:ART:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BEZEICHNUNG:KENNZEICHEN:DATUM:DATUM_VERGEHEN:FK_ARBEITSTAG:FK_BUCHUNG:BETRAG:W\00C4HRUNG:STEUERS')
||'ATZ_BETRAG:NETTO:ZAHLUNGSART:LINK_BELEG:STEUERGRUNDBETRAG:RELEVANTER_TEILBETRAG:BEMERKUNG:PK_RECHNUNGSNUMMER:RECHNUNG:RECHNUNGSDATUM:ZEITRAUM_ZEITRAUM_RECHNUNGSBETRAG_NETTO:FK_STEUERSATZ:RE_MWST_BETRAG:RECHNUNGSBETRAG_BRUTTO:FK_RECHNUNGSTYP:FK_ZAHLUN'
||'GSART:SKONTOBETRAG:SKONTOSATZ:RE_ZAHLUNG_ABGESCHL:VORSTEUER_BEZAHLT:STEUERENDABRECHNUNG:PK_FK_AUFTRAGGEBER:FK_PROJEKTPARTNER_1:FK_PROJEKTPARTNER_2:PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:RECHNUNG_GESTELLT:PR_ZAHLUNG_ABGESCHL:PROJEKT_ABGESCH'
||'LOSSEN_SATZ:ZAHL_ZAHL_NETTOBETRAG:RE_FK_STEUERSATZ:PK_INVENTAR:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:RESTBUCHWERT:PREIS_NETTO:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:FK_INVENTARTYP:KFZ_KENNZEICHEN:FAHRGESTELLNR'
,p_break_on=>'Kontotyp'
,p_break_enabled_on=>'Kontotyp'
);
wwv_flow_api.component_end;
end;
/
