prompt --application/pages/page_00399
begin
--   Manifest
--     PAGE: 00399
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>399
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Niederschlagsmenge'
,p_step_title=>'Niederschlagsmenge'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42861723561245961)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200609164024'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39700000451078303)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_wet_NIEDERSCHLAGSMENGE,',
'       ndlm.JAHR,',
'       ndlm.DATUM,',
'       FK_bas_kal_DATUM,',
'       NIEDERSCHLAGSMENGE,',
'       EINHEIT,',
'       ndlm.COMM,',
'       ndlm.CREATED_AT,',
'       FK_loc_LOCATION,',
'       FLG_kal_AUFSTELLTAG,',
'       arb.datum arb_datum,',
'       arb.tag arb_tag,',
'       arb.monat arb_monat,',
'       arb.jahr arb_jahr, ',
'       ndlm.flg_kal_abbautag,',
'       loc.pk_loc_location,',
'       loc.location',
'  from T_wet_NIEDERSCHLAGSMENGE ndlm',
'    left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = ndlm.fk_bas_kal_datum',
'    left join v_loc_location loc on loc.pk_loc_location = ndlm.fk_loc_location'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39700401831078303)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:RP:P400_PK_WET_NIEDERSCHLAGSMENGE:#PK_WET_NIEDERSCHLAGSMENGE##PK_NIEDERSCHLAGSMENGE#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>41140721106469843
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39700916149078311)
,p_db_column_name=>'JAHR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39701308019078311)
,p_db_column_name=>'DATUM'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39702108264078311)
,p_db_column_name=>'NIEDERSCHLAGSMENGE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Niederschlagsmenge'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39702488325078311)
,p_db_column_name=>'EINHEIT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Einheit'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39702904857078311)
,p_db_column_name=>'COMM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(39625678000207989)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41802872018224807)
,p_db_column_name=>'ARB_DATUM'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Arb Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41802965301224808)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41803041425224809)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41803096765224810)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(44681022825596774)
,p_db_column_name=>'PK_WET_NIEDERSCHLAGSMENGE'
,p_display_order=>89
,p_column_identifier=>'Q'
,p_column_label=>'Pk Wet Niederschlagsmenge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45895640616268782)
,p_db_column_name=>'FK_BAS_KAL_DATUM'
,p_display_order=>99
,p_column_identifier=>'T'
,p_column_label=>'Fk Bas Kal Datum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45895702137268783)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>109
,p_column_identifier=>'U'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45895803293268784)
,p_db_column_name=>'FLG_KAL_AUFSTELLTAG'
,p_display_order=>119
,p_column_identifier=>'V'
,p_column_label=>'Flg Kal Aufstelltag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45895922046268785)
,p_db_column_name=>'FLG_KAL_ABBAUTAG'
,p_display_order=>129
,p_column_identifier=>'W'
,p_column_label=>'Flg Kal Abbautag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45895981652268786)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>139
,p_column_identifier=>'X'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(45896100621268787)
,p_db_column_name=>'LOCATION'
,p_display_order=>149
,p_column_identifier=>'Y'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39710789601139219)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'411512'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'JAHR:LOCATION:ARB_DATUM:NIEDERSCHLAGSMENGE:EINHEIT:COMM:CREATED_AT:ARB_TAG:ARB_MONAT:ARB_JAHR:DATUM:PK_WET_NIEDERSCHLAGSMENGE:FK_BAS_KAL_DATUM:FLG_KAL_ABBAUTAG:PK_LOC_LOCATION:FK_LOC_LOCATION:FLG_KAL_AUFSTELLTAG:'
,p_sort_column_1=>'ARB_JAHR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ARB_MONAT'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'ARB_TAG'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR:0:0:0:0:LOCATION'
,p_break_enabled_on=>'0:0:0:0:JAHR:LOCATION'
,p_sum_columns_on_break=>'NIEDERSCHLAGSMENGE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(45976644975063441)
,p_report_id=>wwv_flow_api.id(39710789601139219)
,p_name=>'end'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KAL_ABBAUTAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FLG_KAL_ABBAUTAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(45977023988063441)
,p_report_id=>wwv_flow_api.id(39710789601139219)
,p_name=>'start'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KAL_AUFSTELLTAG'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FLG_KAL_AUFSTELLTAG" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(45976271905063439)
,p_report_id=>wwv_flow_api.id(39710789601139219)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2020'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39704939629078314)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(39700000451078303)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:400'
);
wwv_flow_api.component_end;
end;
/
