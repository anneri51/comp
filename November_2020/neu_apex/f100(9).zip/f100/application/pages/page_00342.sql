prompt --application/pages/page_00342
begin
--   Manifest
--     PAGE: 00342
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>342
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Verpflegungsaufwand_Detail_short'
,p_step_title=>'Verpflegungsaufwand_Detail_test'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090458'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12146766805878910)
,p_plug_name=>'Verpflegungsmehraufwand_Bel_pos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select belsrc.*, inp.bezeichnung, inp.bel_datum, ort, kat."Kategorie", inp_pos.Brutto_betrag , kat_pos."Kategorie" pos_Kategorie, kat_pos.pk_konto_buch_kat kat_pos_pk_konto_buch_kat',
'from t_rel_verpfl_beleg_src belsrc',
' left join inp_belege_all inp on belsrc.fk_inp_belege_all = inp.pk_inp_belege_all',
' left join inp_belege_pos_all inp_pos on belsrc.fk_inp_belege_all = inp_pos.fk_inp_belege_all',
' left join t_ort ort on ort.pk_ort = inp.fk_city',
' left join t_konto_buch_kat kat on kat.pk_konto_buch_kat = inp.fk_kategorie',
' left join t_konto_buch_kat kat_pos on kat_pos.pk_konto_buch_kat = inp_pos.fk_kategorie',
'where fk_verpflegungsmehraufwd_det = :P342_pk_verpflegungsmehraufwd_det or :P342_pk_verpflegungsmehraufwd_det is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12581975011596061)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>14022294286987601
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12581988662596062)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_SRC'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582103313596063)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582228198596064)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582349824596065)
,p_db_column_name=>'FK_STUNDENZETTEL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Stundenzettel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582403677596066)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582516291596067)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582614557596068)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582719739596069)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582854421596070)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12582893124596071)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12583051967596072)
,p_db_column_name=>'Kategorie'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12583218881596074)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12583335141596075)
,p_db_column_name=>'POS_KATEGORIE'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Pos Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12583471103596076)
,p_db_column_name=>'KAT_POS_PK_KONTO_BUCH_KAT'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Kat Pos Pk Konto Buch Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12591981919636356)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'140324'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_VERPFL_BELEG_SRC:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_INP_BELEGE_ALL:FK_STUNDENZETTEL:COMM:FK_STATUS:CREATION_DATE:BEZEICHNUNG:BEL_DATUM:ORT:Kategorie:BRUTTO_BETRAG:POS_KATEGORIE:KAT_POS_PK_KONTO_BUCH_KAT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12611537930761388)
,p_report_id=>wwv_flow_api.id(12591981919636356)
,p_name=>unistr('fr\00FChst\00FCck')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KAT_POS_PK_KONTO_BUCH_KAT'
,p_operator=>'='
,p_expr=>'314'
,p_condition_sql=>' (case when ("KAT_POS_PK_KONTO_BUCH_KAT" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(25781077733568800)
,p_plug_name=>'Verpflegungsmehraufwand_Detail'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_VERPFLEGUNGSMEHRAUFWAND_DET'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26044659151342638)
,p_plug_name=>'Ort'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_VERPFL_BELEG_ORT,',
'       FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'       FK_ORT,',
'       FK_AUSWAERTS,',
'       CREATION_DATE,',
'       ort,',
'       land',
'  from T_REL_VERPFL_BELEG_ORT bel',
'    left join t_ort ort on ort.pk_ort = bel.fk_ort',
'    left join t_land la on la.pk_land = ort.fk_land',
' where fk_verpflegungsmehraufwd_det = :P342_pK_VERPFLEGUNGSMEHRAUFWD_DET'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26044900147342640)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.:RP:P330_PK_REL_VERPFL_BELEG_SRC,P330_FK_AREITSTAG:#PK_REL_VERPFL_BELEG_SRC#,&P320_FK_DATUM_VERPFMWED.#PK_VERPFLEGUNGSMEHRAUFWAND#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>27485219422734180
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12550191258383203)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12550609477383213)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12551450521383214)
,p_db_column_name=>'FK_ORT'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>'Fk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12551793650383214)
,p_db_column_name=>'FK_AUSWAERTS'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Fk Auswaerts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12552252034383216)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12552626059383216)
,p_db_column_name=>'LAND'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12603241363709585)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_ORT'
,p_display_order=>120
,p_column_identifier=>'H'
,p_column_label=>'Pk Rel Verpfl Beleg Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26140989104678200)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'139933'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CREATION_DATE:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_ORT:FK_AUSWAERTS:ORT:LAND:PK_REL_VERPFL_BELEG_ORT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12574654996475403)
,p_report_id=>wwv_flow_api.id(26140989104678200)
,p_name=>unistr('ausw\00E4rts')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_AUSWAERTS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_AUSWAERTS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26148092363679698)
,p_plug_name=>'Verpflegungsmehraufwand_Bel'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select belort.*, ort',
'from t_rel_verpfl_beleg_ort belort',
'',
' left join t_ort ort on ort.pk_ort = belort.fk_ort',
'where fk_verpflegungsmehraufwd_det = :P342_pk_verpflegungsmehraufwd_det or :P342_pk_verpflegungsmehraufwd_det is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26148171946679699)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>27588491222071239
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12563909540409275)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12564334026409288)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12564760282409288)
,p_db_column_name=>'ORT'
,p_display_order=>100
,p_column_identifier=>'C'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12565536324409289)
,p_db_column_name=>'FK_ORT'
,p_display_order=>120
,p_column_identifier=>'E'
,p_column_label=>'Fk Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12565948873409291)
,p_db_column_name=>'FK_AUSWAERTS'
,p_display_order=>130
,p_column_identifier=>'F'
,p_column_label=>'Fk Auswaerts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12603173055709584)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_ORT'
,p_display_order=>140
,p_column_identifier=>'G'
,p_column_label=>'Pk Rel Verpfl Beleg Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26462936782836519)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'140066'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_VERPFLEGUNGSMEHRAUFWD_DET:CREATION_DATE:ORT:FK_ORT:FK_AUSWAERTS:PK_REL_VERPFL_BELEG_ORT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26457021179788176)
,p_plug_name=>'Verpflegungsmehraufwand_Bel'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select belsrc.*, inp.bezeichnung, inp.bel_datum, ort, "Kategorie", case when "FK_Oberkategorie" = 694 then 1 else 0 end bel_hotel',
'from t_rel_verpfl_beleg_src belsrc',
' left join inp_belege_all inp on belsrc.fk_inp_belege_all = inp.pk_inp_belege_all',
' left join t_ort ort on ort.pk_ort = inp.fk_city',
' left join t_konto_buch_kat kat on kat.pk_konto_buch_kat = inp.fk_kategorie',
'where fk_verpflegungsmehraufwd_det = :P342_pk_verpflegungsmehraufwd_det or :P342_pk_verpflegungsmehraufwd_det is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26457153208788176)
,p_name=>'Verpflegungsmehraufwand_Bel'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>27897472484179716
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12567005310410600)
,p_db_column_name=>'PK_REL_VERPFL_BELEG_SRC'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Verpfl Beleg Src'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12567441846410602)
,p_db_column_name=>'FK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Verpflegungsmehraufwd Det'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12567786257410602)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12568274326410602)
,p_db_column_name=>'FK_STUNDENZETTEL'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Stundenzettel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12568680365410603)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12569008378410603)
,p_db_column_name=>'FK_STATUS'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12569432821410603)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12569805573410603)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12570183668410605)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12570618648410605)
,p_db_column_name=>'ORT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12146562760878908)
,p_db_column_name=>'Kategorie'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12146614522878909)
,p_db_column_name=>'BEL_HOTEL'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Bel Hotel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26465427322837817)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'140113'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_VERPFL_BELEG_SRC:FK_VERPFLEGUNGSMEHRAUFWD_DET:FK_INP_BELEGE_ALL:FK_STUNDENZETTEL:ORT:COMM:FK_STATUS:CREATION_DATE:BEZEICHNUNG:BEL_DATUM::Kategorie:BEL_HOTEL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12581498707591674)
,p_report_id=>wwv_flow_api.id(26465427322837817)
,p_name=>'Hotel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BEL_HOTEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BEL_HOTEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39754533638606980)
,p_plug_name=>'Verpflegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(12168562252523035)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(6256027176136034)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12553413977383225)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(26044659151342638)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:340:&SESSION.::&DEBUG.:330:P340_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P342_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12477901192102369)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(25781077733568800)
,p_button_name=>unistr('\00DCbersicht')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>unistr('\00DCbersicht')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:339:&SESSION.::&DEBUG.:RP:P339_FK_VERPFLEGUNGSMEHRAUFWD_DET:&P342_PK_VERPFLEGUNGSMEHRAUFWD_DET.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12477113614102369)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(25781077733568800)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P342_PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12476312420102367)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(25781077733568800)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:328:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12477567445102369)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(25781077733568800)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P342_PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12476764103102367)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(25781077733568800)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P342_PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(12498584550102427)
,p_branch_name=>'Go To Page 328'
,p_branch_action=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.::P327_PK_VERPFLEGUNGSMEHRAUFWAND:&P342_FK_VERPFLEGUNGSMEHRAUFWAND.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12478313442102369)
,p_name=>'P342_PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'New'
,p_source=>'PK_VERPFLEGUNGSMEHRAUFWD_DET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12478759728102377)
,p_name=>'P342_FK_VERPFLEGUNGSMEHRAUFWAND'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Verpflegungsmehraufwand'
,p_source=>'FK_VERPFLEGUNGSMEHRAUFWAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_jahr || '' '' || fk_monat, pk_verpflegungsmehraufwand',
'from t_verpflegungsmehraufwand'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12479098032102378)
,p_name=>'P342_DATUM_VERPFMWED'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Datum Verpfmwed'
,p_source=>'DATUM_VERPFMWED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12479487982102378)
,p_name=>'P342_FK_DATUM_VERPFMWED'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Datum Verpfmwed'
,p_source=>'FK_DATUM_VERPFMWED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12479931008102380)
,p_name=>'P342_DESCR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Descr'
,p_source=>'DESCR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12480298025102380)
,p_name=>'P342_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>4615419005198635
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12481098713102380)
,p_name=>unistr('P342_FK_FR\00DCHSTUECK')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>unistr('Fk Fr\00FChstueck')
,p_source=>unistr('FK_FR\00DCHSTUECK')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12481532238102381)
,p_name=>'P342_FK_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Verpflegungspauschale Voll'
,p_source=>'FK_VERPFLEGUNGSPAUSCHALE_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name || '' ('' || std_value || '')'' d, std_value r',
'from t_std ',
'where fk_std_group = 242 and mark in (0,1)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12481976755102381)
,p_name=>'P342_FK_STATUS_VP_VOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Status Vp Voll'
,p_source=>'FK_STATUS_VP_VOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name d, std_value r',
'from t_std ',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12534736633213302)
,p_name=>'P342_FK_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Verpflegungspauschale Teil'
,p_source=>'FK_VERPFLEGUNGSPAUSCHALE_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name || '' ('' || std_value || '')'' d, std_value r',
'from t_std ',
'where fk_std_group = 242 and mark in (0,2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12535156250213303)
,p_name=>'P342_FK_STATUS_VP_TEIL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Status Vp Teil'
,p_source=>'FK_STATUS_VP_TEIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name d, std_value r',
'from t_std ',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12535509970213303)
,p_name=>unistr('P342_FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>unistr('Fk Verpflegunspauschale K\00FCrz')
,p_source=>unistr('FK_VERPFLEGUNSPAUSCHALE_K\00DCRZ')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name || '' ('' || std_value || '')'' d, std_value r',
'from t_std ',
'where fk_std_group = 242 and mark in (0,3)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12535898734213305)
,p_name=>unistr('P342_FK_STATUS_VP_K\00DCRZ')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>unistr('Fk Status Vp K\00FCrz')
,p_source=>unistr('FK_STATUS_VP_K\00DCRZ')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name d, std_value r',
'from t_std ',
'where fk_std_group = 241 '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12536349599213305)
,p_name=>unistr('P342_FK_\00DCBERNACHTUNGSPAUSCHALE')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>unistr('Fk \00DCbernachtungspauschale')
,p_source=>unistr('FK_\00DCBERNACHTUNGSPAUSCHALE')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name || '' ('' || std_value || '')'' d, std_value r',
'from t_std ',
'where fk_std_group = 242 and mark in (0,4)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12536730154213306)
,p_name=>unistr('P342_FK_STATUS_\00DCP')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>unistr('Fk Status \00DCp')
,p_source=>unistr('FK_STATUS_\00DCP')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name d, std_value r',
'from t_std ',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12537131479213308)
,p_name=>'P342_FK_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Fk Status'
,p_source=>'FK_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name d, std_value r',
'from t_std ',
'where fk_std_group = 241'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12537482614213308)
,p_name=>'P342_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12537918158213308)
,p_name=>'P342_MODIFY_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(25781077733568800)
,p_item_source_plug_id=>wwv_flow_api.id(25781077733568800)
,p_prompt=>'Modify Date'
,p_source=>'MODIFY_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12486683585102386)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(25781077733568800)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Verpflegungsmehraufwand_Detail'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12486314408102385)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(25781077733568800)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Verpflegungsmehraufwand_Detail'
);
wwv_flow_api.component_end;
end;
/
