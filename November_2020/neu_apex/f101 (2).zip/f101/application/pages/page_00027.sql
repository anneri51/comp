prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>27
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'T_db_app_pages_debug_messages'
,p_alias=>'T-DB-APP-PAGES-DEBUG-MESSAGES'
,p_step_title=>'T_db_app_pages_debug_messages'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201018140030'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28978861631717411)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29209350599281163)
,p_plug_name=>'T_db_app_pages_debug_messages'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APPLICATION,',
'       ATTRIBUTE,',
'       CHECK1,',
'       CATEGORY,',
'       MESSAGE,',
'       VALUE,',
'       PK_DB_APP_PAGES_DEBUG_MESSAGES,',
'       apex_item.checkbox2(1, pk_db_app_pages_debug_messages) sel,',
'       FK_STD_PAG_DEB_IMPORTANCE,',
'FK_STD_PAG_DEB_STATUS',
'  from T_DB_APP_PAGES_DEBUG_MESSAGES'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'T_db_app_pages_debug_messages'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29209474060281163)
,p_name=>'T_db_app_pages_debug_messages'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_PK_DB_APP_PAGES_DEBUG_MESSAGES:#PK_DB_APP_PAGES_DEBUG_MESSAGES#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>29209474060281163
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28977971749717402)
,p_db_column_name=>'APPLICATION'
,p_display_order=>10
,p_column_identifier=>'AD'
,p_column_label=>'Application'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978021360717403)
,p_db_column_name=>'ATTRIBUTE'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Attribute'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978120725717404)
,p_db_column_name=>'CHECK1'
,p_display_order=>30
,p_column_identifier=>'AF'
,p_column_label=>'Check1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978259774717405)
,p_db_column_name=>'CATEGORY'
,p_display_order=>40
,p_column_identifier=>'AG'
,p_column_label=>'Category'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978399227717406)
,p_db_column_name=>'MESSAGE'
,p_display_order=>50
,p_column_identifier=>'AH'
,p_column_label=>'Message'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978424111717407)
,p_db_column_name=>'VALUE'
,p_display_order=>60
,p_column_identifier=>'AI'
,p_column_label=>'Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978538311717408)
,p_db_column_name=>'PK_DB_APP_PAGES_DEBUG_MESSAGES'
,p_display_order=>70
,p_column_identifier=>'AJ'
,p_column_label=>'Pk Db App Pages Debug Messages'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978603545717409)
,p_db_column_name=>'SEL'
,p_display_order=>80
,p_column_identifier=>'AK'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28978793748717410)
,p_db_column_name=>'FK_STD_PAG_DEB_STATUS'
,p_display_order=>90
,p_column_identifier=>'AL'
,p_column_label=>'Fk Std Pag Deb Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(28979387769717416)
,p_db_column_name=>'FK_STD_PAG_DEB_IMPORTANCE'
,p_display_order=>100
,p_column_identifier=>'AM'
,p_column_label=>'Fk Std Pag Deb Importance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29221631709284017)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'292217'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:APPLICATION:ATTRIBUTE:CHECK1:CATEGORY:MESSAGE:VALUE:PK_DB_APP_PAGES_DEBUG_MESSAGES::FK_STD_PAG_DEB_STATUS:FK_STD_PAG_DEB_IMPORTANCE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(29256612697611087)
,p_report_id=>wwv_flow_api.id(29221631709284017)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APPLICATION'
,p_operator=>'='
,p_expr=>'Applications > 100 - Company_neu > Lists > Desktop Navigation Menu > Entries > 100 - Datenbankadministration'
,p_condition_sql=>'"APPLICATION" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Applications > 100 - Company_neu > Lists > Desktop Navigation Menu > Entries > 100 - Datenbankadministration''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(28979169444717414)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(28978861631717411)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Update'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28978915975717412)
,p_name=>'P27_FK_STD_PAG_DEB_IMPORTANCE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28978861631717411)
,p_prompt=>'Fk Std Pag Deb Importance'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Keine Angabe;0,wichtig;1,unwichtig;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28979048201717413)
,p_name=>'P27_FK_STD_PAG_DEB_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28978861631717411)
,p_prompt=>'Fk Std Pag Deb Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Keine Angabe;0,neu;1,in Bearbeitung;2,erledigt;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28979274088717415)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' for i in 1 .. apex_application.g_f01.count loop',
'',
'   if apex_application.g_f01(i) is not null then',
'',
'   update t_db_app_pages_debug_messages set fk_std_pag_deb_importance = :P27_fk_std_pag_deb_importance, FK_STD_PAG_DEB_STATUS = :P27_FK_STD_PAG_DEB_STATUS where pk_db_app_pages_debug_messages = apex_application.g_f01(i);',
'commit;',
'  end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
