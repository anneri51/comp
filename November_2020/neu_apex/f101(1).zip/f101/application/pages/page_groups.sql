prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>2201717242293144
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632727252605008)
,p_group_name=>'1  - 1  DB Work - Database Objects'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632876297608890)
,p_group_name=>'1 - 2 DB Work - Renaming'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632998848613415)
,p_group_name=>'2 - 1 Applicaiton  Work - Navigation'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16633122521615623)
,p_group_name=>'2 - 2 - Application Work - Region Work'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16633221392616695)
,p_group_name=>'3  - Standard'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(47577226753610168)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(48250276776250054)
,p_group_name=>'Global'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(48249829392243539)
,p_group_name=>'Sequence'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(48249782252242664)
,p_group_name=>'Text replacement'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(48249949362247585)
,p_group_name=>'Umbenennung'
);
wwv_flow_api.component_end;
end;
/
