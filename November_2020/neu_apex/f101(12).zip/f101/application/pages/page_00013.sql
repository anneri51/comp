prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'interactive Report'
,p_alias=>'INTERACTIVE_REPORT_13'
,p_step_title=>'interactive Report'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16633122521615623)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201013103823'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7346885205537473)
,p_plug_name=>'Step 2'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7059309376925217)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7342898512537471)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7088215084925228)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7346976327537473)
,p_plug_name=>'Step 2'
,p_parent_plug_id=>wwv_flow_api.id(7346885205537473)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7021577436925200)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(48514731719700423)
,p_plug_name=>'interactive Report'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from  APEX_APPLICATION_PAGE_IR_COL ',
'',
'where (application_id = :P13_application_id or :P13_application_id is null)',
'and',
'(page_id = :P13_page_id or :P13_page_id is null)',
'and',
'(interactive_report_id = :P13_interactive_report_id or :P13_ineractive_report_id is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(48514853687700424)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>48514853687700424
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48514950196700425)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51789020222204202)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>280
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51791726058204229)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>550
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51792959976204241)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>670
,p_column_identifier=>'D'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793035267204242)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>680
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793141340204243)
,p_db_column_name=>'UPDATED_ON'
,p_display_order=>690
,p_column_identifier=>'F'
,p_column_label=>'Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793208622204244)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>700
,p_column_identifier=>'G'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793397240204245)
,p_db_column_name=>'COMPONENT_SIGNATURE'
,p_display_order=>710
,p_column_identifier=>'H'
,p_column_label=>'Component Signature'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793447331204246)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>720
,p_column_identifier=>'I'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793593423204247)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>730
,p_column_identifier=>'J'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793669538204248)
,p_db_column_name=>'INTERACTIVE_REPORT_ID'
,p_display_order=>740
,p_column_identifier=>'K'
,p_column_label=>'Interactive Report Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793791410204249)
,p_db_column_name=>'REGION_ID'
,p_display_order=>750
,p_column_identifier=>'L'
,p_column_label=>'Region Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51793894750204250)
,p_db_column_name=>'REGION_NAME'
,p_display_order=>760
,p_column_identifier=>'M'
,p_column_label=>'Region Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51795702188204219)
,p_db_column_name=>'COLUMN_ID'
,p_display_order=>770
,p_column_identifier=>'N'
,p_column_label=>'Column Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51795862947204220)
,p_db_column_name=>'COLUMN_ALIAS'
,p_display_order=>780
,p_column_identifier=>'O'
,p_column_label=>'Column Alias'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51795961274204221)
,p_db_column_name=>'DISPLAY_ORDER'
,p_display_order=>790
,p_column_identifier=>'P'
,p_column_label=>'Display Order'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796069122204222)
,p_db_column_name=>'COLUMN_GROUP'
,p_display_order=>800
,p_column_identifier=>'Q'
,p_column_label=>'Column Group'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796185233204223)
,p_db_column_name=>'COLUMN_GROUP_ID'
,p_display_order=>810
,p_column_identifier=>'R'
,p_column_label=>'Column Group Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796256279204224)
,p_db_column_name=>'COLUMN_IDENTIFIER'
,p_display_order=>820
,p_column_identifier=>'S'
,p_column_label=>'Column Identifier'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796300223204225)
,p_db_column_name=>'REPORT_LABEL'
,p_display_order=>830
,p_column_identifier=>'T'
,p_column_label=>'Report Label'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796495082204226)
,p_db_column_name=>'FORM_LABEL'
,p_display_order=>840
,p_column_identifier=>'U'
,p_column_label=>'Form Label'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796547732204227)
,p_db_column_name=>'HTML_EXPRESSION'
,p_display_order=>850
,p_column_identifier=>'V'
,p_column_label=>'Html Expression'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796651055204228)
,p_db_column_name=>'COLUMN_LINK'
,p_display_order=>860
,p_column_identifier=>'W'
,p_column_label=>'Column Link'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796767401204229)
,p_db_column_name=>'COLUMN_LINKTEXT'
,p_display_order=>870
,p_column_identifier=>'X'
,p_column_label=>'Column Linktext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796846162204230)
,p_db_column_name=>'COLUMN_LINK_ATTR'
,p_display_order=>880
,p_column_identifier=>'Y'
,p_column_label=>'Column Link Attr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51796929013204231)
,p_db_column_name=>'COLUMN_LINK_CHECKSUM_TYPE'
,p_display_order=>890
,p_column_identifier=>'Z'
,p_column_label=>'Column Link Checksum Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797088274204232)
,p_db_column_name=>'ALLOW_SORTING'
,p_display_order=>900
,p_column_identifier=>'AA'
,p_column_label=>'Allow Sorting'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797172107204233)
,p_db_column_name=>'ALLOW_FILTERING'
,p_display_order=>910
,p_column_identifier=>'AB'
,p_column_label=>'Allow Filtering'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797252673204234)
,p_db_column_name=>'ALLOW_HIGHLIGHTING'
,p_display_order=>920
,p_column_identifier=>'AC'
,p_column_label=>'Allow Highlighting'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797335641204235)
,p_db_column_name=>'ALLOW_CTRL_BREAKS'
,p_display_order=>930
,p_column_identifier=>'AD'
,p_column_label=>'Allow Ctrl Breaks'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797457655204236)
,p_db_column_name=>'ALLOW_AGGREGATIONS'
,p_display_order=>940
,p_column_identifier=>'AE'
,p_column_label=>'Allow Aggregations'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797577572204237)
,p_db_column_name=>'ALLOW_COMPUTATIONS'
,p_display_order=>950
,p_column_identifier=>'AF'
,p_column_label=>'Allow Computations'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797691827204238)
,p_db_column_name=>'ALLOW_CHARTING'
,p_display_order=>960
,p_column_identifier=>'AG'
,p_column_label=>'Allow Charting'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797742128204239)
,p_db_column_name=>'ALLOW_GROUP_BY'
,p_display_order=>970
,p_column_identifier=>'AH'
,p_column_label=>'Allow Group By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797880790204240)
,p_db_column_name=>'ALLOW_PIVOT'
,p_display_order=>980
,p_column_identifier=>'AI'
,p_column_label=>'Allow Pivot'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51797956269204241)
,p_db_column_name=>'ALLOW_HIDE'
,p_display_order=>990
,p_column_identifier=>'AJ'
,p_column_label=>'Allow Hide'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798022200204242)
,p_db_column_name=>'COLUMN_TYPE'
,p_display_order=>1000
,p_column_identifier=>'AK'
,p_column_label=>'Column Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798125873204243)
,p_db_column_name=>'DISPLAY_TEXT_AS'
,p_display_order=>1010
,p_column_identifier=>'AL'
,p_column_label=>'Display Text As'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798224751204244)
,p_db_column_name=>'HEADING_ALIGNMENT'
,p_display_order=>1020
,p_column_identifier=>'AM'
,p_column_label=>'Heading Alignment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798361768204245)
,p_db_column_name=>'COLUMN_ALIGNMENT'
,p_display_order=>1030
,p_column_identifier=>'AN'
,p_column_label=>'Column Alignment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798426499204246)
,p_db_column_name=>'FORMAT_MASK'
,p_display_order=>1040
,p_column_identifier=>'AO'
,p_column_label=>'Format Mask'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798503522204247)
,p_db_column_name=>'TZ_DEPENDENT'
,p_display_order=>1050
,p_column_identifier=>'AP'
,p_column_label=>'Tz Dependent'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798644412204248)
,p_db_column_name=>'STATIC_ID'
,p_display_order=>1060
,p_column_identifier=>'AQ'
,p_column_label=>'Static Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798751020204249)
,p_db_column_name=>'CSS_CLASSES'
,p_display_order=>1070
,p_column_identifier=>'AR'
,p_column_label=>'Css Classes'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798864267204250)
,p_db_column_name=>'FILTER_LOV_SOURCE'
,p_display_order=>1080
,p_column_identifier=>'AS'
,p_column_label=>'Filter Lov Source'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51798980186206001)
,p_db_column_name=>'NAMED_LOV'
,p_display_order=>1090
,p_column_identifier=>'AT'
,p_column_label=>'Named Lov'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799025464206002)
,p_db_column_name=>'RPT_LOV'
,p_display_order=>1100
,p_column_identifier=>'AU'
,p_column_label=>'Rpt Lov'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799104499206003)
,p_db_column_name=>'FILTER_DATE_RANGES'
,p_display_order=>1110
,p_column_identifier=>'AV'
,p_column_label=>'Filter Date Ranges'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799278177206004)
,p_db_column_name=>'DISPLAY_CONDITION_TYPE'
,p_display_order=>1120
,p_column_identifier=>'AW'
,p_column_label=>'Display Condition Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799325760206005)
,p_db_column_name=>'DISPLAY_CONDITION_TYPE_CODE'
,p_display_order=>1130
,p_column_identifier=>'AX'
,p_column_label=>'Display Condition Type Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799451995206006)
,p_db_column_name=>'DISPLAY_CONDITION'
,p_display_order=>1140
,p_column_identifier=>'AY'
,p_column_label=>'Display Condition'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799595238206007)
,p_db_column_name=>'DISPLAY_CONDITION2'
,p_display_order=>1150
,p_column_identifier=>'AZ'
,p_column_label=>'Display Condition2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799642999206008)
,p_db_column_name=>'HELP_TEXT'
,p_display_order=>1160
,p_column_identifier=>'BA'
,p_column_label=>'Help Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799720936206009)
,p_db_column_name=>'AUTHORIZATION_SCHEME'
,p_display_order=>1170
,p_column_identifier=>'BB'
,p_column_label=>'Authorization Scheme'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799858747206010)
,p_db_column_name=>'AUTHORIZATION_SCHEME_ID'
,p_display_order=>1180
,p_column_identifier=>'BC'
,p_column_label=>'Authorization Scheme Id'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51799901696206011)
,p_db_column_name=>'COLUMN_EXPR'
,p_display_order=>1190
,p_column_identifier=>'BD'
,p_column_label=>'Column Expr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51800072770206012)
,p_db_column_name=>'BUILD_OPTION'
,p_display_order=>1200
,p_column_identifier=>'BE'
,p_column_label=>'Build Option'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51800133211206013)
,p_db_column_name=>'BUILD_OPTION_ID'
,p_display_order=>1210
,p_column_identifier=>'BF'
,p_column_label=>'Build Option Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51800289270206014)
,p_db_column_name=>'COMPONENT_COMMENT'
,p_display_order=>1220
,p_column_identifier=>'BG'
,p_column_label=>'Component Comment'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(51822555780207026)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'518226'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COLUMN_LINK:WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:CREATED_ON:CREATED_BY:UPDATED_ON:UPDATED_BY:COMPONENT_SIGNATURE:APPLICATION_NAME:PAGE_ID:INTERACTIVE_REPORT_ID:REGION_ID:REGION_NAME:COLUMN_ID:COLUMN_ALIAS:DISPLAY_ORDER:COLUMN_GROUP:COLUMN_'
||'GROUP_ID:COLUMN_IDENTIFIER:REPORT_LABEL:FORM_LABEL:HTML_EXPRESSION:COLUMN_LINKTEXT:COLUMN_LINK_ATTR:COLUMN_LINK_CHECKSUM_TYPE:ALLOW_SORTING:ALLOW_FILTERING:ALLOW_HIGHLIGHTING:ALLOW_CTRL_BREAKS:ALLOW_AGGREGATIONS:ALLOW_COMPUTATIONS:ALLOW_CHARTING:ALLO'
||'W_GROUP_BY:ALLOW_PIVOT:ALLOW_HIDE:COLUMN_TYPE:DISPLAY_TEXT_AS:HEADING_ALIGNMENT:COLUMN_ALIGNMENT:FORMAT_MASK:TZ_DEPENDENT:STATIC_ID:CSS_CLASSES:FILTER_LOV_SOURCE:NAMED_LOV:RPT_LOV:FILTER_DATE_RANGES:DISPLAY_CONDITION_TYPE:DISPLAY_CONDITION_TYPE_CODE:'
||'DISPLAY_CONDITION:DISPLAY_CONDITION2:HELP_TEXT:AUTHORIZATION_SCHEME:AUTHORIZATION_SCHEME_ID:COLUMN_EXPR:BUILD_OPTION:BUILD_OPTION_ID:COMPONENT_COMMENT:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(51750702502200912)
,p_plug_name=>'interactive Report'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select substr(ir.detail_link_target, instr(ir.detail_link_target,''APP_ID'')+8,instr(ir.detail_link_target,'':'',instr(ir.detail_link_target,''APP_ID'')+8 )-instr(ir.detail_link_target,''APP_ID'')-8) link_to_page, ir.* ',
'from  APEX_APPLICATION_PAGE_IR ir',
'where (application_id = :P13_application_id or :P13_application_id is null)',
'and',
'(page_id = :P13_page_id or :P13_page_id is null)',
'and',
'(interactive_report_id = :P13_interactive_report_id or :P13_ineractive_report_id is null)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(51750827064200912)
,p_name=>'interactive Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>51750827064200912
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51751273989200928)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51751647349200945)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51752093345200945)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51752434622200945)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51752879685200946)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51753249272200946)
,p_db_column_name=>'INTERACTIVE_REPORT_ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Interactive Report Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51753651167200946)
,p_db_column_name=>'REGION_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Region Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51754098814200948)
,p_db_column_name=>'REGION_NAME'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Region Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51754497053200948)
,p_db_column_name=>'NUMBER_OF_COLUMNS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Number Of Columns'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51754800689200948)
,p_db_column_name=>'NUMBER_OF_COLUMN_GROUPS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Number Of Column Groups'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51755255212200950)
,p_db_column_name=>'NUMBER_OF_ALT_DEFAULT_REPORTS'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Number Of Alt Default Reports'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51755605742200950)
,p_db_column_name=>'NUMBER_OF_PUBLIC_REPORTS'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Number Of Public Reports'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51756012043200950)
,p_db_column_name=>'NUMBER_OF_PRIVATE_REPORTS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Number Of Private Reports'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51756433308200951)
,p_db_column_name=>'MAX_ROW_COUNT'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Max Row Count'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51756868337200951)
,p_db_column_name=>'MAX_ROW_COUNT_MESSAGE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Max Row Count Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51757283425200951)
,p_db_column_name=>'NO_DATA_FOUND_MESSAGE'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'No Data Found Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51757680636200953)
,p_db_column_name=>'MAX_ROWS_PER_PAGE'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Max Rows Per Page'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51758061741200953)
,p_db_column_name=>'SEARCH_BUTTON_LABEL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Search Button Label'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51758442352200953)
,p_db_column_name=>'PAGE_ITEMS_TO_SUBMIT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Page Items To Submit'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51758861368200954)
,p_db_column_name=>'BASE_TABLE_OR_VIEW'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Base Table Or View'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51759644299200954)
,p_db_column_name=>'SHOW_NULLS_AS'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Show Nulls As'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51760080115200956)
,p_db_column_name=>'PAGINATION_SCHEME'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Pagination Scheme'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51760409889200956)
,p_db_column_name=>'PAGINATION_DISPLAY_POSITION'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Pagination Display Position'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51760887193200956)
,p_db_column_name=>'BUTTON_TEMPLATE'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Button Template'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51761215318200957)
,p_db_column_name=>'SHOW_FINDER_DROP_DOWN'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Show Finder Drop Down'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51761639511200957)
,p_db_column_name=>'SHOW_REPORTS_SELECT_LIST'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Show Reports Select List'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51762096054200957)
,p_db_column_name=>'SHOW_DISPLAY_ROW_COUNT'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Show Display Row Count'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51762497362200959)
,p_db_column_name=>'SHOW_SEARCH_BAR'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Show Search Bar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51762866657200959)
,p_db_column_name=>'SHOW_SEARCH_TEXTBOX'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Show Search Textbox'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51763252132200959)
,p_db_column_name=>'SHOW_ACTIONS_MENU'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Show Actions Menu'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51763601175200960)
,p_db_column_name=>'ACTIONS_MENU_ICON'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Actions Menu Icon'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51764037139200960)
,p_db_column_name=>'FINDER_ICON'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Finder Icon'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51764409972200960)
,p_db_column_name=>'SHOW_SELECT_COLUMNS'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Show Select Columns'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51764810463200962)
,p_db_column_name=>'SHOW_ROWS_PER_PAGE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Show Rows Per Page'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51765224500200962)
,p_db_column_name=>'SHOW_FILTER'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Show Filter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51765699938200962)
,p_db_column_name=>'SHOW_SORT'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Show Sort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51766090944200964)
,p_db_column_name=>'SHOW_CONTROL_BREAK'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Show Control Break'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51766416409200964)
,p_db_column_name=>'SHOW_HIGHLIGHT'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Show Highlight'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51766842033200964)
,p_db_column_name=>'SHOW_COMPUTE'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Show Compute'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51767236317200965)
,p_db_column_name=>'SHOW_AGGREGATE'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Show Aggregate'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51767642579200965)
,p_db_column_name=>'SHOW_CHART'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Show Chart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51768040114200965)
,p_db_column_name=>'SHOW_GROUP_BY'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Show Group By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51768428174200967)
,p_db_column_name=>'SHOW_PIVOT'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Show Pivot'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51768860284200967)
,p_db_column_name=>'SHOW_NOTIFY'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Show Notify'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51769284267200967)
,p_db_column_name=>'SHOW_FLASHBACK'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Show Flashback'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51769608071200968)
,p_db_column_name=>'SHOW_SAVE'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Show Save'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51770003370200968)
,p_db_column_name=>'SHOW_SAVE_PUBLIC'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Show Save Public'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51770467442200968)
,p_db_column_name=>'SAVE_PUBLIC_AUTH_SCHEME'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Save Public Auth Scheme'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51770888784200970)
,p_db_column_name=>'SAVE_PUBLIC_AUTH_SCHEME_ID'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Save Public Auth Scheme Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51771248970200970)
,p_db_column_name=>'SHOW_RESET'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Show Reset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51771655385200970)
,p_db_column_name=>'SHOW_DOWNLOAD'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Show Download'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51772009412200971)
,p_db_column_name=>'SHOW_HELP'
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>'Show Help'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51772422759200971)
,p_db_column_name=>'DOWNLOAD_FORMATS'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Download Formats'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51772821373200971)
,p_db_column_name=>'FILENAME'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51773221439200973)
,p_db_column_name=>'SEPARATOR'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Separator'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51773623110200973)
,p_db_column_name=>'ENCLOSED_BY'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Enclosed By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51774059564200975)
,p_db_column_name=>'DETAIL_LINK_TYPE'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Detail Link Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51774497733200975)
,p_db_column_name=>'DETAIL_LINK_TARGET'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Detail Link Target'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51774803666200975)
,p_db_column_name=>'DETAIL_LINK_TEXT'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Detail Link Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51775244837200976)
,p_db_column_name=>'DETAIL_LINK_ATTRIBUTES'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Detail Link Attributes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51775698457200976)
,p_db_column_name=>'DETAIL_LINK_CHECKSUM_TYPE'
,p_display_order=>62
,p_column_identifier=>'BJ'
,p_column_label=>'Detail Link Checksum Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51776085806200978)
,p_db_column_name=>'DETAIL_LINK_CONDITION_TYPE'
,p_display_order=>63
,p_column_identifier=>'BK'
,p_column_label=>'Detail Link Condition Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51776443449200978)
,p_db_column_name=>'DETAIL_LINK_COND_TYPE_CODE'
,p_display_order=>64
,p_column_identifier=>'BL'
,p_column_label=>'Detail Link Cond Type Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51776805219200979)
,p_db_column_name=>'DETAIL_LINK_COND_EXPRESSION'
,p_display_order=>65
,p_column_identifier=>'BM'
,p_column_label=>'Detail Link Cond Expression'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51777247866200981)
,p_db_column_name=>'DETAIL_LINK_COND_EXPRESSION2'
,p_display_order=>66
,p_column_identifier=>'BN'
,p_column_label=>'Detail Link Cond Expression2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51777631538200981)
,p_db_column_name=>'DETAIL_LINK_AUTH_SCHEME'
,p_display_order=>67
,p_column_identifier=>'BO'
,p_column_label=>'Detail Link Auth Scheme'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51778010543200982)
,p_db_column_name=>'DETAIL_LINK_AUTH_SCHEME_ID'
,p_display_order=>68
,p_column_identifier=>'BP'
,p_column_label=>'Detail Link Auth Scheme Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51778464990200984)
,p_db_column_name=>'ALIAS'
,p_display_order=>69
,p_column_identifier=>'BQ'
,p_column_label=>'Alias'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51778823314200984)
,p_db_column_name=>'REPORT_ID_ITEM'
,p_display_order=>70
,p_column_identifier=>'BR'
,p_column_label=>'Report Id Item'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51779270748200984)
,p_db_column_name=>'MAX_QUERY_COST'
,p_display_order=>71
,p_column_identifier=>'BS'
,p_column_label=>'Max Query Cost'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51779675124200985)
,p_db_column_name=>'EMAIL_FROM'
,p_display_order=>72
,p_column_identifier=>'BT'
,p_column_label=>'Email From'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51780081917200985)
,p_db_column_name=>'FIXED_HEADER'
,p_display_order=>73
,p_column_identifier=>'BU'
,p_column_label=>'Fixed Header'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51780445083200987)
,p_db_column_name=>'FIXED_HEADER_MAX_HEIGHT'
,p_display_order=>74
,p_column_identifier=>'BV'
,p_column_label=>'Fixed Header Max Height'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51780855391200989)
,p_db_column_name=>'ICON_VIEW_ENABLED_YN'
,p_display_order=>75
,p_column_identifier=>'BW'
,p_column_label=>'Icon View Enabled Yn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51781200210200989)
,p_db_column_name=>'ICON_VIEW_USE_CUSTOM'
,p_display_order=>76
,p_column_identifier=>'BX'
,p_column_label=>'Icon View Use Custom'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51781612214200990)
,p_db_column_name=>'ICON_VIEW_CUSTOM_LINK'
,p_display_order=>77
,p_column_identifier=>'BY'
,p_column_label=>'Icon View Custom Link'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51782026561200990)
,p_db_column_name=>'ICON_VIEW_LINK_COLUMN'
,p_display_order=>78
,p_column_identifier=>'BZ'
,p_column_label=>'Icon View Link Column'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51782480329200992)
,p_db_column_name=>'ICON_VIEW_IMG_SRC_COLUMN'
,p_display_order=>79
,p_column_identifier=>'CA'
,p_column_label=>'Icon View Img Src Column'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51782810145200992)
,p_db_column_name=>'ICON_VIEW_LABEL_COLUMN'
,p_display_order=>80
,p_column_identifier=>'CB'
,p_column_label=>'Icon View Label Column'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51783220379200993)
,p_db_column_name=>'ICON_VIEW_IMG_ATTR_TEXT'
,p_display_order=>81
,p_column_identifier=>'CC'
,p_column_label=>'Icon View Img Attr Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51783604725200993)
,p_db_column_name=>'ICON_VIEW_ALT_TEXT'
,p_display_order=>82
,p_column_identifier=>'CD'
,p_column_label=>'Icon View Alt Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51784035079200993)
,p_db_column_name=>'ICON_VIEW_TITLE_TEXT'
,p_display_order=>83
,p_column_identifier=>'CE'
,p_column_label=>'Icon View Title Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51784432733200995)
,p_db_column_name=>'ICON_VIEW_COLUMNS_PER_ROW'
,p_display_order=>84
,p_column_identifier=>'CF'
,p_column_label=>'Icon View Columns Per Row'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51784828188200995)
,p_db_column_name=>'DETAIL_VIEW_ENABLED_YN'
,p_display_order=>85
,p_column_identifier=>'CG'
,p_column_label=>'Detail View Enabled Yn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51785232710200995)
,p_db_column_name=>'DETAIL_VIEW_BEFORE_ROWS'
,p_display_order=>86
,p_column_identifier=>'CH'
,p_column_label=>'Detail View Before Rows'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51785685380200996)
,p_db_column_name=>'DETAIL_VIEW_FOR_EACH_ROW'
,p_display_order=>87
,p_column_identifier=>'CI'
,p_column_label=>'Detail View For Each Row'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51786090351200996)
,p_db_column_name=>'DETAIL_VIEW_AFTER_ROWS'
,p_display_order=>88
,p_column_identifier=>'CJ'
,p_column_label=>'Detail View After Rows'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51786435254200996)
,p_db_column_name=>'INTERNAL_UID'
,p_display_order=>89
,p_column_identifier=>'CK'
,p_column_label=>'Internal Uid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51786806309200998)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>90
,p_column_identifier=>'CL'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51787289801200998)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>91
,p_column_identifier=>'CM'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51787653793200998)
,p_db_column_name=>'UPDATED_ON'
,p_display_order=>92
,p_column_identifier=>'CN'
,p_column_label=>'Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51787936360201000)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>93
,p_column_identifier=>'CO'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51788327024201000)
,p_db_column_name=>'COMPONENT_SIGNATURE'
,p_display_order=>94
,p_column_identifier=>'CP'
,p_column_label=>'Component Signature'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51800711535206019)
,p_db_column_name=>'SQL_QUERY'
,p_display_order=>104
,p_column_identifier=>'CQ'
,p_column_label=>'Sql Query'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51801240885206024)
,p_db_column_name=>'LINK_TO_PAGE'
,p_display_order=>114
,p_column_identifier=>'CR'
,p_column_label=>'Link To Page'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(51821913086206850)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'518220'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_TO_PAGE:WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:APPLICATION_NAME:PAGE_ID:INTERACTIVE_REPORT_ID:REGION_ID:REGION_NAME:NUMBER_OF_COLUMNS:NUMBER_OF_COLUMN_GROUPS:NUMBER_OF_ALT_DEFAULT_REPORTS:NUMBER_OF_PUBLIC_REPORTS:NUMBER_OF_PRIVATE_REPOR'
||'TS:MAX_ROW_COUNT:MAX_ROW_COUNT_MESSAGE:NO_DATA_FOUND_MESSAGE:MAX_ROWS_PER_PAGE:SEARCH_BUTTON_LABEL:PAGE_ITEMS_TO_SUBMIT:BASE_TABLE_OR_VIEW:SHOW_NULLS_AS:PAGINATION_SCHEME:PAGINATION_DISPLAY_POSITION:BUTTON_TEMPLATE:SHOW_FINDER_DROP_DOWN:SHOW_REPORTS_'
||'SELECT_LIST:SHOW_DISPLAY_ROW_COUNT:SHOW_SEARCH_BAR:SHOW_SEARCH_TEXTBOX:SHOW_ACTIONS_MENU:ACTIONS_MENU_ICON:FINDER_ICON:SHOW_SELECT_COLUMNS:SHOW_ROWS_PER_PAGE:SHOW_FILTER:SHOW_SORT:SHOW_CONTROL_BREAK:SHOW_HIGHLIGHT:SHOW_COMPUTE:SHOW_AGGREGATE:SHOW_CHA'
||'RT:SHOW_GROUP_BY:SHOW_PIVOT:SHOW_NOTIFY:SHOW_FLASHBACK:SHOW_SAVE:SHOW_SAVE_PUBLIC:SAVE_PUBLIC_AUTH_SCHEME:SAVE_PUBLIC_AUTH_SCHEME_ID:SHOW_RESET:SHOW_DOWNLOAD:SHOW_HELP:DOWNLOAD_FORMATS:FILENAME:SEPARATOR:ENCLOSED_BY:DETAIL_LINK_TYPE:DETAIL_LINK_TARGE'
||'T:DETAIL_LINK_TEXT:DETAIL_LINK_ATTRIBUTES:DETAIL_LINK_CHECKSUM_TYPE:DETAIL_LINK_CONDITION_TYPE:DETAIL_LINK_COND_TYPE_CODE:DETAIL_LINK_COND_EXPRESSION:DETAIL_LINK_COND_EXPRESSION2:DETAIL_LINK_AUTH_SCHEME:DETAIL_LINK_AUTH_SCHEME_ID:ALIAS:REPORT_ID_ITEM'
||':MAX_QUERY_COST:EMAIL_FROM:FIXED_HEADER:FIXED_HEADER_MAX_HEIGHT:ICON_VIEW_ENABLED_YN:ICON_VIEW_USE_CUSTOM:ICON_VIEW_CUSTOM_LINK:ICON_VIEW_LINK_COLUMN:ICON_VIEW_IMG_SRC_COLUMN:ICON_VIEW_LABEL_COLUMN:ICON_VIEW_IMG_ATTR_TEXT:ICON_VIEW_ALT_TEXT:ICON_VIEW'
||'_TITLE_TEXT:ICON_VIEW_COLUMNS_PER_ROW:DETAIL_VIEW_ENABLED_YN:DETAIL_VIEW_BEFORE_ROWS:DETAIL_VIEW_FOR_EACH_ROW:DETAIL_VIEW_AFTER_ROWS:INTERNAL_UID:CREATED_ON:CREATED_BY:UPDATED_ON:UPDATED_BY:COMPONENT_SIGNATURE:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(53686373251800290)
,p_report_id=>wwv_flow_api.id(51821913086206850)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'LINK_TO_PAGE'
,p_operator=>'contains'
,p_expr=>'261'
,p_condition_sql=>'upper("LINK_TO_PAGE") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''261''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(51800336784206015)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7348641599537474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7346885205537473)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7348901836537474)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7346885205537473)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7111190258925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7348848199537474)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7346885205537473)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7110358808925237)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7350332669537475)
,p_branch_action=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7348901836537474)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7349643306537474)
,p_branch_action=>'f?p=&APP_ID.:12:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7348848199537474)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7348319311537474)
,p_name=>'P13_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7346976327537473)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51800423137206016)
,p_name=>'P13_APPLICATION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(51800336784206015)
,p_prompt=>'Application Id'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id d , application_id r',
'from APEX_APPLICATION_PAGE_IR',
'group by application_id',
'order by application_id'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51800582749206017)
,p_name=>'P13_PAGE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(51800336784206015)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id || '' '' || page_id d, page_id',
'from APEX_APPLICATION_PAGE_IR',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51800607058206018)
,p_name=>'P13_INTERACTIVE_REPORT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(51800336784206015)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id || '' '' || page_id ||  '' '' || '' '' || region_name || '' '' || region_id || '' ''|| interactive_report_id, interactive_report_id',
'from APEX_APPLICATION_PAGE_IR'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(51800858616206020)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_PAGE_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(51800903912206021)
,p_event_id=>wwv_flow_api.id(51800858616206020)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(51801029208206022)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_INTERACTIVE_REPORT_ID'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(51801196376206023)
,p_event_id=>wwv_flow_api.id(51801029208206022)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
