prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>34
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'v_db_check_table_content_load'
,p_alias=>'V_DB_CHECK_TABLE_CONTENT_34'
,p_step_title=>'v_db_check_table_content_load'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201013105327'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3511560866832246)
,p_plug_name=>' v_db_check_table_content_load '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'apex_item.checkbox2(1,PK_DB_TAB_TABLE_CONTENT_COUNT_CNT) sel,',
'       DT,',
'       OLD_DATUM,',
'       OLD_OBJECT_TYPE,',
'       OLD_FK_STD_DB_NEED_BUILT,',
'       OLD_FK_STD_DB_NEED_REGULARLY_UPD,',
'       OLD_TABLE_NAME_NEW,',
'       OLD_TABLE_NAME_OLD,',
'       OLD_OBJECT_STATUS_OLD,',
'       OLD_MODUL,',
'       PK_DB_TAB_TABLE_CONTENT_COUNT,',
'       OLD_TABLE_NAME,',
'       OLD_TABLE_NAME OLD_TABLE_NAME2,',
'       OLD_CNT,',
'       OLD_COMM,',
'       OLD_DATUM_CHECK_OK,',
'       OLD_FK_STD_DB_CHECK_STATUS,',
'       OLD_FK_STD_DB_DATA_TRANSFERED,',
'       NEW_POS,',
'       NEW_TABLE_NAME,',
'       NEW_CNT,',
'       DIFF,',
'       OBJECT_NAME,',
'       OLD_RE_IMP_NR,',
'       TRANSF_POS1,',
'       TRANSF_MAX_TRANSF_DATE,',
'       TRANSF_MIN_TRANSF_DATE,',
'       TRANSF_CNT_TRANSFERED,',
'       to_number(CNT) cnt,',
'        PK_DB_TAB_TABLE_CONTENT_COUNT_CNT,',
'       PK_DB_TAB_TABLE_CONTENT_COUNT_LOAD,',
'       LOAD_DT,',
'       CREATED_AT,',
'       CONNECTION_STR,',
'       datum_ok',
'  from V_DB_CHECK_TABLE_CONTENT_LOAD'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>' v_db_check_table_content_load '
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3511660367832246)
,p_name=>' v_db_check_table_content_load '
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::P36_PK_DB_TAB_TABLE_CONTENT_COUNT_CNT:#PK_DB_TAB_TABLE_CONTENT_COUNT_CNT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>5713377610125390
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3511996471832388)
,p_db_column_name=>'DT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Dt'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3512301487832392)
,p_db_column_name=>'OLD_DATUM'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Old Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3512707809832392)
,p_db_column_name=>'OLD_OBJECT_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Old Object Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3513173965832393)
,p_db_column_name=>'OLD_FK_STD_DB_NEED_BUILT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Old Fk Std Db Need Built'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3513501520832393)
,p_db_column_name=>'OLD_FK_STD_DB_NEED_REGULARLY_UPD'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Old Fk Std Db Need Regularly Upd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3513895193832393)
,p_db_column_name=>'OLD_TABLE_NAME_NEW'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Old Table Name New'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3514338774832393)
,p_db_column_name=>'OLD_TABLE_NAME_OLD'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Old Table Name Old'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3514774680832393)
,p_db_column_name=>'OLD_OBJECT_STATUS_OLD'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Old Object Status Old'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3515116721832394)
,p_db_column_name=>'OLD_MODUL'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Old Modul'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3515514347832394)
,p_db_column_name=>'PK_DB_TAB_TABLE_CONTENT_COUNT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Pk Db Tab Table Content Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3515927081832394)
,p_db_column_name=>'OLD_TABLE_NAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Old Table Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3516368256832394)
,p_db_column_name=>'OLD_CNT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Old Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3516686977832395)
,p_db_column_name=>'OLD_COMM'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Old Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3517093008832395)
,p_db_column_name=>'OLD_DATUM_CHECK_OK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Old Datum Check Ok'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3517541390832395)
,p_db_column_name=>'OLD_FK_STD_DB_CHECK_STATUS'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Old Fk Std Db Check Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3517919150832395)
,p_db_column_name=>'OLD_FK_STD_DB_DATA_TRANSFERED'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Old Fk Std Db Data Transfered'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3518378936832396)
,p_db_column_name=>'NEW_POS'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'New Pos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3518692217832396)
,p_db_column_name=>'NEW_TABLE_NAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'New Table Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3519167796832396)
,p_db_column_name=>'NEW_CNT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'New Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3519566209832396)
,p_db_column_name=>'DIFF'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3519938801832396)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3520305740832397)
,p_db_column_name=>'OLD_RE_IMP_NR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Old Re Imp Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3520699922832397)
,p_db_column_name=>'TRANSF_POS1'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Transf Pos1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3521101345832397)
,p_db_column_name=>'TRANSF_MAX_TRANSF_DATE'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Transf Max Transf Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3521573033832397)
,p_db_column_name=>'TRANSF_MIN_TRANSF_DATE'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Transf Min Transf Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3521908046832398)
,p_db_column_name=>'TRANSF_CNT_TRANSFERED'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Transf Cnt Transfered'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3522766821832399)
,p_db_column_name=>'PK_DB_TAB_TABLE_CONTENT_COUNT_LOAD'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Pk Db Tab Table Content Count Load'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3523085674832399)
,p_db_column_name=>'LOAD_DT'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Load Dt'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3523528789832400)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3523916904832400)
,p_db_column_name=>'CONNECTION_STR'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Connection Str'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1722350232836261)
,p_db_column_name=>'OLD_TABLE_NAME2'
,p_display_order=>41
,p_column_identifier=>'AF'
,p_column_label=>'Old Table Name2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1722382968836262)
,p_db_column_name=>'CNT'
,p_display_order=>51
,p_column_identifier=>'AG'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1722558347836263)
,p_db_column_name=>'PK_DB_TAB_TABLE_CONTENT_COUNT_CNT'
,p_display_order=>61
,p_column_identifier=>'AH'
,p_column_label=>'Pk Db Tab Table Content Count Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1722614227836264)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>71
,p_column_identifier=>'AI'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1722729928836265)
,p_db_column_name=>'SEL'
,p_display_order=>81
,p_column_identifier=>'AJ'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3524542942834437)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'57263'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:OLD_TABLE_NAME:OLD_TABLE_NAME2:CNT:DATUM_OK:DIFF:NEW_CNT:OLD_CNT:OLD_COMM:PK_DB_TAB_TABLE_CONTENT_COUNT_LOAD:LOAD_DT:CREATED_AT:CONNECTION_STR:DT:OLD_DATUM:OLD_OBJECT_TYPE:OLD_FK_STD_DB_NEED_BUILT:OLD_FK_STD_DB_NEED_REGULARLY_UPD:OLD_TABLE_NAME_N'
||'EW:OLD_TABLE_NAME_OLD:OLD_OBJECT_STATUS_OLD:OLD_MODUL:PK_DB_TAB_TABLE_CONTENT_COUNT:OLD_DATUM_CHECK_OK:OLD_FK_STD_DB_CHECK_STATUS:OLD_FK_STD_DB_DATA_TRANSFERED:NEW_POS:NEW_TABLE_NAME:OBJECT_NAME:OLD_RE_IMP_NR:TRANSF_POS1:TRANSF_MAX_TRANSF_DATE:TRANSF'
||'_MIN_TRANSF_DATE:TRANSF_CNT_TRANSFERED:PK_DB_TAB_TABLE_CONTENT_COUNT_CNT:'
,p_break_on=>'OLD_TABLE_NAME:0:0:0:0:0'
,p_break_enabled_on=>'OLD_TABLE_NAME:0:0:0:0:0'
,p_sum_columns_on_break=>'CNT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3603558539187007)
,p_report_id=>wwv_flow_api.id(3524542942834437)
,p_name=>'datum_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>5
,p_column_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3602699699187006)
,p_report_id=>wwv_flow_api.id(3524542942834437)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CNT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#D4C5D4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3603111225187006)
,p_report_id=>wwv_flow_api.id(3524542942834437)
,p_name=>'new Server'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CONNECTION_STR'
,p_operator=>'contains'
,p_expr=>'46.101'
,p_condition_sql=>' (case when (upper("CONNECTION_STR") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''46.101''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3603960377187007)
,p_report_id=>wwv_flow_api.id(3524542942834437)
,p_name=>'Table_name'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OLD_TABLE_NAME2'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("OLD_TABLE_NAME2" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C2BAC2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3602314582187006)
,p_report_id=>wwv_flow_api.id(3524542942834437)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OLD_OBJECT_TYPE'
,p_operator=>'='
,p_expr=>'TABLE'
,p_condition_sql=>'"OLD_OBJECT_TYPE" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''TABLE''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7433109012545805)
,p_plug_name=>'Step 5'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7059309376925217)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7416671487545795)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7088215084925228)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7433204755545805)
,p_plug_name=>'Step 5'
,p_parent_plug_id=>wwv_flow_api.id(7433109012545805)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7021577436925200)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7434973405545806)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7433109012545805)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7435265605545806)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7433109012545805)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7111190258925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7435174927545806)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7433109012545805)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7110358808925237)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1722782930836266)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(3511560866832246)
,p_button_name=>'set_cnt_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Set Cnt Ok'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7436666401545807)
,p_branch_action=>'f?p=&APP_ID.:35:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7435265605545806)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7435997839545807)
,p_branch_action=>'f?p=&APP_ID.:33:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7435174927545806)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7434672222545806)
,p_name=>'P34_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7433204755545805)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1722944964836267)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_cnt_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'   if apex_application.g_f01(i) is not null then',
'   ',
'     update T_DB_TAB_TABLE_CONTENT_COUNT_CNT set datum_ok = sysdate , fk_std_db_tab_status = 1 where PK_DB_TAB_TABLE_CONTENT_COUNT_CNT = apex_application.g_f01(i);',
'     commit;',
'   end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(1722782930836266)
);
wwv_flow_api.component_end;
end;
/
