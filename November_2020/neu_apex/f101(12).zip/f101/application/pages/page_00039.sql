prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'t_page_groups_old'
,p_alias=>'T-PAGE-GROUPS-OLD'
,p_step_title=>'t_page_groups_old'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16633122521615623)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201013110116'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(27353976355835390)
,p_plug_name=>'t_page_groups_old'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SPALTE1, case when instr(spalte1 , :P39_new)>0 then 1 else 0 end sel, substr(spalte1,2,length(spalte1)) spalte2',
'  from T_PAGE_GROUPS_OLD'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'t_page_groups_old'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(27354023911835390)
,p_name=>'t_page_groups_old'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39:P39_NEW:#SPALTE2#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>27354023911835390
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27354410508835400)
,p_db_column_name=>'SPALTE1'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Spalte1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20889017496551843)
,p_db_column_name=>'SEL'
,p_display_order=>11
,p_column_identifier=>'B'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20889137500551844)
,p_db_column_name=>'SPALTE2'
,p_display_order=>21
,p_column_identifier=>'C'
,p_column_label=>'Spalte2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(27355182386847716)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'273552'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SPALTE1:SEL:SPALTE2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27360754264921228)
,p_report_id=>wwv_flow_api.id(27355182386847716)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27361172718921228)
,p_report_id=>wwv_flow_api.id(27355182386847716)
,p_name=>'Row text contains ''42862992502268653'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'42862992502268653'
,p_enabled=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20888964437551842)
,p_name=>'P39_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(27353976355835390)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
