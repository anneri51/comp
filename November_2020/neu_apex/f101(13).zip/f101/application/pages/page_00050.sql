prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>50
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'1_1_APP_apex_page_content_overview'
,p_alias=>'APEX-PAGE-CONTENT-OVERV_50'
,p_step_title=>'APP apex_page_content_overview'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(27902563542196336)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201015080317'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7498516531033585)
,p_plug_name=>'apex_page_content_overview'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_DB_APP_APEX_PAGES_CONTENT_CNT_LINES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_prn_page_header=>'apex_page_content_overview'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7498698490033585)
,p_name=>'apex_page_content_overview'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7498698490033585
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7499462247033589)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7499846839033590)
,p_db_column_name=>'APP_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'App Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7500280573033590)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7500686622033590)
,p_db_column_name=>'CNT_LINES'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cnt Lines'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7501098336033590)
,p_db_column_name=>'COMM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7501452488033591)
,p_db_column_name=>'COMPLETE_IMPORTED'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Complete Imported'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7501847870033591)
,p_db_column_name=>'CREATED_DATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665398532099810)
,p_db_column_name=>'PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Pk Db App Apex Pages Content Cnt Lines'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665428489099811)
,p_db_column_name=>'REBUILD_COMPLETED'
,p_display_order=>28
,p_column_identifier=>'J'
,p_column_label=>'Rebuild Completed'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665595890099812)
,p_db_column_name=>'REBUILD_COMPLETED_ON'
,p_display_order=>38
,p_column_identifier=>'K'
,p_column_label=>'Rebuild Completed On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665630147099813)
,p_db_column_name=>'FK_DB_APP_APPLICATION'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Fk Db App Application'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7502250987067907)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75023'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE_ID:APP_ID:PAGE_ID:CNT_LINES:COMM:COMPLETE_IMPORTED:CREATED_DATE:PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES:REBUILD_COMPLETED:REBUILD_COMPLETED_ON:FK_DB_APP_APPLICATION'
,p_sort_column_1=>'PAGE_ID'
,p_sort_direction_1=>'ASC'
,p_break_on=>'APP_ID'
,p_break_enabled_on=>'APP_ID'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7502861565070101)
,p_plug_name=>'apex_page_content_overview'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       APP_ID ap_id1,',
'       count(*),',
'       case when app_id = :P50_app_id1 then 1 else 0 end sel',
'  from T_DB_APP_APEX_PAGES_CONTENT_CNT_LINES',
'  group by app_id,',
'  case when app_id = :P50_ap_id1 then 1 else 0 end'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'apex_page_content_overview'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7502970535070102)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::P50_AP_ID1:#AP_ID1##APP_ID1##APP_ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>7502970535070102
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7503867012070111)
,p_db_column_name=>'COUNT(*)'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Count(*)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504197733070114)
,p_db_column_name=>'SEL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504493737070117)
,p_db_column_name=>'AP_ID1'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Ap Id1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7509269946075617)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75093'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COUNT(*):SEL:AP_ID1'
,p_sort_column_1=>'AP_ID1'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'APP_ID'
,p_sort_direction_2=>'ASC'
,p_sum_columns_on_break=>'COUNT(*)'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7520030499326843)
,p_report_id=>wwv_flow_api.id(7509269946075617)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7503970619070112)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7504565613070118)
,p_plug_name=>'apex_page_content_overview'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apcntli.PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES,',
'        apcntli.WORKSPACE_ID,',
'        apcntli.APP_ID,',
'        apcntli.PAGE_ID,',
'        apcntli.CNT_LINES,',
'        apcntli.COMM,',
'        apcntli.COMPLETE_IMPORTED,',
'        apcntli.CREATED_DATE,',
'        apcntli.REBUILD_COMPLETED,',
'        apcntli.REBUILD_COMPLETED_ON,',
'       case when app_id = :P50_ap_id then 1 else 0 end sel,',
'       apcnt.cnt,',
'        apcntli.CNT_LINES-apcnt.cnt diff',
'  from T_DB_APP_APEX_PAGES_CONTENT_CNT_LINES apcntli',
'   left join (select application_id, page_id, count(*) cnt from  t_db_app_apex_pages_content group by application_id, page_id) apcnt on apcntli.app_id = apcnt.application_id and apcntli.page_id = apcnt.page_id',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'apex_page_content_overview'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7504638305070119)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7504638305070119
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504833824070121)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7504958832070122)
,p_db_column_name=>'APP_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'App Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505090994070123)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505127222070124)
,p_db_column_name=>'CNT_LINES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cnt Lines'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505292211070125)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505356093070126)
,p_db_column_name=>'COMPLETE_IMPORTED'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Complete Imported'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505416700070127)
,p_db_column_name=>'CREATED_DATE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505510470070128)
,p_db_column_name=>'REBUILD_COMPLETED'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Rebuild Completed'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505613508070129)
,p_db_column_name=>'REBUILD_COMPLETED_ON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Rebuild Completed On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505780542070130)
,p_db_column_name=>'SEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505843085070131)
,p_db_column_name=>'CNT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7505982999070132)
,p_db_column_name=>'DIFF'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665761058099814)
,p_db_column_name=>'PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Pk Db App Apex Pages Content Cnt Lines'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7715817868222420)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'77159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE_ID:APP_ID:PAGE_ID:CNT_LINES:COMM:COMPLETE_IMPORTED:CREATED_DATE:REBUILD_COMPLETED:REBUILD_COMPLETED_ON:SEL:CNT:DIFF:PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES'
,p_sort_column_1=>'APP_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_ID'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7719045639305599)
,p_report_id=>wwv_flow_api.id(7715817868222420)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7719484477305599)
,p_report_id=>wwv_flow_api.id(7715817868222420)
,p_name=>'rebuild_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'REBUILD_COMPLETED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("REBUILD_COMPLETED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7504388071070116)
,p_name=>'P50_AP_ID1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7503970619070112)
,p_prompt=>'Ap Id1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
