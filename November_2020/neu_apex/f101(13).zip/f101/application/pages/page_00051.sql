prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>51
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'2_4_APP_page_work'
,p_alias=>'PAGE_WORK_51'
,p_step_title=>'APP page_work'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(27902563542196336)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201015080424'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47209473901163799)
,p_plug_name=>'pages'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pag.PK_APP_PAGES,',
'       pag.FK_MDT_MANDANT,',
'       pag.CREATED_AT,',
'       pag.MODIFIED_AT,',
'       pag.PAGE_ID,',
'       pag.COMM,',
'       pag.LAST_CHANGE_DATE,',
'       pag.FK_STD_STAT_STATUS_OK,',
'       app_pages.page_name,',
'       app_pages.page_alias',
'  from T_APP_PAGES pag',
'   left join (select * from apex_application_pages  where application_id = 100) app_pages on app_pages.page_id = pag.page_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'pages'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(47209536974163800)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:465:&SESSION.::&DEBUG.::P465_PK_APP_PAGES:#PK_APP_PAGES#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>47209536974163800
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27677681617328186)
,p_db_column_name=>'PK_APP_PAGES'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk App Pages'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27678019049328189)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27678440014328189)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27678801350328189)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27679281181328189)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27679692213328190)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27680000356328190)
,p_db_column_name=>'LAST_CHANGE_DATE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Last Change Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27680457391328190)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27680845230328190)
,p_db_column_name=>'PAGE_ALIAS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Page Alias'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27681243008328191)
,p_db_column_name=>'FK_STD_STAT_STATUS_OK'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Std Stat Status Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(47489200016933934)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'276816'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_APP_PAGES:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:PAGE_ID:COMM:LAST_CHANGE_DATE:PAGE_NAME:PAGE_ALIAS:FK_STD_STAT_STATUS_OK'
,p_sort_column_1=>'PK_APP_PAGES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_NAME'
,p_sort_direction_2=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27706098271336795)
,p_report_id=>wwv_flow_api.id(47489200016933934)
,p_name=>'OK'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27706400434336795)
,p_report_id=>wwv_flow_api.id(47489200016933934)
,p_name=>'not ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27704885841336794)
,p_report_id=>wwv_flow_api.id(47489200016933934)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27705246759336794)
,p_report_id=>wwv_flow_api.id(47489200016933934)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'in'
,p_expr=>'0,2'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 0, 2  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27705620107336794)
,p_report_id=>wwv_flow_api.id(47489200016933934)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NAME'
,p_operator=>'is not null'
,p_condition_sql=>'"PAGE_NAME" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(47886445331845029)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'finished'
,p_report_seq=>10
,p_report_alias=>'276887'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_APP_PAGES:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:PAGE_ID:COMM:LAST_CHANGE_DATE:PAGE_NAME:PAGE_ALIAS:FK_STD_STAT_STATUS_OK'
,p_sort_column_1=>'PK_APP_PAGES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_NAME'
,p_sort_direction_2=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27690335140328202)
,p_report_id=>wwv_flow_api.id(47886445331845029)
,p_name=>'OK'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27690757004328202)
,p_report_id=>wwv_flow_api.id(47886445331845029)
,p_name=>'not ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27689170054328201)
,p_report_id=>wwv_flow_api.id(47886445331845029)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27689560270328201)
,p_report_id=>wwv_flow_api.id(47886445331845029)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'in'
,p_expr=>'0,2'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 0, 2  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27689931682328201)
,p_report_id=>wwv_flow_api.id(47886445331845029)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NAME'
,p_operator=>'is not null'
,p_condition_sql=>'"PAGE_NAME" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(47889463077847421)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'not finished'
,p_report_seq=>10
,p_report_alias=>'276840'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_APP_PAGES:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:PAGE_ID:COMM:LAST_CHANGE_DATE:PAGE_NAME:PAGE_ALIAS:FK_STD_STAT_STATUS_OK'
,p_sort_column_1=>'PK_APP_PAGES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_NAME'
,p_sort_direction_2=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27685546548328198)
,p_report_id=>wwv_flow_api.id(47889463077847421)
,p_name=>'OK'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27685911303328199)
,p_report_id=>wwv_flow_api.id(47889463077847421)
,p_name=>'not ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27684389671328198)
,p_report_id=>wwv_flow_api.id(47889463077847421)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27684701867328198)
,p_report_id=>wwv_flow_api.id(47889463077847421)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'in'
,p_expr=>'0,2'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 0, 2  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27685115921328198)
,p_report_id=>wwv_flow_api.id(47889463077847421)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NAME'
,p_operator=>'is not null'
,p_condition_sql=>'"PAGE_NAME" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(47892414403850710)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'todo'
,p_report_seq=>10
,p_report_alias=>'276863'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_APP_PAGES:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:PAGE_ID:COMM:LAST_CHANGE_DATE:PAGE_NAME:PAGE_ALIAS:FK_STD_STAT_STATUS_OK'
,p_sort_column_1=>'PK_APP_PAGES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PAGE_NAME'
,p_sort_direction_2=>'DESC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27687982115328200)
,p_report_id=>wwv_flow_api.id(47892414403850710)
,p_name=>'OK'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D0F1CC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27688317849328200)
,p_report_id=>wwv_flow_api.id(47892414403850710)
,p_name=>'not ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFD6D2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27686739542328199)
,p_report_id=>wwv_flow_api.id(47892414403850710)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27687166777328199)
,p_report_id=>wwv_flow_api.id(47892414403850710)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STD_STAT_STATUS_OK'
,p_operator=>'in'
,p_expr=>'0'
,p_condition_sql=>'"FK_STD_STAT_STATUS_OK" in (#APXWS_EXPR_VAL1#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 0  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(27687564241328200)
,p_report_id=>wwv_flow_api.id(47892414403850710)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_NAME'
,p_operator=>'is not null'
,p_condition_sql=>'"PAGE_NAME" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47473634481895969)
,p_plug_name=>'page_work'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7048974933925211)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_APP_PAGES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27692236516328213)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(47473634481895969)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P51_PK_APP_PAGES'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27691470640328209)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(47473634481895969)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27692630223328213)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(47473634481895969)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P51_PK_APP_PAGES'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(27691848611328212)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(47473634481895969)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P51_PK_APP_PAGES'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27693009472328213)
,p_name=>'P51_PK_APP_PAGES'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_source=>'PK_APP_PAGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27693458008328216)
,p_name=>'P51_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_default=>'1'
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27693855478328217)
,p_name=>'P51_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27694233397328217)
,p_name=>'P51_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27694685843328217)
,p_name=>'P51_PAGE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_prompt=>'Page Id'
,p_source=>'PAGE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27695083371328217)
,p_name=>'P51_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27695443401328217)
,p_name=>'P51_FK_STD_STAT_STATUS_OK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_prompt=>'Fk Std Stat Status Ok'
,p_source=>'FK_STD_STAT_STATUS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:NAN;0,finished;1,not ok;2,page deleted - ok;3,page_not_old_app;4'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(27695841834328218)
,p_name=>'P51_LAST_CHANGE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_source_plug_id=>wwv_flow_api.id(47473634481895969)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Last Change Date'
,p_source=>'LAST_CHANGE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7109939202925236)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27696638251328219)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(47473634481895969)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form page_work'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(27696254594328218)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(47473634481895969)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form page_work'
);
wwv_flow_api.component_end;
end;
/
