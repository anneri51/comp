prompt --application/shared_components/user_interface/lovs/lov_fk_db_app_ownership
begin
--   Manifest
--     LOV_FK_DB_APP_OWNERSHIP
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(27750967576366195)
,p_lov_name=>'LOV_FK_DB_APP_OWNERSHIP'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 1003'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'STD_VALUE'
,p_display_column_name=>'STD_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'STD_VALUE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
