prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>42
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'Page history'
,p_alias=>'PAGE-HISTORY'
,p_step_title=>'Page history'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'SHAHIDG'
,p_last_upd_yyyymmddhh24miss=>'20201020102607'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(37575847954343333)
,p_plug_name=>'Page history'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select apcntli.PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES,',
'null pk_db_app_pages_history,',
'apcntli.WORKSPACE_ID,',
'apcntli.APP_ID,',
'apcntli.PAGE_ID,',
'apcntli.CNT_LINES,',
'apcntli.COMM,',
'apcntli.COMPLETE_IMPORTED,',
'apcntli.CREATED_DATE,',
'apcntli.REBUILD_COMPLETED,',
'apcntli.REBUILD_COMPLETED_ON,',
'--case when app_id = :P50_ap_id then 1 else 0 end sel,',
'apcnt.cnt,',
'apcntli.CNT_LINES-apcnt.cnt diff,',
'-- pg.page_name,',
'fk_db_app_workspace,',
'connection_string,',
'apcntli.FK_DB_APP_APPLICATION, apcntli.MODIFIED_AT, apcntli.FK_STD_PAG_STATUS, apcntli.FK_MDT_MANDANT, apcntli.LAST_CHANGE_DATE,',
'',
'app_pages.page_name,',
'app_pages.page_alias,',
'app_pages.page_title,',
'FK_STD_PAG_ITEM_ALL_STATUS,',
'FK_STD_PAG_ITEM_SEL_POPUP_STATUS,',
'FK_STD_PAG_BUTTON_STATUS,',
'FK_STD_PAG_REPORTS_STATUS,',
'FK_STD_PAG_LINKS_STATUS,',
'FK_STD_PAG_PROCESSES_STATUS',
'from T_DB_APP_APEX_PAGES_CONTENT_CNT_LINES apcntli',
'',
'left join (select application_id, page_id, count(*) cnt from t_db_app_apex_pages_content group by application_id, page_id) apcnt on apcntli.app_id = apcnt.application_id and apcntli.page_id = apcnt.page_id',
'left join t_db_app_application app on app.pK_db_app_application = apcntli.fk_db_app_application',
'left join t_db_app_workspace wsp on wsp.pk_db_app_workspace = app.fk_db_app_workspace',
'left join t_db_datenbank db on db.pk_db_datenbank = wsp.fk_db_datenbank',
'left join (select * from apex_application_pages ) app_pages on app_pages.page_id = apcntli.page_id and app_pages.application_id = apcntli.app_id',
'',
'',
'where',
'(app_id=:P42_APP_ID',
' )',
'union',
'select',
'null PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES,',
'pk_db_app_pages_history,',
'null WORKSPACE_ID,',
'APP_ID,',
'PAGE_ID,',
'null CNT_LINES,',
'COMM,',
'null COMPLETE_IMPORTED,',
'null CREATED_DATE,',
'null REBUILD_COMPLETED,',
'null REBUILD_COMPLETED_ON,',
'--case when app_id = :P50_ap_id then 1 else 0 end sel,',
'null cnt,',
'null  diff,',
'-- pg.page_name,',
'null fk_db_app_workspace,',
'null connection_string,',
'FK_DB_APP_APPLICATION,',
'MODIFIED_AT,',
'FK_STD_PAG_STATUS,',
'FK_MDT_MANDANT, ',
'LAST_CHANGE_DATE,',
'',
'page_name,',
'page_alias,',
'page_title,',
'FK_STD_PAG_ITEM_ALL_STATUS,',
'FK_STD_PAG_ITEM_SEL_POPUP_STATUS,',
'FK_STD_PAG_BUTTON_STATUS,',
'FK_STD_PAG_REPORTS_STATUS,',
'FK_STD_PAG_LINKS_STATUS,',
'FK_STD_PAG_PROCESSES_STATUS from ',
'T_DB_APP_PAGES_HISTORY',
'where',
'(app_id=:P42_APP_ID',
')',
'',
'order by Last_Change_date DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P42_APP_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Page history'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(37575973849343333)
,p_name=>'Page history'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'SHAHIDG'
,p_internal_uid=>37575973849343333
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37576389590343342)
,p_db_column_name=>'PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Db App Apex Pages Content Cnt Lines'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37576757209343346)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37577161487343346)
,p_db_column_name=>'APP_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'App Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37577519870343346)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37577939768343347)
,p_db_column_name=>'CNT_LINES'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cnt Lines'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37578351455343347)
,p_db_column_name=>'COMM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37578728198343347)
,p_db_column_name=>'COMPLETE_IMPORTED'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Complete Imported'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37579127339343348)
,p_db_column_name=>'CREATED_DATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37579525715343348)
,p_db_column_name=>'REBUILD_COMPLETED'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Rebuild Completed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37579915845343348)
,p_db_column_name=>'REBUILD_COMPLETED_ON'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Rebuild Completed On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37580712924343349)
,p_db_column_name=>'CNT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37581141927343349)
,p_db_column_name=>'DIFF'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37581583100343349)
,p_db_column_name=>'FK_DB_APP_WORKSPACE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk Db App Workspace'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37581987531343349)
,p_db_column_name=>'CONNECTION_STRING'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Connection String'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37582323875343349)
,p_db_column_name=>'FK_DB_APP_APPLICATION'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Fk Db App Application'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37582747734343350)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37583159585343350)
,p_db_column_name=>'FK_STD_PAG_STATUS'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Fk Std Pag Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37583505021343350)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37583935807343350)
,p_db_column_name=>'LAST_CHANGE_DATE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Last Change Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37584385894343351)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37584788692343351)
,p_db_column_name=>'PAGE_ALIAS'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Page Alias'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37585116832343351)
,p_db_column_name=>'PAGE_TITLE'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Page Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37585557937343352)
,p_db_column_name=>'FK_STD_PAG_ITEM_ALL_STATUS'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fk Std Pag Item All Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37585995479343352)
,p_db_column_name=>'FK_STD_PAG_ITEM_SEL_POPUP_STATUS'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fk Std Pag Item Sel Popup Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37586312798343352)
,p_db_column_name=>'FK_STD_PAG_BUTTON_STATUS'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Pag Button Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37586712308343352)
,p_db_column_name=>'FK_STD_PAG_REPORTS_STATUS'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Fk Std Pag Reports Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37587139791343353)
,p_db_column_name=>'FK_STD_PAG_LINKS_STATUS'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Fk Std Pag Links Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37587554927343353)
,p_db_column_name=>'FK_STD_PAG_PROCESSES_STATUS'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Pag Processes Status'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37588099911347702)
,p_db_column_name=>'PK_DB_APP_PAGES_HISTORY'
,p_display_order=>39
,p_column_identifier=>'AD'
,p_column_label=>'Pk Db App Pages History'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(37593103137363940)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'375932'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_DB_APP_APEX_PAGES_CONTENT_CNT_LINES:WORKSPACE_ID:APP_ID:PAGE_ID:CNT_LINES:COMM:COMPLETE_IMPORTED:CREATED_DATE:REBUILD_COMPLETED:REBUILD_COMPLETED_ON:CNT:DIFF:FK_DB_APP_WORKSPACE:CONNECTION_STRING:FK_DB_APP_APPLICATION:MODIFIED_AT:FK_STD_PAG_STATUS'
||':FK_MDT_MANDANT:LAST_CHANGE_DATE:PAGE_NAME:PAGE_ALIAS:PAGE_TITLE:FK_STD_PAG_ITEM_ALL_STATUS:FK_STD_PAG_ITEM_SEL_POPUP_STATUS:FK_STD_PAG_BUTTON_STATUS:FK_STD_PAG_REPORTS_STATUS:FK_STD_PAG_LINKS_STATUS:FK_STD_PAG_PROCESSES_STATUS:PK_DB_APP_PAGES_HISTOR'
||'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(37588166780347703)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(37575847954343333)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7111050959925237)
,p_button_image_alt=>'Submit'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(37587970187347701)
,p_name=>'P42_APP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(37575847954343333)
,p_prompt=>'App Id'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select application_number||''--''||application_name,application_number from T_DB_APP_APPLICATION'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-All-'
,p_lov_null_value=>'0'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7109775320925236)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
