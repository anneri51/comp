prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(47577226753610168)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632727252605008)
,p_group_name=>'1  - 1 - DB Work - Database Objects'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632876297608890)
,p_group_name=>'1 - 2 - DB Work - Renaming'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16632998848613415)
,p_group_name=>'2 - 1 - Application  Work - Navigation'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(27902563542196336)
,p_group_name=>'2 - 2 - Application Work  - Applications'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16633122521615623)
,p_group_name=>'2 - 3 - Application Work - Old Applications'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(16633221392616695)
,p_group_name=>'99  - Standard'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(48250276776250054)
,p_group_name=>'9999 - Global'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(27926975161811394)
,p_group_name=>'99999 - Unasigned'
);
wwv_flow_api.component_end;
end;
/
