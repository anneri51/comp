prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(6995487047925191)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(47583983871610207)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'DB Work'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'35,40,2,59,60'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54990858693623046)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'1 - TOV - Table Object List'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1718516278732015)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'1 - TOV -  Table (Content) count'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27,30,34'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3510835569832242)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'1 - TOV - Table check Content load'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(1718516278732015)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'34'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(53120358394025700)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'1 - TOV - Table Column Names'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(18732257385199498)
,p_list_item_display_sequence=>165
,p_list_item_link_text=>'2 - TBW - Create Table'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(47613973474642793)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'2 - TBW - Table Rename'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28418414870515755)
,p_list_item_display_sequence=>920
,p_list_item_link_text=>'2 - 1 - TBW - Table rename'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(47613973474642793)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3,9'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(55038625243542276)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'3 - TBWO - Trigger'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'28'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(47683389731974979)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'3 - TBWO -  Sequences'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(17023505403517306)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'4 - TXTW - Text Replace Context'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(17031661791642985)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'4 - TXTW - Text replace'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27929451435969626)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>unistr('5 - DBOV - Datebank \00DCberblick')
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626061271517841)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'59'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27882981544059683)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'5 - 1 - DBOV - Server'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27929451435969626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'54,55'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27900534166143748)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>'5 - 2 - DBOV - Cloud Container'
,p_list_item_link_target=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27929451435969626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'56,57'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28052578676413708)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'5 - 3 - DBOV - Datenbank'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27929451435969626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'60,61'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28217310359451707)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>'5 - 4 - DBOV - Backup'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27929451435969626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'64,65'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(16626638839521372)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Application Work'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'37,38,39,51,52,58,27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(16631313861592381)
,p_list_item_display_sequence=>600
,p_list_item_link_text=>'1 - NAV - Navigation'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626638839521372)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'38'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(49466953589483215)
,p_list_item_display_sequence=>610
,p_list_item_link_text=>unistr('1 - 1 - NAV -  Navigation_Men\00FCs')
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16631313861592381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(48457132579823339)
,p_list_item_display_sequence=>620
,p_list_item_link_text=>'1 - 2 - NAV - Branches'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16631313861592381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_display_sequence=>700
,p_list_item_link_text=>'2 - APP - Applications'
,p_list_item_link_target=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(16626638839521372)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'52,53'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28071155047439609)
,p_list_item_display_sequence=>710
,p_list_item_link_text=>'2 - 1 - 1 - APP - Workspace'
,p_list_item_link_target=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'62,63'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7600611068623040)
,p_list_item_display_sequence=>740
,p_list_item_link_text=>'2 - 2 - 1 - APP - Page List'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(37575421984343323)
,p_list_item_display_sequence=>940
,p_list_item_link_text=>'Page history'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(7600611068623040)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'42'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28025842607279308)
,p_list_item_display_sequence=>750
,p_list_item_link_text=>'2 - 2 - 2 - APP - Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28028794844467982)
,p_list_item_display_sequence=>755
,p_list_item_link_text=>'2 - 2 - 3 - APP - Invalid Regions'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(28220681345486169)
,p_list_item_display_sequence=>757
,p_list_item_link_text=>'2 - 2 - 4 - APP - Backup'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(43661320591984725)
,p_list_item_display_sequence=>950
,p_list_item_link_text=>'Backup'
,p_list_item_link_target=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(28220681345486169)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'43'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29208678295281158)
,p_list_item_display_sequence=>758
,p_list_item_link_text=>'2 - 2 - 5 - APP - app_pages_debug_messages'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27741885343320904)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27925152380677543)
,p_list_item_display_sequence=>760
,p_list_item_link_text=>'3 - OLD - Old Application Pages'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(16626638839521372)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'58'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27676629548328174)
,p_list_item_display_sequence=>770
,p_list_item_link_text=>'3 - 1 - OLD - Pages'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27925152380677543)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'51'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(27353579258835388)
,p_list_item_display_sequence=>780
,p_list_item_link_text=>'3 - 2 - OLD - Page Groups'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27925152380677543)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'39'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7600964014624950)
,p_list_item_display_sequence=>790
,p_list_item_link_text=>'3 - 3 - OLD - Page Content'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(27925152380677543)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(16798457141010903)
,p_list_item_display_sequence=>13
,p_list_item_link_text=>'SAVE HISTORY'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'40'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(49315015663761709)
,p_list_item_display_sequence=>14
,p_list_item_link_text=>'STD'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(49332351640854587)
,p_list_item_display_sequence=>910
,p_list_item_link_text=>'1 - STD'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(49315015663761709)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_api.component_end;
end;
/
