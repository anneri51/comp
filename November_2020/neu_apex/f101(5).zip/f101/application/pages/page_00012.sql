prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>2201717242293144
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(47574086381610126)
,p_name=>'Branches'
,p_step_title=>'Branches'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632998848613415)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200723145100'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(48457580661823348)
,p_plug_name=>'Branches'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *  ',
'from v_apx_branch_from_to_all '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(48457606406823348)
,p_name=>'Branches'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>48457606406823348
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48458059472823368)
,p_db_column_name=>'PAGE_FROM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Page From'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48458378253823400)
,p_db_column_name=>'PAGE_TO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Page To'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48459514264823403)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52626200937148318)
,p_db_column_name=>'BRANCH_NAME'
,p_display_order=>15
,p_column_identifier=>'F'
,p_column_label=>'Branch Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52626360458148319)
,p_db_column_name=>'TYPE'
,p_display_order=>25
,p_column_identifier=>'G'
,p_column_label=>'Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(48469317088824898)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'484694'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PAGE_FROM:PAGE_TO:APPLICATION_ID:BRANCH_NAME:TYPE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48487857126013417)
,p_report_id=>wwv_flow_api.id(48469317088824898)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APPLICATION_ID'
,p_operator=>'='
,p_expr=>'101'
,p_condition_sql=>'"APPLICATION_ID" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48488206417013417)
,p_report_id=>wwv_flow_api.id(48469317088824898)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_TO'
,p_operator=>'='
,p_expr=>'8'
,p_condition_sql=>'"PAGE_TO" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''8''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(48488661802013417)
,p_report_id=>wwv_flow_api.id(48469317088824898)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PAGE_TO'
,p_operator=>'contains'
,p_expr=>'8'
,p_condition_sql=>'upper("PAGE_TO") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''8''  '
,p_enabled=>'N'
);
wwv_flow_api.component_end;
end;
/
