prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>2201717242293144
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(47574086381610126)
,p_name=>'Dependency'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Dependency'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(16632727252605008)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200723120649'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(52645563220846746)
,p_plug_name=>'Dependency'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'V_DB_DEPENDENCY'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(52645644890846746)
,p_name=>'Dependency'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>52645644890846746
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52646070073846782)
,p_db_column_name=>'OWNER_SRC'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Owner Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52646480716846785)
,p_db_column_name=>'OBJECT_NAME_SRC'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Object Name Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52646880475846785)
,p_db_column_name=>'OBJECT_TYPE_SRC'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Object Type Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52647218639846785)
,p_db_column_name=>'LAST_DDL_TIME_SRC'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Last Ddl Time Src'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52647634988846787)
,p_db_column_name=>'STATUS_SRC'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Status Src'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52648011930846787)
,p_db_column_name=>'NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52648497411846787)
,p_db_column_name=>'TYPE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52648806330846787)
,p_db_column_name=>'REFERENCED_OWNER'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Referenced Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52649209636846787)
,p_db_column_name=>'REFERENCED_NAME'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Referenced Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52649647920846787)
,p_db_column_name=>'REFERENCED_TYPE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Referenced Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52650056158846787)
,p_db_column_name=>'REFERENCED_LINK_NAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Referenced Link Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52650442862846787)
,p_db_column_name=>'SCHEMAID'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Schemaid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52650878070846789)
,p_db_column_name=>'DEPENDENCY_TYPE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Dependency Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52651261891846789)
,p_db_column_name=>'OWNER_REF'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Owner Ref'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52651611593846789)
,p_db_column_name=>'OBJECT_NAME_REF'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Object Name Ref'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52652033412846789)
,p_db_column_name=>'OBJECT_TYPE_REF'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Object Type Ref'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52652463795846789)
,p_db_column_name=>'LAST_DDL_TIME_REF'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Last Ddl Time Ref'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(52652861653846789)
,p_db_column_name=>'STATUS_REF'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Status Ref'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(52653486356849065)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'526535'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'OWNER_SRC:OBJECT_NAME_SRC:OBJECT_TYPE_SRC:LAST_DDL_TIME_SRC:STATUS_SRC:NAME:TYPE:REFERENCED_OWNER:REFERENCED_NAME:REFERENCED_TYPE:REFERENCED_LINK_NAME:SCHEMAID:DEPENDENCY_TYPE:OWNER_REF:OBJECT_NAME_REF:OBJECT_TYPE_REF:LAST_DDL_TIME_REF:STATUS_REF'
,p_sort_column_1=>'REFERENCED_NAME'
,p_sort_direction_1=>'DESC'
,p_break_on=>'REFERENCED_NAME'
,p_break_enabled_on=>'REFERENCED_NAME'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52656687996009295)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_name=>'type_ref'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OBJECT_TYPE_REF'
,p_operator=>'='
,p_expr=>'VIEW'
,p_condition_sql=>' (case when ("OBJECT_TYPE_REF" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''VIEW''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52657090559009296)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_name=>'type_src'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OBJECT_TYPE_SRC'
,p_operator=>'='
,p_expr=>'VIEW'
,p_condition_sql=>' (case when ("OBJECT_TYPE_SRC" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''VIEW''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52657497503009296)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_name=>'invalid_referenced'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_REF'
,p_operator=>'='
,p_expr=>'INVALID'
,p_condition_sql=>' (case when ("STATUS_REF" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''INVALID''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52657893412009298)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_name=>'invalid'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_SRC'
,p_operator=>'='
,p_expr=>'INVALID'
,p_condition_sql=>' (case when ("STATUS_SRC" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''INVALID''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52655890780009293)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OBJECT_TYPE_SRC'
,p_operator=>'='
,p_expr=>'VIEW'
,p_condition_sql=>'"OBJECT_TYPE_SRC" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''VIEW''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52656212590009293)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'OWNER_SRC'
,p_operator=>'='
,p_expr=>'COMPANY'
,p_condition_sql=>'"OWNER_SRC" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''COMPANY''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(52658269382009298)
,p_report_id=>wwv_flow_api.id(52653486356849065)
,p_name=>'Row text contains ''v_loc'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'v_loc'
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
