prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>'Tree Page'
,p_step_title=>'Tree Page'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160123050151'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3305506440656398)
,p_plug_name=>'Eltern'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from v_rep_elt'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3305600387656398)
,p_name=>'Eltern'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>3305600387656398
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3305832199656402)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'ID'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3305917270656403)
,p_db_column_name=>'ELTERN'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Eltern'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'ELTERN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3306030209656403)
,p_db_column_name=>'KIND'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Kind'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'KIND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3306122914656403)
,p_db_column_name=>'PARENT_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Parent Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PARENT_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3306211051656403)
,p_db_column_name=>'PARENT_VORNAME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Parent Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PARENT_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3306310415656403)
,p_db_column_name=>'CHILD_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Child Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'CHILD_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3306414402656403)
,p_db_column_name=>'CHILD_VORNAME'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Child Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'CHILD_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3307621460722557)
,p_db_column_name=>'PAR_LB_NAME'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Par Lb Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PAR_LB_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3307704660722558)
,p_db_column_name=>'PAR_LB_VORNAME'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Par Lb Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PAR_LB_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3307932249722558)
,p_db_column_name=>'CH_LB_VORNAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Ch Lb Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'CH_LB_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3308332286930290)
,p_db_column_name=>'CH_LB_NAME'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Ch Lb Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'CH_LB_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3308432385930291)
,p_db_column_name=>'PAR_GES_NAME'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Par Ges Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PAR_GES_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3308505045930291)
,p_db_column_name=>'PAR_GES_VORNAME'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Par Ges Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'PAR_GES_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3308622867930291)
,p_db_column_name=>'LB_CH_GES_NAME'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Lb Ch Ges Name'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LB_CH_GES_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3308716828930291)
,p_db_column_name=>'LB_CH_GES_VORNAME'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Lb Ch Ges Vorname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LB_CH_GES_VORNAME'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3306507133656565)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33066'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'ID:ELTERN:KIND:PARENT_NAME:PARENT_VORNAME:PAR_LB_NAME:PAR_LB_VORNAME:PAR_GES_NAME:PAR_GES_VORNAME:CHILD_NAME:CHILD_VORNAME:CH_LB_NAME:CH_LB_VORNAME:LB_CH_GES_NAME:LB_CH_GES_VORNAME:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3309325225992955)
,p_report_id=>wwv_flow_api.id(3306507133656565)
,p_name=>'Row text contains ''Anit'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Anit'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3304615488626835)
,p_button_sequence=>10
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3300019409618261)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'javascript:apex.widget.tree.collapse_all(''tree3304412115626834'');'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3304808871626836)
,p_button_sequence=>10
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3300019409618261)
,p_button_image_alt=>'Expand All'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'javascript:apex.widget.tree.expand_all(''tree3304412115626834'');'
);
wwv_flow_api.component_end;
end;
/
