prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>'Chart'
,p_step_title=>'Chart'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160109162632'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3310710000529985)
,p_plug_name=>'Chart'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3293720039618254)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_source_type=>'NATIVE_FLASH_CHART5'
);
wwv_flow_api.create_flash_chart5(
 p_id=>wwv_flow_api.id(3310903546529987)
,p_default_chart_type=>'ScatterMarker'
,p_chart_rendering=>'FLASH_PREFERRED'
,p_chart_name=>'chart_3310903546529987'
,p_chart_width=>700
,p_chart_height=>500
,p_chart_animation=>'N'
,p_display_attr=>':H:N:V:B:B:N::V:Y:Circle:::N:::Default:::S'
,p_dial_tick_attr=>':::::::::::'
,p_gantt_attr=>'Y:Rhomb:Rhomb:Full:Rhomb:Rhomb:Full:Rhomb:Rhomb:Full:30:15:5:Y:I:N:S:E::'
,p_pie_attr=>'Outside:::'
,p_map_attr=>'Orthographic:RegionBounds:REGION_NAME'
,p_margins=>':::'
, p_omit_label_interval=> null
,p_bgtype=>'Trans'
,p_color_scheme=>'6'
,p_x_axis_label_font=>'Tahoma:10:#000000'
,p_y_axis_label_font=>'Tahoma:10:#000000'
,p_async_update=>'N'
, p_names_font=> null
, p_names_rotation=> null
,p_values_font=>'Tahoma:10:#000000'
,p_hints_font=>'Tahoma:10:#000000'
,p_legend_font=>'Tahoma:10:#000000'
,p_grid_labels_font=>'Tahoma:10:#000000'
,p_chart_title_font=>'Tahoma:14:#000000'
,p_x_axis_title_font=>'Tahoma:14:#000000'
,p_y_axis_title_font=>'Tahoma:14:#000000'
,p_gauge_labels_font=>'Tahoma:10:#000000'
,p_use_chart_xml=>'Y'
,p_chart_xml=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<?xml version = "1.0" encoding="utf-8" standalone = "yes"?>',
'<anychart>',
'  <settings>',
'    <animation enabled="false"/>',
'    <no_data show_waiting_animation="False">',
'      <label>',
'        <text>#NO_DATA_MESSAGE#</text>',
'        <font family="Verdana" bold="yes" size="10"/>',
'      </label>',
'    </no_data>',
'  </settings>',
'  <margin left="0" top="0" right="0" bottom="0" />',
'  <charts>',
'    <chart plot_type="Scatter" name="chart_3310903546529987"> ',
'      <chart_settings>',
'        <title enabled="False" />',
'        <chart_background>',
'          <fill type="Solid" color="0xffffff" opacity="0" />',
'          <border enabled="false"/>',
'          <corners type="Square"/>',
'        </chart_background>',
'        <data_plot_background>',
'',
'        </data_plot_background>',
'        <axes>',
'          <y_axis >',
'            <scale   mode="Normal"    />',
'            <title enabled="false" />',
'            <labels enabled="true" position="Outside">',
'              <font family="Tahoma" size="10" color="0x000000" />',
'              <format><![CDATA[{%Value}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}]]></format>',
'            </labels>',
'            <major_grid enabled="True" interlaced="false">',
'                <line color="Black" />',
'              </major_grid>',
'<minor_grid enabled="True">',
'              </minor_grid>',
'            <zoom enabled="true" show_scroll_bar="true" />',
'          </y_axis>',
'          <x_axis>',
'            <scale  mode="Normal"    />',
'            <title enabled="false"/>',
'            <labels enabled="true" position="Outside">',
'              <font family="Tahoma" size="10" color="0x000000" />',
'              <format><![CDATA[{%Value}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}]]></format>',
'            </labels>',
'            <major_grid enabled="True" interlaced="false">',
'                <line color="Black" />',
'              </major_grid>',
'<minor_grid enabled="True">',
'              </minor_grid>',
'            <zoom enabled="true" show_scroll_bar="true" />',
'          </x_axis>',
'          ',
'        </axes>',
'',
'',
'      </chart_settings>',
'      <data_plot_settings enable_3d_mode="false" default_series_type="Marker">',
'        <marker_series>',
'          <marker_style marker_type="Circle">',
'            <marker />',
'            <effects>',
'              <drop_shadow enabled="true"/>',
'            </effects>',
'',
'          </marker_style>',
'          <tooltip_settings enabled="true">',
'            <format><![CDATA[{%Name}{enabled:False}: {%XValue}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}, {%YValue}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}]]></format>',
'            <font family="Tahoma" size="10" color="0x000000" />',
'              <position anchor="Float" valign="Top" padding="10" /> ',
'          </tooltip_settings>',
'          <label_settings enabled="true" mode="Outside" multi_line_align="Center">',
'            <format><![CDATA[{%Name}{enabled:False}: {%XValue}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}, {%YValue}{numDecimals:0,decimalSeparator:.,thousandsSeparator:\,}]]></format>',
'            <background enabled="false"/>',
'',
'            <font family="Tahoma" size="10" color="0x000000" />',
'          </label_settings>',
'        </marker_series>',
'      </data_plot_settings>',
'',
'#DATA#',
'    </chart>',
'  </charts>',
'</anychart>',
''))
);
wwv_flow_api.create_flash_chart5_series(
 p_id=>wwv_flow_api.id(3311028987529989)
,p_chart_id=>wwv_flow_api.id(3310903546529987)
,p_series_seq=>10
,p_series_name=>'Series 1'
,p_series_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'null,',
'null,',
'act_lev_id,',
'act_lev_sub_id',
'from tree_tab'))
,p_series_query_type=>'SQL_QUERY'
,p_series_query_parse_opt=>'PARSE_CHART_QUERY'
,p_series_query_no_data_found=>'no data found'
,p_series_query_row_count_max=>15
,p_show_action_link=>'N'
);
wwv_flow_api.component_end;
end;
/
