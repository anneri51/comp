prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>120
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>unistr('Personen\00FCbersicht')
,p_step_title=>unistr('Personen\00FCbersicht')
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'// Modal-Dialog initialisieren',
'function initDialog ( pRegId , pTitle , pWidth , pHeight ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( {',
'      autoOpen:   false,',
'      bgiframe:   true,',
'      modal:      false,',
'      minHeight:  pHeight,',
'      width:      pWidth,',
'      minWidth:   pWidth,',
'      title:      pTitle,',
'      resizable: true,',
'      closeOnEscape : true',
'  } )',
'}',
'',
unistr('// setzt die Breite des Dialogs auf (nahezu) genau die f\00FCr den Report ben\00F6tigte Breite'),
'function setzeDialogBreite ( pRegId ) {',
'  var $vRegion  = $( "#" + pRegId );',
'  var vMinWidth = $vRegion.dialog ( "option" , "minWidth" );',
'  var vWidth    = $vRegion.find ( "table[id^=''report_'']" ).width();',
'  //',
'  $vRegion.dialog ( "option" , "width" , Math.max ( vMinWidth , vWidth + 30 ) );',
'}',
'',
'',
'// zeigt die Reports-Region als jQuery-Dialog an',
'function showDialog ( pRegId ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( "open" );',
'  setzeDialogBreite ( pRegId );',
'',
'}',
'',
'',
'// jQuery-Dialog schliessen',
'function closeDialog (pRegId) {',
'  $("#" + pRegId).dialog("close");',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160205132238'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3339420980587729)
,p_plug_name=>unistr('\00DCbersicht Personen')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with wo as (select * from Person_Wohnort wo join ort on wo.fk_wohnort = ort.pk_ort)',
'SELECT ',
'	    p.PK_PERSON',
',	p.NAME',
',	p.VORNAME',
',	p.GESCHLECHT',
',	p.GEBOREN_AM',
',	p.GESTORBEN_AM',
',	p.BESCHREIBUNG',
',	p.GEBURTSNAME',
',	p.TITEL',
',	p.ADELSTITEL',
',	p.RUFNAME',
',	p.NR_AHNENTAFEL',
',   wo.ort wohnort',
',   wo.land wo_land',
',   go.ort  geburtsort',
',   go.land go_land',
',   so.ort sterbeort',
',   so.land so_land',
',   r.religion',
',   r.status Religion_status',
',   r.ausgetreten_am',
',   round((nvl(p.gestorben_am, sysdate) - p.geboren_am)/365,0) as alt',
',   bt.id',
',   bt.dateiname',
',   dbms_lob.getlength(bt.thumbnail) vorschau',
',   dbms_lob.getlength(bt.bild)      bildgroesse',
',   bt.breite_px',
',   bt.hoehe_px',
',   null as bild_aktion',
'FROM Person p',
' left join wo on p.pk_person = wo.fk_person',
' left join ort go on p.fk_geburtsort = go.pk_ort',
' left join ort so on p.fk_sterbeort = so.pk_ort',
' left join Person_Religion r on r.fk_person = p.PK_person',
' left join person_bild pb on pb.fk_person = p.pk_person',
' left join bilder_tab bt on bt.id = pb.fk_bild'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_header=>'<div style="Overflow:auto;width:97%;height:95%">'
,p_plug_footer=>'</div>'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3339621542587730)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>3339621542587730
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344111934626628)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:121:&SESSION.:::RP:P121_PK_PERSON:#PK_PERSON#'',2000,1000);'
,p_column_linktext=>'#NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344230101626628)
,p_db_column_name=>'VORNAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:121:&SESSION.:::RP:P121_PK_PERSON:#PK_PERSON#'',2000,1000);'
,p_column_linktext=>'#VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344302310626629)
,p_db_column_name=>'GESCHLECHT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Geschlecht'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344501460626629)
,p_db_column_name=>'GESTORBEN_AM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'gestorben am'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_static_id=>'GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344707773626629)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Beschreibung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344810251626629)
,p_db_column_name=>'GEBURTSNAME'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Geburtsname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3344918669626629)
,p_db_column_name=>'TITEL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Titel'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3345025401626629)
,p_db_column_name=>'ADELSTITEL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Adelstitel'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3345207100626630)
,p_db_column_name=>'RUFNAME'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Rufname'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3345303146626630)
,p_db_column_name=>'NR_AHNENTAFEL'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Nr Ahnentafel'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349011356802705)
,p_db_column_name=>'WOHNORT'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Wohnort'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'WOHNORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349107487802705)
,p_db_column_name=>'WO_LAND'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Land<br>(Wohnort)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'WO_LAND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349220417802705)
,p_db_column_name=>'GEBURTSORT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Geburtsort'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349318672802705)
,p_db_column_name=>'GO_LAND'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Land<br>(Geburtsort)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'GO_LAND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349422029802705)
,p_db_column_name=>'STERBEORT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Sterbeort'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3349527013802705)
,p_db_column_name=>'SO_LAND'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Land<br>(Sterbeort)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'SO_LAND'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3381518935798200)
,p_db_column_name=>'RELIGION'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Religion'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'RELIGION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3381620939798201)
,p_db_column_name=>'RELIGION_STATUS'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Status<br>(Religion)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'RELIGION_STATUS'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3381729024798201)
,p_db_column_name=>'AUSGETRETEN_AM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'ausgetreten am'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'AUSGETRETEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3417020536506755)
,p_db_column_name=>'ALT'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Alter'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'ALT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3474813382244007)
,p_db_column_name=>'PK_PERSON'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'ID'
,p_column_link=>'javascript:popUp2(''f?p=&APP_ID.:121:&SESSION.:::RP:P121_PK_PERSON:#PK_PERSON#'',2000,1000);'
,p_column_linktext=>'#PK_PERSON#'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_PERSON'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5900396053570866)
,p_db_column_name=>'ID'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5901065065570872)
,p_db_column_name=>'DATEINAME'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Dateiname'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5901742699570873)
,p_db_column_name=>'VORSCHAU'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Vorschau'
,p_sync_form_label=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:BILDER_TAB:THUMBNAIL:ID:::DATEINAME:::Inline:Download:'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5902460777570876)
,p_db_column_name=>'BILDGROESSE'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Bildgroesse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5903168822570877)
,p_db_column_name=>'BREITE_PX'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Breite Px'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5903807533570878)
,p_db_column_name=>'HOEHE_PX'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Hoehe Px'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5904536000570879)
,p_db_column_name=>'BILD_AKTION'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Bild Aktion'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7579471679597968)
,p_db_column_name=>'GEBOREN_AM'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Geboren am'
,p_column_type=>'DATE'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3339907673587730)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33400'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'PK_PERSON:NR_AHNENTAFEL:TITEL:NAME:VORNAME:VORSCHAU:GESCHLECHT:GEBOREN_AM:GESTORBEN_AM:ALT:GEBURTSNAME:RUFNAME:GEBURTSORT:GO_LAND:STERBEORT:SO_LAND:WOHNORT:WO_LAND:BESCHREIBUNG:RELIGION:RELIGION_STATUS:AUSGETRETEN_AM:ADELSTITEL:ID:DATEINAME:BILDGROES'
||'SE:BREITE_PX:HOEHE_PX:BILD_AKTION:'
,p_break_on=>'NAME:VORNAME'
,p_break_enabled_on=>'NAME:VORNAME'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3464211847504095)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(3339420980587729)
,p_button_name=>'STAMMBAUM'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3300019409618261)
,p_button_image_alt=>'Stammbaum'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:popUp2(''f?p=&APP_ID.:122:&SESSION.:::RP:'',1300,1300);'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6570955474253308)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(3339420980587729)
,p_button_name=>unistr('Datenpr\00FCfung')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3300019409618261)
,p_button_image_alt=>unistr('Datenpr\00FCfung')
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6900141486766349)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(3339420980587729)
,p_button_name=>'NEW_PERSON'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3300019409618261)
,p_button_image_alt=>'Neue Person'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:popUp2(''f?p=&APP_ID.:121:&SESSION.::NO:RP:P121_PK_PERSON:'',1300,650);'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(3342818462587732)
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3342111524587731)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_FOR_PAGES'
,p_attribute_04=>'171'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(3340505899587730)
);
wwv_flow_api.component_end;
end;
/
