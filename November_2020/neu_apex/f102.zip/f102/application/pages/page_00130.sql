prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_page(
 p_id=>130
,p_user_interface_id=>wwv_flow_api.id(3301718287618268)
,p_tab_set=>'TS1'
,p_name=>unistr('Eltern-Kind \00DCbersicht')
,p_step_title=>unistr('Lebenspartner\00FCbersicht')
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'// Modal-Dialog initialisieren',
'function initDialog ( pRegId , pTitle , pWidth , pHeight ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( {',
'      autoOpen:   false,',
'      bgiframe:   true,',
'      modal:      false,',
'      minHeight:  pHeight,',
'      width:      pWidth,',
'      minWidth:   pWidth,',
'      title:      pTitle,',
'      resizable: true,',
'      closeOnEscape : true',
'  } )',
'}',
'',
unistr('// setzt die Breite des Dialogs auf (nahezu) genau die f\00FCr den Report ben\00F6tigte Breite'),
'function setzeDialogBreite ( pRegId ) {',
'  var $vRegion  = $( "#" + pRegId );',
'  var vMinWidth = $vRegion.dialog ( "option" , "minWidth" );',
'  var vWidth    = $vRegion.find ( "table[id^=''report_'']" ).width();',
'  //',
'  $vRegion.dialog ( "option" , "width" , Math.max ( vMinWidth , vWidth + 30 ) );',
'}',
'',
'',
'// zeigt die Reports-Region als jQuery-Dialog an',
'function showDialog ( pRegId ) {',
'  var vRegId = "#" + pRegId;',
'  $( vRegId ).dialog( "open" );',
'  setzeDialogBreite ( pRegId );',
'',
'}',
'',
'',
'// jQuery-Dialog schliessen',
'function closeDialog (pRegId) {',
'  $("#" + pRegId).dialog("close");',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20160125143126'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3350726297867886)
,p_plug_name=>unistr('\00DCbersicht Eltern-Kind')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3294401841618255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bld as ( select pb.fk_person,  id, ',
'  dateiname, ',
'  dbms_lob.getlength(thumbnail) vorschau, ',
'  dbms_lob.getlength(bild)      bildgroesse, ',
'  breite_px, ',
'  hoehe_px,',
'  null as bild_aktion',
'              from Person_bild pb ',
' left join bilder_tab bt on bt.id = pb.fk_bild',
'',
')',
'SELECT ',
'lp.pk_eltern',
', 	lp1.pk_person		LP1_PK_person',
',	lp1.NAME		LP1_NAME',
',	lp1.VORNAME		LP1_VORNAME',
',	lp1.GESCHLECHT		LP1_GESCHLECHT',
',	lp1.GEBURTSDATUM		LP1_GEBURTSDATUM',
',	lp1.GESTORBEN_AM		LP1_GESTORBEN_AM',
',	lp1.fk_GEBURTSORT		LP1_GEBURTSORT',
',	lp1.BESCHREIBUNG		LP1_BESCHREIBUNG',
',	lp1.GEBURTSNAME		LP1_GEBURTSNAME',
',	lp1.TITEL		LP1_TITEL',
',	lp1.ADELSTITEL		LP1_ADELSTITEL',
',	lp1.fk_STERBEORT		LP1_STERBEORT',
',	lp1.RUFNAME		LP1_RUFNAME',
',	lp1.NR_AHNENTAFEL		LP1_NR_AHNENTAFEL',
',	lp2.pk_person		LP2_pk_person',
',	lp2.NAME		LP2_NAME',
',	lp2.VORNAME		LP2_VORNAME',
',	lp2.GESCHLECHT		LP2_GESCHLECHT',
',	lp2.GEBURTSDATUM		LP2_GEBURTSDATUM',
',	lp2.GESTORBEN_AM		LP2_GESTORBEN_AM',
',	lp2.fk_GEBURTSORT		LP2_GEBURTSORT',
',	lp2.BESCHREIBUNG		LP2_BESCHREIBUNG',
',	lp2.GEBURTSNAME		LP2_GEBURTSNAME',
',	lp2.TITEL		LP2_TITEL',
',	lp2.ADELSTITEL		LP2_ADELSTITEL',
',	lp2.fk_STERBEORT		LP2_STERBEORT',
',	lp2.RUFNAME		LP2_RUFNAME',
',	lp2.NR_AHNENTAFEL		LP2_NR_AHNENTAFEL',
'--,   bld_lp1.vorschau lp1_vorschau',
'--,   bld_lp2.vorschau lp2_vorschau',
'',
'FROM eltern lp',
' join person lp1 on lp1.pk_person = lp.fk_eltern',
' join person lp2 on lp2.pk_person = lp.fk_kind',
' left join bld bld_lp1 on bld_lp1.fk_person = lp.fk_eltern',
' left join bld bld_lp2 on bld_lp2.fk_person = lp.fk_kind',
' '))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3350910117867886)
,p_name=>'Orte'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'ANNE'
,p_internal_uid=>3350910117867886
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356203362901066)
,p_db_column_name=>'LP1_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Name<br>(Eltern)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP1_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356319024901066)
,p_db_column_name=>'LP1_VORNAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Vorname<br>(Eltern)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP1_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356427968901066)
,p_db_column_name=>'LP1_GESCHLECHT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Geschlecht<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356512053901066)
,p_db_column_name=>'LP1_GEBURTSDATUM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Geburtsdatum<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356615384901066)
,p_db_column_name=>'LP1_GESTORBEN_AM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Gestorben Am<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356724303901067)
,p_db_column_name=>'LP1_GEBURTSORT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Geburtsort<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356824561901067)
,p_db_column_name=>'LP1_BESCHREIBUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beschreibung<br>(Eltern)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3356903417901067)
,p_db_column_name=>'LP1_GEBURTSNAME'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Geburtsname<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357002810901067)
,p_db_column_name=>'LP1_TITEL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Titel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357129203901067)
,p_db_column_name=>'LP1_ADELSTITEL'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Adelstitel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357209338901067)
,p_db_column_name=>'LP1_STERBEORT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Sterbeort<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357303426901067)
,p_db_column_name=>'LP1_RUFNAME'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Rufname<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357422812901067)
,p_db_column_name=>'LP1_NR_AHNENTAFEL'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Nr Ahnentafel<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357629812901067)
,p_db_column_name=>'LP2_NAME'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Name<br>(Kind)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP2_NAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357721778901067)
,p_db_column_name=>'LP2_VORNAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Vorname<br>(Kind)'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#LP2_VORNAME#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_VORNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357815628901067)
,p_db_column_name=>'LP2_GESCHLECHT'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Geschlecht<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESCHLECHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3357928451901067)
,p_db_column_name=>'LP2_GEBURTSDATUM'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Geburtsdatum<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSDATUM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358010651901068)
,p_db_column_name=>'LP2_GESTORBEN_AM'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Gestorben Am<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GESTORBEN_AM'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358121167901068)
,p_db_column_name=>'LP2_GEBURTSORT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Geburtsort<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358214642901068)
,p_db_column_name=>'LP2_BESCHREIBUNG'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Beschreibung<br>(Kind)'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_BESCHREIBUNG'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358327364901068)
,p_db_column_name=>'LP2_GEBURTSNAME'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Geburtsname<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_GEBURTSNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358420871901068)
,p_db_column_name=>'LP2_TITEL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Titel<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_TITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358506859901068)
,p_db_column_name=>'LP2_ADELSTITEL'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Adelstitel<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_ADELSTITEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358605543901068)
,p_db_column_name=>'LP2_STERBEORT'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Sterbeort<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_STERBEORT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358706059901068)
,p_db_column_name=>'LP2_RUFNAME'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Rufname<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_RUFNAME'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3358831914901068)
,p_db_column_name=>'LP2_NR_AHNENTAFEL'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Nr Ahnentafel<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_NR_AHNENTAFEL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3485530036707272)
,p_db_column_name=>'PK_ELTERN'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'ID'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'PK_ELTERN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3485616775707272)
,p_db_column_name=>'LP1_PK_PERSON'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Person ID<br>(Eltern)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP1_PK_PERSON'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3485728745707272)
,p_db_column_name=>'LP2_PK_PERSON'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Person ID<br>(Kind)'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_static_id=>'LP2_PK_PERSON'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3352824562867889)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'33529'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5000
,p_report_columns=>'PK_ELTERN:LP1_PK_PERSON:LP2_PK_PERSON:LP2_NAME:LP2_VORNAME:LP2_GESCHLECHT:LP2_GEBURTSDATUM:LP2_GESTORBEN_AM:LP2_GEBURTSORT:LP2_BESCHREIBUNG:LP2_GEBURTSNAME:LP2_TITEL:LP2_ADELSTITEL:LP2_STERBEORT:LP2_RUFNAME:LP2_NR_AHNENTAFEL:LP1_NAME:LP1_VORNAME'
,p_break_on=>'LP1_PK_PERSON:LP1_NAME:LP1_VORNAME:0:0:0'
,p_break_enabled_on=>'LP1_PK_PERSON:LP1_NAME:LP1_VORNAME:0:0:0'
);
wwv_flow_api.component_end;
end;
/
