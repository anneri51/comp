prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 102
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5410341843604255
,p_default_application_id=>103
,p_default_id_offset=>3600376060937530
,p_default_owner=>'STAMMBAUM'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(3301631683618267)
,p_theme_id=>26
,p_theme_name=>'Productivity Applications'
,p_theme_internal_name=>'PRODUCTIVITY_APPLICATIONS'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'T'
,p_nav_bar_type=>'NAVBAR'
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(3291822858618250)
,p_error_template=>wwv_flow_api.id(3291310878618250)
,p_printer_friendly_template=>wwv_flow_api.id(3292309250618251)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(3290932639618247)
,p_default_button_template=>wwv_flow_api.id(3300019409618261)
,p_default_region_template=>wwv_flow_api.id(3295300200618255)
,p_default_chart_template=>wwv_flow_api.id(3293720039618254)
,p_default_form_template=>wwv_flow_api.id(3294016162618254)
,p_default_reportr_template=>wwv_flow_api.id(3295300200618255)
,p_default_tabform_template=>wwv_flow_api.id(3295300200618255)
,p_default_wizard_template=>wwv_flow_api.id(3296126787618255)
,p_default_menur_template=>wwv_flow_api.id(3293305939618254)
,p_default_listr_template=>wwv_flow_api.id(3293626302618254)
,p_default_irr_template=>wwv_flow_api.id(3294401841618255)
,p_default_report_template=>wwv_flow_api.id(3297014296618256)
,p_default_label_template=>wwv_flow_api.id(3299619060618260)
,p_default_menu_template=>wwv_flow_api.id(3301027352618262)
,p_default_calendar_template=>wwv_flow_api.id(3301202778618263)
,p_default_list_template=>wwv_flow_api.id(3299125704618259)
,p_default_option_label=>wwv_flow_api.id(3299700013618260)
,p_default_required_label=>wwv_flow_api.id(3299915557618260)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(26),'')
,p_css_file_urls=>'#IMAGE_PREFIX#legacy_ui/css/5.0#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
