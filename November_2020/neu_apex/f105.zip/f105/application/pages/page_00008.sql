prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>19526726201355085
,p_default_application_id=>120
,p_default_id_offset=>3612186064963784
,p_default_owner=>'FLUGZEUGVERMIETUNG_DEV'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(41009372845394105)
,p_name=>'SEARCH_AIRPORTS'
,p_alias=>'SEARCH-AIRPORTS'
,p_step_title=>'SEARCH_AIRPORTS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200713141658'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(702903654077337)
,p_plug_name=>'SEARCH_AIRPORTS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(40975303974394083)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select IATA,',
'       ICAO,',
'       FLUGHAFEN,',
'       ORT,',
'       REGION,',
'       LAND,',
'       PK_FLI_AIR_AIRPORTS,',
'       FK_ADR_ORT,',
'       FK_LOC_LOCATION,',
'       FK_STD_FLI_AIR_AIRPORT_TYPE,',
'       CREATED_ON,',
'       LETTERS,',
'       substr(iata,1,2) letters_2',
'  from T_FLI_AIR_AIRPORTS'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'SEARCH_AIRPORTS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(702957572077337)
,p_name=>'SEARCH_AIRPORTS'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::P9_PK_FLI_AIR_AIRPORTS:#PK_FLI_AIR_AIRPORTS#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>4315143637041121
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(703336505077344)
,p_db_column_name=>'IATA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Iata'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(703806288077349)
,p_db_column_name=>'ICAO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Icao'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(704207692077349)
,p_db_column_name=>'FLUGHAFEN'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Flughafen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(704576455077349)
,p_db_column_name=>'ORT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(704976197077350)
,p_db_column_name=>'REGION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Region'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(705413411077350)
,p_db_column_name=>'LAND'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(705731808077350)
,p_db_column_name=>'PK_FLI_AIR_AIRPORTS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Pk Fli Air Airports'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(706177970077350)
,p_db_column_name=>'FK_ADR_ORT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Adr Ort'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(706567081077350)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690339163747225)
,p_db_column_name=>'FK_STD_FLI_AIR_AIRPORT_TYPE'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Fk Std Fli Air Airport Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690455038747226)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(690595009747227)
,p_db_column_name=>'LETTERS'
,p_display_order=>39
,p_column_identifier=>'L'
,p_column_label=>'Letters'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(693940338747261)
,p_db_column_name=>'LETTERS_2'
,p_display_order=>49
,p_column_identifier=>'M'
,p_column_label=>'Letters 2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(707124159078626)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'43194'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IATA:ICAO:FLUGHAFEN:ORT:REGION:LAND:PK_FLI_AIR_AIRPORTS:FK_ADR_ORT:FK_LOC_LOCATION:FK_STD_FLI_AIR_AIRPORT_TYPE:CREATED_ON:LETTERS:LETTERS_2'
);
wwv_flow_api.component_end;
end;
/
