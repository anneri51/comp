prompt --application/pages/page_00155
begin
--   Manifest
--     PAGE: 00155
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>155
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Tankstelle'
,p_step_title=>'Tankstelle'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42885805042427536)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200620043605'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3544142033001414)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tank."TANKSTELLE",',
'tank."ORT" tank_ort,',
'tank."LAND" tank_land,',
'tank."TANKSTELLEN_NR",',
'tank."BELEG_NR",',
'tank."DATUM",',
'tank."ZAPFSAEULE",',
'tank."LITER",',
'tank."PREIS_PRO_LITER",',
'case when tank."EUR" is not null then to_number(trim(tank."EUR")) else 0 end  "EUR",',
'tank."KARTENZAHLUNG",',
'tank."MWST",',
'tank."MWST_BETRAG",',
'tank."NETTO",',
'tank."STEUERNR",',
'tank."BEMERKUNGEN",',
'tank."VERWENDUNGSZWECK",',
'tank."KENNZEICHEN",',
'tank."BEMERKUNGEN2",',
'tank.PK_IMP_BA_Tankstelle,',
'tank.fk_kto_buchung,',
'tank.fk_bas_kal_arbeitstag,',
'tank.preis_pro_menge,',
'tank.waehrung,',
'tank.fk_imp_ba_bel,',
'apex_item.checkbox(1,tank.pk_imp_ba_tankstelle) sel,',
'tank.checked,',
'tank.wert,',
'arb.jahr,',
'arb.monat,',
'arb.tag,',
'loc.*,',
'fk_bel_beleg_ablage',
'from "IMP_BA_TANKSTELLE" tank',
' left join t_bas_kal_arbeitstage arb on tank.fk_bas_kal_arbeitstag = arb.pk_bas_kal_arbeitstage',
' left join v_loc_location loc on loc.pk_loc_location = tank.fk_loc_location',
'',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3544562465001415)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:156:&SESSION.::&DEBUG.::P156_PK_IMP_BA_TANKSTELLE:#PK_IMP_BA_TANKSTELLE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12854697705422336
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3544997321001417)
,p_db_column_name=>'TANKSTELLE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Tankstelle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3545436043001418)
,p_db_column_name=>'ORT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3545830398001419)
,p_db_column_name=>'LAND'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Land'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3546166795001420)
,p_db_column_name=>'TANKSTELLEN_NR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Tankstellen Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3546574395001420)
,p_db_column_name=>'BELEG_NR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Beleg Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3547028117001421)
,p_db_column_name=>'DATUM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3547853954001423)
,p_db_column_name=>'LITER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Liter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3548212155001423)
,p_db_column_name=>'PREIS_PRO_LITER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Preis Pro Liter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3548988124001425)
,p_db_column_name=>'KARTENZAHLUNG'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Kartenzahlung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3549421923001426)
,p_db_column_name=>'MWST'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3549797280001426)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3550249573001427)
,p_db_column_name=>'NETTO'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3550610720001428)
,p_db_column_name=>'STEUERNR'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Steuernr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3550997921001429)
,p_db_column_name=>'BEMERKUNGEN'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3551366828001429)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3551852282001430)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3552175421001431)
,p_db_column_name=>'BEMERKUNGEN2'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Bemerkungen2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4372804679623581)
,p_db_column_name=>'PK_IMP_BA_TANKSTELLE'
,p_display_order=>30
,p_column_identifier=>'U'
,p_column_label=>'Pk imp ba tankstelle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4373095374623584)
,p_db_column_name=>'PREIS_PRO_MENGE'
,p_display_order=>60
,p_column_identifier=>'X'
,p_column_label=>'Preis pro menge'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4373363303623586)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'Fk imp ba bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4374668261623600)
,p_db_column_name=>'SEL'
,p_display_order=>90
,p_column_identifier=>'AA'
,p_column_label=>'Sel  <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4374986321623603)
,p_db_column_name=>'CHECKED'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'Checked'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4375560332623608)
,p_db_column_name=>'EUR'
,p_display_order=>110
,p_column_identifier=>'AE'
,p_column_label=>'Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4375584428623609)
,p_db_column_name=>'WERT'
,p_display_order=>120
,p_column_identifier=>'AF'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5931732896874581)
,p_db_column_name=>'JAHR'
,p_display_order=>130
,p_column_identifier=>'AG'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5931820030874582)
,p_db_column_name=>'MONAT'
,p_display_order=>140
,p_column_identifier=>'AH'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5931908054874583)
,p_db_column_name=>'TAG'
,p_display_order=>150
,p_column_identifier=>'AI'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7943412245463115)
,p_db_column_name=>'TANK_ORT'
,p_display_order=>160
,p_column_identifier=>'AJ'
,p_column_label=>'Tank ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7943539335463116)
,p_db_column_name=>'TANK_LAND'
,p_display_order=>170
,p_column_identifier=>'AK'
,p_column_label=>'Tank land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7943739076463118)
,p_db_column_name=>'LOCATION'
,p_display_order=>190
,p_column_identifier=>'AM'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7943974299463121)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>220
,p_column_identifier=>'AP'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944065426463122)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>230
,p_column_identifier=>'AQ'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944202638463123)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>240
,p_column_identifier=>'AR'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944339282463124)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>250
,p_column_identifier=>'AS'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944462989463125)
,p_db_column_name=>'LOCATION_TYPE'
,p_display_order=>260
,p_column_identifier=>'AT'
,p_column_label=>'Location type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944466031463126)
,p_db_column_name=>'STRASSE'
,p_display_order=>270
,p_column_identifier=>'AU'
,p_column_label=>'Strasse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944611112463127)
,p_db_column_name=>'HSNR'
,p_display_order=>280
,p_column_identifier=>'AV'
,p_column_label=>'Hsnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944686276463128)
,p_db_column_name=>'BESCHREIBUNG'
,p_display_order=>290
,p_column_identifier=>'AW'
,p_column_label=>'Beschreibung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7944861960463129)
,p_db_column_name=>'COMM'
,p_display_order=>300
,p_column_identifier=>'AX'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8119271166920680)
,p_db_column_name=>'POSTFACH'
,p_display_order=>310
,p_column_identifier=>'AY'
,p_column_label=>'Postfach'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8119381997920681)
,p_db_column_name=>'PLZ'
,p_display_order=>320
,p_column_identifier=>'AZ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11597257191016512)
,p_db_column_name=>'ADR'
,p_display_order=>330
,p_column_identifier=>'BA'
,p_column_label=>'Adr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638040652195662)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>340
,p_column_identifier=>'BC'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638106624195663)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>350
,p_column_identifier=>'BD'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638267529195664)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>360
,p_column_identifier=>'BE'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638338368195665)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>370
,p_column_identifier=>'BF'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638390349195666)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>380
,p_column_identifier=>'BG'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638575476195667)
,p_db_column_name=>'FK_BAS_LOC_LOCATION_TYPE'
,p_display_order=>390
,p_column_identifier=>'BH'
,p_column_label=>'Fk Bas Loc Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638595662195668)
,p_db_column_name=>'FK_ADR_ADRESSE'
,p_display_order=>400
,p_column_identifier=>'BI'
,p_column_label=>'Fk Adr Adresse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638725919195669)
,p_db_column_name=>'PK_ADR_LAND'
,p_display_order=>410
,p_column_identifier=>'BJ'
,p_column_label=>'Pk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638871831195670)
,p_db_column_name=>'PK_ADR_ORT'
,p_display_order=>420
,p_column_identifier=>'BK'
,p_column_label=>'Pk Adr Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49638895342195671)
,p_db_column_name=>'PK_ADR_PLZ_ORT'
,p_display_order=>430
,p_column_identifier=>'BL'
,p_column_label=>'Pk Adr Plz Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49639006655195672)
,p_db_column_name=>'PK_BAS_LOCATION_TYPE'
,p_display_order=>440
,p_column_identifier=>'BM'
,p_column_label=>'Pk Bas Location Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49639171160195673)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>450
,p_column_identifier=>'BN'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3553162617001888)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'128633'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL::CHECKED:WERT'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR:ZAPFSAEULE:FK_KTO_BUCHUNG:FK_BAS_KAL_ARBEITSTAG:WAEHRUNG:PK_LOC_LOCATION:FK_BAS_LOC_'
||'LOCATION_TYPE:FK_ADR_ADRESSE:PK_ADR_LAND:PK_ADR_ORT:PK_ADR_PLZ_ORT:PK_BAS_LOCATION_TYPE:FK_BEL_BELEG_ABLAGE'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE'
,p_break_enabled_on=>'TANKSTELLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4502508462768108)
,p_report_id=>wwv_flow_api.id(3553162617001888)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4502897246768109)
,p_report_id=>wwv_flow_api.id(3553162617001888)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("EUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4503274655768109)
,p_report_id=>wwv_flow_api.id(3553162617001888)
,p_name=>'Row text contains ''shell'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'shell'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4503665769772201)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'datum'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'138139'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5949546196047629)
,p_report_id=>wwv_flow_api.id(4503665769772201)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5949868977047630)
,p_report_id=>wwv_flow_api.id(4503665769772201)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5948685989047625)
,p_report_id=>wwv_flow_api.id(4503665769772201)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5949143532047627)
,p_report_id=>wwv_flow_api.id(4503665769772201)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(5950307975047643)
,p_report_id=>wwv_flow_api.id(4503665769772201)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'KARTENZAHLUNG'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(5950676521047644)
,p_pivot_id=>wwv_flow_api.id(5950307975047643)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'WERT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4504716193775634)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'tankstelle'
,p_report_seq=>10
,p_report_alias=>'138149'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE'
,p_break_enabled_on=>'TANKSTELLE'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4547723105173086)
,p_report_id=>wwv_flow_api.id(4504716193775634)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4548123309173088)
,p_report_id=>wwv_flow_api.id(4504716193775634)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4548545508173089)
,p_report_id=>wwv_flow_api.id(4504716193775634)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4515709765878815)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'tankstelle_checked'
,p_report_seq=>10
,p_report_alias=>'138259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:WERT:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'CHECKED:0:0:0:0'
,p_break_enabled_on=>'CHECKED:0:0:0:0'
,p_sum_columns_on_break=>'WERT'
,p_count_columns_on_break=>'TANKSTELLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4551270252274917)
,p_report_id=>wwv_flow_api.id(4515709765878815)
,p_name=>'checked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4551683252274918)
,p_report_id=>wwv_flow_api.id(4515709765878815)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4552152044274918)
,p_report_id=>wwv_flow_api.id(4515709765878815)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4550885423274917)
,p_report_id=>wwv_flow_api.id(4515709765878815)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"CHECKED" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5951340037111005)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'pivot'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'152615'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||':JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5952495899111009)
,p_report_id=>wwv_flow_api.id(5951340037111005)
,p_name=>'zugeordn'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5952865389111009)
,p_report_id=>wwv_flow_api.id(5951340037111005)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5951728748111008)
,p_report_id=>wwv_flow_api.id(5951340037111005)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5952152859111008)
,p_report_id=>wwv_flow_api.id(5951340037111005)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(5953267799111010)
,p_report_id=>wwv_flow_api.id(5951340037111005)
,p_pivot_columns=>'JAHR'
,p_row_columns=>unistr('KARTENZAHLUNG:W\00C4HRUNG')
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(5953747639111011)
,p_pivot_id=>wwv_flow_api.id(5953267799111010)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'WERT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5956078908201404)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'erledigt'
,p_report_seq=>10
,p_report_alias=>'152663'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE:JAHR:PK_LOCATION'
,p_break_enabled_on=>'PK_LOCATION'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8165988329158063)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8166456669158063)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8166852620158064)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8167222720158064)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8164783934158061)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8165257854158062)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8165662008158063)
,p_report_id=>wwv_flow_api.id(5956078908201404)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'LOCATION'
,p_operator=>'='
,p_expr=>'Tankstelle - Schwarzenberg Q1'
,p_condition_sql=>'"LOCATION" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Tankstelle - Schwarzenberg Q1''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8167636343162197)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Location'
,p_report_seq=>10
,p_report_alias=>'174778'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:WERT:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:FK_ARBEITSPREIS_PRO_MENGE:FK_IMP_BA_BEL:CHECKED:'
||'JAHR:MONAT:TAG:TANK_ORT:TANK_LAND:LOCATION:FK_FK_ADRESSE:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:LOCATION_TYPE:STRASSE:HSNR:BESCHREIBUNG:COMM:POSTFACH:PLZ:ADR'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE:JAHR:PK_LOCATION:LOCATION'
,p_break_enabled_on=>'PK_LOCATION:LOCATION'
,p_sum_columns_on_break=>'WERT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8176413348182731)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_name=>'ckecked'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHECKED'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHECKED" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8176800806182731)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8177253755182731)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_name=>'zugeord'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_BUCHUNG" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8177643110182732)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("WERT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#C4BCC4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8175188612182729)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_BUCHUNG'
,p_operator=>'is null'
,p_condition_sql=>'"FK_BUCHUNG" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8175587358182730)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KARTENZAHLUNG'
,p_operator=>'='
,p_expr=>'ja'
,p_condition_sql=>'"KARTENZAHLUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''ja''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8176017822182730)
,p_report_id=>wwv_flow_api.id(8167636343162197)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'PK_LOCATION'
,p_operator=>'is null'
,p_condition_sql=>'"PK_LOCATION" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4497496105665187)
,p_application_user=>'ANNE'
,p_name=>'datum'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:PREIS_PRO_MENGE:FK_IMP_BA_BEL'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
,p_break_enabled_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4497568934665188)
,p_report_id=>wwv_flow_api.id(4497496105665187)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("EUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4497888827669504)
,p_application_user=>'ANNE'
,p_name=>'datum1'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:PREIS_PRO_MENGE:FK_IMP_BA_BEL'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'DATUM'
,p_break_enabled_on=>'DATUM'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4497999203669504)
,p_report_id=>wwv_flow_api.id(4497888827669504)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("EUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(4498319084674845)
,p_application_user=>'ANNE'
,p_name=>'tankstelle'
,p_report_seq=>10
,p_display_rows=>100000
,p_report_columns=>'TANKSTELLE:ORT:LAND:TANKSTELLEN_NR:BELEG_NR:DATUM:LITER:PREIS_PRO_LITER:KARTENZAHLUNG:MWST:MWST_BETRAG:NETTO:STEUERNR:BEMERKUNGEN:VERWENDUNGSZWECK:KENNZEICHEN:BEMERKUNGEN2:PK_IMP_BA_TANKSTELLE:PREIS_PRO_MENGE:FK_IMP_BA_BEL'
,p_sort_column_1=>'TANKSTELLE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DATUM'
,p_sort_direction_2=>'ASC'
,p_break_on=>'TANKSTELLE'
,p_break_enabled_on=>'TANKSTELLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4498945917752835)
,p_report_id=>wwv_flow_api.id(4498319084674845)
,p_name=>'datum'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E3E0E3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(4499031293752835)
,p_report_id=>wwv_flow_api.id(4498319084674845)
,p_name=>'betrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'EUR'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("EUR" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CFCFCF'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8119636531920683)
,p_plug_name=>'Bearbeitung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8121959638920706)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8119636531920683)
,p_button_name=>'Open_Location'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Open location'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8119539753920682)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8119636531920683)
,p_button_name=>'ADD_Location'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Add location'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3552574168001431)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3544142033001414)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:156:&SESSION.::&DEBUG.:156'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4374793996623601)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(3544142033001414)
,p_button_name=>'checked'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Checked'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8119805758920685)
,p_name=>'P155_FK_LOCATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8119636531920683)
,p_prompt=>'Fk location'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'LOCATION || '' '' ||',
'LOCATION_TYPE  || '' '' ||',
'',
'STRASSE  || '' '' ||',
'HSNR  || '' '' ||',
'POSTFACH  || '' '' ||',
'PLZ  || '' '' ||',
'ORT  || '' '' ||',
'LAND  || '' '' ||',
'',
'',
'',
'BESCHREIBUNG  || '' '' ||',
'COMM',
'',
'',
'',
', pk_location',
'',
'from v_location'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4374896539623602)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'checked'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      update IMP_BA_TANKSTELLE set checked = 1 where pk_imp_ba_tankstelle = apex_application.g_f01(i);',
'      commit;',
'    ',
'    end if;',
'  ',
'  end loop;',
'end;',
'  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4374793996623601)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8119888183920686)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_Locaiton'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    if apex_application.g_f01(i) is not null then',
'      update IMP_BA_TANKSTELLE set fk_location = :P155_FK_LOCATION where pk_imp_ba_tankstelle = apex_application.g_f01(i);',
'      commit;',
'    ',
'    end if;',
'  ',
'  end loop;',
'end;',
'  '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8119539753920682)
);
wwv_flow_api.component_end;
end;
/
