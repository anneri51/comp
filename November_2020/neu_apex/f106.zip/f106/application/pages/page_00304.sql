prompt --application/pages/page_00304
begin
--   Manifest
--     PAGE: 00304
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>304
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kontenblatt'
,p_step_title=>'Kontenblatt'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869730020324050)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200708135657'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10253486697752683)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8070464154546427)
,p_plug_name=>'Kontenblatt'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>45
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto.*,',
'   nvl(sollbetrag_eur,0)-nvl(habenbetrag_eur,0) diff1,',
'   replace(-bruttobetrag,'','',''%2C'') kasse_buchbetrag,',
'   replace(buchungstext,'',''''%2C'') kasse_buchtext, ',
'   rellex.bemerkung, ',
'   std_name storno, rellex.fk_lex_relation1, rellex.fk_lex_relation2, ',
'   rellex.pk_rel_lex_lex, ',
'   replace(habenbetrag_eur,'','',''%2C'') habeneur,',
'   replace(sollbetrag_eur,'','',''%2C'') solleur,',
'    case when gegenkto is null or gegenkto <>9000 then habenbetrag_eur else 0 end habenbetrag_eur2,',
'    case when gegenkto is null or gegenkto <> 9000 then sollbetrag_eur else 0 end sollbetrag_eur2,',
'    case when gegenkto = 9000 then nvl(habenbetrag_eur,0) else 0 end passiva,',
'    case when gegenkto = 9000 then nvl(sollbetrag_eur,0) else 0 end aktiva',
'  ',
'from (',
'select',
'       kto.BUCHUNGSNUMMER buchungsnr,',
'       KONTONUMMER,',
'       KONTOBEZEICHNUNG,',
'       BELEGDATUM,',
'       kto.BELEGNUMMER Belegnr,',
'       BUCHUNGSTEXT,',
'       GEGENKONTO Gegenkto,',
'       SOLLBETRAG_EUR,',
'       HABENBETRAG_EUR,',
'       USTKONTO,',
'       UST,',
'       kto.DATUM_OK,',
'       kto.OK,',
'       SOLLBETRAG_EUR1,',
'       kto.ID,',
'       BUCHUNGSSTATUS,',
'       lg,',
'       case when gegenkonto not in (''1401'',''1406'') and kontonummer   not in (''1401'',''1406'') and ust<>0  then round(abs(nvl(SOLLBETRAG_EUR,0))+abs(nvl(HABENBETRAG_EUR,0)) +(abs(nvl(SOLLBETRAG_EUR,0))+abs(nvl(HABENBETRAG_EUR,0))) *ust/100,2)',
'       else  round(abs(nvl(SOLLBETRAG_EUR,0))+abs(nvl(HABENBETRAG_EUR,0)) ,2)',
'       end Bruttobetrag,',
'       nvl(SOLLBETRAG_EUR,0)-nvl(HABENBETRAG_EUR,0) buchungsbetrag,',
'       kontenbezeichnung,',
'       relkto.kst,',
'       relkto.ktr,',
'       lb,',
'       kto.jahr,',
'       kto.kst kst_ktbl,',
'       kto.ktr ktr_ktbl,',
'       arb.tag arb_tag,',
'       arb.monat arb_monat,',
'       arb.jahr arb_jahr,',
'       apex_item.checkbox2(1,id) sel,',
'       sum_book.diff,',
'       kto.fk_proj_projekt,',
'       kto.fk_std_verw_verwendungszweck,',
'       kto.fk_kon_geschaeftspartner,',
'       kto.fK_bas_kat_kategorie,',
'       kto.fk_inv_inventar,',
'       kto.fk_loc_location,',
'       inv.inventar || '' '' || inv.anschaffungsjahr inv,',
'       kat.Kategorie,',
'       loc.location,',
'       kto.jahr || ''/'' || kto.buchungsnummer || ''/0'' fk_lex_relation,',
'    datum_steuer_ok,',
'    split_nr,',
'',
'    relkto.fk_lex_relation_main,',
'    split_nr_man,',
'    flg_split_buch',
'       ',
'  from t_lex_kontenblatt kto',
'       left join (',
'               select jahr, ',
'                   nr,',
'                   lex.kst, ',
'                   lex.ktr,',
'                   fk_lex_relation_main,',
'                   fk_lex_relation,',
'                   listagg(relkto.fk_main_key || '' '' || substr(zus."Buchungstag",1,10) || '' '' || zus."Betrag" || '' '' || zus.buchungstext || '' '' || wiederholung || '' '' || Kontotyp || '' '' || iban ,'','') within group (order by relkto.fk_main_key) lg',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_kto_konten_zus zus on relkto.fk_main_key = zus.fk_main_key',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   ',
'                    group by nr, fk_lex_relation, jahr,kst,ktr, fk_lex_relation_main',
'                 ) relkto on to_char(relkto.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0'' ',
'       left join (',
'                   select nr, jahr, fk_lex_relation,listagg(inp.pk_inp_belege_all || '' '' || brutto_betrag || '' '' || zahl_art_name || '' '' || bezeichnung || '' '' || case when fk_inv_inventar is not null then ''Inventar: '' || fk_inv_inventar end ,'','') wit'
||'hin group (order by inp.pk_inp_belege_all) lb',
'                   from (select * from t_rel_lex_kto_bel where fk_lex_relation <>''0'') relkto ',
'                       left join v_inp_belege_all inp on inp.pk_inp_belege_all = relkto.fk_inp_belege_all',
'                       join t_lex_long lex on lex.relation = relkto.fk_lex_relation',
'                   ',
'                    group by nr, fk_lex_relation, jahr',
'                 ) relbel on to_char(relbel.fk_lex_relation)= kto.jahr || ''/'' || to_char(kto.buchungsnummer) || ''/0'' ',
'        left join (select konto_nummer, kontenbezeichnung from  t_lex_kontenplan)  ktpl on  substr(''00000'' || ktpl.konto_nummer,length(''00000'' ||ktpl.konto_nummer)-4,5) =  substr(''00000''|| kto.kontonummer,length(''00000''|| kto.kontonummer)-4,5)',
'        left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = kto.fk_bas_kal_belegdatum',
'        left join (select buchungsnummer, belegnummer,jahr,  nvl(sum(nvl(sollbetrag_eur,0)) - sum(nvl(habenbetrag_eur,0)),0) diff from t_lex_kontenblatt group by buchungsnummer, belegnummer, jahr) sum_book on sum_book.jahr= kto.jahr and sum_book.bele'
||'gnummer = kto.belegnummer and sum_book.buchungsnummer = kto.buchungsnummer',
'        left join v_inv_inventare inv on inv.pk_inv_inventar = kto.fk_inv_inventar',
'        left join  t_bas_kat_konto_buch kat on kat.pk_bas_kat_konto_buch = kto.fK_bas_kat_kategorie',
'        left join (select * from  t_std where fk_std_group = 9 ) ver on ver.std_value = kto.fk_std_verw_verwendungszweck',
'        left join t_kon_geschaeftspartner ge on ge.pk_kon_geschaeftspartner  =kto.fk_kon_geschaeftspartner',
'        left join v_loc_location loc on loc.pk_loc_location = kto.fk_loc_location',
'',
'where kontonummer = :P304_KONTO_AUSWAHL or :P304_KONTO_AUSWAHL is null',
'    ) kto',
'        ',
'    left join (',
'                select  pk_rel_lex_lex, id, bemerkung, std_name, fk_lex_relation1, fk_lex_relation2',
'                    from t_rel_lex_lex lex ',
'                        join t_lex_kontenblatt kto1 on ( lex.fk_lex_relation1 = kto1.fk_lex_relation_sub or  lex.fk_lex_relation2 = kto1.fk_lex_relation_sub )',
'                        join (select * from t_std where fk_std_group = 281 and std_value = 2) std on std.std_value = lex.fk_rel_type_lex_lex',
'                        ) rellex on rellex.id = kto.id',
'                    ',
'                 ',
'                    '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8070492198546427)
,p_name=>'Kontenblatt'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.:RP:P305_ID:#ID##ROWID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>9510811473937967
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8071374098546466)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8071753284546466)
,p_db_column_name=>'KONTOBEZEICHNUNG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Kontobezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8072109995546466)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8072924993546467)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Buchungstext'
,p_column_link=>'f?p=&APP_ID.:345:&SESSION.::&DEBUG.:RP:P345_RELATION,P345_KONTONUMMER:#FK_RELATION#,#KONTONUMMER#'
,p_column_linktext=>'#BUCHUNGSTEXT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8074124574546469)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habenbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#HABENEUR#'
,p_column_linktext=>'#HABENBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8074559316546469)
,p_db_column_name=>'USTKONTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Ustkonto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8074944686546469)
,p_db_column_name=>'UST'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Ust'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004223574079596)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7004341583079597)
,p_db_column_name=>'OK'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8212586231291209)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>51
,p_column_identifier=>'O'
,p_column_label=>'Sollbetrag Eur'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#SOLLEUR#'
,p_column_linktext=>'#SOLLBETRAG_EUR#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8212773521291210)
,p_db_column_name=>'SOLLBETRAG_EUR1'
,p_display_order=>61
,p_column_identifier=>'P'
,p_column_label=>'Sollbetrag Eur1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8300290348210161)
,p_db_column_name=>'ID'
,p_display_order=>71
,p_column_identifier=>'Q'
,p_column_label=>'Id'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP:P308_FK_RELATION1,P308_FK_REL_TYPE_LEX_LEX:#FK_RELATION#,2'
,p_column_linktext=>'#ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8300453150210162)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>81
,p_column_identifier=>'R'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301280169210170)
,p_db_column_name=>'LG'
,p_display_order=>91
,p_column_identifier=>'S'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301720524210175)
,p_db_column_name=>'BRUTTOBETRAG'
,p_display_order=>101
,p_column_identifier=>'U'
,p_column_label=>'Bruttobetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301952345210177)
,p_db_column_name=>'KST'
,p_display_order=>121
,p_column_identifier=>'W'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301990637210178)
,p_db_column_name=>'KTR'
,p_display_order=>131
,p_column_identifier=>'X'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8302169123210179)
,p_db_column_name=>'LB'
,p_display_order=>141
,p_column_identifier=>'Y'
,p_column_label=>'Lb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8302270055210180)
,p_db_column_name=>'KONTENBEZEICHNUNG'
,p_display_order=>151
,p_column_identifier=>'Z'
,p_column_label=>'Kontenbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8303213671210190)
,p_db_column_name=>'BUCHUNGSNR'
,p_display_order=>161
,p_column_identifier=>'AA'
,p_column_label=>'Buchungsnr'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252:P252_BELEGNR,P252_BUCHUNGSNR,P252_JAHR:#BELEGNR#,#BUCHUNGSNR#,#JAHR#'
,p_column_linktext=>'#BUCHUNGSNR#'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8303310388210191)
,p_db_column_name=>'BELEGNR'
,p_display_order=>171
,p_column_identifier=>'AB'
,p_column_label=>'Belegnr'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#BELEGNR#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8303451255210192)
,p_db_column_name=>'GEGENKTO'
,p_display_order=>181
,p_column_identifier=>'AC'
,p_column_label=>'Gegenkto'
,p_column_link=>'f?p=&APP_ID.:315:&SESSION.::&DEBUG.:RP,315:P315_DATUM,P315_JAHR,P315_COMM,P315_BETRAG_UEB,P315_FK_RELATION_DISPLAY,P315_BUCHUNGSTEXT_UEB:#BELEGDATUM#,#ARB_JAHR#,#FK_RELATION#,#KASSE_BUCHBETRAG#,#FK_RELATION#,#KASSE_BUCHTEXT#'
,p_column_linktext=>'#GEGENKTO#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7973722317962278)
,p_db_column_name=>'JAHR'
,p_display_order=>191
,p_column_identifier=>'AD'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974270459962283)
,p_db_column_name=>'KST_KTBL'
,p_display_order=>201
,p_column_identifier=>'AE'
,p_column_label=>'Kst Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974365960962284)
,p_db_column_name=>'KTR_KTBL'
,p_display_order=>211
,p_column_identifier=>'AF'
,p_column_label=>'Ktr Ktbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974940902962290)
,p_db_column_name=>'ARB_TAG'
,p_display_order=>221
,p_column_identifier=>'AG'
,p_column_label=>'Arb Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7974981094962291)
,p_db_column_name=>'ARB_MONAT'
,p_display_order=>231
,p_column_identifier=>'AH'
,p_column_label=>'Arb Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7975098487962292)
,p_db_column_name=>'ARB_JAHR'
,p_display_order=>241
,p_column_identifier=>'AI'
,p_column_label=>'Arb Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7975341324962294)
,p_db_column_name=>'BUCHUNGSBETRAG'
,p_display_order=>251
,p_column_identifier=>'AJ'
,p_column_label=>'Buchungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7976682782962308)
,p_db_column_name=>'SEL'
,p_display_order=>261
,p_column_identifier=>'AK'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7976943917962310)
,p_db_column_name=>'DIFF'
,p_display_order=>271
,p_column_identifier=>'AL'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10255539755752703)
,p_db_column_name=>'INV'
,p_display_order=>341
,p_column_identifier=>'AS'
,p_column_label=>'Inv'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10255758615752705)
,p_db_column_name=>'LOCATION'
,p_display_order=>361
,p_column_identifier=>'AU'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11715999771412465)
,p_db_column_name=>'KASSE_BUCHBETRAG'
,p_display_order=>381
,p_column_identifier=>'AW'
,p_column_label=>'Kasse Buchbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11716119190412466)
,p_db_column_name=>'KASSE_BUCHTEXT'
,p_display_order=>391
,p_column_identifier=>'AX'
,p_column_label=>'Kasse Buchtext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12940193294056500)
,p_db_column_name=>'DATUM_STEUER_OK'
,p_display_order=>401
,p_column_identifier=>'AY'
,p_column_label=>'Datum Steuer Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12940454239056502)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>411
,p_column_identifier=>'AZ'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12941066557056508)
,p_db_column_name=>'SPLIT_NR_MAN'
,p_display_order=>431
,p_column_identifier=>'BB'
,p_column_label=>'Split Nr Man'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12941145273056509)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>441
,p_column_identifier=>'BC'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721246283796273)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>451
,p_column_identifier=>'BD'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14721334922796274)
,p_db_column_name=>'STORNO'
,p_display_order=>461
,p_column_identifier=>'BE'
,p_column_label=>'Storno'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14722778084796288)
,p_db_column_name=>'PK_REL_LEX_LEX'
,p_display_order=>491
,p_column_identifier=>'BH'
,p_column_label=>'Pk Rel Lex Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15219480896119283)
,p_db_column_name=>'HABENEUR'
,p_display_order=>501
,p_column_identifier=>'BI'
,p_column_label=>'Habeneur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15219638042119284)
,p_db_column_name=>'SOLLEUR'
,p_display_order=>511
,p_column_identifier=>'BJ'
,p_column_label=>'Solleur'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15417985338179472)
,p_db_column_name=>'DIFF1'
,p_display_order=>521
,p_column_identifier=>'BK'
,p_column_label=>'Diff1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15418480542179476)
,p_db_column_name=>'HABENBETRAG_EUR2'
,p_display_order=>531
,p_column_identifier=>'BL'
,p_column_label=>'Habenbetrag Eur2'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#HABENEUR#'
,p_column_linktext=>'#HABENBETRAG_EUR2#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15418563139179477)
,p_db_column_name=>'SOLLBETRAG_EUR2'
,p_display_order=>541
,p_column_identifier=>'BM'
,p_column_label=>'Sollbetrag Eur2'
,p_column_link=>'f?p=&APP_ID.:354:&SESSION.::&DEBUG.:RP:P354_X:#SOLLEUR#'
,p_column_linktext=>'#SOLLBETRAG_EUR2#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15418670726179478)
,p_db_column_name=>'PASSIVA'
,p_display_order=>551
,p_column_identifier=>'BN'
,p_column_label=>'Passiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15418763940179479)
,p_db_column_name=>'AKTIVA'
,p_display_order=>561
,p_column_identifier=>'BO'
,p_column_label=>'Aktiva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521269456195390)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>571
,p_column_identifier=>'BP'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521325468195391)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>581
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521408036195392)
,p_db_column_name=>'FK_KON_GESCHAEFTSPARTNER'
,p_display_order=>591
,p_column_identifier=>'BR'
,p_column_label=>'Fk Kon Geschaeftspartner'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521504500195393)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>601
,p_column_identifier=>'BS'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521600197195394)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>611
,p_column_identifier=>'BT'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521780068195395)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>621
,p_column_identifier=>'BU'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521833908195396)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>631
,p_column_identifier=>'BV'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53521899502195397)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>641
,p_column_identifier=>'BW'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522013167195398)
,p_db_column_name=>'FK_LEX_RELATION_MAIN'
,p_display_order=>651
,p_column_identifier=>'BX'
,p_column_label=>'Fk Lex Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522090819195399)
,p_db_column_name=>'FK_LEX_RELATION1'
,p_display_order=>661
,p_column_identifier=>'BY'
,p_column_label=>'Fk Lex Relation1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522245103195400)
,p_db_column_name=>'FK_LEX_RELATION2'
,p_display_order=>671
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Lex Relation2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8093877808593453)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'95342'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KONTONUMMER:KONTENBEZEICHNUNG:JAHR:SEL:BELEGDATUM:OK:BELEGNR:BUCHUNGSNR:GEGENKTO:BUCHUNGSTEXT:AKTIVA:PASSIVA:SOLLBETRAG_EUR2:HABENBETRAG_EUR2:BRUTTOBETRAG:DIFF1:USTKONTO:UST:DATUM_OK:ID:BUCHUNGSSTATUS:LG:KST:KTR:LB:KST_KTBL:KTR_KTBL:ARB_TAG:ARB_MONAT'
||':ARB_JAHR:BUCHUNGSBETRAG:DIFF:FK_FK_INVENTAR:LOCATION:INV:KONTOBEZEICHNUNG:SOLLBETRAG_EUR1:KASSE_BUCHBETRAG:KASSE_BUCHTEXT:DATUM_STEUER_OK:SPLIT_NR:SPLIT_NR_MAN:FLG_SPLIT_BUCH:BEMERKUNG:STORNO:PK_REL_LEX_LEX:HABENEUR:SOLLEUR::FK_PROJ_PROJEKT:FK_STD_V'
||'ERW_VERWENDUNGSZWECK:FK_KON_GESCHAEFTSPARTNER:FK_BAS_KAT_FK_INV_INVENTAR:FK_LOC_LOCATION:KATEGORIE:FK_LEX_RELATION:FK_LEX_RELATION_MAIN:FK_LEX_RELATION1:FK_LEX_RELATION2'
,p_sort_column_1=>'ARB_MONAT'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ARB_TAG'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'BELEGNR'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'GEGENKTO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'OK'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'BRUTTOBETRAG'
,p_sort_direction_6=>'ASC'
,p_break_on=>'KONTONUMMER:0:0:0:0:0:KONTENBEZEICHNUNG:JAHR:BELEGDATUM'
,p_break_enabled_on=>'KONTONUMMER:0:0:0:0:0:KONTENBEZEICHNUNG:JAHR'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR:HABENBETRAG_EUR:BUCHUNGSBETRAG:DIFF1:HABENBETRAG_EUR2:SOLLBETRAG_EUR2'
,p_count_columns_on_break=>'ID'
,p_count_distnt_col_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36805112307139005)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#43E643'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36804307738139005)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36804751731139005)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_name=>'DIFF'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36801925986139000)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2019'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36802322002139002)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_MONAT'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"ARB_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36802716706139002)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNR'
,p_operator=>'contains'
,p_expr=>'1443'
,p_condition_sql=>'upper("BUCHUNGSNR") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1443  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36803152072139002)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_STEUER_OK'
,p_operator=>'is not null'
,p_condition_sql=>'"DATUM_STEUER_OK" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36803518909139003)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_STEUER_OK'
,p_operator=>'is null'
,p_condition_sql=>'"DATUM_STEUER_OK" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36803916638139003)
,p_report_id=>wwv_flow_api.id(8093877808593453)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTONUMMER'
,p_operator=>'='
,p_expr=>'01710'
,p_condition_sql=>'"KONTONUMMER" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''01710''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(36805503689140560)
,p_application_user=>'ANNE'
,p_name=>'2020'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_display_rows=>100000
,p_report_columns=>'KONTONUMMER:KONTENBEZEICHNUNG:JAHR:SEL:BELEGDATUM:OK:BELEGNR:BUCHUNGSNR:GEGENKTO:BUCHUNGSTEXT:AKTIVA:PASSIVA:SOLLBETRAG_EUR2:HABENBETRAG_EUR2:BRUTTOBETRAG:DIFF1:USTKONTO:UST:DATUM_OK:ID:BUCHUNGSSTATUS:LG:KST:KTR:LB:KST_KTBL:KTR_KTBL:ARB_TAG:ARB_MONAT'
||':ARB_JAHR:BUCHUNGSBETRAG:DIFF:LOCATION:INV:KONTOBEZEICHNUNG:SOLLBETRAG_EUR1:KASSE_BUCHBETRAG:KASSE_BUCHTEXT:DATUM_STEUER_OK:SPLIT_NR:SPLIT_NR_MAN:FLG_SPLIT_BUCH:BEMERKUNG:STORNO:PK_REL_LEX_LEX:HABENEUR:SOLLEUR'
,p_sort_column_1=>'ARB_MONAT'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ARB_TAG'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'BELEGNR'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'GEGENKTO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'OK'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'BRUTTOBETRAG'
,p_sort_direction_6=>'ASC'
,p_break_on=>'KONTONUMMER:0:0:0:0:0:KONTENBEZEICHNUNG:JAHR:BELEGDATUM'
,p_break_enabled_on=>'KONTONUMMER:0:0:0:0:0:KONTENBEZEICHNUNG:JAHR'
,p_sum_columns_on_break=>'SOLLBETRAG_EUR:HABENBETRAG_EUR:BUCHUNGSBETRAG:DIFF1:HABENBETRAG_EUR2:SOLLBETRAG_EUR2'
,p_count_columns_on_break=>'ID'
,p_count_distnt_col_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905946607233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#43E643'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905745781233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_name=>'storniert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905856489233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_name=>'DIFF'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFF'
,p_operator=>'!='
,p_expr=>'0'
,p_condition_sql=>' (case when ("DIFF" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>20
,p_row_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905099910233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_JAHR'
,p_operator=>'='
,p_expr=>'2019'
,p_condition_sql=>'"ARB_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905234946233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ARB_MONAT'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"ARB_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905284979233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSNR'
,p_operator=>'contains'
,p_expr=>'1443'
,p_condition_sql=>'upper("BUCHUNGSNR") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1443  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905416292233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_STEUER_OK'
,p_operator=>'is not null'
,p_condition_sql=>'"DATUM_STEUER_OK" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905548725233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_STEUER_OK'
,p_operator=>'is null'
,p_condition_sql=>'"DATUM_STEUER_OK" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36905639568233735)
,p_report_id=>wwv_flow_api.id(36805503689140560)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTONUMMER'
,p_operator=>'='
,p_expr=>'01710'
,p_condition_sql=>'"KONTONUMMER" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''01710''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10252793019752676)
,p_plug_name=>'Zuordnung'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>15
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11715810199412463)
,p_plug_name=>'Buttons'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>25
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11715929080412464)
,p_plug_name=>'Kasse'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>35
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16745339554343597)
,p_plug_name=>'susa'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>65
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(2,susa.id) sel,',
' susa.* ,',
' stva.meldemonat,',
' stm.jahr st_m_jahr, ',
' stm.monat st_m_monat,',
' logl.comm,',
' susa.SUMME_WJ_SOLL- susa.SUMME_WJ_HABEN diff_lex,',
' susa.buch_betrag_vorperiode - susa.buch_betrag_akt_periode diff_buch,',
' ( susa.SUMME_WJ_SOLL- susa.SUMME_WJ_HABEN)+( susa.buch_betrag_vorperiode - susa.buch_betrag_akt_periode ) diff,',
' sum( susa.buch_betrag_vorperiode - susa.buch_betrag_akt_periode + nvl( case when eb_wert_relevant = 1 then eb_wert_soll - eb_wert_haben end,0) ) over (order by fk_imp_log_load) sum_lauf',
' ',
'from t_lex_susa susa',
'  left join t_steu_steuer_monat stm on susa.fk_steu_steuer_monat = stm.pk_steu_steuer_monat',
'  left join t_steu_steuer_voranmldg stva on stva.pk_steu_steuer_voranmldg = susa.fk_steu_steuer_voranmeldg',
'  left join t_imp_log_load logl on logl.pk_imp_log_load = susa.fk_imp_log_load',
'where susa.konto = :P304_konto_auswahl and susa.Jahr = :P304_jahr'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16746091755343605)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18186411030735145
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16746505771343609)
,p_db_column_name=>'JAHR'
,p_display_order=>40
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16845920955601004)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>490
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16846066339601005)
,p_db_column_name=>'OK'
,p_display_order=>500
,p_column_identifier=>'C'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16846346293601008)
,p_db_column_name=>'ID'
,p_display_order=>530
,p_column_identifier=>'D'
,p_column_label=>'Id'
,p_column_link=>'f?p=&APP_ID.:374:&SESSION.::&DEBUG.:RP:P374_ID:#ID#'
,p_column_linktext=>'#ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847113415600966)
,p_db_column_name=>'KONTO'
,p_display_order=>540
,p_column_identifier=>'E'
,p_column_label=>'Konto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847276607600967)
,p_db_column_name=>'NAME'
,p_display_order=>550
,p_column_identifier=>'F'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847339906600968)
,p_db_column_name=>'LETZTE_BUCHUNG'
,p_display_order=>560
,p_column_identifier=>'G'
,p_column_label=>'Letzte Buchung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847388822600969)
,p_db_column_name=>'EB_WERT_SOLL'
,p_display_order=>570
,p_column_identifier=>'H'
,p_column_label=>'Eb Wert Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847492317600970)
,p_db_column_name=>'EB_WERT_HABEN'
,p_display_order=>580
,p_column_identifier=>'I'
,p_column_label=>'Eb Wert Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847587490600971)
,p_db_column_name=>'SUMME_WJ_SOLL'
,p_display_order=>590
,p_column_identifier=>'J'
,p_column_label=>'Summe Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847753042600972)
,p_db_column_name=>'SUMME_WJ_HABEN'
,p_display_order=>600
,p_column_identifier=>'K'
,p_column_label=>'Summe Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847785429600973)
,p_db_column_name=>'SUMME_PER_WJ_SOLL'
,p_display_order=>610
,p_column_identifier=>'L'
,p_column_label=>'Summe Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16847935479600974)
,p_db_column_name=>'SUMME_PER_WJ_HABEN'
,p_display_order=>620
,p_column_identifier=>'M'
,p_column_label=>'Summe Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16848019652600975)
,p_db_column_name=>'SALDO_PER_WJ_SOLL'
,p_display_order=>630
,p_column_identifier=>'N'
,p_column_label=>'Saldo Per Wj Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16848115570600976)
,p_db_column_name=>'SALDO_PER_WJ_HABEN'
,p_display_order=>640
,p_column_identifier=>'O'
,p_column_label=>'Saldo Per Wj Haben'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16848264114600977)
,p_db_column_name=>'LOAD_DATE'
,p_display_order=>650
,p_column_identifier=>'P'
,p_column_label=>'Load Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18025600246728074)
,p_db_column_name=>'SEL'
,p_display_order=>660
,p_column_identifier=>'Q'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18028028543728098)
,p_db_column_name=>unistr('DATUM_STEUERB_\00DCBERG')
,p_display_order=>690
,p_column_identifier=>'T'
,p_column_label=>unistr('Datum Steuerb \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18028167831728099)
,p_db_column_name=>unistr('DATUM_FINANZAMT_\00DCBERG')
,p_display_order=>700
,p_column_identifier=>'U'
,p_column_label=>unistr('Datum Finanzamt \00DCberg')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18028685618728105)
,p_db_column_name=>'MELDEMONAT'
,p_display_order=>760
,p_column_identifier=>'AA'
,p_column_label=>'Meldemonat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18028787445728106)
,p_db_column_name=>'ST_M_JAHR'
,p_display_order=>770
,p_column_identifier=>'AB'
,p_column_label=>'St M Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18028975184728107)
,p_db_column_name=>'ST_M_MONAT'
,p_display_order=>780
,p_column_identifier=>'AC'
,p_column_label=>'St M Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18029228830728110)
,p_db_column_name=>'FK_IMP_LOG_LOAD'
,p_display_order=>790
,p_column_identifier=>'AD'
,p_column_label=>'Fk Imp Log Load'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(35711770979752871)
,p_db_column_name=>'COMM'
,p_display_order=>800
,p_column_identifier=>'AE'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786466695805686)
,p_db_column_name=>'CALC_DIFF_BETRAG'
,p_display_order=>810
,p_column_identifier=>'AF'
,p_column_label=>'Calc Diff Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786502070805687)
,p_db_column_name=>'BUCH_BETRAG_VORPERIODE'
,p_display_order=>820
,p_column_identifier=>'AG'
,p_column_label=>'Buch Betrag Vorperiode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786661989805688)
,p_db_column_name=>'BUCH_BETRAG_AKT_PERIODE'
,p_display_order=>830
,p_column_identifier=>'AH'
,p_column_label=>'Buch Betrag Akt Periode'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786710555805689)
,p_db_column_name=>'CALC_BUCH_BETRAG_DIFF'
,p_display_order=>840
,p_column_identifier=>'AI'
,p_column_label=>'Calc Buch Betrag Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786849035805690)
,p_db_column_name=>'DATUM_BUCH_BETRAG_OK'
,p_display_order=>850
,p_column_identifier=>'AJ'
,p_column_label=>'Datum Buch Betrag Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21786972548805691)
,p_db_column_name=>'DIFF'
,p_display_order=>860
,p_column_identifier=>'AK'
,p_column_label=>'Diff'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21787142835805693)
,p_db_column_name=>'EB_WERT_RELEVANT'
,p_display_order=>870
,p_column_identifier=>'AL'
,p_column_label=>'Eb Wert Relevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21787206324805694)
,p_db_column_name=>'DIFF_LEX'
,p_display_order=>880
,p_column_identifier=>'AM'
,p_column_label=>'Diff Lex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21787282863805695)
,p_db_column_name=>'DIFF_BUCH'
,p_display_order=>890
,p_column_identifier=>'AN'
,p_column_label=>'Diff Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21787470573805696)
,p_db_column_name=>'SUM_LAUF'
,p_display_order=>900
,p_column_identifier=>'AO'
,p_column_label=>'Sum Lauf'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522328307195401)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>910
,p_column_identifier=>'AP'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522471780195402)
,p_db_column_name=>'FK_STEU_STEUER_VORANMELDG'
,p_display_order=>920
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Steu Steuer Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522545675195403)
,p_db_column_name=>'FK_LEX_ABSCHLUSS_VORANMELDG'
,p_display_order=>930
,p_column_identifier=>'AR'
,p_column_label=>'Fk Lex Abschluss Voranmeldg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522667606195404)
,p_db_column_name=>'FK_STEU_JAHRES_ABSCHLUSSS'
,p_display_order=>940
,p_column_identifier=>'AS'
,p_column_label=>'Fk Steu Jahres Abschlusss'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522701835195405)
,p_db_column_name=>'FK_LEX_BUCH_CNT'
,p_display_order=>950
,p_column_identifier=>'AT'
,p_column_label=>'Fk Lex Buch Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522866691195406)
,p_db_column_name=>'KAS_KASSE_MONAT_CNT'
,p_display_order=>960
,p_column_identifier=>'AU'
,p_column_label=>'Kas Kasse Monat Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(53522908860195407)
,p_db_column_name=>'KAS_KASSE_JAHR_CNT'
,p_display_order=>970
,p_column_identifier=>'AV'
,p_column_label=>'Kas Kasse Jahr Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16858927763607608)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'182993'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:DATUM_OK:OK:ID:KONTO:NAME:LETZTE_BUCHUNG:EB_WERT_SOLL:EB_WERT_HABEN:SUMME_WJ_SOLL:SUMME_WJ_HABEN:SUMME_PER_WJ_SOLL:SUMME_PER_WJ_HABEN:SALDO_PER_WJ_SOLL:SALDO_PER_WJ_HABEN:LOAD_DATE:SEL:COMM:BUCH_BETRAG_VORPERIODE:BUCH_BETRAG_AKT_PERIODE:FK_IMP_L'
||unistr('OG_LOAD:DIFF_LEX:DIFF_BUCH:DIFF:DATUM_BUCH_BETRAG_OK:CALC_BUCH_BETRAG_DIFF:DATUM_STEUERB_\00DCBERG:DATUM_FINANZAMT_\00DCBERG:MELDEMONAT:ST_M_JAHR:ST_M_MONAT:CALC_DIFF_BETRAG:EB_WERT_RELEVANT:SUM_LAUF::FK_STEU_STEUER_MONAT:FK_STEU_STEUER_VORANMELDG:FK_LEX_ABS')
||'CHLUSS_VORANMELDG:FK_STEU_JAHRES_ABSCHLUSSS:FK_LEX_BUCH_CNT:KAS_KASSE_MONAT_CNT:KAS_KASSE_JAHR_CNT'
,p_sort_column_1=>'FK_IMP_LOG_LOAD'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'LOAD_DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16848307355600978)
,p_plug_name=>'Kontenblatt'
,p_parent_plug_id=>wwv_flow_api.id(10253486697752683)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>55
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto.*,  ',
'   case when kontr.jahr is not null then 1 else 0 end chk, ',
'   finalisierungsdatum, ',
'   datstok.cnt,',
'   datstok.cnt_datum_steuer_ok, ',
'   datstok.diff_datum_steuer_ok, ',
'   case when nvl(datstok.cnt,0) = kontr.final_cnt then 1 else 0 end cnt_check, ',
'   case when to_number(konto) = :P304_konto_auswahl then 1 else 0 end sel',
', kontr.pk_contr_kontrolle,',
'kontr.final_cnt',
'from ',
'    (',
'            select distinct kontonummer',
'            from t_lex_kontenblatt',
'        ',
'    ) kto',
'        join (select * from t_contr_kontrolle where jahr = :P304_jahr and konto = :P304_konto_auswahl) kontr on kontr.konto = kto.kontonummer ',
'        left join (select * from v_steu_steuer_datum_ok where jahr = :P304_jahr) datstok on datstok.kontonummer = kto.kontonummer  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16849102531600986)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.:RP:P305_ID:#ID##ROWID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>18289421806992526
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16850841421601003)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16850964235601004)
,p_db_column_name=>'CHK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Chk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851013650601005)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851139561601006)
,p_db_column_name=>'CNT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851223932601007)
,p_db_column_name=>'CNT_DATUM_STEUER_OK'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cnt Datum Steuer Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851362813601008)
,p_db_column_name=>'DIFF_DATUM_STEUER_OK'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Diff Datum Steuer Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851456702601009)
,p_db_column_name=>'CNT_CHECK'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cnt Check'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16851525696601010)
,p_db_column_name=>'SEL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16859812651689662)
,p_db_column_name=>'FINAL_CNT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Final Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46771489039360671)
,p_db_column_name=>'PK_CONTR_KONTROLLE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Contr Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16870283631691600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'183107'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KONTONUMMER:CHK:FINALISIERUNGSDATUM:CNT:CNT_DATUM_STEUER_OK:DIFF_DATUM_STEUER_OK:CNT_CHECK:SEL:FINAL_CNT:PK_CONTR_KONTROLLE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(16871217909712383)
,p_report_id=>wwv_flow_api.id(16870283631691600)
,p_name=>'cnt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CNT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#ABABAB'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18265663800113879)
,p_plug_name=>'Kontenselection'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>2
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto.*,  ',
'   case when kontr.jahr is not null then 1 else 0 end chk, ',
'   finalisierungsdatum, ',
'   datstok.cnt,',
'   datstok.cnt_datum_steuer_ok, ',
'   datstok.diff_datum_steuer_ok, ',
'   case when nvl(datstok.cnt,0) = kontr.final_cnt then 1 else 0 end cnt_check, ',
'   case when to_number(konto) = :P304_konto_auswahl then 1 else 0 end sel',
', kontr.pk_contr_kontrolle',
'from ',
'    (',
'            select distinct kontonummer',
'            from t_lex_kontenblatt',
'    ) kto',
'        left join (select * from t_contr_kontrolle where jahr = :P304_jahr) kontr on kontr.konto = kto.kontonummer ',
'        left join (select * from v_steu_steuer_datum_ok where jahr = :P304_jahr) datstok on datstok.kontonummer = kto.kontonummer '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18265757023113879)
,p_name=>'Kontenselection'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:RP:P304_KONTO_AUSWAHL:#KONTONUMMER#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>19706076298505419
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8414616516451480)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Kontonummer'
,p_column_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP:P310_KONTO,P310_PK_CONTR_KONTROLLE:#KONTONUMMER#,#PK_CONTR_KONTROLLE#'
,p_column_linktext=>'#KONTONUMMER#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10346845446308561)
,p_db_column_name=>'CHK'
,p_display_order=>31
,p_column_identifier=>'D'
,p_column_label=>'Chk'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10346929761308562)
,p_db_column_name=>'FINALISIERUNGSDATUM'
,p_display_order=>41
,p_column_identifier=>'E'
,p_column_label=>'Finalisierungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558880195839694)
,p_db_column_name=>'CNT'
,p_display_order=>51
,p_column_identifier=>'F'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13558970270839695)
,p_db_column_name=>'CNT_DATUM_STEUER_OK'
,p_display_order=>61
,p_column_identifier=>'G'
,p_column_label=>'Cnt Datum Steuer Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13559042392839696)
,p_db_column_name=>'DIFF_DATUM_STEUER_OK'
,p_display_order=>71
,p_column_identifier=>'H'
,p_column_label=>'Diff Datum Steuer Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951756759462078)
,p_db_column_name=>'CNT_CHECK'
,p_display_order=>81
,p_column_identifier=>'I'
,p_column_label=>'Cnt Check'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13952986520462091)
,p_db_column_name=>'SEL'
,p_display_order=>91
,p_column_identifier=>'J'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46771414003360670)
,p_db_column_name=>'PK_CONTR_KONTROLLE'
,p_display_order=>101
,p_column_identifier=>'L'
,p_column_label=>'Pk Contr Kontrolle'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18268339396279876)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'98552'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'KONTONUMMER:FINALISIERUNGSDATUM:SEL:CNT:CNT_DATUM_STEUER_OK:DIFF_DATUM_STEUER_OK:CNT_CHECK:CHK::PK_CONTR_KONTROLLE'
,p_sort_column_1=>'KONTONUMMER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CHK'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'CHK'
,p_break_enabled_on=>'CHK'
,p_sum_columns_on_break=>'CNT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36872214378833510)
,p_report_id=>wwv_flow_api.id(18268339396279876)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CHK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("CHK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36872985562833511)
,p_report_id=>wwv_flow_api.id(18268339396279876)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(36872596715833511)
,p_report_id=>wwv_flow_api.id(18268339396279876)
,p_name=>'diff'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CNT_CHECK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("CNT_CHECK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_row_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8327782762455463)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>unistr('Zusammenf\00FChren')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>unistr('Zusammenf\00FChren')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8329008099506525)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11739379174329416)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'Update_Kasse'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Update fk_main_key tag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8329376208509092)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontenblatt'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10171767337959993)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'Kasse'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kasse'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:314:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18029075101728108)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(16745339554343597)
,p_button_name=>'Create_susa'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Create Susa'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:374:&SESSION.::&DEBUG.:RP:P374_JAHR,P374_KONTO:&P304_JAHR.,&P304_KONTO_AUSWAHL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8301405047210172)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP,252::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12939851990056496)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'Steuer_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Steuer Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(35711610542752870)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(16745339554343597)
,p_button_name=>'abstimmung_konto'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Abstimmung Konto'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:385:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8396732400500392)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Belege_IR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Belege Ir'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.:RP:P307_NEW:&P305_BUCHUNGSNUMMER.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(21788418927805706)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(16745339554343597)
,p_button_name=>'log_load'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Log Load'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:392:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8450999594204961)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12939924490056497)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'Steuer_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Steuer Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7975216835962293)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Reset'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:RP,304::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7976583508962307)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Remove'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Remove'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9687064811820261)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Kontoauszug_Abstimmung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontoauszug Abstimmung'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9689134784820282)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Susa'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Susa'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8302813194210186)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Kontrolle'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontrolle'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP:P310_KONTO:&P304_KONTO_AUSWAHL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15178664285719725)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15418841445179480)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'kontr_steuer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kontr Steuer'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:357:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(36610968156519085)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Buchungszuordnung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Buchungszuordnung'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39078290796894286)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'check_kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'check_kontenblatt'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:397:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10253630099752684)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'Projekt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10351771786308610)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8070464154546427)
,p_button_name=>'Reset_Kto'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Reset Kto'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:RP:P304_KONTO_AUSWAHL:'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8960424976020149)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8070464154546427)
,p_button_name=>'Ordner_Seite'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Ordner_Seite'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:RP,226:P226_PK_ABL_ORDNER_PAGE:'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12941266263056510)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'Set_split_buch_nr_man'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Split Buch Nr Man'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12998894697531067)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(8070464154546427)
,p_button_name=>'Create_Inp_Beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Create Inp Beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10253725630752685)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'location'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'location'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12998296351531061)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'set_flg_split_buch'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12998774201531065)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(11715929080412464)
,p_button_name=>'reset_flg_split_buch_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10253804699752686)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10253915958752687)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'geschaeftspartner'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'geschaeftspartner'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11493582184375894)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Create'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:166:&SESSION.::&DEBUG.:RP,166:P166_PK_GESCHAEFTSPARTNER:'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10254026269752688)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10254089749752689)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_api.id(10252793019752676)
,p_button_name=>'verwendungszweck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Verwendungszweck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13028800854054964)
,p_button_sequence=>190
,p_button_plug_id=>wwv_flow_api.id(11715810199412463)
,p_button_name=>'Lex_Kontenplan'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Lex Kontenplan'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:257:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18025457484728072)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16745339554343597)
,p_button_name=>'set_susa_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Susa Ok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18025577291728073)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(16745339554343597)
,p_button_name=>'set_susa_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Susa Nok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8303065553210188)
,p_name=>'P304_KONTO_AUSWAHL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8070464154546427)
,p_prompt=>'Konto Auswahl'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8960777893022480)
,p_name=>'P304_PK_ABL_ORDNER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(8070464154546427)
,p_prompt=>'Pk Abl Ordner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8961070121025520)
,p_name=>'P304_PK_ABL_ORDNER_PAGE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(8070464154546427)
,p_prompt=>'Pk Abl Ordner Page'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'         ord.JAHR || '' '' || ',
'        ord.ORDNER_NAME || '' '' ||',
'        ord_page.page_number d,',
'         ord_page.PK_ABL_ORDNER_page r',
'  from T_ABL_ORDNER ord',
'    left join t_abl_ordner_page ord_page on ord.pk_abl_ordner = ord_page.fk_abl_ordner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10252906035752677)
,p_name=>'P304_FK_PROJEKT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>'Projekt'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt, pk_projekt',
'from t_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10253034836752678)
,p_name=>'P304_FK_LOCATION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>'Location'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location, pk_location',
'from v_location'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10253089013752679)
,p_name=>'P304_FK_VERWENDUNGSZWECK'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>'Verwendungszweck'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select verwendungszweck, pk_verwendungszweck',
'from t_verwendungszweck'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10253267919752680)
,p_name=>'P304_FK_INVENTAR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>'Inventar'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr, pk_inventar',
'',
'from v_inventare'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10253376068752681)
,p_name=>'P304_FK_GESCHAEFTSPARTNER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>unistr('Gesch\00E4ftspartner')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select geschaeftspartner, pk_geschaeftspartner',
'from t_geschaeftspartner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10253416605752682)
,p_name=>'P304_FK_KATEGORIE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(10252793019752676)
,p_prompt=>'Kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "Kategorie", pk_konto_buch_kat	',
'from t_konto_buch_kat	',
'order by "Kategorie"	',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10255977001752707)
,p_name=>'P304_JAHR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(8070464154546427)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value',
'from t_std',
'where fk_std_group = 221',
'and mark = 1'))
,p_item_default_type=>'SQL_QUERY_COLON'
,p_prompt=>'Jahr'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_value, std_value',
'from t_std',
'where fk_std_group = 221'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12998479911531062)
,p_name=>'P304_SPLIT_NR_MAN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11715929080412464)
,p_prompt=>'Split Nr Man'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:0;0,1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17043269803073078)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P304_JAHR'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17043338182073079)
,p_event_id=>wwv_flow_api.id(17043269803073078)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10256013332752708)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'/*',
' select std_value',
' into :P304_Jahr',
'from t_std',
'where fk_std_group = 221 and mark = 1;',
'*/',
'null;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7976826780962309)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_Remove'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     delete from  imp_kontenblatt_2018  where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7976583508962307)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10254817552752696)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_projekt = :P304_fk_projekt where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10253630099752684)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10254882071752697)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('3_gesch\00E4ftspartner')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_geschaeftspartner = :P304_fk_geschaeftspartner where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10253915958752687)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10255002872752698)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_inventar = :P304_fk_inventar where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10253804699752686)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10255101292752699)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_kategorie = :P304_fk_kategorie where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10254026269752688)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10255261804752700)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_location'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_location = :P304_fk_location where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10253725630752685)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10255365711752701)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_verwendungszweck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'     update imp_kontenblatt_2018  set fk_verwendungszweck = :P304_fk_verwendungszweck where id  = apex_application.g_f01(i);',
'       commit;',
'    end if;',
'    end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(10254089749752689)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11766742749713170)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'8_Update Tag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'update Kas_Kasse set FK_MAIN_KEY = KTO_KONTO_SEQ.nextval where fk_main_key is null;',
'   ',
'merge into kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from kas_kasse kas',
' left join v_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'    ',
'merge into kas_kasse t1',
'  using (',
'        select pk_arbeitstage, ',
'       pk_kas_kasse',
'',
'        from (select * from kas_kasse where datum is not null and fk_arbeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kas_kasse = t2.pk_kas_kasse)',
'        when matched then',
'        update set t1.fk_arbeitstag= t2.pk_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update kas_kasse set fk_konto = 61 where fk_konto is null;',
'   update kas_kasse set fk_kontotyp = 6 where fk_kontotyp is null;',
'   update kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11739379174329416)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12940034313056498)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_Steuer_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'       select buchungsnummer',
'       into v_buchungsnummer',
'       from imp_kontenblatt_2018 ',
'       where  id  = apex_application.g_f01(i);',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = sysdate where buchungsnummer = v_buchungsnummer and jahr = :P304_JAHR;',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12939851990056496)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12940083236056499)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_Steuer_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'       select buchungsnummer',
'       into v_buchungsnummer',
'       from imp_kontenblatt_2018 ',
'       where  id  = apex_application.g_f01(i);',
'    ',
'        update imp_kontenblatt_2018  set datum_steuer_ok = null where buchungsnummer = v_buchungsnummer and jahr = :P304_JAHR;',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12939924490056497)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12998488106531063)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_set_flg_split_buch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update imp_kontenblatt_2018  set flg_split_buch = 1 where id = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12998296351531061)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12998801465531066)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_reset_flg_split_buch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update imp_kontenblatt_2018  set flg_split_buch = 0 where id = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12998774201531065)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12998623182531064)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'11_set_split_buch_nr_man'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'    ',
'        update imp_kontenblatt_2018  set split_nr_man = :P306_split_nr_man where  id  = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12941266263056510)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12999058932531068)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'12_create_inp_belege_all'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'    ',
'    ',
'    insert into inp_belege_ALL (',
'',
'bel_datum,',
'bezeichnung,',
'brutto_betrag,',
'fk_STATUS,',
'--fk_Kategorie,',
'--fk_verwendungszweck,',
'fk_abl_ordner_page,',
'comm_sonstiges,',
'create_at,',
'modify_at',
')',
'select belegdatum bt,',
'Buchungstext,',
'abs(nvl(habenBetrag_eur, sollbetrag_eur)) Betrag,',
'6  Status,',
'--"FK_Kategorie" ,',
'--"FK_Verwendungszweck",',
':P304_PK_ABL_ORDNER_PAGE,',
'fk_relation || '' '' || buchungsnummer || '' '' || Belegnummer,',
'sysdate,',
'sysdate',
'from imp_kontenblatt_2018',
'where id =   apex_application.g_f01(i);',
'commit;',
'',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12998894697531067)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15178864100723189)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'13_set_relation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' update imp_kontenblatt_2018 set fk_relation = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation is null;',
' commit;',
'  update imp_kontenblatt_2018 set fk_relation_sub = jahr || ''/'' || buchungsnummer ||''/0'' where fk_relation_sub is null;',
' commit;',
' ',
'  update t_lex_long set fk_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_relation_main is null;',
' commit;',
' ',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15178664285719725)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18025810108728076)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'14_susa_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        update imp_lex_susa  set datum_ok = sysdate where id =  apex_application.g_f02(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18025457484728072)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18025937005728077)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'14_susa_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' v_buchungsnummer number;',
'begin',
'',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'    ',
'        update imp_lex_susa  set datum_ok = null where id =  apex_application.g_f02(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18025577291728073)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18025731697728075)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  null;',
'   --Report 1 - Kontenblatt',
'       --Change Zuordnuung',
'           --1_Remove:                                          1',
'           --2_Projekt:                                         1',
unistr('           --3_gesch\00E4ftspartner:                                1'),
'           --4_Inventar:                                        1',
'           --5_Kategorie:                                       1',
'           --6_location:                                        1',
'           --7_verwendungszweck:                                1',
'       --set Steuer ok',
'          --9_Steuer_ok / 9_Steuer_nok:                         1',
'       --set split_buch',
'          --10_set_flg_split_buch / 10_reset_flg_split_buch     1                          --flg_split_buch',
'          --11_set_split_buch_nr_man                            1                          --split_buch_nr',
'       --others',
'         --12_create_inp_belege_all                             1',
'         --13_set_relation                                      --',
'   --Update Tag',
'     --8_Update Tag:                                            --',
'   --Report 3 - Susa',
'       --14_susa_datum_ok / 14_susa_datum_nok                   --',
'     ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
