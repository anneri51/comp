prompt --application/pages/page_00341
begin
--   Manifest
--     PAGE: 00341
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>341
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'map_verpfl'
,p_step_title=>'map_verpfl'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(12169912235547744)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200204141908'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12143551907878878)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_FLASH_MAP'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_flash_chart5(
 p_id=>wwv_flow_api.id(12143644559878879)
,p_default_chart_type=>'Map'
,p_chart_title=>'New'
,p_chart_rendering=>'FLASH_PREFERRED'
,p_chart_animation=>'Appear'
,p_display_attr=>':H:N::X::N::::Circle:N:N:N:N:N:Default:N:N::'
,p_dial_tick_attr=>':::::::::::N'
,p_gantt_attr=>'Y:None:None:Full:None:None:Full:None:None:Full:30:15:5:Y::::::'
,p_pie_attr=>':::'
,p_map_attr=>'Orthographic:RegionBounds:REGION_NAME:Y:Y:::::Y:'
,p_map_source=>'europe/germany_second_level.amap'
,p_margins=>':::'
, p_omit_label_interval=> null
,p_bgtype=>'Trans'
,p_grid_bgtype=>'Trans'
,p_color_scheme=>'7'
,p_map_undef_color_scheme=>'1'
,p_x_axis_label_font=>'::'
,p_y_axis_label_font=>'::'
,p_async_update=>'N'
, p_names_font=> null
, p_names_rotation=> null
,p_values_font=>'Tahoma:10:#000000'
,p_hints_font=>'Tahoma:10:#000000'
,p_legend_font=>'::'
,p_chart_title_font=>'Tahoma:14:#000000'
,p_x_axis_title_font=>'::'
,p_y_axis_title_font=>'::'
,p_gauge_labels_font=>'::'
,p_use_chart_xml=>'N'
);
wwv_flow_api.create_flash_chart5_series(
 p_id=>wwv_flow_api.id(12143728166878880)
,p_chart_id=>wwv_flow_api.id(12143644559878879)
,p_series_seq=>10
,p_series_name=>'New'
,p_series_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null, ''Porz'', 500 from dual union all (',
unistr('  select null, ''M\00FClheim'', 1000 from dual'),
')'))
,p_series_type=>'Map'
,p_series_query_type=>'SQL_QUERY'
,p_series_query_parse_opt=>'PARSE_CHART_QUERY'
,p_show_action_link=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12174775087688858)
,p_plug_name=>'map_verpfl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_FLASH_MAP'
);
wwv_flow_api.create_flash_chart5(
 p_id=>wwv_flow_api.id(12175098257688858)
,p_default_chart_type=>'Map'
,p_chart_title=>'Verpflegung'
,p_chart_rendering=>'FLASH_PREFERRED'
,p_chart_name=>'chart_13615417533080398'
,p_chart_width=>700
,p_chart_height=>500
,p_chart_animation=>'N'
,p_display_attr=>':H:N:V:X:N:N:::Y:None:::N:::Default:::S'
,p_gantt_attr=>'Y:Rhomb:Rhomb:Full:Rhomb:Rhomb:Full:Rhomb:Rhomb:Full:30:15:5:Y:I:N:S:E'
,p_pie_attr=>'Outside:::'
,p_map_attr=>'Orthographic:RegionBounds:REGION_NAME:Y:Y:::::Y:N'
,p_map_source=>'world/europe.amap'
, p_omit_label_interval=> null
,p_bgtype=>'Trans'
,p_grid_bgtype=>'Solid'
,p_grid_bgcolor1=>'#FFFFFF'
,p_color_scheme=>'7'
,p_map_undef_color_scheme=>'1'
,p_x_axis_label_font=>'Tahoma:10:#000000'
,p_y_axis_label_font=>'Tahoma:10:#000000'
, p_names_font=> null
, p_names_rotation=> null
,p_values_font=>'Tahoma:10:#000000'
,p_hints_font=>'Tahoma:10:#000000'
,p_legend_font=>'Tahoma:10:#000000'
,p_grid_labels_font=>'Tahoma:10:#000000'
,p_chart_title_font=>'Tahoma:14:#000000'
,p_x_axis_title_font=>'Tahoma:14:#000000'
,p_y_axis_title_font=>'Tahoma:14:#000000'
,p_gauge_labels_font=>'Tahoma:10:#000000'
);
wwv_flow_api.create_flash_chart5_series(
 p_id=>wwv_flow_api.id(12175548228688860)
,p_chart_id=>wwv_flow_api.id(12175098257688858)
,p_series_seq=>10
,p_series_name=>'Series 1'
,p_series_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null, ''Porz'', 500 from dual union all (',
unistr('  select null, ''M\00FClheim'', 1000 from dual'),
')'))
,p_series_type=>'Map'
,p_series_query_type=>'SQL_QUERY'
,p_series_query_no_data_found=>'no data found'
,p_series_query_row_count_max=>300
,p_show_action_link=>'N'
);
wwv_flow_api.component_end;
end;
/
