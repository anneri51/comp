prompt --application/pages/page_00350
begin
--   Manifest
--     PAGE: 00350
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>350
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'Kalender_Beleg'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Kalender_Beleg'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42863563640275431)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090844'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13842782220362856)
,p_plug_name=>'Kalender_Beleg'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from  (',
'select PK_INP_BELEGE_ALL,',
'    ',
'       BEZEICHNUNG || '' ('' || pk_inp_belege_all || '') '' || brutto_betrag || '' '' || von  || '' - '' || bis bezeichnung,',
'       FK_LAND,',
'       FK_CITY,',
'       BEL_DATUM,',
'       VON,',
'       BIS,',
'    fk_kategorie',
'  from INP_BELEGE_ALL inp',
'  --  left join kal on  (inp.von <=  kal.end_dt and  kal.start_dt>= inp.bis) or :P350_sel_datum is null',
'  union',
'  select PK_INP_BELEGE_ALL,',
'    ',
'       BEZEICHNUNG || '' ('' || pk_inp_belege_all || '')'' || '' '' ||  brutto_betrag || '' '' || bel_datum bezeichnung,',
'       FK_LAND,',
'       FK_CITY,',
'       BEL_DATUM,',
'       BEL_DATUM,',
'      BEL_DATUM,',
'    fk_kategorie',
'  from INP_BELEGE_ALL inp',
'  --     left join kal on (inp.bel_datum between kal.start_dt and kal.end_dt)  or :P350_sel_datum is null',
'    )',
'    where fk_kATEGORIE= :P350_fk_kategorie or :P350_fk_kategorie is null ',
'    ',
'    --with kal as (select to_date(''01.'' ||substr(:P350_sel_datum,4,7), ''DD.MM.YYYY'') start_dt              , to_date(''31.'' ||substr(:P350_sel_datum,4,7), ''DD.MM.YYYY'') end_dt from dual)'))
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'VON'
,p_attribute_02=>'BIS'
,p_attribute_03=>'BEZEICHNUNG'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13858237185827798)
,p_name=>'P350_SEL_DATUM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(13842782220362856)
,p_prompt=>'Sel Datum'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13858305428827799)
,p_name=>'P350_BEZEICHNUNG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13842782220362856)
,p_prompt=>'Bezeichnung'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13882919670823867)
,p_name=>'P350_FK_KATEGORIE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13842782220362856)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Kategorie'
,p_source=>'FK_KATEGORIE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select "Kategorie", pk_konto_buch_kat',
'  from t_konto_buch_kat'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.component_end;
end;
/
