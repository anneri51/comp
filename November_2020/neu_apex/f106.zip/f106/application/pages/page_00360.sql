prompt --application/pages/page_00360
begin
--   Manifest
--     PAGE: 00360
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>360
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'todo_grp'
,p_step_title=>'todo_grp'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42924821574681713)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090815'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14905349741510075)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_STEUER_JAHR_TODO_GRP,',
'       TODO,',
'       ',
'       CREATION_DATE, ',
'       std.std_name thema_dauerhaft,',
'       std1.std_name thema_monatlich,',
unistr('       std2.std_name thema_j\00E4hrlich,'),
'       nvl(nvl(std.std_name, std1.std_name), std2.std_name) thema,',
'       nvl(nvl(std.sort, std1.sort), std2.sort) sort,',
'       steuerberater_involviert,',
unistr('       steuerberater_empf\00E4nger,'),
'       steuerberater_sender,',
'       finanzamt_involviert,',
unistr('       finanzamt_empf\00E4nger,'),
'       finanzamt_sender',
'  from T_STEUER_JAHR_TODO_GRP tdgrp',
'    left join (select * from t_std where fk_std_group = 301) std on tdgrp.fk_thema_dauerhaft = std.std_value',
'      left join (select * from t_std where fk_std_group = 301) std1 on tdgrp.fk_thema_monatlich = std1.std_value',
unistr('        left join (select * from t_std where fk_std_group = 301) std2 on tdgrp.fk_thema_j\00E4hrlich = std2.std_value')))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14905706436510075)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:361:&SESSION.::&DEBUG.:RP:P361_PK_STEUER_JAHR_TODO_GRP:\#PK_STEUER_JAHR_TODO_GRP#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>16346025711901615
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14905828734510080)
,p_db_column_name=>'PK_STEUER_JAHR_TODO_GRP'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Steuer Jahr Todo Grp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14906192969510088)
,p_db_column_name=>'TODO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14875661328356764)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>22
,p_column_identifier=>'D'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14875694895356765)
,p_db_column_name=>'THEMA'
,p_display_order=>32
,p_column_identifier=>'E'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14876427089356772)
,p_db_column_name=>'SORT'
,p_display_order=>42
,p_column_identifier=>'F'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14876542638356773)
,p_db_column_name=>'THEMA_DAUERHAFT'
,p_display_order=>52
,p_column_identifier=>'G'
,p_column_label=>'Thema Dauerhaft'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14876673544356774)
,p_db_column_name=>'THEMA_MONATLICH'
,p_display_order=>62
,p_column_identifier=>'H'
,p_column_label=>'Thema Monatlich'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14876753989356775)
,p_db_column_name=>unistr('THEMA_J\00C4HRLICH')
,p_display_order=>72
,p_column_identifier=>'I'
,p_column_label=>unistr('Thema J\00E4hrlich')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877244105356780)
,p_db_column_name=>'STEUERBERATER_INVOLVIERT'
,p_display_order=>82
,p_column_identifier=>'J'
,p_column_label=>'Steuerberater Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877313009356781)
,p_db_column_name=>'FINANZAMT_INVOLVIERT'
,p_display_order=>92
,p_column_identifier=>'K'
,p_column_label=>'Finanzamt Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877444841356782)
,p_db_column_name=>unistr('STEUERBERATER_EMPF\00C4NGER')
,p_display_order=>102
,p_column_identifier=>'L'
,p_column_label=>unistr('Steuerberater Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877482409356783)
,p_db_column_name=>'STEUERBERATER_SENDER'
,p_display_order=>112
,p_column_identifier=>'M'
,p_column_label=>'Steuerberater Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877611073356784)
,p_db_column_name=>unistr('FINANZAMT_EMPF\00C4NGER')
,p_display_order=>122
,p_column_identifier=>'N'
,p_column_label=>unistr('Finanzamt Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14877768896356785)
,p_db_column_name=>'FINANZAMT_SENDER'
,p_display_order=>132
,p_column_identifier=>'O'
,p_column_label=>'Finanzamt Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14920477346519063)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'163608'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('THEMA:PK_STEUER_JAHR_TODO_GRP:TODO:SORT:THEMA_DAUERHAFT:THEMA_MONATLICH:THEMA_J\00C4HRLICH:STEUERBERATER_INVOLVIERT:STEUERBERATER_EMPF\00C4NGER:STEUERBERATER_SENDER:FINANZAMT_INVOLVIERT:FINANZAMT_EMPF\00C4NGER:FINANZAMT_SENDER:')
,p_break_on=>'THEMA'
,p_break_enabled_on=>'THEMA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14948989568027958)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'fie'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('FINANZAMT_EMPF\00C4NGER')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("FINANZAMT_EMPF\00C4NGER" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14949288845027960)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'fii'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FINANZAMT_INVOLVIERT'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FINANZAMT_INVOLVIERT" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14949687959027960)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'fis'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FINANZAMT_SENDER'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FINANZAMT_SENDER" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14950136032027960)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'stbe'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>unistr('STEUERBERATER_EMPF\00C4NGER')
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>unistr(' (case when ("STEUERBERATER_EMPF\00C4NGER" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) ')
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14950544604027961)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'stbi'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STEUERBERATER_INVOLVIERT'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STEUERBERATER_INVOLVIERT" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14950905222027961)
,p_report_id=>wwv_flow_api.id(14920477346519063)
,p_name=>'stbs'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STEUERBERATER_SENDER'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("STEUERBERATER_SENDER" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14907430370510092)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14905349741510075)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:361:&SESSION.::&DEBUG.:361'
);
wwv_flow_api.component_end;
end;
/
