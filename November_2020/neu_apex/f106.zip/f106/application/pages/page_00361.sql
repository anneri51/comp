prompt --application/pages/page_00361
begin
--   Manifest
--     PAGE: 00361
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>361
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'todo_grp'
,p_step_title=>'todo_grp'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42924821574681713)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090815'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14900204096510044)
,p_plug_name=>'todo_grp'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_STEUER_JAHR_TODO_GRP'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47735262536114865)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select td.PK_STEUER_JAHR_TODO,',
'       td.FK_JAHR,',
'       td.TODO  todo_descr,',
'       td.FK_TODO_GRP,',
'       td.DATUM_OK,',
'       tdgrp.*',
'  from T_STEUER_JAHR_TODO td',
'   left join (select PK_STEUER_JAHR_TODO_GRP,',
'       TODO,',
'       ',
'       CREATION_DATE, ',
'       std.std_name thema_dauerhaft,',
'       std1.std_name thema_monatlich,',
unistr('       std2.std_name thema_j\00E4hrlich,'),
'       nvl(nvl(std.std_name, std1.std_name), std2.std_name) thema,',
'       nvl(nvl(std.sort, std1.sort), std2.sort) sort,',
'       steuerberater_involviert,',
unistr('       steuerberater_empf\00E4nger,'),
'       steuerberater_sender,',
'       finanzamt_involviert,',
unistr('       finanzamt_empf\00E4nger,'),
'       finanzamt_sender',
'  from T_STEUER_JAHR_TODO_GRP tdgrp',
'    left join (select * from t_std where fk_std_group = 301) std on tdgrp.fk_thema_dauerhaft = std.std_value',
'      left join (select * from t_std where fk_std_group = 301) std1 on tdgrp.fk_thema_monatlich = std1.std_value',
unistr('        left join (select * from t_std where fk_std_group = 301) std2 on tdgrp.fk_thema_j\00E4hrlich = std2.std_value) tdgrp on tdgrp.pk_steuer_jahr_todo_grp = td.fk_todo_grp'),
'    where pk_steuer_jahr_todo_grp = :P361_PK_Steuer_jahr_todo_grp'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(47735732808114865)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:363:&SESSION.::&DEBUG.:RP:P363_PK_STEUER_JAHR_TODO:\#PK_STEUER_JAHR_TODO#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>49176052083506405
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14981992531423956)
,p_db_column_name=>'PK_STEUER_JAHR_TODO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Steuer Jahr Todo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14982422287423956)
,p_db_column_name=>'FK_JAHR'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14982834103423956)
,p_db_column_name=>'TODO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14975666540423950)
,p_db_column_name=>'FK_TODO_GRP'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Fk Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14976040785423952)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14976468109423952)
,p_db_column_name=>'PK_STEUER_JAHR_TODO_GRP'
,p_display_order=>43
,p_column_identifier=>'G'
,p_column_label=>'Pk Steuer Jahr Todo Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14976781485423952)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>53
,p_column_identifier=>'H'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14977201523423952)
,p_db_column_name=>'THEMA_DAUERHAFT'
,p_display_order=>63
,p_column_identifier=>'I'
,p_column_label=>'Thema Dauerhaft'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14977600465423953)
,p_db_column_name=>'THEMA_MONATLICH'
,p_display_order=>73
,p_column_identifier=>'J'
,p_column_label=>'Thema Monatlich'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14978010972423953)
,p_db_column_name=>unistr('THEMA_J\00C4HRLICH')
,p_display_order=>83
,p_column_identifier=>'K'
,p_column_label=>unistr('Thema J\00E4hrlich')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14978412823423953)
,p_db_column_name=>'THEMA'
,p_display_order=>93
,p_column_identifier=>'L'
,p_column_label=>'Thema'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14978837143423953)
,p_db_column_name=>'SORT'
,p_display_order=>103
,p_column_identifier=>'M'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14979258803423953)
,p_db_column_name=>'STEUERBERATER_INVOLVIERT'
,p_display_order=>113
,p_column_identifier=>'N'
,p_column_label=>'Steuerberater Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14979584654423953)
,p_db_column_name=>unistr('STEUERBERATER_EMPF\00C4NGER')
,p_display_order=>123
,p_column_identifier=>'O'
,p_column_label=>unistr('Steuerberater Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14980061607423955)
,p_db_column_name=>'STEUERBERATER_SENDER'
,p_display_order=>133
,p_column_identifier=>'P'
,p_column_label=>'Steuerberater Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14980476224423955)
,p_db_column_name=>'FINANZAMT_INVOLVIERT'
,p_display_order=>143
,p_column_identifier=>'Q'
,p_column_label=>'Finanzamt Involviert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14980821238423955)
,p_db_column_name=>unistr('FINANZAMT_EMPF\00C4NGER')
,p_display_order=>153
,p_column_identifier=>'R'
,p_column_label=>unistr('Finanzamt Empf\00E4nger')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14981244812423955)
,p_db_column_name=>'FINANZAMT_SENDER'
,p_display_order=>163
,p_column_identifier=>'S'
,p_column_label=>'Finanzamt Sender'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14981663533423955)
,p_db_column_name=>'TODO_DESCR'
,p_display_order=>173
,p_column_identifier=>'U'
,p_column_label=>'Todo Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(47740906951116827)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'164235'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('FK_JAHR:THEMA:TODO:PK_STEUER_JAHR_TODO:DATUM_OK:PK_STEUER_JAHR_TODO_GRP:SORT:STEUERBERATER_INVOLVIERT:STEUERBERATER_EMPF\00C4NGER:STEUERBERATER_SENDER:FINANZAMT_INVOLVIERT:FINANZAMT_EMPF\00C4NGER:FINANZAMT_SENDER:TODO_DESCR:CREATION_DATE:FK_TODO_GRP:THEMA_DA')
||unistr('UERHAFT:THEMA_J\00C4HRLICH:THEMA_MONATLICH:')
,p_break_on=>'THEMA'
,p_break_enabled_on=>'THEMA'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14903087283510069)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14900204096510044)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P361_PK_STEUER_JAHR_TODO_GRP'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14901884778510064)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14900204096510044)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:360:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14903500244510069)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14900204096510044)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P361_PK_STEUER_JAHR_TODO_GRP'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14902768774510069)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14900204096510044)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P361_PK_STEUER_JAHR_TODO_GRP'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(14903813823510069)
,p_branch_action=>'f?p=&APP_ID.:360:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14875833922356766)
,p_name=>'P361_FK_THEMA_DAUERHAFT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>'Fk Thema Dauerhaft'
,p_source=>'FK_THEMA_DAUERHAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 301'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14875886277356767)
,p_name=>'P361_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Creation Date'
,p_source=>'CREATION_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14876784566356776)
,p_name=>'P361_FK_THEMA_MONATLICH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>'Fk Thema Monatlich'
,p_source=>'FK_THEMA_MONATLICH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 301'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14876918854356777)
,p_name=>unistr('P361_FK_THEMA_J\00C4HRLICH')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>unistr('Fk Thema J\00E4hrlich')
,p_source=>unistr('FK_THEMA_J\00C4HRLICH')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 301'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14877027329356778)
,p_name=>'P361_STEUERBERATER_INVOLVIERT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_default=>'0'
,p_prompt=>'Steuerberater Involviert'
,p_source=>'STEUERBERATER_INVOLVIERT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14877091238356779)
,p_name=>'P361_FINANZAMT_INVOLVIERT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_default=>'0'
,p_prompt=>'Finanzamt Involviert'
,p_source=>'FINANZAMT_INVOLVIERT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14877861382356786)
,p_name=>unistr('P361_STEUERBERATER_EMPF\00C4NGER')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>unistr('Steuerberater Empf\00E4nger')
,p_source=>unistr('STEUERBERATER_EMPF\00C4NGER')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14877931811356787)
,p_name=>'P361_STEUERBERATER_SENDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>'Steuerberater Sender'
,p_source=>'STEUERBERATER_SENDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14878073118356788)
,p_name=>unistr('P361_FINANZAMT_EMPF\00C4NGER')
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>unistr('Finanzamt Empf\00E4nger')
,p_source=>unistr('FINANZAMT_EMPF\00C4NGER')
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14878094680356789)
,p_name=>'P361_FINANZAMT_SENDER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_prompt=>'Finanzamt Sender'
,p_source=>'FINANZAMT_SENDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:nein;0,ja;1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14900668370510049)
,p_name=>'P361_PK_STEUER_JAHR_TODO_GRP'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pk Steuer Jahr Todo Grp'
,p_source=>'PK_STEUER_JAHR_TODO_GRP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14901035843510058)
,p_name=>'P361_TODO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14900204096510044)
,p_item_source_plug_id=>wwv_flow_api.id(14900204096510044)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Todo'
,p_source=>'TODO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14904742427510072)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(14900204096510044)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form todo_grp'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14904346718510072)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(14900204096510044)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form todo_grp'
);
wwv_flow_api.component_end;
end;
/
