prompt --application/pages/page_00376
begin
--   Manifest
--     PAGE: 00376
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>2830423005072681
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>376
,p_user_interface_id=>wwv_flow_api.id(6266307226136058)
,p_name=>'dupl_lex'
,p_step_title=>'dupl_lex'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42901582232549956)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200524090908'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18317388828351594)
,p_plug_name=>'dupl_lex'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'apex_item.checkbox2(1, relation) sel,',
'dupl.*, ll.relation, ll.fk_relation_main, replace(ll.betrag, '','',''%2C'') betr, ll.fk_dupl_status,',
'dpc.datum_ok',
'',
'from  v_lex_dupl_jahr_betr dupl',
'  left join (select * from t_lex_long where status is null) ll on ll.jahr = dupl.jahr and dupl.betrag = ll.betrag',
'  left join t_duplikat dp on dp.fk_relation1_lex = ll.relation',
'  left join t_duplikat_check dpc on dpc.pk_duplikat_check = dp.fk_duplikat_check'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18317487158351594)
,p_name=>'dupl_lex'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>19757806433743134
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18317959261351605)
,p_db_column_name=>'JAHR'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18318379323351606)
,p_db_column_name=>'BETRAG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Betrag'
,p_column_link=>'f?p=&APP_ID.:377:&SESSION.::&DEBUG.:RP:P377_BETRAG,P377_JAHR:#BETR#,#JAHR#'
,p_column_linktext=>'#BETRAG#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18318759417351606)
,p_db_column_name=>'CNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18282075970295081)
,p_db_column_name=>'RELATION'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18282143316295082)
,p_db_column_name=>'FK_RELATION_MAIN'
,p_display_order=>23
,p_column_identifier=>'E'
,p_column_label=>'Fk Relation Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18282725748295088)
,p_db_column_name=>'BETR'
,p_display_order=>33
,p_column_identifier=>'F'
,p_column_label=>'Betr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18822019382682880)
,p_db_column_name=>'SEL'
,p_display_order=>43
,p_column_identifier=>'G'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18822450196682884)
,p_db_column_name=>'FK_DUPL_STATUS'
,p_display_order=>53
,p_column_identifier=>'H'
,p_column_label=>'Fk Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18822968144682889)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>63
,p_column_identifier=>'I'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18319135391353897)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197595'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL:BETRAG:CNT:RELATION:FK_RELATION_MAIN:JAHR::FK_DUPL_STATUS:DATUM_OK'
,p_break_on=>'BETRAG'
,p_break_enabled_on=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21695221006092780)
,p_report_id=>wwv_flow_api.id(18319135391353897)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(21694873583092778)
,p_report_id=>wwv_flow_api.id(18319135391353897)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18822159823682881)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(18317388828351594)
,p_button_name=>'set_fk_dupl_status'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Fk_dupl_status'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(18822279185682882)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(18317388828351594)
,p_button_name=>'reset_fk_dupl_status_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6255523634136033)
,p_button_image_alt=>'Set Fk_dupl_status'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18852233322994497)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_set_fk_status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update t_lex_long  set fk_dupl_status = 1 where relation = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18822159823682881)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18822376360682883)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_reset_fk_status'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'     ',
'        update t_lex_long  set fk_dupl_status = 0 where relation = apex_application.g_f01(i);',
'        commit;',
'        ',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(18822279185682882)
);
wwv_flow_api.component_end;
end;
/
