prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 107
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20546679608983279)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20762856715521075)
,p_group_name=>'Angebot'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20705165126616782)
,p_group_name=>'Fremdleistung'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20704950076615303)
,p_group_name=>'Gesamtkalkulation'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20704729713613506)
,p_group_name=>'Global'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20706600205646636)
,p_group_name=>'Inbetriebnahme'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(21270107913049255)
,p_group_name=>'Maschinenbau'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20705025890616052)
,p_group_name=>'Material'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20704825775614316)
,p_group_name=>'Projekt'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(20705262428618092)
,p_group_name=>'Stammdaten'
);
wwv_flow_api.component_end;
end;
/
