prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_api.id(20543567030983233)
,p_name=>'Stationsaufbau'
,p_alias=>'STATIONSAUFBAU'
,p_step_title=>'Stationsaufbau'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(21270107913049255)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200801163108'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22266453203819002)
,p_plug_name=>'Prozess'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44348416857961205)
,p_plug_name=>'Select'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44353760485970118)
,p_plug_name=>'Komponenten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'  select relkm.*,',
'  komp.pk_masch_komponenten,',
'  komp.bezeichnung,',
'  matm.pk_masch_material main_pk_masch_material,',
'  matm.materialbezeichnung main_materialbezeichnung,',
'    mat.pk_masch_material pk_masch_material,',
'  mat.materialbezeichnung materialbezeichnung',
'from t_masch_komponenten komp',
' left join t_rel_masch_komp_komponente_material relkm on relkm.fk_masch_komponente = komp.pk_masch_komponenten',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.fk_rel_masch_mat_material_material_main',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
'   )',
'   select *',
'   from bas',
'where fK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Komponenten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44353962708970120)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>44353962708970120
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22295692346258004)
,p_db_column_name=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Komp Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22296026675258006)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22296495497258006)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22296813785258006)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22297291873258007)
,p_db_column_name=>'FK_MASCH_KOMPONENTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Komponente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22297618578258007)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22298013335258007)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22298405521258007)
,p_db_column_name=>'FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22298830703258008)
,p_db_column_name=>'PK_MASCH_KOMPONENTEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Masch Komponenten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22299295688258008)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22299623020258008)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22300032171258008)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22300451697258009)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22300873942258009)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44402529593154436)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'223012'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_KOMPONENTE:COMM:FK_STD_MASCH_ZUORD_VAR_FIX:FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:PK_MASCH_KOMPONENTEN:BEZEICHNUNG:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:P'
||'K_MASCH_MATERIAL:MATERIALBEZEICHNUNG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44360190094972318)
,p_plug_name=>'Band_Station'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'  select relstm.*,',
' stm.stationsbezeichnung,',
'    stm.pk_masch_band_station,',
'  matm.pk_masch_material main_pk_masch_material,',
'  matm.materialbezeichnung main_materialbezeichnung,',
'    mat.pk_masch_material pk_masch_material,',
'  mat.materialbezeichnung materialbezeichnung,',
'    relmatm.pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'from t_masch_band_station stm',
' left join t_rel_masch_band_station_material relstm on relstm.fk_masch_band_station = stm.pk_masch_band_station',
' left join t_rel_masch_komp_komponente_material relkm on relkm.PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL = relstm.fk_rel_masch_komp_komponente_material',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
'   )',
'   select *',
'   from bas',
'where pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Band_Station'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44362046459972337)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>44362046459972337
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22301938829260203)
,p_db_column_name=>'PK_REL_MASCH_BAND_STATION_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Band Station Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22302302594260203)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22302773996260203)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22303153918260204)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22303529701260204)
,p_db_column_name=>'FK_MASCH_BAND_STATION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Band Station'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22303993377260204)
,p_db_column_name=>'COMM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22304334475260204)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22304797637260205)
,p_db_column_name=>'PK_MASCH_BAND_STATION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Masch Band Station'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22305159956260205)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22305536789260205)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22305957768260205)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22306368390260205)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22306776581260206)
,p_db_column_name=>'FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Rel Masch Komp Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22307147403260206)
,p_db_column_name=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Pk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44416638545241922)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'223075'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_BAND_STATION_MATERIAL:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_BAND_STATION:COMM:STATIONSBEZEICHNUNG:PK_MASCH_BAND_STATION:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:PK_MASCH_MATERIAL:MATERIALBEZEICHNUNG:FK_REL_MASCH_KOMP_KOMP'
||'ONENTE_MATERIAL:PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44384082541046875)
,p_plug_name=>'Materialzuordnungen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from (select relmatm.*, ',
' mat_m.pk_masch_material main_pk_masch_material,',
' mat_m.materialbezeichnung main_materialbezeichnung,',
' mat.pk_masch_material pk_masch_material,',
' mat.materialbezeichnung materialbezeichnung,',
' kat.std_name kategorie',
' ',
'',
'from T_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm',
' left join t_masch_material mat_m on mat_m.pk_masch_material = relmatm.fk_masch_material_main',
'  left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join (select * from t_std where fk_std_group = 803) kat on kat.std_value = mat.fk_std_masch_mat_kategorie',
'where (PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null)',
'      )',
'where ( pk_masch_material = :P23_PK_MASCH_MATERIAL or :P23_PK_MASCH_MATERIAL is null  )'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Materialzuordnungen'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44384179869046875)
,p_name=>'Materialzuordnungen'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:#PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>44384179869046875
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22290413027252913)
,p_db_column_name=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22290884923252914)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22291204137252914)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22291630920252914)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22292092809252915)
,p_db_column_name=>'FK_MASCH_MATERIAL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22292492457252915)
,p_db_column_name=>'FK_MASCH_MATERIAL_MAIN'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Masch Material Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22292832419252915)
,p_db_column_name=>'COMM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22293200283252915)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22293628824252916)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22294010999252916)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22294437260252916)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22290022769252910)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44396412115149329)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'222948'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_MATERIAL:FK_MASCH_MATERIAL_MAIN:COMM:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:PK_MASCH_MATERIAL:MATERIALBEZEICHNUNG:KATEGORIE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44609388513264515)
,p_plug_name=>'Material'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with  bas as ',
'(',
'     select mat.PK_MASCH_MATERIAL,',
'       mat.FK_MDT_MANDANT,',
'       mat.CREATED_AT,',
'       mat.MODIFIED_AT,',
'       mat.STUECKKOSTEN,',
'       mat.FIXKOSTEN,',
'       mat.ANZAHL,',
'       mat.DESCR,',
'       mat.MATERIALBEZEICHNUNG,',
'       mat.COMM,',
'       mat.FK_STD_MASCH_ZUORD_VAR_FIX,',
'',
'       komp.bezeichnung komp_bezeicnung,',
'       st.stationsbezeichnung,',
'       st.pk_masch_band_stationen,',
'       st.descr st_descr,',
'       st.position st_position,',
'       komp.fk_std_masch_komp_sort,',
'       mat.grundpreis,',
'       mat.fk_bas_mon_waehrung,',
'    mat1.pk_masch_material pk_masch_material_main,',
'    mat1.materialbezeichnung materialbezeichnung_main,',
'    kat.std_name material_kategorie',
'  from T_MASCH_MATERIAL mat',
'    left join T_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm on relmatm.fk_masch_material = mat.pk_masch_material',
'    left join T_MASCH_MATERIAL mat1 on relmatm.fk_masch_material_main = mat1.pk_masch_material',
'    left join t_rel_masch_komp_komponente_material relkm on relkm.fk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN  =relmatm.pk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'    left join t_masch_komponenten komp on komp.pk_masch_komponenten = relkm.fk_masch_komponente',
'    left join t_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm on relmatm.pk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = relkm.fk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'    left join t_rel_masch_band_station_komponente_material relstm on relstm.fk_rel_masch_komp_komponente_material =relkm.pk_rel_masch_komp_komponente_material',
'    left join t_masch_band_stationen st on st.pk_masch_band_stationen  = relstm.fk_masch_band_station',
'    left join (select * from t_std where fk_std_group = 803 ) kat on kat.std_value = mat.fk_std_masch_mat_kategorie',
'  )',
'  select *',
'  from bas',
'  where pk_masch_band_stationen = :P23_SEL_STATION or :P23_SEL_STATION  is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Material'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44609813937264515)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:RP:P46_PK_MASCH_MATERIAL:\#PK_MASCH_MATERIAL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'FAIQA'
,p_internal_uid=>44609813937264515
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22591306839172394)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Masch Material'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PK_MASCH_MATERIAL:#PK_MASCH_MATERIAL#'
,p_column_linktext=>'#PK_MASCH_MATERIAL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22591763918172394)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22592148379172394)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22592597709172394)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22592982485172395)
,p_db_column_name=>'STUECKKOSTEN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Stueckkosten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22593301500172395)
,p_db_column_name=>'FIXKOSTEN'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fixkosten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22593702461172395)
,p_db_column_name=>'ANZAHL'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22594183790172395)
,p_db_column_name=>'DESCR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22594528930172395)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22594970744172396)
,p_db_column_name=>'COMM'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22595329162172396)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22590104147172392)
,p_db_column_name=>'KOMP_BEZEICNUNG'
,p_display_order=>22
,p_column_identifier=>'P'
,p_column_label=>'Komp Bezeicnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22590584156172393)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>32
,p_column_identifier=>'Q'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22595771395172396)
,p_db_column_name=>'ST_DESCR'
,p_display_order=>52
,p_column_identifier=>'S'
,p_column_label=>'St Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22596122940172396)
,p_db_column_name=>'ST_POSITION'
,p_display_order=>62
,p_column_identifier=>'T'
,p_column_label=>'St Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22596510912172397)
,p_db_column_name=>'FK_STD_MASCH_KOMP_SORT'
,p_display_order=>72
,p_column_identifier=>'U'
,p_column_label=>'Fk Std Masch Komp Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22596948038172397)
,p_db_column_name=>'GRUNDPREIS'
,p_display_order=>82
,p_column_identifier=>'V'
,p_column_label=>'Grundpreis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22597330910172397)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>92
,p_column_identifier=>'W'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22597738954172397)
,p_db_column_name=>'PK_MASCH_MATERIAL_MAIN'
,p_display_order=>102
,p_column_identifier=>'X'
,p_column_label=>'Pk Masch Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22598191038172397)
,p_db_column_name=>'MATERIALBEZEICHNUNG_MAIN'
,p_display_order=>112
,p_column_identifier=>'Y'
,p_column_label=>'Materialbezeichnung Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22598514846172398)
,p_db_column_name=>'MATERIAL_KATEGORIE'
,p_display_order=>122
,p_column_identifier=>'Z'
,p_column_label=>'Material Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22786875913048803)
,p_db_column_name=>'PK_MASCH_BAND_STATIONEN'
,p_display_order=>132
,p_column_identifier=>'AA'
,p_column_label=>'Pk Masch Band Stationen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44617132079270858)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'225989'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:PK_MASCH_MATERIAL:FK_MDT_MANDANT:ST_DESCR:MATERIAL_KATEGORIE:PK_MASCH_MATERIAL_MAIN:MATERIALBEZEICHNUNG_MAIN:MATERIALBEZEICHNUNG:COMM:FK_STD_MASCH_ZUORD_VAR_FIX:STATIONSBEZEICHNUNG:ST_POSITION:GRUNDPREIS:FK_BAS_'
||'MON_WAEHRUNG:STUECKKOSTEN:FIXKOSTEN:ANZAHL:DESCR:CREATED_AT:MODIFIED_AT::PK_MASCH_BAND_STATIONEN'
,p_break_on=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:0:0:0:0'
,p_break_enabled_on=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:0:0:0:0'
,p_sum_columns_on_break=>'GRUNDPREIS'
,p_count_columns_on_break=>'PK_MASCH_MATERIAL'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22599309225172399)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(44609388513264515)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:46'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22288579440249082)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN,P23_PK_MASCH_MATERIAL:,'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22266570527819003)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'1_Material'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'1 Material'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::P46_PK_MASCH_MATERIAL:'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22266727171819005)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'1_1_Materialzuordnung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'1 1 Materialzuordnung'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::P26_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22266674002819004)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'2_Komponenten'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'2 Komponenten'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::P44_PK_MASCH_KOMPONENTEN:'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22266824271819006)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'2_1_Komponenten_Materialzuordnung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'2 1 Komponenten Materialzuordnung'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22787627467048811)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'3_Komponentenzuordnung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'3_Komponentenzuordnung'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::P28_PK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN:'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22266947455819007)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(22266453203819002)
,p_button_name=>'4_Stationen_Komponenten_Material'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(20521094056983187)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'4 Stationen Komponenten Material'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::P34_PK_REL_MASCH_BAND_STATION_MATERIAL:&P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN.'
,p_grid_column_attributes=>'style="padding-top:8px"'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22288965533249088)
,p_name=>'P23_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22266453203819002)
,p_prompt=>'Pk Rel Masch Mat Material Material Main'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(20519966476983182)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22289349411249091)
,p_name=>'P23_PK_MASCH_MATERIAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22266453203819002)
,p_prompt=>'Pk Masch Material'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(20519966476983182)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
