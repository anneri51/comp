prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_api.id(20543567030983233)
,p_name=>'Komponenten'
,p_alias=>'KOMPONENTEN'
,p_step_title=>'Komponenten'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(21270107913049255)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200728164014'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(21805170952791160)
,p_plug_name=>'Komponenten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select komp.*, komp_m.bezeichnung komp_m_beeichnung',
'from t_masch_komponenten komp',
' left join t_masch_komponenten komp_m on komp_m.pk_masch_komponenten = komp.fk_masch_komponenten_main'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Komponenten'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(21805254004791160)
,p_name=>'Komponenten'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>21805254004791160
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21805614010791164)
,p_db_column_name=>'PK_MASCH_KOMPONENTEN'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Masch Komponenten'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21805940970791164)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21806308441791165)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21806771650791165)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21807109761791165)
,p_db_column_name=>'COMM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21807595602791165)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21807903960791165)
,p_db_column_name=>'ANZAHL'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21808371407791166)
,p_db_column_name=>'FK_MASCH_KOMPONENTEN_MAIN'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Masch Komponenten Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21808762941791166)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21282727619326930)
,p_db_column_name=>'KOMP_M_BEEICHNUNG'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Komp M Beeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(21809858595804689)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'218099'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_MASCH_KOMPONENTEN:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:COMM:BEZEICHNUNG:ANZAHL:FK_MASCH_KOMPONENTEN_MAIN:FK_STD_MASCH_ZUORD_VAR_FIX:KOMP_M_BEEICHNUNG'
);
wwv_flow_api.component_end;
end;
/
