prompt --application/shared_components/navigation/lists/add_location_prozess3
begin
--   Manifest
--     LIST: Add Location Prozess3
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(21555110577647066)
,p_name=>'Add Location Prozess3'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21555480900647066)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Step 1 (Land)'
,p_list_item_link_target=>'f?p=&APP_ID.:268:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21555878659647067)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Step 2 (Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:270:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21556215561647067)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Step 3 (PLZ Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:271:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21556619708647067)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Step 4 (Stra\00DFe)')
,p_list_item_link_target=>'f?p=&APP_ID.:274:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21557070394647067)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Step 5 (Location)'
,p_list_item_link_target=>'f?p=&APP_ID.:275:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21557456231647067)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Step 6 (Location / Beleg)'
,p_list_item_link_target=>'f?p=&APP_ID.:276:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
