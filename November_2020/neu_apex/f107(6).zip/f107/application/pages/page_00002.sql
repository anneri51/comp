prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'1-PROJEKTE'
,p_alias=>'1-PROJEKTE'
,p_step_title=>'1-PROJEKTE'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599314024934579)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200903124544'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5226439498321511)
,p_plug_name=>'1-PROJEKTE'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5138571886283855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5225906998321508)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5167472751283873)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5226525693321511)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(5226439498321511)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5100723994283838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20564902338013234)
,p_plug_name=>'Projekte'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select proj.PK_PROJ_PROJEKT,',
'       proj.FK_KON_AUFTRAGGEBER,',
'       proj.FK_KON_PROJEKTPARTNER_1,',
'       proj.FK_KON_PROJEKTPARTNER_2,',
'       proj.PROJEKT,',
'       proj.VON,',
'       proj.BIS,',
'       proj.AKTUELLER_STUNDENSATZ,',
'       proj.PSP_ELEMENT,',
'       proj.CREATED_BY,',
'       proj.CREATED_AT,',
'       proj.MODIFIED_BY,',
'       proj.MODIFIED_AT,',
'       proj.RECHNUNG_GESTELLT,',
'       proj.ZAHLUNG_ABGESCHLOSSEN,',
'       proj.BELEGE_ZUGEORDNET,',
'       proj.KM_GERECHNET,',
'       proj.PROJEKT_ABGESCHLOSSEN,',
'       proj.FK_STD_PROJ_PROJEKT_ART,',
'       proj.FK_LEHR_LEHRGANG,',
'       proj.BILD,',
'       proj.BILD1,',
'       proj.BILD2,',
'       proj.BILD3,',
'       proj.BILD4,',
'       proj.BILD5,',
'       proj.DATEINAME,',
'       proj.DATEINAME1,',
'       proj.DATEINAME2,',
'       proj.DATEINAME3,',
'       proj.DATEINAME4,',
'       proj.DATEINAME5,',
'       proj.DESCR,',
'       proj.COMM,',
'       proj.FK_STD_PROJ_PROJEKT_STATUS,',
'       proj.BILD6,',
'       proj.FILENAME6,',
'       proj.BILD7,',
'       proj.FILENAME7,',
'       proj.LEBENSLAUF_REL,',
'       proj.FK_STD_PROF_JOB_TYPE,',
'       proj.POSITION,',
'       proj.ORT,',
'       proj.PROJEKTINHALTE,',
'       proj.TOOLS,',
'       proj.FLG_PROJ_REFERENZPROJEKT,',
'       proj.TECHN,',
'       proj.OTHER,',
'       proj.REFERENZEN,',
'       proj.ABSCHLUSSNOTE,',
'       proj.FK_KON_PROJEKTPARTNER_3,',
'       proj.FK_MDT_MANDANT,',
'       proj.EXT_PROJEKTNUMMER,',
'       proj.FIXTERMIN_START,',
'       proj.FIXTERMIN_ENDE,',
'       proj.STARTDATUM_GEPLANT,',
'       proj.STARTDATUM_IST,',
'       proj.ENDDATUM_GEPLANT,',
'       proj.ENDDATUM_IST,',
'       proj.ZEITRAUM_GEPLANT,',
'       proj.ZEITRAUM_IST,',
'       proj.FK_STD_PROJ_ZEITRAUM_GEPL_EINHEIT,',
'       proj.FK_STD_PROJ_ZEITRAUM_IST_EINHEIT,',
'       proj.FK_KON_PROJEKTLEITER,',
'       proj.FK_PROJ_REFERENZPROJEKT,',
'       proj.FK_PROJ_PROJEKT_MAIN,',
'       proj_main.projekt main_projekt,',
'       case when proj.pk_proj_projekt = proj.fk_proj_projekt_main then ''Hauptprojekt'' end Hauptprojekt',
'  from T_PROJ_PROJEKT proj',
'    left join t_proj_projekt proj_main on proj.fk_proj_projekt_main = proj_main.pk_proj_projekt',
' where proj.fk_mdt_mandant = 3'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Projekte'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(20565016597013235)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::P11_PK_PROJ_PROJEKT:#PK_PROJ_PROJEKT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>20565016597013235
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565153900013236)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Proj Projekt'
,p_column_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::P40_PK_PROJ_PROJEKT1:#PK_PROJ_PROJEKT#'
,p_column_linktext=>'#PK_PROJ_PROJEKT#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565253206013237)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565359083013238)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565467155013239)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565573072013240)
,p_db_column_name=>'PROJEKT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565655741013241)
,p_db_column_name=>'VON'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565791188013242)
,p_db_column_name=>'BIS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565839377013243)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Aktueller Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20565967259013244)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Psp Element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566015025013245)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566132108013246)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566285947013247)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566343386013248)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566415229013249)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Rechnung Gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20566559306013250)
,p_db_column_name=>'ZAHLUNG_ABGESCHLOSSEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Zahlung Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641388838592301)
,p_db_column_name=>'BELEGE_ZUGEORDNET'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Belege Zugeordnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641473922592302)
,p_db_column_name=>'KM_GERECHNET'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Km Gerechnet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641523245592303)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Projekt Abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641638602592304)
,p_db_column_name=>'FK_STD_PROJ_PROJEKT_ART'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Std Proj Projekt Art'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641752895592305)
,p_db_column_name=>'FK_LEHR_LEHRGANG'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Fk Lehr Lehrgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641886491592306)
,p_db_column_name=>'BILD'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Bild'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20641997861592307)
,p_db_column_name=>'BILD1'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Bild1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642047780592308)
,p_db_column_name=>'BILD2'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Bild2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642127163592309)
,p_db_column_name=>'BILD3'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Bild3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642228015592310)
,p_db_column_name=>'BILD4'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Bild4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642370793592311)
,p_db_column_name=>'BILD5'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Bild5'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642404009592312)
,p_db_column_name=>'DATEINAME'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Dateiname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642503981592313)
,p_db_column_name=>'DATEINAME1'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Dateiname1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642687594592314)
,p_db_column_name=>'DATEINAME2'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Dateiname2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642792297592315)
,p_db_column_name=>'DATEINAME3'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Dateiname3'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642801332592316)
,p_db_column_name=>'DATEINAME4'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Dateiname4'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20642981312592317)
,p_db_column_name=>'DATEINAME5'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Dateiname5'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643074995592318)
,p_db_column_name=>'DESCR'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643186885592319)
,p_db_column_name=>'COMM'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643276321592320)
,p_db_column_name=>'FK_STD_PROJ_PROJEKT_STATUS'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Fk Std Proj Projekt Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643385630592321)
,p_db_column_name=>'BILD6'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Bild6'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643492413592322)
,p_db_column_name=>'FILENAME6'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Filename6'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643597066592323)
,p_db_column_name=>'BILD7'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Bild7'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643650314592324)
,p_db_column_name=>'FILENAME7'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Filename7'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643788189592325)
,p_db_column_name=>'LEBENSLAUF_REL'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Lebenslauf Rel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643805908592326)
,p_db_column_name=>'FK_STD_PROF_JOB_TYPE'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Std Prof Job Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20643900117592327)
,p_db_column_name=>'POSITION'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Position'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644015493592328)
,p_db_column_name=>'ORT'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644134183592329)
,p_db_column_name=>'PROJEKTINHALTE'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Projektinhalte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644236336592330)
,p_db_column_name=>'TOOLS'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Tools'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644313126592331)
,p_db_column_name=>'FLG_PROJ_REFERENZPROJEKT'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Flg Proj Referenzprojekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644427117592332)
,p_db_column_name=>'TECHN'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Techn'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644580703592333)
,p_db_column_name=>'OTHER'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Other'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644635062592334)
,p_db_column_name=>'REFERENZEN'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Referenzen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644755609592335)
,p_db_column_name=>'ABSCHLUSSNOTE'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Abschlussnote'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644824895592336)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_3'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Kon Projektpartner 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20644949285592337)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539331377958329)
,p_db_column_name=>'EXT_PROJEKTNUMMER'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Ext Projektnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539481349958330)
,p_db_column_name=>'FIXTERMIN_START'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Fixtermin Start'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539572045958331)
,p_db_column_name=>'FIXTERMIN_ENDE'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fixtermin Ende'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539607882958332)
,p_db_column_name=>'STARTDATUM_GEPLANT'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Startdatum Geplant'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539788549958333)
,p_db_column_name=>'STARTDATUM_IST'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Startdatum Ist'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539825476958334)
,p_db_column_name=>'ENDDATUM_GEPLANT'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Enddatum Geplant'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11539950484958335)
,p_db_column_name=>'ENDDATUM_IST'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Enddatum Ist'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540030295958336)
,p_db_column_name=>'ZEITRAUM_GEPLANT'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Zeitraum Geplant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540198097958337)
,p_db_column_name=>'ZEITRAUM_IST'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Zeitraum Ist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540223832958338)
,p_db_column_name=>'FK_STD_PROJ_ZEITRAUM_GEPL_EINHEIT'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Std Proj Zeitraum Gepl Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540359572958339)
,p_db_column_name=>'FK_STD_PROJ_ZEITRAUM_IST_EINHEIT'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Fk Std Proj Zeitraum Ist Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540478421958340)
,p_db_column_name=>'FK_KON_PROJEKTLEITER'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Kon Projektleiter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540553128958341)
,p_db_column_name=>'FK_PROJ_REFERENZPROJEKT'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Proj Referenzprojekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540661363958342)
,p_db_column_name=>'FK_PROJ_PROJEKT_MAIN'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Proj Projekt Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540709591958343)
,p_db_column_name=>'MAIN_PROJEKT'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Main Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540848610958344)
,p_db_column_name=>'HAUPTPROJEKT'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Hauptprojekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(20662523985596392)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'206626'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2:PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:RECHNUNG_GESTELLT:ZAHLUNG_ABGESCHLOSSEN:BELEGE_ZUGEORDNET:KM_GERECHNET'
||':PROJEKT_ABGESCHLOSSEN:FK_STD_PROJ_PROJEKT_ART:FK_LEHR_LEHRGANG:BILD:BILD1:BILD2:BILD3:BILD4:BILD5:DATEINAME:DATEINAME1:DATEINAME2:DATEINAME3:DATEINAME4:DATEINAME5:DESCR:COMM:FK_STD_PROJ_PROJEKT_STATUS:BILD6:FILENAME6:BILD7:FILENAME7:LEBENSLAUF_REL:F'
||'K_STD_PROF_JOB_TYPE:POSITION:ORT:PROJEKTINHALTE:TOOLS:FLG_PROJ_REFERENZPROJEKT:TECHN:OTHER:REFERENZEN:ABSCHLUSSNOTE:FK_KON_PROJEKTPARTNER_3:FK_MDT_MANDANT:EXT_PROJEKTNUMMER:FIXTERMIN_START:FIXTERMIN_ENDE:STARTDATUM_GEPLANT:STARTDATUM_IST:ENDDATUM_GEP'
||'LANT:ENDDATUM_IST:ZEITRAUM_GEPLANT:ZEITRAUM_IST:FK_STD_PROJ_ZEITRAUM_GEPL_EINHEIT:FK_STD_PROJ_ZEITRAUM_IST_EINHEIT:FK_KON_PROJEKTLEITER:FK_PROJ_REFERENZPROJEKT:FK_PROJ_PROJEKT_MAIN:MAIN_PROJEKT:HAUPTPROJEKT'
,p_break_on=>'MAIN_PROJEKT'
,p_break_enabled_on=>'MAIN_PROJEKT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(12528851346269312)
,p_report_id=>wwv_flow_api.id(20662523985596392)
,p_name=>'Hauptprojekt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HAUPTPROJEKT'
,p_operator=>'='
,p_expr=>'Hauptprojekt'
,p_condition_sql=>' (case when ("HAUPTPROJEKT" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Hauptprojekt''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#CCE5FF'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23336396962454118)
,p_plug_name=>'Personen'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select relprojper.PK_REL_PROJ_PROJECT_PERSON,',
'       relprojper.FK_MDT_MANDANT,',
'       relprojper.CREATED_AT,',
'       relprojper.MODIFIED_AT,',
'       relprojper.FK_PROJ_PROJECT,',
'       relprojper.FK_KON_PERSON,',
'       relprojper.FK_REL_KON_PERSON_ROLE,',
'       relprojper.FK_STD_KON_PERSON_ROLE_PROJECT,',
'       proj.projekt,',
'       proj_main.projekt main_projekt,',
'       pers.vorname,',
'       pers.nachname,',
'       stdperrole.std_name,',
'       inp.bezeichnung,',
'       inp.az_sollstunden,',
'       inp.az_stundenzahl,',
'       inp.az_ueberstunden,',
'       inp.fahrzeit',
'  from T_REL_PROJ_PROJECT_PERSON relprojper',
'   join (select * from t_proj_projekt where fk_std_proj_projekT_art in (124, 127) ) proj on proj.pk_proj_projekt = relprojper.fk_proj_project',
'   left join t_proj_projekt proj_main on proj_main.pk_proj_projekt = proj.fk_proj_projekt_main',
'   left join t_rel_kon_person_role relpers on relpers.pk_rel_kon_person_role = relprojper.fk_rel_kon_person_role',
'   left join t_kon_person pers on pers.pk_kon_person = relpers.fk_kon_person',
'   left join (select * from t_std where fk_std_group = 723) stdperrole on stdperrole.std_value = relprojper.fk_std_kon_person_role_project',
'   left join (select * from t_inp_belege_all where fk_bas_kat_kategorie =98) inp on inp.fk_kon_person = pers.pk_kon_person and inp.fk_proj_projekt = proj.pk_proj_Projekt',
'  where relprojper.fk_mdt_mandant = :P0_FK_MDT_Mandant'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(23336480358454119)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>23336480358454119
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13335623095414123)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13336054764414127)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13336418634414127)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13336881828414127)
,p_db_column_name=>'PK_REL_PROJ_PROJECT_PERSON'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Pk Rel Proj Project Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13337292640414127)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13337643953414128)
,p_db_column_name=>'FK_PROJ_PROJECT'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Fk Proj Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13338050964414128)
,p_db_column_name=>'FK_REL_KON_PERSON_ROLE'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Fk Rel Kon Person Role'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13338470748414128)
,p_db_column_name=>'FK_STD_KON_PERSON_ROLE_PROJECT'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Fk Std Kon Person Role Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13338885568414128)
,p_db_column_name=>'PROJEKT'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13339235796414129)
,p_db_column_name=>'MAIN_PROJEKT'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Main Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13339623989414129)
,p_db_column_name=>'VORNAME'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13340033217414129)
,p_db_column_name=>'NACHNAME'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13340492334414129)
,p_db_column_name=>'STD_NAME'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245257550475425)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245346134475426)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245489876475427)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>180
,p_column_identifier=>'S'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245546880475428)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13246107312475434)
,p_db_column_name=>'FAHRZEIT'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(23347886481482862)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'133408'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_KON_PERSON:CREATED_AT:MODIFIED_AT:PK_REL_PROJ_PROJECT_PERSON:FK_MDT_MANDANT:FK_PROJ_PROJECT:FK_REL_KON_PERSON_ROLE:FK_STD_KON_PERSON_ROLE_PROJECT:PROJEKT:MAIN_PROJEKT:VORNAME:NACHNAME:STD_NAME:BEZEICHNUNG:AZ_SOLLSTUNDEN:AZ_STUNDENZAHL:AZ_UEBERSTUN'
||'DEN:FAHRZEIT'
,p_break_on=>'MAIN_PROJEKT'
,p_break_enabled_on=>'MAIN_PROJEKT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(20645153439592339)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(20564902338013234)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::P11_PK_PROJ_PROJEKT:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5228222853321512)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5226439498321511)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5228506428321512)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5226439498321511)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(5190363820283892)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5229275524321513)
,p_branch_action=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5228506428321512)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5227977676321511)
,p_name=>'P2_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5226525693321511)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
