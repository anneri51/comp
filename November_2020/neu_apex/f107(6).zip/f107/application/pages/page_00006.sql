prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'Materialzuordnungen'
,p_alias=>'MATERIALZUORDNUNGEN'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Materialzuordnungen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599502027938369)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200828155712'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5242544540321520)
,p_plug_name=>'Step 5'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5138571886283855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5299807257335305)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5167472751283873)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5242628436321520)
,p_plug_name=>'Step 5'
,p_parent_plug_id=>wwv_flow_api.id(5242544540321520)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5100723994283838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22058448281712115)
,p_plug_name=>'Komponenten'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'  select relkm.*,',
'  komp.pk_masch_komponenten,',
'  komp.bezeichnung,',
'  matm.pk_masch_material main_pk_masch_material,',
'  matm.materialbezeichnung main_materialbezeichnung,',
'    mat.pk_masch_material pk_masch_material,',
'  mat.materialbezeichnung materialbezeichnung',
'from t_masch_komponenten komp',
' left join t_rel_masch_komp_komponente_material relkm on relkm.fk_masch_komponente = komp.pk_masch_komponenten',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.fk_rel_masch_mat_material_material_main',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
'   )',
'   select *',
'   from bas',
'where fK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Komponenten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22058650504712117)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>22058650504712117
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058769319712118)
,p_db_column_name=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Komp Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058843920712119)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058968980712120)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059097598712121)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059135283712122)
,p_db_column_name=>'FK_MASCH_KOMPONENTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Komponente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059206248712123)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059363989712124)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059448212712125)
,p_db_column_name=>'FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059583600712126)
,p_db_column_name=>'PK_MASCH_KOMPONENTEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Masch Komponenten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059655661712127)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059758545712128)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059811651712129)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22059910570712130)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060056556712131)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22107217388896433)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'221073'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_KOMPONENTE:COMM:FK_STD_MASCH_ZUORD_VAR_FIX:FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:PK_MASCH_KOMPONENTEN:BEZEICHNUNG:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:P'
||'K_MASCH_MATERIAL:MATERIALBEZEICHNUNG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22058587050712116)
,p_plug_name=>'Band_Station'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'  select relstm.*,',
' stm.stationsbezeichnung,',
'    stm.pk_masch_band_station,',
'  matm.pk_masch_material main_pk_masch_material,',
'  matm.materialbezeichnung main_materialbezeichnung,',
'    mat.pk_masch_material pk_masch_material,',
'  mat.materialbezeichnung materialbezeichnung,',
'    relmatm.pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'from t_masch_band_station stm',
' left join t_rel_masch_band_station_material relstm on relstm.fk_masch_band_station = stm.pk_masch_band_station',
' left join t_rel_masch_komp_komponente_material relkm on relkm.PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL = relstm.fk_rel_masch_komp_komponente_material',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
'   )',
'   select *',
'   from bas',
'where pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Band_Station'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22060443415712135)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>22060443415712135
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060522774712136)
,p_db_column_name=>'PK_REL_MASCH_BAND_STATION_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Band Station Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060615357712137)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060741929712138)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060877572712139)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22060992986712140)
,p_db_column_name=>'FK_MASCH_BAND_STATION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Band Station'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061198856712142)
,p_db_column_name=>'COMM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061205972712143)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061310481712144)
,p_db_column_name=>'PK_MASCH_BAND_STATION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Pk Masch Band Station'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061443689712145)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061508563712146)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061627374712147)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061767134712148)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061832578712149)
,p_db_column_name=>'FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Rel Masch Komp Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22061968737712150)
,p_db_column_name=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Pk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22115035500981720)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'221151'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_BAND_STATION_MATERIAL:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_BAND_STATION:COMM:STATIONSBEZEICHNUNG:PK_MASCH_BAND_STATION:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:PK_MASCH_MATERIAL:MATERIALBEZEICHNUNG:FK_REL_MASCH_KOMP_KOMP'
||'ONENTE_MATERIAL:PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22060119034712132)
,p_plug_name=>'Select'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22094322470793973)
,p_plug_name=>'Materialzuordnungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from (select relmatm.*, ',
' mat_m.pk_masch_material main_pk_masch_material,',
' mat_m.materialbezeichnung main_materialbezeichnung,',
' mat.pk_masch_material pk_masch_material,',
' mat.materialbezeichnung materialbezeichnung,',
' kat.std_name kategorie',
' ',
'',
'from T_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm',
' left join t_masch_material mat_m on mat_m.pk_masch_material = relmatm.fk_masch_material_main',
'  left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join (select * from t_std where fk_std_group = 803) kat on kat.std_value = mat.fk_std_masch_mat_kategorie',
'where (PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null)',
'      )',
'where ( pk_masch_material = :P6_FK_MASCH_MATERIAL or :P6_FK_MASCH_MATERIAL is null  )'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Materialzuordnungen'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22094419798793973)
,p_name=>'Materialzuordnungen'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:#PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>22094419798793973
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22094864313793978)
,p_db_column_name=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22095268088793979)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22095609807793979)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22096065371793979)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22096462135793979)
,p_db_column_name=>'FK_MASCH_MATERIAL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22096819668793980)
,p_db_column_name=>'FK_MASCH_MATERIAL_MAIN'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fk Masch Material Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22097278244793980)
,p_db_column_name=>'COMM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22097684063793980)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22098066044793980)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22098406863793981)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22098864908793981)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058370365712114)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9868639030748924)
,p_db_column_name=>'ANZAHL'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22106652044896427)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'221067'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_MATERIAL:FK_MASCH_MATERIAL_MAIN:COMM:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:PK_MASCH_MATERIAL:MATERIALBEZEICHNUNG:KATEGORIE:ANZAHL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22060310179712134)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22060119034712132)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Reset'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN,P6_PK_MASCH_MATERIAL:,'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9870784684748945)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22060119034712132)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9868482709748922)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22060119034712132)
,p_button_name=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5244373327321521)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5242544540321520)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5244603507321521)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5242544540321520)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(5190363820283892)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5244524592321521)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5242544540321520)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5189510317283890)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5246015799321522)
,p_branch_action=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5244603507321521)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5245391540321522)
,p_branch_action=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5244524592321521)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5244056593321521)
,p_name=>'P6_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5242628436321520)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9867693700748914)
,p_name=>'P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'Pk Rel Masch Mat Material Material Main'
,p_source=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9867753743748915)
,p_name=>'P6_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_default=>'P0_FK_MDT_MANDANT'
,p_item_default_type=>'ITEM'
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_MDT_MANDANT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant D, pk_mdt_mandant R',
'from t_mdt_mandant',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9867805001748916)
,p_name=>'P6_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9867970536748917)
,p_name=>'P6_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9868092682748918)
,p_name=>'P6_FK_MASCH_MATERIAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'<b><i>Fk Masch Material<i><b>'
,p_source=>'FK_MASCH_MATERIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select materialbezeichnung || '' '' || grundpreis d, pk_masch_material',
'from t_masch_material'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9868177647748919)
,p_name=>'P6_FK_MASCH_MATERIAL_MAIN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'<b>Fk Masch Material Main<b>'
,p_source=>'FK_MASCH_MATERIAL_MAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select materialbezeichnung || '' '' || grundpreis d, pk_masch_material',
'from t_masch_material'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9868253744748920)
,p_name=>'P6_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9868325302748921)
,p_name=>'P6_ANZAHL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(22060119034712132)
,p_item_source_plug_id=>wwv_flow_api.id(22060119034712132)
,p_prompt=>'Anzahl'
,p_source=>'ANZAHL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9868534737748923)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(22060119034712132)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'add materialzuordnun'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9868960747748927)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22060119034712132)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'New'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_process_when2=>'0'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9869096236748928)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  If :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN =0 then',
'   :P6_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN := null;',
'  end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
