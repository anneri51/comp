prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'4 - Inbetriebnahme'
,p_alias=>'4-INBETRIEBNAHME'
,p_step_title=>'4 - Inbetriebnahme'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599314024934579)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200903155127'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5246778573321523)
,p_plug_name=>'Step 6'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5138571886283855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5262971475329612)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5167472751283873)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5246836983321523)
,p_plug_name=>'Step 6'
,p_parent_plug_id=>wwv_flow_api.id(5246778573321523)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5100723994283838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9870837479748946)
,p_plug_name=>'Inbetriebnahme'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inb.PK_proj_projekt,',
'       inb.FK_MDT_MANDANT,',
'       inb.CREATED_AT,',
'       inb.MODIFIED_AT,',
'       inb.fk_std_proj_projekt_art,',
'       loc.pK_LOC_LOCATION,',
'  ',
'       loc.location, ',
'       inb.projekt',
'  from (select * from  T_proj_projekt where fk_std_proj_projekt_art =127 ) inb',
'  left join t_rel_proj_project_location relprojloc on relprojloc.fk_proj_projekt = inb.pk_proj_projekt',
'   left join v_loc_location loc on loc.pk_loc_location = relprojloc.fk_loc_location'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Inbetriebnahme'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9870955222748947)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>9870955222748947
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9871195068748949)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9871255553748950)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10000486670040001)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10000869160040005)
,p_db_column_name=>'LOCATION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Location'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10000907287040006)
,p_db_column_name=>'PROJEKT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13243981357475412)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244057490475413)
,p_db_column_name=>'PK_LOC_LOCATION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244112637475414)
,p_db_column_name=>'FK_STD_PROJ_PROJEKT_ART'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Std Proj Projekt Art'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10007960181040901)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'100080'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_PROJ_FK_LOC_FK_STD_MASCH_PROJ_INBETRIEBNAHME_TYPE:LOCATION:PROJEKT:PK_PROJ_PROJEKT:PK_LOC_LOCATION:FK_STD_PROJ_PROJEKT_ART'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10001059178040007)
,p_plug_name=>'Personen-Stunden'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select relprojper.PK_REL_PROJ_PROJECT_PERSON,',
'       relprojper.FK_MDT_MANDANT,',
'       relprojper.CREATED_AT,',
'       relprojper.MODIFIED_AT,',
'       relprojper.FK_PROJ_PROJECT,',
'       relprojper.FK_KON_PERSON,',
'       relprojper.FK_REL_KON_PERSON_ROLE,',
'       relprojper.FK_STD_KON_PERSON_ROLE_PROJECT,',
'       proj.projekt,',
'       proj_main.projekt main_projekt,',
'       pers.vorname,',
'       pers.nachname,',
'       stdperrole.std_name,',
'       inp.bezeichnung,',
'       inp.az_sollstunden,',
'       inp.az_stundenzahl,',
'       inp.az_ueberstunden,',
'       inp.az_fahrzeit,',
'       pers.pk_kon_person pers_pk_kon_person,',
'       pk_inp_belege_all,',
'       inp.bezeichnung inp_bezeichnung,',
'       stdnorm.stundensatz norm_stundensatz,',
'       stdueber.stundensatz Ueberstunden_stundensatz,',
'       stdwe.stundensatz we_stundensatz,',
'       stdfahr.stundensatz Fahrzeit_stundensatz,',
'       inp.az_sollstunden * stdNorm.stundensatz norm_preis,',
'       inp.az_ueberstunden * stdueber.stundensatz ueberstunden_preis,',
'       inp.az_fahrzeit * stdfahr.stundensatz fahrzeit_preis,',
'       nvl(    inp.az_sollstunden * stdNorm.stundensatz,0) + nvl(inp.az_ueberstunden * stdueber.stundensatz ,0)+nvl(inp.az_fahrzeit * stdfahr.stundensatz,0) preis_pro_person',
'  from T_REL_PROJ_PROJECT_PERSON relprojper',
'   join (select * from t_proj_projekt where fk_std_proj_projekT_art = 127) proj on proj.pk_proj_projekt = relprojper.fk_proj_project',
'   left join t_proj_projekt proj_main on proj_main.pk_proj_projekt = proj.fk_proj_projekt_main',
'   left join t_rel_kon_person_role relpers on relpers.pk_rel_kon_person_role = relprojper.fk_rel_kon_person_role',
'   left join t_kon_person pers on pers.pk_kon_person = relpers.fk_kon_person',
'   left join (select * from t_std where fk_std_group = 723) stdperrole on stdperrole.std_value = relprojper.fk_std_kon_person_role_project',
'   left join (select * from t_inp_belege_all where fk_bas_kat_kategorie =98) inp on inp.fk_kon_person = pers.pk_kon_person and inp.fk_proj_projekt = proj.pk_proj_Projekt',
'   left join v_work_stundensatz stdnorm on stdnorm.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ',
'   left join v_work_stundensatz stdueber on stdueber.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_Ueberstunden',
'   left join v_work_stundensatz stdwe on stdwe.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_wochenende',
'   left join v_work_stundensatz stdfahr on stdfahr.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_fahrzeit',
'  where relprojper.fk_mdt_mandant = :P0_FK_MDT_Mandant'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personen-Stunden'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10001142574040008)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>10001142574040008
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10001482681040011)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10001508302040012)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10001659830040013)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244285308475415)
,p_db_column_name=>'PK_REL_PROJ_PROJECT_PERSON'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Pk Rel Proj Project Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244342163475416)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244465054475417)
,p_db_column_name=>'FK_PROJ_PROJECT'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Fk Proj Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244579946475418)
,p_db_column_name=>'FK_REL_KON_PERSON_ROLE'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Fk Rel Kon Person Role'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244628813475419)
,p_db_column_name=>'FK_STD_KON_PERSON_ROLE_PROJECT'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Fk Std Kon Person Role Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244713663475420)
,p_db_column_name=>'PROJEKT'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244837948475421)
,p_db_column_name=>'MAIN_PROJEKT'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Main Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13244934310475422)
,p_db_column_name=>'VORNAME'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245040768475423)
,p_db_column_name=>'NACHNAME'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245109555475424)
,p_db_column_name=>'STD_NAME'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245620468475429)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245753640475430)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245853754475431)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>180
,p_column_identifier=>'S'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13245950771475432)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13370820726645301)
,p_db_column_name=>'AZ_FAHRZEIT'
,p_display_order=>200
,p_column_identifier=>'V'
,p_column_label=>'Az Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13370922733645302)
,p_db_column_name=>'PERS_PK_KON_PERSON'
,p_display_order=>210
,p_column_identifier=>'W'
,p_column_label=>'Pers Pk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371012993645303)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>220
,p_column_identifier=>'X'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::P54_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371103352645304)
,p_db_column_name=>'INP_BEZEICHNUNG'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>'Inp Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371357189645306)
,p_db_column_name=>'NORM_STUNDENSATZ'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>'Norm Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371494335645307)
,p_db_column_name=>'UEBERSTUNDEN_STUNDENSATZ'
,p_display_order=>250
,p_column_identifier=>'AA'
,p_column_label=>'Ueberstunden Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371550167645308)
,p_db_column_name=>'WE_STUNDENSATZ'
,p_display_order=>260
,p_column_identifier=>'AB'
,p_column_label=>'We Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371696187645309)
,p_db_column_name=>'FAHRZEIT_STUNDENSATZ'
,p_display_order=>270
,p_column_identifier=>'AC'
,p_column_label=>'Fahrzeit Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371751091645310)
,p_db_column_name=>'NORM_PREIS'
,p_display_order=>280
,p_column_identifier=>'AD'
,p_column_label=>'Norm Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371817114645311)
,p_db_column_name=>'UEBERSTUNDEN_PREIS'
,p_display_order=>290
,p_column_identifier=>'AE'
,p_column_label=>'Ueberstunden Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13371908812645312)
,p_db_column_name=>'FAHRZEIT_PREIS'
,p_display_order=>300
,p_column_identifier=>'AF'
,p_column_label=>'Fahrzeit Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372033485645313)
,p_db_column_name=>'PREIS_PRO_PERSON'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'Preis Pro Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10012548697068751)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'100126'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_KON_PERSON:CREATED_AT:MODIFIED_AT:PK_REL_PROJ_PROJECT_PERSON:FK_MDT_MANDANT:FK_PROJ_PROJECT:FK_REL_KON_PERSON_ROLE:FK_STD_KON_PERSON_ROLE_PROJECT:PROJEKT:MAIN_PROJEKT:VORNAME:NACHNAME:STD_NAME:BEZEICHNUNG:AZ_SOLLSTUNDEN:AZ_STUNDENZAHL:AZ_UEBERSTUN'
||'DEN:AZ_FAHRZEIT:PERS_PK_KON_PERSON:PK_INP_BELEGE_ALL:INP_BEZEICHNUNG:NORM_STUNDENSATZ:UEBERSTUNDEN_STUNDENSATZ:WE_STUNDENSATZ:FAHRZEIT_STUNDENSATZ:NORM_PREIS:UEBERSTUNDEN_PREIS:FAHRZEIT_PREIS:PREIS_PRO_PERSON'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13372102537645314)
,p_plug_name=>'Personen-Reisekosten'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select relprojper.PK_REL_PROJ_PROJECT_PERSON,',
'       relprojper.FK_MDT_MANDANT,',
'       relprojper.CREATED_AT,',
'       relprojper.MODIFIED_AT,',
'       relprojper.FK_PROJ_PROJECT,',
'       relprojper.FK_KON_PERSON,',
'       relprojper.FK_REL_KON_PERSON_ROLE,',
'       relprojper.FK_STD_KON_PERSON_ROLE_PROJECT,',
'       proj.projekt,',
'       proj_main.projekt main_projekt,',
'       pers.vorname,',
'       pers.nachname,',
'       stdperrole.std_name,',
'       inp.bezeichnung,',
'       inp.az_sollstunden,',
'       inp.az_stundenzahl,',
'       inp.az_ueberstunden,',
'       inp.az_fahrzeit,',
'       pers.pk_kon_person pers_pk_kon_person,',
'       pk_inp_belege_all,',
'       inp.bezeichnung inp_bezeichnung,',
'       stdnorm.stundensatz norm_stundensatz,',
'       stdueber.stundensatz Ueberstunden_stundensatz,',
'       stdwe.stundensatz we_stundensatz,',
'       stdfahr.stundensatz Fahrzeit_stundensatz,',
'       inp.az_sollstunden * stdNorm.stundensatz norm_preis,',
'       inp.az_ueberstunden * stdueber.stundensatz ueberstunden_preis,',
'       inp.az_fahrzeit * stdfahr.stundensatz fahrzeit_preis,',
'       nvl(    inp.az_sollstunden * stdNorm.stundensatz,0) + nvl(inp.az_ueberstunden * stdueber.stundensatz ,0)+nvl(inp.az_fahrzeit * stdfahr.stundensatz,0) preis_pro_person,',
'       menge,',
'       stdmenge.std_name mengeneinheit,',
'       soll_brutto_betrag',
'  from T_REL_PROJ_PROJECT_PERSON relprojper',
'   join (select * from t_proj_projekt where fk_std_proj_projekT_art = 127) proj on proj.pk_proj_projekt = relprojper.fk_proj_project',
'   left join t_proj_projekt proj_main on proj_main.pk_proj_projekt = proj.fk_proj_projekt_main',
'   left join t_rel_kon_person_role relpers on relpers.pk_rel_kon_person_role = relprojper.fk_rel_kon_person_role',
'   left join t_kon_person pers on pers.pk_kon_person = relpers.fk_kon_person',
'   left join (select * from t_std where fk_std_group = 723) stdperrole on stdperrole.std_value = relprojper.fk_std_kon_person_role_project',
'   left join (select * from t_inp_belege_all inp join t_bas_kat_kategorie kat on inp.fk_bas_kat_kategorie = kat.pk_bas_kat_kategorie where fk_bas_kat_oberkategorie = ''694'') inp on inp.fk_kon_person = pers.pk_kon_person and inp.fk_proj_projekt = proj.'
||'pk_proj_Projekt',
'   left join v_work_stundensatz stdnorm on stdnorm.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ',
'   left join v_work_stundensatz stdueber on stdueber.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_Ueberstunden',
'   left join v_work_stundensatz stdwe on stdwe.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_wochenende',
'   left join v_work_stundensatz stdfahr on stdfahr.pk_work_stundensatz = inp.FK_WORK_STUNDENSATZ_fahrzeit',
'   left join (select * from t_std where fk_std_group = 883) stdmenge on stdmenge.std_value = inp.fk_std_inp_menge_einheit',
'  where relprojper.fk_mdt_mandant = :P0_FK_MDT_Mandant'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personen-Reisekosten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13372201744645315)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13372201744645315
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372321049645316)
,p_db_column_name=>'UEBERSTUNDEN_STUNDENSATZ'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ueberstunden Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372412835645317)
,p_db_column_name=>'WE_STUNDENSATZ'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'We Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372577047645318)
,p_db_column_name=>'FAHRZEIT_STUNDENSATZ'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fahrzeit Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372602651645319)
,p_db_column_name=>'NORM_PREIS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Norm Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372786324645320)
,p_db_column_name=>'UEBERSTUNDEN_PREIS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ueberstunden Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372861659645321)
,p_db_column_name=>'FAHRZEIT_PREIS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fahrzeit Preis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13372942998645322)
,p_db_column_name=>'PREIS_PRO_PERSON'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Preis Pro Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373050605645323)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373192066645324)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373210459645325)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373304102645326)
,p_db_column_name=>'PK_REL_PROJ_PROJECT_PERSON'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Pk Rel Proj Project Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373448117645327)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373507171645328)
,p_db_column_name=>'FK_PROJ_PROJECT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fk Proj Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373612111645329)
,p_db_column_name=>'FK_REL_KON_PERSON_ROLE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Rel Kon Person Role'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373708448645330)
,p_db_column_name=>'FK_STD_KON_PERSON_ROLE_PROJECT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fk Std Kon Person Role Project'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373869978645331)
,p_db_column_name=>'PROJEKT'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13373992920645332)
,p_db_column_name=>'MAIN_PROJEKT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Main Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374057351645333)
,p_db_column_name=>'VORNAME'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374191997645334)
,p_db_column_name=>'NACHNAME'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374212577645335)
,p_db_column_name=>'STD_NAME'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374301826645336)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374473804645337)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374536511645338)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374682005645339)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374717909645340)
,p_db_column_name=>'AZ_FAHRZEIT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Az Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374802862645341)
,p_db_column_name=>'PERS_PK_KON_PERSON'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Pers Pk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13374984317645342)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::P54_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13375085519645343)
,p_db_column_name=>'INP_BEZEICHNUNG'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Inp Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13375104483645344)
,p_db_column_name=>'NORM_STUNDENSATZ'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Norm Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13408312526282110)
,p_db_column_name=>'MENGE'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13408406360282111)
,p_db_column_name=>'MENGENEINHEIT'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Mengeneinheit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13408586029282112)
,p_db_column_name=>'SOLL_BRUTTO_BETRAG'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Soll Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13405249324123421)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134053'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'UEBERSTUNDEN_STUNDENSATZ:WE_STUNDENSATZ:FAHRZEIT_STUNDENSATZ:NORM_PREIS:UEBERSTUNDEN_PREIS:FAHRZEIT_PREIS:PREIS_PRO_PERSON:FK_KON_PERSON:CREATED_AT:MODIFIED_AT:PK_REL_PROJ_PROJECT_PERSON:FK_MDT_MANDANT:FK_PROJ_PROJECT:FK_REL_KON_PERSON_ROLE:FK_STD_KO'
||'N_PERSON_ROLE_PROJECT:PROJEKT:MAIN_PROJEKT:VORNAME:NACHNAME:STD_NAME:BEZEICHNUNG:AZ_SOLLSTUNDEN:AZ_STUNDENZAHL:AZ_UEBERSTUNDEN:AZ_FAHRZEIT:PERS_PK_KON_PERSON:PK_INP_BELEGE_ALL:INP_BEZEICHNUNG:NORM_STUNDENSATZ:MENGE:MENGENEINHEIT:SOLL_BRUTTO_BETRAG'
,p_sum_columns_on_break=>'SOLL_BRUTTO_BETRAG'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5248517484321523)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5246778573321523)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5248866302321524)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5246778573321523)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(5190363820283892)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5248744578321524)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5246778573321523)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5189510317283890)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5250299427321524)
,p_branch_action=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5248866302321524)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5249560015321524)
,p_branch_action=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5248744578321524)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5248257685321523)
,p_name=>'P7_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5246836983321523)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
