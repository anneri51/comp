prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>29
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'Komponenten_Materialzuordnung'
,p_alias=>'KOMPONENTEN_MATERIALZUORDNUNG'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Komponenten_Materialzuordnung'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599502027938369)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200828112451'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5337249749342641)
,p_plug_name=>'Step 1'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5138571886283855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5299807257335305)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5167472751283873)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5337396647342641)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(5337249749342641)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5100723994283838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22346196766526024)
,p_plug_name=>'Materialzuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22346296714526025)
,p_plug_name=>'Station zuordnen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22405453831857042)
,p_plug_name=>'Komponenten_Materialzuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22586455840158318)
,p_plug_name=>'tab'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(20465750138983140)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44892810324151427)
,p_plug_name=>'Komponentenzuordnung'
,p_parent_plug_id=>wwv_flow_api.id(22586455840158318)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select komp.*, relkm.fk_masch_komponente, mam.pk_masch_material main_pk_masch_material, ma.pk_masch_material, mam.materialbezeichnung main_materialbezeichnung , ma.materialbezeichnung, st.stationsbezeichnung, ma.grundpreis, pk_rel_masch_komp_komponen'
||'te_material, pk_rel_masch_komp_komponenten_komponenten',
'from t_masch_komponenten komp',
' left join t_rel_masch_komp_komponenten_komponenten relkk on relkk.fk_masch_komponenten = komp.pk_masch_komponenten',
' left join t_rel_masch_komp_komponente_material relkm on relkm.fk_rel_masch_komp_komponenten_komponenten = relkk.pk_rel_masch_komp_komponenten_komponenten',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.fk_rel_masch_mat_material_material_main',
' left join t_masch_material mam on mam.pk_masch_material = relmatm.fk_masch_material_main',
' left join t_masch_material ma on ma.pk_masch_material = relmatm.fk_masch_material',
' left join t_rel_masch_band_station_komponente_material relstm on relstm.fk_rel_masch_komp_komponente_material = relkm.pk_rel_masch_komp_komponente_material',
' left join t_masch_band_stationen st on st.pk_masch_band_stationen = relstm.fk_masch_band_station'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Komponentenzuordnung'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44892864285151428)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:#PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>44892864285151428
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22548719929625429)
,p_db_column_name=>'PK_MASCH_KOMPONENTEN'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Masch Komponenten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22549158197625429)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22549525518625430)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22549987917625430)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22550371583625430)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22550792603625431)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22551129330625431)
,p_db_column_name=>'ANZAHL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22551547932625431)
,p_db_column_name=>'FK_MASCH_KOMPONENTEN_MAIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Masch Komponenten Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22551920299625431)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22552395115625432)
,p_db_column_name=>'FK_STD_MASCH_KOMP_SORT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Std Masch Komp Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22552765836625432)
,p_db_column_name=>'FK_MASCH_KOMPONENTE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Masch Komponente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22553130883625432)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22553537405625432)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22553943400625433)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22554357465625433)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22554787737625433)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787305916048808)
,p_db_column_name=>'GRUNDPREIS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Grundpreis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787433578048809)
,p_db_column_name=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Pk Rel Masch Komp Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787517908048810)
,p_db_column_name=>'PK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Pk Rel Masch Komp Komponenten Komponenten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44937029116333739)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'225551'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_MASCH_KOMPONENTEN:FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:COMM:BEZEICHNUNG:ANZAHL:FK_MASCH_KOMPONENTEN_MAIN:FK_STD_MASCH_ZUORD_VAR_FIX:FK_STD_MASCH_KOMP_SORT:FK_MASCH_KOMPONENTE:MAIN_PK_MASCH_MATERIAL:PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:MATER'
||'IALBEZEICHNUNG:STATIONSBEZEICHNUNG:GRUNDPREIS:PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:PK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN'
,p_break_on=>'PK_MASCH_KOMPONENTEN:BEZEICHNUNG'
,p_break_enabled_on=>'PK_MASCH_KOMPONENTEN:BEZEICHNUNG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(66967854757323097)
,p_plug_name=>'Band_Station'
,p_parent_plug_id=>wwv_flow_api.id(22586455840158318)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(20457067247983136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with bas as (',
'  select relstm.*,',
' stm.stationsbezeichnung,',
'    stm.pk_masch_band_stationen,',
'  matm.pk_masch_material main_pk_masch_material,',
'  matm.materialbezeichnung main_materialbezeichnung,',
'    mat.pk_masch_material pk_masch_material,',
'  mat.materialbezeichnung materialbezeichnung,',
'    relmatm.pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN,',
'    komp.bezeichnung komp_bezeichnung,',
'    mat.grundpreis,',
'   relkm.position komp_material_position,',
'    komp.fk_std_masch_komp_sort komp_position',
'from t_masch_band_stationen stm',
' left join t_rel_masch_band_station_komponente_material relstm on relstm.fk_masch_band_station = stm.pk_masch_band_stationen',
' left join t_rel_masch_komp_komponente_material relkm on relkm.PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL = relstm.fk_rel_masch_komp_komponente_material',
' left join t_rel_masch_mat_material_material_main relmatm on relmatm.pk_rel_masch_mat_material_material_main = relkm.FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
'    left join t_masch_komponenten komp on komp.pk_masch_komponenten = relkm.fk_masch_komponente',
'   )',
'   select *',
'   from bas',
'where pK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = :P29_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN or :P29_PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Band_Station'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(66969711122323116)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>66969711122323116
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22608323880350784)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22608740532350784)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22609168038350784)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22609510246350785)
,p_db_column_name=>'FK_MASCH_BAND_STATION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Masch Band Station'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22609918233350785)
,p_db_column_name=>'COMM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22610370622350786)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22611135762350786)
,p_db_column_name=>'MAIN_PK_MASCH_MATERIAL'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Main Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22611563021350787)
,p_db_column_name=>'MAIN_MATERIALBEZEICHNUNG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Main Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22611918247350787)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Pk Masch Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22612390693350787)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22612753889350788)
,p_db_column_name=>'FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Rel Masch Komp Komponente Material'
,p_column_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:#FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL#'
,p_column_linktext=>'#FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22613178242350788)
,p_db_column_name=>'PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Pk Rel Masch Mat Material Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22586501402158319)
,p_db_column_name=>'POSITION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22586621894158320)
,p_db_column_name=>'ANZAHL'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22586755216158321)
,p_db_column_name=>'KOMP_BEZEICHNUNG'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Komp Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22586844964158322)
,p_db_column_name=>'GRUNDPREIS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Grundpreis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22587026389158324)
,p_db_column_name=>'KOMP_MATERIAL_POSITION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Komp Material Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22587181343158325)
,p_db_column_name=>'KOMP_POSITION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Komp Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787059956048805)
,p_db_column_name=>'PK_REL_MASCH_BAND_STATION_KOMPONENTE_MATERIAL'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Pk Rel Masch Band Station Komponente Material'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787116896048806)
,p_db_column_name=>'PK_MASCH_BAND_STATIONEN'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Pk Masch Band Stationen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(67024303207592701)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'226135'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MDT_MANDANT:CREATED_AT:MODIFIED_AT:FK_MASCH_BAND_STATION:COMM:STATIONSBEZEICHNUNG:MAIN_PK_MASCH_MATERIAL:MAIN_MATERIALBEZEICHNUNG:PK_MASCH_MATERIAL:MATERIALBEZEICHNUNG:FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL:PK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN:P'
||'OSITION:ANZAHL:KOMP_BEZEICHNUNG:GRUNDPREIS:KOMP_MATERIAL_POSITION:KOMP_POSITION:PK_REL_MASCH_BAND_STATION_KOMPONENTE_MATERIAL:PK_MASCH_BAND_STATIONEN'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
,p_break_on=>'KOMP_BEZEICHNUNG'
,p_break_enabled_on=>'KOMP_BEZEICHNUNG'
,p_sum_columns_on_break=>'GRUNDPREIS:ANZAHL'
,p_count_columns_on_break=>'PK_REL_MASCH_BAND_STATION_MATERIAL'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(22625169119643919)
,p_report_id=>wwv_flow_api.id(67024303207592701)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STATIONSBEZEICHNUNG'
,p_operator=>'='
,p_expr=>'Station 5'
,p_condition_sql=>'"STATIONSBEZEICHNUNG" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Station 5''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22346567129526028)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22346296714526025)
,p_button_name=>'Station_anlegen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Station Anlegen'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22347055099526033)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22346196766526024)
,p_button_name=>'Material_anlegen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Material Anlegen'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22346482012526027)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22346296714526025)
,p_button_name=>'Station_zuordnen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Station Zuordnen'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22347109450526034)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22346196766526024)
,p_button_name=>'Material_zuordnen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Material Zuordnen'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22412523653857060)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22405453831857042)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5339073170342643)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5337249749342641)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22411330811857057)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(22405453831857042)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22346372084526026)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(22405453831857042)
,p_button_name=>'Komponente_anlegen'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Komponente Anlegen'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22412936172857060)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(22405453831857042)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22412160469857060)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22405453831857042)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5339342388342643)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5337249749342641)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(5190363820283892)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(22413264266857061)
,p_branch_action=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5340070870342643)
,p_branch_action=>'f?p=&APP_ID.:30:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5339342388342643)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5338748213342642)
,p_name=>'P29_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5337396647342641)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22346670025526029)
,p_name=>'P29_FK_MASCH_BAND_STATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22346296714526025)
,p_prompt=>'Fk Masch Band Station'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select stationsbezeichnung, pk_masch_band_stationen',
'from t_masch_band_stationen'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22346870229526031)
,p_name=>'P29_FK_MASCH_MATERIAL_MAIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22346196766526024)
,p_prompt=>'Fk Masch Material Main'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select materialbezeichnung || '' '' || grundpreis, pk_masch_material',
'from t_masch_material'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22346901119526032)
,p_name=>'P29_FK_MASCH_MATERIAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22346196766526024)
,p_prompt=>'FK_MASCH_MATERIAL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select materialbezeichnung || '' '' || grundpreis, pk_masch_material',
'from t_masch_material'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22347274319526035)
,p_name=>'P29_FK_STD_MASCH_ZUORD_VAR_FIX_MAT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22346196766526024)
,p_prompt=>'Fk Std Masch Zuord Var Fix Mat'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:keine Angabe;0,fix;1,variabel;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22405747557857044)
,p_name=>'P29_PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_source=>'PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22406132766857048)
,p_name=>'P29_FK_MDT_MANDANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_default=>':P0_FK_MDT_MANDANT'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fk Mdt Mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant, pk_mdt_mandant',
'from t_mdt_mandant'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22406503192857052)
,p_name=>'P29_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_default=>'sysdate'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22406965454857052)
,p_name=>'P29_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22407344588857053)
,p_name=>'P29_FK_MASCH_KOMPONENTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Fk Masch Komponente'
,p_source=>'FK_MASCH_KOMPONENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, pk_masch_komponenten',
'from t_masch_komponenten'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22407782157857053)
,p_name=>'P29_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22408182191857053)
,p_name=>'P29_FK_STD_MASCH_ZUORD_VAR_FIX'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_default=>'1'
,p_prompt=>'Fk Std Masch Zuord Var Fix'
,p_source=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:keine Angabe;0,fix;1,variabel;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22408574390857054)
,p_name=>'P29_FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Fk Rel Masch Mat Material Material Main'
,p_source=>'FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''main:'' || matm.pk_masch_material || '' '' || matm.materialbezeichnung || '' sub: '' || mat.pk_masch_material || '' '' || mat.materialbezeichnung || '' '' || mat.grundpreis d, pk_rel_masch_mat_material_material_main',
'from t_rel_masch_mat_material_material_main relmatm',
' left join t_masch_material matm on matm.pk_masch_material = relmatm.fk_masch_material_main',
' left join t_masch_material mat on mat.pk_masch_material = relmatm.fk_masch_material'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22585805344158312)
,p_name=>'P29_ANZAHL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22346296714526025)
,p_item_default=>'1'
,p_prompt=>'Anzahl'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22585945880158313)
,p_name=>'P29_POSITION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22346296714526025)
,p_prompt=>'Position'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22586330826158317)
,p_name=>'P29_COMM_MATERIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(22346196766526024)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Comm Material'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22586922025158323)
,p_name=>'P29_POSITION_KOMP_MATERIAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Position Komp Material'
,p_source=>'POSITION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22786993755048804)
,p_name=>'P29_FK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(22405453831857042)
,p_item_source_plug_id=>wwv_flow_api.id(22405453831857042)
,p_prompt=>'Fk Rel Masch Komp Komponenten Komponenten'
,p_source=>'FK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_rel_masch_komp_komponenten_komponenten || '' main: '' || komp_main.pk_masch_komponenten || '' '' || komp_main.bezeichnung || '' main: '' || komp.pk_masch_komponenten || '' '' || komp.bezeichnung ',
'',
'd, pk_rel_masch_komp_komponenten_komponenten r',
'from t_rel_masch_komp_komponenten_komponenten relkk ',
' left join t_masch_komponenten komp on komp.pk_masch_komponenten = relkk.fk_masch_komponenten',
' left join t_masch_komponenten komp_main on komp_main.pk_masch_komponenten = relkk.fk_masch_komponenten_main'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22414181716857063)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(22405453831857042)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Komponenten_Materialzuordnung'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22347370081526036)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_station_komponente_material'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  v_pk_rel_masch_komp_komponente_material number;',
'begin',
'',
' v_pk_rel_masch_komp_komponente_material  :=t_rel_masch_komp_komponente_material_seq.nextval;',
'',
' insert into t_rel_masch_komp_komponente_material (',
'               PK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL,',
'               FK_MDT_MANDANT,',
'               CREATED_AT,',
'               MODIFIED_AT,',
'               FK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN,',
'               FK_MASCH_KOMPONENTE,',
'               COMM,',
'               FK_STD_MASCH_ZUORD_VAR_FIX,',
'               FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN,',
'               position',
' ',
' )',
' values (',
'             v_pk_rel_masch_komp_komponente_material ,',
'             :P0_FK_MDT_MANDANT,',
'             sysdate,',
'             sysdate,',
'             :P29_FK_REL_MASCH_KOMP_KOMPONENTEN_KOMPONENTEN,',
'             :P29_FK_MASCH_KOMPONENTE,',
'             :P29_COMM,',
'             :P29_FK_STD_MASCH_ZUORD_VAR_FIX,',
'             :P29_FK_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN,',
'             :P29_POSITION_KOMP_MATERIAL',
' ',
' ',
' );',
' commit;',
' ',
' insert into t_rel_masch_band_station_Komponente_material (',
'                                                           FK_MDT_MANDANT, CREATED_AT, MODIFIED_AT, FK_MASCH_BAND_STATION, FK_REL_MASCH_KOMP_KOMPONENTE_MATERIAL, COMM, position, anzahl',
'                                                          )',
'  values                                                   (',
'                                                           :P0_FK_MDT_MANDANT,sysdate, sysdate, :P29_FK_MASCH_BAND_STATION,  v_pk_rel_masch_komp_komponente_material , :P29_COMM, :P29_position, :P29_anzahl ',
'                                                          );',
' commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(22346482012526027)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(22413784048857062)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(22405453831857042)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Komponenten_Materialzuordnung'
);
wwv_flow_api.component_end;
end;
/
