prompt --application/pages/page_00045
begin
--   Manifest
--     PAGE: 00045
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>45
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'7  - 3 Material'
,p_alias=>'7-3-MATERIAL1'
,p_step_title=>'7  - 3 Material'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599502027938369)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200827152906'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5402881869348579)
,p_plug_name=>'Step 8'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(5138571886283855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(5299807257335305)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(5167472751283873)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5402992666348579)
,p_plug_name=>'Step 8'
,p_parent_plug_id=>wwv_flow_api.id(5402881869348579)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5100723994283838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22019550515092124)
,p_plug_name=>'Material'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with  bas as ',
'(',
'     select mat.PK_MASCH_MATERIAL,',
'       mat.FK_MDT_MANDANT,',
'       mat.CREATED_AT,',
'       mat.MODIFIED_AT,',
'       mat.STUECKKOSTEN,',
'       mat.FIXKOSTEN,',
'       mat.ANZAHL,',
'       mat.DESCR,',
'       mat.MATERIALBEZEICHNUNG,',
'       mat.COMM,',
'       mat.FK_STD_MASCH_ZUORD_VAR_FIX,',
'',
'       komp.bezeichnung komp_bezeicnung,',
'       st.stationsbezeichnung,',
'       st.pk_masch_band_stationen,',
'       st.descr st_descr,',
'       st.position st_position,',
'       komp.fk_std_masch_komp_sort,',
'       mat.grundpreis,',
'       mat.fk_bas_mon_waehrung,',
'    mat1.pk_masch_material pk_masch_material_main,',
'    mat1.materialbezeichnung materialbezeichnung_main,',
'    kat.std_name material_kategorie',
'  from T_MASCH_MATERIAL mat',
'    left join T_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm on relmatm.fk_masch_material = mat.pk_masch_material',
'    left join T_MASCH_MATERIAL mat1 on relmatm.fk_masch_material_main = mat1.pk_masch_material',
'    left join t_rel_masch_komp_komponente_material relkm on relkm.fk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN  =relmatm.pk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'    left join t_masch_komponenten komp on komp.pk_masch_komponenten = relkm.fk_masch_komponente',
'    left join t_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN relmatm on relmatm.pk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN = relkm.fk_REL_MASCH_MAT_MATERIAL_MATERIAL_MAIN',
'    left join t_rel_masch_band_station_Komponente_material relstm on relstm.fk_rel_masch_komp_komponente_material =relkm.pk_rel_masch_komp_komponente_material',
'    left join t_masch_band_stationen st on st.pk_masch_band_stationen  = relstm.fk_masch_band_station',
'    left join (select * from t_std where fk_std_group = 803 ) kat on kat.std_value = mat.fk_std_masch_mat_kategorie',
'  )',
'  select *',
'  from bas',
'  where pk_masch_band_stationen = :P45_SEL_STATION or :P45_SEL_STATION  is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Material'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22019975939092124)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:RP:P46_PK_MASCH_MATERIAL:\#PK_MASCH_MATERIAL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'FAIQA'
,p_internal_uid=>22019975939092124
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22020075241092124)
,p_db_column_name=>'PK_MASCH_MATERIAL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Masch Material'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_PK_MASCH_MATERIAL:#PK_MASCH_MATERIAL#'
,p_column_linktext=>'#PK_MASCH_MATERIAL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22020439262092124)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22020895597092125)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22021243782092125)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22021656815092125)
,p_db_column_name=>'STUECKKOSTEN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Stueckkosten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22022012149092125)
,p_db_column_name=>'FIXKOSTEN'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Fixkosten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22022440845092125)
,p_db_column_name=>'ANZAHL'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Anzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22022851111092126)
,p_db_column_name=>'DESCR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22023271841092126)
,p_db_column_name=>'MATERIALBEZEICHNUNG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Materialbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22023695119092126)
,p_db_column_name=>'COMM'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22024073434092126)
,p_db_column_name=>'FK_STD_MASCH_ZUORD_VAR_FIX'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fk Std Masch Zuord Var Fix'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20145925477098342)
,p_db_column_name=>'KOMP_BEZEICNUNG'
,p_display_order=>22
,p_column_identifier=>'P'
,p_column_label=>'Komp Bezeicnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21284630263326949)
,p_db_column_name=>'STATIONSBEZEICHNUNG'
,p_display_order=>32
,p_column_identifier=>'Q'
,p_column_label=>'Stationsbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22057060382712101)
,p_db_column_name=>'ST_DESCR'
,p_display_order=>52
,p_column_identifier=>'S'
,p_column_label=>'St Descr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22057129626712102)
,p_db_column_name=>'ST_POSITION'
,p_display_order=>62
,p_column_identifier=>'T'
,p_column_label=>'St Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22057782891712108)
,p_db_column_name=>'FK_STD_MASCH_KOMP_SORT'
,p_display_order=>72
,p_column_identifier=>'U'
,p_column_label=>'Fk Std Masch Komp Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22057843637712109)
,p_db_column_name=>'GRUNDPREIS'
,p_display_order=>82
,p_column_identifier=>'V'
,p_column_label=>'Grundpreis'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22057963910712110)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>92
,p_column_identifier=>'W'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058047441712111)
,p_db_column_name=>'PK_MASCH_MATERIAL_MAIN'
,p_display_order=>102
,p_column_identifier=>'X'
,p_column_label=>'Pk Masch Material Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058126233712112)
,p_db_column_name=>'MATERIALBEZEICHNUNG_MAIN'
,p_display_order=>112
,p_column_identifier=>'Y'
,p_column_label=>'Materialbezeichnung Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22058286438712113)
,p_db_column_name=>'MATERIAL_KATEGORIE'
,p_display_order=>122
,p_column_identifier=>'Z'
,p_column_label=>'Material Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22787276190048807)
,p_db_column_name=>'PK_MASCH_BAND_STATIONEN'
,p_display_order=>132
,p_column_identifier=>'AA'
,p_column_label=>'Pk Masch Band Stationen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22027294081098467)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'220273'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:PK_MASCH_MATERIAL:FK_MDT_MANDANT:ST_DESCR:MATERIAL_KATEGORIE:PK_MASCH_MATERIAL_MAIN:MATERIALBEZEICHNUNG_MAIN:MATERIALBEZEICHNUNG:COMM:FK_STD_MASCH_ZUORD_VAR_FIX:STATIONSBEZEICHNUNG:ST_POSITION:GRUNDPREIS:FK_BAS_'
||'MON_WAEHRUNG:STUECKKOSTEN:FIXKOSTEN:ANZAHL:DESCR:CREATED_AT:MODIFIED_AT::PK_MASCH_BAND_STATIONEN'
,p_break_on=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:0:0:0:0'
,p_break_enabled_on=>'FK_STD_MASCH_KOMP_SORT:KOMP_BEZEICNUNG:0:0:0:0'
,p_sum_columns_on_break=>'GRUNDPREIS'
,p_count_columns_on_break=>'PK_MASCH_MATERIAL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22057282186712103)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22025785318092127)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(22019550515092124)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:46'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(22057425212712105)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(22057282186712103)
,p_button_name=>'Reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Reset'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::P45_SEL_STATION:'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5404644476348580)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5402881869348579)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5404972619348580)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5402881869348579)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(5190363820283892)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5404823907348580)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5402881869348579)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5189510317283890)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5406358938348581)
,p_branch_action=>'f?p=&APP_ID.:46:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5404972619348580)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(5405663953348581)
,p_branch_action=>'f?p=&APP_ID.:44:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(5404823907348580)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5404389456348580)
,p_name=>'P45_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5402992666348579)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22057357884712104)
,p_name=>'P45_SEL_STATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22057282186712103)
,p_prompt=>'Sel Station'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select stationsbezeichnung, pk_masch_band_stationen',
'from t_masch_band_stationen'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(22057563477712106)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P45_SEL_STATION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(22057607918712107)
,p_event_id=>wwv_flow_api.id(22057563477712106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
