prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>48
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'Prozessablauf'
,p_alias=>'PROZESSABLAUF'
,p_step_title=>'Prozessablauf'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9600085149967089)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200827152803'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9446837626636013)
,p_plug_name=>'Prozessablauf'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with data as (select rownum rnr, list_name, application_id, application_name, display_sequence, entrY_text, entry_target,current_for_pages_expression, current_for_pages_expression str , current_for_pages_type_code from apex_application_list_entries w'
||'here application_id = 107 and list_name in (''1 Projektmanagement'', ''2 Projektkostenplanung'',''3 Materialplanung''))',
', con as (SELECT trim(regexp_substr(str, ''[^,]+'', 1, LEVEL)) str, rnr,application_id, application_name, display_sequence, entrY_text, entry_target,current_for_pages_expression, current_for_pages_type_code, list_name',
'   FROM DATA',
'   CONNECT BY nocycle regexp_substr(str , ''[^,]+'', 1, LEVEL) IS NOT NUll )',
'   select distinct con.* , ap.page_id, ap.page_name, case when mod(rnr,2) = 1 then 1 else 0 end mark',
'   from con',
'     left join apex_application_pages ap on con.str = ap.page_id and con.application_id = ap.application_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Prozessablauf'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9446930816636013)
,p_name=>'Prozessablauf'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>9446930816636013
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9158726105102431)
,p_db_column_name=>'STR'
,p_display_order=>10
,p_column_identifier=>'AS'
,p_column_label=>'Str'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159444072102438)
,p_db_column_name=>'RNR'
,p_display_order=>20
,p_column_identifier=>'AZ'
,p_column_label=>'Rnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159560931102439)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>30
,p_column_identifier=>'BA'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159653943102440)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>40
,p_column_identifier=>'BB'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159752055102441)
,p_db_column_name=>'DISPLAY_SEQUENCE'
,p_display_order=>50
,p_column_identifier=>'BC'
,p_column_label=>'Display Sequence'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159878971102442)
,p_db_column_name=>'ENTRY_TEXT'
,p_display_order=>60
,p_column_identifier=>'BD'
,p_column_label=>'Entry Text'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9159987647102443)
,p_db_column_name=>'ENTRY_TARGET'
,p_display_order=>70
,p_column_identifier=>'BE'
,p_column_label=>'Entry Target'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160047319102444)
,p_db_column_name=>'CURRENT_FOR_PAGES_EXPRESSION'
,p_display_order=>80
,p_column_identifier=>'BF'
,p_column_label=>'Current For Pages Expression'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160140147102445)
,p_db_column_name=>'CURRENT_FOR_PAGES_TYPE_CODE'
,p_display_order=>90
,p_column_identifier=>'BG'
,p_column_label=>'Current For Pages Type Code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160202823102446)
,p_db_column_name=>'LIST_NAME'
,p_display_order=>100
,p_column_identifier=>'BH'
,p_column_label=>'List Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160364677102447)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>110
,p_column_identifier=>'BI'
,p_column_label=>'Page Id'
,p_column_link=>'f?p=&APP_ID.:#PAGE_ID#:&SESSION.::&DEBUG.:::'
,p_column_linktext=>'#PAGE_ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160445616102448)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>120
,p_column_identifier=>'BJ'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9160517840102449)
,p_db_column_name=>'MARK'
,p_display_order=>130
,p_column_identifier=>'BK'
,p_column_label=>'Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9464987078637159)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94650'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STR:RNR:APPLICATION_ID:APPLICATION_NAME:DISPLAY_SEQUENCE:ENTRY_TEXT:ENTRY_TARGET:CURRENT_FOR_PAGES_TYPE_CODE:CURRENT_FOR_PAGES_EXPRESSION::LIST_NAME:PAGE_ID:PAGE_NAME:MARK'
,p_sort_column_1=>'RNR'
,p_sort_direction_1=>'ASC'
,p_break_on=>'LIST_NAME'
,p_break_enabled_on=>'LIST_NAME'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9519907433848242)
,p_report_id=>wwv_flow_api.id(9464987078637159)
,p_name=>'Pages'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CURRENT_FOR_PAGES_EXPRESSION'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CURRENT_FOR_PAGES_EXPRESSION" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9520329321848242)
,p_report_id=>wwv_flow_api.id(9464987078637159)
,p_name=>'Entry'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ENTRY_TEXT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("ENTRY_TEXT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(9520785145848242)
,p_report_id=>wwv_flow_api.id(9464987078637159)
,p_name=>'mark'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'MARK'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("MARK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#CCE5FF'
);
wwv_flow_api.component_end;
end;
/
