prompt --application/pages/page_00049
begin
--   Manifest
--     PAGE: 00049
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>49
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'Personen'
,p_alias=>'PERSONEN'
,p_step_title=>'Personen'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599623665939631)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200903051728'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10025015070098471)
,p_plug_name=>'Personen'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_KON_PERSON'
,p_query_where=>'fk_mdt_mandAnt = 3'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10025449059098472)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:RP:P51_PK_KON_PERSON:\#PK_KON_PERSON#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>10025449059098472
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10025544240098474)
,p_db_column_name=>'PK_KON_PERSON'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Kon Person'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10025943464098475)
,p_db_column_name=>'NACHNAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10026386281098475)
,p_db_column_name=>'VORNAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10026746216098475)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10027184759098476)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10027517677098476)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10027990997098476)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10028363704098476)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10028758490098476)
,p_db_column_name=>'GEBURTSDATUM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Geburtsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10029126361098477)
,p_db_column_name=>'STERBEDATUM'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Sterbedatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10031021538101235)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'100311'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_KON_PERSON:NACHNAME:VORNAME:BEMERKUNG:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:GEBURTSDATUM:STERBEDATUM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10001901216040016)
,p_plug_name=>'Srundenzettel'
,p_parent_plug_id=>wwv_flow_api.id(10025015070098471)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std.PK_INP_BELEGE_ALL,',
'        std.bezeichnung,',
'        std.MONAT,',
'        std.JAHR,',
'        std.FK_PROJ_PROJEKT,',
'        std.vON,',
'        std.BIS,',
'        std.ERSTELLT_AM,',
'        std.GEZEICHNET_AM,',
'        std.FK_KON_GEZEICHNET_VON,',
'        std.AZ_STUNDENZAHL,',
'        std.GENEHMIGT_AM,',
'        std.EINGEREICHT_AM_PP_1,',
'        std.EINGEREICHT_AM_PP_2,',
'        std.BESTAETIGUNG_AM_PP_1,',
'        std.BESTAETIGUNG_AM_PP_2,',
'   ',
'       ',
'        std.FK_KON_PERSON,',
'        std.AZ_UEBERSTUNDEN,',
'        std.FK_MDT_MANDANT,',
'        std.FAHRZEIT,',
'        std.FK_STD_REISE_FAHRZEIT_EINHEIT,',
'        std.AZ_SOLLSTUNDEN,',
'        per.vorname,',
'        per.nachname,',
'        proj.projekt,',
'        proj_main.projekt main_projektbezeichnung',
'  from t_inp_belege_all std',
'   left join t_kon_person per on std.fk_kon_person = per.pk_kon_person',
'   left join t_proj_projekt proj on proj.pk_proj_projekt = std.fk_proj_projekt',
'   left join t_proj_projekt proj_main on proj_main.pk_proj_projekt = proj.fk_proj_projekt_main',
' where std.fk_mdt_mandant = :P0_FK_MDT_MANDANT'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Srundenzettel'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10002078551040017)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>10002078551040017
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002379376040020)
,p_db_column_name=>'MONAT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002467473040021)
,p_db_column_name=>'JAHR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002594509040022)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002853581040025)
,p_db_column_name=>'ERSTELLT_AM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Erstellt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10002904668040026)
,p_db_column_name=>'GEZEICHNET_AM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Gezeichnet Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003051737040027)
,p_db_column_name=>'FK_KON_GEZEICHNET_VON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Kon Gezeichnet Von'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003288721040029)
,p_db_column_name=>'GENEHMIGT_AM'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Genehmigt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003326824040030)
,p_db_column_name=>'EINGEREICHT_AM_PP_1'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Eingereicht Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003482370040031)
,p_db_column_name=>'EINGEREICHT_AM_PP_2'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Eingereicht Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003577607040032)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_1'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Bestaetigung Am Pp 1'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10003611430040033)
,p_db_column_name=>'BESTAETIGUNG_AM_PP_2'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Bestaetigung Am Pp 2'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004202445040039)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004446371040041)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004538684040042)
,p_db_column_name=>'FAHRZEIT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004684289040043)
,p_db_column_name=>'FK_STD_REISE_FAHRZEIT_EINHEIT'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fk Std Reise Fahrzeit Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004751534040044)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004842447040045)
,p_db_column_name=>'VORNAME'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10004927685040046)
,p_db_column_name=>'NACHNAME'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10005056479040047)
,p_db_column_name=>'PROJEKT'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10005117541040048)
,p_db_column_name=>'MAIN_PROJEKTBEZEICHNUNG'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Main Projektbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11540912499958345)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11541012195958346)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11541127625958347)
,p_db_column_name=>'VON'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11541278210958348)
,p_db_column_name=>'BIS'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11541388698958349)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12627978860918426)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10174806602979861)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'101749'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MAIN_PROJEKTBEZEICHNUNG:PROJEKT:BEZEICHNUNG:VORNAME:NACHNAME:MONAT:JAHR:AZ_SOLLSTUNDEN:AZ_UEBERSTUNDEN:GEZEICHNET_AM:GENEHMIGT_AM:EINGEREICHT_AM_PP_1:EINGEREICHT_AM_PP_2:BESTAETIGUNG_AM_PP_1:BESTAETIGUNG_AM_PP_2:FK_KON_PERSON:FK_MDT_MANDANT:FAHRZEIT:'
||'FK_STD_REISE_FAHRZEIT_EINHEIT:FK_PROJ_PROJEKT:PK_INP_BELEGE_ALL:VON:BIS:ERSTELLT_AM:FK_KON_GEZEICHNET_VON::AZ_STUNDENZAHL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11541424868958350)
,p_plug_name=>'Personen_Rolle'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select per.PK_KON_PERSON,',
'       per.NACHNAME,',
'       per.VORNAME,',
'       per.BEMERKUNG,',
'       per.CREATED_BY,',
'       per.CREATED_AT,',
'       per.MODIFIED_BY,',
'       per.MODIFIED_AT,',
'       per.GEBURTSDATUM,',
'       per.STERBEDATUM,',
'       per.FK_MDT_MANDANT,',
'       role.std_name role,',
'       perrol.pk_rel_kon_person_role',
'  from T_KON_PERSON per',
'    left join t_rel_kon_person_role perrol on per.pk_kon_person = perrol.fk_kon_person',
'    left join (select * from t_std where fk_std_group = 723 ) role on role.std_value = perrol.fk_std_kon_person_role',
'  ',
' where per.fk_mdt_mandAnt = 3'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personen_Rolle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12548842891439502)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:RP,:P60_PK_REL_KON_PERSON_ROLE,P60_FK_KON_PERSON:#PK_REL_KON_PERSON_ROLE#,#PK_KON_PERSON#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>12548842891439502
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12548989837439503)
,p_db_column_name=>'PK_KON_PERSON'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Kon Person'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549038368439504)
,p_db_column_name=>'NACHNAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nachname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549126513439505)
,p_db_column_name=>'VORNAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Vorname'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549213187439506)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549388836439507)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549439434439508)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549546551439509)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549660976439510)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549714607439511)
,p_db_column_name=>'GEBURTSDATUM'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Geburtsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549820110439512)
,p_db_column_name=>'STERBEDATUM'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Sterbedatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12549932872439513)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12550084774439514)
,p_db_column_name=>'ROLE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Role'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12550187422439515)
,p_db_column_name=>'PK_REL_KON_PERSON_ROLE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Pk Rel Kon Person Role'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12559403949470538)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'125595'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_KON_PERSON:NACHNAME:VORNAME:BEMERKUNG:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:GEBURTSDATUM:STERBEDATUM:FK_MDT_MANDANT:ROLE:PK_REL_KON_PERSON_ROLE'
,p_break_on=>'ROLE'
,p_break_enabled_on=>'ROLE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12548739227439501)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11541424868958350)
,p_button_name=>'CREATE_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:51'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10030671688098494)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10025015070098471)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:51'
);
wwv_flow_api.component_end;
end;
/
