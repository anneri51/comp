prompt --application/pages/page_00056
begin
--   Manifest
--     PAGE: 00056
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>56
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'Cost_Grp'
,p_alias=>'COST-GRP1'
,p_step_title=>'Cost_Grp'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(9599623665939631)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200903064619'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13207042080074425)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(5126267378283850)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select grp.PK_COST_COST_GRP,',
'       grp.COST_GRP_NAME,',
'       grp.FK_MDT_MANDANT,',
'       grp.FK_COST_COST_GRP_MAIN,',
'       grp_main.cost_grp_name main_cost_grp_name,',
'       grp.lv',
'  from (select grp.*, level lv',
'from T_COST_COST_GRP grp',
'start with fk_cost_cost_grp_main is null',
'connect by  nocycle  prior pk_cost_cost_grp  =  fk_cost_cost_grp_main ',
') grp',
'    left join t_cost_cost_grp grp_main on grp_main.pk_cost_cost_grp = grp.fk_cost_cost_grp_main',
'  where grp.fk_mdt_mandant =:P0_FK_Mdt_mandant'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13207401338074425)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:RP:P59_PK_COST_COST_GRP:\#PK_COST_COST_GRP#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13207401338074425
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13207523695074428)
,p_db_column_name=>'PK_COST_COST_GRP'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Cost Cost Grp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13207958959074432)
,p_db_column_name=>'COST_GRP_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Cost Grp Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13208315010074433)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13208759003074433)
,p_db_column_name=>'FK_COST_COST_GRP_MAIN'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Cost Cost Grp Main'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12630178781918448)
,p_db_column_name=>'MAIN_COST_GRP_NAME'
,p_display_order=>14
,p_column_identifier=>'E'
,p_column_label=>'Main Cost Grp Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12630245842918449)
,p_db_column_name=>'LV'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'Lv'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13210647305077673)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'132107'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_COST_COST_GRP:COST_GRP_NAME:FK_MDT_MANDANT:FK_COST_COST_GRP_MAIN:MAIN_COST_GRP_NAME:LV'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13210208146074439)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(13207042080074425)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:59'
);
wwv_flow_api.component_end;
end;
/
