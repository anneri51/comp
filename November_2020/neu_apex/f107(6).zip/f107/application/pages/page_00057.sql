prompt --application/pages/page_00057
begin
--   Manifest
--     PAGE: 00057
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>57
,p_user_interface_id=>wwv_flow_api.id(5212770529283919)
,p_name=>'inp_belege_all_kategorisieren'
,p_alias=>'INP-BELEGE-ALL-KATEGORISIEREN'
,p_step_title=>'inp_belege_all_kategorisieren'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200903141444'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26700088980501276)
,p_plug_name=>'inp_belege_all_kategorisieren'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,v_inp.pk_inp_belege_all) sel,',
'',
'inp.datum_buchung_ok, ',
'inp.fk_real_beleg_exist,',
'inp.fk_kon_person,',
'inp.dummy,',
'       v_inp.PK_INP_BELEGE_ALL,',
'        v_inp.fk_bas_std_status,',
'        v_inp.FK_LEX_BUCHUNG,',
'        v_inp.FK_bas_kat_KATEGORIE,',
'        v_inp.FK_bas_kal_ARBEITSTAG,',
'        v_inp.FK_kto_BUCHUNG,',
'        v_inp.FK_std_kto_ZAHLUNGSART,',
'        v_inp.FK_std_verw_VERWENDUNGSZWECK,',
'        v_inp.FK_inv_INVENTAR,',
'       v_inp.FK_proj_PROJEKT,',
'        nvl(v_inp.BELEGNUMMER,0) belegnummer,',
'        v_inp.BEZEICHNUNG,',
'        v_inp.FK_adr_LAND,',
'        v_inp.FK_adr_CITY,',
'        v_inp.BEL_DATUM,',
'        v_inp.beleg_uhrzeit,',
'        v_inp.VON,',
'        v_inp.BIS,',
'        v_inp.NETTO_BETRAG,',
'        v_inp.FK_bas_steu_STEUER_SATZ,',
'        v_inp.MWST_BETRAG,',
'        v_inp.BRUTTO_BETRAG,',
'        v_inp.FK_bas_mon_WAEHRUNG,',
'        v_inp.STEUERNUMMER,',
'        v_inp.FK_bas_mon_UMRECHNUNGSKURS,',
'        v_inp.COMM_REST_BELEG,',
'        v_inp.COMM_TEL_BELEG,',
'        v_inp.COMM_PRODUKTE,',
'        v_inp."COMM_BEGRUENDUNG",',
'        v_inp.COMM_SONSTIGES,',
'        v_inp.BELEG,',
'        v_inp.ZAHLUNGSBELEG,',
'        v_inp.LITER,',
'        v_inp."ZAPFSAEULE",',
'        v_inp.FK_loc_LOCATION,',
'        v_inp."PERSOENLICH_VOR_ORT",',
'       inp_bel_all_jahr,',
'       inp.fk_la_wdh,',
'       nvl(ll.habenkto,0) habenkto,',
'       ll.sollkto,',
'       v_inp.ort,',
'       v_inp.abl_ord_jahr,',
'       v_inp.ktokat_kategorie,',
'       v_inp.ABL_ORD_PK_ABL_ORDNER_PAGE,',
'       v_inp.ABL_ORD_PAGE_NUMBER,',
'       case when ll.status is not null then ''<span style="color:red">'' || ''<b>''  || nvl(rellex.pk_rel_lex_kto_bel,0) || ''</b>''|| ''</span>'' else '''' || nvl(rellex.pk_rel_lex_kto_bel,0)  end  pk_rel_lex_kto_bel,',
'        pk_rel_lex_kto_bel  pk_rel_lex_kto_bel_1,',
'       ll.belegnr ,',
'       arb.jahr,',
'       arb.monat,',
'       arb.tag,',
'            case when datum_ort_ok is not null or datum_addresse_ok is not null or datum_bussgeld_ok is not null or datum_beleg_pos_ok is not null or datum_buchung_ok is not null  or datum_verpfl_bel_ok is not null then 1 else 0 end flg_kontr_bel_ok',
'  from V_INP_BELEGE_ALL v_inp',
'   left join t_rel_lex_kto_bel rellex on v_inp.pk_inp_belege_all = rellex.fk_inp_belege_all',
'   left join t_inp_belege_all inp on v_inp.pk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation = rellex.fk_lex_relation',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag',
'',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(26700249405501276)
,p_name=>'inp_belege_all_kategorisieren'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:RP,:P54_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>26700249405501276
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11186809468211979)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:RP,:P54_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11187263074211980)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319__FK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_LEX_BUCHUNG#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11187663712211980)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11188003831211980)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11188443413211981)
,p_db_column_name=>'VON'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11188858074211981)
,p_db_column_name=>'BIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11189206292211981)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11189688390211982)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11190024483211982)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11190462836211982)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11190843056211982)
,p_db_column_name=>'LITER'
,p_display_order=>31
,p_column_identifier=>'AC'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11184494784211976)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>281
,p_column_identifier=>'JH'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11184815304211978)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>291
,p_column_identifier=>'JI'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11185253927211978)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>301
,p_column_identifier=>'JJ'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11185616620211978)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>321
,p_column_identifier=>'JL'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11186078960211979)
,p_db_column_name=>'BELEG'
,p_display_order=>331
,p_column_identifier=>'JM'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11186477975211979)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>341
,p_column_identifier=>'JN'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11191279925211983)
,p_db_column_name=>'SEL'
,p_display_order=>391
,p_column_identifier=>'JS'
,p_column_label=>'pk <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11191611156211983)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>401
,p_column_identifier=>'JT'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11192043954211983)
,p_db_column_name=>'HABENKTO'
,p_display_order=>411
,p_column_identifier=>'JU'
,p_column_label=>'Habenkto'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#HABENKTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11192402065211984)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>421
,p_column_identifier=>'JV'
,p_column_label=>'Sollkto'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#SOLLKTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11192814747211984)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>441
,p_column_identifier=>'JX'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11193226588211984)
,p_db_column_name=>'ORT'
,p_display_order=>451
,p_column_identifier=>'JY'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11193615757211985)
,p_db_column_name=>'FLG_KONTR_BEL_OK'
,p_display_order=>461
,p_column_identifier=>'JZ'
,p_column_label=>'Flg Kontr Bel Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11194077573211985)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>471
,p_column_identifier=>'KA'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11194450589211985)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>481
,p_column_identifier=>'KB'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11194829759211985)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>491
,p_column_identifier=>'KD'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP:P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1,P373_SRC_PK_INP_BELEGE_ALL,P373_ZIEL_PK_INP_BELEGE_ALL:,#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11195261865211986)
,p_db_column_name=>'JAHR'
,p_display_order=>501
,p_column_identifier=>'KE'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11195636618211986)
,p_db_column_name=>'MONAT'
,p_display_order=>511
,p_column_identifier=>'KF'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11196064895211986)
,p_db_column_name=>'TAG'
,p_display_order=>521
,p_column_identifier=>'KG'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11196491487211987)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>531
,p_column_identifier=>'KH'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11196818305211987)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>541
,p_column_identifier=>'KI'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11197211949211987)
,p_db_column_name=>'BELEGNR'
,p_display_order=>561
,p_column_identifier=>'KK'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11197622692211988)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>571
,p_column_identifier=>'KL'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11198039741211988)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>581
,p_column_identifier=>'KM'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11198419818211988)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>591
,p_column_identifier=>'KN'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11198819968211988)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>601
,p_column_identifier=>'KO'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL,P252_FK_INP_BELEGE_ALL:#PK_REL_LEX_KTO_BEL_1#,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11199253049211989)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL_1'
,p_display_order=>611
,p_column_identifier=>'KP'
,p_column_label=>'Pk Rel Lex Kto Bel 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11199625528211989)
,p_db_column_name=>'DUMMY'
,p_display_order=>621
,p_column_identifier=>'KQ'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11200087575211989)
,p_db_column_name=>'FK_BAS_STD_STATUS'
,p_display_order=>631
,p_column_identifier=>'KR'
,p_column_label=>'Fk Bas Std Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11200411454211990)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>641
,p_column_identifier=>'KS'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11200824342211990)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>651
,p_column_identifier=>'KT'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11201238375211990)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>661
,p_column_identifier=>'KU'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11201656938211991)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>691
,p_column_identifier=>'KX'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11202082776211991)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>701
,p_column_identifier=>'KY'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11202440144211991)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>711
,p_column_identifier=>'KZ'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11202862350211992)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>721
,p_column_identifier=>'LA'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11203237232211992)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>731
,p_column_identifier=>'LB'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11203603630211992)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>741
,p_column_identifier=>'LC'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11204034917211993)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>751
,p_column_identifier=>'LD'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11204431021211993)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>761
,p_column_identifier=>'LE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11204820575211993)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>771
,p_column_identifier=>'LF'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11205293120211993)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>781
,p_column_identifier=>'LG'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11205673408211994)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>791
,p_column_identifier=>'LH'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11206064101211994)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>801
,p_column_identifier=>'LJ'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11206447649211994)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>811
,p_column_identifier=>'LK'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13246268062475435)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>821
,p_column_identifier=>'LL'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(26830261451567094)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112068'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER:DUMMY:PK_REL_LEX_KTO_BEL:PK_INP_BELEGE_ALL:FK_REAL_BELEG_EXIST:DATUM_BUCHUNG_OK:BELEGNUMMER:SEL:HABENKTO:BEZEICHNUNG:BEL_DATUM:BELEG_UHRZEIT:VON:BIS:NETTO_BETRAG:MWST_BETRAG:BRUTTO_BETRAG:STEUERNUMMER:COMM_SONSTIGES:L'
||'ITER:COMM_PRODUKTE:COMM_REST_BELEG:COMM_TEL_BELEG:ZAHLUNGSBELEG:ORT:FLG_KONTR_BEL_OK:FK_LEX_BUCHUNG:SOLLKTO:JAHR:MONAT:TAG:ABL_ORD_PK_ABL_ORDNER_PAGE:BELEGNR:FK_LA_WDH:BELEG:INP_BEL_ALL_JAHR:KTOKAT_KATEGORIE:PK_REL_LEX_KTO_BEL_1::FK_BAS_STD_STATUS:FK'
||'_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:FK_BAS_MON_UMRECHNUNGSKURS:COMM_BEGRUENDUNG:ZAPFSAEULE:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:FK_'
||'STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_KON_PERSON'
,p_sort_column_1=>'BEZEICHNUNG'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'FK_STATUS'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PK_INP_BELEGE_ALL'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PK_INP_BELEGE_ALL:0:0:0:0:ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER'
,p_break_enabled_on=>'0:0:0:0:ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11209240619211997)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_name=>'Dummy'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUMMY'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DUMMY" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11209658736211997)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_name=>'beleg_fehlt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_REAL_BELEG_EXIST'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_REAL_BELEG_EXIST" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11208822654211997)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11207243190211995)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ABL_ORD_JAHR'
,p_operator=>'contains'
,p_expr=>'2020'
,p_condition_sql=>'upper("ABL_ORD_JAHR") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 2020  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11207621159211996)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_operator=>'='
,p_expr=>'15'
,p_condition_sql=>'"ABL_ORD_PAGE_NUMBER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11208090541211996)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KONTR_BEL_OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FLG_KONTR_BEL_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11208457376211996)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MONAT'
,p_operator=>'='
,p_expr=>'3'
,p_condition_sql=>'"MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(11209928349211997)
,p_report_id=>wwv_flow_api.id(26830261451567094)
,p_name=>'Row text contains ''33336807'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'33336807'
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47495116464579070)
,p_plug_name=>'Button'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47495009676579069)
,p_plug_name=>'Lex'
,p_parent_plug_id=>wwv_flow_api.id(47495116464579070)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(60871751282247334)
,p_plug_name=>'Kasse'
,p_parent_plug_id=>wwv_flow_api.id(47495116464579070)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(51711638112173221)
,p_plug_name=>unistr('Kategorie \00E4ndern')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(5128117820283851)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11210633726211998)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(47495116464579070)
,p_button_name=>'Show_Buchungen_all'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Show Buchungen All'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11211348957211999)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:54:P54_PK_INP_BELEGE_ALL:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11211766786211999)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Delete_Beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Delete Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11215681047212001)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'Update_Kasse'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update fk_main_key tag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11216071235212001)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'Kasse'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Kasse'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:314:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11212126242211999)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>unistr('Zusammenf\00FChren')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('Zusammenf\00FChren')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11216494548212001)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'Steuer_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Steuer Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11212590160211999)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11212968586212000)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Kontenblatt'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11216851696212001)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'Steuer_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Steuer Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11213309549212000)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11213720769212000)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Kontoauszug_Abstimmung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Kontoauszug Abstimmung'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP::#target="_blank"'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11214143540212000)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Susa'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Susa'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11214508704212000)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Kontrolle'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Kontrolle'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP:P310_KONTO:&P304_KONTO_AUSWAHL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11217288864212002)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11219551671212003)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Update_Land'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update Land'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11219908677212003)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Update_Ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update Ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11217671532212002)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'Set_split_buch_nr_man'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Set Split Buch Nr Man'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11220346053212003)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Update_Kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11218072223212002)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'set_flg_split_buch'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11218469176212002)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(60871751282247334)
,p_button_name=>'reset_flg_split_buch_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11220716380212003)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Update_Verwendungszweck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update verwendungszweck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11221122476212004)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Update_Wiederholung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Update wiederholung'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11221530626212004)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11221958856212004)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung_1')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11222390424212004)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Insert_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Insert inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11222758404212004)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'remove_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'remove inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11223164743212004)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'Insert_Projekt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Insert Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11223542121212004)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'remove_Projekt_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Remove Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11223940458212005)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>'set_zahlungsart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'set_zahlungsart'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11224393813212005)
,p_button_sequence=>290
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>unistr('Update_Gesch\00E4ftspartner')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('Update Gesch\00E4ftspartner')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11224797136212005)
,p_button_sequence=>300
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>unistr('Change_Gesch\00E4ftspartner')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('Change Gesch\00E4ftspartner')
,p_button_position=>'BODY'
,p_button_redirect_url=>unistr('f?p=&APP_ID.:233:&SESSION.::&DEBUG.:RP:P233_PK_GESCHAEFTSPARTNER:&"P229_FK_GESCH\00C4FTSPARTNER".')
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11225178154212005)
,p_button_sequence=>310
,p_button_plug_id=>wwv_flow_api.id(51711638112173221)
,p_button_name=>unistr('set_pers\00F6nlich_vor_ort')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>unistr('set_pers\00F6nlich_vor_ort')
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11214967219212000)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(47495009676579069)
,p_button_name=>'Lex_Kontenplan'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(5190223434283891)
,p_button_image_alt=>'Lex Kontenplan'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:257:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11218838692212002)
,p_name=>'P57_SPLIT_NR_MAN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(60871751282247334)
,p_prompt=>'Split Nr Man'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:0;0,1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11225593788212005)
,p_name=>'P57_FK_ADR_LAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land, pk_adr_land',
'from t_adr_land',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11225942041212006)
,p_name=>'P57_FK_ADR_ORT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort, pk_adr_ort',
'from t_adr_ort',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11226367880212006)
,p_name=>'P57_FK_BAS_KAT_KATEGORIE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11226750296212006)
,p_name=>'P57_DESCR1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'fk_main_key, konrotsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11227122697212007)
,p_name=>'P57_FK_BAS_STD_VERWENDUNGSZWECK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'Fk verwendungszweck'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 109'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11227586590212007)
,p_name=>'P57_DESCR1_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11227964692212007)
,p_name=>'P57_WIEDERHOLUNG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'Wiederholung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC:',
unistr('"j\00E4hrlich";"j\00E4hrlich",'),
unistr('"halbj\00E4hrlich";"halbj\00E4hrlich",'),
unistr('"viertelj\00E4hrlich";"viertelj\00E4hrlich",'),
'"monatlich";"monatlich",',
'einmalig;einmalig'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11228307923212007)
,p_name=>'P57_DESCR1_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11228719336212008)
,p_name=>'P57_NAECHSTE_ZAHLUNG'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>unistr('N\00E4chste zahlung')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11229119365212008)
,p_name=>'P57_DESCR1_3'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11229568536212008)
,p_name=>'P57_FK_INV_INVENTAR'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr, pk_inv_inventar',
'from t_inv_inventare'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11229934088212008)
,p_name=>'P57_DESCR1_4'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'fk_main_key'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightgreen"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11230398293212008)
,p_name=>'P57_FK_PROJ_PROJEKT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_prompt=>'Fk projekt'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || von || '' - '' || bis || '')''  ,Pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11230787674212009)
,p_name=>'P57_FK_BAS_STD_ZAHLUNGSART'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Bas Std Zahlungsart'
,p_source=>'FK_BAS_STD_ZAHLUNGSART'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select std_name, std_value',
'  from t_std',
'  where fk_std_group = 22'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11231155799212009)
,p_name=>'P57_FK_KON_GESCHAEFTSPARTNER'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(51711638112173221)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Gesch\00E4ftspartner')
,p_source=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select geschaeftspartner, pk_kon_geschaeftspartner',
'from v_kon_geschaeftspartner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(5189187675283889)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11233109393212010)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'',
'',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select  v_fk_main_key,',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11233505599212010)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'',
'  ',
'',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select v_fk_main_key,',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11231518877212009)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_1_Update_land'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set  fk_land = :P57_fK_LAND where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11219551671212003)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11231905031212010)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_2_Update_Ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_city = :P57_FK_ort where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11219908677212003)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11233906192212011)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_Update_Verwendungszweck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_Verwendungszweck = :P57_FK_VERWENDUNGSZWECK where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11220716380212003)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11234375792212011)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_1_Update_Wiederholung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'  ',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set fk_la_wdh = :P57_Wiederholung  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11221122476212004)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11234730693212011)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_2_Update_naechste_Zahlung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
unistr('       update "KTO_Girokonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
unistr('       update "KTO_Kreditkarte"  set N\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
unistr('       update "KTO_Paypal"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
unistr('       update "KTO_Tagesgeldkonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11221530626212004)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11235157553212011)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_2_Update_naechste_Zahlung_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'       p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11221958856212004)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11238345889212013)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_3_Update_naechste_Zahlung_1_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'  --     select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'   --            substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'  --     into v_fk_main_key, v_kontotyp',
'  --     from dual;',
'      ',
'    ',
'    --   p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
unistr('   update inp_belege_all set fk_la_wdh = :"P57_N\00C4CHSTE_ZAHLUNG" where pk_inp_belege_all = apex_application.g_f01(i);'),
'    commit;',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11221958856212004)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11235579194212011)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_Update_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_Kategorie = :P57_FK_Kategorie  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11220346053212003)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11235911005212012)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_1_insert_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_inventar = to_number(:P57_fk_inventar)  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11222390424212004)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11236356814212012)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_2_remove_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_inventar_zahlung where fk_inventar = to_number(:P195_fk_inventar) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11222758404212004)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11236711779212012)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_1_insert_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set fk_projekt = to_number(:P57_fk_projekt)  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11223164743212004)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11237115853212012)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_2_remove_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_projekt_zahlung where fk_projekt = to_number(:P195_fk_projekt) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11223542121212004)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11232304559212010)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('8_set_pers\00F6nlich_vor_ort')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
unistr('       update inp_belege_all  set pers\00F6nlich_vor_ort = 1 where  pk_inp_belege_all =  apex_application.g_f01(i);'),
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11225178154212005)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11232753209212010)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_Update_zahlrungsart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_zahlungsart = :P57_FK_ZAHLUNGSART  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11223940458212005)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11237974269212013)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('11_Update_Gesch\00E4ftspartner')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
unistr('       update inp_belege_all  set fk_gesch\00E4ftspartner = :P57_FK_geschaeftspartner  where  pk_inp_belege_all =  apex_application.g_f01(i);'),
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11224393813212005)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11238773095212013)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_delete_Beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      delete from  inp_belege_all where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(11211766786211999)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11237502911212012)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' null;',
' ',
' --1 OK',
'   --OK:     2 - v_fk_main_key (,) v_kontotyp ',
'   --OK_1:     2 - v_fk_main_key (,) v_kontotyp ',
' ',
' --2 Update Land / Ort',
'   --Update Land:  1  - pk_input_belege_all',
'   --Update Ort:  1  -  pk_input_belege_all',
' ',
' --3 Update Verwendungszweck',
'   --Update Verwendungszweck:  1  -  pk_input_belege_all',
' ',
unistr(' --4 Update Wiederholung, Update n\00E4chste Zahlung, Update n\00E4chste Zahlung1'),
'   --Update Wiederholung:  1  - pk_input_belege_all',
unistr('   --Update n\00E4chste Zahlung:   2 - v_fk_main_key (,) v_kontotyp '),
unistr('   --Update n\00E4chste Zahlung1:  2 - v_fk_main_key (,) v_kontotyp '),
'',
' --5 Update Kategorie',
'   --Update Kategorie: 1  -  pk_input_belege_all',
' ',
' ',
' --6 insert Inventar / remove Inventar',
'   --insert Inventar:  1  -  pk_input_belege_all',
'   --remove Inventar: 1  -  pk_input_belege_all',
' ',
' --7 insert Projekt / remove Projekt',
'    --insert Projekt: 1  - pk_input_belege_all',
'    --remove Projekt: 1  -  pk_input_belege_all',
' ',
unistr(' --8 set pers\00F6nlich vor Ort'),
unistr('     --set pers\00F6nlich vor Ort: 1  -  pk_input_belege_all'),
' ',
' --9 Update zahlungsart',
'     --Update zahlungsart: 1  -  pk_input_belege_all',
' ',
' --10 delete Beleg',
'     --delete Beleg:  1  -  pk_input_belege_all',
unistr(' --11 Update Gesch\00E4ftspartner'),
unistr('     --Update Gesch\00E4ftspartner: 1  -  pk_input_belege_all'),
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
