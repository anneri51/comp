prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 107
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(5215978410283946)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9599288521933091)
,p_group_name=>'Angebot'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9599441013935951)
,p_group_name=>'Location'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9599502027938369)
,p_group_name=>'Maschinenbau'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9599314024934579)
,p_group_name=>'Projektmanagement'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9600085149967089)
,p_group_name=>'Prozesse'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(9599623665939631)
,p_group_name=>'Stammdaten'
);
wwv_flow_api.component_end;
end;
/
