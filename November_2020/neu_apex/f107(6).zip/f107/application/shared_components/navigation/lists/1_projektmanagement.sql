prompt --application/shared_components/navigation/lists/1_projektmanagement
begin
--   Manifest
--     LIST: 1 Projektmanagement
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(5225906998321508)
,p_name=>'1 Projektmanagement'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5226910960321511)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Angebotserstellung'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12,14'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5230458942321514)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Projekttierung'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,3,40,11,9'
);
wwv_flow_api.component_end;
end;
/
