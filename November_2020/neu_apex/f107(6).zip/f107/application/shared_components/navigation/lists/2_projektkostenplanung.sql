prompt --application/shared_components/navigation/lists/2_projektkostenplanung
begin
--   Manifest
--     LIST: 2 Projektkostenplanung
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(5262971475329612)
,p_name=>'2 Projektkostenplanung'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5263984062329613)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Selbstkostenplanung'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30,21,5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5267441194329614)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Fremdkostenplanung'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30,33,32'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(9018673582933748)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Inbetriebnahmekosten'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5271673749329617)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Gesamtkostenplanung'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_api.component_end;
end;
/
