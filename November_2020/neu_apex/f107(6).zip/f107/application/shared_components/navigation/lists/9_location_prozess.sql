prompt --application/shared_components/navigation/lists/9_location_prozess
begin
--   Manifest
--     LIST: 9 Location Prozess
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(21510616592640432)
,p_name=>'9 Location Prozess'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21510930938640432)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Step 1 (Land)'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21511382420640432)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Step 2 (Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21511760779640432)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Step 3 (PLZ Ort)'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21512168591640433)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Step 4 (Stra\00DFe)')
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21512559120640433)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Step 5 (Location)'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(21512990962640433)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Step 6 (Location / Beleg)'
,p_list_item_link_target=>'f?p=107:276:107::107::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
