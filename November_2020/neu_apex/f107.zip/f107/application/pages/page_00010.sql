prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1431826922163694
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(20543567030983233)
,p_name=>'Stammdaten - Einzeln'
,p_alias=>'STAMMDATEN-EINZELN'
,p_step_title=>'Stammdaten - Einzeln'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(20705262428618092)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200726194122'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41183644740482569)
,p_plug_name=>'Auswahl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(41183775969482570)
,p_plug_name=>'Stammdaten'
,p_region_template_options=>'#DEFAULT#:t-Region--accent13:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(20458938251983137)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std.PK_STD,',
'       std.FK_STD_GROUP,',
'       std.STD_NAME,',
'       std.STD_VALUE,',
'       std.COMM,',
'       std.VALID,',
'       std.VALID_FROM,',
'       std.VALID_TO,',
'       std.CREATED_BY,',
'       std.CREATED_AT,',
'       std.MODIFIED_BY,',
'       std.MODIFIED_AT,',
'       std.MARK,',
'       std.SORT,',
'       std.FK_STD_FARBE,',
'       std.STD_NAME_ENG,',
'       std.FK_MDT_MANDANT,',
'       stdg.STD_GROUP_NAME',
'  from T_STD std',
'   left join t_std_group stdg on std.fk_std_group = stdg.pk_std_group and std.fk_mdt_mandant = stdg.fk_mdt_mandant',
'where std.fk_mdt_mandant = :P10_PK_MDT_MANDANT'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Stammdaten'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(41183907432482572)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>41183907432482572
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20625178527469391)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20625518427469391)
,p_db_column_name=>'VALID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Valid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20625925698469391)
,p_db_column_name=>'VALID_FROM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Valid From'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20626314571469391)
,p_db_column_name=>'VALID_TO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Valid To'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20626729114469391)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20627184594469392)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20627530205469392)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20627960987469392)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20628773783469393)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564002487013225)
,p_db_column_name=>'PK_STD'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Pk Std'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564108659013226)
,p_db_column_name=>'FK_STD_GROUP'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fk Std Group'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564215122013227)
,p_db_column_name=>'STD_NAME'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Std Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564359225013228)
,p_db_column_name=>'STD_VALUE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Std Value'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564442655013229)
,p_db_column_name=>'MARK'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Mark'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564540180013230)
,p_db_column_name=>'SORT'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Sort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564676017013231)
,p_db_column_name=>'FK_STD_FARBE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Fk Std Farbe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564780249013232)
,p_db_column_name=>'STD_NAME_ENG'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Std Name Eng'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20564843581013233)
,p_db_column_name=>'STD_GROUP_NAME'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Std Group Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(41238331837843018)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'206291'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_STD:STD_NAME:STD_VALUE:FK_STD_GROUP:STD_GROUP_NAME:COMM:VALID:VALID_FROM:VALID_TO:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:FK_MDT_MANDANT:MARK:SORT:FK_STD_FARBE:STD_NAME_ENG:'
,p_break_on=>'FK_STD_GROUP:STD_GROUP_NAME'
,p_break_enabled_on=>'FK_STD_GROUP:STD_GROUP_NAME'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20622878545469382)
,p_name=>'P10_PK_MDT_MANDANT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(41183644740482569)
,p_item_default=>'3'
,p_prompt=>'Pk Mdt Mandant'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mandant, pk_mdt_mandant',
'from t_mdt_mandant',
'where pk_mdt_mandant in (1,3)'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(20519966476983182)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20629583852469410)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_PK_MDT_MANDANT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20630042097469412)
,p_event_id=>wwv_flow_api.id(20629583852469410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.component_end;
end;
/
