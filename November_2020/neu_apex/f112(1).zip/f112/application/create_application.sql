prompt --application/create_application
begin
--   Manifest
--     FLOW: 112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'ORACLE')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'APEX Application Archive')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'7270')
,p_application_group=>23752528892236742
,p_application_group_name=>'20.1 Productivity Apps'
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'954F3DBD4F0A0C941FF00EE01E674E3067D9261F3DD3D6DAFF5F286765FC43C1'
,p_checksum_salt_last_reset=>'20150102073924'
,p_bookmark_checksum_function=>'SH1'
,p_max_session_length_sec=>28800
,p_max_session_idle_sec=>28800
,p_compatibility_mode=>'19.2'
,p_flow_language=>'en'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1.0.17 -> 1.0.18: Changed navigation region to native APEX list.',
'1.0.18 -> 1.0.19: Changed Authentication scheme to use new "APEX_PACKAGED_APPLICATIONS" cookie',
'1.0.19 -> 1.0.20: Added confirm modal when enabling ACL',
'1.0.20 -> 1.0.21: Fixed page 402 (mobile) to prevent overlapping text.',
'1.1.22 -> 1.1.23: Added "Rename Application" page and supporting application items, computations, substitution strings, item and region  changes on login pages, and UI Logo text replacement.',
'1.1.23 -> 1.1.24: Added Notifications functionality (admin list item, pages 36 and 37, and report regions on home page and mobile home page)',
'1.1.25 -> 1.1.26: Error handling procedure updated to resolve bug 17516350',
'1.1.26 -> 1.1.27: Implemented redesigned administrative ACL controls'))
,p_authentication=>'PLUGIN'
,p_authentication_id=>wwv_flow_api.id(4296837142778175588)
,p_application_tab_set=>0
,p_logo_type=>'T'
,p_logo_text=>'&APPLICATION_TITLE.'
,p_favicons=>'<link rel="shortcut icon" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-apex-application-archive.ico"><link rel="icon" sizes="16x16" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-apex-application-archive-16x16.png"><link rel="icon" sizes="32x32" href="'
||'#IMAGE_PREFIX#apex_ui/img/favicons/app-apex-application-archive-32x32.png"><link rel="apple-touch-icon" sizes="180x180" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-apex-application-archive.png">'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'2.1.5'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_deep_linking=>'Y'
,p_runtime_api_usage=>'T:W'
,p_security_scheme=>wwv_flow_api.id(3178217022053777117)
,p_rejoin_existing_sessions=>'P'
,p_csv_encoding=>'Y'
,p_error_handling_function=>'eba_archive_fw.apex_error_handling'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'APEX Application Archive'
,p_substitution_string_02=>'GETTING_STARTED_URL'
,p_substitution_value_02=>'#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201021202116'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>2
,p_ui_type_name => null
);
wwv_flow_api.component_end;
end;
/
