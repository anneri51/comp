prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install(
 p_id=>wwv_flow_api.id(2473557013686207276)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from user_tables',
' where table_name like ''EBA_ARCHIVE_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop package eba_archive;',
'drop package eba_archive_fw;',
'',
'drop sequence eba_archive_seq;',
'',
'begin',
'    wwv_flow_cloud_archive_obj.remove_archive_objects;',
'end;',
'/',
'',
'drop table eba_archive_users          cascade constraints;',
'drop table eba_archive_errors         cascade constraints;',
'drop table eba_archive_access_levels  cascade constraints;',
'drop table eba_archive_notifications  cascade constraints;',
'',
'drop table eba_archive_error_lookup;',
'',
'drop table eba_archive_preferences;',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_ARCHIVE:EBA_ARCHIVE_SEQ:EBA_ARCHIVE_ACCESS_LEVELS:EBA_ARCHIVE_PREFERENCES:EBA_ARCHIVE_ERROR_LOOKUP:EBA_ARCHIVE_USERS:EBA_ARCHIVE_FW'
,p_deinstall_message=>'This operation will completely remove this application from your workspace.'
);
wwv_flow_api.component_end;
end;
/
