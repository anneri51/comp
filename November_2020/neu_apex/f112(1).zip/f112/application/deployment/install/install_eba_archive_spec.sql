prompt --application/deployment/install/install_eba_archive_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_archive spec
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(3178215711617745707)
,p_install_id=>wwv_flow_api.id(2473557013686207276)
,p_name=>'eba_archive spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_archive is',
'    -------------------------------------------------------------------------',
'    -- Generates a unique Identifier',
'    -------------------------------------------------------------------------',
'    function gen_id return number;',
'',
'    -------------------------------------------------------------------------',
'    -- Gets the current user''s authorization level. Can depend on the following:',
'    --  * If access control is currently disabled, returns highest level of 3.',
'    --  * If access control is enabled, but user is not in list, returns 0',
'    --  * If access control is enabled and user is in list, returns their',
'    --    access level.',
'    -------------------------------------------------------------------------',
'    function get_authorization_level (',
'        p_username             varchar2)',
'        return number;',
'',
'end eba_archive;'))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(1662366758903666544)
,p_script_id=>wwv_flow_api.id(3178215711617745707)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_ARCHIVE'
,p_last_updated_on=>to_date('20141219062105','YYYYMMDDHH24MISS')
,p_created_on=>to_date('20141219062105','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
