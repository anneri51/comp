prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'APEX Application Archive'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297480025812594124)
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use this application to archive the Oracle Application Express (APEX) applications and files in this workspace.  Archives consist of export fi',
'les which are stored in APEX$ table in your local schema.  An Oracle APEX export file is a sqlplus compatible script which creates or recreates a',
'n application''s meta data.  You can use archives to revert or restore an application or file to an earlier point in time.  You can also search ar',
'chived copies of your application to see the meta data as it existed when the archive was performed.  This utility does not archive database data',
' or data structures, only applications and files.</p>'))
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'body { min-width: 800px !important;}',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span em{color:#EA0000}',
'',
'ul.barGraph{margin:12px !important;list-style:none;white-space:nowrap}',
'ul.barGraph li{display:inline-block;width:48px}',
'ul.barGraph li:hover big small{background-color:#4A6D98}',
'ul.barGraph li.barHeaders{width:128px}',
'ul.barGraph li.barHeaders > span{text-align:left}',
'ul.barGraph li > label{display:block;font:normal 11px/12px Arial,sans-serif;color:#444;text-align:center}',
'ul.barGraph li > label span{display:block;font:normal 11px/12px Arial,sans-serif;color:#767676}',
'ul.barGraph li > big{height:120px;margin:8px;position:relative;display:block}',
'ul.barGraph li > big > small{display:block;position:absolute;bottom:0;width:30px;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;background-color:#6A9CDA;-moz-box-shadow:0 1px 0 rgba(255,255,255,0.5) inset;-webkit-box-shadow:0 1px '
||'0 rgba(255,255,255,0.5) inset;box-shadow:0 1px 0 rgba(255,255,255,0.5) inset;border:1px solid #4A6D98}',
'ul.barGraph li > span{display:block;text-align:center;font:normal 11px/16px Arial,sans-serif;color:#444;border-top:1px solid #F0F0F0;padding:8px}',
'ul.barGraph li > span.noBorder{border-top:none;padding-top:0}',
'ul.barGraph li > span a{color:##405580}',
'</style>'))
,p_last_updated_by=>'DPEAKE'
,p_last_upd_yyyymmddhh24miss=>'20200123141451'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1225874527203398218)
,p_name=>'Archive Repository History'
,p_template=>wwv_flow_api.id(1252718055457814273)
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<span>''||apex_escape.html(y)||''</span>''||m||'' ''||d bar_label,',
'    to_char(afs/(1024*1024),''999G999G999G990'')||'' MB'' bar_value,',
'    round(100*afs/(first_value(afs) over (order by afs desc))) bar_height_pct,',
'    da distinct_applications,',
'    af archived_files',
'from (',
'    select y, m, d, ymd, afs, da, af, row_number() over (order by ymd desc) r',
'    from (',
'        select to_char(created,''YYYY'') y,',
'            to_char(created,''Mon'') m,',
'            to_char(created,''fmDD'') d,',
'            to_char(created,''YYYYMMDD'') ymd,',
'            archived_file_size afs,',
'            distinct_applications da,',
'            archived_files af',
'        from apex$archive_history',
'        where created in (',
'            select max(created)',
'            from apex$archive_history',
'            group by to_char(created,''YYYYMMDD'')',
'        )',
'        group by to_char(created,''YYYY''),',
'            to_char(created,''Mon''),',
'            to_char(created,''fmDD''),',
'            to_char(created,''YYYYMMDD''),',
'            archived_file_size,',
'            distinct_applications,',
'            archived_files',
'        )',
'    )',
'where r <= (',
'    select min(x)',
'    from (',
'        select count(distinct to_char(created,''YYYYMMDD'')) x',
'        from apex$archive_history t',
'        union all',
'        select 16 x from dual',
'        )',
'    )',
'order by ymd'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252723338497814278)
,p_query_num_rows=>25
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1225874836227398219)
,p_query_column_id=>1
,p_column_alias=>'BAR_LABEL'
,p_column_display_sequence=>1
,p_column_heading=>'BAR_LABEL'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1225874918735398219)
,p_query_column_id=>2
,p_column_alias=>'BAR_VALUE'
,p_column_display_sequence=>2
,p_column_heading=>'BAR_VALUE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1225875034250398219)
,p_query_column_id=>3
,p_column_alias=>'BAR_HEIGHT_PCT'
,p_column_display_sequence=>3
,p_column_heading=>'BAR_HEIGHT_PCT'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1225875134554398219)
,p_query_column_id=>4
,p_column_alias=>'DISTINCT_APPLICATIONS'
,p_column_display_sequence=>4
,p_column_heading=>'DISTINCT_APPLICATIONS'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1225875228800398219)
,p_query_column_id=>5
,p_column_alias=>'ARCHIVED_FILES'
,p_column_display_sequence=>5
,p_column_heading=>'ARCHIVED_FILES'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1356143713187943513)
,p_name=>'Notifications'
,p_template=>wwv_flow_api.id(1252711439049814264)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_new_grid_column=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     id,',
'    decode(lower(NOTIFICATION_TYPE),''yellow'',''warning'',''red'',''danger'',lower(NOTIFICATION_TYPE)) as ALERT_TYPE,',
'    NOTIFICATION_NAME as ALERT_TITLE,',
'    NOTIFICATION_DESCRIPTION as ALERT_DESC,',
'    '''' alert_action',
'  from EBA_ARCHIVE_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)',
' order by nvl(DISPLAY_SEQUENCE,0),NOTIFICATION_NAME'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from EBA_ARCHIVE_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1629158408044363491)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1356144033115943514)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1899480351817094610)
,p_query_column_id=>2
,p_column_alias=>'ALERT_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Alert Type'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1899480762716094610)
,p_query_column_id=>3
,p_column_alias=>'ALERT_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Alert Title'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1899481154471094610)
,p_query_column_id=>4
,p_column_alias=>'ALERT_DESC'
,p_column_display_sequence=>4
,p_column_heading=>'Alert Desc'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1899481469493094611)
,p_query_column_id=>5
,p_column_alias=>'ALERT_ACTION'
,p_column_display_sequence=>5
,p_column_heading=>'Alert Action'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1633192990857812606)
,p_plug_name=>'&APPLICATION_TITLE.'
,p_icon_css_classes=>'app-apex-application-archive'
,p_plug_template=>wwv_flow_api.id(1252714661433814268)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ( select preference_value',
'            from eba_archive_preferences',
'            where preference_name = ''APPLICATION_SUBTITLE''',
'            union all',
'            select ''Archive Oracle Application Express (APEX) applications''',
'            from dual',
'            where not exists ( select null',
'                               from eba_archive_preferences',
'                               where preference_name = ''APPLICATION_SUBTITLE'')',
'          ) loop',
'    sys.htp.p(''<p>''||apex_escape.html(c1.preference_value)||''</p>'');',
'end loop;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1714773191153185019)
,p_plug_name=>'Overview'
,p_region_css_classes=>'i-h220'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  1 display_sequence,',
'        workspace_display_name display_value,',
'       ''Workspace'' as label,',
'       ''#'' as the_link',
'from apex_workspaces a',
'where workspace_id = :flow_security_group_id',
'union all',
'select 2 display_sequence,',
'       to_char(count(*) ,''999G999G999G990'')    as display_value,',
'       ''Archives'' as label,',
'       apex_util.prepare_url(''f?p=&APP_ID.:3:&APP_SESSION.::NO:3,RIR::'') as the_link',
' from APEX$ARCHIVE_HEADER',
'union all',
'select',
'  3 display_sequence,',
'  to_char(count(*) ,''999G999G999G990'')  as display_value,',
'  ''Workspace Apps'' as label,',
'  apex_util.prepare_url(''f?p=&APP_ID.:4:&APP_SESSION.::NO:4,RIR::'') as the_link',
'from apex_applications a',
'where workspace_id = :flow_security_group_id',
'and upper(build_status) <> ''RUN AND HIDDEN''',
'union all',
'select ',
'  4 display_sequence,',
'  to_char(',
'      sum(',
'         decode(greatest(c.created,a.last_updated_on),c.created,0,1)),',
'  ''999G999G999G990'') as display_value,',
'  ''Changed Apps'' as label,',
'  replace(apex_util.prepare_url(''f?p=&APP_ID.:4:&APP_SESSION.::NO:4,RIR:IREQ_STATUS:Changed since last archive''),''%20'','' '') as the_link',
'from apex_applications a, (select app_id, max(created) created from APEX$ARCHIVE_contents group by app_id) c',
'where a.workspace_id = :flow_security_group_id and ',
'      a.application_id = c.app_id and',
'      upper(a.build_status) <> ''RUN AND HIDDEN''',
'order by 1'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'LABEL'
,p_attribute_02=>'DISPLAY_VALUE'
,p_attribute_04=>'&THE_LINK.'
,p_attribute_05=>'2'
,p_attribute_06=>'B'
,p_attribute_07=>'BOX'
,p_attribute_08=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1714881953950750982)
,p_plug_name=>'Archive Size by Date (in MB)'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select y||'' ''||m||'' ''||d bar_label,',
'    round(afs/(1024*1024),2) bar_value,',
'    round(100*afs/(first_value(afs) over (order by afs desc))) bar_height_pct,',
'    da distinct_applications,',
'    af archived_files,',
'    to_char(to_date(ymd,''YYYYMMDD''),''DD-MON-YY'') as filter',
'from (',
'    select y, m, d, ymd, afs, da, af, row_number() over (order by ymd desc) r',
'    from (',
'        select to_char(created,''YYYY'') y,',
'            to_char(created,''Month'') m,',
'            to_char(created,''fmDD'') d,',
'            to_char(created,''YYYYMMDD'') ymd,',
'            archived_file_size afs,',
'            distinct_applications da,',
'            archived_files af',
'        from apex$archive_history',
'        where created in (',
'            select max(created)',
'            from apex$archive_history',
'            group by to_char(created,''YYYYMMDD'')',
'        )',
'        group by to_char(created,''YYYY''),',
'            to_char(created,''Month''),',
'            to_char(created,''fmDD''),',
'            to_char(created,''YYYYMMDD''),',
'            archived_file_size,',
'            distinct_applications,',
'            archived_files',
'        )',
'    )',
'where r <= (',
'    select min(x)',
'    from (',
'        select count(distinct to_char(created,''YYYYMMDD'')) x',
'        from apex$archive_history t',
'        union all',
'        select 16 x from dual',
'        )',
'    )',
'order by ymd desc '))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'INITIALS'
,p_attribute_02=>'BAR_LABEL'
,p_attribute_03=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP,11,RIR:IREQ_CREATED_ON:&FILTER.'
,p_attribute_04=>'BAR_VALUE'
,p_attribute_05=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP,11,RIR:IREQ_CREATED_ON:&FILTER.'
,p_attribute_11=>'VALUE'
,p_attribute_14=>'50'
,p_attribute_15=>'TEXT'
,p_attribute_16=>'ABSOLUTE'
,p_attribute_17=>'MODERN'
,p_attribute_18=>'AROUND'
,p_attribute_20=>'No data found.'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1847903337227835548)
,p_plug_name=>'ACL Warning'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--defaultIcons:t-Alert--warning:t-Alert--horizontal'
,p_plug_template=>wwv_flow_api.id(1252710023340814262)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ACL_WARNING'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'PLSQL_EXPRESSION'
,p_plug_display_when_condition=>'eba_archive_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''N'''
,p_attribute_01=>'f?p=&APP_ID.:SETTINGS:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1920221569411086977)
,p_name=>'Recent Archives'
,p_template=>wwv_flow_api.id(1252718055457814273)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'i-h220'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--showBadges:t-MediaList--stack'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    id,',
'    archive_name as list_title,',
'    created,',
'    created_by,',
'    apex_page.get_url(p_page => 7,  p_items => ''P7_ARCHIVE_ID'', p_values => id) link,',
'    '' '' link_attr,',
'    '' '' link_class,',
'    '' '' list_badge,',
'    '' '' list_class,',
'    '' '' list_text,',
'    workspace_id,',
'    workspace_name,',
'    schema,',
'    db_pod as database_pod,',
'    comments,',
'    retentions_in_days,',
'    updated_by,',
'    updated,',
'    ''fa-book'' as icon',
'from',
'    APEX$ARCHIVE_HEADER',
'order by',
'    created desc'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(696192870743679949)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688711590278812861)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712922205812874)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>13
,p_column_heading=>'List title'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688711816048812863)
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>2
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688711899738812864)
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>3
,p_column_heading=>'Created by'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713505167812880)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>19
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713011138812875)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>14
,p_column_heading=>'Link attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713168377812876)
,p_query_column_id=>7
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>15
,p_column_heading=>'Link class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713181631812877)
,p_query_column_id=>8
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>16
,p_column_heading=>'List badge'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#CREATED#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713332848812878)
,p_query_column_id=>9
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>17
,p_column_heading=>'List class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688713428077812879)
,p_query_column_id=>10
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>18
,p_column_heading=>'List text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'Retention: #RETENTIONS_IN_DAYS# Day(s)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712011699812865)
,p_query_column_id=>11
,p_column_alias=>'WORKSPACE_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Workspace id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712111334812866)
,p_query_column_id=>12
,p_column_alias=>'WORKSPACE_NAME'
,p_column_display_sequence=>5
,p_column_heading=>'Workspace name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712211740812867)
,p_query_column_id=>13
,p_column_alias=>'SCHEMA'
,p_column_display_sequence=>6
,p_column_heading=>'Schema'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712346751812868)
,p_query_column_id=>14
,p_column_alias=>'DATABASE_POD'
,p_column_display_sequence=>7
,p_column_heading=>'Database pod'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712393393812869)
,p_query_column_id=>15
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>8
,p_column_heading=>'Comments'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712489397812870)
,p_query_column_id=>16
,p_column_alias=>'RETENTIONS_IN_DAYS'
,p_column_display_sequence=>9
,p_column_heading=>'Retentions in days'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712580673812871)
,p_query_column_id=>17
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Updated by'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712677309812872)
,p_query_column_id=>18
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(688712868565812873)
,p_query_column_id=>19
,p_column_alias=>'ICON'
,p_column_display_sequence=>12
,p_column_heading=>'Icon'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2497399311492448124)
,p_plug_name=>'Overview OLD'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>' style="height: 300px; overflow: hidden;" data-grid="col_2" data-grid-start="yes"  '
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_archives integer :=0;',
'begin',
'sys.htp.prn(''<ul class="vapList">'');',
'',
'for c1 in (select workspace_display_name',
'from apex_workspaces a',
'where workspace_id = :flow_security_group_id) loop',
'    sys.htp.p(''<li><label>Workspace</label><span>'');',
'    sys.htp.p(apex_escape.html(c1.workspace_display_name));',
'    sys.htp.prn(''</span></li>'');',
'end loop;',
'for c1 in (',
'select count(*) archives',
' from APEX$ARCHIVE_HEADER) loop',
'    l_archives := c1.archives;',
'end loop;',
'',
'',
'for c1 in (',
'select',
'  count(*) applications,',
'  sum(decode(last_archived,null,0,',
'    decode(greatest(last_archived,last_updated_on),last_archived,',
'      1,0))) archived_apps',
'from',
'(',
'select ',
'  LAST_UPDATED_ON,',
'  (select max(created) ',
'   from apex$archive_contents c',
'   where a.application_id = c.app_id) last_archived,',
'  (select count(*) c',
'   from apex$archive_contents c',
'   where a.application_id = c.app_id) archived_versions',
'from apex_applications a',
'where workspace_id = :flow_security_group_id',
'and upper(build_status) <> ''RUN AND HIDDEN''',
') x) loop',
'',
' sys.htp.p(''<li><label>Applications</label><span>'');',
' sys.htp.prn(trim(to_char(c1.applications,''999G999G999G999G999G990'')));',
' sys.htp.prn('' total<br />''||',
'   trim(to_char(c1.archived_apps,''999G999G999G999G999G990''))||',
'   '' archived''||',
'   ''<br />''||',
'   trim(to_char((c1.applications - c1.archived_apps),''999G999G999G999G999G990''))||',
'   '' not archived''',
'   );',
'   sys.htp.prn(''</span></li>'');',
'end loop;',
'',
'',
'for c1 in (',
'select count(*) archive_count,',
'       count(distinct app_id) distinct_applications,',
'       sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'       sum(decode(CONTENT_TYPE,''FILE'',1,0)) archived_files,',
'       sum(dbms_lob.getlength(content)) content_size',
' from APEX$ARCHIVE_CONTENTS) loop',
'',
'    sys.htp.p(''<li><label>Archived Content</label><span>'');',
'    sys.htp.prn(trim(to_char(c1.archive_count,''999G999G999G999G999G990'')));',
'    sys.htp.prn('' components organized in ''||to_char(l_archives,''999G999G999G999G999G990'')||'' archives<br /> ''||',
'   trim(to_char(c1.archived_applictions,''999G999G999G999G999G990''))||''  Application Export Files'');',
'    sys.htp.prn(''<br /> ''||',
'   trim(to_char(c1.distinct_applications,''999G999G999G999G999G990''))||''  Distinct Applications'');',
'    --sys.htp.prn(''<br /> ''||',
'   --trim(to_char(c1.archived_files,''999G999G999G999G999G990''))||''  Archived Files'');',
'   sys.htp.prn(''</span>'');',
'   sys.htp.prn(''</li>'');',
'',
'if c1.content_size > 0 then',
'    sys.htp.p(''<li><label>Archive Size</label><span>'');',
'    sys.htp.p( to_char( c1.content_size / 1024 / 1024, ''fm999G999G999G999G999G990'' ) || '' MB</span></li>'' );',
'end if;',
'',
'end loop;',
'end;',
'',
'sys.htp.prn(''</ul>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'NEVER'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2541699817902795203)
,p_plug_name=>'Recent Archives OLD'
,p_region_css_classes=>'i-h200'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  l_cnt pls_integer := 0;',
'begin',
'',
'sys.htp.p(''<ul class="vapList">'');',
'',
'for c1 in (',
'select id, archive_name, created, created_by ',
'from APEX$ARCHIVE_HEADER',
'order by created desc )',
' ',
'loop',
'  l_cnt := l_cnt+1;',
'  sys.htp.p(''<li><span><a href="''',
'    ||apex_util.prepare_url(''f?p=''||:APP_ID||'':7:''||:APP_SESSION||''::NO:RP,7,:P7_ARCHIVE_ID:''||c1.id)',
'    ||''">''||apex_escape.html(c1.archive_name)||''</a> Archived by <strong>''||apex_escape.html(lower(c1.created_by))||''</strong> ''||apex_util.get_since(c1.created)||''</span></li>'');',
'  if l_cnt = 7 then',
'      exit;',
'  end if;',
'end loop;',
'',
'sys.htp.p(''</ul>'');',
'',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4296838950103175602)
,p_plug_name=>'Breadcrumbs'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3233638011294384970)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1714881953950750982)
,p_button_name=>'VIEW_HISTORY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'View History'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2513756132571820806)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1633192990857812606)
,p_button_name=>'MANAGE_ARCHIVES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Manage Archives'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_security_scheme=>wwv_flow_api.id(3178213613384693719)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2557712515053175541)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(1633192990857812606)
,p_button_name=>'RESTORE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Restore'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,RIR,CIR::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2690847609934507251)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(1633192990857812606)
,p_button_name=>'search_content'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Search Content'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:26::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2481582525860210284)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(1633192990857812606)
,p_button_name=>'ARCHIVE_FULL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive Applications'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5,10,9::'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(146346476312819448)
,p_branch_name=>'Check First Run'
,p_branch_action=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'PLSQL_EXPRESSION'
,p_branch_condition=>'eba_archive_fw.get_preference_value(''FIRST_RUN'') = ''YES'''
,p_security_scheme=>wwv_flow_api.id(3178213613384693719)
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(2047966717579725909)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_api.component_end;
end;
/
