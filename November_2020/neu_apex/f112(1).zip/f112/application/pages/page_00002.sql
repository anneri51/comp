prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive History'
,p_alias=>'ARCHIVE-HISTORY'
,p_step_title=>'Archive History'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(1297479619578592289)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_help_text=>'<p>This page lists all archived versions of your application and additional change history.</p>'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304466417445650597)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This page lists all archived versions of your application and additional change history.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2475424420837831950)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2478952038019389268)
,p_plug_name=>'Content'
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    c integer := 0;',
'begin',
'for c1 in (',
'select ',
'  application_name, ',
'  application_id, ',
'  pages, ',
'  owner, ',
'  LAST_UPDATED_ON, ',
'  last_updated_by',
'from apex_applications where application_id = :P2_APP_ID',
'and upper(build_status) <> ''RUN AND HIDDEN''',
') loop',
'--',
'sys.htp.prn(''<ul class="vapList">'');',
'',
'sys.htp.p(''<li><label>Archive Application</label><span>'');',
'sys.htp.p(apex_escape.html(c1.application_name)||''</span></li>'');',
'--',
'sys.htp.p(''<li><label>Pages</label><span>'');',
'sys.htp.p(apex_escape.html(c1.pages)||''</span></li>'');',
'--',
'sys.htp.p(''<li><label>Parsing Schema</label><span>'');',
'sys.htp.p(apex_escape.html(c1.owner)||''</span></li>'');',
'--',
'sys.htp.p(''<li><label>Last Updated</label><span>'');',
'sys.htp.p(apex_escape.html(apex_util.get_since(c1.LAST_UPDATED_ON))||'' by ''||',
'    apex_escape.html(lower(c1.last_updated_by))||''</span></li>'');',
'    ',
'',
'    ',
'    -- application versions',
'    c := 0;',
'    sys.htp.p(''<li><label>Application Archives</label><span>'');',
'    for c2 in (',
'     select id, version, created, created_by, dbms_lob.getlength(CONTENT) s ',
'     from APEX$ARCHIVE_CONTENTS',
'     where app_id = c1.application_id  and CONTENT_TYPE = ''APPLICATION''',
'     order by created desc) loop',
'        c := c + 1;',
'        sys.htp.p(''<a href="''',
'          ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'          ||''" title="Access Archive" >',
'Version ''||apex_escape.html(c2.version)||''</a> Archived ''||apex_util.get_since(c2.created)||'' by ''||lower(apex_escape.html(c2.created_by))||'', size ''|| apex_util.filesize_mask( c2.s ) ||'', ''',
'          ||''<a href="''',
'          ||apex_util.prepare_url(''f?p=''||:APP_ID||'':27:''||:APP_SESSION||'':::27:P27_APPLICATION:''||c2.id)',
'          ||''">View Source</a><br />'');',
'        if c > 15 then exit; end if;',
'    end loop;',
'    if c = 0 then sys.htp.p(''None''); end if;',
'    sys.htp.p(''</span></li>'');    ',
'',
'    -- file versions',
'    -- file versions',
'    c := 0;',
'    sys.htp.p(''<li><label>Archived Files</label><span>'');',
'    for c2 in (',
'     select id, version, CONTENT_FILENAME , created, created_by, dbms_lob.getlength(CONTENT) s ',
'     from APEX$ARCHIVE_CONTENTS',
'     where app_id = c1.application_id  and CONTENT_TYPE = ''FILE''',
'     order by created desc) loop',
'        c := c + 1;',
'        sys.htp.p(apex_escape.html(c2.CONTENT_FILENAME)||'', <a href="''',
'          ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'          ||''" title="Access Archive" >',
'Version ''||apex_escape.html(c2.version)||''</a> Archived ''||apex_util.get_since(c2.created)||'' by ''||lower(apex_escape.html(c2.created_by))||'', size ''|| apex_util.filesize_mask( c2.s ) ||''<br />'');',
'        if c > 15 then exit; end if;',
'    end loop;',
'    if c = 0 then sys.htp.p(''None''); end if;',
'    sys.htp.p(''</span></li>'');   ',
'    ',
'    -- recently edited pages',
'    c := 0;',
'    sys.htp.p(''<li><label>Recently Edited Pages</label><span>'');',
'    for c2 in (',
'        select page_id, page_name, last_updated_on, last_updated_by ',
'        from apex_application_pages ',
'        where application_id = c1.application_id ',
'        order by last_updated_on desc) loop',
'        c := c + 1;',
'        sys.htp.p(''Page ''||c2.page_id||'' "''||apex_escape.html(c2.page_name)|| ''" last updated ''||apex_util.get_since(c2.last_updated_on)||'' by ''||lower(apex_escape.html(c2.last_updated_by))||''<br />'');',
'        if c > 15 then exit; end if;',
'    end loop;',
'    if c = 0 then sys.htp.p(''None''); end if;',
'    sys.htp.p(''</span></li>''); ',
'    ',
'    sys.htp.p(''</ul>'');',
'end loop;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2482398834714325062)
,p_button_sequence=>1
,p_button_plug_id=>wwv_flow_api.id(2475424420837831950)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2479112940144418268)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2475424420837831950)
,p_button_name=>'ARCHIVE_APPLICATION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive Application'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_APP_ID:&P2_APP_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2478975216333392458)
,p_name=>'P2_APP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2478952038019389268)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
