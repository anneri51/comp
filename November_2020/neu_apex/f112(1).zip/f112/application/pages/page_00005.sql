prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Create Application Archive'
,p_alias=>'CREATE-APPLICATION-ARCHIVE'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Application Archive'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(1297485020233639767)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1589349338215115269)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2482486434114352729)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p(apex_escape.html(wwv_flow_lang.message(''ARCHIVE_WIZ_PG_1'')));',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2497046109320390727)
,p_plug_name=>'Form Elements'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3279635841227140725)
,p_plug_name=>'Note'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_api.id(1252710023340814262)
,p_plug_display_sequence=>15
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>'Packaged applications will not be archived, only applications you can edit are archivable.'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2482487037795352731)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1589349338215115269)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2482487210224352731)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1589349338215115269)
,p_button_name=>'ARCHIVE_NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2482488210469352747)
,p_branch_action=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RIR,CIR,10::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(2482487210224352731)
,p_branch_sequence=>10
,p_branch_comment=>'Created 18-NOV-2011 07:13 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2482486631808352729)
,p_name=>'P5_APP_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2497046109320390727)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2490126526960764071)
,p_name=>'P5_ARCHIVE_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2497046109320390727)
,p_item_default=>'INCREMENTAL'
,p_source=>'INCREMENTAL'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2490262132070784444)
,p_name=>'P5_ARCHIVE_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2497046109320390727)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return wwv_flow_lang.system_message(''Archive'')||'' ''||to_char(localtimestamp,''YYYY'')||''.''||',
'to_char(localtimestamp,''MM'')||''.''||',
'to_char(localtimestamp,''DD'')||''.''||',
'to_char(localtimestamp,''HH24MISS'');'))
,p_item_default_type=>'PLSQL_FUNCTION_BODY'
,p_prompt=>'Archive Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1252730828830814289)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1589349387021115270)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2482487037795352731)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1589349517982115271)
,p_event_id=>wwv_flow_api.id(1589349387021115270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2482487929068352741)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'archive application'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_app_clob         clob;',
' l_wksp_clob        clob;',
' l_workspace_id     number;',
' l_workspace        varchar2(255);',
' l_owner            varchar2(255);',
' l_id               number;',
' l_application_name varchar2(255);',
' l_application_id   number;',
' l_app_blob         blob;',
' l_elap             number;',
' l_start            timestamp;',
' max_apps           number := 50;',
' c                  number := 0;',
' function get_elapsed_time',
'    return number',
'is',
'    l_interval   interval day to second;',
'    l_current_ts timestamp;',
' begin',
'    l_current_ts := systimestamp at time zone ''GMT'';',
'    l_interval := l_current_ts - l_start;',
'    return extract(second from l_interval) + extract( minute from l_interval) * 60;',
' end get_elapsed_time;',
'begin',
' for c in (select workspace from apex_workspaces where workspace_id = :FLOW_SECURITY_GROUP_ID) loop',
'    l_workspace := c.workspace;',
'    exit;',
' end loop;',
' ',
' insert into  apex$archive_header ',
'    (version, archive_name, workspace_id, workspace_name, schema)',
'    values ',
'    (1, :P5_ARCHIVE_NAME,',
'     :flow_security_group_id, l_workspace, :APP_USER) ',
'    returning id into l_id;',
' commit;',
'',
' for c0 in (select application_id from apex_applications where workspace_id = :flow_security_group_id order by LAST_UPDATED_ON desc, 1) loop',
'     c := c + 1;',
'     l_start := systimestamp at time zone ''GMT'';',
'     for c1 in (',
'        select application_id, workspace_id, workspace, owner, application_name',
'        from apex_applications where application_id = c0.application_id) loop',
'        l_workspace := c1.workspace;',
'        l_workspace_id := c1.workspace_id;',
'        l_owner := c1.owner;',
'        l_application_id := c1.application_id;',
'        l_application_name := c1.application_name;',
'',
'     l_app_clob := wwv_flow_utilities.export_application_to_clob (',
'       p_application_id   => c1.application_id,',
'       p_export_ir_public_reports  =>  ''N'',',
'       p_export_ir_private_reports =>  ''N'',',
'       p_export_ir_notifications   =>  ''N'',',
'       p_export_translations       =>  ''Y'');',
'     l_app_blob := wwv_flow_utilities.clob_to_blob(l_app_clob);',
'',
'     l_elap := get_elapsed_time;',
'     insert into apex$archive_contents (',
'        header_id, app_id, app_name, content, content_type, creation_elap_time,',
'        CONTENT_MIMETYPE, CONTENT_FILENAME)',
'        values ',
'        (l_id, l_application_id, l_application_name, l_app_blob, ''APPLICATION'', l_elap,',
'        ''application/octet-stream'',''f''||to_char(l_application_id)||''.sql'');',
'',
'     commit;',
'     end loop; --c1',
'     if c = 10 then exit; end if;',
' end loop; -- c0',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_process_success_message=>'Application Archived'
);
wwv_flow_api.component_end;
end;
/
