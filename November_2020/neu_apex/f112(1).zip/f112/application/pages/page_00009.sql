prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Create Application Archive'
,p_alias=>'CREATE-APPLICATION-ARCHIVE2'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Application Archive'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297485020233639767)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201021202116'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1218278830028896098)
,p_name=>'Archive Details'
,p_template=>wwv_flow_api.id(1252718055457814273)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent4:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P5_ARCHIVE_NAME archive_name,',
'    :P5_ARCHIVE_TYPE type,',
'    replace(replace(replace(rtrim(:P10_APPLICATIONS_TO_ARCHIVE,'':''),'':'','', ''),''-'','' <b>Application:</b> ''),'','','', <b>Workspace:</b> '') applications',
'from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252724637305814280)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218279118816896126)
,p_query_column_id=>1
,p_column_alias=>'ARCHIVE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'Archive Name'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218279220005896130)
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218279317533896130)
,p_query_column_id=>3
,p_column_alias=>'APPLICATIONS'
,p_column_display_sequence=>3
,p_column_heading=>'Applications to Archive'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1546051318157243568)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Verify your archive''s name, the list of applications being archived, and add optional archive comments.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1589349672429115273)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2492978721178657501)
,p_plug_name=>'Form Elements'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1298312835748160987)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1589349672429115273)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2493005723569659892)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1589349672429115273)
,p_button_name=>'ARCHIVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Archive'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2493005529489659892)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1589349672429115273)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2496724923903347614)
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,RIR,CIR::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 21-NOV-2011 06:30 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2493250608898767440)
,p_name=>'P9_COMMENTS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2492978721178657501)
,p_prompt=>'Archive Comments'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2527556712268942508)
,p_name=>'submit page'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2493005723569659892)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2527557034567942508)
,p_event_id=>wwv_flow_api.id(2527556712268942508)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ARCHIVE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2492922418839637904)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'archive application'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_vc_arr2    APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    l_hdr_id     number;',
'    z            integer;',
'    l_workspace  number;',
'    l_application_to_archive varchar(4000 char);',
'BEGIN',
'    l_vc_arr2 := APEX_UTIL.STRING_TO_TABLE(ltrim(rtrim(:P10_APPLICATIONS_TO_ARCHIVE,'':''),'':''));',
'    ',
'    l_hdr_id := apex_cloud_archive.create_header(',
'                    p_workspace_id          => :flow_security_group_id,',
'                    p_version               => 1,',
'                    p_archive_name          => :P5_ARCHIVE_NAME,',
'                    p_comments              =>:P9_COMMENTS);    ',
'',
'    FOR z IN 1..l_vc_arr2.count LOOP',
'        apex_cloud_archive.archive_applications(',
'           -- p_workspace_id    => :flow_security_group_id,',
'            p_workspace_id  => substr(l_vc_arr2(z),1,instr(l_vc_arr2(z),''-'')-1) ,',
'            p_header_id       => l_hdr_id,',
'           -- p_application_id  => l_vc_arr2(z));',
'           p_application_id  =>  substr(l_vc_arr2(z),instr(l_vc_arr2(z),''-'')+1,length(l_vc_arr2(z)) ));',
'         --  insert into company.test (inhalte) values (substr(l_vc_arr2(z),1,instr(l_vc_arr2(z),''-'')-1) );',
'         --  insert into company.test (inhalte) values (substr(l_vc_arr2(z),instr(l_vc_arr2(z),''-'')+1,length(l_vc_arr2(z)) ));',
'         --   insert into company.test (inhalte) values (l_vc_arr2(z));',
'         --  commit;',
'    END LOOP;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ARCHIVE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Archived completed.'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_app_clob         clob;',
' l_wksp_clob        clob;',
' l_workspace_id     number;',
' l_workspace        varchar2(255);',
' l_owner            varchar2(255);',
' l_id               number;',
' l_application_name varchar2(255);',
' l_application_id   number;',
' l_app_blob         blob;',
' l_elap             number;',
' l_start            timestamp;',
' max_apps           number := 50;',
' c                  number := 0;',
' g_log_seq          integer := 0;',
'procedure log_history as',
'begin',
'for c1 in ( ',
'select count(*) archive_count,',
'       count(distinct app_id) distinct_applications,',
'       sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'       sum(dbms_lob.getlength(content)) content_size',
' from APEX$ARCHIVE_CONTENTS) loop',
'  insert into apex$archive_history (',
'   archived_applications,',
'   distinct_applications,',
'   archived_files,',
'   archived_file_size) ',
'  values (',
'   c1.archived_applictions,',
'   c1.distinct_applications,',
'   c1.archive_count,',
'   c1.content_size);',
'end loop;',
'commit;',
'end log_history;',
' procedure log (',
'   p_message in varchar2)',
' is',
' begin ',
'    g_log_seq := g_log_seq + 1;',
'    insert into APEX$ARCHIVE_LOG (log_entry, log_session, log_sequence) values (p_message, :APP_SESSION, g_log_seq);',
'    commit;',
' end;',
'',
' function get_elapsed_time',
'    return number',
'is',
'    l_interval   interval day to second;',
'    l_current_ts timestamp;',
' begin',
'    l_current_ts := systimestamp at time zone ''GMT'';',
'    l_interval := l_current_ts - l_start;',
'    return extract(second from l_interval) + extract( minute from l_interval) * 60;',
' end get_elapsed_time;',
'begin',
' for c in (',
'    select workspace ',
'    from apex_workspaces ',
'    where workspace_id = :FLOW_SECURITY_GROUP_ID) loop',
'    l_workspace := c.workspace;',
'    exit;',
' end loop;',
' ',
' insert into  apex$archive_header ',
'    (version, archive_name, workspace_id, workspace_name, schema, comments)',
'    values ',
'    (1, :P5_ARCHIVE_NAME,',
'     :flow_security_group_id, l_workspace, :APP_USER, :P9_COMMENTS) ',
'    returning id into l_id;',
' commit;',
'',
' for c0 in (',
'    select application_id ',
'    from apex_applications a',
'    where workspace_id = :flow_security_group_id and',
'      instr('':''||:P10_APPLICATIONS_TO_ARCHIVE||'':'', '':''||to_char(a.application_id)||'':'' ) > 0',
'    order by LAST_UPDATED_ON desc, 1) loop',
'     c := c + 1;',
'     l_start := systimestamp at time zone ''GMT'';',
'     for c1 in (',
'        select application_id, workspace_id, workspace, owner, application_name',
'        from apex_applications where application_id = c0.application_id) loop',
'        l_workspace := c1.workspace;',
'        l_workspace_id := c1.workspace_id;',
'        l_owner := c1.owner;',
'        l_application_id := c1.application_id;',
'        l_application_name := c1.application_name;',
'',
'     l_app_clob := wwv_flow_utilities.export_application_to_clob (',
'       p_application_id   => c1.application_id,',
'       p_export_ir_public_reports  =>  ''N'',',
'       p_export_ir_private_reports =>  ''N'',',
'       p_export_ir_notifications   =>  ''N'',',
'       p_export_translations       =>  ''Y'');',
'     l_app_blob := wwv_flow_utilities.clob_to_blob(l_app_clob);',
'',
'     l_elap := get_elapsed_time;',
'     insert into apex$archive_contents (',
'        header_id, app_id, app_name, content, content_type, creation_elap_time,',
'        CONTENT_MIMETYPE, CONTENT_FILENAME)',
'        values ',
'        (l_id, l_application_id, l_application_name, l_app_blob, ''APPLICATION'', l_elap,',
'        ''application/octet-stream'',''f''||to_char(l_application_id)||''.sql'');',
'     log(''Application ''||l_application_id||'' with length ''||',
'       to_char(dbms_lob.getlength(l_app_blob),''999G999G999G999G990'')||'' bytes archived.'');',
'     commit;',
'     end loop; --c1',
'     if c > 20 then ',
'        log(''attempting to archive more then 20 applications is not permitted in one call'');',
'        exit; ',
'     end if;',
' end loop; -- c0',
'',
'-- history',
'   log_history;',
'end;'))
);
wwv_flow_api.component_end;
end;
/
