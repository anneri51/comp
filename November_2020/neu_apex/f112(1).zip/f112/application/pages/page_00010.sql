prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Create Application Archive'
,p_alias=>'CREATE-APPLICATION-ARCHIVE3'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Application Archive'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297485020233639767)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201021194033'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1218284737263945572)
,p_name=>'Archive Details'
,p_template=>wwv_flow_api.id(1252711439049814264)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P5_ARCHIVE_NAME archive_name,',
'	:P5_ARCHIVE_TYPE type',
'from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252724637305814280)
,p_query_headings_type=>'QUERY_COLUMNS_INITCAP'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218285014720945574)
,p_query_column_id=>1
,p_column_alias=>'ARCHIVE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'ARCHIVE_NAME'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218285129401945574)
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'TYPE'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1589349581304115272)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2496438310862304441)
,p_plug_name=>'Confirm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2498583229947935938)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p(''<p>''||apex_escape.html(',
'    wwv_flow_lang.message(''ARCHIVE_WIZ_PG_2''))||''</p>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1298312112901156417)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1589349581304115272)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2496439133925304442)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1589349581304115272)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2496438909419304442)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1589349581304115272)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2496535537577313724)
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 21-NOV-2011 06:24 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2496796335116360311)
,p_name=>'P10_APPLICATIONS_TO_ARCHIVE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2496438310862304441)
,p_prompt=>'Select Applications to Archive'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'   r varchar2(32767) := null;',
'begin',
'if nvl(:P5_ARCHIVE_TYPE,''INCREMENTAL'') = ''FULL'' then',
'-- full export',
'for c1 in (',
'select',
'  application_id',
'from apex_applications a',
'where workspace_id = :FLOW_SECURITY_GROUP_ID',
'  and build_status != ''Run and Hidden''',
'order by 1)',
'loop',
'    r := r||to_char(c1.application_id)||'':'';',
'end loop;',
'',
'else',
'-- Incremental Export',
'for c1 in (',
'select',
'  application_id',
'from',
'(',
'select ',
'  application_id,',
'  LAST_UPDATED_ON,',
'  (select max(created) ',
'   from apex$archive_contents c',
'   where a.application_id = c.app_id) last_archived,',
'  (select count(*) c',
'   from apex$archive_contents c',
'   where a.application_id = c.app_id) archived_versions',
'from apex_applications a',
'where workspace_id = :FLOW_SECURITY_GROUP_ID',
'  and build_status != ''Run and Hidden''',
') x',
'where',
'  decode(last_archived,null,0,',
'    decode(greatest(last_archived,last_updated_on),last_archived,',
'      1,0))  = 0',
'order by 1',
')',
'loop',
'    r := r||to_char(c1.application_id)||'':'';',
'end loop;',
'end if;',
'return r;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select workspace_id ||   ''-'' || application_id||'': ''||application_name d,',
'       workspace_id ||   ''-'' || application_id r',
'from apex_applications',
'where --workspace_id = :FLOW_SECURITY_GROUP_ID and ',
'application_name is not null',
'  and build_status != ''Run and Hidden''',
'order by application_name'))
,p_cHeight=>20
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
);
wwv_flow_api.component_end;
end;
/
