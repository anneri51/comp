prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Purge'
,p_alias=>'PURGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Purge'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(3178261633959790084)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178213613384693719)
,p_protection_level=>'C'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20200206043743'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1920222647832086987)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noBorder:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2511754631482636418)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2511781833163638208)
,p_plug_name=>'Purge'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c           integer := -1;',
'    l_app_count integer := 0;',
'    l_size      number := 0;',
'    l_action    number;',
'begin',
'    if :P13_PURGE_ACTION = ''ALL'' then',
'        l_action := 0;',
'    elsif :P13_PURGE_ACTION = ''1V'' then ',
'        l_action := 1;',
'    elsif :P13_PURGE_ACTION = ''2V'' then ',
'        l_action := 2;',
'    elsif :P13_PURGE_ACTION = ''3V'' then ',
'        l_action := 3;',
'    elsif :P13_PURGE_ACTION = ''4V'' then ',
'        l_action := 4;',
'    elsif :P13_PURGE_ACTION = ''5V'' then ',
'        l_action := 5;',
'    end if;',
'    for c1 in ',
'    (',
'        select nvl(app_id,0) app_id, nvl(content_id,0) content_id, count(*) c',
'          from APEX$ARCHIVE_CONTENTS',
'         where app_id is not null',
'         group by nvl(app_id,0), nvl(content_id,0) ',
'    )',
'    loop',
'        c := -1;',
'        for c2 in ',
'        (',
'          select id, app_id, dbms_lob.getlength(content) c_size',
'          from APEX$ARCHIVE_CONTENTS c',
'          where nvl(app_id,0) = c1.app_id and nvl(content_id,0) = c1.content_id',
'          order by created desc',
'        )',
'        loop',
'            c := c + 1;',
'            if c >= l_action then',
'                l_app_count := l_app_count + 1;',
'                l_size := l_size + c2.c_size;',
'            end if;',
'        end loop;',
'    end loop;',
'    sys.htp.prn(''Purge ''||l_app_count||'' archived components consuming ''||',
'        to_char((l_size/1024),''999G999G999G990'')||''K bytes of archived storage'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2512009017756671612)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2511754631482636418)
,p_button_name=>'PURGE_ARCHIVE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Purge Archive(s)'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'javascript:apex.confirm(''Are you sure you want to purge the selected archives?'',''PURGE_ARCHIVE'');'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2511944528707665301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2511754631482636418)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2512065427799674457)
,p_branch_name=>'Go To Page 13'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 22-NOV-2011 11:11 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2511812819226653094)
,p_name=>'P13_PURGE_ACTION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1920222647832086987)
,p_prompt=>'Purge Action'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PURGE ACTIONS'
,p_lov=>'.'||wwv_flow_api.id(2512099113385679809)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(267024205242916755)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'REDIRECT_SET_VALUE'
,p_item_comment=>'style="width:695px;"'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(34314514358946964)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2511944528707665301)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(34314588098946965)
,p_event_id=>wwv_flow_api.id(34314514358946964)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2512036224336673502)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'process purge'
,p_process_sql_clob=>'apex_cloud_archive.purge_archives;'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P13_PURGE_ACTION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'ALL'
,p_process_success_message=>'All versions purged.'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'procedure log_history as',
'begin',
'for c1 in ( ',
'select count(*) archive_count,',
'       count(distinct app_id) distinct_applications,',
'       sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'       sum(decode(CONTENT_TYPE,''FILE'',1,0)) archived_files,',
'       sum(dbms_lob.getlength(content)) content_size',
' from APEX$ARCHIVE_CONTENTS) loop',
'  insert into apex$archive_history (',
'   archived_applications,',
'   distinct_applications,',
'   archived_files,',
'   archived_file_size) ',
'  values (',
'   c1.archived_applictions,',
'   c1.distinct_applications,',
'   c1.archive_count,',
'   c1.content_size);',
'end loop;',
'commit;',
'end log_history;',
'begin',
'',
'delete from APEX$ARCHIVE_HEADER ',
'where :P13_PURGE_ACTION = ''ALL'';',
'log_history;',
'commit;',
'end;'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2515527733161388714)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'purge 1V'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_action number;',
'begin',
'-- determine how many versions to keep.',
'if :P13_PURGE_ACTION = ''1V'' then ',
'  l_action := 1;',
'elsif :P13_PURGE_ACTION = ''2V'' then ',
'  l_action := 2;',
'elsif :P13_PURGE_ACTION = ''3V'' then ',
'  l_action := 3;',
'elsif :P13_PURGE_ACTION = ''4V'' then ',
'  l_action := 4;',
'elsif :P13_PURGE_ACTION = ''5V'' then ',
'  l_action := 5;',
'end if;',
'',
'apex_cloud_archive.purge_versions(l_action);',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':P13_PURGE_ACTION in (''1V'',''2V'',''3V'',''4V'',''5V'')'
,p_process_when_type=>'PLSQL_EXPRESSION'
,p_process_when2=>'1V'
,p_process_success_message=>'Applications purged from archives.'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   c integer := 0;',
'   l_action number;',
'procedure log_history as',
'begin',
'for c1 in ( ',
'select count(*) archive_count,',
'       count(distinct app_id) distinct_applications,',
'       sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'       sum(dbms_lob.getlength(content)) content_size',
' from APEX$ARCHIVE_CONTENTS) loop',
'  insert into apex$archive_history (',
'   archived_applications,',
'   distinct_applications,',
'   archived_files,',
'   archived_file_size) ',
'  values (',
'   c1.archived_applictions,',
'   c1.distinct_applications,',
'   c1.archive_count,',
'   c1.content_size);',
'end loop;',
'commit;',
'end log_history;',
'begin',
'-- determine how many versions to keep.',
'if :P13_PURGE_ACTION = ''1V'' then ',
'  l_action := 1;',
'elsif :P13_PURGE_ACTION = ''2V'' then ',
'  l_action := 2;',
'elsif :P13_PURGE_ACTION = ''3V'' then ',
'  l_action := 3;',
'elsif :P13_PURGE_ACTION = ''4V'' then ',
'  l_action := 4;',
'elsif :P13_PURGE_ACTION = ''5V'' then ',
'  l_action := 5;',
'end if;',
'',
'-- delete versions not needed',
'for c1 in (',
'select nvl(app_id,0) app_id , nvl(content_id,0) content_id, count(*) c',
'from APEX$ARCHIVE_CONTENTS',
'where app_id is not null',
'group by nvl(app_id,0), nvl(content_id,0)  ) loop',
'   c := 0;',
'   for c2 in (',
'      select id, app_id',
'      from APEX$ARCHIVE_CONTENTS',
'      where nvl(app_id,0) = c1.app_id and nvl(content_id,0) = c1.content_id',
'      order by created desc ) loop',
'      c := c + 1;',
'      if c > l_action then',
'         delete from APEX$ARCHIVE_CONTENTS where id = c2.id;',
'      end if;',
'   end loop;',
'end loop;',
'commit;',
'',
'-- remove archives with no files',
'for c1 in (',
'select h.id,',
'   (select count(*) c from APEX$ARCHIVE_CONTENTS c where c.HEADER_ID = h.id) file_count',
'from APEX$ARCHIVE_HEADER h',
') loop',
'   if c1.file_count = 0 then',
'       delete from APEX$ARCHIVE_HEADER where id = c1.id;',
'   end if;',
'end loop;',
'commit;',
'log_history;',
'end;'))
);
wwv_flow_api.component_end;
end;
/
