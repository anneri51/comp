prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Delete Archive'
,p_alias=>'DELETE-ARCHIVE'
,p_step_title=>'Delete Archive'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479822695593204)
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1218294313752241584)
,p_name=>'Content'
,p_template=>wwv_flow_api.id(1252711439049814264)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ah.id,',
'    ah.archive_name,',
'    ah.created,',
'    lower(ah.created_by) created_by,',
'    count(ac.id) file_count,',
'    sum( sys.dbms_lob.getlength( ac.content ) ) / 1024 as archive_size',
'from APEX$ARCHIVE_HEADER ah,',
'    APEX$ARCHIVE_CONTENTS ac',
'where ah.id = :P14_ARCHIVE_ID',
'    and ac.header_id(+) = ah.id',
'group by ah.id,',
'    ah.archive_name,',
'    ah.created,',
'    ah.created_by',
'order by 2'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252724637305814280)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218294629712241586)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218294710745241587)
,p_query_column_id=>2
,p_column_alias=>'ARCHIVE_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Archive Name'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218294835534241587)
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'Since'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218294933352241587)
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218295017522241587)
,p_query_column_id=>5
,p_column_alias=>'FILE_COUNT'
,p_column_display_sequence=>5
,p_column_heading=>'Files'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218295134126241587)
,p_query_column_id=>6
,p_column_alias=>'ARCHIVE_SIZE'
,p_column_display_sequence=>6
,p_column_heading=>'Archive Size (KB)'
,p_use_as_row_header=>'N'
,p_column_format=>'fm999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2514355739169974130)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2514673317025119125)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2514355739169974130)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2514692523259120879)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2514355739169974130)
,p_button_name=>'delete_archive'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete Archive'
,p_button_position=>'REGION_TEMPLATE_DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2515040011156268774)
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 22-NOV-2011 15:37 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2514827708976135714)
,p_name=>'P14_ARCHIVE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1218294313752241584)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2515020737345266910)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete Archive'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from APEX$ARCHIVE_HEADER where id = :P14_ARCHIVE_ID;',
'commit;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2514692523259120879)
,p_process_success_message=>'Archive Deleted'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.component_end;
end;
/
