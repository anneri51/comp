prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Content Restored'
,p_alias=>'CONTENT-RESTORED'
,p_step_title=>'Content Restored'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479822695593204)
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2605654221080656853)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2605736327795662309)
,p_plug_name=>'Content Restored to Export Repository'
,p_region_template_options=>'#DEFAULT#:t-Alert--warning:t-Alert--horizontal'
,p_plug_template=>wwv_flow_api.id(1252710023340814262)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_file_cnt integer := 0;',
'   l_success  boolean := true;',
'   l_file_size  integer;',
'   l_application_id number;',
'   l_size_disp  varchar2(255);',
'begin',
'',
'if nvl(:P17_FILE_ID,0) = 0 then',
'   l_success := false;',
'end if;',
'',
'for c1 in (',
'select file_id, ',
'       application_id, ',
'       file_name, ',
'       file_size, ',
'       created_by, ',
'       created_on, ',
'       created_on created_on_date, ',
'       file_type',
'  from apex_workspace_files ',
' where file_type in (''Application Export'',''Text Image Export'',''Application Page Export'',''User Interface Theme Export'')',
'and file_id = :P17_FILE_ID) loop',
'    l_file_cnt := l_file_cnt + 1;',
'    l_file_size := c1.file_size;',
'    l_application_id := c1.application_id;',
'    exit;',
'end loop;',
'',
'if l_file_cnt = 1 then',
'   if l_file_size is null then',
'      l_size_disp := ''NULL'';',
'      l_success := false;',
'   elsif l_file_size = 0 then',
'      l_size_disp := ''zero'';',
'      l_success := false;',
'   else',
'      l_size_disp := trim(to_char(l_file_size/1024,''999G999G999G999G990''))||'' KB'';',
'   end if;',
'else',
'   l_success := false;',
'end if;',
'',
'',
'',
'If l_success then',
'-- show success',
'   sys.htp.p(''<strong>Application ''||l_application_id||''</strong> (''||l_size_disp||'') has been copied to the APEX export repository and can now be installed.'');',
'else',
'-- show failure',
'   sys.htp.p(''Application ''||l_application_id||'' with size ''||l_size_disp||'' has encountered an error during restore.'');',
'end if;',
'',
'sys.htp.prn(''To install this application:',
'<ul>',
'<li>Navigate to Oracle Application Express home page</li>',
'<li>Click the Application Builder</li>',
'<li>Click the Workspace Utilities button</li>',
'<li>Click the Export list item</li>',
'<li>Click the Export Repository link (on the right, under "Tasks")</li>',
'<li>Locate your file and click it''''s associated "install" link</li>',
'</ul>'');',
'',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#IMAGE_PREFIX#cloud/app_theme/icons/success_96.png'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2605808235618671809)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2605654221080656853)
,p_button_name=>'RESTORE_APPLICATION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Restore Additional Content'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.component_end;
end;
/
