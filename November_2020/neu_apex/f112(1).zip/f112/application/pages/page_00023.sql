prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive History'
,p_alias=>'ARCHIVE-HISTORY2'
,p_step_title=>'Archive History'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479720963592658)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_help_text=>'<p>This page lists all archived versions of your File.</p>'
,p_last_upd_yyyymmddhh24miss=>'20200116130642'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304709418417521360)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This page lists all archived versions of your File.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2613305409005657031)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2613543727451707141)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c integer := 0;',
'begin',
'    for c1 in',
'    (',
'        select application_file_id as file_id,',
'               application_id,',
'               file_name,',
'               sys.dbms_lob.getlength(file_content) as file_size,',
'               created_by,',
'               created_on,',
'               created_on created_on_date,',
'               mime_type as file_type',
'          from apex_application_static_files f',
'         where application_file_id = :P23_FILE_ID and',
'            (   lower(file_name) like ''%.png'' or',
'                lower(file_name) like ''%.gif'' or',
'                lower(file_name) like ''%.jpg'' or',
'                lower(file_name) like ''%.jpeg'' or',
'                lower(file_name) like ''%.css''',
'            )',
'        union',
'        select workspace_file_id as file_id,',
'               0 as application_id,',
'               file_name,',
'               sys.dbms_lob.getlength(file_content) as file_size,',
'               created_by,',
'               created_on,',
'               created_on created_on_date,',
'               mime_type as file_type',
'          from apex_workspace_static_files f',
'         where workspace_file_id = :P23_FILE_ID and',
'            (   lower(file_name) like ''%.png'' or',
'                lower(file_name) like ''%.gif'' or',
'                lower(file_name) like ''%.jpg'' or',
'                lower(file_name) like ''%.jpeg'' or',
'                lower(file_name) like ''%.css''',
'            )',
'    )',
'    loop',
'        --',
'        sys.htp.prn(''<ul class="vapList">'');',
'',
'        sys.htp.p(''<li><label>Archive File</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.file_Name)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>File size</label><span>'');',
'        sys.htp.p( apex_util.filesize_mask( c1.file_size ) || ''</span></li>'' );',
'        --',
'        sys.htp.p(''<li><label>Created</label><span>'');',
'        sys.htp.p(apex_escape.html(apex_util.get_since(c1.created_on))||'' by ''||',
'        apex_escape.html(lower(c1.created_by))||''</span></li>'');',
'        --',
'        if c1.application_id is not null and c1.application_id != 0 then',
'            for c2 in ( select application_name',
'                        from   apex_applications',
'                        where  application_id = c1.application_id) loop',
'                sys.htp.p(''<li><label>Associated Application</label><span>'');',
'                sys.htp.p(c1.application_id||'': ''||',
'                apex_escape.html(c2.application_name)||''</span></li>'');',
'            end loop;',
'        end if;',
'',
'        c := 0;',
'        sys.htp.p(''<li><label>Archives</label><span>'');',
'        for c2 in ( select id, version,created,',
'                        created_by,',
'                        dbms_lob.getlength(CONTENT) s',
'                    from APEX$ARCHIVE_CONTENTS',
'                    where content_id = c1.file_id',
'                    order by created desc) loop',
'            c := c + 1;',
'            sys.htp.p(''<a href="''',
'                ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'                ||''" title="Access Archive" >Version ''||c2.version||''</a> Archived ''',
'                ||apex_util.get_since(c2.created)||'' by ''||lower(apex_escape.html(c2.created_by))',
'                ||'', size ''|| apex_util.filesize_mask( c2.s ) ||''<br />'');',
'            if c > 15 then exit; end if;',
'        end loop;',
'        if c = 0 then sys.htp.p(''None''); end if;',
'        sys.htp.p(''</span></li>'');',
'',
'        sys.htp.p(''</ul>'');',
'    end loop;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2613631220787717245)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2613305409005657031)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2613631421000717246)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2613305409005657031)
,p_button_name=>'ARCHIVE_FILE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive File'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_FILE_ID:&P23_FILE_ID.'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2613566932992708738)
,p_name=>'P23_FILE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2613543727451707141)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
