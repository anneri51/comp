prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>24
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive Files'
,p_alias=>'ARCHIVE-FILES2'
,p_page_mode=>'MODAL'
,p_step_title=>'Archive Files'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479720963592658)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'//  .shuttle_left {width:300px !important;}',
'//  .shuttle_right {width:300px !important;}',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_required_patch=>wwv_flow_api.id(3187967021764496048)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130642'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1218301017917318488)
,p_name=>'Contents'
,p_template=>wwv_flow_api.id(1252711439049814264)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P16_ARCHIVE_NAME archive_name,',
'	:P16_ARCHIVE_TYPE type',
'from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252724637305814280)
,p_query_headings_type=>'QUERY_COLUMNS_INITCAP'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218301325127318491)
,p_query_column_id=>1
,p_column_alias=>'ARCHIVE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'ARCHIVE_NAME'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218301409385318491)
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'TYPE'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1589350091391115277)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2619450236644040025)
,p_plug_name=>'Contents'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'sys.htp.p(apex_escape.html(wwv_flow_lang.message(''ARCHIVE_FILES_WIZ_PG_2'')));'
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2619451210106040034)
,p_plug_name=>'Confirm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1599395241788462002)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1589350091391115277)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2619450810431040033)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1589350091391115277)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2619450623532040031)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1589350091391115277)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2619452430585040046)
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 21-NOV-2011 06:24 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2619451433974040034)
,p_name=>'P24_FILES_TO_ARCHIVE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2619451210106040034)
,p_prompt=>'Files to archive'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'   r varchar2(32767) := null;',
'begin',
'    if nvl(:P16_ARCHIVE_TYPE,''INCREMENTAL'') = ''FULL'' then',
'    -- full export',
'        for c1 in',
'        (',
'            select',
'                application_file_id as file_id',
'            from',
'                APEX_APPLICATION_STATIC_FILES',
'            where ',
'              (',
'              lower(file_name) like ''%.png'' or',
'              lower(file_name) like ''%.gif'' or',
'              lower(file_name) like ''%.jpg'' or',
'              lower(file_name) like ''%.jpeg'' or',
'              lower(file_name) like ''%.css'' or',
'              lower(file_name) like ''%.js''',
'              )',
'            union',
'            select',
'                workspace_file_id as file_id',
'            from',
'                APEX_WORKSPACE_STATIC_FILES',
'            where ',
'              (',
'              lower(file_name) like ''%.png'' or',
'              lower(file_name) like ''%.gif'' or',
'              lower(file_name) like ''%.jpg'' or',
'              lower(file_name) like ''%.jpeg'' or',
'              lower(file_name) like ''%.css'' or',
'              lower(file_name) like ''%.js''',
'              )',
'            order by 1',
'        )',
'        loop',
'            r := r||to_char(c1.file_id)||'':'';',
'        end loop;',
'',
'    else',
'        -- Incremental Export',
'        for c1 in',
'        (',
'            select',
'                file_id',
'            from',
'            (',
'                select ',
'                    application_file_id as file_id,',
'                    created_ON,',
'                    (select max(created) ',
'                     from apex$archive_contents c',
'                     where c.content_id = f.application_file_id) last_archived,',
'                    (select count(*) c',
'                     from apex$archive_contents c',
'                     where c.content_id = f.application_file_id) archived_versions',
'                from',
'                    APEX_APPLICATION_STATIC_FILES f',
'                where (',
'                    lower(file_name) like ''%.png'' or',
'                    lower(file_name) like ''%.gif'' or',
'                    lower(file_name) like ''%.jpg'' or',
'                    lower(file_name) like ''%.jpeg'' or',
'                    lower(file_name) like ''%.css'' or',
'                    lower(file_name) like ''%.js''',
'                )',
'                union',
'                select ',
'                    workspace_file_id as file_id,',
'                    created_ON,',
'                    (select max(created) ',
'                     from apex$archive_contents c',
'                     where c.content_id = f.workspace_file_id) last_archived,',
'                    (select count(*) c',
'                     from apex$archive_contents c',
'                     where c.content_id = f.workspace_file_id) archived_versions',
'                from',
'                    APEX_WORKSPACE_STATIC_FILES f',
'                where (',
'                    lower(file_name) like ''%.png'' or',
'                    lower(file_name) like ''%.gif'' or',
'                    lower(file_name) like ''%.jpg'' or',
'                    lower(file_name) like ''%.jpeg'' or',
'                    lower(file_name) like ''%.css'' or',
'                    lower(file_name) like ''%.js''',
'                )',
'            ) x',
'            where',
'                decode(last_archived,null,0,',
'                    decode(greatest(last_archived,created_on),last_archived,',
'                1,0))  = 0',
'            order by 1',
'        )',
'        loop',
'          r := r||to_char(c1.file_id)||'':'';',
'        end loop;',
'    end if;',
'    return r;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_display_as=>'NATIVE_SHUTTLE'
,p_named_lov=>'FILES TO ARCHIVE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select file_name d,',
'       application_file_id r',
'from APEX_APPLICATION_STATIC_FILES f',
'where ',
'(',
'lower(file_name) like ''%.png'' or',
'lower(file_name) like ''%.gif'' or',
'lower(file_name) like ''%.jpg'' or',
'lower(file_name) like ''%.jpeg'' or',
'lower(file_name) like ''%.css'' or',
'lower(file_name) like ''%.js''',
')',
'union',
'select file_name d,',
'       workspace_file_id r',
'from apex_workspace_static_files f',
'where ',
'(',
'lower(file_name) like ''%.png'' or',
'lower(file_name) like ''%.gif'' or',
'lower(file_name) like ''%.jpg'' or',
'lower(file_name) like ''%.jpeg'' or',
'lower(file_name) like ''%.css'' or',
'lower(file_name) like ''%.js''',
')',
'order by 1'))
,p_cHeight=>20
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1589350171658115278)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(1599395241788462002)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1589350297980115279)
,p_event_id=>wwv_flow_api.id(1589350171658115278)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.component_end;
end;
/
