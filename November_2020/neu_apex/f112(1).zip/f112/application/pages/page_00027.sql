prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>27
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Display Archived Application'
,p_alias=>'DISPLAY-ARCHIVED-APPLICATION'
,p_step_title=>'Display Archived Application'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479924426593750)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'body { min-width: 800px !important;}',
'',
'code.codeView{margin:0;padding:0;overflow:auto;background-color:#fdf6e3;display:block}',
'code.codeView.searchResults ol li{padding-left:0}',
'code.codeView.searchResults ol li a{padding-left:8px}',
'code.codeView.searchResults ol li:nth-child(odd){background-color:#fdf6e3}',
'code.codeView.searchResults ol:nth-child(odd) li{background-color:#F6EFDC}',
'code.codeView h3{border-bottom:1px solid #93a1a1;border-top:1px solid #93a1a1;padding:8px;font:bold 13px/24px "Consolas","Menlo","Courier New",courier,mono;color:#586e75;background-color:#F8F8F8}',
'code.codeView h3:first-child{border-top:none}',
'code.codeView ol{list-style:decimal outside;margin:0 0 0 64px}',
'code.codeView ol li{color:#657b83;font:normal 11px/24px "Consolas","Menlo","Courier New",courier,mono;white-space:pre;border-left:1px solid #93a1a1;padding-left:8px;background-color:#fdf6e3}',
'code.codeView ol li a{display:block;color:#657b83;text-decoration:none}',
'code.codeView ol li:nth-child(odd){background-color:#F6EFDC}',
'code.codeView ol li.selected,code.codeView ol li a:hover{background-color:#d6d1be;color:#586e75}',
'',
'#codeview .uRegionContent {padding: 0;}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2690924226899531312)
,p_plug_name=>'Code View'
,p_region_name=>'codeview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Region--hideHeader'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_line      varchar2(32767) := null;',
'    l_str1      varchar2(32767) := null;',
'    l_str2      varchar2(32767) := null;',
'    l_leftover  varchar2(32767) := null;',
'    l_chunksize number := 3000;',
'    l_offset    number := 1;',
'    l_linebreak varchar2(2) := chr(10);',
'    l_length    number;',
'    p_blob blob;',
'    c           integer := 0;',
'    m           integer := 0;',
'    l_max       integer := 100000;',
'    l_line_start integer ;',
'    l_line_end   integer;',
'    l_app_id     varchar2(50) := :APP_ID;',
'    l_app_SESSION    varchar2(50) := :APP_SESSION;',
'begin',
'    l_line_start := nvl(:P27_LINE,1);',
'    l_line_end := nvl(:P27_LINE2,10000);',
'    for c1 in ( select APP_NAME, app_id, content, created, HEADER_ID',
'                from APEX$ARCHIVE_CONTENTS',
'                where ID = :P27_APPLICATION',
'                order by created desc ) loop',
'',
'        sys.htp.prn(''<code class="codeView">'');',
'',
'        if l_line_start > 1 and nvl(:P27_APPLICATION,0) != 0 then',
'            sys.htp.prn(''<h3><a href="''',
'                ||apex_util.prepare_url(''f?p=''||l_app_id||'':27:''||l_app_session||''::::P27_LINE:''||greatest(l_line_start - 100,1))',
'                ||''">show more</a></h3>'');',
'        end if;',
'        p_blob := c1.content;',
'        sys.htp.prn(''<ol start="''||l_line_start||''">'');',
'',
'        l_length := dbms_lob.getlength(p_blob);',
'',
'        while l_offset < l_length loop',
'',
'            l_str1 := l_leftover ||utl_raw.cast_to_varchar2(dbms_lob.substr(p_blob, l_chunksize, l_offset));',
'            l_leftover := null;',
'            l_str2 := l_str1;',
'',
'            while l_str2 is not null loop',
'                c := c + 1;',
'                if instr(l_str2, l_linebreak) <= 0 then',
'                    l_leftover := l_str2;',
'                    l_str2 := null;',
'                else',
'                    l_line := substr(l_str2, 1, instr(l_str2, l_linebreak)-1);',
'',
'                    l_line := replace(l_line,''unistr(''''\000a'''')||'',null);',
'                    if c >= l_line_start and c <= l_line_end then',
'                        if to_char(c) = :P27_SELECTED_LINE then',
'                            sys.htp.prn(''<li id="L''||to_char(c)||''" class="selected">''||apex_escape.html(l_line) ||''</li>''); ',
'                        else',
'                            sys.htp.prn(''<li id="L''||to_char(c)||''">''||apex_escape.html(l_line) ||''</li>''); ',
'                        end if;',
'',
'                        m := m + 1;',
'                    end if;',
'',
'                    l_str2 := substr(l_str2, instr(l_str2, l_linebreak)+1);',
'                end if;',
'                if m > l_max then exit; end if;',
'',
'            end loop;',
'',
'            l_offset := l_offset + l_chunksize;',
'            if m > l_max then exit; end if;',
'        end loop;',
'',
'        if l_leftover is not null then',
'            null;',
'            --dbms_output.put_line ( l_leftover );',
'        end if;',
'        if m > l_max then ',
'            sys.htp.p(''</ol>'');',
'            if nvl(:P27_APPLICATION,0) != 0 then',
'                sys.htp.prn(''<h3><a href="''',
'                    ||apex_util.prepare_url(''f?p=''||l_app_id||'':27:''||l_app_session||''::::P27_LINE2:''||greatest(l_line_end  + 100,1)||''#L''||l_line_end)',
'                    ||''">show more</a></h3>'');',
'            end if;',
'            sys.htp.p(''</code>'');',
'            exit; ',
'        end if;',
'    end loop;',
'    if m <= l_max then ',
'        sys.htp.p(''</ol>'');',
'        if nvl(:P27_APPLICATION,0) != 0 then',
'            sys.htp.prn(''<h3><a href="''',
'                ||apex_util.prepare_url(''f?p=''||l_app_id||'':27:''||l_app_session||''::::P27_LINE2:''||greatest(l_line_end  + 100,1)||''#L''||l_line_end)',
'                ||''">show more</a></h3>'');',
'        end if;',
'        sys.htp.prn(''</code>'');',
'    end if;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P27_APPLICATION'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2690924409287531313)
,p_plug_name=>'search'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:t-Form--labelsAbove'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2690925215381531315)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2690924828347531314)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_button_name=>'P27_GO'
,p_button_static_id=>'P27_GO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go'
,p_button_position=>'BODY'
,p_button_cattributes=>'style="margin-top:32px;"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2698000435187168173)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2690925215381531315)
,p_button_name=>'ALL_LINES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'All Lines'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_LINE,P27_LINE2:1,10000000'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2691543028698692475)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(2690925215381531315)
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_image_alt=>'Search Content'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2698552436029329332)
,p_branch_action=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:26:P26_APPLICATION,P26_SEARCH:&P27_SELECTED_APP_ID.,prompt '
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(2691543028698692475)
,p_branch_sequence=>10
,p_branch_comment=>'Created 19-DEC-2011 12:14 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2690925034527531315)
,p_name=>'P27_APPLICATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_item_default=>'0'
,p_prompt=>'Archived Application'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select app_name||'' (''||app_id||'') - v''||version||'', ''||apex_util.get_since(created) d, id r',
'from APEX$ARCHIVE_CONTENTS',
'where CONTENT_TYPE =''APPLICATION''',
'order by app_id, created desc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Application -'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2691310120725614421)
,p_name=>'P27_LINE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_item_default=>'1'
,p_prompt=>'Line'
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>8
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_attribute_01=>'1'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2691359236655619025)
,p_name=>'P27_LINE2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_item_default=>'10000'
,p_prompt=>'Through'
,p_source=>'10000'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>8
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#:margin-top-sm'
,p_attribute_01=>'1'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2695581325258323174)
,p_name=>'P27_SELECTED_LINE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2698469633820319233)
,p_name=>'P27_SELECTED_APP_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(2690924409287531313)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select app_id',
'from APEX$ARCHIVE_CONTENTS',
'where id = :P27_APPLICATION'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1305551631565140678)
,p_name=>'Validate Input'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P27_LINE,P27_LINE2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1305551756945140679)
,p_event_id=>wwv_flow_api.id(1305551631565140678)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_LINE,P27_LINE2'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (isNaN($v(''P27_LINE''))) {',
'    $s(''P27_LINE'',1);',
'}',
'if (isNaN($v(''P27_LINE2''))) {',
'    $s(''P27_LINE2'',1000);',
'}'))
);
wwv_flow_api.component_end;
end;
/
