prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>29
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive'
,p_alias=>'ARCHIVE'
,p_step_title=>'Archive'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479619578592289)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_help_text=>'<p>This page lists all archived versions of your application and additional change history.</p>'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304488424777673979)
,p_plug_name=>'Content'
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c integer := 0;',
'begin',
'    for c1 in ( select application_name,',
'                    application_id,',
'                    pages,',
'                    owner,',
'                    LAST_UPDATED_ON,',
'                    last_updated_by',
'                from apex_applications where application_id = :P29_APP_ID',
'                    and upper(build_status) <> ''RUN AND HIDDEN'') loop',
'        --',
'        sys.htp.prn(''<ul class="vapList">'');',
'',
'        sys.htp.p(''<li><label>Archive Application</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.application_name)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>Pages</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.pages)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>Parsing Schema</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.owner)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>Last Updated</label><span>'');',
'        sys.htp.p(apex_escape.html(apex_util.get_since(c1.LAST_UPDATED_ON))||'' by ''||',
'        apex_escape.html(lower(c1.last_updated_by))||''</span></li>'');',
'',
'        -- application versions',
'        c := 0;',
'        sys.htp.p(''<li><label>Application Archives</label><span>'');',
'        for c2 in ( select id, version, created, created_by, dbms_lob.getlength(CONTENT) s',
'                    from APEX$ARCHIVE_CONTENTS',
'                    where app_id = c1.application_id  and CONTENT_TYPE = ''APPLICATION''',
'                    order by created desc) loop',
'            c := c + 1;',
'            sys.htp.p(''<a href="''',
'                ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'                ||''" title="Access Archive" >Version ''||c2.version||''</a> Archived ''||apex_util.get_since(c2.created)',
'                ||'' by ''||lower(apex_escape.html(c2.created_by))||'', size ''||to_char(c2.s/(1024),''999G999G999G990'')||'' KB, ''',
'                ||''<a href="''',
'                ||apex_util.prepare_url(''f?p=''||:APP_ID||'':27:''||:APP_SESSION||'':::27:P27_APPLICATION:''||c2.id)',
'                ||''">View Source</a><br />'');',
'            if c > 15 then exit; end if;',
'        end loop;',
'        if c = 0 then sys.htp.p(''None''); end if;',
'        sys.htp.p(''</span></li>'');',
'',
'        -- file versions',
'        c := 0;',
'        sys.htp.p(''<li><label>Archived Files</label><span>'');',
'        for c2 in ( select id, version, CONTENT_FILENAME , created, created_by, dbms_lob.getlength(CONTENT) s',
'                    from APEX$ARCHIVE_CONTENTS',
'                    where app_id = c1.application_id  and CONTENT_TYPE = ''FILE''',
'                    order by created desc) loop',
'            c := c + 1;',
'            sys.htp.p(apex_escape.html(c2.CONTENT_FILENAME)||'', <a href="''',
'                ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'                ||''" title="Access Archive" >Version ''||c2.version||''</a> Archived ''||apex_util.get_since(c2.created)',
'                ||'' by ''||lower(apex_escape.html(c2.created_by))||'', size ''||to_char(c2.s/(1024),''999G999G999G990'')||'' KB<br />'');',
'            if c > 15 then exit; end if;',
'        end loop;',
'        if c = 0 then sys.htp.p(''None''); end if;',
'        sys.htp.p(''</span></li>'');',
'',
'        -- recently edited pages',
'        c := 0;',
'        sys.htp.p(''<li><label>Recently Edited Pages</label><span>'');',
'        for c2 in ( select page_id, page_name, last_updated_on, last_updated_by',
'                    from apex_application_pages',
'                    where application_id = c1.application_id',
'                    order by last_updated_on desc) loop',
'            c := c + 1;',
'            sys.htp.p(''Page ''||c2.page_id||'' "''||apex_escape.html(c2.page_name)|| ''" last updated ''',
'                ||apex_util.get_since(c2.last_updated_on)||'' by ''||lower(apex_escape.html(c2.last_updated_by))||''<br />'');',
'            if c > 15 then exit; end if;',
'        end loop;',
'        if c = 0 then sys.htp.p(''None''); end if;',
'        sys.htp.p(''</span></li>'');',
'',
'        sys.htp.p(''</ul>'');',
'    end loop;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304489434587673985)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This page lists all archived versions of your application and additional change history.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304489832416674000)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1304489019516673984)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1304489832416674000)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1304489211909673984)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1304489832416674000)
,p_button_name=>'ARCHIVE_APPLICATION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive Application'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P29_APP_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(1304490811043674004)
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.:4:&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(1304489211909673984)
,p_branch_sequence=>10
,p_branch_comment=>'Created 18-NOV-2011 07:13 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1304488637619673981)
,p_name=>'P29_APP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1304488424777673979)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1304490325043674002)
,p_name=>'Submit Page'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(1304489211909673984)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1304490623750674004)
,p_event_id=>wwv_flow_api.id(1304490325043674002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ARCHIVE_APPLICATION'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1304490134076674001)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'archive application'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_app_name    varchar2(4000);',
'begin',
'    for c1 in (select application_name',
'                 from apex_applications',
'                where application_id = :P29_APP_ID) loop',
'      l_app_name := c1.application_name;',
'    end loop;',
'',
'    apex_cloud_archive.archive_applications(',
'        p_workspace_id          => :flow_security_group_id,',
'        p_application_id        => :P29_APP_ID,',
'        p_version               => 1,',
'        p_archive_name          => ''App ''||:P29_APP_ID||'': ''||l_app_name);',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(1304489211909673984)
,p_process_success_message=>'Application Archived'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_app_clob         clob;',
' l_wksp_clob        clob;',
' l_workspace_id     number;',
' l_workspace        varchar2(255);',
' l_owner            varchar2(255);',
' l_id               number;',
' l_application_name varchar2(255);',
' l_application_id   number;',
' l_app_blob         blob;',
' l_elap             number;',
' l_start            timestamp;',
' g_log_seq          integer := 0;',
'procedure log_history as',
'begin',
'for c1 in ( ',
'select count(*) archive_count,',
'       count(distinct app_id) distinct_applications,',
'       sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'       sum(dbms_lob.getlength(content)) content_size',
' from APEX$ARCHIVE_CONTENTS) loop',
'  insert into apex$archive_history (',
'   archived_applications,',
'   distinct_applications,',
'   archived_files,',
'   archived_file_size) ',
'  values (',
'   c1.archived_applictions,',
'   c1.distinct_applications,',
'   c1.archive_count,',
'   c1.content_size);',
'end loop;',
'commit;',
'end log_history;',
' procedure log (',
'   p_message in varchar2)',
' is',
' begin ',
'    g_log_seq := g_log_seq + 1;',
'    insert into APEX$ARCHIVE_LOG (log_entry, log_session, log_sequence) values (p_message, :APP_SESSION, g_log_seq);',
'    commit;',
' end;',
' function get_elapsed_time',
'    return number',
'is',
'    l_interval   interval day to second;',
'    l_current_ts timestamp;',
' begin',
'    l_current_ts := systimestamp at time zone ''GMT'';',
'    l_interval := l_current_ts - l_start;',
'    return extract(second from l_interval) + extract( minute from l_interval) * 60;',
' end get_elapsed_time;',
'begin',
' l_start := systimestamp at time zone ''GMT'';',
' for c1 in (',
'    select application_id, workspace_id, workspace, owner, application_name',
'    from apex_applications where application_id = :P2_APP_ID) loop',
'    l_workspace := c1.workspace;',
'    l_workspace_id := c1.workspace_id;',
'    l_owner := c1.owner;',
'    l_application_id := c1.application_id;',
'    l_application_name := c1.application_name;',
' end loop;',
' l_app_clob := wwv_flow_utilities.export_application_to_clob (',
'   p_application_id   => :P2_APP_ID,',
'   p_export_ir_public_reports  =>  ''N'',',
'   p_export_ir_private_reports =>  ''N'',',
'   p_export_ir_notifications   =>  ''N'',',
'   p_export_translations       =>  ''Y'');',
' l_app_blob := wwv_flow_utilities.clob_to_blob(l_app_clob);',
'',
' --l_wksp_clob := wwv_flow_utilities.export_workspace_to_clob (',
' --  p_workspace_id             => l_workspace_ID,',
' --  p_include_team_development => true );',
'',
' insert into  apex$archive_header ',
'    (version, archive_name, workspace_id, workspace_name, schema)',
'    values ',
'    (1, ''App ''||to_char(l_application_id)||'': ''||l_application_name,',
'     l_workspace_id, l_workspace, l_owner) ',
'    returning id into l_id;',
' commit;',
'  ',
' l_elap := get_elapsed_time;',
' insert into apex$archive_contents (',
'    header_id, app_id, app_name, content, content_type, creation_elap_time,',
'    CONTENT_MIMETYPE, CONTENT_FILENAME)',
'    values ',
'    (l_id, l_application_id, l_application_name, l_app_blob, ''APPLICATION'', l_elap,',
'    ''application/octet-stream'',''f''||to_char(l_application_id)||''.sql'');',
'',
' log(''Application ''||l_application_id||'' with length ''||to_char(',
'    dbms_lob.getlength(l_app_blob),''999G999G999G999G990'')||'' bytes.'');',
' commit;',
' log_history;',
' commit;',
'',
'end;'))
);
wwv_flow_api.component_end;
end;
/
