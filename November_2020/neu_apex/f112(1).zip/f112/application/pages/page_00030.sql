prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive File'
,p_alias=>'ARCHIVE-FILE'
,p_step_title=>'Archive File'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479720963592658)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_help_text=>'<p>This page lists all archived versions of your File.</p>'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304677219350380050)
,p_plug_name=>'Content'
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c integer := 0;',
'begin',
'    for c1 in',
'    (',
'        select',
'            application_file_id as file_id,',
'            application_id,',
'            file_name,',
'            sys.dbms_lob.getlength(file_content) as file_size,',
'            created_by,',
'            created_on',
'        from',
'            apex_application_static_files f',
'        where',
'            application_file_id = :P30_FILE_ID',
'        and',
'            (   lower(file_name) like ''%.png'' or',
'                lower(file_name) like ''%.gif'' or',
'                lower(file_name) like ''%.jpg'' or',
'                lower(file_name) like ''%.jpeg'' or',
'                lower(file_name) like ''%.css'' or',
'                lower(file_name) like ''%.js''',
'            )',
'        union all',
'        select',
'            workspace_file_id as file_id,',
'            0 as application_id,',
'            file_name,',
'            sys.dbms_lob.getlength(file_content) as file_size,',
'            created_by,',
'            created_on',
'        from',
'            apex_workspace_static_files f',
'        where',
'            workspace_file_id = :P30_FILE_ID',
'        and',
'            (   lower(file_name) like ''%.png'' or',
'                lower(file_name) like ''%.gif'' or',
'                lower(file_name) like ''%.jpg'' or',
'                lower(file_name) like ''%.jpeg'' or',
'                lower(file_name) like ''%.css'' or',
'                lower(file_name) like ''%.js''',
'            )',
'    )',
'    loop',
'        --',
'        sys.htp.prn(''<ul class="vapList">'');',
'',
'        sys.htp.p(''<li><label>Archive File</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.file_Name)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>File size</label><span>'');',
'        sys.htp.p(to_char((c1.file_size/1024),''999G999G999G990'')||'' KB</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>Created</label><span>'');',
'        sys.htp.p(apex_escape.html(apex_util.get_since(c1.created_on))||'' by ''||',
'        apex_escape.html(lower(c1.created_by))||''</span></li>'');',
'        --',
'        if c1.application_id is not null and c1.application_id != 0 then',
'            for c2 in ( select application_name',
'                        from   apex_applications',
'                        where  application_id = c1.application_id) loop',
'                sys.htp.p(''<li><label>Associated Application</label><span>'');',
'                sys.htp.p(c1.application_id||'': ''||',
'                apex_escape.html(c2.application_name)||''</span></li>'');',
'            end loop;',
'        end if;',
'',
'        c := 0;',
'        sys.htp.p(''<li><label>Archives</label><span>'');',
'        for c2 in (',
'                select version,',
'                    id,',
'                    created,',
'                    created_by,',
'                    dbms_lob.getlength(CONTENT) s',
'                from APEX$ARCHIVE_CONTENTS',
'                where content_id = c1.file_id',
'                order by created desc) loop',
'            c := c + 1;',
'            sys.htp.p(''<a href="''',
'                ||apex_util.prepare_url(''f?p=''||:APP_ID||'':18:''||:APP_SESSION||'':::RIR,CIR:IR_ID:''||c2.id)',
'                ||''" title="Access Archive" >Version ''||c2.version||''</a> ''',
'                ||''Archived ''||apex_util.get_since(c2.created)||'' by ''||lower(apex_escape.html(c2.created_by))',
'                ||'', size ''||to_char(c2.s/(1024),''999G999G999G990'')||'' KB<br />'');',
'            if c > 15 then exit; end if;',
'        end loop;',
'        if c = 0 then sys.htp.p(''None''); end if;',
'        sys.htp.p(''</span></li>'');',
'',
'        sys.htp.p(''</ul>'');',
'    end loop;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304678423768380061)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1304711235864535869)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This page lists all archived versions of your File.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1304677831984380056)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1304678423768380061)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1304678031180380057)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1304678423768380061)
,p_button_name=>'ARCHIVE_FILE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive File'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(1304679427424380065)
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 08-DEC-2011 08:13 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1304677427703380056)
,p_name=>'P30_FILE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(1304677219350380050)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1304678911876380063)
,p_name=>'Submit Page'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(1304678031180380057)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1304679240209380064)
,p_event_id=>wwv_flow_api.id(1304678911876380063)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ARCHIVE_APPLICATION'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1304678732833380062)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'archive file'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_size    number;',
'begin',
'    l_size := apex_cloud_archive.archive_file(',
'                  p_workspace_id => :flow_security_group_id,',
'                  p_file_id      => :P30_FILE_ID,',
'                  p_log          => true );',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'File Archived'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' l_app_clob         clob;',
' l_wksp_clob        clob;',
' l_workspace        varchar2(255);',
' l_schema           varchar2(255);',
' l_file_name        varchar2(512);',
' l_owner            varchar2(255);',
' l_id               number;',
' l_application_name varchar2(255);',
' l_application_id   number;',
' l_app_blob         blob;',
' l_elap             number;',
' l_start            timestamp;',
' g_log_seq          integer := 0;',
'',
'',
'    procedure log_history as',
'    begin',
'    for c1 in ( ',
'    select count(*) archive_count,',
'           count(distinct app_id) distinct_applications,',
'           sum(decode(CONTENT_TYPE,''APPLICATION'',1,0)) archived_applictions,',
'           sum(dbms_lob.getlength(content)) content_size',
'     from APEX$ARCHIVE_CONTENTS) loop',
'      insert into apex$archive_history (',
'       archived_applications,',
'       distinct_applications,',
'       archived_files,',
'       archived_file_size) ',
'      values (',
'       c1.archived_applictions,',
'       c1.distinct_applications,',
'       c1.archive_count,',
'       c1.content_size);',
'    end loop;',
'    commit;',
'    end log_history;',
'    ',
'    procedure log (',
'        p_message in varchar2)',
'    is',
'    begin ',
'      g_log_seq := g_log_seq + 1;',
'      insert into APEX$ARCHIVE_LOG (log_entry, log_session, log_sequence) values (p_message, :APP_SESSION, g_log_seq);',
'      commit;',
'    end;',
'    ',
'    function get_elapsed_time',
'        return number',
'    is',
'        l_interval   interval day to second;',
'        l_current_ts timestamp;',
'    begin',
'        l_current_ts := systimestamp at time zone ''GMT'';',
'        l_interval := l_current_ts - l_start;',
'        return extract(second from l_interval) + extract( minute from l_interval) * 60;',
'    end get_elapsed_time;',
'',
'begin',
'   l_start := systimestamp at time zone ''GMT'';',
'    ',
'for c1 in (',
'select file_id, ',
'  application_id, ',
'  (select application_name from apex_applications a where a.application_id = f.application_id) application_name,',
'  file_name, ',
'  mime_type,',
'  file_size, ',
'  created_by, ',
'  created_on, ',
'  created_on created_on_date, ',
'  file_type,',
'  document,',
'  workspace_id,',
'  workspace_name',
'  from apex_workspace_files f',
'where file_id = :P23_FILE_ID and',
'(',
'lower(file_name) like ''%.png'' or',
'lower(file_name) like ''%.gif'' or',
'lower(file_name) like ''%.jpg'' or',
'lower(file_name) like ''%.jpeg'' or',
'lower(file_name) like ''%.css'' ',
')',
') loop',
' l_file_name := c1.file_name;',
'',
' for c2 in (select FIRST_SCHEMA_PROVISIONED from apex_workspace_schemas) loop',
'     l_schema := c2.FIRST_SCHEMA_PROVISIONED;',
'     exit;',
' end loop;',
'',
' insert into apex$archive_header ',
'    (version, archive_name, workspace_id, workspace_name, schema)',
'    values ',
'    (1, c1.file_name, c1.workspace_id, c1.workspace_name, l_schema) ',
'    returning id into l_id;',
' ',
' l_elap := get_elapsed_time;',
'',
' insert into apex$archive_contents (',
'    header_id, ',
'    app_id, ',
'    app_name, ',
'    content, ',
'    content_id,',
'    content_type, ',
'    creation_elap_time, ',
'    CONTENT_MIMETYPE, ',
'    CONTENT_FILENAME)',
'    values ',
'    (l_id, ',
'    c1.application_id, ',
'    c1.application_name, ',
'    c1.document, ',
'    c1.file_id,',
'    ''FILE'', ',
'    l_elap, ',
'    c1.mime_type,',
'    c1.file_name);',
'',
'end loop;',
'',
'  log(''File ''||l_file_name||'' with length ''||to_char(',
'    dbms_lob.getlength(l_app_blob),''999G999G999G999G990'')||'' bytes.'');',
' commit;',
' log_history;',
'end;'))
);
wwv_flow_api.component_end;
end;
/
