prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>31
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Administration'
,p_alias=>'SETTINGS'
,p_step_title=>'Administration'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(3178261633959790084)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.acl-Info {',
'  display: block;',
'  overflow: hidden;',
'}',
'.acl-Info-statusBox,',
'.acl-Info-usersBox {',
'  display: block;',
'  float: left;',
'  width: 50%;',
'}',
'.acl-Info-statusBox {',
'  text-align: center;',
'}',
'.acl-Info-heading {',
'  display: block;',
'  font-size: 16px;',
'  margin: 16px 16px 8px 16px;',
'  font-weight: bold;',
'  color: #404040;',
'}',
'.acl-Info-heading span {',
'  color: #707070;',
'  font-weight: normal;',
'}',
'.acl-Info-status {',
'  display: block;',
'  width: 50%;',
'  margin: 0 auto 8px auto;',
'  padding: 12px 0;',
'  border: 1px solid #D0D0D0;',
'  border-radius: 2px;',
'  font-size: 20px;',
'  line-height: 20px;',
'  color: #404040;',
'  font-weight: bold;',
'  background-color: #F0F0F0;',
'}',
'.authScheme .acl-Info-status {',
'  font-size: 16px;',
'  width: 70%',
'}',
'.acl-Info-status.is-enabled {',
'  background-color: #40C230;',
'  border-color: #37A62A;',
'  color: #FFF;',
'  text-shadow: 0 -1px 0 rgba(0,0,0,.25);',
'}',
'.acl-Info-status.is-disabled {',
'  background-color: #DE3038;',
'  border-color: #A0242A;',
'  color: #FFF;',
'  text-shadow: 0 -1px 0 rgba(0,0,0,.25);',
'}',
'.acl-Info-changeStatusLink {',
'  display: inline-block;',
'  padding: 8px 0;',
'  color: #404040;',
'  text-decoration: none;',
'  font-size: 11px;',
'  background-color: #F0F0F0;',
'  border: 1px solid #D0D0D0;',
'  margin: 0 16px 16px 16px;',
'  border-radius: 2px;',
'  width: 50%;',
'}',
'.acl-Info-changeStatusLink:hover {',
'  background-color: #fff;',
'  border-color: #C0C0C0;',
'  box-shadow: 0 1px 1px rgba(0,0,0,.15);',
'}',
'.acl-Info-changeStatusLink:active {',
'  background-color: #E0E0E0;',
'  border-color: #C0C0C0;',
'  box-shadow: 0 1px 1px rgba(0,0,0,.25) inset;',
'}',
'.acl-Info-users {',
'  margin: 0;',
'  list-style: none;',
'  padding: 0;',
'  margin: 0;',
'  border-left: 1px solid #F0F0F0;',
'}',
'.acl-Info-user {',
'  border-top: 1px solid #F0F0F0;',
'}',
'.acl-Info-userLink {',
'  text-decoration: none;',
'  display: block;',
'  padding: 8px;',
'}',
'.acl-Info-userLink:hover {',
'  background-color: #689AD8;',
'}',
'.acl-Info-user:first-child {',
'  border-top: none;',
'}',
'.acl-Info-userType,',
'.acl-Info-userCount {',
'  display: block;',
'  font-size: 14px;',
'}',
'.acl-Info-userType {',
'  font-weight: bold;',
'  float: left;',
'  margin-right: 8px;',
'  line-height: 32px;',
'}',
'.acl-Info-userLink:hover .acl-Info-userType {',
'  color: #FFF;',
'}',
'.acl-Info-userCount {',
'  display: block;',
'  overflow: hidden;',
'  text-align: right;',
'}',
'.acl-Info-userCount span {',
'  display: inline-block;',
'  padding: 8px;',
'  background-color: #F8F8F8;',
'  color: #404040;',
'  line-height: 16px;',
'  min-width: 36px;',
'  text-decoration: none;',
'  text-align: right;',
'  border-radius: 2px;',
'}',
'.acl-Info-desc {',
'    padding: 16px;',
'    border-top: 1px solid #E0E0E0;',
'    border-bottom: 1px solid #E0E0E0;',
'    background: #F8F8F8;',
'    font-size: 14px;',
'    clear: both;',
'}',
'.acl-Info-desc>p:last-child {',
'  margin-bottom: 0;',
'}',
''))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178213613384693719)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page allows users with application administrator privileges to perform the following actions:',
'    <ul>',
'        <li>Enable or disable access control</li>',
'        <li>Add, edit, and/or remove users</li>',
'        <li>Change the application''s username format (email address or non-email address)</li>',
'        <li>Monitor application errors</li>',
'        <li>Manage the application''s appearance</li>',
'        <li>Add, edit, and/or remove application notifications</li>',
'        <li>Rename the application</li>',
'        <li>Manage all other application settings and preferences</li>',
'    </ul>',
'</p>'))
,p_last_upd_yyyymmddhh24miss=>'20190320121244'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1227326930502449091)
,p_plug_name=>'Confirm Enabling Access Control'
,p_region_name=>'confirmEnableACL'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(1629140998722363415)
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'<p>Enabling Access Control allows access to the application and its features to be controlled by an Access Control List (ACL).  Until access control is enabled all authenticated users are administrators.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1507731814407873035)
,p_plug_name=>'Access Control Settings'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(3178213613384693719)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(34315655477946975)
,p_plug_name=>'ACL Info'
,p_parent_plug_id=>wwv_flow_api.id(1507731814407873035)
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--warning:t-Alert--accessibleHeading:margin-top-sm:margin-bottom-sm:margin-left-sm:margin-right-sm'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252710023340814262)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_acl_enabled varchar2(45);',
'    l_acl_scope   varchar2(45);',
'begin',
'    l_acl_enabled := eba_archive_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'');',
'    l_acl_scope   := eba_archive_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'');',
'',
'    if l_acl_enabled = ''N'' then',
'        sys.htp.p(apex_lang.message(''ACL_DISABLED''));',
'    else',
'        case l_acl_scope',
'            when ''ACL_ONLY'' then sys.htp.p(apex_lang.message(''ACL_ENABLED''));',
'            when ''PUBLIC_CONTRIBUTE'' then sys.htp.p(apex_lang.message(''ACL_PUBLIC_CONTRIBUTE''));',
'            when ''PUBLIC_READONLY'' then sys.htp.p(apex_lang.message(''ACL_PUBLIC_READONLY''));',
'        end case;',
'    end if;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(34315728743946976)
,p_name=>'User Counts Report'
,p_parent_plug_id=>wwv_flow_api.id(1507731814407873035)
,p_template=>wwv_flow_api.id(1252718055457814273)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--stacked:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(case when access_level_id = 1 then 1 else 0 end) readers,',
'       sum(case when access_level_id = 2 then 1 else 0 end) contributors,',
'       sum(case when access_level_id = 3 then 1 else 0 end) administrators',
'from eba_archive_users',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(1252721134586814276)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34315792935946977)
,p_query_column_id=>1
,p_column_alias=>'READERS'
,p_column_display_sequence=>1
,p_column_heading=>'Readers'
,p_column_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,32,RIR:IR_ACCESS_LEVEL_ID:Reader'
,p_column_linktext=>'#READERS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34315934699946978)
,p_query_column_id=>2
,p_column_alias=>'CONTRIBUTORS'
,p_column_display_sequence=>2
,p_column_heading=>'Contributors'
,p_column_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,32,RIR:IR_ACCESS_LEVEL_ID:Contributor'
,p_column_linktext=>'#CONTRIBUTORS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(34316054051946979)
,p_query_column_id=>3
,p_column_alias=>'ADMINISTRATORS'
,p_column_display_sequence=>3
,p_column_heading=>'Administrators'
,p_column_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,32,RIR:IR_ACCESS_LEVEL_ID:Administrator'
,p_column_linktext=>'#ADMINISTRATORS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1847903392325835549)
,p_plug_name=>'ACL Status'
,p_parent_plug_id=>wwv_flow_api.id(1507731814407873035)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(case when access_level_id = 1 then 1 else 0 end) reader_count,',
'    sum(case when access_level_id = 2 then 1 else 0 end) contributor_count,',
'    sum(case when access_level_id = 3 then 1 else 0 end) admin_count',
'from eba_archive_users'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ACL_STATUS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'34'
,p_attribute_02=>'32'
,p_attribute_03=>'ADMIN_COUNT'
,p_attribute_04=>'CONTRIBUTOR_COUNT'
,p_attribute_05=>'READER_COUNT'
,p_attribute_06=>'eba_archive_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'')'
,p_attribute_07=>'eba_archive_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'')'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3178210813420693691)
,p_plug_name=>'Access Control'
,p_parent_plug_id=>wwv_flow_api.id(1507731814407873035)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(3178212311680693714)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1252727603670814283)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(3178213613384693719)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1847903509991835550)
,p_plug_name=>'Authentication and Authorization'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.AUTH_ADMINISTRATION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_api.id(3178213613384693719)
,p_attribute_01=>'22'
,p_attribute_02=>'Public Pages'
,p_attribute_03=>'Login Required Pages'
,p_attribute_04=>'Authorization Protected'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2177937231530009645)
,p_plug_name=>'Archive Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1 seq,',
'    (select to_char(count(*),''999G999G999G990'') from apex$archive_contents where app_id is not null) as value,',
'    ''Archived Components'' as label,',
'    ''#'' as the_link',
'from dual',
'union all',
'select',
'    2 seq,',
'    (select to_char(count(*) + 1,''999G999G999G990'') from apex$archive_contents where app_id is not null and content_type = ''APPLICATION'') as value,',
'    ''Applications'' as label,',
'    ''#'' as the_link',
'from dual',
'union all',
'select',
'    3 seq,',
'    (select to_char(count(*) + 1,''999G999G999G990'') from apex$archive_contents where app_id is not null and content_type = ''FILE'') as value,',
'    ''Files'' as label,',
'    ''#'' as the_link',
'from dual',
'union all',
'select',
'    4 seq,',
'    (select to_char(sum(sys.dbms_lob.getlength(content)) / 1024 / 1024, ''fm999G999G999G999G999G990'' ) || '' MB'' from apex$archive_contents where app_id is not null) as value,',
'    ''Archive Size'' as label,',
'    ''#'' as the_link',
'from dual'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'LABEL'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'2'
,p_attribute_06=>'B'
,p_attribute_07=>'BOX'
,p_attribute_08=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3178211217188693698)
,p_plug_name=>'Hidden Items'
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="width:49%; float:left; margin-right: 1%;"'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3178211625894693702)
,p_plug_name=>'Administration'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3228916826242280082)
,p_plug_name=>'Manage Archives'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   c                   integer := 0;',
'   c2                  integer := 1;',
'   l_last_app_id       number := 0;',
'   l_last_CONTENT_ID   number := 0;',
'   l_app_count         integer := 1;',
'   l_file_count        integer := 1;',
'   l_most_recent_size  number;',
'   l_total_count       number := 0;',
'   l_total_size        number := 0;',
'   l_apps_eq_1         integer := 0;',
'   l_apps_gt_1         integer := 0;',
'   l_apps_gt_2         integer := 0;',
'   l_apps_gt_3         integer := 0;',
'   l_apps_gt_4         integer := 0;',
'begin',
'    for c1 in (',
'        select count(*) c ',
'          from APEX$ARCHIVE_HEADER)',
'    loop',
'       sys.htp.prn(''<br />Archives: ''||to_char(c1.c,''999G999G990''));',
'       sys.htp.prn('' [ <a href="''',
'          ||apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13:P13_PURGE_ACTION:ALL'')',
'          ||''">Purge All Archives</a> ]'');',
'    end loop;',
'',
'    for c1 in (',
'        select ID, ',
'          nvl(APP_ID,0) app_id, ',
'          nvl(CONTENT_ID,0) CONTENT_ID, ',
'          CREATED , ',
'          sys.dbms_lob.getlength( content ) as arch_size,',
'          content_type',
'        from APEX$ARCHIVE_CONTENTS',
'       where app_id is not null',
'       order by app_id, created desc',
'    )',
'    loop',
'       c := c + 1;',
'       if c1.content_type = ''APPLICATION'' then',
'           l_app_count := l_app_count + 1;',
'       elsif c1.content_type = ''FILE'' then',
'           l_file_count := l_file_count + 1;',
'       end if;',
'       l_total_count := l_total_count + 1;',
'       l_total_size := l_total_size + c1.arch_size;',
'',
'       if l_last_app_id = c1.app_id and l_last_content_id = c1.content_id then',
'           c2 := c2 + 1;',
'       else',
'           if c > 1 then',
'              if c2 = 1 then l_apps_eq_1 := l_apps_eq_1 + 1; end if;',
'              if c2 > 1 then l_apps_gt_1 := l_apps_gt_1 + 1; end if;',
'              if c2 > 2 then l_apps_gt_2 := l_apps_gt_2 + 1; end if;',
'              if c2 > 3 then l_apps_gt_3 := l_apps_gt_3 + 1; end if;',
'              if c2 > 4 then l_apps_gt_4 := l_apps_gt_4 + 1; end if;',
'              c2 := 1;',
'           else',
'              c2 := 1;',
'           end if;',
'       end if; ',
'       l_last_app_id := c1.app_id;',
'       l_last_content_id := c1.content_id;',
'    end loop;',
'',
'    /*',
'    sys.htp.prn(''<br />Archived Components: ''||to_char(l_total_count,''999G999G999G990''));',
'    sys.htp.prn(''<br />Applications: ''||to_char(l_app_count,''999G999G999G990''));',
'    sys.htp.prn(''<br />Files: ''||to_char(l_file_count,''999G999G999G990''));',
'    sys.htp.prn(''<br />Archive Size: '' || to_char( l_total_size / 1024 / 1024, ''fm999G999G999G999G999G990'' ) || '' MB'' );',
'    */',
'',
'    sys.htp.prn(''<br />Components with only 1 archive: ''||to_char(l_apps_eq_1,''999G999G999G990''));',
'',
'    sys.htp.prn(''<br />Components with 2 or more versions: ''||to_char(l_apps_gt_1,''999G999G999G990''));',
'    if l_apps_gt_1 > 0 then',
'    sys.htp.prn('' [ <a href="''',
'        ||apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13:P13_PURGE_ACTION:1V'')',
'        ||''">Purge all except latest version</a> ]'');',
'    end if;',
'',
'    sys.htp.prn(''<br />Components with 3 or more versions:''||to_char(l_apps_gt_2,''999G999G999G990''));',
'     if l_apps_gt_2 > 0 then',
'    sys.htp.prn('' [ <a href="''',
'        ||apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13:P13_PURGE_ACTION:2V'')',
'        ||''">Purge all except latest 2 versions</a> ]'');',
'    end if;',
'',
'    sys.htp.prn(''<br />Components with 4 or more versions: ''||to_char(l_apps_gt_3,''999G999G999G990''));',
'    if l_apps_gt_3 > 0 then',
'    sys.htp.prn('' [ <a href="''',
'        ||apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13:P13_PURGE_ACTION:3V'')',
'        ||''">Purge all except latest 3 versions</a> ]'');',
'    end if;',
'',
'    sys.htp.prn(''<br />Components with 5 or more versions: ''||to_char(l_apps_gt_4,''999G999G999G990''));',
'    if l_apps_gt_4 > 0 then',
'    sys.htp.prn('' [ <a href="''',
'        ||apex_util.prepare_url(''f?p=''||:APP_ID||'':13:''||:APP_SESSION||'':::13:P13_PURGE_ACTION:4V'')',
'        ||''">Purge all except latest 4 versions</a> ]'');',
'    end if;',
'',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3228917028666280760)
,p_plug_name=>'Version Retention'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   for c1 in (',
'   select max_versions',
'   from APEX$ARCHIVE_PREF) loop',
'   sys.htp.prn(''<br />Maximum versions: ''||to_char(c1.max_versions,''999G999G990''));',
'   sys.htp.prn('' [ <a href="''',
'      ||apex_util.prepare_url(''f?p=''||:APP_ID||'':28:''||:APP_SESSION||'':::28:P28_ID:1'')',
'      ||''">Adjust</a> ]'');',
'   end loop;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3287934823315049115)
,p_plug_name=>'Administrative Tasks'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(3287935137167053090)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1252727603670814283)
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_required_role=>wwv_flow_api.id(3178213613384693719)
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1227327513664453716)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1227326930502449091)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'javascript:closeModal();'
,p_button_execute_validations=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1227327822322456152)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1227326930502449091)
,p_button_name=>'ENABLE_ACCESS_CONTROL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enable Access Control'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1410036413819516779)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1333787559104661963)
,p_name=>'Refresh Retention Region'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1333787627638661964)
,p_event_id=>wwv_flow_api.id(1333787559104661963)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3178212140053693711)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENABLE_ACCESS_CONTROL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Set AC flag',
'eba_archive_fw.set_preference_value(''ACCESS_CONTROL_ENABLED'',''Y'');',
'',
'-- Seed user table with current user as an administrator or set the current user as administrator',
'declare',
'   l_count number;',
'begin',
'    select count(*) ',
'       into l_count ',
'       from eba_archive_users',
'       where username = :APP_USER;',
'    if l_count = 0 then',
'        insert into eba_archive_users(username, access_level_id) values (:APP_USER, 3);   ',
'    else',
'        update eba_archive_users',
'            set access_level_id = 3',
'            where username = :APP_USER;',
'    end if;',
'end;'))
,p_process_error_message=>'Error'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ENABLE_ACCESS_CONTROL'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Access Control enabled and the current user ''&APP_USER.'' has been set to be an Administrator. '
,p_security_scheme=>wwv_flow_api.id(3178213613384693719)
);
wwv_flow_api.component_end;
end;
/
