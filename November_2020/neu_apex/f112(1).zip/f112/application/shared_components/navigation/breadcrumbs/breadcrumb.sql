prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(4296838443629175598)
,p_name=>' Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1041779196506524385)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Application Appearance'
,p_link=>'f?p=&APP_ID.:39:&SESSION.'
,p_page_id=>39
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1297477031871579044)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1304490021603674000)
,p_parent_id=>wwv_flow_api.id(2477678040604149553)
,p_short_name=>'Archive'
,p_link=>'f?p=&APP_ID.:29:&SESSION.'
,p_page_id=>29
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1304678617717380062)
,p_parent_id=>wwv_flow_api.id(2489234637593049857)
,p_short_name=>'Archive File'
,p_link=>'f?p=&APP_ID.:30:&SESSION.'
,p_page_id=>30
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318191941207196968)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:36:&SESSION.'
,p_page_id=>36
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1356130015556882587)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:12:&SESSION.'
,p_page_id=>12
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1356137221763894080)
,p_parent_id=>wwv_flow_api.id(1356130015556882587)
,p_short_name=>'Notification'
,p_link=>'f?p=&APP_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1410005420458192225)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1410014216242304186)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1410026628800346533)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2475424723962831950)
,p_parent_id=>wwv_flow_api.id(2477678040604149553)
,p_short_name=>'Archive History'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2475606911402851410)
,p_parent_id=>wwv_flow_api.id(2483797012704665302)
,p_short_name=>'Archives'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2477678040604149553)
,p_parent_id=>0
,p_short_name=>'Applications'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2482487813310352740)
,p_parent_id=>wwv_flow_api.id(2477678040604149553)
,p_short_name=>'Create Application Archive'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2483797012704665302)
,p_parent_id=>0
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2488178832016354842)
,p_parent_id=>wwv_flow_api.id(2475606911402851410)
,p_short_name=>'Archive Details'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2489234637593049857)
,p_parent_id=>0
,p_short_name=>'Files'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2492892009343622749)
,p_parent_id=>wwv_flow_api.id(2477678040604149553)
,p_short_name=>'Create Application Archive'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2496440129466304445)
,p_parent_id=>wwv_flow_api.id(2477678040604149553)
,p_short_name=>'Create Application Archive'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2511754923078636419)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Purge'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2514356038753974130)
,p_parent_id=>wwv_flow_api.id(2475606911402851410)
,p_short_name=>'Delete Archive'
,p_link=>'f?p=&FLOW_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2538434319723657024)
,p_parent_id=>wwv_flow_api.id(2483797012704665302)
,p_short_name=>'Archive Log'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2538904410373755260)
,p_parent_id=>wwv_flow_api.id(2489234637593049857)
,p_short_name=>'Archive Files'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2550143521499937322)
,p_parent_id=>wwv_flow_api.id(2483797012704665302)
,p_short_name=>'History'
,p_link=>'f?p=&APP_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2550537720571002957)
,p_parent_id=>wwv_flow_api.id(2555180036705962234)
,p_short_name=>'Restore Content'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2555180036705962234)
,p_parent_id=>0
,p_short_name=>'Archived Content'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2605654540799656856)
,p_parent_id=>wwv_flow_api.id(2555180036705962234)
,p_short_name=>'Content Restored'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2613305739458657032)
,p_parent_id=>wwv_flow_api.id(2489234637593049857)
,p_short_name=>'Archive History'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2619452216838040043)
,p_parent_id=>wwv_flow_api.id(2489234637593049857)
,p_short_name=>'Archive Files'
,p_link=>'f?p=&FLOW_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2620028623589211828)
,p_parent_id=>wwv_flow_api.id(2489234637593049857)
,p_short_name=>'Archive FIles'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2683330240828385750)
,p_parent_id=>wwv_flow_api.id(2483797012704665302)
,p_short_name=>'Applications Archived by Day (Timeline)'
,p_link=>'f?p=&FLOW_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2689561628431060800)
,p_parent_id=>wwv_flow_api.id(2555180036705962234)
,p_short_name=>'Search Application Archives'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2690925635489531327)
,p_parent_id=>wwv_flow_api.id(2555180036705962234)
,p_short_name=>'Display Archived Application'
,p_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2712696513856469838)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Adjust Preferences'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3178212015460693709)
,p_parent_id=>0
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3178267412983804431)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Access Control List'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3178273527518817933)
,p_parent_id=>wwv_flow_api.id(3178267412983804431)
,p_short_name=>'User Details'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3204399615864823729)
,p_parent_id=>wwv_flow_api.id(4296838855477175601)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3287934332492037921)
,p_parent_id=>wwv_flow_api.id(3178212015460693709)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3314452334794445262)
,p_parent_id=>wwv_flow_api.id(2483797012704665302)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&FLOW_ID.:20:&SESSION.'
,p_page_id=>20
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(4296838855477175601)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_api.component_end;
end;
/
