prompt --application/shared_components/navigation/lists/archive_reports
begin
--   Manifest
--     LIST: Archive Reports
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2538481427757667035)
,p_name=>'Archive Reports'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1304923524709234686)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Archives'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3,RIR:::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Lists the current archives. You can drill in to see the contents of each archive.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2538481613314667038)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'View Archive Log'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15,RIR:::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'View the log of archive requests.  Identifies who and when each request was made.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2550233629029944899)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'History'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP,11,RIR:::'
,p_list_item_icon=>'fa-history'
,p_list_text_01=>'Historical count of number of applications archived and the space consumed.  Use this report to view size changes of the archive over time.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2683349532804388291)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Archive Timeline'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'View a timeline of archived applications in a by Day timeline format.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3314452532644452767)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Activity Calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20:::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Page views by user displayed in a monthly calendar.'
,p_list_text_02=>'calendarIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
