prompt --application/shared_components/user_interface/lovs/archive_components
begin
--   Manifest
--     ARCHIVE COMPONENTS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(2490379010861797231)
,p_lov_name=>'ARCHIVE COMPONENTS'
,p_lov_query=>'.'||wwv_flow_api.id(2490379010861797231)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490379217504797232)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Applications'
,p_lov_return_value=>'APPLICATIONS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490379431430797234)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Workspace'
,p_lov_return_value=>'WORKSPACE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490379625183797235)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Users'
,p_lov_return_value=>'USERS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490379835541797235)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Files'
,p_lov_return_value=>'FILES'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490380014510797235)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Web Services'
,p_lov_return_value=>'WEBSERVICES'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2490380223519797235)
,p_lov_disp_sequence=>60
,p_lov_disp_value=>'Feedback'
,p_lov_return_value=>'FEEDBACK'
);
wwv_flow_api.component_end;
end;
/
