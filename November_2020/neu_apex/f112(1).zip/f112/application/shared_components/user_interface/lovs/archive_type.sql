prompt --application/shared_components/user_interface/lovs/archive_type
begin
--   Manifest
--     ARCHIVE TYPE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(3191153228603813244)
,p_lov_name=>'ARCHIVE TYPE'
,p_lov_query=>'.'||wwv_flow_api.id(3191153228603813244)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(3191153440825813250)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Incremental (only archive applications not currently archived or those that have changed since last archival)'
,p_lov_return_value=>'INCREMENTAL'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(3191153635119813255)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Full'
,p_lov_return_value=>'FULL'
);
wwv_flow_api.component_end;
end;
/
