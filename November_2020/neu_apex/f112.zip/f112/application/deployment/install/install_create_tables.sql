prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-create tables
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(2473603536196213776)
,p_install_id=>wwv_flow_api.id(2473557013686207276)
,p_name=>'create tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select 1 from user_tables where table_name = ''APEX$ARCHIVE_CONTENTS'''
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    wwv_flow_cloud_archive_obj.create_archive_objects;',
'end;',
'/'))
);
wwv_flow_api.component_end;
end;
/
