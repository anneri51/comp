prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive Details'
,p_alias=>'ARCHIVE-DETAILS'
,p_step_title=>'Archive Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479822695593204)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li > span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li > span em{color:#EA0000}',
'',
'a.simpleButton{display:inline-block;padding:0 8px;font:normal 11px/20px Arial,sans-serif;color:#666;background-color:#F0F0F0;border:1px solid #CCC;text-align:center;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:8px; text-decoration: '
||'none !important}',
'a.simpleButton:hover {background-color: #FFF}',
'</style>'))
,p_step_template=>wwv_flow_api.id(1252705462544814256)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20200205083117'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1456184916268411991)
,p_plug_name=>'Created'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--stacked:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select created, ''Date Created'' lbl',
'from APEX$ARCHIVE_HEADER h',
'where id = :P7_ARCHIVE_ID'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.MINICALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'CREATED'
,p_attribute_02=>'LBL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2488178536747354838)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2488178938335354842)
,p_plug_name=>'Archived Files'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252717549530814272)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 "ID",',
'	 "ROW_VERSION_NUMBER",',
'	 "HEADER_ID",',
'         version,',
'	 decode( content_type, ''APPLICATION'', ''Application'',',
'                               ''FILE'', ''File'',',
'                               ''WORKSPACE'', ''Workspace'',',
'                               ''REST'', ''RESTful Services'',',
'                               ''FILES'', ''Files'',',
'                               content_type ) as "CONTENT_TYPE",',
'	 "APP_ID",',
'	 "APP_NAME",',
'         case when app_id is not null then app_id || '': '' || app_name end as application,',
'         sys.dbms_lob.getlength( content ) as content_length,',
'         sys.dbms_lob.getlength( content ) as download,',
'	 "CONTENT_FILENAME",',
'	 "CONTENT_MIMETYPE",',
'	 "CONTENT_LAST_UPDATED",',
'	 "CONTENT_CHARSET",',
'	 "CREATION_ELAP_TIME",',
'	 "CREATED_BY",',
'	 "CREATED",',
'	 "UPDATED_BY",',
'	 "UPDATED" ,',
'         (select archive_name from APEX$ARCHIVE_HEADER h where c.header_id = h.id) archive_name,',
'         ''Restore'' restore, ',
'         ''View'' view_app',
' from	 "APEX$ARCHIVE_CONTENTS" c',
'where (header_id = nvl(to_number(:P7_ARCHIVE_ID),0)',
'       or nvl(to_number(:P7_ARCHIVE_ID),0) = 0)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2488179015278354842)
,p_name=>'Archived Files'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'Archive has no components'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'MIKE'
,p_internal_uid=>1845845206589698550
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179215766354844)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179339709354845)
,p_db_column_name=>'ROW_VERSION_NUMBER'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Row Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179430222354845)
,p_db_column_name=>'HEADER_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Header ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179540716354845)
,p_db_column_name=>'CONTENT_TYPE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Content Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179622118354845)
,p_db_column_name=>'APP_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Application ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179729762354845)
,p_db_column_name=>'APP_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Application'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179816995354845)
,p_db_column_name=>'CONTENT_FILENAME'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488179924810354845)
,p_db_column_name=>'CONTENT_MIMETYPE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180032152354846)
,p_db_column_name=>'CONTENT_LAST_UPDATED'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180132280354846)
,p_db_column_name=>'CONTENT_CHARSET'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Charset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180235999354846)
,p_db_column_name=>'CREATION_ELAP_TIME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Elap Time (seconds)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D000'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180329655354846)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180437774354846)
,p_db_column_name=>'CREATED'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180536443354846)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2488180628424354846)
,p_db_column_name=>'UPDATED'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2489705331585349062)
,p_db_column_name=>'CONTENT_LENGTH'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'File Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2489891009833522526)
,p_db_column_name=>'DOWNLOAD'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Download'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:APEX$ARCHIVE_CONTENTS:CONTENT:ID::CONTENT_MIMETYPE:CONTENT_FILENAME::CONTENT_CHARSET:inline:Download'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2489925333382529375)
,p_db_column_name=>'APPLICATION'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Application'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2556488034791831152)
,p_db_column_name=>'ARCHIVE_NAME'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Archive Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2556488126152831155)
,p_db_column_name=>'RESTORE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Restore'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:P17_ARCHIVE_ID:#ID#'
,p_column_linktext=>'#RESTORE#'
,p_column_link_attr=>'class="simpleButton"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2698927615681654570)
,p_db_column_name=>'VIEW_APP'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'View'
,p_column_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27:P27_APPLICATION:#ID#'
,p_column_linktext=>'#VIEW_APP#'
,p_column_link_attr=>'class="simpleButton"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2700125935325653778)
,p_db_column_name=>'VERSION'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2488237629040364216)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'18459039'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CONTENT_TYPE:APPLICATION:CONTENT_FILENAME:VERSION:CREATED_BY:CREATED:CONTENT_LENGTH:DOWNLOAD:RESTORE:VIEW_APP:'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2489448919830146898)
,p_plug_name=>'Selected Archive'
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p(''<ul class="vapList">'');',
'for c1 in (',
'select archive_name, VERSION, COMMENTS, created, created_by,',
'(select count(*) c from APEX$ARCHIVE_CONTENTS c where c.header_id = h.id) file_count,',
'(select sum(dbms_lob.getlength(CONTENT)) content_size',
'from APEX$ARCHIVE_CONTENTS c  where c.header_id = h.id) archive_size',
'from APEX$ARCHIVE_HEADER h',
'where id = :P7_ARCHIVE_ID) loop',
'',
'    if apex_util.public_check_authorization(''CONTRIBUTION RIGHTS'') then',
'        sys.htp.p(''<li><label>Archive Name</label><span>''||apex_escape.html(c1.archive_name)||'' &nbsp;&nbsp;[ <a href="javascript:apex.submit(''''DELETE_ARCHIVE'''')">Delete Archive</a> ]</span></li>'');',
'    else',
'        sys.htp.p(''<li><label>Archive Name</label><span>''||apex_escape.html(c1.archive_name)||''</span></li>'');',
'    end if;',
'    sys.htp.p(''<li><label>Archived</label><span>''||apex_util.get_since(c1.created)||''</span></li>'');',
'    sys.htp.p(''<li><label>Archived By</label><span>''||apex_escape.html(c1.created_by)||''</span></li>'');',
'    sys.htp.p(''<li><label>Files</label><span>''||to_char(c1.file_count,''999G999G999G990'')||''</span></li>'');',
'    sys.htp.p(''<li><label>Size</label><span>'' ||to_char( c1.archive_size / 1024, ''fm999G999G999G999G999G990'' ) || '' KB</span></li>'');',
'',
'end loop;',
'sys.htp.p(''</ul>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2698886225593647970)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2488178938335354842)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2514793434471133646)
,p_branch_name=>'Go To Page 14'
,p_branch_action=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:14:P14_ARCHIVE_ID:&P7_ARCHIVE_ID.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_branch_comment=>'Created 22-NOV-2011 15:14 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2488207635836356696)
,p_name=>'P7_ARCHIVE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2489448919830146898)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(1920222889210086990)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_api.component_end;
end;
/
