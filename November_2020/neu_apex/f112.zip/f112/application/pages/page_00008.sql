prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Files'
,p_alias=>'FILE-LIST'
,p_step_title=>'Files'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479720963592658)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'a.simpleButton{display:inline-block;padding:0 8px;font:normal 11px/20px Arial,sans-serif;color:#666;background-color:#F0F0F0;border:1px solid #CCC;text-align:center;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:8px; text-decoration: '
||'none !important}',
'a.simpleButton:hover {background-color: #FFF}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_required_patch=>wwv_flow_api.id(3187967021764496048)
,p_protection_level=>'C'
,p_help_text=>'<p>This is a listing of all the Files contained within your workspace (located under Shared Components).  Files can be Cascading Style Sheets, Images or Static Files.  You can archive a selected file or use the large Archive Files button to archive m'
||'ultiple. Click on the File Name to view the archive history.</p>'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201020063212'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1300918023454885828)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This is a listing of all the Files contained within your workspace (located under Shared Components).  Files can be Cascading Style Sheets, Images or Static Files.  You can archive a selected file or use the large Archive Files button to archive m'
||'ultiple. Click on the File Name to view the archive history.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2489234331569049857)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2612355839517256460)
,p_plug_name=>'Files'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252717549530814272)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    file_id,',
'    application_id,',
'    file_name,',
'    file_size,',
'    decode(last_archived,null,''Not Archived'',',
'       decode(greatest(last_archived,created_on),last_archived,',
'      ''Archived'',''Not Archived'')) status,',
'    created_by,',
'    created_on,',
'    created_on_date,',
'    file_type,',
'    associated_application,',
'    ''Archive'' action,',
'    last_archived,',
'    archived_versions,',
'    archive_size',
'from',
'(',
'    select application_file_id as file_id, ',
'      application_id, ',
'      file_name, ',
'      dbms_lob.getlength(file_content) as file_size, ',
'      created_by, ',
'      created_on, ',
'      created_on created_on_date, ',
'      mime_type as file_type,',
'      nvl(decode(nvl(application_id,0),0,''Workspace File'',',
'        (select application_id||'' ''||application_name x',
'         from apex_applications a ',
'         where a.application_id = f.application_id)),',
'        ''Associated application does not exist'') associated_application,',
'     --',
'     (select max(created) ',
'       from apex$archive_contents c',
'       where c.content_id = f.application_file_id) last_archived,',
'      --',
'      (select count(*) c',
'       from apex$archive_contents c',
'       where c.content_id = f.application_file_id) archived_versions,',
'      --',
'      (select sum(dbms_lob.getlength(content)) c',
'       from apex$archive_contents c',
'       where c.content_id = f.application_file_id) archive_size',
'      from APEX_APPLICATION_STATIC_FILES f',
'    where ',
'    (',
'        lower(file_name) like ''%.png'' or',
'        lower(file_name) like ''%.gif'' or',
'        lower(file_name) like ''%.jpg'' or',
'        lower(file_name) like ''%.jpeg'' or',
'        lower(file_name) like ''%.css'' or',
'        lower(file_name) like ''%.js''',
'    )',
'    union',
'    select',
'      workspace_file_id as file_id, ',
'      0 as application_id, ',
'      file_name, ',
'      dbms_lob.getlength(file_content) as file_size, ',
'      created_by, ',
'      created_on, ',
'      created_on created_on_date, ',
'      mime_type as file_type,',
'      ''Workspace File'' as associated_application,',
'     --',
'     (select max(created) ',
'       from apex$archive_contents c',
'       where c.content_id = f.workspace_file_id) last_archived,',
'      --',
'      (select count(*) c',
'       from apex$archive_contents c',
'       where c.content_id = f.workspace_file_id) archived_versions,',
'      --',
'      (select sum(dbms_lob.getlength(content)) c',
'       from apex$archive_contents c',
'       where c.content_id = f.workspace_file_id) archive_size',
'      from APEX_WORKSPACE_STATIC_FILES f',
'    where ',
'    (',
'        lower(file_name) like ''%.png'' or',
'        lower(file_name) like ''%.gif'' or',
'        lower(file_name) like ''%.jpg'' or',
'        lower(file_name) like ''%.jpeg'' or',
'        lower(file_name) like ''%.css'' or',
'        lower(file_name) like ''%.js''',
'    )',
') ilv'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2612355931511256460)
,p_name=>'Files'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'MIKE'
,p_internal_uid=>1970022122822600168
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356119537256464)
,p_db_column_name=>'FILE_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'File ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356216558256465)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Associated Application ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356324052256465)
,p_db_column_name=>'FILE_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'File Name'
,p_column_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_FILE_ID:#FILE_ID#'
,p_column_linktext=>'#FILE_NAME#'
,p_column_link_attr=>'title="View Archive History"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356438385256465)
,p_db_column_name=>'FILE_SIZE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356509624256465)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356608921256465)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356732930256465)
,p_db_column_name=>'CREATED_ON_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612356813026256465)
,p_db_column_name=>'FILE_TYPE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'File Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612755829923386205)
,p_db_column_name=>'ASSOCIATED_APPLICATION'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Associated Application'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2613366325888668835)
,p_db_column_name=>'ACTION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Archive'
,p_column_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_FILE_ID:#FILE_ID#'
,p_column_linktext=>'#ACTION#'
,p_column_link_attr=>'class="simpleButton"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2613928512523100271)
,p_db_column_name=>'STATUS'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2617538441163043940)
,p_db_column_name=>'LAST_ARCHIVED'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Last Archived'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2618657422153041351)
,p_db_column_name=>'ARCHIVED_VERSIONS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Archived Versions'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2618657535932041353)
,p_db_column_name=>'ARCHIVE_SIZE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Archive Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2612364240556256745)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'19700305'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'FILE_NAME:FILE_SIZE:CREATED_BY:CREATED_ON:LAST_ARCHIVED:STATUS:ASSOCIATED_APPLICATION:ARCHIVED_VERSIONS:ACTION:'
,p_sort_column_1=>'CREATED_ON'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2539056818116768301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2489234331569049857)
,p_button_name=>'ARCHIVE_FILES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archive Files'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16::'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2613162541033616484)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2612355839517256460)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RIR,CIR,RP::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1589350958412115285)
,p_name=>'Refresh Reports'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1589350970090115286)
,p_event_id=>wwv_flow_api.id(1589350958412115285)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2612355839517256460)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1589351089279115287)
,p_event_id=>wwv_flow_api.id(1589350958412115285)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Action Processed.'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(52080450557514101)
,p_name=>'Refresh on File Archive Create'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2539056818116768301)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(52080566114514102)
,p_event_id=>wwv_flow_api.id(52080450557514101)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(2612355839517256460)
);
wwv_flow_api.component_end;
end;
/
