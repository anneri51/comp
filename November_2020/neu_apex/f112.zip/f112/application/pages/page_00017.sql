prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>17
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Restore Content'
,p_alias=>'RESTORE-CONTENT'
,p_step_title=>'Restore Content'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479822695593204)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span em{color:#EA0000}',
'ul.secondaryList {',
'background-color: #FFF9C8;',
'border: 1px solid #A5A398;',
'border-radius: 4px;',
'margin-top: 16px !important;',
'}',
'</style>',
''))
,p_step_template=>wwv_flow_api.id(1252682257607814232)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2550537434149002953)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2555351840338991527)
,p_plug_name=>'contents'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_api.id(1252710023340814262)
,p_plug_display_sequence=>10
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select	 "ID",',
'	 "HEADER_ID",',
'         content_type content_type2,',
'	 decode(content_type,',
'             ''APPLICATION'',''Application'',',
'             content_type) "CONTENT_TYPE",',
'	 "APP_ID",',
'	 "APP_NAME",',
'         app_Id||'': ''||app_name application,',
'         dbms_lob.getlength(content) content_length,',
'         dbms_lob.getlength(content) download,',
'	 "CONTENT_FILENAME",',
'	 "CONTENT_MIMETYPE",',
'	 "CONTENT_LAST_UPDATED",',
'	 "CONTENT_CHARSET",',
'	 "CREATION_ELAP_TIME",',
'	 "CREATED_BY",',
'	 "CREATED",',
'	 "UPDATED_BY",',
'	 "UPDATED" ,',
'         (select archive_name from APEX$ARCHIVE_HEADER h where c.header_id = h.id) archive_name,',
'         version',
' from	 "APEX$ARCHIVE_CONTENTS" c',
'where id = :P17_ARCHIVE_ID ) loop',
'',
'',
'sys.htp.prn(''<ul class="vapList">'');',
'    sys.htp.p(''<li><label>Archive Name</label><span>'');',
'    sys.htp.p(apex_escape.html(c1.archive_name)||''</span></li>'');',
'',
'    sys.htp.p(''<li><label>Type</label><span>'');',
'    sys.htp.p(apex_escape.html(c1.CONTENT_TYPE)||''</span></li>'');',
'',
'    sys.htp.p(''<li><label>Version</label><span>'');',
'    sys.htp.p(to_char(c1.version,''999G999G990'')||''</span></li>'');',
'',
'    sys.htp.p(''<li><label>Size</label><span>'');',
'    sys.htp.p(to_char((c1.content_length/1024),''999G999G999G999G999G990'')||''K</span></li>'');',
'',
'    sys.htp.p(''<li><label>Archived</label><span>'');',
'    sys.htp.p(apex_util.get_since(c1.created)||'' by ''||',
'       apex_escape.html(c1.created_by)||',
'       ''</span></li>'');',
'',
'',
'    if c1.content_type2 = ''APPLICATION'' then',
'        sys.htp.p(''<li><label>Application Name</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.APP_NAME)||''</span></li>'');',
'        --',
'        sys.htp.p(''<li><label>Application ID</label><span>'');',
'        sys.htp.p(apex_escape.html(c1.app_id)||''</span></li>'');',
'        for c2 in (',
'            select application_name, last_updated_on',
'            from   apex_applications',
'            where  application_id = c1.app_id) loop',
'            sys.htp.p(''</ul><ul class="vapList secondaryList"><li><span><strong>An Application with this ID already exists.</strong></span></li>'');',
'',
'            sys.htp.p(''<li><label>Existing Application Name</label>'');',
'            sys.htp.p(''<span>''||apex_escape.html(c2.application_name)||''</span></li>'');',
'            sys.htp.p(''<li><label>Last Modified</label>'');',
'            sys.htp.p(''<span>''||apex_util.get_since(c2.last_updated_on)||''</span></li>'');',
'        end loop;',
'',
'    end if;',
'',
'',
'    sys.htp.p(''</ul>'');',
'',
'end loop;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2555514734845018316)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2550537434149002953)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2602848211501738286)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2550537434149002953)
,p_button_name=>'RESTORE_APPLICATION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Restore Content'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(2605052233524427458)
,p_branch_action=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 06-DEC-2011 07:50 by MIKE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2555382316920994236)
,p_name=>'P17_ARCHIVE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2555351840338991527)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2605021708937420380)
,p_name=>'P17_FILE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2555351840338991527)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2603416939271626200)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'restore_APPLICATION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  x                  number;',
'  l_file_size        integer := 0;',
'  l_file_size_disp   varchar2(255) := 0;',
'begin',
'for c1 in (',
'select CONTENT,',
'       APP_ID,',
'       APP_NAME,',
'       CONTENT_FILENAME,',
'       CONTENT_MIMETYPE,',
'       CONTENT_LAST_UPDATED,',
'       CONTENT_CHARSET,',
'       dbms_lob.getlength(content) content_size',
'from APEX$ARCHIVE_CONTENTS',
'where id = :P17_ARCHIVE_ID and app_id is not null',
') loop',
'x := wwv_flow_utilities.load_apex_archive_file (',
'    p_blob           => c1.content,',
'    p_app_id         => c1.app_id,',
'    p_file_type      => ''FLOW_EXPORT'',',
'    p_file_name      => c1.CONTENT_FILENAME||'' ''||to_char(localtimestamp,''YYYYMMDDHH24MISS''),',
'    p_title          => c1.CONTENT_FILENAME,',
'    p_mime_type      => c1.CONTENT_MIMETYPE,',
'    p_file_charset   => c1.CONTENT_CHARSET,',
'    p_description    => ''Archive Restore''',
'    );',
':P17_FILE_ID := x;',
'commit;',
'exit;',
'end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'File copied to export repository'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.component_end;
end;
/
