prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archived Content'
,p_alias=>'ARCHIVED-CONTENT'
,p_step_title=>'Archived Content'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479822695593204)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'a.simpleButton{display:inline-block;padding:0 8px;font:normal 11px/20px Arial,sans-serif;color:#666;background-color:#F0F0F0;border:1px solid #CCC;text-align:center;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:8px; text-decoration: '
||'none !important}',
'a.simpleButton:hover {background-color: #FFF}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This report contains all archived content.  There are links to view the Application, view the Archive''s details, download ',
'the content and to restore the content.  Restore will add the content to the Export Repository of the current workspace.  You',
' will then need to install from there. Note that Archived Content will be removed based upon Version Retention (the number of',
' versions to keep).  Version Retention is managed under Administration.</p>'))
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20200205083856'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1303147911998355692)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This report contains all archived content.  There are links to view the Application, view the Archive''s details, download ',
'the content and to restore the content.  Restore will add the content to the Export Repository of the current workspace.  You',
' will then need to install from there. Note that Archived Content will be removed based upon Version Retention (the number of',
' versions to keep).  Version Retention is managed under Administration.</p>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2555008524814949866)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2555008719729949867)
,p_plug_name=>'Archived Files'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252717549530814272)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'    row_version_number,',
'    version,',
'    header_id,',
'    decode(content_type,',
'        ''APPLICATION'',''Application'',',
'        ''FILE'',''File'',',
'        ''WORKSPACE'',''Workspace'',',
'        content_type) content_type,',
'    case when content_type = ''APPLICATION''',
'        then app_id ',
'        else null',
'    end app_id,',
'    case when content_type = ''APPLICATION''',
'        then ''<a href=''||apex_util.prepare_url(''f?p=''||:APP_ID||'':27:''||:APP_SESSION',
'                                            ||'':::27:P27_APPLICATION:''||id)',
'            ||'' title="View Archived Application">''||apex_escape.html(app_name)||''</a>'' ',
'        else ''N/A''',
'    end app_name,',
'    dbms_lob.getlength(content) content_length,',
'    dbms_lob.getlength(content) download,',
'    content_filename,',
'    content_mimetype,',
'    content_last_updated,',
'    content_charset,',
'    creation_elap_time,',
'    created_by,',
'    created,',
'    updated_by,',
'    updated,',
'    (   select archive_name',
'        from apex$archive_header h',
'        where c.header_id = h.id ) archive_name,',
'    c.header_id archive_id,',
'    ''Restore'' restore',
' from apex$archive_contents c'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2555008929157949867)
,p_name=>'Archived Files'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'Archive has no components'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'MIKE'
,p_internal_uid=>1912675120469293575
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009036219949870)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Selected Content'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009141027949870)
,p_db_column_name=>'ROW_VERSION_NUMBER'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Row Version'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009220059949870)
,p_db_column_name=>'HEADER_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Header ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009320261949870)
,p_db_column_name=>'CONTENT_TYPE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Content Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009418491949870)
,p_db_column_name=>'APP_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'App ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009536126949870)
,p_db_column_name=>'APP_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009621458949870)
,p_db_column_name=>'CONTENT_FILENAME'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009719794949870)
,p_db_column_name=>'CONTENT_MIMETYPE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009816945949871)
,p_db_column_name=>'CONTENT_LAST_UPDATED'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555009929935949871)
,p_db_column_name=>'CONTENT_CHARSET'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Charset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010015118949871)
,p_db_column_name=>'CREATION_ELAP_TIME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Elap Time (seconds)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D000'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010137118949871)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010237750949871)
,p_db_column_name=>'CREATED'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010312486949871)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010425729949871)
,p_db_column_name=>'UPDATED'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010534615949871)
,p_db_column_name=>'CONTENT_LENGTH'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Content Length'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555010638129949871)
,p_db_column_name=>'DOWNLOAD'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Download'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:APEX$ARCHIVE_CONTENTS:CONTENT:ID::CONTENT_MIMETYPE:CONTENT_FILENAME::CONTENT_CHARSET:inline:Download'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555254020121976271)
,p_db_column_name=>'ARCHIVE_NAME'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Archive Name'
,p_column_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP,7:P7_ARCHIVE_ID:#ARCHIVE_ID#'
,p_column_linktext=>'#ARCHIVE_NAME#'
,p_column_link_attr=>'title="View Archive Details"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2555427529173007268)
,p_db_column_name=>'RESTORE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Restore'
,p_column_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:P17_ARCHIVE_ID:#ID#'
,p_column_linktext=>'<span>#RESTORE#</span>'
,p_column_link_attr=>'class="simpleButton" style="text-decoration: none"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2700103214893647921)
,p_db_column_name=>'VERSION'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1304935435128412180)
,p_db_column_name=>'ARCHIVE_ID'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Archive Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2555010822962949872)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'19126771'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CONTENT_FILENAME:CONTENT_TYPE:VERSION:APP_ID:APP_NAME:CREATED_BY:CREATED:CONTENT_LENGTH:ARCHIVE_NAME:DOWNLOAD:RESTORE:ARCHIVE_ID'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1297520109029052948)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2555008524814949866)
,p_button_name=>'SEARCH_CONTENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search App Archives'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2555008114156949861)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2555008719729949867)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.component_end;
end;
/
