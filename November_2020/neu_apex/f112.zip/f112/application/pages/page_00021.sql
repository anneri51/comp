prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>21
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Applications Archived by Day (Timeline)'
,p_alias=>'APPLICATIONS-ARCHIVED-BY-DAY-TIMELINE'
,p_step_title=>'Applications Archived by Day (Timeline)'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479924426593750)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'div.ebaTimeline{border-bottom:1px solid #DDD;clear:both;position:relative;}',
'div.ebaTimeline:last-child{border-bottom:none;}',
'div.ebaTimeline h3{font:bold 11px/12px Arial,sans-serif;margin:0;padding:9px 10px;width:80px;color:#333;position:absolute;top:0;left:0;}',
'div.ebaTimeline h3 + ul{margin:0;list-style:none;padding:0;margin:0 0 0 80px;}',
'div.ebaTimeline ul li{display:table;width:100%;position:relative;}',
'div.ebaTimeline ul.ebaNoHover li:hover span.eS,',
'div.ebaTimeline ul.ebaNoHover li:hover span.eL{background:transparent;}',
'div.ebaTimeline ul li:hover span.eS{background-color:#F8F8F8;}',
'div.ebaTimeline ul li:hover span.eL{background:#F8F8F8;}',
'div.ebaTimeline ul li:hover span.eL a.eN span{text-decoration:underline;}',
'div.ebaTimeline ul li span.eD,',
'div.ebaTimeline ul li span.eS,',
'div.ebaTimeline ul li span.eL{display:table-cell;vertical-align:top;}',
'div.ebaTimeline ul li span.eD{width:20px;padding:0 10px 0 0;font:normal 11px/30px Arial,sans-serif;border-right:1px solid #EEE;text-align:right;color:#666;}',
'div.ebaTimeline ul li span.eS{padding:5px;width:20px;border-bottom:1px dotted #EEE;;}',
'div.ebaTimeline ul li:last-child span.eS,',
'div.ebaTimeline ul li:last-child span.eL{border-bottom:none;}',
'div.ebaTimeline ul li span.eS span{display:block;width:12px;height:12px;border-radius:10px;-moz-border-radius:10px;-webkit-box-shadow:0 1px 1px rgba(255,255,255,.75),0 0 2px rgba(0,0,0,.5) inset;-moz-box-shadow:0 1px 1px rgba(255,255,255,.75),0 0 2px'
||' rgba(0,0,0,.5) inset;box-shadow:0 1px 1px rgba(255,255,255,.75),0 0 2px rgba(0,0,0,.5) inset;background:-webkit-gradient(linear,0 0,0 100%,from(transparent),to(rgba(0,0,0,.25)));background:-moz-linear-gradient(top,transparent,rgba(0,0,0,.25));margin'
||':4px;}',
'div.ebaTimeline ul li span.eS span.ebaRed{background-color:#F00;}',
'div.ebaTimeline ul li span.eS span.ebaYellow{background-color:#FCE709;}',
'div.ebaTimeline ul li span.eS span.ebaGreen{background-color:#22C615;}',
'div.ebaTimeline ul li span.eS span.ebaBlack{background-color:#444;}',
'div.ebaTimeline ul li span.eS span.ebaNull{background-color:#CCC;}',
'div.ebaTimeline ul li span.eL{border-bottom:1px dotted #EEE;}',
'div.ebaTimeline ul li a.eN{display:block;padding:7px 0;text-decoration:none;}',
'div.ebaTimeline ul li a.eN span{display:block;font:bold 12px/16px Arial,sans-serif;color:#333;}',
'div.ebaTimeline ul li a.eN em,',
'div.ebaTimeline ul li span.eL em{display:block;font:normal 11px/16px Arial,sans-serif;color:#666;}',
'div.ebaTimeline ul li a.ebaEditLink{position:absolute;right:0;top:0;display:block;margin:7px 7px 0 0;font:normal 11px/12px Arial,sans-serif;text-decoration:none;color:#666;padding:2px 10px;border-radius:4px;-moz-border-radius:4px;border:1px solid #EE'
||'E;-webkit-transition:background .2s linear,border .2s linear,color .2s linear;}',
'div.ebaTimeline ul li a.ebaEditLink:hover{border:1px solid #BBB;background:#FFF;color:#333;}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2144353406721100569)
,p_plug_name=>'Timeline'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    ROW_VERSION_NUMBER,',
'    created,',
'    ''gray'' as color,',
'    apex_util.prepare_url(''f?p=''||:APP_ID||'':2:''||:APP_SESSION||'':::2:P2_APP_ID:''||app_id) the_link,',
'    APP_ID   attribute_01,',
'    APP_NAME primary_label,',
'    dbms_lob.getlength(CONTENT) attribute_02,',
'    CONTENT_FILENAME attribute_03,',
'    CREATED attribute_04,',
'    to_char(CREATED,''Month'') the_month,',
'    to_char(CREATED,''YYYY'') the_year,',
'    to_char(CREATED,''DD'') the_day,',
'    (select last_updated_on from apex_applications a where a.application_id = c.app_id) attribute_05',
'from APEX$ARCHIVE_CONTENTS c',
'where content_type = ''APPLICATION'' and dbms_lob.getlength(CONTENT) > 0 and',
'     (nvl(:P21_APPLICATION,0) = 0 or c.app_id = nvl(:P21_APPLICATION,0))',
'order by created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TIMELINESTATUSLIST'
,p_plug_query_num_rows=>50
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'CREATED'
,p_attribute_02=>'COLOR'
,p_attribute_03=>'PRIMARY_LABEL'
,p_attribute_04=>'THE_LINK'
,p_attribute_05=>'ATTRIBUTE_01'
,p_attribute_06=>'ATTRIBUTE_02'
,p_attribute_07=>'ATTRIBUTE_03'
,p_attribute_08=>'ATTRIBUTE_04'
,p_attribute_12=>'D'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144353506309100570)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ID'
,p_is_visible=>true
,p_heading=>'Id'
,p_display_sequence=>10
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144353615031100571)
,p_name=>'ROW_VERSION_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ROW_VERSION_NUMBER'
,p_is_visible=>true
,p_heading=>'Row version number'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144353739917100572)
,p_name=>'THE_LINK'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'THE_LINK'
,p_is_visible=>true
,p_heading=>'The link'
,p_display_sequence=>30
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144353865245100573)
,p_name=>'ATTRIBUTE_01'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ATTRIBUTE_01'
,p_is_visible=>true
,p_heading=>'App ID'
,p_display_sequence=>40
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144353968540100574)
,p_name=>'PRIMARY_LABEL'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'PRIMARY_LABEL'
,p_is_visible=>true
,p_heading=>'Primary label'
,p_display_sequence=>50
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354064859100575)
,p_name=>'ATTRIBUTE_02'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ATTRIBUTE_02'
,p_is_visible=>true
,p_heading=>'File Size'
,p_display_sequence=>60
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354157743100576)
,p_name=>'ATTRIBUTE_03'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ATTRIBUTE_03'
,p_is_visible=>true
,p_heading=>'Filename'
,p_display_sequence=>70
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354178918100577)
,p_name=>'ATTRIBUTE_04'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ATTRIBUTE_04'
,p_is_visible=>true
,p_heading=>'Created'
,p_display_sequence=>80
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354351603100578)
,p_name=>'THE_MONTH'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'THE_MONTH'
,p_is_visible=>true
,p_heading=>'The month'
,p_display_sequence=>90
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354422982100579)
,p_name=>'THE_YEAR'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'THE_YEAR'
,p_is_visible=>true
,p_heading=>'The year'
,p_display_sequence=>100
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354519730100580)
,p_name=>'THE_DAY'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'THE_DAY'
,p_is_visible=>true
,p_heading=>'The day'
,p_display_sequence=>110
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354626779100581)
,p_name=>'ATTRIBUTE_05'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'ATTRIBUTE_05'
,p_is_visible=>true
,p_heading=>'Attribute 05'
,p_display_sequence=>120
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354753351100582)
,p_name=>'COLOR'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'COLOR'
,p_is_visible=>true
,p_heading=>'Color'
,p_display_sequence=>130
,p_use_as_row_header=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(2144354834826100583)
,p_name=>'CREATED'
,p_source_type=>'DB_COLUMN'
,p_data_type=>'CREATED'
,p_is_visible=>true
,p_heading=>'Created'
,p_display_sequence=>140
,p_use_as_row_header=>false
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2683329912101385747)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2684716835358748624)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2684943016620790516)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2684716835358748624)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(1252731113576814290)
,p_button_image_alt=>'Reset'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:21::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2684747826485755540)
,p_name=>'P21_APPLICATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2684716835358748624)
,p_item_default=>'0'
,p_prompt=>'Application'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_name||'' - ''||application_id, application_id',
'from apex_applications',
'where workspace_id = :flow_security_group_id',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All Applications -'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_api.component_end;
end;
/
