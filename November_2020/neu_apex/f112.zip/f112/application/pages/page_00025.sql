prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Archive FIles'
,p_alias=>'ARCHIVE-FILES3'
,p_page_mode=>'MODAL'
,p_step_title=>'Archive FIles'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1297479720963592658)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.vapList{margin:0 !important;list-style:none}',
'ul.vapList li{display:block;border-top:1px solid #EEE}',
'ul.vapList li:first-child{border-top:none}',
'ul.vapList li a{color:#3D5B80}',
'ul.vapList li label{display:inline-block;width:140px;padding:6px 12px;font:bold 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'ul.vapList li span{display:inline-block;padding:6px 12px;font:normal 11px/20px Arial,sans-serif;color:#444;vertical-align:top}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(3178217216040777118)
,p_required_patch=>wwv_flow_api.id(3187967021764496048)
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130642'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(1218302416925346519)
,p_name=>'Display Text'
,p_template=>wwv_flow_api.id(1252711439049814264)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P16_ARCHIVE_NAME archive_name,',
'	:P16_ARCHIVE_TYPE type,',
'	--replace(rtrim(:P24_FILES_TO_ARCHIVE,'':''),'':'','', '') files_to_archive',
'    :P25_FILE_NAMES files_to_archive',
'from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_query_row_template=>wwv_flow_api.id(1252724637305814280)
,p_query_headings_type=>'QUERY_COLUMNS_INITCAP'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218302730823346521)
,p_query_column_id=>1
,p_column_alias=>'ARCHIVE_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'ARCHIVE_NAME'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218302829257346521)
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'TYPE'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(1218302920893346521)
,p_query_column_id=>3
,p_column_alias=>'FILES_TO_ARCHIVE'
,p_column_display_sequence=>3
,p_column_heading=>'FILES_TO_ARCHIVE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1589350440716115280)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2620027022113211821)
,p_plug_name=>'Form Elements'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711439049814264)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_translate_title=>'N'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1589350507456115281)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1589350440716115280)
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2620027828530211827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1589350440716115280)
,p_button_name=>'ARCHIVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Archive'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2620027637288211825)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1589350440716115280)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252730954090814290)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3769658889432420)
,p_name=>'P25_FILE_NAMES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2620027022113211821)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2620027211130211821)
,p_name=>'P25_COMMENTS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2620027022113211821)
,p_prompt=>'Archive Comments'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(1252730703889814288)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(3769726867432421)
,p_computation_sequence=>10
,p_computation_item=>'P25_FILE_NAMES'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_vc_arr2 APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    l_files   varchar2(32767);',
'    l_file    varchar2(1000);',
'BEGIN',
'',
'    l_vc_arr2 := APEX_UTIL.STRING_TO_TABLE(ltrim(rtrim(:P24_FILES_TO_ARCHIVE,'':''),'':''));',
'    ',
'    for i in 1 .. l_vc_arr2.count',
'    LOOP',
'        BEGIN',
'            select file_name into l_file from apex_application_static_files where application_file_id = l_vc_arr2(i);',
'        EXCEPTION',
'          WHEN OTHERS THEN',
'            l_file := null;',
'        END;',
'',
'        if l_file is null THEN',
'            BEGIN',
'                select file_name into l_file from apex_workspace_static_files where workspace_file_id = l_vc_arr2(i);',
'            EXCEPTION',
'              WHEN OTHERS THEN',
'                l_file := null;',
'            END;',
'        end if;',
'',
'        l_files := l_files || '', '' || l_file;',
'    END LOOP;',
'    l_files := trim(BOTH '','' from l_files);',
'    return l_files;',
'END;'))
,p_compute_when=>'P24_FILES_TO_ARCHIVE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1589350660662115282)
,p_name=>'Cancel Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(1589350507456115281)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1589350697151115283)
,p_event_id=>wwv_flow_api.id(1589350660662115282)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2620028728569211828)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'archive application'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_vc_arr2          APEX_APPLICATION_GLOBAL.VC_ARR2;',
'BEGIN',
'',
'    l_vc_arr2 := APEX_UTIL.STRING_TO_TABLE(ltrim(rtrim(:P24_FILES_TO_ARCHIVE,'':''),'':''));',
'    ',
'    apex_cloud_archive.archive_files(',
'        p_workspace_id   => :FLOW_SECURITY_GROUP_ID,',
'        p_files          => l_vc_arr2,',
'        p_archive_name   => :P16_ARCHIVE_NAME,',
'        p_comments       => :P25_COMMENTS);',
'END',
';'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2620027828530211827)
,p_process_success_message=>'Files Archived'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1589350773562115284)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
