prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_api.id(1121032412428498402)
,p_name=>'Search Application Archives'
,p_alias=>'SEARCH-APPLICATION-ARCHIVES'
,p_step_title=>'Search Application Archives'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(1297479924426593750)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'body { min-width: 800px !important;}',
'',
'code.codeView{margin:0;padding:0;overflow:auto;background-color:#fdf6e3;display:block}',
'code.codeView.searchResults ol li{padding-left:0}',
'code.codeView.searchResults ol li a{padding-left:8px}',
'code.codeView.searchResults ol li:nth-child(odd){background-color:#fdf6e3}',
'code.codeView.searchResults ol:nth-child(odd) li{background-color:#F6EFDC}',
'code.codeView h3{border-bottom:1px solid #93a1a1;border-top:1px solid #93a1a1;padding:8px;font:bold 13px/24px "Consolas","Menlo","Courier New",courier,mono;color:#586e75;background-color:#F8F8F8}',
'code.codeView h3:first-child{border-top:none}',
'code.codeView ol{list-style:decimal outside;margin:0 0 0 64px}',
'code.codeView ol li{color:#657b83;font:normal 11px/24px "Consolas","Menlo","Courier New",courier,mono;white-space:pre;border-left:1px solid #93a1a1;padding-left:8px;background-color:#fdf6e3}',
'code.codeView ol li a{display:block;color:#657b83;text-decoration:none}',
'code.codeView ol li:nth-child(odd){background-color:#F6EFDC}',
'code.codeView ol li.selected,code.codeView ol li a:hover{background-color:#d6d1be;color:#586e75}',
'',
'#searchresults .uRegionContent {padding: 0;}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_last_upd_yyyymmddhh24miss=>'20200116130021'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2689561314180060796)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1252711609209814265)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(4296838443629175598)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1252731569743814292)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2689908419893178958)
,p_plug_name=>'search blob'
,p_region_name=>'searchresults'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Region--removeHeader'
,p_plug_template=>wwv_flow_api.id(1252718055457814273)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_line      varchar2(32767) := null;',
'    l_str1      varchar2(32767) := null;',
'    l_str2      varchar2(32767) := null;',
'    l_leftover  varchar2(32767) := null;',
'    l_chunksize number := 3000;',
'    l_offset    number := 1;',
'    l_linebreak varchar2(2) := chr(10);',
'    l_length    number;',
'    p_blob blob;',
'    c           integer := 0;',
'    m           integer := 0;',
'    l_app       varchar2(255) := :APP_ID;',
'    l_session   varchar2(255) := :APP_SESSION;',
'    l_window    integer := 20;',
'    l_window2   integer := 50;',
'begin',
'    sys.htp.p(''<code class="codeView searchResults">'');',
'    for c1 in ( select id, APP_NAME, app_id, content, created, HEADER_ID, version',
'                from APEX$ARCHIVE_CONTENTS',
'                where APP_ID = apex_escape.html(:P26_APPLICATION)',
'                order by created desc ) loop',
'        c := 0;',
'        l_line := null;',
'        l_str1 := null;',
'        l_str2 := null;',
'        l_leftover := null;',
'        l_offset := 1;',
'        l_length  := null;',
'',
'        sys.htp.p(''<h3>''||c1.app_id||''. ''||apex_escape.html(c1.app_name)||'' version: ''||c1.version||'' - ''||apex_util.get_since(c1.created)||''</h3>'');',
'        p_blob := c1.content;',
'',
'        l_length := dbms_lob.getlength(p_blob);',
'',
'        while l_offset < l_length loop',
'',
'            l_str1 := l_leftover ||utl_raw.cast_to_varchar2(dbms_lob.substr(p_blob, l_chunksize, l_offset));',
'            l_leftover := null;',
'            l_str2 := l_str1;',
'',
'            while l_str2 is not null loop',
'                c := c + 1;',
'                if instr(l_str2, l_linebreak) <= 0 then',
'                    l_leftover := l_str2;',
'                    l_str2 := null;',
'                else',
'                    l_line := substr(l_str2, 1, instr(l_str2, l_linebreak)-1);',
'',
'                    if instr(upper(l_line),upper(:P26_SEARCH)) > 0 then',
'                        l_line := replace(l_line,''unistr(''''\000a'''')||'',null);',
'                        sys.htp.prn(''<ol start="''||to_char(c)||''"><li>''||''<a href="''',
'                            ||apex_util.prepare_url(''f?p=''||l_app||'':27:''||l_session||'':::27:''||''P27_LINE,P27_LINE2,P27_APPLICATION,P27_SELECTED_LINE:''',
'                                ||to_char(greatest(c - l_window,1))||'',''||to_char(c + l_window2)||'',''||c1.id||'',''||to_char(c))',
'                            ||''">''||apex_escape.html(l_line)||''</a></span></li></ol>'');',
'                        m := m + 1;',
'                    end if;',
'',
'                    l_str2 := substr(l_str2, instr(l_str2, l_linebreak)+1);',
'                end if;',
'                if m > 1000 then exit; end if;',
'',
'            end loop;',
'',
'            l_offset := l_offset + l_chunksize;',
'            if m > 1000 then exit; end if;',
'        end loop;',
'',
'        if l_leftover is not null then',
'            null;',
'            --dbms_output.put_line ( l_leftover );',
'        end if;',
'    end loop;',
'    sys.htp.p(''</code>'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'PLSQL_EXPRESSION'
,p_plug_display_when_condition=>'length(:P26_SEARCH) > 1 and nvl(:P26_APPLICATION,0) > 0'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2690313238574383028)
,p_plug_name=>'search'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(1252712248390814266)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2690397335935391734)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2689561314180060796)
,p_button_name=>'P26_GO'
,p_button_static_id=>'P26_GO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1252731539068814292)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2690370428662389694)
,p_name=>'P26_SEARCH'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2690313238574383028)
,p_prompt=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1252730828830814289)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2690461136889410923)
,p_name=>'P26_APPLICATION'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2690313238574383028)
,p_item_default=>'0'
,p_prompt=>'Application'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_name||'' - ''||application_id, application_id',
'from apex_applications',
'where workspace_id = :flow_security_group_id',
'and upper(build_status) <> ''RUN AND HIDDEN''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Application -'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(1252730828830814289)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
