prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479311959590076)
,p_group_name=>'ACL'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(3178261633959790084)
,p_group_name=>'Administration'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479619578592289)
,p_group_name=>'Applications'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479822695593204)
,p_group_name=>'Archives'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297485020233639767)
,p_group_name=>'Create Archive'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479720963592658)
,p_group_name=>'Files'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297480025812594124)
,p_group_name=>'Home'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297488238764683037)
,p_group_name=>'Mobile'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479514037590669)
,p_group_name=>'Other'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1297479924426593750)
,p_group_name=>'Reports'
);
wwv_flow_api.component_end;
end;
/
