prompt --application/shared_components/navigation/lists/archive_train
begin
--   Manifest
--     LIST: archive train
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2492674909002549896)
,p_name=>'archive train'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2492675131420549906)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Options'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5,16'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2496471322686309363)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Contents'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2492675430516549910)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Confirm'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_security_scheme=>wwv_flow_api.id(3178217216040777118)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9:25'
);
wwv_flow_api.component_end;
end;
/
