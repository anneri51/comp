prompt --application/shared_components/user_interface/lovs/archive_names
begin
--   Manifest
--     ARCHIVE NAMES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(2489494626194158278)
,p_lov_name=>'ARCHIVE NAMES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select archive_name||'' - ''||to_char(created,''YYYY.MM.DD HH24:MI'') archive, id',
'from APEX$ARCHIVE_HEADER',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_api.component_end;
end;
/
