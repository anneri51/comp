prompt --application/shared_components/user_interface/lovs/purge_actions
begin
--   Manifest
--     PURGE ACTIONS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(2512099113385679809)
,p_lov_name=>'PURGE ACTIONS'
,p_lov_query=>'.'||wwv_flow_api.id(2512099113385679809)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2512099311995679810)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Purge All Archives'
,p_lov_return_value=>'ALL'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2512099522602679810)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Purge all except latest version'
,p_lov_return_value=>'1V'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2512099722662679810)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Purge all except latest 2 versions'
,p_lov_return_value=>'2V'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2512099940034679810)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Purge all except latest 3 versions'
,p_lov_return_value=>'3V'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(2512100127042679810)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Purge all except latest 4 versions'
,p_lov_return_value=>'4V'
);
wwv_flow_api.component_end;
end;
/
