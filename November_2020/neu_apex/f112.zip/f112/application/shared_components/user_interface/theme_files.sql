prompt --application/shared_components/user_interface/theme_files
begin
--   Manifest
--     THEME FILES: 112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20
,p_default_application_id=>7270
,p_default_id_offset=>32947560167136877
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_api.component_end;
end;
/
