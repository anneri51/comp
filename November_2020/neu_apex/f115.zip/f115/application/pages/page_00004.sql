prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>6988393411891522
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(47574086381610126)
,p_name=>'Text_Replaced'
,p_step_title=>'Text_Replaced'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(48249782252242664)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200612210642'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(47775833588146714)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select txt_con.PK_TXT_REPLACE_CONTEXT,',
'       txt_con.FK_TXT_REPLACE,',
'       length(FROM_TXT) l_from_txt,',
'       length(TO_TXT) l_to_txt,',
'       txt_con.DATUM,',
'       txt_con.CONTEXT,',
'       txt_con.CONTEXT_TYPE,',
'       suchen,',
'       ersetzen,',
'       fk_txt_replace_context_previous,',
'       substr(view_header_old,1,200) view_header_old,',
'       substr(view_sql_old,1,200) view_sql_old',
'  from T_TXT_REPLACE_CONTEXT txt_con',
'    left join t_txt_replace txt on txt_con.fk_txt_replace = txt.pk_txt_replace'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(47775996092146715)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4:P4_PK_TXT_REPLACE_CONTEXT:#PK_TXT_REPLACE_CONTEXT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>47775996092146715
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776080670146716)
,p_db_column_name=>'PK_TXT_REPLACE_CONTEXT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Txt Replace Context'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776159101146717)
,p_db_column_name=>'FK_TXT_REPLACE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk Txt Replace'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776481790146720)
,p_db_column_name=>'DATUM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776510737146721)
,p_db_column_name=>'CONTEXT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Context'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776620984146722)
,p_db_column_name=>'CONTEXT_TYPE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Context Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776739770146723)
,p_db_column_name=>'L_FROM_TXT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'L From Txt'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_FROM_TXT,P4_TO_TXT,P4_CONTEXT,P4_CONTEXT_TYPE:#L_FROM_TXT#,,#CONTEXT#,#CONTEXT_TYPE#'
,p_column_linktext=>'#L_FROM_TXT#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776871395146724)
,p_db_column_name=>'L_TO_TXT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'L To Txt'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_FROM_TXT,P4_TO_TXT,P4_CONTEXT,P4_CONTEXT_TYPE:#L_TO_TXT#,,#CONTEXT#,#CONTEXT_TYPE#'
,p_column_linktext=>'#L_TO_TXT#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47776992198146725)
,p_db_column_name=>'SUCHEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Suchen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47777094925146726)
,p_db_column_name=>'ERSETZEN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Ersetzen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47777772557146733)
,p_db_column_name=>'FK_TXT_REPLACE_CONTEXT_PREVIOUS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Txt Replace Context Previous'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48320053327154236)
,p_db_column_name=>'VIEW_HEADER_OLD'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'View Header Old'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48320161821154237)
,p_db_column_name=>'VIEW_SQL_OLD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'View Sql Old'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(48294507396512071)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'482946'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_TXT_REPLACE_CONTEXT:FK_TXT_REPLACE:DATUM:CONTEXT:CONTEXT_TYPE:L_FROM_TXT:L_TO_TXT:SUCHEN:ERSETZEN:FK_TXT_REPLACE_CONTEXT_PREVIOUS:VIEW_HEADER_OLD:VIEW_SQL_OLD'
,p_sort_column_1=>'PK_TXT_REPLACE_CONTEXT'
,p_sort_direction_1=>'DESC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(48211936527752212)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(47494371775610010)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with txt_ as (select * from  user_views  where view_name =substr(:P4_context,1,instr(:P4_context,''('')-2)),',
'col_ as (',
'select table_name, listagg(column_name,'','') lg',
'from',
'  user_tab_cols utc',
'  join txt_ ',
'  on utc.table_name = txt_.view_name  ',
'  group by table_name',
'   )',
'select ''create or replace view '' || view_name || '' ('' || lg ||'') as'' d',
' from col_',
' left join txt_ on col_.table_name = txt_.view_name'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(48212087285752213)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4:P4_PK_TXT_REPLACE_CONTEXT:#PK_TXT_REPLACE_CONTEXT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>48212087285752213
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48318648100154222)
,p_db_column_name=>'D'
,p_display_order=>60
,p_column_identifier=>'CU'
,p_column_label=>'D'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(48347517151155935)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'483476'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TEXT_VC_LENGTH:OID_TEXT_OWNER:D'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(93669775815433497)
,p_plug_name=>'Text_Replaced'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(47495434063610012)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_TXT_REPLACE_CONTEXT'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47777424934146730)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'get_new_from_txt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Get New From Txt'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(48318724077154223)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'get_new_from_txt_view'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Get New From Txt View'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(48320338116154239)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'get_new_from_txt_view_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Get New From Txt View'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47774854280146704)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'open_txt_replace'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Open Txt Replace'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP:P11_PK_TXT_REPLACE:&P4_PK_TXT_REPLACED.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47603794063633428)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P4_PK_TXT_REPLACE_CONTEXT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47604544575633428)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:437:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47604157409633428)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P4_PK_TXT_REPLACE_CONTEXT'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(47603310934633428)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P4_PK_TXT_REPLACE_CONTEXT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(48302173648688712)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(93669775815433497)
,p_button_name=>'Replace'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(47551582506610071)
,p_button_image_alt=>'Replace'
,p_button_position=>'TOP'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(47777380400146729)
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP:P4_PK_TXT_REPLACE_CONTEXT:&P4_PK_TXT_REPLACE_CONTEXT.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47775207403146708)
,p_name=>'P4_CONTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Context'
,p_source=>'CONTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ut.table_name || '' (Table) - '' || uo.status d , ut.table_name || '' (Table)'' r',
'from user_tables ut',
'  left join user_objects uo on ut.table_name = uo.object_name',
'union',
'select uv.view_name || '' (View) - '' || uo.status d, uv.view_name || '' (View)'' r',
'from user_views uv',
'   left join user_objects uo on uv.view_name = uo.object_name',
'union',
'select up.object_name || ''.'' || up.procedure_name || '' ('' || up.object_type || '') - '' || uo.status d, up.object_name || ''.'' || up.procedure_name || '' ('' || up.object_type || '')'' r',
'from user_procedures up',
'   left join user_objects uo on up.procedure_name = uo.object_name',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47775455760146710)
,p_name=>'P4_FK_TXT_REPLACE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk Txt Replace'
,p_source=>'FK_TXT_REPLACE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''from: '' || suchen || '' // to: '' || ersetzen || '' ('' || pk_txt_replace || '')'', pk_txt_replace',
'from t_txt_replace'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47775544966146711)
,p_name=>'P4_FROM_TXT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'From Txt'
,p_source=>'select substr(from_txt,1,4000) from t_txt_replace_context where pk_txt_replace_context = :P4_pk_txt_replace_context'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47775625412146712)
,p_name=>'P4_TO_TXT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'To Txt'
,p_source=>'select substr(to_txt,1,4000) from t_txt_replace_context where pk_txt_replace_context = :P4_pk_txt_replace_context'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47775703090146713)
,p_name=>'P4_CONTEXT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Context Type'
,p_source=>'CONTEXT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Keine Angabe;0,Tabelle;1,View;2,Procedure_Package;3,Apex Report;4,Apex Item;5,Apex Process;6'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47777635055146732)
,p_name=>'P4_FK_TXT_REPLACE_CONTEXT_PREVIOUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk Txt Replace Context Previous'
,p_source=>'FK_TXT_REPLACE_CONTEXT_PREVIOUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(47779456480146750)
,p_name=>'P4_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Datum'
,p_source=>'DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48319278922154228)
,p_name=>'P4_PK_TXT_REPLACE_CONTEXT'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Pk Txt Replace Context'
,p_source=>'PK_TXT_REPLACE_CONTEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48319387577154229)
,p_name=>'P4_VIEW_HEADER_OLD'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'View Header Old'
,p_source=>'select substr(view_header_old,1,4000) from t_txt_replace_context'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48319591930154231)
,p_name=>'P4_VIEW_HEADER_NEW'
,p_source_data_type=>'CLOB'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'View Header New'
,p_source=>'VIEW_HEADER_NEW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48319842481154234)
,p_name=>'P4_VIEW_SQL_OLD'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'View Sql Old'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select substr(view_sql_old,1,4000) from t_txt_replace_context where ',
'pk_txt_replace_context = :P4_pk_txt_replace_context'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48319998350154235)
,p_name=>'P4_VIEW_SQL_NEW'
,p_source_data_type=>'CLOB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'View Sql New'
,p_source=>'VIEW_SQL_NEW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48512797063700403)
,p_name=>'P4_FK_APEX_APPLICATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk Apex Application'
,p_source=>'FK_APEX_APPLICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id d, application_id r',
'from apex_applications'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48512822394700404)
,p_name=>'P4_FK_APEX_PAGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk Apex Page'
,p_source=>'FK_APEX_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id || '' '' || page_id || '': '' || page_name d, Page_id r',
'from apex_application_pages'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48512970704700405)
,p_name=>'P4_COMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Comm'
,p_source=>'COMM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48513029245700406)
,p_name=>'P4_FK_APEX_WORKSPACE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk Apex Workspace'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select workspace d, workspace r',
'from apex_workspaces'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(48513164150700407)
,p_name=>'P4_FK_FROM_TXT1'
,p_source_data_type=>'CLOB'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(93669775815433497)
,p_item_source_plug_id=>wwv_flow_api.id(93669775815433497)
,p_prompt=>'Fk From Txt1'
,p_source=>'FROM_TXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(47550446954610065)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(47607683482633429)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(93669775815433497)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Text_Replaced'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(48302458418690687)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'replace'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' merge into t_txt_replace_context t1',
' using (',
'          select pk_txt_replace_context, replace(from_txt, suchen, ersetzen) rep',
'          from t_txt_replace_context txt_con',
'            join t_txt_replace txt on txt_con.fk_txt_replace = txt.pk_txt_replace',
'          where pk_txt_replace_context = :P4_pk_txt_replace_context',
'         ) t2 on (t1.pk_txt_replace_context = t2.pk_txt_replace_context)',
' when matched then ',
'  update set t1.to_txt = t2.rep;',
' commit;',
' ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(48302173648688712)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(47777533933146731)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_new_from_txt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'--from text aus bestehendem to_text auslesen',
' merge into t_txt_replace_context t1',
' using (',
'          select *',
'          from t_txt_replace_context txt_con',
'          where pk_txt_replace_context = :P4_pk_txt_replace_context',
'         ) t2 on (1=2)',
' when  not matched then ',
'  insert   (',
'    t1.from_txt,',
'      t1.context,',
'    t1.context_type,',
'',
'    t1.fk_txt_replace_context_previous,',
'      t1.fk_apex_workspace,',
'       t1.fk_apex_application,',
'      t1.fk_apex_page',
'     ',
'  )',
'  values (',
'      t2.to_txt,',
'      t2.context,',
'    t2.context_type,',
'',
'    t2.pk_txt_replace_context,',
'      t2.fk_apex_workspace,',
'       t2.fk_apex_application,',
'      t2.fk_apex_page',
'  );',
' commit;',
' ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(47777424934146730)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(48318891279154224)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_new_from_txt_view'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'--view header',
'merge into t_TXT_REPLACE_CONTEXT t1',
'using (',
'',
'with txt_ as (select * from  user_views  where view_name =substr(:P4_context,1,instr(:P4_context,''('')-2)),',
'col_ as (',
'select table_name, listagg(column_name,'','') lg',
'from',
'  user_tab_cols utc',
'  join txt_ ',
'  on utc.table_name = txt_.view_name  ',
'  group by table_name',
'   )',
'select ''create or replace view '' || view_name || '' ('' || lg ||'') as'' d , txt_.text',
' from col_',
' left join txt_ on col_.table_name = txt_.view_name',
') t2 on (:P4_PK_TXT_REPLACE_CONTEXT = t1.PK_TXT_REPLACE_CONTEXT)',
'when matched then ',
'update set',
't1.view_header_old = t2.d ',
';',
'',
'commit;',
'',
'--t_clob bereinigen',
'delete from t_clob where fk_txt_replace_context =  :P4_pk_txt_replace_context;',
'commit;',
'',
'--long Werte in T_clob speichern',
'    insert into t_clob (fld_clob, view_name1,datum, fk_txt_replace_context ) ',
'    select to_lob(text),substr(:P4_context,1,instr(:P4_context,''('')-2), sysdate ,:P4_pk_txt_replace_context from user_views where  view_name =substr(:P4_context,1,instr(:P4_context,''('')-2) ;',
'  commit;',
'  ',
unistr(' --hinzuf\00FCgen vom SQL'),
'  merge into t_txt_replace_context t1 ',
' using (',
' select *',
' from t_clob',
'     where fk_txt_replace_context = :P4_pk_txt_replace_context',
' ) t2 on (t1.pk_txt_replace_context = t2.fk_txt_replace_context)',
' when matched then',
' update set t1.view_sql_old = fld_clob;',
' commit;',
' ',
unistr(' --hinzuf\00FCgen zu from_txt'),
'update t_txt_replace_context set from_txt = view_header_old || '' '' || view_sql_old where pk_txt_replace_context = :P4_pk_txt_replace_context;',
'commit;',
' end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(48318724077154223)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1320940113457139
,p_default_application_id=>100
,p_default_id_offset=>6988393411891522
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(48320216008154238)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_new_from_txt_view_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'--view header',
'update t_txt_replace_context set view_header_old = ''create or replace view '' || substr(:P4_context,1,instr(:P4_context,''('')-2) || '' (''  where pk_txt_replace_context = :P4_pk_txt_replace_context;',
'commit;',
'',
'for i in (',
'',
'select table_name, grp, listagg(column_name,'','') within group (order by table_name, grp) lg from (select table_name, (rnr - mod(rnr,100))/100+1 grp, column_name from  (',
'select table_name,',
'column_name,row_number() over (partition by table_name order by table_name) rnr',
'from',
'  (select * from user_tab_cols where table_name =substr(:P4_context,1,instr(:P4_context,''('')-2))   utc ',
'  join user_views txt_ ',
'  on utc.table_name = txt_.view_name  ',
'',
'  ))  group by grp, table_name',
') loop',
'',
'update  t_txt_replace_context set view_header_old = view_header_old || i.lg where pk_txt_replace_context = :P4_pk_txt_replace_context;',
'commit;',
'',
'end loop;',
'',
'',
'update t_txt_replace_context set view_header_old =  view_header_old || '') as'' where pk_txt_replace_context = :P4_pk_txt_replace_context;',
'commit;',
'',
'',
'--t_clob bereinigen',
'delete from t_clob where fk_txt_replace_context =  :P4_pk_txt_replace_context;',
'commit;',
'',
'--long Werte in T_clob speichern',
'    insert into t_clob (fld_clob, view_name1,datum, fk_txt_replace_context ) ',
'    select to_lob(text),substr(:P4_context,1,instr(:P4_context,''('')-2), sysdate ,:P4_pk_txt_replace_context from user_views where  view_name =substr(:P4_context,1,instr(:P4_context,''('')-2) ;',
'  commit;',
'  ',
unistr(' --hinzuf\00FCgen vom SQL'),
'  merge into t_txt_replace_context t1 ',
' using (',
' select *',
' from t_clob',
'     where fk_txt_replace_context = :P4_pk_txt_replace_context',
' ) t2 on (t1.pk_txt_replace_context = t2.fk_txt_replace_context)',
' when matched then',
' update set t1.view_sql_old = fld_clob;',
' commit;',
' ',
unistr(' --hinzuf\00FCgen zu from_txt'),
'update t_txt_replace_context set from_txt = view_header_old || '' '' || view_sql_old where pk_txt_replace_context = :P4_pk_txt_replace_context;',
'commit;',
' end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(48320338116154239)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(47607210719633429)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(93669775815433497)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Text_Replaced'
);
wwv_flow_api.component_end;
end;
/
