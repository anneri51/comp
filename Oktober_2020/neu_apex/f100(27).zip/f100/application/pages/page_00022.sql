prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Belege'
,p_alias=>'BELEGE_22'
,p_step_title=>'Belege'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(42869453008316864)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201011071903'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(161927279601029)
,p_plug_name=>'Beleg aus Template erstellen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6408165230474145)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'APEX_item.checkbox(1,pk_bel_beleg) sel,',
'tb."PK_BEL_BELEG" ID, ',
'tb."FK_BAS_STEU_STEUER_SATZ" Steuersatz,',
'tb.FK_std_verw_VERWENDUNGSZWECK Verwendungszweck,',
'tb."FK_PROJ_PROJEKT" Projekt,',
'tb."FK_LEHR_LEHRGANG" Lehrgang,',
'tb."FK_WH_WAREN_BEWEGUNG" Einkauf,',
'tb."BELEG",',
'tb."BETRAG_BRUTTO",',
'tb."DATUM" dat_bel,',
'tb."VON",',
'tb."BIS",',
'tb."AZ_O_PAUSE",',
'tb."AZ_M_PAUSE",',
'tb."ANWESENHEITSZEIT",',
'tb."PARKZEIT",',
'tb."AZ_MANUELL_GEPFLEGT",',
'tb."KOMMENTAR",',
'tb."BETRAG_NETTO",',
'tb."MWST" Mwst,',
'tb."FK_IMP_BEL_NR" IMP_Belegnummer,',
'tb."FK_IMP_NO" Import_Nr,',
'tb."EXT_RENR",',
'tb."EXT_AUFTRAGSNR",',
'tb."EXT_LIEFERSCHEINNR",',
'tb."EXT_LEISTUNGSDATUM",',
'tb."EXT_RECHNUNGSDATUM",',
'tb."EXT_AUFTRAGSDATUM",',
'tb.FK_STD_STEU_VORSTEUERRELEVANT Vorsteuerrelevant,',
'tb.FK_STD_STEU_VORSTEUERPFLEGE Vorsteuerpflege,',
'tb.FK_STD_RE_RECHNUNGSERSTELLUNG Rechnungserstellung,',
'tb.FK_STD_KTO_BANKBELEG,',
'tb.fk_main_beleg,',
'tb.fk_std_bel_fehlend,',
'BELEGART,',
'ta.DATUM dat_arb,',
'ta.FK_std_kal_WOCHENENDE,',
'ta.FK_std_kal_FEIERTAG,',
'ta.FEIERTAG,',
'ta.TAG,',
'ta.MONAT beleg_monat,',
'ta.JAHR beleg_jahr,',
'ta.wochentag,',
'tcnt.cnt ,',
'tg.lg,',
'tstdz.pk_inp_belege_all,',
'tstdz.bezeichnung,',
'tstdz.monat stundenzettel_monat,',
'tstdz.jahr stundenzettel_jahr',
'from "T_BEL_BELEG" tb',
'left join t_bas_bel_belegart tba on tb.fk_bas_bel_belegart = tba.pk_bas_bel_belegart',
'left join t_bas_kal_arbeitstage ta on tb.fk_bas_kal_arbeitstag = ta.pk_bas_kal_arbeitstage',
'left join t_rel_proj_stundenzettel_beleg trstdzb on trstdzb.fk_bel_beleg = tb.pk_bel_beleg',
'left join t_inp_belege_all tstdz on tstdz.pk_inp_belege_all = trstdzb.fk_proj_stundenzettel',
'left join (select fk_main_beleg, count(*) cnt from t_bel_beleg group by fk_main_beleg)  tcnt on tcnt.fk_main_beleg = tb.pk_bel_beleg',
'left join (select fk_main_beleg, listagg(nvl(belegart,''Keine Angabe'') || '' ('' || cntd, '') | '') within group (order by fk_main_beleg) || '')'' as lg',
'from (',
'select fk_main_beleg, belegart, count(*) cntd',
'from t_bel_beleg tbel',
' left join t_bas_bel_belegart tbela on tbel.fk_bas_bel_belegart = tbela.pk_bas_bel_belegart',
'group by fk_main_beleg, belegart',
')',
'group by fk_main_beleg) tg on tg.fk_main_beleg = tb.pk_bel_beleg'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6408591985474149)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_csv_output_separator=>';'
,p_detail_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::P23_PK_BELEG,P23_CH_FLAG:#ID#,0'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>6408591985474149
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6411706456474227)
,p_db_column_name=>'BELEG'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Beleg'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6412131994474228)
,p_db_column_name=>'BETRAG_BRUTTO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Betrag Brutto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6412976963474232)
,p_db_column_name=>'VON'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6413365693474233)
,p_db_column_name=>'BIS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD.MM.YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6413779680474234)
,p_db_column_name=>'AZ_O_PAUSE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'AZ ohne Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6414135360474235)
,p_db_column_name=>'AZ_M_PAUSE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'AZ mit Pause'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6414530732474236)
,p_db_column_name=>'ANWESENHEITSZEIT'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Anwesenheitszeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6414935841474238)
,p_db_column_name=>'PARKZEIT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Parkzeit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6415335773474238)
,p_db_column_name=>'AZ_MANUELL_GEPFLEGT'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Az Manuell Gepflegt'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6415792047474239)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6416143727474240)
,p_db_column_name=>'BETRAG_NETTO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Betrag Netto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6417724440474242)
,p_db_column_name=>'EXT_RENR'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Ext Renr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6418106324474243)
,p_db_column_name=>'EXT_AUFTRAGSNR'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Ext Auftragsnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6418586584474244)
,p_db_column_name=>'EXT_LIEFERSCHEINNR'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Ext Lieferscheinnr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6418955041474244)
,p_db_column_name=>'EXT_LEISTUNGSDATUM'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Ext Leistungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6419380191474245)
,p_db_column_name=>'EXT_RECHNUNGSDATUM'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Ext Rechnungsdatum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6700762893567142)
,p_db_column_name=>'EXT_AUFTRAGSDATUM'
,p_display_order=>78
,p_column_identifier=>'AH'
,p_column_label=>'Ext auftragsdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437094299436417)
,p_db_column_name=>'ID'
,p_display_order=>108
,p_column_identifier=>'AK'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437100711436418)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>118
,p_column_identifier=>'AL'
,p_column_label=>'Steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437353996436420)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>138
,p_column_identifier=>'AN'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437583917436422)
,p_db_column_name=>'PROJEKT'
,p_display_order=>158
,p_column_identifier=>'AP'
,p_column_label=>'Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437685373436423)
,p_db_column_name=>'LEHRGANG'
,p_display_order=>168
,p_column_identifier=>'AQ'
,p_column_label=>'Lehrgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437773130436424)
,p_db_column_name=>'EINKAUF'
,p_display_order=>178
,p_column_identifier=>'AR'
,p_column_label=>'Einkauf'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437890210436425)
,p_db_column_name=>'IMP_BELEGNUMMER'
,p_display_order=>188
,p_column_identifier=>'AS'
,p_column_label=>'Imp belegnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5437921458436426)
,p_db_column_name=>'IMPORT_NR'
,p_display_order=>198
,p_column_identifier=>'AT'
,p_column_label=>'Import nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5438067490436427)
,p_db_column_name=>'VORSTEUERRELEVANT'
,p_display_order=>208
,p_column_identifier=>'AU'
,p_column_label=>'Vorsteuerrelevant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5438121852436428)
,p_db_column_name=>'VORSTEUERPFLEGE'
,p_display_order=>218
,p_column_identifier=>'AV'
,p_column_label=>'Vorsteuerpflege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5438299172436429)
,p_db_column_name=>'RECHNUNGSERSTELLUNG'
,p_display_order=>228
,p_column_identifier=>'AW'
,p_column_label=>'Rechnungserstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5438339790436430)
,p_db_column_name=>'MWST'
,p_display_order=>238
,p_column_identifier=>'AX'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3870597212984479)
,p_db_column_name=>'BELEGART'
,p_display_order=>248
,p_column_identifier=>'AY'
,p_column_label=>'Belegart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3870116605984474)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>298
,p_column_identifier=>'BD'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3869940223984473)
,p_db_column_name=>'TAG'
,p_display_order=>308
,p_column_identifier=>'BE'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(115201052374980)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>338
,p_column_identifier=>'BH'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(549028481059607)
,p_db_column_name=>'SEL'
,p_display_order=>348
,p_column_identifier=>'BI'
,p_column_label=>'<input type="checkbox" id="selectunselectall">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(549646826059613)
,p_db_column_name=>'DAT_BEL'
,p_display_order=>358
,p_column_identifier=>'BJ'
,p_column_label=>'Dat bel'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(549726291059614)
,p_db_column_name=>'DAT_ARB'
,p_display_order=>368
,p_column_identifier=>'BK'
,p_column_label=>'Dat arb'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(681096151355206)
,p_db_column_name=>'CNT'
,p_display_order=>378
,p_column_identifier=>'BL'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(681167443355207)
,p_db_column_name=>'LG'
,p_display_order=>388
,p_column_identifier=>'BM'
,p_column_label=>'Lg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(861198332399181)
,p_db_column_name=>'BELEG_MONAT'
,p_display_order=>398
,p_column_identifier=>'BN'
,p_column_label=>'Beleg monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(861270499399182)
,p_db_column_name=>'BELEG_JAHR'
,p_display_order=>408
,p_column_identifier=>'BO'
,p_column_label=>'Beleg jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(861608019399185)
,p_db_column_name=>'STUNDENZETTEL_MONAT'
,p_display_order=>438
,p_column_identifier=>'BR'
,p_column_label=>'Stundenzettel monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(861685163399186)
,p_db_column_name=>'STUNDENZETTEL_JAHR'
,p_display_order=>448
,p_column_identifier=>'BS'
,p_column_label=>'Stundenzettel jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1031761224191680)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>468
,p_column_identifier=>'BU'
,p_column_label=>'Fk main beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880350593762702)
,p_db_column_name=>'FK_STD_KTO_BANKBELEG'
,p_display_order=>478
,p_column_identifier=>'BW'
,p_column_label=>'Fk Std Kto Bankbeleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880403589762703)
,p_db_column_name=>'FK_STD_BEL_FEHLEND'
,p_display_order=>488
,p_column_identifier=>'BX'
,p_column_label=>'Fk Std Bel Fehlend'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880545951762704)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>498
,p_column_identifier=>'BY'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(46880662916762705)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>508
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21603878086589504)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>518
,p_column_identifier=>'CB'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21603950003589505)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>528
,p_column_identifier=>'CC'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6483858815684246)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'64839'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_view_mode=>'REPORT'
,p_report_columns=>'ID:SEL:CNT:TAG:WOCHENTAG:FEIERTAG:PROJEKT:BELEGART:BELEG:BETRAG_NETTO:MWST:BETRAG_BRUTTO:VON:BIS:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:PARKZEIT:AZ_MANUELL_GEPFLEGT:EXT_RENR:EXT_AUFTRAGSNR:EXT_LIEFERSCHEINNR:EXT_LEISTUNGSDATUM:EXT_RECHNUNGSDATUM:STEU'
||'ERSATZ:VERWENDUNGSZWECK:LEHRGANG:EINKAUF:IMP_BELEGNUMMER:IMPORT_NR:VORSTEUERRELEVANT:VORSTEUERPFLEGE:RECHNUNGSERSTELLUNG:EXT_AUFTRAGSDATUM:KOMMENTAR:DAT_BEL:DAT_ARB:LG:BELEG_MONAT:BELEG_JAHR:STUNDENZETTEL_MONAT:STUNDENZETTEL_JAHR::FK_MAIN_BELEG:FK_ST'
||'D_KTO_BANKBELEG:FK_STD_BEL_FEHLEND:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:PK_INP_BELEGE_ALL:BEZEICHNUNG'
,p_sort_column_1=>'TAG'
,p_sort_direction_1=>'ASC'
,p_break_on=>'TAG:WOCHENTAG'
,p_break_enabled_on=>'TAG:WOCHENTAG'
,p_chart_type=>'pie'
,p_chart_label_column=>'TAG'
,p_chart_label_title=>'datum'
,p_chart_value_column=>'VERWENDUNGSZWECK'
,p_chart_aggregate=>'COUNT'
,p_chart_value_title=>'anzahl'
,p_chart_sorting=>'LABEL_ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47094332596332622)
,p_report_id=>wwv_flow_api.id(6483858815684246)
,p_name=>'Vorsteuerrelevant'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_BELEG'
,p_operator=>'!='
,p_expr=>'4976'
,p_condition_sql=>' (case when ("FK_MAIN_BELEG" != to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# != #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#AFD6FA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47093923622332620)
,p_report_id=>wwv_flow_api.id(6483858815684246)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEG_MONAT'
,p_operator=>'='
,p_expr=>'8'
,p_condition_sql=>'"BELEG_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1054720331802090)
,p_application_user=>'ANNE'
,p_name=>'chart1'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_display_rows=>1000
,p_view_mode=>'REPORT'
,p_report_columns=>'ID:SEL:CNT:TAG:WOCHENTAG:FEIERTAG:PROJEKT:BELEGART:BELEG:BETRAG_NETTO:MWST:BETRAG_BRUTTO:VON:BIS:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:PARKZEIT:AZ_MANUELL_GEPFLEGT:EXT_RENR:EXT_AUFTRAGSNR:EXT_LIEFERSCHEINNR:EXT_LEISTUNGSDATUM:EXT_RECHNUNGSDATUM:STEU'
||'ERSATZ:VERWENDUNGSZWECK:LEHRGANG:EINKAUF:IMP_BELEGNUMMER:IMPORT_NR:VORSTEUERRELEVANT:VORSTEUERPFLEGE:RECHNUNGSERSTELLUNG:EXT_AUFTRAGSDATUM:KOMMENTAR:DAT_BEL:DAT_ARB:LG:BELEG_MONAT:BELEG_JAHR:STUNDENZETTEL_MONAT:STUNDENZETTEL_JAHR::FK_MAIN_BELEG'
,p_sort_column_1=>'TAG'
,p_sort_direction_1=>'ASC'
,p_chart_type=>'pie'
,p_chart_label_column=>'TAG'
,p_chart_label_title=>'datum'
,p_chart_value_column=>'VERWENDUNGSZWECK'
,p_chart_aggregate=>'COUNT'
,p_chart_value_title=>'anzahl'
,p_chart_sorting=>'LABEL_ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1054845781802091)
,p_report_id=>wwv_flow_api.id(1054720331802090)
,p_name=>'Wochenende'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_WOCHENENDE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_WOCHENENDE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D6D6D6'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1058145029234553)
,p_application_user=>'ANNE'
,p_name=>'monat'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_display_rows=>1000
,p_view_mode=>'REPORT'
,p_report_columns=>'ID:SEL:CNT:TAG:WOCHENTAG:FEIERTAG:PROJEKT:BELEGART:BELEG:BETRAG_NETTO:MWST:BETRAG_BRUTTO:VON:BIS:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:PARKZEIT:AZ_MANUELL_GEPFLEGT:EXT_RENR:EXT_AUFTRAGSNR:EXT_LIEFERSCHEINNR:EXT_LEISTUNGSDATUM:EXT_RECHNUNGSDATUM:STEU'
||'ERSATZ:VERWENDUNGSZWECK:LEHRGANG:EINKAUF:IMP_BELEGNUMMER:IMPORT_NR:VORSTEUERRELEVANT:VORSTEUERPFLEGE:RECHNUNGSERSTELLUNG:EXT_AUFTRAGSDATUM:KOMMENTAR:DAT_BEL:DAT_ARB:LG:BELEG_MONAT:BELEG_JAHR:STUNDENZETTEL_MONAT:STUNDENZETTEL_JAHR::FK_MAIN_BELEG'
,p_sort_column_1=>'TAG'
,p_sort_direction_1=>'ASC'
,p_chart_type=>'pie'
,p_chart_label_column=>'TAG'
,p_chart_label_title=>'datum'
,p_chart_value_column=>'VERWENDUNGSZWECK'
,p_chart_aggregate=>'COUNT'
,p_chart_value_title=>'anzahl'
,p_chart_sorting=>'LABEL_ASC'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1058268443234553)
,p_report_id=>wwv_flow_api.id(1058145029234553)
,p_name=>'Wochenende'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_WOCHENENDE'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_WOCHENENDE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D6D6D6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(1058211205234553)
,p_report_id=>wwv_flow_api.id(1058145029234553)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BELEG_MONAT'
,p_operator=>'='
,p_expr=>'8'
,p_condition_sql=>'"BELEG_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6518137102112926)
,p_plug_name=>'Belegart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>2
,p_plug_grid_column_css_classes=>'width="50"'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as status, ',
'       level, ',
'       "BELEGART" as title, ',
'       null as icon, ',
'       "CHILD" as value, ',
'       null as tooltip, ',
'       null as link ',
'from "#OWNER#"."V_BEL_BELEG"',
'start with "PARENT" = ''A0''',
'connect by prior "CHILD" = "PARENT"',
'order siblings by "BELEGART"'))
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'S'
,p_attribute_04=>'N'
,p_attribute_08=>'a-Icon'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_15=>'STATUS'
,p_attribute_23=>'LEVEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7854190343987844)
,p_plug_name=>'Belege'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7837564520987810)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7854242670987844)
,p_plug_name=>'BUENDELUNG'
,p_parent_plug_id=>wwv_flow_api.id(7854190343987844)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(258961063378680)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(161927279601029)
,p_button_name=>'CREATE_FROM_TEMP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Beleg aus Template erzeugen'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(549152998059608)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(161927279601029)
,p_button_name=>'ADD_BELEGART'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Belegart zuweisen'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7855995763987845)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7854190343987844)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7856245341987845)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7854190343987844)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7856120306987845)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7854190343987844)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6420147817474246)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6408165230474145)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_CH_FLAG:0'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7857622993987845)
,p_branch_action=>'f?p=&APP_ID.:23:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7856245341987845)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7856916340987845)
,p_branch_action=>'f?p=&APP_ID.:21:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7856120306987845)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(258965448378681)
,p_name=>'P22_SEL_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(161927279601029)
,p_prompt=>'Datum'
,p_format_mask=>'DD.MM.YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259121633378682)
,p_name=>'P22_SEL_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(161927279601029)
,p_prompt=>'Belegart'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select belegart, pk_bas_bel_belegart',
'from t_bas_bel_belegart'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7855675382987844)
,p_name=>'P22_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7854242670987844)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259419386378685)
,p_name=>'Create From Template'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(258961063378680)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259651545378687)
,p_event_id=>wwv_flow_api.id(259419386378685)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'insert into t_beleg',
'(fk_belegart ,',
'fk_arbeitstag,',
'fk_verwendungszweck,',
'beleg,',
'fk_projekt,',
'',
'fk_lehrgang,',
'fk_einkauf,',
'datum,',
'AZ_MANUELL_GEPFLEGT,',
'FK_offen,',
'',
'fk_vorsteuerrelevant,',
'fk_vorsteuerpflege,',
'fk_rechnungserstellung,',
'fk_rechnung_erstellt,',
'fk_bankbeleg)',
'',
'select',
'',
'',
'fk_belegart ,',
'(select pk_arbeitstage from t_arbeitstage where to_char(trunc(Datum),''DD.MM.YYYY'') = :P22_SEL_DATE),',
'fk_verwendungszweck,',
'beleg,',
'fk_projekt,',
'',
'fk_lehrgang,',
'fk_einkauf,',
'to_date(:P22_SEL_DATE,''DD.MM.YYYY''),',
'AZ_MANUELL_GEPFLEGT,',
'FK_offen,',
'',
'fk_vorsteuerrelevant,',
'fk_vorsteuerpflege,',
'fk_rechnungserstellung,',
'fk_rechnung_erstellt,',
'fk_bankbeleg',
'from t_temp_beleg',
'where fk_belegart = :P22_SEL_TYPE;',
'commit;',
'end;'))
,p_attribute_02=>'P22_SEL_DATE,P22_SEL_TYPE'
,p_attribute_03=>'P22_SEL_DATE,P22_SEL_TYPE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(549823130059615)
,p_event_id=>wwv_flow_api.id(259419386378685)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(549224561059609)
,p_name=>'ADD_Belegart'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(549152998059608)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(549309095059610)
,p_event_id=>wwv_flow_api.id(549224561059609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P22_SEL_TYPE'
,p_attribute_03=>'P22_SEL_TYPE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(549423318059611)
,p_event_id=>wwv_flow_api.id(549224561059609)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
' v_nr number;',
'',
'begin',
'',
'v_nr := Apex_application.g_f01.count;',
'',
'insert into test (',
'col1',
') values ( v_nr',
'); commit;',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'    merge into t_beleg t1',
'      using (',
'         select :P22_SEL_TYPE fk_belegart,',
'          apex_application.g_f01(i) pk_beleg',
'          from dual',
'      ) t2 on (t1.pk_beleg = t2.pk_beleg)',
'      ',
'      when matched then ',
'        update set t1.fk_belegart = t2.fk_belegart;',
'       commit;',
' ',
' ',
' end loop;',
'',
'',
'end;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(549494510059612)
,p_event_id=>wwv_flow_api.id(549224561059609)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(259685115378688)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_PAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P22_SEL_DATE := null;',
':P22_SEL_TYPE := null;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
