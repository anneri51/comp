prompt --application/pages/page_00073
begin
--   Manifest
--     PAGE: 00073
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>73
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Artikeltyp'
,p_alias=>'ARTIKELTYP_73'
,p_step_title=>'Artikeltyp'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201001161920'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1032543652191688)
,p_plug_name=>unistr('Artikeltyp \00DCbersicht')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_grid_column_css_classes=>'width="300"'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as st, ',
'       level lev, ',
'       artikeltyp as title, ',
'       null as icon, ',
'       fk_bas_wh_art_artikeltyp_sub  as value, ',
'       null as tooltip, ',
'       null as link ',
'from t_rel_wh_artikeltyp_artikeltyp tartt',
'  left join t_bas_wh_art_artikeltyp tart on tart.pk_bas_wh_art_artikeltyp = tartt.fk_bas_wh_art_artikeltyp_sub',
'connect by fk_bas_wh_art_artikeltyp_main = prior  fk_bas_wh_art_artikeltyp_sub',
'start with fk_bas_wh_art_artikeltyp_main is null'))
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'S'
,p_attribute_04=>'N'
,p_attribute_08=>'a-Icon'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEV'
,p_attribute_15=>'ST'
,p_attribute_23=>'LEVEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1033519047191698)
,p_plug_name=>'TAB'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1032656385191689)
,p_plug_name=>'Artikeltypverbindung'
,p_parent_plug_id=>wwv_flow_api.id(1033519047191698)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tartt.*, tart_m.artikeltyp main, tart_s.artikeltyp sub',
'from t_rel_wh_artikeltyp_artikeltyp tartt ',
' left join t_bas_wh_art_artikeltyp tart_m on tart_m.pk_bas_wh_art_artikeltyp = tartt.fk_bas_wh_art_artikeltyp_main',
' left join t_bas_wh_art_artikeltyp tart_s on tart_s.pk_bas_wh_art_artikeltyp = tartt.fk_bas_wh_art_artikeltyp_sub'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1032746894191690)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:RP:P75_PK_REL_WH_ARTIKELTYP_ARTIKELTYP:#PK_REL_WH_ARTIKELTYP_ARTIKELTYP##PK_REL_ARTT_ARTT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>10342882134612611
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033076638191694)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033179519191695)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033336549191696)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033447738191697)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033624434191699)
,p_db_column_name=>'MAIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1033688849191700)
,p_db_column_name=>'SUB'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Sub'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47809587551542176)
,p_db_column_name=>'PK_REL_WH_ARTIKELTYP_ARTIKELTYP'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pk Rel Wh Artikeltyp Artikeltyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47809757999542177)
,p_db_column_name=>'FK_BAS_WH_ART_ARTIKELTYP_MAIN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk Bas Wh Art Artikeltyp Main'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47809822067542178)
,p_db_column_name=>'FK_BAS_WH_ART_ARTIKELTYP_SUB'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fk Bas Wh Art Artikeltyp Sub'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1230123791317024)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'105403'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MAIN:SUB:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT::PK_REL_WH_ARTIKELTYP_ARTIKELTYP:FK_BAS_WH_ART_ARTIKELTYP_MAIN:FK_BAS_WH_ART_ARTIKELTYP_SUB'
,p_break_on=>'FK_ARTIKELTYP_MAIN:MAIN:0:0:0:0'
,p_break_enabled_on=>'FK_ARTIKELTYP_MAIN:MAIN:0:0:0:0'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1214239704912867)
,p_plug_name=>'Artikeltyp'
,p_parent_plug_id=>wwv_flow_api.id(1033519047191698)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_BAS_WH_ART_ARTIKELTYP", ',
'"ARTIKELTYP",',
'"FK_BAS_WH_ART_ARTIKELHAUPTTYP",',
'"CREATED_BY",',
'"CREATED_AT",',
'"MODIFIED_BY",',
'"MODIFIED_AT"',
'from "#OWNER#"."T_BAS_WH_ART_ARTIKELTYP" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(1214596694912867)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.::P74_PK_BAS_WH_ART_ARTIKELTYP:#PK_BAS_WH_ART_ARTIKELTYP##PK_ARTIKELTYP#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>10524731935333788
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1215127231912873)
,p_db_column_name=>'ARTIKELTYP'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Artikeltyp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1215920803912875)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1216350312912875)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1216665484912876)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(1217142832912877)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47809912084542179)
,p_db_column_name=>'PK_BAS_WH_ART_ARTIKELTYP'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Pk Bas Wh Art Artikeltyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47809989467542180)
,p_db_column_name=>'FK_BAS_WH_ART_ARTIKELHAUPTTYP'
,p_display_order=>27
,p_column_identifier=>'I'
,p_column_label=>'Fk Bas Wh Art Artikelhaupttyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(1219340145913394)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'105295'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ARTIKELTYP:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:PK_BAS_WH_ART_ARTIKELTYP:FK_BAS_WH_ART_ARTIKELHAUPTTYP'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8090476038039418)
,p_plug_name=>'Step 8'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8061285448039393)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8090558165039418)
,p_plug_name=>'Step 8'
,p_parent_plug_id=>wwv_flow_api.id(8090476038039418)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8092275202039419)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8090476038039418)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8092574147039419)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8090476038039418)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8092493946039419)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8090476038039418)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1217512340912877)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1214239704912867)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:74:P74_PK_BAS_WH_ART_ARTIKELTYP:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1033911979191702)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1032656385191689)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'TOP_AND_BOTTOM'
,p_button_redirect_url=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:RP:P75_PK_REL_WH_ARTIKELTYP_ARTIKELTYP,P75_FK_BAS_WH_ART_ARTIKELTYP_MAIN,P75_FK_BAS_WH_ART_ARTIKELTYP_SUB:&P75_PK_REL_WH_ARTIKELTYP_ARTIKELTYP.,&P75_FK_BAS_WH_ART_ARTIKELTYP_MAIN.,&P75_FK_BAS_WH_ART_ARTIKELTYP_SUB.'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8093956782039419)
,p_branch_action=>'f?p=&APP_ID.:74:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8092574147039419)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8093259262039419)
,p_branch_action=>'f?p=&APP_ID.:72:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8092493946039419)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8091962689039418)
,p_name=>'P73_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8090558165039418)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
