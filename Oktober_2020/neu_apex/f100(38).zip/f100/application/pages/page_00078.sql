prompt --application/pages/page_00078
begin
--   Manifest
--     PAGE: 00078
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>78
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Route'
,p_alias=>'ROUTE_78'
,p_step_title=>'Route'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <meta name="viewport" content="initial-scale=1.0, width=device-width" />',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-core.js"',
'  type="text/javascript" charset="utf-8"></script>',
'  <script src="http://js.api.here.com/v3/3.0/mapsjs-service.js"',
'  type="text/javascript" charset="utf-8"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-ui.js"></script>',
'	  <script type ="text/javascript" src="https://js.api.here.com/v3/3.0/mapsjs-mapevents.js"></script>'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var v_ctr_lat = document.getElementById(''P78_CTR_LAT'').value;',
'var v_ctr_lng = document.getElementById(''P78_CTR_LNG'').value;',
'',
'var v_wp0_str =''geo!55.1120423728813,8.68340740740811'';',
'var v_wp1_str =''geo!57.5309916298853,13.3846220493377'';',
'var v_wp2_str =''geo!58.5309916298853,13.3846220493377'';',
'',
'var v_lat1 = 57.0309916298853;',
'var v_lng1 = 13.384622049337;',
'',
'',
'// Instantiate a map and platform object:',
'var platform = new H.service.Platform({',
'  ''app_id'': ''hU8C4hi5HZZAA29CN1h5'',',
'  ''app_code'': ''no8qak0DOkDF8O_oi1xqaw''',
'});',
'',
'',
'',
'// Retrieve the target element for the map:',
'var targetElement = document.getElementById(''mapContainer'');',
'',
'// Get the default map types from the platform object:',
'var defaultLayers = platform.createDefaultLayers();',
'',
'// Instantiate the map:',
'var map = new H.Map(',
'  document.getElementById(''mapContainer''),',
'  defaultLayers.normal.map,',
'  {',
'  zoom: 8,',
'  center: { lat:  v_ctr_lat, lng: v_ctr_lng }',
'  });',
'',
'',
'',
'// Create the parameters for the routing request:',
'var routingParameters = {',
'  // The routing mode:',
'  ''mode'': ''fastest;car'',',
'  // The start point of the route:',
'   ''waypoint0'': v_wp0_str,',
'  // The end point of the route:',
'  ''waypoint1'':  v_wp1_str,',
'      ',
'  // To retrieve the shape of the route we choose the route',
'  // representation mode ''display''',
'  ''representation'': ''display''',
'};',
'',
'var routingParameters1 = {',
'  // The routing mode:',
'  ''mode'': ''fastest;car'',',
'  // The start point of the route:',
'   ''waypoint0'': v_wp1_str,',
'  // The end point of the route:',
'  ''waypoint1'':  v_wp2_str,',
'  // To retrieve the shape of the route we choose the route',
'  // representation mode ''display''',
'  ''representation'': ''display''',
'};',
'',
'',
'',
'// Define a callback function to process the routing response:',
'var onResult = function(result) {',
'  var route,',
'    routeShape,',
'    startPoint,',
'    endPoint,',
'    linestring;',
'  if(result.response.route) {',
'  // Pick the first route from the response:',
'  route = result.response.route[0];',
'  // Pick the route''s shape:',
'  routeShape = route.shape;',
'      ',
'',
'',
'  // Create a linestring to use as a point source for the route line',
'  linestring = new H.geo.LineString();',
'',
'',
'  // Push all the points in the shape into the linestring:',
'  routeShape.forEach(function(point) {',
'    var parts = point.split('','');',
'    linestring.pushLatLngAlt(parts[0], parts[1]);',
'  });',
'',
'      ',
'    ',
'      ',
'  // Retrieve the mapped positions of the requested waypoints:',
'  startPoint = route.waypoint[0].mappedPosition;',
'  endPoint = route.waypoint[1].mappedPosition;',
'',
'      ',
'',
'',
'  // Create a polyline to display the route:',
'  var routeLine = new H.map.Polyline(linestring, {',
'    style: { strokeColor: ''blue'', lineWidth: 10 }',
'  });',
'',
'  // Create a marker for the start point:',
'  var startMarker = new H.map.Marker({',
'    lat: startPoint.latitude,',
'    lng: startPoint.longitude',
'  });',
'',
'  // Create a marker for the end point:',
'  var endMarker = new H.map.Marker({',
'    lat: endPoint.latitude,',
'    lng: endPoint.longitude',
'  });',
'      ',
'',
'',
'  // Add the route polyline and the two markers to the map:',
'  map.addObjects([routeLine, startMarker, endMarker]);',
'',
'  // Set the map''s viewport to make the whole route visible:',
'  map.setViewBounds(routeLine.getBounds());',
'  }',
'};',
'',
'',
'// Get an instance of the routing service:',
'var router = platform.getRoutingService();',
'',
'// Call calculateRoute() with the routing parameters,',
'// the callback and an error callback function (called if a',
'// communication error occurs):',
'router.calculateRoute(routingParameters, onResult,',
'  function(error) {',
'    alert(error.message);',
'  });',
'',
'for (var i=1 ; i <=2; i++) {',
' test = show_marker(v_lat1, v_lng1+0.4*i, ''VB''+i);',
'',
'}',
'',
'function show_marker(v_lat, v_lng, v_text) {',
'var svgMarkup = ''<svg width="24" height="22" '' +',
'  ''xmlns="http://www.w3.org/2000/svg">'' +',
'  ''<rect stroke="white" fill="#1b468d" x="1" y="1" width="100" '' +',
'  ''height="22" /><text x="12" y="18" font-size="8pt" '' +',
'  ''font-family="Arial" font-weight="bold" text-anchor="middle" '' +',
'  ''fill="white">'' + v_text + ''</text></svg>'';',
'',
' ',
'',
'// Create an icon, an object holding the latitude and longitude, and a marker:',
'var icon = new H.map.Icon(svgMarkup),',
'  coords = {lat: v_lat , lng: v_lng},',
'  marker = new H.map.Marker(coords, {icon: icon});',
'',
'// Add the marker to the map and center the map at the location of the marker:',
'map.addObject(marker);',
'};',
'',
'',
'',
'  ',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201001162014'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8114060600214174)
,p_plug_name=>'Step 4'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8101658331214164)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8114112694214174)
,p_plug_name=>'Step 4'
,p_parent_plug_id=>wwv_flow_api.id(8114060600214174)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12428285597560715)
,p_plug_name=>'Route'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'width="50"'
,p_plug_display_point=>'BODY'
,p_plug_source=>' <div style="width: 640px; height: 480px" id="mapContainer">test2</div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'font-size:24px;'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8115844172214175)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8114060600214174)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8116165543214175)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8114060600214174)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8116043019214175)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8114060600214174)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8117530246214175)
,p_branch_action=>'f?p=&APP_ID.:79:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8116165543214175)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8116854824214175)
,p_branch_action=>'f?p=&APP_ID.:77:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8116043019214175)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1728792387268547)
,p_name=>'P78_CTR_LAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12428285597560715)
,p_prompt=>'Ctr lat'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1729084361268551)
,p_name=>'P78_CTR_LNG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12428285597560715)
,p_prompt=>'Ctr lng'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8115527395214175)
,p_name=>'P78_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8114112694214174)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1729483031268571)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :P78_CTR_LAT := 54.13;',
'  :P78_CTR_LNG := 10.13;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
