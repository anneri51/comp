prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>100
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'inp_belege_all_kategorisieren'
,p_alias=>'INP_BELEGE_ALL_KATEGORISIEREN9'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'inp_belege_all_kategorisieren'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201006182500'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8332307838927183)
,p_plug_name=>'Step 8'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8303117678927148)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8332439707927183)
,p_plug_name=>'Step 8'
,p_parent_plug_id=>wwv_flow_api.id(8332307838927183)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(59966043353744403)
,p_plug_name=>'inp_belege_all_kategorisieren'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(1,v_inp.pk_inp_belege_all) sel,',
'',
'inp.datum_buchung_ok, ',
'inp.fk_real_beleg_exist,',
'inp.dummy,',
'       v_inp.PK_INP_BELEGE_ALL,',
'        v_inp.fk_bas_std_status,',
'        v_inp.FK_LEX_BUCHUNG,',
'        v_inp.FK_bas_kat_KATEGORIE,',
'        v_inp.FK_bas_kal_ARBEITSTAG,',
'        v_inp.FK_kto_BUCHUNG,',
'        v_inp.FK_std_kto_ZAHLUNGSART,',
'        v_inp.FK_std_verw_VERWENDUNGSZWECK,',
'        v_inp.FK_inv_INVENTAR,',
'       v_inp.FK_proj_PROJEKT,',
'        nvl(v_inp.BELEGNUMMER,0) belegnummer,',
'        v_inp.BEZEICHNUNG,',
'        v_inp.FK_adr_LAND,',
'        v_inp.FK_adr_CITY,',
'        v_inp.BEL_DATUM,',
'        v_inp.beleg_uhrzeit,',
'        v_inp.VON,',
'        v_inp.BIS,',
'        v_inp.NETTO_BETRAG,',
'        v_inp.FK_bas_steu_STEUER_SATZ,',
'        v_inp.MWST_BETRAG,',
'        v_inp.BRUTTO_BETRAG,',
'        v_inp.FK_bas_mon_WAEHRUNG,',
'        v_inp.STEUERNUMMER,',
'        v_inp.FK_bas_mon_UMRECHNUNGSKURS,',
'        v_inp.COMM_REST_BELEG,',
'        v_inp.COMM_TEL_BELEG,',
'        v_inp.COMM_PRODUKTE,',
'        v_inp.COMM_BEGRUENDUNG,',
'        v_inp.COMM_SONSTIGES,',
'        v_inp.BELEG,',
'        v_inp.ZAHLUNGSBELEG,',
'        v_inp.LITER,',
'        v_inp.ZAPFSAEULE,',
'        v_inp.FK_loc_LOCATION,',
'        v_inp.PERSOENLICH_VOR_ORT,',
'       inp_bel_all_jahr,',
'       inp.fk_la_wdh,',
'       nvl(ll.habenkto,0) habenkto,',
'       ll.sollkto,',
'       v_inp.ort,',
'       v_inp.abl_ord_jahr,',
'       v_inp.ktokat_kategorie,',
'       v_inp.ABL_ORD_PK_ABL_ORDNER_PAGE,',
'       v_inp.ABL_ORD_PAGE_NUMBER,',
'       case when ll.status is not null then ''<span style="color:red">'' || ''<b>''  || nvl(rellex.pk_rel_lex_kto_bel,0) || ''</b>''|| ''</span>'' else '''' || nvl(rellex.pk_rel_lex_kto_bel,0)  end  pk_rel_lex_kto_bel,',
'        pk_rel_lex_kto_bel  pk_rel_lex_kto_bel_1,',
'       ll.belegnr ,',
'       arb.jahr,',
'       arb.monat,',
'       arb.tag,',
'       case when datum_ort_ok is not null or datum_addresse_ok is not null or datum_bussgeld_ok is not null or datum_beleg_pos_ok is not null or datum_buchung_ok is not null  or datum_verpfl_bel_ok is not null then 1 else 0 end flg_kontr_bel_ok',
'  from V_INP_BELEGE_ALL v_inp',
'   left join t_rel_lex_kto_bel rellex on v_inp.pk_inp_belege_all = rellex.fk_inp_belege_all',
'   left join t_inp_belege_all inp on v_inp.pk_inp_belege_all = inp.pk_inp_belege_all',
'   left join t_lex_long ll on ll.relation = rellex.fk_lex_relation',
'   left join t_bas_kal_arbeitstage arb on arb.pk_bas_kal_arbeitstage = inp.fk_bas_kal_arbeitstag'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(59966203778744403)
,p_name=>'inp_belege_all_kategorisieren'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>61406523054135943
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43012894350063616)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:RP:P229_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43013353513063616)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Lex Buchung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319__FK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#FK_LEX_BUCHUNG#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43016562775063617)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Bezeichnung'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BEZEICHNUNG#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43017691944063619)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43018165373063619)
,p_db_column_name=>'VON'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43018562593063619)
,p_db_column_name=>'BIS'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43018917149063619)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43019721614063620)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43020143034063620)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43020946176063620)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43021721819063622)
,p_db_column_name=>'LITER'
,p_display_order=>31
,p_column_identifier=>'AC'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43010120947063605)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>281
,p_column_identifier=>'JH'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43010578436063614)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>291
,p_column_identifier=>'JI'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43010884843063614)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>301
,p_column_identifier=>'JJ'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43011704376063614)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>321
,p_column_identifier=>'JL'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43012083827063614)
,p_db_column_name=>'BELEG'
,p_display_order=>331
,p_column_identifier=>'JM'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43012529288063616)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>341
,p_column_identifier=>'JN'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43023323420063622)
,p_db_column_name=>'SEL'
,p_display_order=>391
,p_column_identifier=>'JS'
,p_column_label=>'pk <input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f01]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43023739054063624)
,p_db_column_name=>'INP_BEL_ALL_JAHR'
,p_display_order=>401
,p_column_identifier=>'JT'
,p_column_label=>'Inp Bel All Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43024105545063624)
,p_db_column_name=>'HABENKTO'
,p_display_order=>411
,p_column_identifier=>'JU'
,p_column_label=>'Habenkto'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#HABENKTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43024544267063624)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>421
,p_column_identifier=>'JV'
,p_column_label=>'Sollkto'
,p_column_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP:P306_BELEGNR,P306_JAHR:#BELEGNR#,#JAHR#'
,p_column_linktext=>'#SOLLKTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43025303876063624)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>441
,p_column_identifier=>'JX'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'HH24:MI:SS'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43025757518063624)
,p_db_column_name=>'ORT'
,p_display_order=>451
,p_column_identifier=>'JY'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43026167683063625)
,p_db_column_name=>'FLG_KONTR_BEL_OK'
,p_display_order=>461
,p_column_identifier=>'JZ'
,p_column_label=>'Flg Kontr Bel Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43026570726063625)
,p_db_column_name=>'ABL_ORD_JAHR'
,p_display_order=>471
,p_column_identifier=>'KA'
,p_column_label=>'Abl Ord Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43026884443063625)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>481
,p_column_identifier=>'KB'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43027305161063627)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>491
,p_column_identifier=>'KD'
,p_column_label=>'Belegnummer'
,p_column_link=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:RP:P373_PK_INP_BELEGE_ALL,P373_PK_INP_BELEGE_ALL_1,P373_SRC_PK_INP_BELEGE_ALL,P373_ZIEL_PK_INP_BELEGE_ALL:,#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#BELEGNUMMER#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43027729337063627)
,p_db_column_name=>'JAHR'
,p_display_order=>501
,p_column_identifier=>'KE'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43028178310063627)
,p_db_column_name=>'MONAT'
,p_display_order=>511
,p_column_identifier=>'KF'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43028521709063627)
,p_db_column_name=>'TAG'
,p_display_order=>521
,p_column_identifier=>'KG'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43028958061063627)
,p_db_column_name=>'ABL_ORD_PK_ABL_ORDNER_PAGE'
,p_display_order=>531
,p_column_identifier=>'KH'
,p_column_label=>'Abl Ord Pk Abl Ordner Page'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43029281053063627)
,p_db_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_display_order=>541
,p_column_identifier=>'KI'
,p_column_label=>'Abl Ord Page Number'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43029712942063628)
,p_db_column_name=>'BELEGNR'
,p_display_order=>561
,p_column_identifier=>'KK'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43030178025063628)
,p_db_column_name=>'FK_REAL_BELEG_EXIST'
,p_display_order=>571
,p_column_identifier=>'KL'
,p_column_label=>'Fk Real Beleg Exist'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43030555974063628)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>581
,p_column_identifier=>'KM'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43030945283063628)
,p_db_column_name=>'FK_LA_WDH'
,p_display_order=>591
,p_column_identifier=>'KN'
,p_column_label=>'Fk La Wdh'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43031294441063628)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>601
,p_column_identifier=>'KO'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL,P252_FK_INP_BELEGE_ALL:#PK_REL_LEX_KTO_BEL_1#,#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43031694722063628)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL_1'
,p_display_order=>611
,p_column_identifier=>'KP'
,p_column_label=>'Pk Rel Lex Kto Bel 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43032115268063630)
,p_db_column_name=>'DUMMY'
,p_display_order=>621
,p_column_identifier=>'KQ'
,p_column_label=>'Dummy'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48286671572134904)
,p_db_column_name=>'FK_BAS_STD_STATUS'
,p_display_order=>631
,p_column_identifier=>'KR'
,p_column_label=>'Fk Bas Std Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48286721475134905)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>641
,p_column_identifier=>'KS'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48286879453134906)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>651
,p_column_identifier=>'KT'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48286884873134907)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>661
,p_column_identifier=>'KU'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48287110545134909)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>681
,p_column_identifier=>'KW'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48287203719134910)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>691
,p_column_identifier=>'KX'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360266854732861)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>701
,p_column_identifier=>'KY'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360365454732862)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>711
,p_column_identifier=>'KZ'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360386581732863)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>721
,p_column_identifier=>'LA'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360531242732864)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>731
,p_column_identifier=>'LB'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360673100732865)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>741
,p_column_identifier=>'LC'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360771388732866)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_display_order=>751
,p_column_identifier=>'LD'
,p_column_label=>'Fk Bas Mon Umrechnungskurs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360798007732867)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>761
,p_column_identifier=>'LE'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48360902073732868)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>771
,p_column_identifier=>'LF'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48361000385732869)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>781
,p_column_identifier=>'LG'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48361166954732870)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>791
,p_column_identifier=>'LH'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25667322670571649)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>801
,p_column_identifier=>'LI'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(60096215824810221)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'444728'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER:DUMMY:PK_REL_LEX_KTO_BEL:PK_INP_BELEGE_ALL:FK_REAL_BELEG_EXIST:DATUM_BUCHUNG_OK:BELEGNUMMER:SEL:HABENKTO:BEZEICHNUNG:BEL_DATUM:BELEG_UHRZEIT:VON:BIS:NETTO_BETRAG:MWST_BETRAG:BRUTTO_BETRAG:STEUERNUMMER:COMM_SONSTIGES:L'
||'ITER:COMM_PRODUKTE:COMM_REST_BELEG:COMM_TEL_BELEG:ZAHLUNGSBELEG:ORT:FLG_KONTR_BEL_OK:FK_LEX_BUCHUNG:SOLLKTO:JAHR:MONAT:TAG:ABL_ORD_PK_ABL_ORDNER_PAGE:BELEGNR:FK_LA_WDH:BELEG:INP_BEL_ALL_JAHR:KTOKAT_KATEGORIE:PK_REL_LEX_KTO_BEL_1::FK_BAS_STD_STATUS:FK'
||'_BAS_KAT_KATEGORIE:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:FK_BAS_MON_UMRECHNUNGSKURS:COMM_BEGRUENDUNG:ZAPFSAEULE:FK_LOC_LOC'
||'ATION:PERSOENLICH_VOR_ORT:FK_STD_KTO_ZAHLUNGSART'
,p_sort_column_1=>'BEZEICHNUNG'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'FK_STATUS'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PK_INP_BELEGE_ALL'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'FK_STATUS:PK_INP_BELEGE_ALL:0:0:0:0:ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER'
,p_break_enabled_on=>'0:0:0:0:ABL_ORD_JAHR:ABL_ORD_PAGE_NUMBER'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43034968181063636)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_name=>'Dummy'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DUMMY'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DUMMY" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43035755237063638)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_name=>'fk_status_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_STATUS'
,p_operator=>'='
,p_expr=>'3'
,p_condition_sql=>' (case when ("FK_STATUS" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43035346649063636)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_name=>'beleg_fehlt'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_REAL_BELEG_EXIST'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_REAL_BELEG_EXIST" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>15
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43034574728063636)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>16
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43032913922063635)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ABL_ORD_JAHR'
,p_operator=>'contains'
,p_expr=>'2020'
,p_condition_sql=>'upper("ABL_ORD_JAHR") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 2020  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43033377361063635)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ABL_ORD_PAGE_NUMBER'
,p_operator=>'='
,p_expr=>'15'
,p_condition_sql=>'"ABL_ORD_PAGE_NUMBER" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43033730801063635)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FLG_KONTR_BEL_OK'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FLG_KONTR_BEL_OK" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43034084754063636)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'MONAT'
,p_operator=>'='
,p_expr=>'3'
,p_condition_sql=>'"MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(43036085588063638)
,p_report_id=>wwv_flow_api.id(60096215824810221)
,p_name=>'Row text contains ''4501'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'4501'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(80761070837822197)
,p_plug_name=>'Button'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(80760964049822196)
,p_plug_name=>'Lex'
,p_parent_plug_id=>wwv_flow_api.id(80761070837822197)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(94137705655490461)
,p_plug_name=>'Kasse'
,p_parent_plug_id=>wwv_flow_api.id(80761070837822197)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(84977592485416348)
,p_plug_name=>unistr('Kategorie \00E4ndern')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43036788119063644)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(80761070837822197)
,p_button_name=>'Show_Buchungen_all'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Show Buchungen All'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:386:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43044624221063652)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:229:&SESSION.::&DEBUG.:229'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43039097001063645)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'Update_Kasse'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update fk_main_key tag'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43041472128063650)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Delete_Beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete Beleg'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43037547210063645)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'Kasse'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kasse'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:314:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43039513875063645)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'Steuer_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Steuer Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43041845312063650)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>unistr('Zusammenf\00FChren')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Zusammenf\00FChren')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43042212123063650)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Lexware_new'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lexware new'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:253:&SESSION.::&DEBUG.:RP,253::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43039979581063645)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'Steuer_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Steuer Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43042586596063650)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Kontenblatt'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontenblatt'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43042995211063650)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Kontoauszug'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontoauszug'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:242:&SESSION.::&DEBUG.:RP,242::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43043427158063650)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Kontoauszug_Abstimmung'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontoauszug Abstimmung'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP::#target="_blank"'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43043861361063650)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Susa'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Susa'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43044190609063650)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Kontrolle'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Kontrolle'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP:P310_KONTO:&P304_KONTO_AUSWAHL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43040310542063645)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'1_set_Relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'1_ Set Relation'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43050526580063653)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Update_Land'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Land'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43050163684063653)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Update_Ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43037904357063645)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'Set_split_buch_nr_man'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Split Buch Nr Man'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43045704455063652)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Update_Kategorie'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update kategorie'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43038286033063645)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'set_flg_split_buch'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43038696750063645)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(94137705655490461)
,p_button_name=>'reset_flg_split_buch_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Flg Split Buch'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43046089042063652)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Update_Verwendungszweck'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update verwendungszweck'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43046558786063652)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Update_Wiederholung'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update wiederholung'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43046955209063652)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43047334714063653)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>unistr('Update_n\00E4chste_Zahllung_1')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Update n\00E4chste zahllung')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43047757554063653)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Insert_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Insert inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43048173144063653)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'remove_Inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'remove inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43048554964063653)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'Insert_Projekt'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Insert Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43048938085063653)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'remove_Projekt_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Remove Projekt'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43051336520063655)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'set_zahlungsart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'set_zahlungsart'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43049359174063653)
,p_button_sequence=>290
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>unistr('Update_Gesch\00E4ftspartner')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Update Gesch\00E4ftspartner')
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43049748327063653)
,p_button_sequence=>300
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>unistr('Change_Gesch\00E4ftspartner')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Change Gesch\00E4ftspartner')
,p_button_position=>'BODY'
,p_button_redirect_url=>unistr('f?p=&APP_ID.:233:&SESSION.::&DEBUG.:RP:P233_PK_GESCHAEFTSPARTNER:&"P229_FK_GESCH\00C4FTSPARTNER".')
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43050914593063653)
,p_button_sequence=>310
,p_button_plug_id=>wwv_flow_api.id(84977592485416348)
,p_button_name=>'set_persoenlich_vor_ort'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'set_persoenlich_vor_ort'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8334178339927183)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8332307838927183)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43045015557063652)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(80760964049822196)
,p_button_name=>'Lex_Kontenplan'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Lex Kontenplan'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:257:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8334447631927183)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8332307838927183)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8334302043927183)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8332307838927183)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8335862414927184)
,p_branch_action=>'f?p=&APP_ID.:101:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8334447631927183)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8335193479927184)
,p_branch_action=>'f?p=&APP_ID.:99:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8334302043927183)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8333819324927183)
,p_name=>'P100_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8332439707927183)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43040721311063647)
,p_name=>'P100_SPLIT_NR_MAN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(94137705655490461)
,p_prompt=>'Split Nr Man'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:0;0,1;1,2;2,3;3,4;4,5;5,6;6,7;7,8;8,9;9,10;10'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43051744305063655)
,p_name=>'P100_FK_ADR_LAND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'land'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_ADR_LAND'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select land, pk_adr_land',
'from t_adr_land',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43052159872063655)
,p_name=>'P100_FK_ADR_ORT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'ort'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_ADR_ORT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ort || '' ('' || land || '')'' ort, pk_adr_ort',
'from V_adr_ort ort',
'--  left join t_adr_land la on ort.fk_adr_land = la.pk_adr_land',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43052566996063655)
,p_name=>'P100_FK_BAS_KAT_KATEGORIE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'Fk kategorie'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_BAS_KAT_KATEGORIE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43052924756063655)
,p_name=>'P100_DESCR1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'fk_main_key, konrotsp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43053300701063655)
,p_name=>'P100_FK_STD_VERW_VERWENDUNGSZWECK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'Fk verwendungszweck'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_VERW_VERWENDUNGSZWECK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std where fk_std_group = 9'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43053728028063656)
,p_name=>'P100_DESCR1_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43054094112063656)
,p_name=>'P100_WIEDERHOLUNG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'Wiederholung'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC:',
unistr('"j\00E4hrlich";"j\00E4hrlich",'),
unistr('"halbj\00E4hrlich";"halbj\00E4hrlich",'),
unistr('"viertelj\00E4hrlich";"viertelj\00E4hrlich",'),
'"monatlich";"monatlich",',
'einmalig;einmalig'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43054567008063656)
,p_name=>'P100_DESCR1_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43054884332063656)
,p_name=>unistr('P100_N\00C4CHSTE_ZAHLUNG')
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>unistr('N\00E4chste zahlung')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43055298880063656)
,p_name=>'P100_DESCR1_3'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'fk_main_key, kontotyp'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightblue"style="background-color:lightblue"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43055721972063658)
,p_name=>'P100_FK_INV_INVENTAR'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_INV_INVENTAR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr d, pk_inv_inventar',
'from t_inv_inventare'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43056090795063658)
,p_name=>'P100_DESCR1_4'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'fk_main_key'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="background-color:lightgreen"'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43056539643063658)
,p_name=>'P100_FK_PROJ_PROJEKT'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_prompt=>'Fk projekt'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_PROJ_PROJEKT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select projekt || '' ('' || von || '' - '' || bis || '')'' d  ,Pk_proj_projekt',
'from t_proj_projekt'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43056899166063658)
,p_name=>'P100_FK_STD_KTO_ZAHLUNGSART'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Std Kto Zahlungsart'
,p_source=>'FK_STD_KTO_ZAHLUNGSART'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FK_STD_INP_ZAHLUNGSART'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select std_name d, std_value',
'  from t_std',
'  where fk_std_group = 22'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(43057319560063658)
,p_name=>'P100_FK_KON_GESCHAEFTSPARTNER'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(84977592485416348)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Gesch\00E4ftspartner')
,p_source=>unistr('FK_GESCH\00C4FTSPARTNER')
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_KON_GESCHAEFTSPARTNER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select geschaeftspartner, pk_kon_geschaeftspartner',
'from v_kon_geschaeftspartner'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43059213112063669)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_OK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'',
'',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select  v_fk_main_key,',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43059599552063669)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_OK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'',
'  ',
'',
'      insert into contr_kategorie_zahlung',
'      (',
'        fk_main_key,',
'        fk_status,',
'          Kontrollzweck',
'      )',
'      select v_fk_main_key,',
'      1,',
'      ''Verwendungszweck''',
'      from dual;',
'      commit;',
'    end if;',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43057726597063669)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_1_Update_land'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set  fk_land = :P100_fK_LAND where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43050526580063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43058080359063669)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_2_Update_Ort'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_city = :P100_FK_ort where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43050163684063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43060008734063670)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_Update_Verwendungszweck'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_Verwendungszweck = :P100_FK_VERWENDUNGSZWECK where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43046089042063652)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43060395565063670)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_1_Update_Wiederholung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'  ',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set fk_la_wdh = :P100_Wiederholung  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43046558786063652)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43060829260063670)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_2_Update_naechste_Zahlung'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'      if v_kontotyp = 1 then',
unistr('       update "KTO_Girokonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 2 then',
unistr('       update "KTO_Kreditkarte"  set N\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'      ',
'      if v_kontotyp = 3 then',
unistr('       update "KTO_Paypal"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    ',
'    ',
'      if v_kontotyp = 4 then',
unistr('       update "KTO_Tagesgeldkonto"  set n\00E4chste_Zahlung = :P195_n\00E4chste_Zahlung where  fk_main_key = v_fk_main_key;'),
'       commit;',
'      end if;',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43046955209063652)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43061190038063670)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_2_Update_naechste_Zahlung_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'    ',
'       select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'               substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'       into v_fk_main_key, v_kontotyp',
'       from dual;',
'      ',
'    ',
'       p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43047334714063653)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43064472517063672)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_3_Update_naechste_Zahlung_1_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'  --     select  substr(apex_application.g_f02(i),1, instr(apex_application.g_f02(i),'','')-1),',
'   --            substr(apex_application.g_f02(i),instr(apex_application.g_f02(i),'','')+1,length(apex_application.g_f02(i))-instr(apex_application.g_f02(i),'','') )',
'  --     into v_fk_main_key, v_kontotyp',
'  --     from dual;',
'      ',
'    ',
'    --   p_set_naechste_zahlung (v_fk_main_key , v_kontotyp );',
unistr('   update inp_belege_all set fk_la_wdh = :"P100_N\00C4CHSTE_ZAHLUNG" where pk_inp_belege_all = apex_application.g_f01(i);'),
'    commit;',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43047334714063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43061583032063670)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_Update_Kategorie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_Kategorie = :P100_FK_Kategorie  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43045704455063652)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43062035088063670)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_1_insert_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_inventar = to_number(:P100_fk_inventar)  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43047757554063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43062410395063670)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_2_remove_Inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_inventar_zahlung where fk_inventar = to_number(:P195_fk_inventar) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43048173144063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43062874367063670)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_1_insert_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set fk_projekt = to_number(:P100_fk_projekt)  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43048554964063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43063248223063670)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_2_remove_Projekt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'',
' for i in 1..apex_application.g_f01.count loop',
' ',
'  delete from t_rel_projekt_zahlung where fk_projekt = to_number(:P195_fk_projekt) and fk_main_key =  apex_application.g_f01(i);',
'  commit;',
' ',
'',
' ',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43048938085063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43058406366063669)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('8_set_pers\00F6nlich_vor_ort')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Update Category for all basic bank account tables',
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'  for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
unistr('       update inp_belege_all  set pers\00F6nlich_vor_ort = 1 where  pk_inp_belege_all =  apex_application.g_f01(i);'),
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43050914593063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43058813173063669)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_Update_zahlrungsart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
'       update inp_belege_all  set FK_zahlungsart = :P100_FK_ZAHLUNGSART  where  pk_inp_belege_all =  apex_application.g_f01(i);',
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43051336520063655)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43064027761063672)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('11_Update_Gesch\00E4ftspartner')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_fk_main_key number;',
'  v_kontotyp number;',
'begin',
'',
'    for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'  ',
'      ',
'',
unistr('       update inp_belege_all  set fk_gesch\00E4ftspartner = :P100_FK_geschaeftspartner  where  pk_inp_belege_all =  apex_application.g_f01(i);'),
'       commit;',
'      ',
'    ',
'    end if;',
'  ',
'  end loop;',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(43049359174063653)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43064824748063672)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_delete_Beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'   if apex_application.g_f01(i) is not null then',
'      delete from  inp_belege_all where pk_inp_belege_all =  apex_application.g_f01(i);',
'      commit;',
'                     ',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(36415025091550378)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(43063614503063672)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' null;',
' ',
' --1 OK',
'   --OK:     2 - v_fk_main_key (,) v_kontotyp ',
'   --OK_1:     2 - v_fk_main_key (,) v_kontotyp ',
' ',
' --2 Update Land / Ort',
'   --Update Land:  1  - pk_input_belege_all',
'   --Update Ort:  1  -  pk_input_belege_all',
' ',
' --3 Update Verwendungszweck',
'   --Update Verwendungszweck:  1  -  pk_input_belege_all',
' ',
unistr(' --4 Update Wiederholung, Update n\00E4chste Zahlung, Update n\00E4chste Zahlung1'),
'   --Update Wiederholung:  1  - pk_input_belege_all',
unistr('   --Update n\00E4chste Zahlung:   2 - v_fk_main_key (,) v_kontotyp '),
unistr('   --Update n\00E4chste Zahlung1:  2 - v_fk_main_key (,) v_kontotyp '),
'',
' --5 Update Kategorie',
'   --Update Kategorie: 1  -  pk_input_belege_all',
' ',
' ',
' --6 insert Inventar / remove Inventar',
'   --insert Inventar:  1  -  pk_input_belege_all',
'   --remove Inventar: 1  -  pk_input_belege_all',
' ',
' --7 insert Projekt / remove Projekt',
'    --insert Projekt: 1  - pk_input_belege_all',
'    --remove Projekt: 1  -  pk_input_belege_all',
' ',
unistr(' --8 set pers\00F6nlich vor Ort'),
unistr('     --set pers\00F6nlich vor Ort: 1  -  pk_input_belege_all'),
' ',
' --9 Update zahlungsart',
'     --Update zahlungsart: 1  -  pk_input_belege_all',
' ',
' --10 delete Beleg',
'     --delete Beleg:  1  -  pk_input_belege_all',
unistr(' --11 Update Gesch\00E4ftspartner'),
unistr('     --Update Gesch\00E4ftspartner: 1  -  pk_input_belege_all'),
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
