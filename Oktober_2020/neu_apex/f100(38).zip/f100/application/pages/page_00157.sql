prompt --application/pages/page_00157
begin
--   Manifest
--     PAGE: 00157
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>157
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Telefonkarten'
,p_alias=>'TELEFONKARTEN99'
,p_step_title=>'Telefonkarten'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200929111223'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3574746647008339)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *    ',
'from "#OWNER#"."T_TEL_TELEFONKARTEN" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3575123127008340)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.::P158_PK_IMP_BA_TELEFONKARTEN:#PK_IMP_BA_TELEFONKARTEN#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>12885258367429261
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3577617204008346)
,p_db_column_name=>'TYP'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3582011296008354)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5632992190967489)
,p_db_column_name=>'TYP_TELEFON_KARTE'
,p_display_order=>112
,p_column_identifier=>'AE'
,p_column_label=>'Typ telefon karte'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49640854209195690)
,p_db_column_name=>'COMM'
,p_display_order=>232
,p_column_identifier=>'AQ'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49641084237195693)
,p_db_column_name=>'PK_TEL_TELEFONKARTEN'
,p_display_order=>262
,p_column_identifier=>'AT'
,p_column_label=>'Pk Tel Telefonkarten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850273529228828)
,p_db_column_name=>'TEL_TELEFONNUMMER'
,p_display_order=>272
,p_column_identifier=>'AU'
,p_column_label=>'Tel Telefonnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850354785228829)
,p_db_column_name=>'VER_FL_VERTRAG'
,p_display_order=>282
,p_column_identifier=>'AV'
,p_column_label=>'Ver Fl Vertrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850400611228830)
,p_db_column_name=>'VER_KAR_FL_BESTEHEND'
,p_display_order=>292
,p_column_identifier=>'AW'
,p_column_label=>'Ver Kar Fl Bestehend'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850590748228831)
,p_db_column_name=>'VER_ANTRAGSNUMMER'
,p_display_order=>302
,p_column_identifier=>'AX'
,p_column_label=>'Ver Antragsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850680770228832)
,p_db_column_name=>'VER_KAR_DATENKAPAZITAET'
,p_display_order=>312
,p_column_identifier=>'AY'
,p_column_label=>'Ver Kar Datenkapazitaet'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850741002228833)
,p_db_column_name=>'VER_KUNDENNUMMER'
,p_display_order=>322
,p_column_identifier=>'AZ'
,p_column_label=>'Ver Kundennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850860522228834)
,p_db_column_name=>'VER_DATUM'
,p_display_order=>332
,p_column_identifier=>'BA'
,p_column_label=>'Ver Datum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20850964790228835)
,p_db_column_name=>'VER_KAR_PROVIDER'
,p_display_order=>342
,p_column_identifier=>'BB'
,p_column_label=>'Ver Kar Provider'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851017413228836)
,p_db_column_name=>'VER_KAR_DIENSTLEISTER'
,p_display_order=>352
,p_column_identifier=>'BC'
,p_column_label=>'Ver Kar Dienstleister'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851135113228837)
,p_db_column_name=>'KAR_PIN1'
,p_display_order=>362
,p_column_identifier=>'BD'
,p_column_label=>'Kar Pin1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851212700228838)
,p_db_column_name=>'KAR_KARTENNUMMER'
,p_display_order=>372
,p_column_identifier=>'BE'
,p_column_label=>'Kar Kartennummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851312354228839)
,p_db_column_name=>'KAR_KARTENNUMMER1'
,p_display_order=>382
,p_column_identifier=>'BF'
,p_column_label=>'Kar Kartennummer1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851452559228840)
,p_db_column_name=>'VER_ABLAUFDATUM'
,p_display_order=>392
,p_column_identifier=>'BG'
,p_column_label=>'Ver Ablaufdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851524790228841)
,p_db_column_name=>'VER_VERTRAGSART'
,p_display_order=>402
,p_column_identifier=>'BH'
,p_column_label=>'Ver Vertragsart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851666896228842)
,p_db_column_name=>'VER_VERTRAGSLAUFZEIT'
,p_display_order=>412
,p_column_identifier=>'BI'
,p_column_label=>'Ver Vertragslaufzeit'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851755718228843)
,p_db_column_name=>'VER_KAR_DATUM2'
,p_display_order=>422
,p_column_identifier=>'BJ'
,p_column_label=>'Ver Kar Datum2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851829607228844)
,p_db_column_name=>'VER_AUFTRAGSNUMMER'
,p_display_order=>432
,p_column_identifier=>'BK'
,p_column_label=>'Ver Auftragsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20851912688228845)
,p_db_column_name=>'WEB_WEBSEITE'
,p_display_order=>442
,p_column_identifier=>'BL'
,p_column_label=>'Web Webseite'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20852074465228846)
,p_db_column_name=>'WEB_BENUTZERNAME'
,p_display_order=>452
,p_column_identifier=>'BM'
,p_column_label=>'Web Benutzername'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20852135334228847)
,p_db_column_name=>'WEB_PASSWORT'
,p_display_order=>462
,p_column_identifier=>'BN'
,p_column_label=>'Web Passwort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20852238016228848)
,p_db_column_name=>'KAR_PUK1'
,p_display_order=>472
,p_column_identifier=>'BO'
,p_column_label=>'Kar Puk1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20852329368228849)
,p_db_column_name=>'KAR_PUK2'
,p_display_order=>482
,p_column_identifier=>'BP'
,p_column_label=>'Kar Puk2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20852443315228850)
,p_db_column_name=>'KAR_PIN2'
,p_display_order=>492
,p_column_identifier=>'BQ'
,p_column_label=>'Kar Pin2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20884812869551801)
,p_db_column_name=>'KAR_SIMKARTENNR'
,p_display_order=>502
,p_column_identifier=>'BR'
,p_column_label=>'Kar Simkartennr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20884925379551802)
,p_db_column_name=>'GER_IMEI'
,p_display_order=>512
,p_column_identifier=>'BS'
,p_column_label=>'Ger Imei'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885060005551803)
,p_db_column_name=>'VER_MANDATSREFERENZNUMMER'
,p_display_order=>522
,p_column_identifier=>'BT'
,p_column_label=>'Ver Mandatsreferenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885153898551804)
,p_db_column_name=>'VER_PROD_PRODUKT'
,p_display_order=>532
,p_column_identifier=>'BU'
,p_column_label=>'Ver Prod Produkt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885225008551805)
,p_db_column_name=>'VER_KAR_DATENUEBERTRAGUNG'
,p_display_order=>542
,p_column_identifier=>'BV'
,p_column_label=>'Ver Kar Datenuebertragung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885397822551806)
,p_db_column_name=>'VER_VERTRAGSNUMMER'
,p_display_order=>552
,p_column_identifier=>'BW'
,p_column_label=>'Ver Vertragsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885482659551807)
,p_db_column_name=>'VER_VON'
,p_display_order=>562
,p_column_identifier=>'BX'
,p_column_label=>'Ver Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885529506551808)
,p_db_column_name=>'VER_BIS'
,p_display_order=>572
,p_column_identifier=>'BY'
,p_column_label=>'Ver Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885620459551809)
,p_db_column_name=>'BEST_AUFTRAGSDATUM'
,p_display_order=>582
,p_column_identifier=>'BZ'
,p_column_label=>'Best Auftragsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885710057551810)
,p_db_column_name=>'KAR_SIMKARTENNR_NEU'
,p_display_order=>592
,p_column_identifier=>'CA'
,p_column_label=>'Kar Simkartennr Neu'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885830689551811)
,p_db_column_name=>'FK_VER_VERTRAG'
,p_display_order=>602
,p_column_identifier=>'CB'
,p_column_label=>'Fk Ver Vertrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20885912479551812)
,p_db_column_name=>'FESTNETZNUMMER'
,p_display_order=>612
,p_column_identifier=>'CC'
,p_column_label=>'Festnetznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(20886013043551813)
,p_db_column_name=>'GERAET'
,p_display_order=>622
,p_column_identifier=>'CD'
,p_column_label=>'Geraet'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5522185461766204)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'148324'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TYP_TELEFON_KARTE:TYP:BEMERKUNG::COMM:PK_TEL_TELEFONKARTEN:TEL_TELEFONNUMMER:VER_FL_VERTRAG:VER_KAR_FL_BESTEHEND:VER_ANTRAGSNUMMER:VER_KAR_DATENKAPAZITAET:VER_KUNDENNUMMER:VER_DATUM:VER_KAR_PROVIDER:VER_KAR_DIENSTLEISTER:KAR_PIN1:KAR_KARTENNUMMER:KAR'
||'_KARTENNUMMER1:VER_ABLAUFDATUM:VER_VERTRAGSART:VER_VERTRAGSLAUFZEIT:VER_KAR_DATUM2:VER_AUFTRAGSNUMMER:WEB_WEBSEITE:WEB_BENUTZERNAME:WEB_PASSWORT:KAR_PUK1:KAR_PUK2:KAR_PIN2:KAR_SIMKARTENNR:GER_IMEI:VER_MANDATSREFERENZNUMMER:VER_PROD_PRODUKT:VER_KAR_DA'
||'TENUEBERTRAGUNG:VER_VERTRAGSNUMMER:VER_VON:VER_BIS:BEST_AUFTRAGSDATUM:KAR_SIMKARTENNR_NEU:FK_VER_VERTRAG:FESTNETZNUMMER:GERAET'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8638336420719118)
,p_plug_name=>'Step 2'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8634358988719092)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8638484775719118)
,p_plug_name=>'Step 2'
,p_parent_plug_id=>wwv_flow_api.id(8638336420719118)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8640142085719119)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8638336420719118)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8640484822719119)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8638336420719118)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8640345584719119)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8638336420719118)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3583967003008357)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3574746647008339)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.:158'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8641851902719119)
,p_branch_action=>'f?p=&APP_ID.:158:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8640484822719119)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8641170402719119)
,p_branch_action=>'f?p=&APP_ID.:156:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8640345584719119)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8639812840719119)
,p_name=>'P157_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8638484775719118)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
