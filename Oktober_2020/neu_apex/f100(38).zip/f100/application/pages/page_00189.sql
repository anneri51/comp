prompt --application/pages/page_00189
begin
--   Manifest
--     PAGE: 00189
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>189
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kontoauszug_Bild'
,p_alias=>'KONTOAUSZUG_BILD99'
,p_step_title=>'Kontoauszug_Bild'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20200929183800'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6245142701367885)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6251159899536764)
,p_plug_name=>'Kontoauszug_Bild'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_kto_KONTO_AUSZUG_BILD,',
'       FK_kto_KoNTO_AUSZUG,',
'       SEITE,',
'       length(BILD) bild',
'  from T_REL_kto_KONTO_AUSZUG_BILD',
'where fk_kto_konto_auszug = :P189_PK_kto_KONTO_AUSZUG'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6251171735536764)
,p_name=>'Kontoauszug_Bild'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15561306975957685
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6252458527536774)
,p_db_column_name=>'SEITE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Seite'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6244826486367882)
,p_db_column_name=>'BILD'
,p_display_order=>13
,p_column_identifier=>'E'
,p_column_label=>'Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:T_REL_KONTO_AUSZUG_BILD:BILD:PK_KONTO_AUSZUG_BILD::::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50110850214262190)
,p_db_column_name=>'PK_KTO_KONTO_AUSZUG_BILD'
,p_display_order=>23
,p_column_identifier=>'F'
,p_column_label=>'Pk Kto Konto Auszug Bild'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50110904745262191)
,p_db_column_name=>'FK_KTO_KONTO_AUSZUG'
,p_display_order=>33
,p_column_identifier=>'G'
,p_column_label=>'Fk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6255502938605450)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'155657'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1
,p_report_columns=>'SEITE:BILD::PK_KTO_KONTO_AUSZUG_BILD:FK_KTO_KONTO_AUSZUG'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6245204522367886)
,p_name=>'P189_PK_KONTO_AUSZUG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6245142701367885)
,p_prompt=>'Pk konto auszug'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
