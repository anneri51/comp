prompt --application/pages/page_00190
begin
--   Manifest
--     PAGE: 00190
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>190
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_alias=>'KARTENZAHLUNG_BELEG_ZUORDNUNG_'
,p_step_title=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200930124526'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6331165586829422)
,p_plug_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum, t1.*',
'from (',
'SELECT',
'',
'     kto.fk_main_key,',
'     id, ',
'     ',
'  ---',
'     TO_CHAR("Buchungstag") "Buchungstag",',
'     ',
'     to_char(nvl(belzus.betrag,round(kto."Betrag",2))) steuergrundbetrag,',
'    ',
'     steuersatz zahl_mwst_satz,',
'     null  zahl_mwst,',
'     netto zahl_nettobetrag,',
' ---',
' ',
'     round(kto."Betrag",2) "Betrag",',
'     kto.Waehrung kto_waehrung,',
unistr('     round(kto.Fremdwaehrungsbetrag,2) "Fremdw\00E4hrungsbetrag",'),
'     kto.Fremdwaehrung,',
'     kto.buchungstext,',
'     kto.FK_bas_kat_Kategorie kto_fk_bas_kat_kategorie,',
'     kto.FK_std_verw_Verwendungszweck,',
'     kto.FK_std_kto_Kontotyp,',
'     kto.fk_bas_kal_buchungstag,',
'     kto.fk_bas_kal_wertstellung,',
'     kto.verwendungszweck kto_verwendungszweck,',
'     kto.kategorie kto_kategorie,',
'     kto.bucht_tag,',
'     kto.bucht_monat,',
'     kto.bucht_jahr,',
'     kto.bucht_datum,',
'     kto.wertt_tag,',
'     kto.wertt_monat,',
'     kto.wertt_jahr,',
'     kto.wertt_datum,',
'     kto.Kontotyp,',
'     rreza.cnt_re,',
'     rreza.rel_teil   sum_rel_teil,',
'     pp.fk_kto_vorgang    paypal_vorg,',
'     CASE',
'         WHEN FK_std_kto_Kontotyp = 1 THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''> ''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN FK_std_kto_Kontotyp = 2 THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN FK_std_kto_Kontotyp = 3 THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'         WHEN FK_std_kto_Kontotyp = 4 THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_ID:''',
'                                     || id',
'                                     || CHR(39)',
'                                     || ''>''',
'                                     || buchungstext',
'                                     || ''</a>''',
'     END link_buchung,',
'     pp."Name",',
'     pp."Artikelbezeichnung",',
'    ',
'    belzus.ART	,',
'belzus.FK_IMP_BA_BEL	,',
'belzus.PK_IMP_BA_ALLG_BEL	,',
'belzus.BEZEICHNUNG	,',
'belzus.KENNZEICHEN	,',
'belzus.DATUM	,',
'belzus.DATUM_VERGEHEN	,',
'belzus.FK_BAS_KAL_ARBEITSTAG	,',
'belzus.FK_KTO_BUCHUNG	,',
'belzus.BETRAG	,',
'belzus.WAEHRUNG	,',
'belzus.STEUERSATZ	,',
'belzus.MWST_BETRAG	,',
'belzus.NETTO	,',
'belzus.ZAHLUNGSART	,',
'belzus.VERWENDUNGSZWECK	,',
'belzus.FK_INV_INVENTAR	,',
'belzus.FK_PROJ_PROJEKT	,',
'belzus.WAEHRUNG_BETRAG	,',
'belzus.FK_BAS_KAT_KATEGORIE	,',
'belzus.KATEGORIE	,',
'belzus.PROJEKT	,',
'belzus.INVENTAR	,',
'belzus.FK_BEL_BELEG_ABLAGE	,',
'     CASE',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''> ''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'     END link_beleg,',
'     reza.RELEVANTER_TEILBETRAG, ',
'     reza.BEMERKUNG,',
'     re.PK_re_RECHNUNG, ',
'     re.RECHNUNGSNUMMER, ',
'     re.RECHNUNG, ',
'     re.RECHNUNGSDATUM, ',
'     re.ZEITRAUM_VON, ',
'     re.ZEITRAUM_BIS, ',
'     re.RECHNUNGSBETRAG_NETTO, ',
'     re.FK_bas_steu_STEUER_SATZ re_fk_steuersatz, ',
'     re.MWST re_mwst_betrag, ',
'     re.RECHNUNGSBETRAG_BRUTTO, ',
'     std_retyp.std_name fk_bas_re_rechnungstyp, ',
'     re.FK_std_kto_ZAHLUNGSART, ',
'     re.SKONTOBETRAG, ',
'     re.SKONTOSATZ, ',
'     re.ZAHLUNG_ABGESCHLOSSEN re_zahlung_abgeschl, ',
'     re.VORSTEUER_BEZAHLT, ',
'     re.STEUERENDABRECHNUNG,',
'     pr.PK_proj_PROJEKT, ',
'     pr.FK_kon_AUFTRAGGEBER, ',
'     pr.FK_kon_PROJEKTPARTNER_1, ',
'     pr.FK_kon_PROJEKTPARTNER_2, ',
'     pr.PROJEKT pr_projekt, ',
'     pr.VON, ',
'     pr.BIS, ',
'     pr.AKTUELLER_STUNDENSATZ, ',
'     pr.PSP_ELEMENT,',
'     pr.RECHNUNG_GESTELLT, ',
'     pr.ZAHLUNG_ABGESCHLOSSEN pr_zahlung_abgeschl, ',
'     pr.PROJEKT_ABGESCHLOSSEN,',
'     inv.PK_Inv_INVENTAR, ',
'     inv.INVENTAR inv_inventar, ',
'     inv.ANSCHAFFUNGSDATUM, ',
'     inv.ANSCHAFFUNGSJAHR, ',
'     inv.ABSCHREIBUNGSDAUER, ',
'     inv.RESTBUCHWERT_2018, ',
'     inv.RESTBUCHWERT_2019, ',
'     inv.RESTBUCHWERT_2020, ',
'     inv.PREIS_NETTO, ',
'     inv.MWST, ',
'     inv.fk_bas_steu_steuer_satz, ',
'     inv.PREIS_BRUTTO, ',
'     inv.COMM, ',
'     inv.LIZENZNUMMER, ',
'     inv.ANFORDERUNGSCODE, ',
'     inv.FK_bas_INV_INVENTARTYP, ',
'     inv.KFZ_KENNZEICHEN, ',
'     inv.FAHRGESTELLNR',
'    FROM',
'     v_kto_konten_zus kto',
'     LEFT JOIN (',
'         SELECT',
'             fk_kto_vorgang,',
'             fk_main_key,',
'             art,',
'             bezeichnung,',
'             "Name",',
'             "Artikelbezeichnung"',
'         FROM',
'             t_KTO_Paypal pp',
'             JOIN v_imp_bel_zus bzus ON pp.fk_main_key = bzus.fk_kto_buchung',
'         GROUP BY',
'             fk_kto_vorgang,',
'             fk_main_key,',
'             art,',
'             bezeichnung,',
'             "Name",',
'             "Artikelbezeichnung"',
'     ) pp ON pp.fk_kto_vorgang = kto.fk_kto_vorgang',
'     LEFT JOIN v_imp_bel_zus belzus ON belzus.fk_kto_buchung = kto.fk_main_key',
'',
'     left join t_rel_re_rechnung_zahlung reza on reza.fk_main_key = kto.fk_main_key',
'     left join t_re_rechnung re on re.pk_re_rechnung = reza.fk_re_rechnung',
'     left join (select * from t_std where fk_std_group = 7) std_retyp on std_retyp.std_value = re.fk_std_re_rechnungstyp',
'     left join t_proj_projekt pr on pr.pk_proj_Projekt = re.fk_proj_projekt',
'     left join t_rel_inv_inventar_zahlung reinza on reinza.fk_main_key = kto.fk_main_key',
'     left join t_inv_inventare inv on inv.pk_inv_inventar = reinza.fk_inv_inventar',
'     LEFT JOIN (',
'         SELECT',
'             fk_main_key,',
'             COUNT(*) cnt_re,',
'             SUM(relevanter_teilbetrag) rel_teil',
'         FROM',
'             t_rel_re_rechnung_zahlung',
'         GROUP BY',
'             fk_main_key',
'     ) rreza ON rreza.fk_main_key = kto.fk_main_key',
'     LEFT JOIN (',
'         SELECT',
'             kto.fk_main_key',
'         FROM',
'             t_steu_steuer_lohnsteuerkarte lo',
'             LEFT JOIN T_REL_STEU_STEUER_LOHN_ZAHLUNG loz ON lo.pk_steu_steuer_lohnsteuerkarte = loz.fk_steu_steuer_lohnsteuerkarte',
'             LEFT JOIN v_kto_konten_zus kto ON kto.fk_main_key = loz.fk_main_key',
'     ) lo ON lo.fk_main_key = kto.fk_main_key',
' UNION',
' SELECT',
' ',
'     NULL fk_main_key,',
'     NULL id,',
'     ',
'     TO_CHAR(belzus.datum) "Buchungstag", ',
'  ---',
'  ',
'     belzus.betrag steuergrundbetrag,',
'     ',
'     belzus.steuersatz,',
'     null mwst,',
'     belzus.netto,',
' ---',
' ',
'     NULL "Betrag",',
unistr('     NULL "W\00E4hrung",'),
unistr('     NULL "Fremdw\00E4hrungsbetrag",'),
unistr('     NULL "Fremdw\00E4hrung",'),
'     NULL buchungstext,',
'     NULL "FK_Kategorie",',
'     NULL "FK_Verwendungszweck",',
'     NULL "FK_Kontotyp",',
'     NULL fk_buchungstag,',
'     NULL fk_wertstellung,',
'     NULL verwendungszweck,',
'     NULL kategorie,',
'     NULL bucht_tag,',
'     NULL bucht_monat,',
'     NULL bucht_jahr,',
'     NULL bucht_datum,',
'     NULL wertt_tag,',
'     NULL wertt_monat,',
'     NULL wertt_jahr,',
'     NULL wertt_datum,',
'     NULL "Kontotyp",',
'     NULL cnt_re,',
'     NULL sum_rel_teil,',
'     NULL paypal_vorg,',
'     NULL link_buchung,',
'     NULL "Name",',
'     NULL "Artikelbezeichnung",',
'     ',
'    belzus.ART	,',
'belzus.FK_IMP_BA_BEL	,',
'belzus.PK_IMP_BA_ALLG_BEL	,',
'belzus.BEZEICHNUNG	,',
'belzus.KENNZEICHEN	,',
'belzus.DATUM	,',
'belzus.DATUM_VERGEHEN	,',
'belzus.FK_BAS_KAL_ARBEITSTAG	,',
'belzus.FK_KTO_BUCHUNG	,',
'belzus.BETRAG	,',
'belzus.WAEHRUNG	,',
'belzus.STEUERSATZ	,',
'belzus.MWST_BETRAG	,',
'belzus.NETTO	,',
'belzus.ZAHLUNGSART	,',
'belzus.VERWENDUNGSZWECK	,',
'belzus.FK_INV_INVENTAR	,',
'belzus.FK_PROJ_PROJEKT	,',
'belzus.WAEHRUNG_BETRAG	,',
'belzus.FK_BAS_KAT_KATEGORIE	,',
'belzus.KATEGORIE	,',
'belzus.PROJEKT	,',
'belzus.INVENTAR	,',
'belzus.FK_BEL_BELEG_ABLAGE	,',
'',
'     CASE',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:111:&SESSION.::NO:RP:P111_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''> ''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:114:&SESSION.::NO:RP:P114_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:116:&SESSION.::NO:RP:P116_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'         WHEN belzus.art = ''ALLG_BELEG'' THEN ''<a href=''''f?p=&APP_ID.:77:&SESSION.::NO:RP:P77_FK_IMP_BA_BEL:''',
'                                             || belzus.fk_imp_ba_bel',
'                                             || CHR(39)',
'                                             || ''>''',
'                                             || belzus.bezeichnung',
'                                             || ''</a>''',
'     END link_beleg,',
'     null RELEVANTER_TEILBETRAG, ',
'     null BEMERKUNG,',
'     null PK_RECHNUNG, ',
'     null RECHNUNGSNUMMER, ',
'     null RECHNUNG, ',
'     null RECHNUNGSDATUM, ',
'     null ZEITRAUM_VON, ',
'     null ZEITRAUM_BIS, ',
'     null RECHNUNGSBETRAG_NETTO, ',
'     null FK_STEUERSATZ, ',
'     null MWST, ',
'     null RECHNUNGSBETRAG_BRUTTO, ',
'     null FK_RECHNUNGSTYP, ',
'     null FK_ZAHLUNGSART, ',
'     null SKONTOBETRAG, ',
'     null SKONTOSATZ, ',
'     null ZAHLUNG_ABGESCHLOSSEN, ',
'     null VORSTEUER_BEZAHLT, ',
'     null STEUERENDABRECHNUNG,',
'     null PK_PROJEKT, ',
'     null FK_AUFTRAGGEBER, ',
'     null FK_PROJEKTPARTNER_1, ',
'     null FK_PROJEKTPARTNER_2, ',
'     null PROJEKT, ',
'     null VON, ',
'     null BIS, ',
'     null AKTUELLER_STUNDENSATZ, ',
'     null PSP_ELEMENT,',
'     null RECHNUNG_GESTELLT, ',
'     null ZAHLUNG_ABGESCHLOSSEN, ',
'     null PROJEKT_ABGESCHLOSSEN,',
'     inv.PK_inv_INVENTAR, ',
'     inv.INVENTAR, ',
'     inv.ANSCHAFFUNGSDATUM, ',
'     inv.ANSCHAFFUNGSJAHR, ',
'     inv.ABSCHREIBUNGSDAUER, ',
'     inv.RESTBUCHWERT_2018, ',
'     inv.RESTBUCHWERT_2019, ',
'     inv.RESTBUCHWERT_2020, ',
'     inv.PREIS_NETTO, ',
'     inv.MWST, ',
'     inv.FK_bas_steu_STEUER_SATZ, ',
'     inv.PREIS_BRUTTO, ',
'     inv.COMM, ',
'     inv.LIZENZNUMMER, ',
'     inv.ANFORDERUNGSCODE, ',
'     inv.FK_bas_inv_INVENTARTYP, ',
'     inv.KFZ_KENNZEICHEN, ',
'     inv.FAHRGESTELLNR',
'',
' FROM',
'     v_imp_bel_zus belzus',
'     left join t_rel_inv_inventar_zahlung reinza on reinza.fk_imp_ba_bel = belzus.fk_imp_ba_bel',
'     left join t_inv_inventare inv on inv.pk_inv_inventar = reinza.fk_inv_inventar',
' WHERE',
'     belzus.zahlungsart = ''Barzahlung''',
'     ) t1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6331277057829422)
,p_name=>'Kartenzahlung_Beleg_Zuordnung_Steuer'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15641412298250343
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6331703202829426)
,p_db_column_name=>'ROWNUM'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Rownum'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332147974829427)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332478407829427)
,p_db_column_name=>'ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6332886959829428)
,p_db_column_name=>'Buchungstag'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Buchungstag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6334870192829432)
,p_db_column_name=>'Betrag'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6335702580829433)
,p_db_column_name=>unistr('Fremdw\00E4hrungsbetrag')
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>unistr('Fremdw\00E4hrungsbetrag')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6336548868829435)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6338930776829439)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6339303811829439)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6339712162829440)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340127182829440)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340495151829441)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6340962461829441)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6341356580829442)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6341709714829443)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6342076808829443)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6342518157829444)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6343313066829445)
,p_db_column_name=>'CNT_RE'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Cnt Re'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6343754941829446)
,p_db_column_name=>'SUM_REL_TEIL'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Sum Rel Teil'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344086332829447)
,p_db_column_name=>'PAYPAL_VORG'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Paypal Vorg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344529506829447)
,p_db_column_name=>'LINK_BUCHUNG'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Link Buchung'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6344957641829448)
,p_db_column_name=>'Name'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6345319537829449)
,p_db_column_name=>'Artikelbezeichnung'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6345728160829451)
,p_db_column_name=>'ART'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Art'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346130626829453)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346488201829454)
,p_db_column_name=>'PK_IMP_BA_ALLG_BEL'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Pk Imp Ba Allg Bel'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6346877700829455)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6347301402829457)
,p_db_column_name=>'KENNZEICHEN'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Kennzeichen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6347753486829458)
,p_db_column_name=>'DATUM'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Datum'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6348072532829459)
,p_db_column_name=>'DATUM_VERGEHEN'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Datum Vergehen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6349357485829463)
,p_db_column_name=>'BETRAG'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350067063829466)
,p_db_column_name=>'STEUERSATZ'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Steuersatz'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350496165829467)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6350873551829468)
,p_db_column_name=>'NETTO'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6351334169829469)
,p_db_column_name=>'ZAHLUNGSART'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Zahlungsart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6351678333829470)
,p_db_column_name=>'LINK_BELEG'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Link Beleg'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295300001780211)
,p_db_column_name=>'STEUERGRUNDBETRAG'
,p_display_order=>61
,p_column_identifier=>'AZ'
,p_column_label=>'Steuergrundbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295490863780213)
,p_db_column_name=>'RELEVANTER_TEILBETRAG'
,p_display_order=>71
,p_column_identifier=>'BA'
,p_column_label=>'Relevanter teilbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295575820780214)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>81
,p_column_identifier=>'BB'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295810590780216)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>101
,p_column_identifier=>'BD'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295881964780217)
,p_db_column_name=>'RECHNUNG'
,p_display_order=>111
,p_column_identifier=>'BE'
,p_column_label=>'Rechnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6295998886780218)
,p_db_column_name=>'RECHNUNGSDATUM'
,p_display_order=>121
,p_column_identifier=>'BF'
,p_column_label=>'Rechnungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296078098780219)
,p_db_column_name=>'ZEITRAUM_VON'
,p_display_order=>131
,p_column_identifier=>'BG'
,p_column_label=>'Zeitraum von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296175774780220)
,p_db_column_name=>'ZEITRAUM_BIS'
,p_display_order=>141
,p_column_identifier=>'BH'
,p_column_label=>'Zeitraum bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296346956780221)
,p_db_column_name=>'RECHNUNGSBETRAG_NETTO'
,p_display_order=>151
,p_column_identifier=>'BI'
,p_column_label=>'Rechnungsbetrag netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296525340780223)
,p_db_column_name=>'RE_MWST_BETRAG'
,p_display_order=>171
,p_column_identifier=>'BK'
,p_column_label=>'Re mwst betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296594525780224)
,p_db_column_name=>'RECHNUNGSBETRAG_BRUTTO'
,p_display_order=>181
,p_column_identifier=>'BL'
,p_column_label=>'Rechnungsbetrag brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296945033780227)
,p_db_column_name=>'SKONTOBETRAG'
,p_display_order=>211
,p_column_identifier=>'BO'
,p_column_label=>'Skontobetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6296986442780228)
,p_db_column_name=>'SKONTOSATZ'
,p_display_order=>221
,p_column_identifier=>'BP'
,p_column_label=>'Skontosatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6297160041780229)
,p_db_column_name=>'RE_ZAHLUNG_ABGESCHL'
,p_display_order=>231
,p_column_identifier=>'BQ'
,p_column_label=>'Re zahlung abgeschl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6358924266383980)
,p_db_column_name=>'VORSTEUER_BEZAHLT'
,p_display_order=>241
,p_column_identifier=>'BR'
,p_column_label=>'Vorsteuer bezahlt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359026035383981)
,p_db_column_name=>'STEUERENDABRECHNUNG'
,p_display_order=>251
,p_column_identifier=>'BS'
,p_column_label=>'Steuerendabrechnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359539607383986)
,p_db_column_name=>'PROJEKT'
,p_display_order=>301
,p_column_identifier=>'BX'
,p_column_label=>'Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359629713383987)
,p_db_column_name=>'VON'
,p_display_order=>311
,p_column_identifier=>'BY'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359672685383988)
,p_db_column_name=>'BIS'
,p_display_order=>321
,p_column_identifier=>'BZ'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359820153383989)
,p_db_column_name=>'AKTUELLER_STUNDENSATZ'
,p_display_order=>331
,p_column_identifier=>'CA'
,p_column_label=>'Aktueller stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6359952820383990)
,p_db_column_name=>'PSP_ELEMENT'
,p_display_order=>341
,p_column_identifier=>'CB'
,p_column_label=>'Psp element'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360025968383991)
,p_db_column_name=>'RECHNUNG_GESTELLT'
,p_display_order=>351
,p_column_identifier=>'CC'
,p_column_label=>'Rechnung gestellt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360134410383992)
,p_db_column_name=>'PR_ZAHLUNG_ABGESCHL'
,p_display_order=>361
,p_column_identifier=>'CD'
,p_column_label=>'Pr zahlung abgeschl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6360197545383993)
,p_db_column_name=>'PROJEKT_ABGESCHLOSSEN'
,p_display_order=>371
,p_column_identifier=>'CE'
,p_column_label=>'Projekt abgeschlossen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408693988215313)
,p_db_column_name=>'ZAHL_MWST_SATZ'
,p_display_order=>381
,p_column_identifier=>'CF'
,p_column_label=>'Zahl mwst satz'
,p_column_type=>'STRING'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408794499215314)
,p_db_column_name=>'ZAHL_MWST'
,p_display_order=>391
,p_column_identifier=>'CG'
,p_column_label=>'Zahl mwst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408951485215315)
,p_db_column_name=>'ZAHL_NETTOBETRAG'
,p_display_order=>401
,p_column_identifier=>'CH'
,p_column_label=>'Zahl nettobetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6408978101215316)
,p_db_column_name=>'RE_FK_STEUERSATZ'
,p_display_order=>411
,p_column_identifier=>'CI'
,p_column_label=>'Re fk steuersatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409226227215318)
,p_db_column_name=>'INVENTAR'
,p_display_order=>431
,p_column_identifier=>'CK'
,p_column_label=>'Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409328829215319)
,p_db_column_name=>'ANSCHAFFUNGSDATUM'
,p_display_order=>441
,p_column_identifier=>'CL'
,p_column_label=>'Anschaffungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409450471215320)
,p_db_column_name=>'ANSCHAFFUNGSJAHR'
,p_display_order=>451
,p_column_identifier=>'CM'
,p_column_label=>'Anschaffungsjahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409539059215321)
,p_db_column_name=>'ABSCHREIBUNGSDAUER'
,p_display_order=>461
,p_column_identifier=>'CN'
,p_column_label=>'Abschreibungsdauer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409756720215323)
,p_db_column_name=>'PREIS_NETTO'
,p_display_order=>481
,p_column_identifier=>'CP'
,p_column_label=>'Preis netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409830396215324)
,p_db_column_name=>'MWST'
,p_display_order=>491
,p_column_identifier=>'CQ'
,p_column_label=>'Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409921446215325)
,p_db_column_name=>'PREIS_BRUTTO'
,p_display_order=>501
,p_column_identifier=>'CR'
,p_column_label=>'Preis brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6409980437215326)
,p_db_column_name=>'COMM'
,p_display_order=>511
,p_column_identifier=>'CS'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6410075838215327)
,p_db_column_name=>'LIZENZNUMMER'
,p_display_order=>521
,p_column_identifier=>'CT'
,p_column_label=>'Lizenznummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6410189129215328)
,p_db_column_name=>'ANFORDERUNGSCODE'
,p_display_order=>531
,p_column_identifier=>'CU'
,p_column_label=>'Anforderungscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6440384718721580)
,p_db_column_name=>'KFZ_KENNZEICHEN'
,p_display_order=>551
,p_column_identifier=>'CW'
,p_column_label=>'Kfz kennzeichen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6440515177721581)
,p_db_column_name=>'FAHRGESTELLNR'
,p_display_order=>561
,p_column_identifier=>'CX'
,p_column_label=>'Fahrgestellnr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19958980061446326)
,p_db_column_name=>'KTO_WAEHRUNG'
,p_display_order=>571
,p_column_identifier=>'CY'
,p_column_label=>'Kto Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959085281446327)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>581
,p_column_identifier=>'CZ'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959144584446328)
,p_db_column_name=>'KTO_FK_BAS_KAT_KATEGORIE'
,p_display_order=>591
,p_column_identifier=>'DA'
,p_column_label=>'Kto Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959245278446329)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>601
,p_column_identifier=>'DB'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959366503446330)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>611
,p_column_identifier=>'DC'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959454417446331)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>621
,p_column_identifier=>'DD'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959545458446332)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>631
,p_column_identifier=>'DE'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959690149446333)
,p_db_column_name=>'KTO_VERWENDUNGSZWECK'
,p_display_order=>641
,p_column_identifier=>'DF'
,p_column_label=>'Kto Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959736241446334)
,p_db_column_name=>'KTO_KATEGORIE'
,p_display_order=>651
,p_column_identifier=>'DG'
,p_column_label=>'Kto Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959816275446335)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>661
,p_column_identifier=>'DH'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19959919793446336)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>671
,p_column_identifier=>'DI'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960005147446337)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>681
,p_column_identifier=>'DJ'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960125923446338)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>691
,p_column_identifier=>'DK'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960218034446339)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>701
,p_column_identifier=>'DL'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960318304446340)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>711
,p_column_identifier=>'DM'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960437670446341)
,p_db_column_name=>'WAEHRUNG_BETRAG'
,p_display_order=>721
,p_column_identifier=>'DN'
,p_column_label=>'Waehrung Betrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960581341446342)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>731
,p_column_identifier=>'DO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960666090446343)
,p_db_column_name=>'FK_BEL_BELEG_ABLAGE'
,p_display_order=>741
,p_column_identifier=>'DP'
,p_column_label=>'Fk Bel Beleg Ablage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960799732446344)
,p_db_column_name=>'PK_RE_RECHNUNG'
,p_display_order=>751
,p_column_identifier=>'DQ'
,p_column_label=>'Pk Re Rechnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960894149446345)
,p_db_column_name=>'FK_BAS_RE_RECHNUNGSTYP'
,p_display_order=>761
,p_column_identifier=>'DR'
,p_column_label=>'Fk Bas Re Rechnungstyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19960974829446346)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>771
,p_column_identifier=>'DS'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19961073983446347)
,p_db_column_name=>'PK_PROJ_PROJEKT'
,p_display_order=>781
,p_column_identifier=>'DT'
,p_column_label=>'Pk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19961171410446348)
,p_db_column_name=>'FK_KON_AUFTRAGGEBER'
,p_display_order=>791
,p_column_identifier=>'DU'
,p_column_label=>'Fk Kon Auftraggeber'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19961214219446349)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_1'
,p_display_order=>801
,p_column_identifier=>'DV'
,p_column_label=>'Fk Kon Projektpartner 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19961338790446350)
,p_db_column_name=>'FK_KON_PROJEKTPARTNER_2'
,p_display_order=>811
,p_column_identifier=>'DW'
,p_column_label=>'Fk Kon Projektpartner 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204251997752701)
,p_db_column_name=>'PR_PROJEKT'
,p_display_order=>821
,p_column_identifier=>'DX'
,p_column_label=>'Pr Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204382049752702)
,p_db_column_name=>'PK_INV_INVENTAR'
,p_display_order=>831
,p_column_identifier=>'DY'
,p_column_label=>'Pk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204456872752703)
,p_db_column_name=>'INV_INVENTAR'
,p_display_order=>841
,p_column_identifier=>'DZ'
,p_column_label=>'Inv Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204585981752704)
,p_db_column_name=>'RESTBUCHWERT_2018'
,p_display_order=>851
,p_column_identifier=>'EA'
,p_column_label=>'Restbuchwert 2018'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204602891752705)
,p_db_column_name=>'RESTBUCHWERT_2019'
,p_display_order=>861
,p_column_identifier=>'EB'
,p_column_label=>'Restbuchwert 2019'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204730074752706)
,p_db_column_name=>'RESTBUCHWERT_2020'
,p_display_order=>871
,p_column_identifier=>'EC'
,p_column_label=>'Restbuchwert 2020'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204897203752707)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>881
,p_column_identifier=>'ED'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(21204990963752708)
,p_db_column_name=>'FK_BAS_INV_INVENTARTYP'
,p_display_order=>891
,p_column_identifier=>'EE'
,p_column_label=>'Fk Bas Inv Inventartyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6354441440925365)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'156646'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ROWNUM:FK_MAIN_KEY:ID:Buchungstag_SATZ:Betrag:Fremdw\00E4hrungsbetrag:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:CNT_RE:SUM_REL_TEIL:PAYPAL_VORG:LINK_BUCHUNG:Name:Arti')
||'kelbezeichnung:ART:FK_IMP_BA_BEL:PK_IMP_BA_ALLG_BEL:BEZEICHNUNG:KENNZEICHEN:DATUM:DATUM_VERGEHEN:BETRAG:STEUERSATZ_BETRAG:NETTO:ZAHLUNGSART:LINK_BELEG:STEUERGRUNDBETRAG:RELEVANTER_TEILBETRAG:BEMERKUNG:PK_RECHNUNGSNUMMER:RECHNUNG:RECHNUNGSDATUM:ZEITRA'
||'UM_ZEITRAUM_RECHNUNGSBETRAG_NETTO:RE_MWST_BETRAG:RECHNUNGSBETRAG_BRUTTO:SKONTOBETRAG:SKONTOSATZ:RE_ZAHLUNG_ABGESCHL:VORSTEUER_BEZAHLT:STEUERENDABRECHNUNG:PK_FK_AUFTRAGGEBER:PROJEKT:VON:BIS:AKTUELLER_STUNDENSATZ:PSP_ELEMENT:RECHNUNG_GESTELLT:PR_ZAHLUN'
||'G_ABGESCHL:PROJEKT_ABGESCHLOSSEN_SATZ:ZAHL_ZAHL_NETTOBETRAG:RE_FK_STEUERSATZ:INVENTAR:ANSCHAFFUNGSDATUM:ANSCHAFFUNGSJAHR:ABSCHREIBUNGSDAUER:PREIS_NETTO:PREIS_BRUTTO:COMM:LIZENZNUMMER:ANFORDERUNGSCODE:KFZ_KENNZEICHEN:FAHRGESTELLNR:KTO_FREMDKTO_FK_STD_'
||'VERW_VERWENDUNGSZWECK:FK_STD_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KTO_VERWENDUNGSZWECK:KTO_KATEGORIE:KONTOTYP:FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:WAEHRUNG:FK_FK_PROJ_PROJEKT:WAEHRUNG_BETRAG:FK_BAS_KAT_KATEGORIE:FK_BEL_BELEG_ABLAGE:PK_R'
||'E_RECHNUNG:FK_BAS_RE_RECHNUNGSTYP:FK_STD_KTO_ZAHLUNGSART:PK_PROJ_PROJEKT:FK_KON_AUFTRAGGEBER:FK_KON_PROJEKTPARTNER_1:FK_KON_PROJEKTPARTNER_2:PR_PROJEKT:PK_INV_INVENTAR:INV_INVENTAR:RESTBUCHWERT_2018:RESTBUCHWERT_2019:RESTBUCHWERT_2020:FK_BAS_STEU_STE'
||'UER_SATZ:FK_BAS_INV_INVENTARTYP'
,p_break_on=>'Kontotyp'
,p_break_enabled_on=>'Kontotyp'
);
wwv_flow_api.component_end;
end;
/
