prompt --application/pages/page_00297
begin
--   Manifest
--     PAGE: 00297
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>297
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'rechnung_inp_beleg'
,p_alias=>'RECHNUNG_INP_BELEG_297'
,p_step_title=>'rechnung_inp_beleg'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201003100614'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6942349653380799)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_RE_RECHNUNG_BELEG'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6942728442380800)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:298:&SESSION.::&DEBUG.:RP:P298_PK_REL_RE_BEL:\#PK_REL_RE_BEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>8383047717772340
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6943922968380866)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6944321101380867)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6944768933380867)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6945094356380869)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6945558558380870)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22753210348612341)
,p_db_column_name=>'PK_REL_RE_RECHNUNG_BELEG'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Pk Rel Re Rechnung Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22753333184612342)
,p_db_column_name=>'FK_RE_RECHNUNG'
,p_display_order=>28
,p_column_identifier=>'J'
,p_column_label=>'Fk Re Rechnung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22753461027612343)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>38
,p_column_identifier=>'K'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(22753570627612344)
,p_db_column_name=>'FK_INP_BELEGE_POS_ALL'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Fk Inp Belege Pos All'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6966380854017214)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'84068'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:FK_INP_BELEGE_ALL:PK_REL_RE_RECHNUNG_BELEG:FK_RE_RECHNUNG:FK_BEL_BELEG:FK_INP_BELEGE_POS_ALL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6945981002380874)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6942349653380799)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:298:&SESSION.::&DEBUG.:298'
);
wwv_flow_api.component_end;
end;
/
