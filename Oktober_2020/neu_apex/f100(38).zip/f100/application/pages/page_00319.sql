prompt --application/pages/page_00319
begin
--   Manifest
--     PAGE: 00319
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>319
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'belege_lex_buchungen_modal'
,p_alias=>'BELEGE_LEX_BUCHUNGEN_319'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'belege_lex_buchungen_modal'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201009125247'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11228479937915741)
,p_plug_name=>'belege_lex_buchungen_modal1_lex'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(10,relation) sel,apex_item.checkbox(12, pk_rel_lex_kto_bel) pk_sel, pk_inp_belege_all, pk_rel_lex_kto_bel, habenkto, sollkto,',
'betrag, ust_kto, ust_text,buchungstext, belegnr, ll.nr, belegdat, relation, ll.datum_ok, ll.split_nr, ll.flg_split_buch, fk_main_key,ktr,kst, ',
'rel.cnt, ll.status, ktpl1.name name_hk, ktpl2.name name_sk, ktpl3.name name_ust',
'from t_inp_belege_all inp',
'  left join t_rel_lex_kto_bel bel on inp.pk_inp_belege_all = bel.fk_inp_belege_all',
'  left join t_lex_long ll on (ll.fk_Lex_relation_main = bel.fk_lex_relation or (ll.relation = bel.fk_lex_relation and  substr(relation,instr(relation,''/'',-1)+1, length(relation)) >0))',
'  left join (select count(*) cnt, fk_lex_relation from t_rel_lex_kto_bel group by fk_lex_relation) rel on (rel.fk_lex_relation = bel.fk_lex_relation) ',
'    left join T_LEX_KONTENPLAN_neu ktpl1 on ktpl1.nr = ll.habenkto',
'  left join T_LEX_KONTENPLAN_neu ktpl2 on ktpl2.nr = ll.sollkto',
'   left join T_LEX_KONTENPLAN_neu ktpl3 on ktpl3.nr = ll.ust_kto',
' where pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_comment=>'1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11228534717915741)
,p_name=>'belege_lex_buchungen_modal'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>12668853993307281
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11228931676915752)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11229289453915758)
,p_db_column_name=>'HABENKTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11229735116915760)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11230170339915760)
,p_db_column_name=>'BETRAG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11230522901915760)
,p_db_column_name=>'UST_KTO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Ust Kto'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11230907978915761)
,p_db_column_name=>'UST_TEXT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Ust Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11231361478915761)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11231757831915761)
,p_db_column_name=>'BELEGNR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Belegnr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11232165019915761)
,p_db_column_name=>'NR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11232550758915763)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950950702462070)
,p_db_column_name=>'RELATION'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17042018176073066)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17042139210073067)
,p_db_column_name=>'SEL'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17042259121073068)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17043629640073082)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17043696012073083)
,p_db_column_name=>'FLG_SPLIT_BUCH'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Flg Split Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38288975387208364)
,p_db_column_name=>'PK_SEL'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Pk Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38289111393208366)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>90
,p_column_identifier=>'R'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41085072326228370)
,p_db_column_name=>'KTR'
,p_display_order=>100
,p_column_identifier=>'S'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41085176290228371)
,p_db_column_name=>'KST'
,p_display_order=>110
,p_column_identifier=>'T'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087679573228396)
,p_db_column_name=>'CNT'
,p_display_order=>120
,p_column_identifier=>'U'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087962908228399)
,p_db_column_name=>'STATUS'
,p_display_order=>130
,p_column_identifier=>'V'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41088029943228400)
,p_db_column_name=>'NAME_HK'
,p_display_order=>140
,p_column_identifier=>'W'
,p_column_label=>'Name Hk'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41088147769228401)
,p_db_column_name=>'NAME_SK'
,p_display_order=>150
,p_column_identifier=>'X'
,p_column_label=>'Name Sk'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41088272614228402)
,p_db_column_name=>'NAME_UST'
,p_display_order=>160
,p_column_identifier=>'Y'
,p_column_label=>'Name Ust'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11234463758974963)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'126748'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_LEX_KTO_BEL:SEL:PK_SEL:CNT:PK_INP_BELEGE_ALL:HABENKTO:NAME_HK:SOLLKTO:NAME_SK:BETRAG:UST_KTO:NAME_UST:UST_TEXT:BUCHUNGSTEXT:DATUM_OK:BELEGNR:NR:BELEGDAT:RELATION:SPLIT_NR:FLG_SPLIT_BUCH:FK_MAIN_KEY:KTR:KST:STATUS:'
,p_sort_column_1=>'SPLIT_NR'
,p_sort_direction_1=>'ASC'
,p_break_on=>'PK_REL_LEX_KTO_BEL'
,p_break_enabled_on=>'PK_REL_LEX_KTO_BEL'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26622608293075569)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'bel_dat'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BELEGDAT'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BELEGDAT" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B3B3B3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26623023696075570)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26623491550075570)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'Geldtransit'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'HABENKTO'
,p_operator=>'='
,p_expr=>'1460'
,p_condition_sql=>' (case when ("HABENKTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26623831361075570)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'pk_sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CCE5FF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26624219747075570)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("SEL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26624673645075571)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'Geldtransit1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SOLLKTO'
,p_operator=>'='
,p_expr=>'1460'
,p_condition_sql=>' (case when ("SOLLKTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26625067517075571)
,p_report_id=>wwv_flow_api.id(11234463758974963)
,p_name=>'storno'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STATUS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11669737284735070)
,p_plug_name=>'belege_lex_buchungen_modal2_kto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(13,relbel.fk_main_key) sel,  pk_inp_belege_all, zus.*, ktoaus.datum_ok, ktoaus.jahr, ktoaus.monat, ktoaus.konto_auszug_type, to_char("Buchungstag", ''DD.MM.YYYY'') ch_Buchungstag , rel.cnt',
'from T_inp_belege_all inp',
'  left join t_rel_lex_kto_bel relbel on inp.pk_inp_belege_all = relbel.fk_inp_belege_all',
'  left join v_kto_konten_zus zus on zus.fk_main_key = relbel.fk_main_key',
'  left join (select count(*) cnt, fk_main_key from t_rel_lex_kto_bel group by fk_main_key) rel on rel.fk_main_key = relbel.fk_main_key',
'  left join t_rel_kto_konto_auszug_gir ktogir on ktogir.fk_main_key = zus.fk_main_key',
'  left join v_Kto_konto_auszug ktoaus on ktoaus.pk_kto_konto_auszug = ktogir.fk_kto_konto_auszug',
' where pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11669822731735071)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13110142007126611
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11669907793735072)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11670490656735078)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11670975277735082)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Fk Main Key'
,p_column_link=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.:RP:P199_FK_MAIN_KEY1,P199_SEL_DATE:#FK_MAIN_KEY#,#CH_BUCHUNGSTAG#'
,p_column_linktext=>'#FK_MAIN_KEY#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11671049392735083)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11671092752735084)
,p_db_column_name=>'Buchungstag'
,p_display_order=>100
,p_column_identifier=>'E'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11671243035735085)
,p_db_column_name=>'Betrag'
,p_display_order=>110
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672130712735094)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>200
,p_column_identifier=>'O'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672189148735095)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>210
,p_column_identifier=>'P'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672295313735096)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>220
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672413419735097)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>230
,p_column_identifier=>'R'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672549441735098)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>240
,p_column_identifier=>'S'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672618968735099)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>250
,p_column_identifier=>'T'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672761168735100)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>260
,p_column_identifier=>'U'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672798348735101)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>270
,p_column_identifier=>'V'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11672949469735102)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>280
,p_column_identifier=>'W'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11673050015735103)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>290
,p_column_identifier=>'X'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11673311807735106)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>320
,p_column_identifier=>'AA'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11673392621735107)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>330
,p_column_identifier=>'AB'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11673555148735108)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>340
,p_column_identifier=>'AC'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11673763896735110)
,p_db_column_name=>'KTO_BEZEICHNUNG'
,p_display_order=>360
,p_column_identifier=>'AE'
,p_column_label=>'Kto Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11715678968412461)
,p_db_column_name=>'IBAN'
,p_display_order=>370
,p_column_identifier=>'AF'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11715701008412462)
,p_db_column_name=>'BANK'
,p_display_order=>380
,p_column_identifier=>'AG'
,p_column_label=>'Bank'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13765023181091865)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>390
,p_column_identifier=>'AH'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13765323256091868)
,p_db_column_name=>'KONTO_AUSZUG_TYPE'
,p_display_order=>420
,p_column_identifier=>'AK'
,p_column_label=>'Konto Auszug Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13931255408257909)
,p_db_column_name=>'CH_BUCHUNGSTAG'
,p_display_order=>430
,p_column_identifier=>'AL'
,p_column_label=>'Ch Buchungstag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37713047296079780)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>440
,p_column_identifier=>'AM'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087017452228390)
,p_db_column_name=>'SEL'
,p_display_order=>450
,p_column_identifier=>'AN'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087158883228391)
,p_db_column_name=>'TBL'
,p_display_order=>460
,p_column_identifier=>'AO'
,p_column_label=>'Tbl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087713218228397)
,p_db_column_name=>'CNT'
,p_display_order=>470
,p_column_identifier=>'AP'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295139090264886)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>480
,p_column_identifier=>'AQ'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295209557264887)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>490
,p_column_identifier=>'AR'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295348270264888)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>500
,p_column_identifier=>'AS'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295443581264889)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>510
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295572882264890)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>520
,p_column_identifier=>'AU'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295662721264891)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>530
,p_column_identifier=>'AV'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295731029264892)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>540
,p_column_identifier=>'AW'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295858218264893)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>550
,p_column_identifier=>'AX'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51295960160264894)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>560
,p_column_identifier=>'AY'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296046755264895)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>570
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296169270264896)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>580
,p_column_identifier=>'BA'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296191453264897)
,p_db_column_name=>'JAHR'
,p_display_order=>590
,p_column_identifier=>'BB'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296323319264898)
,p_db_column_name=>'MONAT'
,p_display_order=>600
,p_column_identifier=>'BC'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26518613472361632)
,p_db_column_name=>'UMSATZART'
,p_display_order=>610
,p_column_identifier=>'BD'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26518712552361633)
,p_db_column_name=>'SALDO'
,p_display_order=>620
,p_column_identifier=>'BE'
,p_column_label=>'Saldo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26518816698361634)
,p_db_column_name=>'AUFTRAGGEBERKONTO'
,p_display_order=>630
,p_column_identifier=>'BF'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26518994474361635)
,p_db_column_name=>'AUFTRAGGEBER'
,p_display_order=>640
,p_column_identifier=>'BG'
,p_column_label=>'Auftraggeber'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26519074083361636)
,p_db_column_name=>'EMPFAENGER'
,p_display_order=>650
,p_column_identifier=>'BH'
,p_column_label=>'Empfaenger'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26519161666361637)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>660
,p_column_identifier=>'BI'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(26519247317361638)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>670
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11731225680418802)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131716'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KONTO_AUSZUG_TYPE:SEL:CNT:IBAN:PK_INP_BELEGE_ALL:BUCHUNGSTEXT:FK_MAIN_KEY:ID:Buchungstag:Betrag:DATUM_LEX_BUCHUNG_OK:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:WERTT_TAG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:KTO_BEZEICHNUNG:BANK:CH_BUCHUNGSTAG:TB'
||'L:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:FK_KTO_BANKKONTO:JAHR:MONAT:BUCHT_DATUM:BUCHT_JAHR:BUCHT_MONAT:DATUM_OK:FK_BAS_KAL_BUCHUNGSTAG:FK_STD_KTO_KONTOTYP:FREMDWAEHRUNGSBETRAG:'
||'WAEHRUNG:WERTT_DATUM:WERTT_JAHR:WERTT_MONAT::UMSATZART:SALDOKONTO:AUFTRAGGEBER:EMPFAENGER:FLG_KREDITKARTENBUCHUNG:FK_EIN_AUS'
,p_break_on=>'DATUM_OK:KONTO_AUSZUG_TYPE:0'
,p_break_enabled_on=>'DATUM_OK:KONTO_AUSZUG_TYPE:0'
,p_sum_columns_on_break=>'Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26627172176366233)
,p_report_id=>wwv_flow_api.id(11731225680418802)
,p_name=>'bel_dat'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'Buchungstag'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("Buchungstag" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B3B3B3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26627571287366234)
,p_report_id=>wwv_flow_api.id(11731225680418802)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_LEX_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11718172121412486)
,p_plug_name=>'belege_lex_buchungen_modal3_ktbl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(9,ktbl.id,''checked'') sel, pk_inp_belege_all,belegdatum, habenbetrag_eur, sollbetrag_eur, kontonummer, gegenkonto belegnummer, buchungsnummer, buchungsstatus, ktpl1.name bez_konto,',
'ktpl2.name bez_gegenkonto, ktbl.kst, ktbl.ktr, datum_steuer_ok, fk_lex_relation_sub, split_nr,  case when ktbl.split_nr = 0 then 0 ',
'       when mod(ktbl.split_nr,2) = 1 then 1 ',
'       else 2 end colo, ktbl.id',
'from t_inp_belege_all inp',
'  left join t_rel_lex_kto_bel bel on inp.pk_inp_belege_all = bel.fk_inp_belege_all',
'  left join t_lex_kontenblatt ktbl on ktbl.fk_lex_relation = bel.fk_lex_relation',
'  left join T_LEX_KONTENPLAN_neu ktpl1 on ktpl1.nr = ktbl.kontonummer',
'  left join T_LEX_KONTENPLAN_neu ktpl2 on ktpl2.nr = ktbl.gegenkonto',
' where pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11718238034412487)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>13158557309804027
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11718359966412488)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719299692412498)
,p_db_column_name=>'BELEGDATUM'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Belegdatum'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719416004412499)
,p_db_column_name=>'HABENBETRAG_EUR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Habenbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719577187412500)
,p_db_column_name=>'SOLLBETRAG_EUR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Sollbetrag Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719593541412501)
,p_db_column_name=>'KONTONUMMER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kontonummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719735870412502)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719814854412503)
,p_db_column_name=>'BUCHUNGSNUMMER'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Buchungsnummer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11719929881412504)
,p_db_column_name=>'BUCHUNGSSTATUS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Buchungsstatus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13805130471389875)
,p_db_column_name=>'BEZ_KONTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bez Konto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13805184852389876)
,p_db_column_name=>'BEZ_GEGENKONTO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Bez Gegenkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13805443507389878)
,p_db_column_name=>'KST'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Kst'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13805552495389879)
,p_db_column_name=>'KTR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Ktr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15054945927097980)
,p_db_column_name=>'SEL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f09]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(15055386773097985)
,p_db_column_name=>'DATUM_STEUER_OK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Datum Steuer Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17043521323073081)
,p_db_column_name=>'SPLIT_NR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Split Nr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17043858845073084)
,p_db_column_name=>'COLO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Colo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17043977964073085)
,p_db_column_name=>'ID'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Id'
,p_column_link=>'f?p=&APP_ID.:355:&SESSION.::&DEBUG.:RP:P355_ID:#ID#'
,p_column_linktext=>'#ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296518290264900)
,p_db_column_name=>'FK_LEX_RELATION_SUB'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Fk Lex Relation Sub'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12013400409203825)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134538'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:BELEGDATUM:HABENBETRAG_EUR:SOLLBETRAG_EUR:KONTONUMMER:BELEGNUMMER:BUCHUNGSNUMMER:BUCHUNGSSTATUS:BEZ_KONTO:BEZ_GEGENKONTO:KST:KTR:SEL:DATUM_STEUER_OK:SPLIT_NR:COLO:ID:FK_LEX_RELATION_SUB'
,p_sort_column_1=>'SPLIT_NR'
,p_sort_direction_1=>'ASC'
,p_break_on=>'BUCHUNGSNUMMER'
,p_break_enabled_on=>'BUCHUNGSNUMMER'
,p_sum_columns_on_break=>'HABENBETRAG_EUR:SOLLBETRAG_EUR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17124349586560575)
,p_report_id=>wwv_flow_api.id(12013400409203825)
,p_name=>'sp0'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLO'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("COLO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F5F5C1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17124766960560577)
,p_report_id=>wwv_flow_api.id(12013400409203825)
,p_name=>'sp1'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLO'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("COLO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E8E8D6'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17125116384560578)
,p_report_id=>wwv_flow_api.id(12013400409203825)
,p_name=>'sp2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'COLO'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("COLO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#C2C2BA'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(17123964571560574)
,p_report_id=>wwv_flow_api.id(12013400409203825)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHUNGSSTATUS'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>'"BUCHUNGSSTATUS" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14415506880889463)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct inp.pk_inp_belege_all ,inp.datum_buchung_ok, relbel.fk_main_key, ',
'inp_buch.pk_inp_belege_all inp_buch_pk_inp_belege_all,',
'inp_buch.datum_buchung_ok inp_buch_datum_buchung_ok, ',
' relbel_buch.fk_main_key relbel_buch_fk_main_key, relbel_buch.pk_rel_lex_kto_bel relbel_buch_pk_rel_lex_kto_bel, relbel.pk_rel_lex_kto_bel, relbel_buch.fk_lex_relation buch_fk_relation, relbel.fk_lex_relation,',
' case when inp.datum_buchung_ok is not null then 1 else 0 end + case when zus.datum_lex_buchung_ok is not null then 1 else 0 end + case when ll.datum_ok  is not null and (status is null or status = ''EBa'')  then 1 else 0  end ok',
', cnt_fk_main_Key',
', cnt_inp_belege_all',
', cnt_fk_lex_relation',
'from ',
'    (select * from t_rel_lex_kto_bel where (fk_inp_belege_all = :P319_PK_INP_BELEGE_ALL ) or (:P319_PK_INP_BELEGE_ALL is null and fk_main_key = :P319_FK_MAIN_KEY))  relbel',
'    left join t_rel_lex_kto_bel relbel_buch on relbel_buch.fk_main_key = relbel.fk_main_key',
'    left join t_inp_belege_all inp on inp.pk_inp_belege_all = relbel.fk_inp_belege_all',
'    left join t_inp_belege_all inp_buch on inp_buch.pk_inp_belege_all  = relbel_buch.fk_inp_belege_all',
'    left join t_lex_long ll on ll.relation = relbel.fk_lex_relation',
'    left join v_kto_konten_zus zus on zus.fk_main_key = relbel.fk_main_key',
'    left join v_cnt_rel_lex_fk_main_key relbel_zus on relbel_zus.fk_main_key = zus.fk_main_key',
'    left join v_cnt_rel_lex_inp_belege_all  relbel_inp on relbel_inp.fk_inp_belege_all = inp.pk_inp_belege_all',
'    left join v_cnt_rel_lex_relation  relbel_rel on relbel_rel.fk_lex_relation = ll.relation',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14415596456889464)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL:#RELBEL_BUCH_PK_REL_LEX_KTO_BEL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>15855915732281004
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14416769722889475)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>110
,p_column_identifier=>'A'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418214776889490)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>120
,p_column_identifier=>'B'
,p_column_label=>'Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.::P319_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418311610889491)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>130
,p_column_identifier=>'C'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418430785889492)
,p_db_column_name=>'INP_BUCH_PK_INP_BELEGE_ALL'
,p_display_order=>140
,p_column_identifier=>'D'
,p_column_label=>'Inp Buch Pk Inp Belege All'
,p_column_link=>'f?p=&APP_ID.:373:&SESSION.::&DEBUG.:373:P373_PK_INP_BELEGE_ALL_1,P373_SRC_PK_INP_BELEGE_ALL:#INP_BUCH_PK_INP_BELEGE_ALL#,#INP_BUCH_PK_INP_BELEGE_ALL#'
,p_column_linktext=>'#INP_BUCH_PK_INP_BELEGE_ALL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418566622889493)
,p_db_column_name=>'INP_BUCH_DATUM_BUCHUNG_OK'
,p_display_order=>150
,p_column_identifier=>'E'
,p_column_label=>'Inp Buch Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418657620889494)
,p_db_column_name=>'RELBEL_BUCH_FK_MAIN_KEY'
,p_display_order=>160
,p_column_identifier=>'F'
,p_column_label=>'Relbel Buch Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438538979335694)
,p_db_column_name=>'RELBEL_BUCH_PK_REL_LEX_KTO_BEL'
,p_display_order=>170
,p_column_identifier=>'G'
,p_column_label=>'Relbel Buch Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438629231335695)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>180
,p_column_identifier=>'H'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_link=>'f?p=&APP_ID.:319:&SESSION.::&DEBUG.:RP:P319_PK_REL_LEX_KTO_BEL,P319_PK_INP_BELEGE_ALL,P319_FK_MAIN_KEY_SEL,P319_FK_INP_BELEGE_ALL_SEL,P319_FK_RELATION_SEL:#PK_REL_LEX_KTO_BEL#,#PK_INP_BELEGE_ALL#,#FK_MAIN_KEY#,#PK_INP_BELEGE_ALL#,#FK_RELATION#'
,p_column_linktext=>'#PK_REL_LEX_KTO_BEL#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16741938112343563)
,p_db_column_name=>'BUCH_FK_RELATION'
,p_display_order=>200
,p_column_identifier=>'J'
,p_column_label=>'Buch Fk Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(41087860696228398)
,p_db_column_name=>'OK'
,p_display_order=>210
,p_column_identifier=>'K'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43275376754786700)
,p_db_column_name=>'CNT_FK_MAIN_KEY'
,p_display_order=>220
,p_column_identifier=>'L'
,p_column_label=>'Cnt Fk Main Key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(43275413098786701)
,p_db_column_name=>'CNT_INP_BELEGE_ALL'
,p_display_order=>230
,p_column_identifier=>'M'
,p_column_label=>'Cnt Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51404707747478009)
,p_db_column_name=>'FK_LEX_RELATION'
,p_display_order=>240
,p_column_identifier=>'O'
,p_column_label=>'Fk Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51404850776478010)
,p_db_column_name=>'CNT_FK_LEX_RELATION'
,p_display_order=>250
,p_column_identifier=>'P'
,p_column_label=>'Cnt Fk Lex Relation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14434418219232656)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'158748'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OK:PK_INP_BELEGE_ALL:FK_MAIN_KEY:INP_BUCH_PK_INP_BELEGE_ALL:RELBEL_BUCH_PK_REL_LEX_KTO_BEL:PK_REL_LEX_KTO_BEL:BUCH_FK_RELATION:CNT_FK_MAIN_KEY:CNT_INP_BELEGE_ALL:FK_LEX_RELATION:CNT_FK_LEX_RELATION:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26131613704582622)
,p_report_id=>wwv_flow_api.id(14434418219232656)
,p_name=>'lex'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_LEX_RELATION'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_LEX_RELATION" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26132044805582623)
,p_report_id=>wwv_flow_api.id(14434418219232656)
,p_name=>'fk_main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26132422816582623)
,p_report_id=>wwv_flow_api.id(14434418219232656)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'OK'
,p_operator=>'='
,p_expr=>'3'
,p_condition_sql=>' (case when ("OK" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(26132846654582623)
,p_report_id=>wwv_flow_api.id(14434418219232656)
,p_name=>'inp'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'PK_INP_BELEGE_ALL'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("PK_INP_BELEGE_ALL" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#E8E8E8'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14418684720889495)
,p_plug_name=>'belege_lex_buchungen_modal2_inp'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inp.pk_inp_belege_all, inp.bel_datum, inp.brutto_betrag, ktokat_kategorie, datum_buchung_ok, datum_beleg_pos_ok, zahl_art_name, vinp.proj_projekt, vinp.proj_projekt_art, vinp.verwendungszweck, vbel_inventar, vinp.ort, vinp.land, inp.bezeichnun'
||'g, inp.persoenlich_vor_ort, ',
'inp.comm_sonstiges, inp.comm_produkte, vinp.belegnummer',
'from t_inp_belege_all inp',
'  left join v_inp_belege_all vinp on inp.pk_inp_belege_all = vinp.pk_inp_belege_all',
'  ',
'',
'',
' where inp.pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(14418852113889496)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15859171389281036
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14418881674889497)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14436413902335673)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>270
,p_column_identifier=>'B'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14437645273335685)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>280
,p_column_identifier=>'C'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14437696970335686)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>290
,p_column_identifier=>'D'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14437808289335687)
,p_db_column_name=>'KTOKAT_KATEGORIE'
,p_display_order=>300
,p_column_identifier=>'E'
,p_column_label=>'Ktokat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14437976565335688)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>310
,p_column_identifier=>'F'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438060737335689)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>320
,p_column_identifier=>'G'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438163904335690)
,p_db_column_name=>'ZAHL_ART_NAME'
,p_display_order=>330
,p_column_identifier=>'H'
,p_column_label=>'Zahl Art Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438268433335691)
,p_db_column_name=>'PROJ_PROJEKT'
,p_display_order=>340
,p_column_identifier=>'I'
,p_column_label=>'Proj Projekt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438300879335692)
,p_db_column_name=>'PROJ_PROJEKT_ART'
,p_display_order=>350
,p_column_identifier=>'J'
,p_column_label=>'Proj Projekt Art'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14438438057335693)
,p_db_column_name=>'VBEL_INVENTAR'
,p_display_order=>360
,p_column_identifier=>'K'
,p_column_label=>'Vbel Inventar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17044067393073086)
,p_db_column_name=>'ORT'
,p_display_order=>370
,p_column_identifier=>'L'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17044175584073087)
,p_db_column_name=>'LAND'
,p_display_order=>380
,p_column_identifier=>'M'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(35972120969425061)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>390
,p_column_identifier=>'N'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(37713172609079781)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>410
,p_column_identifier=>'P'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(38288689624208362)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>420
,p_column_identifier=>'Q'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42142010782766304)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>430
,p_column_identifier=>'R'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51296460751264899)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>440
,p_column_identifier=>'S'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(14444625898402700)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'158850'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:VERWENDUNGSZWECK:BEL_DATUM:BRUTTO_BETRAG:KTOKAT_KATEGORIE:DATUM_BUCHUNG_OK:DATUM_BELEG_POS_OK:ZAHL_ART_NAME:PROJ_PROJEKT:PROJ_PROJEKT_ART:VBEL_INVENTAR:ORT:LAND:BEZEICHNUNG:COMM_SONSTIGES:COMM_PRODUKTE:BELEGNUMMER:PERSOENLICH_VOR_OR'
||'T'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(44080176198976499)
,p_report_id=>wwv_flow_api.id(14444625898402700)
,p_name=>'bel_dat'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BEL_DATUM'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("BEL_DATUM" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B3B3B3'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(44080558872976499)
,p_report_id=>wwv_flow_api.id(14444625898402700)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14438732430335696)
,p_plug_name=>'upd_reason'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P319_PK_REL_LEX_KTO_BEL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13891264970241164)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_parent_plug_id=>wwv_flow_api.id(14438732430335696)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox2(8,pk_rel_kto_kont_buch_kont_buch) sel_pk,',
'rel.*',
'from (',
'select pk_rel_kto_kont_buch_kont_buch, zus1.buchungstext buchtext1,inp1.bezeichnung bez1,  ',
'    inp1.pk_inp_belege_all pk_inp_belege_all1, relkto.fk_kto_konto_buch1, case when inp1.pk_inp_belege_all = :P319_pk_inp_belege_all then 1 else 0 end sel, ',
'    round(inp1.brutto_betrag,2) brutto_betrag, round(zus1."Betrag",2) "Betrag", inp1.datum_buchung_ok,',
'll1.habenkto, ll1.sollkto, ll1.betrag,ll1.relation, ll1.belegdat,',
'ktpl11.name habenkto_name, ktpl12.name sollkto_Name ,',
'          round((zus1."Betrag"*1.5/100),2) Betrag_15,',
'                                    round((zus1."Betrag"*1.75/100),2) Betrag_175,',
'                                 round( zus1."Betrag"*100/1.5,2) betrag_100_15,',
'                                 round( zus1."Betrag"*100/1.75) betrag_100_175,',
'                                 zus1.Kontotyp,',
'                                 zus1.iban,',
'                                 relkto.bemerkung',
'    ,',
'    reltype.std_name reltype',
'from  (select * from t_inp_belege_all ',
'       where pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null',
'      ) inp ',
'left join t_rel_lex_kto_bel relbel on inp.pk_inp_belege_all = relbel.fk_inp_belege_all',
'left join (select * from t_rel_kto_kont_buch_kont_buch relkto ',
unistr('           --where  instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0'),
'          ) relkto on relkto.fk_kto_konto_buch1 = relbel.fk_main_key or  relkto.fk_kto_konto_buch2 = relbel.fk_main_key ',
'left join v_kto_konten_zus zus1 on zus1.fk_main_key = relkto.fk_kto_konto_buch1',
'',
'left join t_rel_lex_kto_bel relkto1 on relkto1.fk_main_key = relkto.fk_kto_konto_buch1',
'',
'left join t_inp_belege_all inp1 on relkto1.fk_inp_belege_all = inp1.pk_inp_belege_all',
'left join t_lex_long ll1 on ll1.relation =  relkto1.fk_lex_relation',
'  left join T_LEX_KONTENPLAN_neu ktpl11 on ktpl11.nr = ll1.habenkto',
'  left join T_LEX_KONTENPLAN_neu ktpl12 on ktpl12.nr =ll1.sollkto',
'  left join (select * from t_std where fk_std_group  = 281) reltype on relkto.fk_std_type = reltype.std_value',
'union',
'',
'select pk_rel_kto_kont_buch_kont_buch, zus2.buchungstext buchtedext2,  inp2.bezeichnung bez2, inp2.pk_inp_belege_all pk_inp_belege_all2, relkto.fk_kto_konto_buch2,case when inp2.pk_inp_belege_all = :P319_pk_inp_belege_all then 1 else 0 end sel, round'
||'(inp2.brutto_betrag,2) brutto_betrag, round(zus2."Betrag",2) "Betrag", inp2.datum_buchung_ok,',
'll2.habenkto, ll2.sollkto, ll2.betrag, ll2.relation, ll2.belegdat,',
'',
'ktpl21.name habenkto_name, ktpl22.name sollkto_Name ,',
' round((zus2."Betrag"*1.5/100),2) Betrag_15,',
'                                    round((zus2."Betrag"*1.75/100),2) Betrag_175,',
'                                 round( zus2."Betrag"*100/1.5,2) betrag_100_15,',
'                                 round( zus2."Betrag"*100/1.75) betrag_100_175,',
'                                 zus2.Kontotyp,',
'                                 zus2.iban,',
'                                 relkto.bemerkung,',
'    reltype.std_name reltype',
'from  (select * from t_inp_belege_all',
'       where pk_inp_belege_all = :P319_PK_INP_BELeGE_ALL or :P319_PK_INP_BELeGE_ALL is null',
'      ) inp ',
'left join t_rel_lex_kto_bel relbel on inp.pk_inp_belege_all = relbel.fk_inp_belege_all',
'left join (select * from t_rel_kto_kont_buch_kont_buch relkto',
unistr('           --where  instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'')>0'),
'          ) relkto on relkto.fk_kto_konto_buch1 = relbel.fk_main_key or  relkto.fk_kto_konto_buch2 = relbel.fk_main_key ',
'left join v_kto_konten_zus zus1 on zus1.fk_main_key = relkto.fk_kto_konto_buch1',
'',
'left join v_kto_konten_zus zus2 on zus2.fk_main_key = relkto.fk_kto_konto_buch2',
'',
'left join t_rel_lex_kto_bel relkto2 on relkto2.fk_main_key = relkto.fk_kto_konto_buch2',
'',
'left join t_inp_belege_all inp2 on relkto2.fk_inp_belege_all = inp2.pk_inp_belege_all',
'left join t_lex_long ll2 on ll2.relation =   relkto2.fk_lex_relation',
'  left join T_LEX_KONTENPLAN_neu ktpl21 on ktpl21.nr = ll2.habenkto',
'  left join T_LEX_KONTENPLAN_neu ktpl22 on ktpl22.nr = ll2.sollkto',
'      left join (select * from t_std where fk_std_group  = 281) reltype on relkto.fk_std_type = reltype.std_value',
')',
'  rel'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13891349673241165)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>15331668948632705
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892515571241177)
,p_db_column_name=>'BUCHTEXT1'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchtext1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892729259241179)
,p_db_column_name=>'BEZ1'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bez1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13892941957241181)
,p_db_column_name=>'PK_INP_BELEGE_ALL1'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Pk Inp Belege All1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893284468241185)
,p_db_column_name=>'SEL'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Sel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893480115241186)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893491894241187)
,p_db_column_name=>'Betrag'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13893626031241188)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13931281225257910)
,p_db_column_name=>'HABENKTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Habenkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950045762462061)
,p_db_column_name=>'SOLLKTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sollkto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950118308462062)
,p_db_column_name=>'BETRAG'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950278972462063)
,p_db_column_name=>'HABENKTO_NAME'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Habenkto Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950298109462064)
,p_db_column_name=>'SOLLKTO_NAME'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sollkto Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950445019462065)
,p_db_column_name=>'BETRAG_15'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Betrag 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950546671462066)
,p_db_column_name=>'BETRAG_175'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Betrag 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950584601462067)
,p_db_column_name=>'BETRAG_100_15'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Betrag 100 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950684689462068)
,p_db_column_name=>'BETRAG_100_175'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Betrag 100 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13950799935462069)
,p_db_column_name=>'RELATION'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951048710462071)
,p_db_column_name=>'BELEGDAT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Belegdat'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951164597462072)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13951664542462077)
,p_db_column_name=>'IBAN'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14288140176362610)
,p_db_column_name=>'SEL_PK'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f08]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14415308815889461)
,p_db_column_name=>'RELTYPE'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Reltype'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217329455063243)
,p_db_column_name=>'PK_REL_KTO_KONT_BUCH_KONT_BUCH'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Pk Rel Kto Kont Buch Kont Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217428702063244)
,p_db_column_name=>'FK_KTO_KONTO_BUCH1'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fk Kto Konto Buch1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217584922063245)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13914715473702258)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'153551'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL_PK:RELTYPE:BUCHTEXT1:BEZ1:PK_INP_BELEGE_ALL1:SEL:DATUM_BUCHUNG_OK:Betrag:BRUTTO_BETRAG:HABENKTO:SOLLKTO:BETRAG:HABENKTO_NAME:SOLLKTO_NAME:BETRAG_15:BETRAG_175:BETRAG_100_15:BETRAG_100_175:RELATION:BELEGDAT:BEMERKUNG:IBAN::PK_REL_KTO_KONT_BUCH_KON'
||'T_BUCH:FK_KTO_KONTO_BUCH1:KONTOTYP'
,p_sort_column_1=>'SEL'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_break_enabled_on=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_sum_columns_on_break=>'BRUTTO_BETRAG:Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14429371857072256)
,p_report_id=>wwv_flow_api.id(13914715473702258)
,p_name=>'buch_ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_BUCHUNG_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_BUCHUNG_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(14429736145072258)
,p_report_id=>wwv_flow_api.id(13914715473702258)
,p_name=>'sel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'SEL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("SEL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99CCFF'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16604549792482405)
,p_plug_name=>'add_zuord'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P319_PK_REL_LEX_KTO_BEL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16860829093689672)
,p_plug_name=>'show_inp_beleg_pos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16862039049689684)
,p_plug_name=>'belege_lex_buchungen_modal1_ausl'
,p_parent_plug_id=>wwv_flow_api.id(16860829093689672)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inp1.* ,',
'''<a href="'' || APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || V(''APP_ID'') || '':252:'' || V(''APP_SESSION'') || ''::NO:RP:P252_fK_inp_belege_pos_all,P252_fK_inp_belege_all,P252_fk_imp_ba_bel,p252_PK_REL_LEX_KTO_BEL:'' ||',
'                                     inp1.PK_inp_belege_pos_all || '','' || inp1.fk_inp_belege_all || '','' || :P229_FK_imp_ba_bel  , P_CHECKSUM_TYPE => ''SESSION'') || ''">'' || pk_inp_belege_pos_all || ''</a>'' buchungs_zuord,',
' s_netto_betrag,',
' s_mwst,',
' s_brutto_betrag,',
' s_betrageur,',
' s_kto_betrag,',
' apex_item.checkbox2(11, pk_inp_belege_pos_all) sel,',
'  kat.Kategorie',
'from t_INP_BELEGE_POS_ALL inp1',
' left join (',
'             select fk_inp_belege_pos_all, sum(netto_betrag) s_netto_betrag, sum(mwst_betrag) s_mwst, sum(brutto_betrag) s_brutto_betrag, sum(betrageur) s_betrageur, sum(kto_betrag) s_kto_betrag',
'             from v_rel_lex',
'             group by fk_inp_belege_pos_all',
'          ) v_lex on v_lex.fk_inp_belege_pos_all = inp1.pk_inp_belege_pos_all',
' left join t_bas_kat_kategorie kat on kat.pk_bas_kat_kategorie = inp1.FK_bas_kat_Kategorie',
'where fk_inp_belege_all = :P319_PK_INP_BELEGE_ALL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16862130558689685)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>18302449834081225
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16863078381689694)
,p_db_column_name=>'BRUTTO_BETRAG'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17036563757073061)
,p_db_column_name=>'PK_INP_BELEGE_POS_ALL'
,p_display_order=>100
,p_column_identifier=>'Z'
,p_column_label=>'Pk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17036614245073062)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>110
,p_column_identifier=>'AA'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17036695563073063)
,p_db_column_name=>'FK_LEX_BUCHUNG'
,p_display_order=>120
,p_column_identifier=>'AB'
,p_column_label=>'Fk Lex Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17037525055073071)
,p_db_column_name=>'BELEGNUMMER'
,p_display_order=>200
,p_column_identifier=>'AJ'
,p_column_label=>'Belegnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17037679163073072)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>210
,p_column_identifier=>'AK'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17037936294073075)
,p_db_column_name=>'BEL_DATUM'
,p_display_order=>240
,p_column_identifier=>'AN'
,p_column_label=>'Bel Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17037994922073076)
,p_db_column_name=>'VON'
,p_display_order=>250
,p_column_identifier=>'AO'
,p_column_label=>'Von'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038109878073077)
,p_db_column_name=>'BIS'
,p_display_order=>260
,p_column_identifier=>'AP'
,p_column_label=>'Bis'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038245034073078)
,p_db_column_name=>'NETTO_BETRAG'
,p_display_order=>270
,p_column_identifier=>'AQ'
,p_column_label=>'Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038436943073080)
,p_db_column_name=>'MWST_BETRAG'
,p_display_order=>290
,p_column_identifier=>'AS'
,p_column_label=>'Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038591332073082)
,p_db_column_name=>'STEUERNUMMER'
,p_display_order=>310
,p_column_identifier=>'AU'
,p_column_label=>'Steuernummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038751843073083)
,p_db_column_name=>'UMRECHNUNGSKURS'
,p_display_order=>320
,p_column_identifier=>'AV'
,p_column_label=>'Umrechnungskurs'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038801001073084)
,p_db_column_name=>'COMM_REST_BELEG'
,p_display_order=>330
,p_column_identifier=>'AW'
,p_column_label=>'Comm Rest Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038951074073085)
,p_db_column_name=>'COMM_TEL_BELEG'
,p_display_order=>340
,p_column_identifier=>'AX'
,p_column_label=>'Comm Tel Beleg'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17038984995073086)
,p_db_column_name=>'COMM_PRODUKTE'
,p_display_order=>350
,p_column_identifier=>'AY'
,p_column_label=>'Comm Produkte'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039270051073088)
,p_db_column_name=>'COMM_SONSTIGES'
,p_display_order=>370
,p_column_identifier=>'BA'
,p_column_label=>'Comm Sonstiges'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039363270073089)
,p_db_column_name=>'BELEG'
,p_display_order=>380
,p_column_identifier=>'BB'
,p_column_label=>'Beleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039448877073090)
,p_db_column_name=>'ZAHLUNGSBELEG'
,p_display_order=>390
,p_column_identifier=>'BC'
,p_column_label=>'Zahlungsbeleg'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039529232073091)
,p_db_column_name=>'LITER'
,p_display_order=>400
,p_column_identifier=>'BD'
,p_column_label=>'Liter'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039719982073093)
,p_db_column_name=>'FK_CALC_STATE'
,p_display_order=>420
,p_column_identifier=>'BF'
,p_column_label=>'Fk Calc State'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039795088073094)
,p_db_column_name=>'FK_CALC_STATE_EUR'
,p_display_order=>430
,p_column_identifier=>'BG'
,p_column_label=>'Fk Calc State Eur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17039961953073095)
,p_db_column_name=>'FK_CALC_STATE_FRMDW'
,p_display_order=>440
,p_column_identifier=>'BH'
,p_column_label=>'Fk Calc State Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040021521073096)
,p_db_column_name=>'FRMDW_NETTO_BETRAG'
,p_display_order=>450
,p_column_identifier=>'BI'
,p_column_label=>'Frmdw Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040349138073099)
,p_db_column_name=>'FRMDW_MWST_BETRAG'
,p_display_order=>480
,p_column_identifier=>'BL'
,p_column_label=>'Frmdw Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040466230073100)
,p_db_column_name=>'FRMDW_BRUTTO_BETRAG'
,p_display_order=>490
,p_column_identifier=>'BM'
,p_column_label=>'Frmdw Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040545472073101)
,p_db_column_name=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_display_order=>500
,p_column_identifier=>'BN'
,p_column_label=>'Frmdw Brutto Incl Trinkg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040582559073102)
,p_db_column_name=>'DATUM_OK_BUCH'
,p_display_order=>510
,p_column_identifier=>'BO'
,p_column_label=>'Datum Ok Buch'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17040914476073105)
,p_db_column_name=>'BUCHUNGS_ZUORD'
,p_display_order=>540
,p_column_identifier=>'BR'
,p_column_label=>'Buchungs Zuord'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041033630073106)
,p_db_column_name=>'S_NETTO_BETRAG'
,p_display_order=>550
,p_column_identifier=>'BS'
,p_column_label=>'S Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041087852073107)
,p_db_column_name=>'S_MWST'
,p_display_order=>560
,p_column_identifier=>'BT'
,p_column_label=>'S Mwst'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041247371073108)
,p_db_column_name=>'S_BRUTTO_BETRAG'
,p_display_order=>570
,p_column_identifier=>'BU'
,p_column_label=>'S Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041370474073109)
,p_db_column_name=>'S_BETRAGEUR'
,p_display_order=>580
,p_column_identifier=>'BV'
,p_column_label=>'S Betrageur'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041471567073110)
,p_db_column_name=>'S_KTO_BETRAG'
,p_display_order=>590
,p_column_identifier=>'BW'
,p_column_label=>'S Kto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17041533520073061)
,p_db_column_name=>'SEL'
,p_display_order=>600
,p_column_identifier=>'BX'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51292958476264864)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>610
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293075977264865)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>620
,p_column_identifier=>'CA'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293157517264866)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>630
,p_column_identifier=>'CB'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293208961264867)
,p_db_column_name=>'FK_STD_KTO_ZAHLUNGSART'
,p_display_order=>640
,p_column_identifier=>'CC'
,p_column_label=>'Fk Std Kto Zahlungsart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293319877264868)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>650
,p_column_identifier=>'CD'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293454648264869)
,p_db_column_name=>'FK_INV_INVENTAR'
,p_display_order=>660
,p_column_identifier=>'CE'
,p_column_label=>'Fk Inv Inventar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293482814264870)
,p_db_column_name=>'FK_PROJ_PROJEKT'
,p_display_order=>670
,p_column_identifier=>'CF'
,p_column_label=>'Fk Proj Projekt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293679787264871)
,p_db_column_name=>'FK_ADR_LAND'
,p_display_order=>680
,p_column_identifier=>'CG'
,p_column_label=>'Fk Adr Land'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293715149264872)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>690
,p_column_identifier=>'CH'
,p_column_label=>'Fk Adr City'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293799145264873)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ'
,p_display_order=>700
,p_column_identifier=>'CI'
,p_column_label=>'Fk Bas Steu Steuer Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293967586264874)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG'
,p_display_order=>710
,p_column_identifier=>'CJ'
,p_column_label=>'Fk Bas Mon Waehrung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51293995178264875)
,p_db_column_name=>'COMM_BEGRUENDUNG'
,p_display_order=>720
,p_column_identifier=>'CK'
,p_column_label=>'Comm Begruendung'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294164180264876)
,p_db_column_name=>'ZAPFSAEULE'
,p_display_order=>730
,p_column_identifier=>'CL'
,p_column_label=>'Zapfsaeule'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294271908264877)
,p_db_column_name=>'FK_BAS_MON_FRMDW'
,p_display_order=>740
,p_column_identifier=>'CM'
,p_column_label=>'Fk Bas Mon Frmdw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294367207264878)
,p_db_column_name=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_display_order=>750
,p_column_identifier=>'CN'
,p_column_label=>'Fk Bas Mon Frmdw Mwst Satz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294397360264879)
,p_db_column_name=>'FK_LOC_LOCATION'
,p_display_order=>760
,p_column_identifier=>'CO'
,p_column_label=>'Fk Loc Location'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294523075264880)
,p_db_column_name=>'PERSOENLICH_VOR_ORT'
,p_display_order=>770
,p_column_identifier=>'CP'
,p_column_label=>'Persoenlich Vor Ort'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294581591264881)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>780
,p_column_identifier=>'CQ'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294752231264882)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>790
,p_column_identifier=>'CR'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294826402264883)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>800
,p_column_identifier=>'CS'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294978227264884)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>810
,p_column_identifier=>'CT'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51294985136264885)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>820
,p_column_identifier=>'CU'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217688011063246)
,p_db_column_name=>'AZ_O_PAUSE'
,p_display_order=>830
,p_column_identifier=>'CV'
,p_column_label=>'Az O Pause'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217720078063247)
,p_db_column_name=>'AZ_M_PAUSE'
,p_display_order=>840
,p_column_identifier=>'CW'
,p_column_label=>'Az M Pause'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217870730063248)
,p_db_column_name=>'ANWESENHEITSZEIT'
,p_display_order=>850
,p_column_identifier=>'CX'
,p_column_label=>'Anwesenheitszeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25217978505063249)
,p_db_column_name=>'AZ_MANUELL_GEPFLEGT'
,p_display_order=>860
,p_column_identifier=>'CY'
,p_column_label=>'Az Manuell Gepflegt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25218085651063250)
,p_db_column_name=>'AZ_COMM'
,p_display_order=>870
,p_column_identifier=>'CZ'
,p_column_label=>'Az Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25324885645482801)
,p_db_column_name=>'BELEG_UHRZEIT'
,p_display_order=>880
,p_column_identifier=>'DA'
,p_column_label=>'Beleg Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25324965934482802)
,p_db_column_name=>'VON_UHRZEIT'
,p_display_order=>890
,p_column_identifier=>'DB'
,p_column_label=>'Von Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325057324482803)
,p_db_column_name=>'BIS_UHRZEIT'
,p_display_order=>900
,p_column_identifier=>'DC'
,p_column_label=>'Bis Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325101865482804)
,p_db_column_name=>'PARKZEIT'
,p_display_order=>910
,p_column_identifier=>'DD'
,p_column_label=>'Parkzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325214946482805)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>920
,p_column_identifier=>'DE'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325373200482806)
,p_db_column_name=>'AZ_STUNDENZAHL'
,p_display_order=>930
,p_column_identifier=>'DF'
,p_column_label=>'Az Stundenzahl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325464851482807)
,p_db_column_name=>'AZ_UEBERSTUNDEN'
,p_display_order=>940
,p_column_identifier=>'DG'
,p_column_label=>'Az Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325582457482808)
,p_db_column_name=>'AZ_SOLLSTUNDEN'
,p_display_order=>950
,p_column_identifier=>'DH'
,p_column_label=>'Az Sollstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325686210482809)
,p_db_column_name=>'FAHRZEIT'
,p_display_order=>960
,p_column_identifier=>'DI'
,p_column_label=>'Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325740505482810)
,p_db_column_name=>'FK_STD_REISE_FAHRZEIT_EINHEIT'
,p_display_order=>970
,p_column_identifier=>'DJ'
,p_column_label=>'Fk Std Reise Fahrzeit Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325828435482811)
,p_db_column_name=>'FK_WORK_STUNDENSATZ'
,p_display_order=>980
,p_column_identifier=>'DK'
,p_column_label=>'Fk Work Stundensatz'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25325996485482812)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_UEBERSTUNDEN'
,p_display_order=>990
,p_column_identifier=>'DL'
,p_column_label=>'Fk Work Stundensatz Ueberstunden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326046869482813)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_WOCHENENDE'
,p_display_order=>1000
,p_column_identifier=>'DM'
,p_column_label=>'Fk Work Stundensatz Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326156365482814)
,p_db_column_name=>'FK_WF_WORKFLOW'
,p_display_order=>1010
,p_column_identifier=>'DN'
,p_column_label=>'Fk Wf Workflow'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326274045482815)
,p_db_column_name=>'FK_WF_WORKFLOW_STEP'
,p_display_order=>1020
,p_column_identifier=>'DO'
,p_column_label=>'Fk Wf Workflow Step'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326347388482816)
,p_db_column_name=>'FK_WORK_STUNDENSATZ_FAHRZEIT'
,p_display_order=>1030
,p_column_identifier=>'DP'
,p_column_label=>'Fk Work Stundensatz Fahrzeit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326465111482817)
,p_db_column_name=>'FK_BAS_MON_WAEHRUNG_SOLL'
,p_display_order=>1040
,p_column_identifier=>'DQ'
,p_column_label=>'Fk Bas Mon Waehrung Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326573126482818)
,p_db_column_name=>'FK_BAS_STEU_STEUER_SATZ_SOLL'
,p_display_order=>1050
,p_column_identifier=>'DR'
,p_column_label=>'Fk Bas Steu Steuer Satz Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326684720482819)
,p_db_column_name=>'SOLL_NETTO_BETRAG'
,p_display_order=>1060
,p_column_identifier=>'DS'
,p_column_label=>'Soll Netto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326791502482820)
,p_db_column_name=>'SOLL_MWST_BETRAG'
,p_display_order=>1070
,p_column_identifier=>'DT'
,p_column_label=>'Soll Mwst Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326872460482821)
,p_db_column_name=>'SOLL_BRUTTO_BETRAG'
,p_display_order=>1080
,p_column_identifier=>'DU'
,p_column_label=>'Soll Brutto Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25326944418482822)
,p_db_column_name=>'FK_BAS_MON_UMRECHNUNGSKURS_SOLL'
,p_display_order=>1090
,p_column_identifier=>'DV'
,p_column_label=>'Fk Bas Mon Umrechnungskurs Soll'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327093681482823)
,p_db_column_name=>'ANZAHL_ZUGEHOERIGE_REAL_BELEGE'
,p_display_order=>1100
,p_column_identifier=>'DW'
,p_column_label=>'Anzahl Zugehoerige Real Belege'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327158843482824)
,p_db_column_name=>'MENGE'
,p_display_order=>1110
,p_column_identifier=>'DX'
,p_column_label=>'Menge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327283553482825)
,p_db_column_name=>'FK_STD_INP_MENGE_EINHEIT'
,p_display_order=>1120
,p_column_identifier=>'DY'
,p_column_label=>'Fk Std Inp Menge Einheit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327398040482826)
,p_db_column_name=>'POSITION'
,p_display_order=>1130
,p_column_identifier=>'DZ'
,p_column_label=>'Position'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327491378482827)
,p_db_column_name=>'PREIS_EINZEL'
,p_display_order=>1140
,p_column_identifier=>'EA'
,p_column_label=>'Preis Einzel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327597223482828)
,p_db_column_name=>'PREIS_GESAMT'
,p_display_order=>1150
,p_column_identifier=>'EB'
,p_column_label=>'Preis Gesamt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327653901482829)
,p_db_column_name=>'GEZAHLT_AM'
,p_display_order=>1160
,p_column_identifier=>'EC'
,p_column_label=>'Gezahlt Am'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327761834482830)
,p_db_column_name=>'FK_WH_ART_ARTIKEL'
,p_display_order=>1170
,p_column_identifier=>'ED'
,p_column_label=>'Fk Wh Art Artikel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327877606482831)
,p_db_column_name=>'BESTELLDATUM'
,p_display_order=>1180
,p_column_identifier=>'EE'
,p_column_label=>'Bestelldatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25327978703482832)
,p_db_column_name=>'LIEFERDATUM'
,p_display_order=>1190
,p_column_identifier=>'EF'
,p_column_label=>'Lieferdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25328097438482833)
,p_db_column_name=>'RECHNUNGSDATUM'
,p_display_order=>1200
,p_column_identifier=>'EG'
,p_column_label=>'Rechnungsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25328161100482834)
,p_db_column_name=>'FK_STEU_STEUER_JAHR'
,p_display_order=>1210
,p_column_identifier=>'EH'
,p_column_label=>'Fk Steu Steuer Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25328294916482835)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>1220
,p_column_identifier=>'EI'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25328347095482836)
,p_db_column_name=>'FK_STD_STEU_STEUERERKLAERUNG_ANLAGE'
,p_display_order=>1230
,p_column_identifier=>'EJ'
,p_column_label=>'Fk Std Steu Steuererklaerung Anlage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(25328498180482837)
,p_db_column_name=>'ZEILE_EINKOMMENSSTEUERERKLAERUNG'
,p_display_order=>1240
,p_column_identifier=>'EK'
,p_column_label=>'Zeile Einkommenssteuererklaerung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(17069401785074063)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'185098'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATUM_OK_BUCH:SEL:S_MWST:S_BRUTTO_BETRAG:S_BETRAGEUR:S_KTO_BETRAG:BRUTTO_BETRAG:PK_INP_BELEGE_POS_ALL:FK_INP_BELEGE_ALL:FK_LEX_BUCHUNG:BEZEICHNUNG:BEL_DATUM:VON:BIS:NETTO_BETRAG:MWST_BETRAG:STEUERNUMMER:UMRECHNUNGSKURS:COMM_REST_BELEG:COMM_TEL_BELEG:'
||'COMM_PRODUKTE:COMM_SONSTIGES:BELEG:ZAHLUNGSBELEG:LITER:FK_CALC_STATE:FK_CALC_STATE_EUR:FK_CALC_STATE_FRMDW:FRMDW_NETTO_BETRAG:FRMDW_MWST_BETRAG:FRMDW_BRUTTO_BETRAG:FRMDW_BRUTTO_INCL_TRINKG:BUCHUNGS_ZUORD:S_NETTO_BETRAG:FK_FK_ARBEITSTAG:BELEGNUMMER::F'
||'K_BAS_KAT_FK_BAS_KAL_ARBEITSTAG:FK_KTO_BUCHUNG:FK_STD_KTO_ZAHLUNGSART:FK_STD_VERW_VERWENDUNGSZWECK:FK_INV_INVENTAR:FK_PROJ_PROJEKT:FK_ADR_LAND:FK_ADR_CITY:FK_BAS_STEU_STEUER_SATZ:FK_BAS_MON_WAEHRUNG:COMM_BEGRUENDUNG:ZAPFSAEULE:FK_BAS_MON_FRMDW:FK_BAS'
||'_MON_FRMDW_MWST_SATZ:FK_LOC_LOCATION:PERSOENLICH_VOR_ORT:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:KATEGORIE:AZ_O_PAUSE:AZ_M_PAUSE:ANWESENHEITSZEIT:AZ_MANUELL_GEPFLEGT:AZ_COMM:BELEG_UHRZEIT:VON_UHRZEIT:BIS_UH'
||'RZEIT:PARKZEIT:FK_MDT_MANDANT:AZ_STUNDENZAHL:AZ_UEBERSTUNDEN:AZ_SOLLSTUNDEN:FAHRZEIT:FK_STD_REISE_FAHRZEIT_EINHEIT:FK_WORK_STUNDENSATZ:FK_WORK_STUNDENSATZ_UEBERSTUNDEN:FK_WORK_STUNDENSATZ_WOCHENENDE:FK_WF_WORKFLOW:FK_WF_WORKFLOW_STEP:FK_WORK_STUNDENS'
||'ATZ_FAHRZEIT:FK_BAS_MON_WAEHRUNG_SOLL:FK_BAS_STEU_STEUER_SATZ_SOLL:SOLL_NETTO_BETRAG:SOLL_MWST_BETRAG:SOLL_BRUTTO_BETRAG:FK_BAS_MON_UMRECHNUNGSKURS_SOLL:ANZAHL_ZUGEHOERIGE_REAL_BELEGE:MENGE:FK_STD_INP_MENGE_EINHEIT:POSITION:PREIS_EINZEL:PREIS_GESAMT:'
||'GEZAHLT_AM:FK_WH_ART_ARTIKEL:BESTELLDATUM:LIEFERDATUM:RECHNUNGSDATUM:FK_STEU_STEUER_JAHR:FK_STEU_STEUER_MONAT:FK_STD_STEU_STEUERERKLAERUNG_ANLAGE:ZEILE_EINKOMMENSSTEUERERKLAERUNG'
,p_break_on=>'FK_STEUERSATZ'
,p_break_enabled_on=>'FK_STEUERSATZ'
,p_sum_columns_on_break=>'BRUTTO_BETRAG:NETTO_BETRAG:MWST_BETRAG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29633645630800372)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_INP_BELEGE_ALL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2650486660143285)
,p_plug_name=>'Page Items'
,p_parent_plug_id=>wwv_flow_api.id(29633645630800372)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14438980180335698)
,p_plug_name=>'Kontenabgleich'
,p_parent_plug_id=>wwv_flow_api.id(29633645630800372)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29498935325292166)
,p_plug_name=>'kontenabgleich1'
,p_parent_plug_id=>wwv_flow_api.id(14438980180335698)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7186264232999294)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all,',
'datum_ort_ok,',
'datum_addresse_ok,',
'datum_bussgeld_ok,',
'datum_beleg_pos_ok,',
'datum_buchung_ok,',
'DATum_VERPFL_BEL_OK',
'from t_inp_belege_all',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29499090976292167)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:349:&SESSION.::&DEBUG.:RP:P349_PK_INP_BELEGE_ALL:#PK_INP_BELEGE_ALL#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>30939410251683707
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14499143558060924)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14499518557060925)
,p_db_column_name=>'DATUM_ORT_OK'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum Ort Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14499928647060925)
,p_db_column_name=>'DATUM_ADDRESSE_OK'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Datum Addresse Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14500285207060925)
,p_db_column_name=>'DATUM_BUSSGELD_OK'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Datum Bussgeld Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14500683660060925)
,p_db_column_name=>'DATUM_BELEG_POS_OK'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Datum Beleg Pos Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14501144662060927)
,p_db_column_name=>'DATUM_BUCHUNG_OK'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Datum Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14501559090060927)
,p_db_column_name=>'DATUM_VERPFL_BEL_OK'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Datum Verpfl Bel Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29685623978932267)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'159422'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_INP_BELEGE_ALL:DATUM_ORT_OK:DATUM_ADDRESSE_OK:DATUM_BUSSGELD_OK:DATUM_BELEG_POS_OK:DATUM_BUCHUNG_OK:DATUM_VERPFL_BEL_OK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(44748634443513016)
,p_plug_name=>'kontenabgleich'
,p_parent_plug_id=>wwv_flow_api.id(29633645630800372)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_inp_belege_all,',
'apex_item.checkbox2(1, sysdate) dat_all,',
'apex_item.checkbox2(2,1,1,1) dat_ort_ok,',
'apex_item.checkbox2(3,sysdate) dat_addr_ok,',
'apex_item.checkbox2(4,sysdate) dat_buss_ok,',
'apex_item.checkbox2(5,1,1,1) dat_belegpos_ok,',
'apex_item.checkbox2(6,1,1,1) dat_buch_ok,',
'apex_item.checkbox2(7,sysdate) dat_verpfl_bel_ok',
'from t_inp_belege_all',
'where pk_inp_belege_all =:P319_pk_inp_belege_all'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(44748669404513016)
,p_name=>'kontenabgleich'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>46188988679904556
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14494791038059769)
,p_db_column_name=>'PK_INP_BELEGE_ALL'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Pk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14495279337059781)
,p_db_column_name=>'DAT_ALL'
,p_display_order=>20
,p_column_identifier=>'V'
,p_column_label=>'Dat All'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14495671042059781)
,p_db_column_name=>'DAT_ORT_OK'
,p_display_order=>30
,p_column_identifier=>'W'
,p_column_label=>'Dat Ort Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14496035455059781)
,p_db_column_name=>'DAT_ADDR_OK'
,p_display_order=>40
,p_column_identifier=>'X'
,p_column_label=>'Dat Addr Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14496434137059781)
,p_db_column_name=>'DAT_BUSS_OK'
,p_display_order=>50
,p_column_identifier=>'Y'
,p_column_label=>'Dat Buss Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14496848305059783)
,p_db_column_name=>'DAT_BELEGPOS_OK'
,p_display_order=>60
,p_column_identifier=>'Z'
,p_column_label=>'Dat Belegpos Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14497204797059783)
,p_db_column_name=>'DAT_BUCH_OK'
,p_display_order=>70
,p_column_identifier=>'AA'
,p_column_label=>'Dat Buch Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14497586752059783)
,p_db_column_name=>'DAT_VERPFL_BEL_OK'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Dat Verpfl Bel Ok'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(44752868533516808)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'159383'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'PK_INP_BELEGE_ALL:DAT_ALL:DAT_ORT_OK:DAT_ADDR_OK:DAT_BUSS_OK:DAT_BELEGPOS_OK:DAT_BUCH_OK:DAT_VERPFL_BEL_OK'
,p_count_columns_on_break=>'BELEGNUMMER'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14498450187059791)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(44748634443513016)
,p_button_name=>'3_Set_dates'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set Dates'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16742506274343569)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14415506880889463)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_PK_REL_LEX_KTO_BEL,P252_FK_INP_BELEGE_ALL:,&P319_PK_INP_BELEGE_ALL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16860764468689671)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11228479937915741)
,p_button_name=>'show_inp_bel_pos'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Show Inp Bel Pos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:369:&SESSION.::&DEBUG.:RP:P369_PK_INP_BELEGE_ALL:&P319_PK_INP_BELEGE_ALL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17042814410073074)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16862039049689684)
,p_button_name=>'10_set_inp_pos_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Inp Pos Datum Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17041785145073064)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11228479937915741)
,p_button_name=>'8_update_relation_main'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Relation Main'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17042940869073075)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(16862039049689684)
,p_button_name=>'10_set_inp_pos_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Inp Pos Datum Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41087445752228394)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11669737284735070)
,p_button_name=>'12_set_kto_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Steuer Datum Ok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(38288799613208363)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11228479937915741)
,p_button_name=>'11_delete_relation_main_1'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'<span style="background-color:lightblue">delete Relation Main</span>'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17042328824073069)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11228479937915741)
,p_button_name=>'9_set_lex_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'<span style="background-color:lightgrey">Set Lex Datum Ok</span>'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(41087544523228395)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(11669737284735070)
,p_button_name=>'12_set_kto_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Steuer Datum Nok'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14721112608796272)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'relation'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Relation'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17042424253073070)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(11228479937915741)
,p_button_name=>'9_set_lex_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'<span style="background-color:lightgrey">Set Lex Datum Nok</span>'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15219847443119286)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'relation_beleg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Relation_beleg'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:252:&SESSION.::&DEBUG.:RP:P252_FK_INP_BELEGE_ALL:&P319_PK_INP_BELEGE_ALL.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14288005827362609)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14438732430335696)
,p_button_name=>'1_Update_Reason'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'1 Update Reason'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16604745439482407)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(16604549792482405)
,p_button_name=>'4_Update_fk_main_key'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Fk Main Key'
,p_button_position=>'BODY'
,p_button_condition=>'P319_PK_REL_LEX_KTO_BEL'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(43721202953618879)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'Show_Input_belege_all'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Show Input Belege All'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:RP:P422_PK_INP_BELEGE_ALL:&P319_PK_INP_BELEGE_ALL.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14490649842057753)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Delete'
,p_button_position=>'BODY'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P319_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16604852996482408)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(16604549792482405)
,p_button_name=>'5_update_inp_bel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Inp Bel'
,p_button_position=>'BODY'
,p_button_condition=>'P319_PK_REL_LEX_KTO_BEL'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14491460746057755)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BODY'
,p_button_condition=>'P319_PK_INP_BELEGE_ALL'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650770589143287)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'13_SAVE_update_arbeitstag'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'13 Save Update Arbeitstag'
,p_button_position=>'BODY'
,p_button_execute_validations=>'N'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16604883930482409)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(16604549792482405)
,p_button_name=>'6_update_relation'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update Relation'
,p_button_position=>'BODY'
,p_button_condition=>'P319_PK_REL_LEX_KTO_BEL'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16742446226343568)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(16604549792482405)
,p_button_name=>'7_create_kasse_from_lex'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create Kasse From Lex'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14490238063057752)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29633645630800372)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15054997806097981)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11718172121412486)
,p_button_name=>'2_set_steuer_datum_ok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Steuer Datum Ok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15055126986097982)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11718172121412486)
,p_button_name=>'2_set_steuer_datum_nok'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set Steuer Datum Nok'
,p_button_position=>'TOP_AND_BOTTOM'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946052442588400)
,p_name=>'P319_VERG_DATUM_RECHTSKRAFT'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Datum Rechtskraft'
,p_source=>'VERG_DATUM_RECHTSKRAFT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946152441588401)
,p_name=>'P319_VERG_DATUM_TILGUNG'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Datum Tilgung'
,p_source=>'VERG_DATUM_TILGUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946228478588402)
,p_name=>'P319_VERG_NUMMER_FLENS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Nummer Flens'
,p_source=>'VERG_NUMMER_FLENS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946349142588403)
,p_name=>'P319_VERG_AKTENZEICHEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Aktenzeichen'
,p_source=>'VERG_AKTENZEICHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946471338588404)
,p_name=>'P319_VERG_TATBESTANDSNUMMER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Tatbestandsnummer'
,p_source=>'VERG_TATBESTANDSNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1946579907588405)
,p_name=>'P319_FK_VER_VERTRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Ver Vertrag'
,p_source=>'FK_VER_VERTRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14287972081362608)
,p_name=>'P319_FK_TYPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14438732430335696)
,p_prompt=>'Fk Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 281'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14491838210057756)
,p_name=>'P319_PK_INP_BELEGE_ALL'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29633645630800372)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'PK_INP_BELEGE_ALL'
,p_source=>'PK_INP_BELEGE_ALL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14492162342057761)
,p_name=>'P319_DATUM_ORT_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Ort Ok'
,p_source=>'DATUM_ORT_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14492543075057761)
,p_name=>'P319_DATUM_ADDRESSE_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>1100
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Addresse Ok'
,p_source=>'DATUM_ADDRESSE_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14492923678057761)
,p_name=>'P319_DATUM_BUSSGELD_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Bussgeld Ok'
,p_source=>'DATUM_BUSSGELD_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14493324005057761)
,p_name=>'P319_DATUM_BELEG_POS_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Beleg Pos Ok'
,p_source=>'DATUM_BELEG_POS_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14493770628057761)
,p_name=>'P319_DATUM_BUCHUNG_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Buchung Ok'
,p_source=>'DATUM_BUCHUNG_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14494172455057763)
,p_name=>'P319_DATUM_VERPFL_BEL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>1090
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Verpfl Bel Ok'
,p_source=>'DATUM_VERPFL_BEL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16737385945291933)
,p_name=>'P319_PK_REL_LEX_KTO_BEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ID'
,p_source=>'PK_REL_LEX_KTO_BEL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pk_rel_lex_kto_bel d, pk_rel_lex_kto_bel r',
'from t_rel_lex_kto_bel'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16737780668295250)
,p_name=>'P319_FK_LEX_RELATION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Lex Relation'
,p_source=>'FK_LEX_RELATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lex.relation || '' '' || lex.Betrag || ''  '' || lex.belegdat || '' '' || lex.Buchungstext || '' '' || lex.Sollkto || '' '' || lex.Habenkto d, lex.relation r',
'from t_lex_long lex',
'  left join  T_REL_LEX_KTO_BEL rel on rel.fk_lex_relation = lex.relation',
'where lex.status is null',
'  ',
'  '))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16737984790298291)
,p_name=>'P319_FK_MAIN_KEY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Main Key'
,p_source=>'FK_MAIN_KEY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_FK_MAIN_KEY_BUCHUNG'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       Waehrung || '' '' ||',
'        round(Fremdwaehrungsbetrag,2) || '' '' ||',
'    Fremdwaehrung  || '' '' || BUCHUNGSTEXT || '' '' || FK_bas_kat_Kategorie || '' '' || FK_std_verw_Verwendungszweck || '' ''  || Kontotyp || '' '' || FK_bas_kal_BUCHUNGSTAG || '' '' || FK_bas_kal_WERTSTELLUNG || '' '' || Wertt_datum d,  FK_MAIN_KEY r',
'from v_kto_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16738319833302358)
,p_name=>'P319_FK_INP_BELEGE_ALL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk Inp Belege All'
,p_source=>'FK_INP_BELEGE_ALL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung || '' '' || pk_inp_belege_all || '' '' || BEL_DATUM || '' '' || bezeichnung || '' '' || BRUTTO_BETRAG, pk_inp_belege_all',
'from t_inp_belege_all'))
,p_lov_display_null=>'YES'
,p_cSize=>100
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16741999117343564)
,p_name=>'P319_FK_MAIN_KEY_SEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_prompt=>'Fk Main Key Sel'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16742119367343565)
,p_name=>'P319_FK_INP_BELEGE_ALL_SEL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_prompt=>'FK_Inp_belege_all Sel'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16742227778343566)
,p_name=>'P319_FK_LEX_RELATION_SEL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(16604549792482405)
,p_prompt=>'Fk relation Sel'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51394498715466007)
,p_name=>'P319_FK_LEX_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Lex Buchung'
,p_source=>'FK_LEX_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51394590989466008)
,p_name=>'P319_FK_BAS_KAT_KATEGORIE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Kat Kategorie'
,p_source=>'FK_BAS_KAT_KATEGORIE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51394772380466009)
,p_name=>'P319_FK_BAS_KAL_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(29633645630800372)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_source=>'FK_BAS_KAL_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select datum, pk_bas_kal_arbeitstage',
'from t_bas_kal_arbeitstage'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51394872170466010)
,p_name=>'P319_FK_KTO_BUCHUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Kto Buchung'
,p_source=>'FK_KTO_BUCHUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51394914330477861)
,p_name=>'P319_FK_STD_KTO_ZAHLUNGSART'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Kto Zahlungsart'
,p_source=>'FK_STD_KTO_ZAHLUNGSART'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395024229477862)
,p_name=>'P319_FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Verw Verwendungszweck'
,p_source=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395161105477863)
,p_name=>'P319_FK_INV_INVENTAR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Inv Inventar'
,p_source=>'FK_INV_INVENTAR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395212885477864)
,p_name=>'P319_FK_PROJ_PROJEKT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Proj Projekt'
,p_source=>'FK_PROJ_PROJEKT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395339194477865)
,p_name=>'P319_BELEGNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Belegnummer'
,p_source=>'BELEGNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>128
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395454511477866)
,p_name=>'P319_BEZEICHNUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(29633645630800372)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Bezeichnung'
,p_source=>'BEZEICHNUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395489375477867)
,p_name=>'P319_FK_ADR_LAND'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Adr Land'
,p_source=>'FK_ADR_LAND'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395629125477868)
,p_name=>'P319_FK_ADR_CITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Adr City'
,p_source=>'FK_ADR_CITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395734255477869)
,p_name=>'P319_BEL_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(29633645630800372)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Bel Datum'
,p_source=>'BEL_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395818555477870)
,p_name=>'P319_VON'
,p_source_data_type=>'DATE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Von'
,p_source=>'VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51395966522477871)
,p_name=>'P319_BIS'
,p_source_data_type=>'DATE'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Bis'
,p_source=>'BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396029880477872)
,p_name=>'P319_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Netto Betrag'
,p_source=>'NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396148877477873)
,p_name=>'P319_FK_BAS_STEU_STEUER_SATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Steu Steuer Satz'
,p_source=>'FK_BAS_STEU_STEUER_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396218810477874)
,p_name=>'P319_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Mwst Betrag'
,p_source=>'MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396371437477875)
,p_name=>'P319_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Brutto Betrag'
,p_source=>'BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396452674477876)
,p_name=>'P319_FK_BAS_MON_WAEHRUNG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Mon Waehrung'
,p_source=>'FK_BAS_MON_WAEHRUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396576694477877)
,p_name=>'P319_STEUERNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Steuernummer'
,p_source=>'STEUERNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396627336477878)
,p_name=>'P319_FK_BAS_MON_UMRECHNUNGSKURS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Mon Umrechnungskurs'
,p_source=>'FK_BAS_MON_UMRECHNUNGSKURS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396773953477879)
,p_name=>'P319_COMM_REST_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Rest Beleg'
,p_source=>'COMM_REST_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396875885477880)
,p_name=>'P319_COMM_TEL_BELEG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Tel Beleg'
,p_source=>'COMM_TEL_BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396942586477881)
,p_name=>'P319_COMM_PRODUKTE'
,p_source_data_type=>'CLOB'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Produkte'
,p_source=>'COMM_PRODUKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51396997757477882)
,p_name=>'P319_COMM_BEGRUENDUNG'
,p_source_data_type=>'CLOB'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Begruendung'
,p_source=>'COMM_BEGRUENDUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397122954477883)
,p_name=>'P319_COMM_SONSTIGES'
,p_source_data_type=>'CLOB'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Sonstiges'
,p_source=>'COMM_SONSTIGES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397280240477884)
,p_name=>'P319_BELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Beleg'
,p_source=>'BELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397345872477885)
,p_name=>'P319_ZAHLUNGSBELEG'
,p_source_data_type=>'BLOB'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Zahlungsbeleg'
,p_source=>'ZAHLUNGSBELEG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397448819477886)
,p_name=>'P319_LITER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Liter'
,p_source=>'LITER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397544726477887)
,p_name=>'P319_ZAPFSAEULE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Zapfsaeule'
,p_source=>'ZAPFSAEULE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397604162477888)
,p_name=>'P319_FK_LOC_LOCATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Loc Location'
,p_source=>'FK_LOC_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397744950477889)
,p_name=>'P319_PERSOENLICH_VOR_ORT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Persoenlich Vor Ort'
,p_source=>'PERSOENLICH_VOR_ORT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397781004477890)
,p_name=>'P319_BELEG_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Beleg Uhrzeit'
,p_source=>'BELEG_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51397924649477891)
,p_name=>'P319_VON_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Von Uhrzeit'
,p_source=>'VON_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398012063477892)
,p_name=>'P319_BIS_UHRZEIT'
,p_source_data_type=>'DATE'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Bis Uhrzeit'
,p_source=>'BIS_UHRZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398133294477893)
,p_name=>'P319_FK_BAS_KAL_VON_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Kal Von Arbeitstag'
,p_source=>'FK_BAS_KAL_VON_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398257394477894)
,p_name=>'P319_FK_BAS_KAL_BIS_ARBEITSTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Kal Bis Arbeitstag'
,p_source=>'FK_BAS_KAL_BIS_ARBEITSTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398339197477895)
,p_name=>'P319_COMM_ADRESSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Adresse'
,p_source=>'COMM_ADRESSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398455792477896)
,p_name=>'P319_TANKSTELLEN_NR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Tankstellen Nr'
,p_source=>'TANKSTELLEN_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398508245477897)
,p_name=>'P319_BRUTTO_BETRAG_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Brutto Betrag Incl Trinkg'
,p_source=>'BRUTTO_BETRAG_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398591961477898)
,p_name=>'P319_COMM_PARKTICKET'
,p_source_data_type=>'CLOB'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Parkticket'
,p_source=>'COMM_PARKTICKET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398720248477899)
,p_name=>'P319_FRMDW_NETTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Frmdw Netto Betrag'
,p_source=>'FRMDW_NETTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398809451477900)
,p_name=>'P319_FK_BAS_MON_FRMDW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Mon Frmdw'
,p_source=>'FK_BAS_MON_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51398882529477901)
,p_name=>'P319_FK_BAS_MON_FRMDW_MWST_SATZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bas Mon Frmdw Mwst Satz'
,p_source=>'FK_BAS_MON_FRMDW_MWST_SATZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399053987477902)
,p_name=>'P319_FRMDW_MWST_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Frmdw Mwst Betrag'
,p_source=>'FRMDW_MWST_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399082252477903)
,p_name=>'P319_FRMDW_BRUTTO_BETRAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Frmdw Brutto Betrag'
,p_source=>'FRMDW_BRUTTO_BETRAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399229505477904)
,p_name=>'P319_FRMDW_BRUTTO_INCL_TRINKG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Frmdw Brutto Incl Trinkg'
,p_source=>'FRMDW_BRUTTO_INCL_TRINKG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399315881477905)
,p_name=>'P319_MWST_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>560
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Mwst Betrag Eur'
,p_source=>'MWST_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399427326477906)
,p_name=>'P319_BRUTTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>570
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Brutto Betrag Eur'
,p_source=>'BRUTTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399482019477907)
,p_name=>'P319_BRUTTO_INCL_TRINKG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>580
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Brutto Incl Trinkg Eur'
,p_source=>'BRUTTO_INCL_TRINKG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399597937477908)
,p_name=>'P319_NETTO_BETRAG_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>590
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Netto Betrag Eur'
,p_source=>'NETTO_BETRAG_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399699352477909)
,p_name=>'P319_PREIS_PRO_MENGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>600
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Preis Pro Menge'
,p_source=>'PREIS_PRO_MENGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399860600477910)
,p_name=>'P319_MENGENEINHEIT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>610
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Mengeneinheit'
,p_source=>'MENGENEINHEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51399974824477961)
,p_name=>'P319_LA_DATUM'
,p_source_data_type=>'DATE'
,p_item_sequence=>620
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'La Datum'
,p_source=>'LA_DATUM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400050004477962)
,p_name=>'P319_FK_LA_KONTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>630
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk La Konto'
,p_source=>'FK_LA_KONTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400091485477963)
,p_name=>'P319_FK_LA_WDH'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>640
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk La Wdh'
,p_source=>'FK_LA_WDH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400193395477964)
,p_name=>'P319_FK_STD_INP_ZAHLUNGSSTATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>650
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Inp Zahlungsstatus'
,p_source=>'FK_STD_INP_ZAHLUNGSSTATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400328795477965)
,p_name=>'P319_COMM_VERGEHEN'
,p_source_data_type=>'CLOB'
,p_item_sequence=>660
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Comm Vergehen'
,p_source=>'COMM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400438017477966)
,p_name=>'P319_VERG_BEHOERDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>670
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Behoerde'
,p_source=>'VERG_BEHOERDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400514163477967)
,p_name=>'P319_VERG_CNT_PUNKTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>680
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Cnt Punkte'
,p_source=>'VERG_CNT_PUNKTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400593066477968)
,p_name=>'P319_FK_BEL_BELEG_ABLAGE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>690
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Bel Beleg Ablage'
,p_source=>'FK_BEL_BELEG_ABLAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400693580477969)
,p_name=>'P319_FK_ABL_ORDNER_PAGE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>700
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Abl Ordner Page'
,p_source=>'FK_ABL_ORDNER_PAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400855634477970)
,p_name=>'P319_VERG_CNT_PUNKTE_GESCHAETZT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>710
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Cnt Punkte Geschaetzt'
,p_source=>'VERG_CNT_PUNKTE_GESCHAETZT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400933179477971)
,p_name=>'P319_VERG_PUNKTE_VON'
,p_source_data_type=>'DATE'
,p_item_sequence=>720
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Punkte Von'
,p_source=>'VERG_PUNKTE_VON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51400994008477972)
,p_name=>'P319_VERG_PUNKTE_BIS'
,p_source_data_type=>'DATE'
,p_item_sequence=>730
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Punkte Bis'
,p_source=>'VERG_PUNKTE_BIS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401126249477973)
,p_name=>'P319_FK_LOC_LOCATION_VERG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>740
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Loc Location Verg'
,p_source=>'FK_LOC_LOCATION_VERG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401267313477974)
,p_name=>'P319_FK_IMP_BA_BEL_OLD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>750
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Imp Ba Bel Old'
,p_source=>'FK_IMP_BA_BEL_OLD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401353401477975)
,p_name=>'P319_VERG_GESCHW_IST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>760
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Geschw Ist'
,p_source=>'VERG_GESCHW_IST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401437612477976)
,p_name=>'P319_VERG_GESCHW_SOLL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>770
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Geschw Soll'
,p_source=>'VERG_GESCHW_SOLL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401499287477977)
,p_name=>'P319_VERG_GESCHW_UEBER_GRZ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>780
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Geschw Ueber Grz'
,p_source=>'VERG_GESCHW_UEBER_GRZ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401670403477978)
,p_name=>'P319_VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>790
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Geschw Ueber Grz Abzgl Messtol'
,p_source=>'VERG_GESCHW_UEBER_GRZ_ABZGL_MESSTOL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401714152477979)
,p_name=>'P319_VERG_CODE_BUSSGELD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>800
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Code Bussgeld'
,p_source=>'VERG_CODE_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401826348477980)
,p_name=>'P319_VERG_DESCR_BUSSGELD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>810
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Verg Descr Bussgeld'
,p_source=>'VERG_DESCR_BUSSGELD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51401922423477981)
,p_name=>'P319_GEZAHLT_AM'
,p_source_data_type=>'DATE'
,p_item_sequence=>820
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Gezahlt Am'
,p_source=>'GEZAHLT_AM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402072777477982)
,p_name=>'P319_WEBSEITE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>830
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Webseite'
,p_source=>'WEBSEITE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402082948477983)
,p_name=>'P319_KUNDENNUMMER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>840
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Kundennummer'
,p_source=>'KUNDENNUMMER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402247612477984)
,p_name=>'P319_FK_REAL_BELEG_EXIST'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>850
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Real Beleg Exist'
,p_source=>'FK_REAL_BELEG_EXIST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402366360477985)
,p_name=>'P319_FK_CALC_STATE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>860
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Calc State'
,p_source=>'FK_CALC_STATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402403254477986)
,p_name=>'P319_FK_CALC_STATE_EUR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>870
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Calc State Eur'
,p_source=>'FK_CALC_STATE_EUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402576888477987)
,p_name=>'P319_FK_CALC_STATE_FRMDW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>880
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Calc State Frmdw'
,p_source=>'FK_CALC_STATE_FRMDW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402626702477988)
,p_name=>'P319_FK_STD_INP_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>890
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Inp Status'
,p_source=>'FK_STD_INP_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402716355477989)
,p_name=>'P319_DATUM_VERGEHEN'
,p_source_data_type=>'DATE'
,p_item_sequence=>900
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Vergehen'
,p_source=>'DATUM_VERGEHEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402852764477990)
,p_name=>'P319_CREATE_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>910
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Create At'
,p_source=>'CREATE_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51402889097477991)
,p_name=>'P319_CREATE_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>920
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Create By'
,p_source=>'CREATE_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403033733477992)
,p_name=>'P319_MODIFY_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>930
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Modify At'
,p_source=>'MODIFY_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403097961477993)
,p_name=>'P319_MODIFY_BY'
,p_source_data_type=>'DATE'
,p_item_sequence=>940
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Modify By'
,p_source=>'MODIFY_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403330287477995)
,p_name=>'P319_FK_INT_INTERNET_APP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>950
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Int Internet App'
,p_source=>'FK_INT_INTERNET_APP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403395989477996)
,p_name=>'P319_FK_CONTR_DUPL_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>960
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Contr Dupl Status'
,p_source=>'FK_CONTR_DUPL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403570384477997)
,p_name=>'P319_DATUM_DUPL_OK'
,p_source_data_type=>'DATE'
,p_item_sequence=>970
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Dupl Ok'
,p_source=>'DATUM_DUPL_OK'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403656686477998)
,p_name=>'P319_DUPL_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>980
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Dupl Bemerkung'
,p_source=>'DUPL_BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403714764477999)
,p_name=>'P319_FK_KON_GESCHAEFTSPARTNER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>990
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Kon Geschaeftspartner'
,p_source=>'FK_KON_GESCHAEFTSPARTNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403786182478000)
,p_name=>'P319_DUMMY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1000
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Dummy'
,p_source=>'DUMMY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51403891129478001)
,p_name=>'P319_STORNIERT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1010
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Storniert'
,p_source=>'STORNIERT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404063089478002)
,p_name=>'P319_FK_ADR_ADRESSE_SCHNELL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1020
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Adr Adresse Schnell'
,p_source=>'FK_ADR_ADRESSE_SCHNELL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404170330478003)
,p_name=>'P319_FK_LEX_RELATION_SRC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>1030
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Lex Relation Src'
,p_source=>'FK_LEX_RELATION_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404190239478004)
,p_name=>'P319_FK_MAIN_KEY_SRC'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1040
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Main Key Src'
,p_source=>'FK_MAIN_KEY_SRC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404306928478005)
,p_name=>'P319_FK_STD_CONTR_STATUS_KAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1050
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Contr Status Kat'
,p_source=>'FK_STD_CONTR_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404422791478006)
,p_name=>'P319_FK_STD_CONTR_STATUS_VERW'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>1060
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Fk Std Contr Status Verw'
,p_source=>'FK_STD_CONTR_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404567656478007)
,p_name=>'P319_DATUM_STATUS_VERW'
,p_source_data_type=>'DATE'
,p_item_sequence=>1070
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Status Verw'
,p_source=>'DATUM_STATUS_VERW'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(51404618777478008)
,p_name=>'P319_DATUM_STATUS_KAT'
,p_source_data_type=>'DATE'
,p_item_sequence=>1080
,p_item_plug_id=>wwv_flow_api.id(2650486660143285)
,p_item_source_plug_id=>wwv_flow_api.id(29633645630800372)
,p_prompt=>'Datum Status Kat'
,p_source=>'DATUM_STATUS_KAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14415412775889462)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'1_add_type'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f08.count loop',
'   if apex_application.g_f08(i) is not null then',
'      update t_rel_kont_buch_kont_buch set fk_type = :P319_FK_TYPE where pk_rel_kont_buch_kont_buch =   apex_application.g_f08(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14288005827362609)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15055246710097983)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_set_steuer_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f09.count loop',
'   if apex_application.g_f09(i) is not null then',
'      update t_lex_kontenblatt set datum_steuer_ok = sysdate where id =   apex_application.g_f09(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15054997806097981)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15055311590097984)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'2_set_steuer_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f09.count loop',
'   if apex_application.g_f09(i) is not null then',
'      update t_lex_kontenblatt set datum_steuer_ok = null where id =   apex_application.g_f09(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15055126986097982)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14502319446067258)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'3_set_dates'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'--1 - set all dates',
'for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      update t_inp_belege_all set datum_ort_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'      update t_inp_belege_all set datum_addresse_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'            ',
'      update t_inp_belege_all set datum_bussgeld_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'      ',
'                  ',
'      update t_inp_belege_all set datum_beleg_pos_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'     update t_inp_belege_all set datum_buchung_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'   end if;',
' end loop;',
' ',
' ',
' ',
'--2 - set all dates',
'for i in 1..apex_application.g_f02.count loop',
'    if apex_application.g_f02(i) is not null then',
'            update t_inp_belege_all set datum_ort_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'            commit;',
'    ',
'   end if;',
' end loop;',
' ',
' ',
' ',
'--3 - set all dates',
'for i in 1..apex_application.g_f03.count loop',
'    if apex_application.g_f03(i) is not null then',
'      ',
'            ',
'      update t_inp_belege_all set datum_addresse_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'      ',
'    ',
'   end if;',
' end loop;',
' ',
' ',
'-- 4- set all dates',
'for i in 1..apex_application.g_f04.count loop',
'    if apex_application.g_f04(i) is not null then',
'      ',
'                ',
'      update t_inp_belege_all set datum_bussgeld_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'   end if;',
' end loop;',
' ',
' ',
'--5 - set all dates',
'for i in 1..apex_application.g_f05.count loop',
'    if apex_application.g_f05(i) is not null then',
'      ',
'          update t_inp_belege_all set datum_beleg_pos_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'   end if;',
' end loop;',
' ',
' ',
'--6 - set all dates',
'for i in 1..apex_application.g_f06.count loop',
'    if apex_application.g_f06(i) is not null then',
'           update t_inp_belege_all set datum_buchung_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'    ',
'   end if;',
' end loop;',
' ',
' --7 - set all dates',
'for i in 1..apex_application.g_f07.count loop',
'    if apex_application.g_f07(i) is not null then',
'           update t_inp_belege_all set datum_verpfl_bel_ok = sysdate  where pk_inp_belege_all = :p319_pk_inp_belege_all;',
'      commit;',
'    ',
'   end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(14498450187059791)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16605047275482410)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'4_Update_buch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  update t_rel_lex_kto_bel set fk_main_key = :P319_FK_Main_key where pk_rel_lex_kto_bel = :P319_PK_REL_LEX_KTO_BEL;',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16604745439482407)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16741767114343561)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'5_Update_inp_bel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  update t_rel_lex_kto_bel set fk_inp_belege_all = :P319_FK_inp_belege_all where pk_rel_lex_kto_bel = :P319_PK_REL_LEX_KTO_BEL;',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16604852996482408)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16741817970343562)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'6_update_rel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  update t_rel_lex_kto_bel set fk_lex_relation = :P319_FK_lex_relation where pk_rel_lex_kto_bel = :P319_PK_REL_LEX_KTO_BEL;',
'  commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16604883930482409)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16742373406343567)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'7_create_kasse_from_lex'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_seq_kas number;',
'  v_fk_main_key_kas number;',
'  v_relation varchar(4000 char);',
' begin',
' ',
' --v_relation selektieren',
'    v_relation:= :P319_FK_RELATION_SEL;',
' ',
' --neue Kassenbuchung erzeugen - aus Lex_Buchung',
'   select KAS_KASSE_SEQ.nextval',
'   into v_seq_kas',
'   from dual;',
' ',
' ',
' insert into kas_kasse (datum, buchungstext, betrag, jahr, comm) ',
' select   belegdat, buchungstext, case when habenkto = ''1600'' then -betrag else betrag end betrag_neu,  jahr, relation',
' ',
' from t_lex_long',
'commit;',
'',
'',
'--Kassenbuchung updaten (Arbeitstag, Kontonummer, kontotyp, fk_main_key)',
'v_fk_main_key_kas := KTO_KONTO_SEQ.nextval;',
'update Kas_Kasse set FK_MAIN_KEY = v_fk_main_key_kas where fk_main_key is null;',
'  ',
'  /*',
'merge into kas_kasse t1 ',
'using (',
'select kas.fk_main_key,',
'      nvl(kas.datum, zus."Buchungstag") dat,',
'      nvl(kas.buchungstext, zus.buchungstext) txt,',
'      nvl(kas.jahr, zus.bucht_jahr) jahr,',
'      nvl(kas.betrag, -zus."Betrag") Betrag',
'      ',
'from kas_kasse kas',
' left join v_konten_zus zus on kas.fk_main_key_bankkonto = zus.fk_main_key',
' ) t2 on (t1.fk_main_key = t2.fk_main_key)',
' when matched then ',
' update set t1.datum = t2.dat,',
'    t1.buchungstext = t2.txt,',
'    t1.jahr = t2.jahr,',
'    t1.betrag  = t2.Betrag;',
'commit;',
'*/',
'    ',
'merge into kas_kasse t1',
'  using (',
'        select pk_arbeitstage, ',
'       pk_kas_kasse',
'',
'        from (select * from kas_kasse where datum is not null and fk_arbeitstag is null) bel,',
'          t_arbeitstage arb',
'        where  to_date(substr(bel.datum,1,10), ''DD.MM.YYYY'')= arb.datum ',
'         ) t2 on (t1.pk_kas_kasse = t2.pk_kas_kasse)',
'        when matched then',
'        update set t1.fk_arbeitstag= t2.pk_arbeitstage;',
'        commit;',
'        ',
'   ',
'   update kas_kasse set fk_konto = 61 where fk_konto is null;',
'   update kas_kasse set fk_kontotyp = 6 where fk_kontotyp is null;',
'   update kas_kasse set creation_date = sysdate where creation_date is null;',
'   commit;',
'   ',
'  --Kassenbuchung - Lexwarebuchung zuordnen ',
'  /*',
'   select fk_main_key',
'   into  v_fk_main_key_kas',
'   from kas_kasse',
'   where instr(comm, v_relation)>0;',
'   */',
'   ',
'   /*',
'   insert into t_rel_lex_kto_bel (fk_main_key, fk_relation)',
'   select v_fk_main_key_kas, v_relation',
'   from dual;',
'   */',
'   update t_rel_lex_kto_bel set fk_main_key = v_fk_main_key_kas where pk_rel_lex_kto_bel = :P319_PK_rel_lex_kto_bel;',
'   commit;',
'end;',
'',
'',
'',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16742446226343568)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17041889390073065)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'8_update_rel_main'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' update t_lex_long set fk_lex_relation_main = substr(relation,1,instr(relation,''/'',-1)) || ''0'' where fk_lex_relation_main is null;',
' commit;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17041785145073064)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17042692270073073)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_set_lex_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f10.count loop',
'   if apex_application.g_f10(i) is not null then',
'      update t_lex_long set datum_ok = sysdate where relation =   apex_application.g_f10(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17042328824073069)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17042672074073072)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'9_set_lex_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f10.count loop',
'   if apex_application.g_f10(i) is not null then',
'      update t_lex_long set datum_ok = null where relation =   apex_application.g_f10(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17042424253073070)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17043018830073076)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_set_inp_pos_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f11.count loop',
'   if apex_application.g_f11(i) is not null then',
'      update inp_belege_pos_all set datum_ok_buch = sysdate where pk_inp_belege_pos_all =   apex_application.g_f11(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17042814410073074)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17043155323073077)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'10_set_inp_pos_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f11.count loop',
'   if apex_application.g_f11(i) is not null then',
'     update inp_belege_pos_all set datum_ok_buch = null where pk_inp_belege_pos_all =   apex_application.g_f11(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17042940869073075)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(38289015181208365)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'11_delete_rel_lex_kto_bel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f12.count loop',
'   if apex_application.g_f12(i) is not null then',
'     delete from t_rel_lex_kto_bel where pk_rel_lex_kto_bel =   apex_application.g_f12(i);',
'      ',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(38288799613208363)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(41087184142228392)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'12_set_kto_datum_ok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f13.count loop',
'   if apex_application.g_f13(i) is not null then',
'      update t_kto_girokonto set datum_lex_buchung_ok = sysdate',
'      where fk_main_key = apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_kreditkarte set datum_lex_buchung_ok = sysdate',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_paypal set datum_lex_buchung_ok = sysdate',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_tagesgeldkonto set datum_lex_buchung_ok = sysdate',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_kas_kasse set datum_lex_buchung_ok = sysdate',
'      where fk_main_key=apex_application.g_f13(i);',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(41087445752228394)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(41087340130228393)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'12_set_kto_datum_nok'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f13.count loop',
'   if apex_application.g_f13(i) is not null then',
'      update t_kto_girokonto set datum_lex_buchung_ok = null',
'      where fk_main_key = apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_kreditkarte set datum_lex_buchung_ok =null',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_paypal set datum_lex_buchung_ok = null',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_tagesgeldkonto set datum_lex_buchung_ok = null',
'      where fk_main_key= apex_application.g_f13(i);',
'      commit;',
'      ',
'       update t_kto_kas_kasse set datum_lex_buchung_ok = null',
'      where fk_main_key=apex_application.g_f13(i);',
'      commit;',
'    end if;',
' ',
'   end loop;',
'  ',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(41087544523228395)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2650645685143286)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'13_Save_Update_Arbeitstag'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  update t_inp_belege_all set fk_bas_kal_arbeitstag =:P319_FK_BAS_KAL_ARBEITSTAG where pk_inp_belege_all = :P319_PK_INP_BELEGE_ALL ;',
'commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2650770589143287)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17042492303073071)
,p_process_sequence=>200
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'hints'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  null;',
'',
'   --1_add_type:                                             8',
'   --2_set_steuer_datum_ok / 2_set_steuer_datum_nok:         9',
'   --3_set_dates:                                            1-7',
'   --4_update_buch:                                       --',
'   --5_update_inp_bel:                                    --',
'   --6_update_rel                                         --',
'   --7_create_kasse_from_lex                              --',
'   --8_update_rel_main                                    --',
'   --9_set_lex_datum_ok / 9_set_lex_datum_nok            10,12',
'   --10_set_inp_pos_datum_ok / 10_set_inp_pos_datum_nok  11',
'   --11_delete_rel_lex_kto_bel                           12',
'   --12_set_lex_datum_ok                                 13',
'   --13_Save_update_arbeitstag                           --',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(1946617276588406)
,p_process_sequence=>210
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(29633645630800372)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'SAVE1'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2650770589143287)
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14439492559335704)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(29633645630800372)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'New'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
