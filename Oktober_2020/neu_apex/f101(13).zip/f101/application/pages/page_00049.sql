prompt --application/pages/page_00049
begin
--   Manifest
--     PAGE: 00049
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>49
,p_user_interface_id=>wwv_flow_api.id(7133518773925246)
,p_name=>'2_4_APP_Apex_Page_Content'
,p_alias=>'APEX-PAGE-CONTENT_49'
,p_step_title=>'APP Apex Page Content'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20201014142726'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7490645339564513)
,p_plug_name=>'Apex_Page_Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7047063755925210)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'V_DB_APP_APEX_PAGES_CONTENT'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Apex_Page_Content'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7490788603564513)
,p_name=>'Apex_Page_Content'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>7490788603564513
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7491504820564534)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7491999135564534)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7492302137564534)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7492792535564534)
,p_db_column_name=>'TXT_LINE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Txt Line'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7493112035564535)
,p_db_column_name=>'COMM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7493500216564535)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7493922962564535)
,p_db_column_name=>'FILTER'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Filter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7494390148564535)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7494748709564536)
,p_db_column_name=>'KOMP'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Komp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7495188732564536)
,p_db_column_name=>'KOMP_TYPE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Komp Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7495545613564536)
,p_db_column_name=>'FIL_TXT_LINE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fil Txt Line'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7495958498564536)
,p_db_column_name=>'END_LINE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'End Line'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(27665826368099815)
,p_db_column_name=>'PK_DB_APP_APEX_PAGES_CONTENT'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Pk Db App Apex Pages Content'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7496333713566676)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'74964'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE_ID:APPLICATION_ID:PAGE_ID:TXT_LINE:COMM:CREATION_DATE:FILTER:KATEGORIE:KOMP:KOMP_TYPE:FIL_TXT_LINE:END_LINE:PK_DB_APP_APEX_PAGES_CONTENT'
,p_break_on=>'KOMP_TYPE'
,p_break_enabled_on=>'KOMP_TYPE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7497390226589543)
,p_report_id=>wwv_flow_api.id(7496333713566676)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'APPLICATION_ID'
,p_operator=>'='
,p_expr=>'100'
,p_condition_sql=>'"APPLICATION_ID" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7497768936589543)
,p_report_id=>wwv_flow_api.id(7496333713566676)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KOMP_TYPE'
,p_operator=>'is not null'
,p_condition_sql=>'"KOMP_TYPE" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.component_end;
end;
/
