prompt --application/pages/page_00185
begin
--   Manifest
--     PAGE: 00185
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>185
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5998409161300007)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_IMP_TEL_MOBILCOM_RECH_OV, ',
'"Monat" "MONAT",',
'"Rechnungsnummer" "RECHNUNGSNUMMER",',
'"Netto" "NETTO",',
'"Mwst" "MWST",',
'"Brutto" "BRUTTO",',
'"FK_KTO_BUCHUNG",',
'dbms_lob.getlength("BELEG")  "BELEG",',
'',
'mimetype',
'from "#OWNER#"."T_IMP_TEL_MOBILCOM_RECH_OV" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5998689659300009)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:186:&SESSION.::&DEBUG.::P186_PK_IMP_TEL_MOBILCOM_RECH:#PK_IMP_TEL_MOBILCOM_RECH_OV##PK_TEL_MOBILCOM_GES#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>15308824899720930
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5999204360300040)
,p_db_column_name=>'MONAT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5999602722300043)
,p_db_column_name=>'RECHNUNGSNUMMER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Netto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5999983399300046)
,p_db_column_name=>'NETTO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Mwst'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6000459320300049)
,p_db_column_name=>'MWST'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Brutto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6000765091300052)
,p_db_column_name=>'BRUTTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Pk Tel Mobilcom Ges'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5934827789874612)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5934876588874613)
,p_db_column_name=>'BELEG'
,p_display_order=>28
,p_column_identifier=>'J'
,p_column_label=>'Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:IMP_TEL_MOBILCOM_RECH_OV:BELEG:PK_TEL_MOBILCOM_GES::MIMETYPE::::::'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6481024510829909)
,p_db_column_name=>'PK_IMP_TEL_MOBILCOM_RECH_OV'
,p_display_order=>38
,p_column_identifier=>'K'
,p_column_label=>'Pk imp tel mobilcom rech ov'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50109744221262179)
,p_db_column_name=>'FK_KTO_BUCHUNG'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Fk Kto Buchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6002735509301208)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'153129'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MONAT:RECHNUNGSNUMMER:NETTO:MWST:BRUTTO:MIMETYPE:PK_IMP_TEL_MOBILCOM_RECH_OV:FK_KTO_BUCHUNG'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6002052976300059)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5998409161300007)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:186:&SESSION.::&DEBUG.:186'
);
wwv_flow_api.component_end;
end;
/
