prompt --application/pages/page_00242
begin
--   Manifest
--     PAGE: 00242
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>242
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(674641327567401)
,p_plug_name=>'Kontobuchungen'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11761702562258716)
,p_plug_name=>'V_kto_konten_zus'
,p_parent_plug_id=>wwv_flow_api.id(674641327567401)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       apex_item.checkbox2(1, zus.fk_main_key) sel,',
'       zus.FK_MAIN_KEY,',
'       zus.ID,',
'       zus."Buchungstag",',
'       round(zus."Betrag",2) Betrag,',
'       zus.Waehrung,',
'       zus.Fremdwaehrungsbetrag,',
'       zus.Fremdwaehrung,',
'       zus.BUCHUNGSTEXT,',
'       zus.FK_bas_kat_Kategorie,',
'       zus.FK_std_verw_Verwendungszweck,',
'       zus.FK_std_kto_Kontotyp,',
'       zus.FK_bas_kal_BUCHUNGSTAG,',
'       zus.FK_bas_kal_WERTSTELLUNG,',
'       zus.VERWENDUNGSZWECK,',
'       zus.KATEGORIE,',
'       zus.BUCHT_TAG,',
'       zus.BUCHT_MONAT,',
'       zus.BUCHT_JAHR,',
'       zus.BUCHT_DATUM,',
'       zus.WERTT_TAG,',
'       zus.WERTT_MONAT,',
'       zus.WERTT_JAHR,',
'       zus.WERTT_DATUM,',
'       zus.Kontotyp,',
'       zus.FK_kto_VORGANG,',
'       zus.WIEDERHOLUNG,',
'       zus.NAECHSTE_ZAHLUNG,',
'       --zus.FK_lex_BUCHUNG_STEUER,',
'       ktoaus.pk_kto_konto_auszug,',
'      zus.fk_kto_bankkonto,',
'      gir."Umsatzart",',
'      gir."Auftraggeberkonto",',
'      gir.flg_kreditkartenbuchung,',
'      iban',
'  from V_kto_KONTEN_ZUS zus',
'   left join t_rel_kto_konto_auszug_gir ktogir on ktogir.fk_main_key = zus.fk_main_key',
'   left join t_kto_konto_auszug ktoaus on ktoaus.pk_kto_konto_auszug = ktogir.fk_kto_konto_auszug',
'   left join t_kto_girokonto gir on gir.fk_main_key = ktogir.fk_main_key'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11761856032258716)
,p_name=>'V_konten_zus'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>21071991272679637
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11762250753258770)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11762555082258777)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11762922152258778)
,p_db_column_name=>'Buchungstag'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11764959013258780)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11767345385258783)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11767704167258783)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11768121880258783)
,p_db_column_name=>'BUCHT_TAG'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11768519944258784)
,p_db_column_name=>'BUCHT_MONAT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11768897622258784)
,p_db_column_name=>'BUCHT_JAHR'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bucht Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11769273384258785)
,p_db_column_name=>'BUCHT_DATUM'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Bucht Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11769758696258785)
,p_db_column_name=>'WERTT_TAG'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Wertt Tag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11770159368258786)
,p_db_column_name=>'WERTT_MONAT'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Wertt Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11770525074258786)
,p_db_column_name=>'WERTT_JAHR'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Wertt Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11770929183258787)
,p_db_column_name=>'WERTT_DATUM'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Wertt Datum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11772068316258788)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11772509028258789)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12029484975266601)
,p_db_column_name=>'BETRAG'
,p_display_order=>38
,p_column_identifier=>'AC'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16602101085482381)
,p_db_column_name=>'SEL'
,p_display_order=>68
,p_column_identifier=>'AF'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36310403315367088)
,p_db_column_name=>'Umsatzart'
,p_display_order=>88
,p_column_identifier=>'AH'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36310545221367089)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>98
,p_column_identifier=>'AI'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(36310662410367090)
,p_db_column_name=>'FLG_KREDITKARTENBUCHUNG'
,p_display_order=>108
,p_column_identifier=>'AJ'
,p_column_label=>'Flg Kreditkartenbuchung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(42138180608766265)
,p_db_column_name=>'IBAN'
,p_display_order=>118
,p_column_identifier=>'AK'
,p_column_label=>'Iban'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48565086979300909)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>128
,p_column_identifier=>'AL'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48565243378300910)
,p_db_column_name=>'FREMDWAEHRUNGSBETRAG'
,p_display_order=>138
,p_column_identifier=>'AM'
,p_column_label=>'Fremdwaehrungsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621372019507561)
,p_db_column_name=>'FREMDWAEHRUNG'
,p_display_order=>148
,p_column_identifier=>'AN'
,p_column_label=>'Fremdwaehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621462943507562)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>158
,p_column_identifier=>'AO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621580561507563)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>168
,p_column_identifier=>'AP'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621687648507565)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>188
,p_column_identifier=>'AR'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621799179507566)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>198
,p_column_identifier=>'AS'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48621906513507567)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>208
,p_column_identifier=>'AT'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622022456507568)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>218
,p_column_identifier=>'AU'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622145281507569)
,p_db_column_name=>'PK_KTO_KONTO_AUSZUG'
,p_display_order=>228
,p_column_identifier=>'AV'
,p_column_label=>'Pk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48622256106507570)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>238
,p_column_identifier=>'AW'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(51720028657903965)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>248
,p_column_identifier=>'AX'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12001314525262857)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'213115'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:FK_MAIN_KEY:ID:Buchungstag:BETRAG:BUCHUNGSTEXT:VERWENDUNGSZWECK:KATEGORIE:BUCHT_TAG:BUCHT_MONAT:BUCHT_JAHR:BUCHT_DATUM:WERTT_TAG:WERTT_MONAT:WERTT_JAHR:WERTT_DATUM:WIEDERHOLUNG:NAECHSTE_ZAHLUNG::Umsatzart:Auftraggeberkonto:FLG_KREDITKARTENBUCHUNG'
||':IBAN:WAEHRUNGSBETRAG:FREMDWAEHRUNG:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KTO_FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:KONTOTYP:FK_KTO_VORGANG:PK_KTO_KONTO_AUSZUG:FK_KTO_BANKKONTO:FK_STD_KTO_KONTOTYP'
,p_break_on=>'BUCHT_TAG'
,p_break_enabled_on=>'BUCHT_TAG'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35954326922169925)
,p_report_id=>wwv_flow_api.id(12001314525262857)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35954725679169927)
,p_report_id=>wwv_flow_api.id(12001314525262857)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Kontotyp'
,p_operator=>'='
,p_expr=>'Girokonto'
,p_condition_sql=>'"Kontotyp" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Girokonto''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(35955081593169927)
,p_report_id=>wwv_flow_api.id(12001314525262857)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'WERTT_MONAT'
,p_operator=>'='
,p_expr=>'5'
,p_condition_sql=>'"WERTT_MONAT" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16602221081482382)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(11761702562258716)
,p_button_name=>'delete_from_gir'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Delete From Gir'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16603221490482392)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(11761702562258716)
,p_button_name=>'delete_from_kred'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Delete From kred'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16664364004775092)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(674641327567401)
,p_button_name=>'create_beleg'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Create Beleg'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16666883631844469)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(674641327567401)
,p_button_name=>'add_beleg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Add Beleg'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:367:&SESSION.::&DEBUG.:RP:P367_FK_VERPFLEGUNGSMEHRAUFWD_DET,P367_FK_AREITSTAG:&P339_FK_VERPFLEGUNGSMEHRAUFWD_DET.,&P339_FK_ARBEITSTAG.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16664038180773000)
,p_name=>'P242_FK_ABLAGE_ORDNER_PAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(674641327567401)
,p_item_default=>'1'
,p_prompt=>'FK_ABLAGE_ORDNER_PAGE'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  pk_abl_ordner_page d, pk_abl_ordner_page r',
'from t_abl_ordner_page'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16666329627840160)
,p_name=>'P242_FK_STEU_VERPFL_SMEHRAUFWD_DET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(674641327567401)
,p_prompt=>'Fk Steu Verpfl Smehraufwd Det'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16666677119842008)
,p_name=>'P242_FK_BAS_KAL_ARBEITSTAG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(674641327567401)
,p_prompt=>'Fk Bas Kal Arbeitstag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16670387665907167)
,p_name=>'P242_FK_STD_STEU_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(674641327567401)
,p_prompt=>'Fk Std Steu Status'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16670691783909550)
,p_name=>'P242_COMM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(674641327567401)
,p_prompt=>'Comm'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16602335561482383)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'p_delete_from_gir'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      delete from kto_girokonto where fk_main_key  = apex_application.g_f01(i) ;',
'      ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16602221081482382)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16603369029482393)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'p_delete_from_kred'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'      delete from kto_kreditkarte where fk_main_key  = apex_application.g_f01(i) ;',
'      ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16603221490482392)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16663373698767653)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'p_new_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
' p_add_new_inp_bel_kto (apex_application.g_f01(i), :P242_PK_ABL_ORNDER_PAGE);',
' end if;',
' end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16664364004775092)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(16670074771891199)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'p_add_beleg'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'    if apex_application.g_f01(i) is not null then',
'    ',
'      insert into T_REL_VERPFL_BELEG_SRC (',
'     ',
'FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'FK_INP_BELEGE_ALL,',
'--FK_STUNDENZETTEL',
'COMM,',
'FK_STATUS,',
'CREATION_DATE',
'          )',
'      values (',
'      :P242_FK_VERPFLEGUNGSMEHRAUFWD_DET,',
'',
'       apex_application.g_f01(i),',
'          :P242_COMM,',
':P242_FK_STATUS,',
':P242_CREATION_DATE',
'      );',
'    ',
'      commit;',
'',
' end if;',
' end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16666883631844469)
);
wwv_flow_api.component_end;
end;
/
