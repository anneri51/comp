prompt --application/pages/page_00333
begin
--   Manifest
--     PAGE: 00333
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>333
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11950512354481847)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_STEUER_VORANMLDG","MELDEMONAT","BERICHTIGTE_ANMLDG_NR","BELEG_NR","STEUERPFL_UMSAETZE","ABZIEHBARE_VORSTEUERBETR","UMSATZSTVORAUSZLG_UEBERSCHUSS","SENDEDATUM","TRANSAKTIONSNUMMER",stva."CREATED_BY",stva."CREATED_AT",stva."MODIFIED_BY",stva'
||'."MODIFIED_AT","FK_STEUER_MONAT",sys.dbms_lob.getlength("FILE1")"FILE1",sys.dbms_lob.getlength("FILE2")"FILE2"',
'',
', stm.monat',
', stm.jahr',
', std.std_name status_vorsteueranmeldg',
', std1.std_name type',
', std1.std_value fk_type',
'from "T_STEUER_VORANMLDG" stva',
'  left join t_steuer_monat stm on stva.fk_steuer_monat = stm.pk_steuer_monat',
'  left join (select * from t_std where fk_std_group = 342) std on std.std_value = stva.fk_status',
'    left join (select * from t_std where fk_std_group = 343) std1 on std1.std_value = stva.fk_type',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(11950960644481849)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:334:&SESSION.::&DEBUG.:RP:P334_PK_STEUER_VORANMLDG:\#PK_STEUER_VORANMLDG#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ANNE'
,p_internal_uid=>13391279919873389
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11951054214481849)
,p_db_column_name=>'PK_STEUER_VORANMLDG'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Steuer Voranmldg'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11951433295481852)
,p_db_column_name=>'MELDEMONAT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Meldemonat'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11951825790481852)
,p_db_column_name=>'BERICHTIGTE_ANMLDG_NR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Berichtigte Anmldg Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11952259136481852)
,p_db_column_name=>'BELEG_NR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Beleg Nr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11952673580481853)
,p_db_column_name=>'STEUERPFL_UMSAETZE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Steuerpfl Umsaetze'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953007277481853)
,p_db_column_name=>'ABZIEHBARE_VORSTEUERBETR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Abziehbare Vorsteuerbetr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953474824481853)
,p_db_column_name=>'UMSATZSTVORAUSZLG_UEBERSCHUSS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Umsatzstvorauszlg Ueberschuss'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11953854587481853)
,p_db_column_name=>'SENDEDATUM'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Sendedatum'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11954232682481853)
,p_db_column_name=>'TRANSAKTIONSNUMMER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Transaktionsnummer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11954642238481853)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955054781481853)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955412962481855)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11955849177481855)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11956191471481855)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11956621260481855)
,p_db_column_name=>'FILE1'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'File1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:T_STEUER_VORANMLDG:FILE1:PK_STEUER_VORANMLDG'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(11957077669481855)
,p_db_column_name=>'FILE2'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'File2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:T_STEUER_VORANMLDG:FILE2:PK_STEUER_VORANMLDG'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18026973239728087)
,p_db_column_name=>'MONAT'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027016291728088)
,p_db_column_name=>'JAHR'
,p_display_order=>36
,p_column_identifier=>'R'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027180381728089)
,p_db_column_name=>'STATUS_VORSTEUERANMELDG'
,p_display_order=>46
,p_column_identifier=>'S'
,p_column_label=>'Status Vorsteueranmeldg'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027565448728093)
,p_db_column_name=>'TYPE'
,p_display_order=>56
,p_column_identifier=>'T'
,p_column_label=>'Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18027621793728094)
,p_db_column_name=>'FK_TYPE'
,p_display_order=>66
,p_column_identifier=>'U'
,p_column_label=>'Fk Type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(11969555858677836)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134099'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:PK_STEUER_VORANMLDG:BELEG_NR:STEUERPFL_UMSAETZE:ABZIEHBARE_VORSTEUERBETR:UMSATZSTVORAUSZLG_UEBERSCHUSS:SENDEDATUM:TRANSAKTIONSNUMMER:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:FILE2:MONAT:STATUS_VORSTEUERANMELDG:TYPE:BERICHTIGTE_ANMLDG_NR:FIL'
||'E1:FK_STEUER_MONAT:MELDEMONAT::FK_TYPE'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'MONAT'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'FK_TYPE'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'JAHR'
,p_break_enabled_on=>'JAHR'
,p_count_columns_on_break=>'PK_STEUER_VORANMLDG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18093471971675794)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'erl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_VORSTEUERANMELDG'
,p_operator=>'='
,p_expr=>'erledigt'
,p_condition_sql=>' (case when ("STATUS_VORSTEUERANMELDG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''erledigt''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(18093848442675794)
,p_report_id=>wwv_flow_api.id(11969555858677836)
,p_name=>'korr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'TYPE'
,p_operator=>'='
,p_expr=>'Korrektur'
,p_condition_sql=>' (case when ("TYPE" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Korrektur''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11958248704481856)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(11950512354481847)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:334:&SESSION.::&DEBUG.:334'
);
wwv_flow_api.component_end;
end;
/
