prompt --application/pages/page_00380
begin
--   Manifest
--     PAGE: 00380
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>380
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(39093511374343976)
,p_plug_name=>'dupl_lex_buch'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from t_duplikat_check_kontrolle'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39093627316343977)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>40533946591735517
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19166694159850789)
,p_db_column_name=>'JAHR'
,p_display_order=>210
,p_column_identifier=>'A'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19167092417850794)
,p_db_column_name=>'DATUM_OK'
,p_display_order=>250
,p_column_identifier=>'B'
,p_column_label=>'Datum Ok'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19167494508850794)
,p_db_column_name=>'FK_STEUER_MONAT'
,p_display_order=>380
,p_column_identifier=>'C'
,p_column_label=>'Fk Steuer Monat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19167973905850795)
,p_db_column_name=>'PK_DUPLIKAT_CHECK_KONTROLLE'
,p_display_order=>390
,p_column_identifier=>'D'
,p_column_label=>'Pk Duplikat Check Kontrolle'
,p_column_link=>'f?p=&APP_ID.:379:&SESSION.::&DEBUG.:RP:P379_PK_DUPLIKAT_CHECK_KONTROLLE:#PK_DUPLIKAT_CHECK_KONTROLLE#'
,p_column_linktext=>'#PK_DUPLIKAT_CHECK_KONTROLLE#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19168320022850795)
,p_db_column_name=>'FK_DUPLKAT_TYPE'
,p_display_order=>400
,p_column_identifier=>'E'
,p_column_label=>'Fk Duplkat Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19168742848850795)
,p_db_column_name=>'FK_DUPLIKAT_CHECK_STATUS'
,p_display_order=>410
,p_column_identifier=>'F'
,p_column_label=>'Fk Duplikat Check Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19169141370850795)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>420
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19169542379850795)
,p_db_column_name=>'FK_OBJEKT_1'
,p_display_order=>430
,p_column_identifier=>'H'
,p_column_label=>'Fk Objekt 1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19169941472850797)
,p_db_column_name=>'FK_OBJEKT_2'
,p_display_order=>440
,p_column_identifier=>'I'
,p_column_label=>'Fk Objekt 2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19170377304850797)
,p_db_column_name=>'FK_OBJEKT_3'
,p_display_order=>450
,p_column_identifier=>'J'
,p_column_label=>'Fk Objekt 3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19170691668850797)
,p_db_column_name=>'FK_OBJEKT_4'
,p_display_order=>460
,p_column_identifier=>'K'
,p_column_label=>'Fk Objekt 4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(19171159532850797)
,p_db_column_name=>'FK_OBJEKT_5'
,p_display_order=>470
,p_column_identifier=>'L'
,p_column_label=>'Fk Objekt 5'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(39122850082355892)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'206118'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JAHR:FK_STEUER_MONAT:PK_DUPLIKAT_CHECK_KONTROLLE:FK_DUPLKAT_TYPE:FK_DUPLIKAT_CHECK_STATUS:DATUM_OK:CREATION_DATE:FK_OBJEKT_1:FK_OBJEKT_2:FK_OBJEKT_3:FK_OBJEKT_4:FK_OBJEKT_5:'
,p_sort_column_1=>'FK_DUPLKAT_TYPE'
,p_sort_direction_1=>'DESC'
,p_break_on=>'JAHR:FK_STEUER_MONAT'
,p_break_enabled_on=>'JAHR:FK_STEUER_MONAT'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19171917643850803)
,p_report_id=>wwv_flow_api.id(39122850082355892)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DATUM_OK'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("DATUM_OK" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19172315921850805)
,p_report_id=>wwv_flow_api.id(39122850082355892)
,p_name=>'all'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'='
,p_expr=>'999'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19172687247850806)
,p_report_id=>wwv_flow_api.id(39122850082355892)
,p_name=>'inp_bel'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_DUPLKAT_TYPE'
,p_operator=>'in'
,p_expr=>'1,2'
,p_condition_sql=>' (case when ("FK_DUPLKAT_TYPE" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 1, 2  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19173170339850806)
,p_report_id=>wwv_flow_api.id(39122850082355892)
,p_name=>'t_lex'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(19173483819850806)
,p_report_id=>wwv_flow_api.id(39122850082355892)
,p_name=>'inp_belege'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_OBJEKT_1'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("FK_OBJEKT_1" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.component_end;
end;
/
