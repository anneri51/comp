prompt --application/pages/page_00105
begin
--   Manifest
--     PAGE: 00105
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>105
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Girokonto'
,p_alias=>'GIROKONTO'
,p_step_title=>'Girokonto'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200925105725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2192563515681109)
,p_plug_name=>'UPDATE / FILTER'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2460217071770580)
,p_plug_name=>unistr('Buchungss\00E4tze')
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(7210029454999303)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2223781148080634)
,p_plug_name=>'Girokonto'
,p_parent_plug_id=>wwv_flow_api.id(2460217071770580)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gir.ID,',
'       apex_item.checkbox2(1,gir.id) sel,',
'       apex_item.checkbox2(5, gir.fk_main_key) sel1,',
'       gir."Buchungstag",',
'       gir."Wertstellung",',
'       gir."Umsatzart",',
'       gir."Buchungstext",',
'       round(gir."Betrag",2) betrag,',
'       gir.WAEhrung,',
'       gir."Auftraggeberkonto",',
'       gir."Bankleitzahl Auftraggeberkonto",',
'       gir.IBAN_Auftraggeberkonto,',
'       gir.Kategorie,',
'       gir."alt_ID",',
'       gir.FK_BAS_KAT_Kategorie,',
'       gir.FK_std_verw_Verwendungszweck,',
'       gir.FK_std_kto_Kontotyp,',
'       gir."Bemerkungen",',
'       gir.fk_bas_kal_buchungstag,',
'       arb.*,',
'       kat.Kategorie kAT_Kategorie,',
'       verw.std_name Verwendungszweck,',
'       gir.fk_main_key,',
'       ktoaus.PK_kto_KONTO_AUSZUG,',
'       ktoaus.FK_kto_bankKONTO,',
'       ktoaus.FK_kto_KONTO_AUSZUG,',
'       ktoaus.JAHR KTOAUS_JAHR,',
'       ktoaus.MONAT KTOAUS_MONAT,',
'       ktoaus.ANFANGSDATUM,',
'       ktoaus.ENDDATUM,',
'       ktoaus.ABHOLDATUM,',
'       ktoaus.KOMMENTAR,',
'       ktoaus.ANFANGSBETRAG,',
'       ktoaus.ENDBETRAG,',
'       ktoaus.FK_BAS_kal_ABHOLDATUM,',
'       ktoaus.FK_BAS_kal_ANFANGSDATUM,',
'       ktoaus.FK_BAS_kal_ENDDATUM,',
'       relinv.fk_main_key inv_fk_main_key,',
'       relproj.fk_main_Key proj_fk_main_Key',
'  from t_KTO_GIROKONTO gir',
'    left join t_bas_kal_arbeitstage arb on gir.FK_BAS_KAL_Buchungstag = arb.pk_bas_kal_arbeitstage',
'    left join t_bas_kat_kategorie KAT on kat.pk_bas_kat_kategorie = gir.FK_BAS_KAT_Kategorie',
'    left join (select * from t_std where fk_std_group = 9) verw on verw.std_value = gir.FK_std_verw_Verwendungszweck',
'    left join T_REL_kto_KONTO_AUSZUG_GIR relktoaus on relktoaus.fk_main_key = gir.fk_main_key',
'    left join t_kto_konto_auszug ktoaus on ktoaus.pk_KTO_konto_auszug = relktoaus.fk_KTO_konto_auszug',
'    left join (select fk_main_key from t_rel_Inv_inventar_zahlung group by fk_main_key) relinv on relinv.fk_main_key = gir.fk_main_key',
'    left join (select fk_main_key from t_rel_proj_project_payment group by fk_main_key) relproj on relproj.fk_main_key = gir.fk_main_key',
'  where instr('':''||:P105_SEL_KATEGORIE || '':'', '':'' || gir.FK_BAS_KAT_Kategorie  || '':'') >0 or (:P105_SEL_KAtegorie is null and :P105_SHOW_ALL = 1)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2223920510080634)
,p_name=>'Girokonto'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:RP:P111_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>11534055750501555
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2224729485080641)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2225133646080642)
,p_db_column_name=>'Wertstellung'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2225562214080643)
,p_db_column_name=>'Umsatzart'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2229479321080648)
,p_db_column_name=>'alt_ID'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Alt Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2231092970080650)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2191422743681098)
,p_db_column_name=>'BETRAG'
,p_display_order=>28
,p_column_identifier=>'S'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2192384132681108)
,p_db_column_name=>'SEL'
,p_display_order=>58
,p_column_identifier=>'V'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3120034755866584)
,p_db_column_name=>'ID'
,p_display_order=>68
,p_column_identifier=>'W'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3659332726780799)
,p_db_column_name=>'DATUM'
,p_display_order=>128
,p_column_identifier=>'AC'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3659731497780803)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>168
,p_column_identifier=>'AG'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3659783104780804)
,p_db_column_name=>'TAG'
,p_display_order=>178
,p_column_identifier=>'AH'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3659929533780805)
,p_db_column_name=>'MONAT'
,p_display_order=>188
,p_column_identifier=>'AI'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3659996085780806)
,p_db_column_name=>'JAHR'
,p_display_order=>198
,p_column_identifier=>'AJ'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660155364780807)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>208
,p_column_identifier=>'AK'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660217317780808)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>218
,p_column_identifier=>'AL'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660277689780809)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>228
,p_column_identifier=>'AM'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660462541780810)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>238
,p_column_identifier=>'AN'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660522902780811)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>248
,p_column_identifier=>'AO'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660663403780812)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>258
,p_column_identifier=>'AP'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660670762780813)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>268
,p_column_identifier=>'AQ'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5189454807986788)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>278
,p_column_identifier=>'AR'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729231910156720)
,p_db_column_name=>'ANFANGSDATUM'
,p_display_order=>338
,p_column_identifier=>'AX'
,p_column_label=>'Anfangsdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729342186156721)
,p_db_column_name=>'ENDDATUM'
,p_display_order=>348
,p_column_identifier=>'AY'
,p_column_label=>'Enddatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729401872156722)
,p_db_column_name=>'ABHOLDATUM'
,p_display_order=>358
,p_column_identifier=>'AZ'
,p_column_label=>'Abholdatum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729538749156723)
,p_db_column_name=>'KOMMENTAR'
,p_display_order=>368
,p_column_identifier=>'BA'
,p_column_label=>'Kommentar'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729607769156724)
,p_db_column_name=>'ANFANGSBETRAG'
,p_display_order=>378
,p_column_identifier=>'BB'
,p_column_label=>'Anfangsbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6729762918156725)
,p_db_column_name=>'ENDBETRAG'
,p_display_order=>388
,p_column_identifier=>'BC'
,p_column_label=>'Endbetrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7621433221546510)
,p_db_column_name=>'INV_FK_MAIN_KEY'
,p_display_order=>428
,p_column_identifier=>'BG'
,p_column_label=>'Inv fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7621492140546511)
,p_db_column_name=>'PROJ_FK_MAIN_KEY'
,p_display_order=>438
,p_column_identifier=>'BH'
,p_column_label=>'proj_fk_main_key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7621602760546512)
,p_db_column_name=>'SEL1'
,p_display_order=>448
,p_column_identifier=>'BI'
,p_column_label=>'<input type="checkbox" onclick="javascript:$f_CheckAll(this, this.checked, $(''[name=f05]''));">'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(675078088567405)
,p_db_column_name=>'Buchungstext'
,p_display_order=>458
,p_column_identifier=>'BJ'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(675120163567406)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>468
,p_column_identifier=>'BK'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(675234010567407)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>478
,p_column_identifier=>'BL'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623320299507581)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>488
,p_column_identifier=>'BM'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623460284507582)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>498
,p_column_identifier=>'BN'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623505514507583)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>508
,p_column_identifier=>'BO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623660675507584)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>518
,p_column_identifier=>'BP'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623790394507586)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>538
,p_column_identifier=>'BR'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623972139507587)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>548
,p_column_identifier=>'BS'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48623987821507588)
,p_db_column_name=>'FK_STD_KAL_ARBEITSTAG'
,p_display_order=>558
,p_column_identifier=>'BT'
,p_column_label=>'Fk Std Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624131350507589)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>568
,p_column_identifier=>'BU'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624267738507590)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>578
,p_column_identifier=>'BV'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624377262507591)
,p_db_column_name=>'KAT_KATEGORIE'
,p_display_order=>588
,p_column_identifier=>'BW'
,p_column_label=>'Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624469135507592)
,p_db_column_name=>'PK_KTO_KONTO_AUSZUG'
,p_display_order=>598
,p_column_identifier=>'BX'
,p_column_label=>'Pk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624566549507593)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>608
,p_column_identifier=>'BY'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624613993507594)
,p_db_column_name=>'FK_KTO_KONTO_AUSZUG'
,p_display_order=>618
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Kto Konto Auszug'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624774854507595)
,p_db_column_name=>'KTOAUS_JAHR'
,p_display_order=>628
,p_column_identifier=>'CA'
,p_column_label=>'Ktoaus Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624854782507596)
,p_db_column_name=>'KTOAUS_MONAT'
,p_display_order=>638
,p_column_identifier=>'CB'
,p_column_label=>'Ktoaus Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48624898259507597)
,p_db_column_name=>'FK_BAS_KAL_ABHOLDATUM'
,p_display_order=>648
,p_column_identifier=>'CC'
,p_column_label=>'Fk Bas Kal Abholdatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625053760507598)
,p_db_column_name=>'FK_BAS_KAL_ANFANGSDATUM'
,p_display_order=>658
,p_column_identifier=>'CD'
,p_column_label=>'Fk Bas Kal Anfangsdatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625169605507599)
,p_db_column_name=>'FK_BAS_KAL_ENDDATUM'
,p_display_order=>668
,p_column_identifier=>'CE'
,p_column_label=>'Fk Bas Kal Enddatum'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17972740950959700)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>678
,p_column_identifier=>'CF'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17972822334959701)
,p_db_column_name=>'KALENDERWOCHE'
,p_display_order=>688
,p_column_identifier=>'CG'
,p_column_label=>'Kalenderwoche'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2231552331081626)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'115417'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Umsatzart:BETRAG:MONAT:JAHR:KATEGORIE:VERWENDUNGSZWECK::FK_MAIN_KEY:ANFANGSDATUM:ENDDATUM:ABHOLDATUM:KOMMENTAR:ANFANGSBETRAG:ENDBETRAG:INV_FK_MAIN_KEY:PROJ_FK_MAIN_KEY:SEL1:WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:FK_BAS_FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KA'
||'L_BUCHUNGSTAG:PK_BAS_KAL_ARBEITSTAGE:FK_STD_KAL_ARBEITSTAG:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:KAT_KATEGORIE:PK_KTO_KONTO_AUSZUG:FK_KTO_BANKKONTO:FK_KTO_KONTO_AUSZUG:KTOAUS_JAHR:KTOAUS_MONAT:FK_BAS_KAL_ABHOLDATUM:FK_BAS_KAL_ANFANGSDATUM:FK_BAS_'
||'KAL_ENDDATUM:FK_STD_KTO_KONTOTYP:KALENDERWOCHE'
,p_break_on=>'JAHR:MONAT:VERWENDUNGSZWECK:KATEGORIE'
,p_break_enabled_on=>'JAHR:MONAT:VERWENDUNGSZWECK:KATEGORIE'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3737876409959011)
,p_report_id=>wwv_flow_api.id(2231552331081626)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_Kategorie" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''0''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(3738340677959011)
,p_report_id=>wwv_flow_api.id(2231552331081626)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'VERWENDUNGSZWECK:KATEGORIE:MONAT'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(3738727923959011)
,p_pivot_id=>wwv_flow_api.id(3738340677959011)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'BETRAG'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2235933299110816)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Wertstellung'
,p_report_seq=>10
,p_report_type=>'GROUP_BY'
,p_report_alias=>'115461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BETRAG::SEL:FK_BUCHUNGSPK_ARBEITSTAGE:DATUM:FK_ARBEITSFK_WOCHENENDE:FK_FEIERFEIERTAG:TAG:MONAT:JAHR:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:WOCHENTAG:KATEGORIE:VERWENDUNGSZWECK:FK_MAIN_KEY:ANFANGSDATUM:ENDDATUM:ABHOLDATUM:KOMMENTAR:ANFANGSBETRA'
||'G:ENDBETRAG:INV_FK_MAIN_KEY:PROJ_FK_MAIN_KEY:SEL1'
,p_break_on=>'FK_Kategorie:0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_group_by(
 p_id=>wwv_flow_api.id(2236671459158014)
,p_report_id=>wwv_flow_api.id(2235933299110816)
,p_group_by_columns=>'FK_Kategorie'
,p_function_01=>'SUM'
,p_function_column_01=>'BETRAG'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_label_01=>'Betrag'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3739345469970995)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Kategorie'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'130495'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Umsatzart:BETRAG:MONAT:JAHR:KATEGORIE:VERWENDUNGSZWECK::FK_MAIN_KEY:ANFANGSDATUM:ENDDATUM:ABHOLDATUM:KOMMENTAR:ANFANGSBETRAG:ENDBETRAG:INV_FK_MAIN_KEY:PROJ_FK_MAIN_KEY:SEL1'
,p_break_on=>'JAHR:MONAT:VERWENDUNGSZWECK:KATEGORIE'
,p_break_enabled_on=>'JAHR:MONAT:VERWENDUNGSZWECK:KATEGORIE'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3739763285970996)
,p_report_id=>wwv_flow_api.id(3739345469970995)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_Kategorie" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''0''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(3740082790970997)
,p_report_id=>wwv_flow_api.id(3739345469970995)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'VERWENDUNGSZWECK'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(3740514531970997)
,p_pivot_id=>wwv_flow_api.id(3740082790970997)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'BETRAG'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6823733765371705)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'kategorie is null'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'161339'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_view_mode=>'REPORT'
,p_report_columns=>'SEL1:ANFANGSDATUM:ENDDATUM:ANFANGSBETRAG:ENDBETRAG:FK_MAIN_KEY:Buchungstag:Wertstellung:Umsatzart:alt_ID:Bemerkungen:BETRAG:CREATED_AT:CREATED_BY:DATUM:FEIERTAG:INV_FK_MAIN_KEY:PROJ_FK_MAIN_KEY:ID:JAHR:KATEGORIE:MODIFIED_AT:MODIFIED_BY:MONAT:SEL:TAG:'
||'VERWENDUNGSZWECK:WOCHENTAG:ABHOLDATUM:KOMMENTAR'
,p_break_on=>'Wertstellung'
,p_break_enabled_on=>'Wertstellung'
,p_sum_columns_on_break=>'BETRAG'
,p_count_distnt_col_on_break=>'FK_MAIN_KEY'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7647665792840871)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_name=>'fk-main_key'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7648067011840872)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_name=>'zuord_inv'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'INV_FK_MAIN_KEY'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("INV_FK_MAIN_KEY" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7646084601840869)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'Buchungstag'
,p_operator=>'is in the last'
,p_expr=>'2'
,p_expr2=>'months'
,p_condition_sql=>'"Buchungstag" between add_months(sysdate,-1 * #APXWS_EXPR#) and sysdate'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# 2 #APXWS_EXPR2_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7646469261840869)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'is null'
,p_condition_sql=>'"FK_Kategorie" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7646920056840870)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'INV_FK_MAIN_KEY'
,p_operator=>'is null'
,p_condition_sql=>'"INV_FK_MAIN_KEY" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7647280185840871)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KATEGORIE'
,p_operator=>'contains'
,p_expr=>'Auto'
,p_condition_sql=>'upper("KATEGORIE") like ''%''||upper(#APXWS_EXPR#)||''%'''
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''Auto''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_group_by(
 p_id=>wwv_flow_api.id(7648541761840873)
,p_report_id=>wwv_flow_api.id(6823733765371705)
,p_group_by_columns=>'FK_Verwendungszweck'
,p_function_01=>'SUM'
,p_function_column_01=>'BETRAG'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2237101958160607)
,p_application_user=>'ANNE'
,p_name=>'nach Kategorie'
,p_report_seq=>10
,p_report_type=>'GROUP_BY'
,p_report_columns=>'BETRAG'
,p_break_on=>'FK_Kategorie:0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_group_by(
 p_id=>wwv_flow_api.id(2237183921160608)
,p_report_id=>wwv_flow_api.id(2237101958160607)
,p_group_by_columns=>'FK_Kategorie'
,p_function_01=>'SUM'
,p_function_column_01=>'BETRAG'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_label_01=>'Betrag'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2237606710168841)
,p_application_user=>'ANNE'
,p_name=>'Group - nach Verwendungszw'
,p_report_seq=>10
,p_report_type=>'GROUP_BY'
,p_report_columns=>'Buchungstag:Wertstellung:Umsatzart:Bankleitzahl IBAN Kategorie:alt_ID:Bemerkungen:BETRAG'
,p_break_on=>'Wertstellung'
,p_break_enabled_on=>'Wertstellung'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_group_by(
 p_id=>wwv_flow_api.id(2238403940179062)
,p_report_id=>wwv_flow_api.id(2237606710168841)
,p_group_by_columns=>'FK_Verwendungszweck'
,p_function_01=>'SUM'
,p_function_column_01=>'BETRAG'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2237996888175248)
,p_application_user=>'ANNE'
,p_name=>'Group - Gesamt'
,p_report_seq=>10
,p_report_type=>'GROUP_BY'
,p_report_columns=>'Buchungstag:Wertstellung:Umsatzart:Bankleitzahl IBAN Kategorie:alt_ID:Bemerkungen:BETRAG'
,p_break_on=>'Wertstellung'
,p_break_enabled_on=>'Wertstellung'
,p_sum_columns_on_break=>'BETRAG'
);
wwv_flow_api.create_worksheet_group_by(
 p_id=>wwv_flow_api.id(2238103804175248)
,p_report_id=>wwv_flow_api.id(2237996888175248)
,p_group_by_columns=>'IBAN Auftraggeberkonto'
,p_function_01=>'SUM'
,p_function_column_01=>'BETRAG'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2460307229770581)
,p_plug_name=>'Kreditkarte'
,p_parent_plug_id=>wwv_flow_api.id(2460217071770580)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kred.*, ',
'   apex_item.checkbox(2, id) sel, ',
'   round(kred."Betrag",2) wert,',
'   arb.*,',
'   kat.Kategorie kat_Kategorie,',
'   verw.std_name Verwendungszweck',
'from t_KTO_Kreditkarte kred',
'    left join t_BAS_KAL_arbeitstage arb on kred.FK_BAS_KAL_Buchungstag = arb.pk_BAS_KAL_arbeitstage',
'    left join t_BAS_KAT_kategorie kat on kat.pk_BAS_KAT_kategorie = kred.FK_BAS_KAT_Kategorie',
'    left join (Select * from t_std where fk_std_group = 9) verw on verw.std_value = kred.FK_std_verw_Verwendungszweck',
'where instr('':''||:P105_SEL_KATEGORIE || '':'', '':'' || kred.FK_bas_kat_Kategorie  || '':'') >0  or (:P105_SEL_KAtegorie is null and :P105_SHOW_ALL = 1)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2460382161770582)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11770517402191503
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2460601571770584)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2460702820770585)
,p_db_column_name=>'Beleg'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2460832421770586)
,p_db_column_name=>'Unternehmen'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2460957999770587)
,p_db_column_name=>'Betrag'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'S999G999G999G999G990D00'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2461164402770589)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Betrag ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2461350930770591)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2461544265770593)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479100929878111)
,p_db_column_name=>'Dummy'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Dummy'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479259221878112)
,p_db_column_name=>'Referenz'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Referenz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479316598878113)
,p_db_column_name=>'SEL'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479653140878116)
,p_db_column_name=>'WERT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3660812805780814)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3661238580780818)
,p_db_column_name=>'FK_MAIN_BELEG'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Fk main beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3661347638780819)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3661773666780824)
,p_db_column_name=>'DATUM'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3662165787780828)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3662347423780829)
,p_db_column_name=>'TAG'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3741939104022180)
,p_db_column_name=>'MONAT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742034225022181)
,p_db_column_name=>'JAHR'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742152802022182)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742248035022183)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742302066022184)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742449315022185)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742470862022186)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742614991022187)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742711300022188)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625237694507600)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625340646507601)
,p_db_column_name=>'WAEHRUNG_URSPRUNG'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Waehrung Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625396842507602)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625491477507603)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625687817507605)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625863894507606)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48625946411507607)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48626066313507608)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48626140719507609)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48626274377507610)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48730989972910061)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731124525910062)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731200048910063)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731285357910064)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731386145910065)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731563214910066)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731597622910067)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731736801910068)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731822920910069)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48731896260910070)
,p_db_column_name=>'FK_STD_KAL_ARBEITSTAG'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Fk Std Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732035396910071)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732095496910072)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732250013910073)
,p_db_column_name=>'KAT_KATEGORIE'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17972908255959702)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973015997959703)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973113422959704)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973185489959705)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973318906959706)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973476115959707)
,p_db_column_name=>'KALENDERWOCHE'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Kalenderwoche'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2495562403878938)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118057'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:WERT:Buchungstag:Beleg:Unternehmen:Betrag:Betrag Ursprung:Belastete Kreditkarte:Wertstellungsmonat:Dummy:Referenz::FK_MAIN_BELEG:FK_MAIN_KEY:FK_BUCHUNGSFK_BELEG:DATUM:FK_ARBEITSFK_WOCHENENDE:FK_FEIERFEIERTAG:TAG:MONAT:JAHR:CREATED_BY:CREATED_AT:M'
||'ODIFIED_BY:MODIFIED_AT:WOCHENTAG:KATEGORIE:VERWENDUNGSZWECK:WAEHRUNG:WAEHRUNG_URSPRUNG:FK_BAS_FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_BUCHUNGSTAG:FK_BEL_BELEG:BEMERKUNG:FK_KTO_BANKKONTO:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KT'
||'O_VORGANG:FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BEMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:PK_BAS_KAL_ARBEITSTAGE:FK_STD_KAL_ARBEITSTAG:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:KAT_KATEGORIE:FK_STD_KTO_KONTOTYP:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_'
||'STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_KAT:KALENDERWOCHE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2592970291630632)
,p_report_id=>wwv_flow_api.id(2495562403878938)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Verwendungszweck'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_Verwendungszweck" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''0''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2593386915630632)
,p_report_id=>wwv_flow_api.id(2495562403878938)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Kategorie'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_Kategorie" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''0''  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3764701050044961)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Verwendungszweck'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'130749'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WERT:VERWENDUNGSZWECK'
,p_break_on=>'JAHR:VERWENDUNGSZWECK'
,p_break_enabled_on=>'JAHR:VERWENDUNGSZWECK'
,p_sum_columns_on_break=>'Betrag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3765153782044962)
,p_report_id=>wwv_flow_api.id(3764701050044961)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FK_Verwendungszweck'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>'"FK_Verwendungszweck" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''0''  '
,p_enabled=>'N'
);
wwv_flow_api.create_worksheet_pivot(
 p_id=>wwv_flow_api.id(3765562904044962)
,p_report_id=>wwv_flow_api.id(3764701050044961)
,p_pivot_columns=>'JAHR'
,p_row_columns=>'VERWENDUNGSZWECK'
);
wwv_flow_api.create_worksheet_pivot_agg(
 p_id=>wwv_flow_api.id(3765925075044963)
,p_pivot_id=>wwv_flow_api.id(3765562904044962)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'WERT'
,p_db_column_name=>'PFC1'
,p_format_mask=>'999G999G999G999G990'
,p_display_sum=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2461851405770596)
,p_plug_name=>'Tagesgeldkonto'
,p_parent_plug_id=>wwv_flow_api.id(2460217071770580)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
' tag.* , ',
' apex_item.checkbox(3, id) sel,',
' arb.*,',
' kat.Kategorie kat_Kategorie,',
' verw.std_name Verwendungszweck',
'from t_KTO_Tagesgeldkonto tag',
'    left join t_bas_kal_arbeitstage arb on tag.FK_bas_kal_Buchungstag = arb.pk_bas_kal_arbeitstage',
'    left join t_bas_kat_kategorie kat on kat.pk_bas_kat_kategorie = tag.FK_bas_kat_Kategorie',
'    left join (select * from t_std where fk_std_group = 9) verw on verw.std_value= tag.FK_std_verw_Verwendungszweck',
'where instr('':''||:P105_SEL_KATEGORIE || '':'', '':'' || FK_bas_kat_Kategorie  || '':'') >0  or (:P105_SEL_KAtegorie is null and :P105_SHOW_ALL = 1)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2461924894770597)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11772060135191518
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462115456770599)
,p_db_column_name=>'Buchungstag'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462235532770600)
,p_db_column_name=>'Wertstellung'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462336757770601)
,p_db_column_name=>'Umsatzart'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462373566770602)
,p_db_column_name=>'Buchungstext'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Buchungstext'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462521229770603)
,p_db_column_name=>'Betrag'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462693592770605)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2462954485770607)
,p_db_column_name=>'IBAN Auftraggeberkonto'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Iban auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479432707878114)
,p_db_column_name=>'SEL'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3742860535022189)
,p_db_column_name=>'ID'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3743071705022192)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3743465081022196)
,p_db_column_name=>'BUCHUNGSTEXT'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3743738644022198)
,p_db_column_name=>'DATUM'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744113509022202)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744224668022203)
,p_db_column_name=>'TAG'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744295663022204)
,p_db_column_name=>'MONAT'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744454539022205)
,p_db_column_name=>'JAHR'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744555600022206)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744629449022207)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744740902022208)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744804545022209)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3744865011022210)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3745042845022211)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3745119051022212)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732285856910074)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732454349910075)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732556948910076)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732662123910077)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732769951910078)
,p_db_column_name=>'FK_BAS_KAL_BUCHUNGSTAG'
,p_display_order=>430
,p_column_identifier=>'AQ'
,p_column_label=>'Fk Bas Kal Buchungstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732868411910079)
,p_db_column_name=>'FK_BAS_KAL_WERTSTELLUNG'
,p_display_order=>440
,p_column_identifier=>'AR'
,p_column_label=>'Fk Bas Kal Wertstellung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48732896232910080)
,p_db_column_name=>'FK_BAS_KTO_KONTOTYP'
,p_display_order=>450
,p_column_identifier=>'AS'
,p_column_label=>'Fk Bas Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733061878910081)
,p_db_column_name=>'KONTOSTAND'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Kontostand'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733121467910082)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733272105910083)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733348178910084)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>490
,p_column_identifier=>'AW'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733448057910085)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>500
,p_column_identifier=>'AX'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733532275910086)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>510
,p_column_identifier=>'AY'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733655748910087)
,p_db_column_name=>'DATUM_DUPL_OK'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Datum Dupl Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733726071910088)
,p_db_column_name=>'DUPL_BEMERKUNG'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Dupl Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733876444910089)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48733925045910090)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734043002910091)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734093454910092)
,p_db_column_name=>'FK_STD_KAL_ARBEITSTAG'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Fk Std Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734182106910093)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>580
,p_column_identifier=>'BF'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734356993910094)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734469184910095)
,p_db_column_name=>'KAT_KATEGORIE'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973503610959708)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973583163959709)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973731654959710)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973830164959711)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>640
,p_column_identifier=>'BL'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17973972540959712)
,p_db_column_name=>'KALENDERWOCHE'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Kalenderwoche'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2496104120878943)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118063'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:Buchungstag:Wertstellung:Umsatzart:Buchungstext:Betrag:Auftraggeberkonto:IBAN Auftraggeberkonto::FK_MAIN_KEY:FK_BUCHUNGSFK_WERTSTELLUNG:BUCHUNGSTEXT:DATUM:FK_ARBEITSFK_WOCHENENDE:FK_FEIERFEIERTAG:TAG:MONAT:JAHR:CREATED_BY:CREATED_AT:MODIFIED_BY:M'
||'ODIFIED_AT:WOCHENTAG:KATEGORIE:VERWENDUNGSZWECK:WAEHRUNG:FK_BAS_FK_STD_VERW_VERWENDUNGSZWECK:FK_BAS_KAL_BUCHUNGSTAG:FK_BAS_KAL_WERTSTELLUNG:FK_BAS_KTO_KONTOTYP:KONTOSTAND:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BANKKONTO:FK_CONTR_DUPL_'
||'STATUS:DATUM_DUPL_OK:DUPL_BEMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:PK_BAS_KAL_ARBEITSTAGE:FK_STD_KAL_ARBEITSTAG:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:KAT_KATEGORIE:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS_VERW:DATUM_STATUS_K'
||'AT:KALENDERWOCHE'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2463272503770611)
,p_plug_name=>'Paypal'
,p_parent_plug_id=>wwv_flow_api.id(2460217071770580)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  pay.*, ',
'  apex_item.checkbox(4, id) sel,',
'  arb.PK_bas_kal_ARBEITSTAGE, arb.DATUM, arb.FK_std_kal_ARBEITSTAG ARBEITSTAG, arb.FK_std_kal_WOCHENENDE, arb.FK_std_kal_FEIERTAG, arb.FEIERTAG, arb.TAG, arb.MONAT, arb.JAHR, arb.WOCHENTAG,',
'  kat.Kategorie kat_Kategorie,',
'  verw.std_name Verwendungszweck',
'from t_KTO_Paypal pay',
'    left join T_BAS_KAL_arbeitstage arb on pay.FK_BAS_KAL_arbeitstag= arb.pk_BAS_KAL_arbeitstage',
'    left join t_BAS_KAT_kategorie kat on kat.pk_BAS_KAT_kategorie = pay.FK_BAS_KAT_Kategorie',
'    left join (select * from t_std where fk_std_group = 9) verw on verw.std_value = pay.FK_std_verw_Verwendungszweck',
'',
'where instr('':''||:P105_SEL_KATEGORIE || '':'', '':'' || FK_bas_kat_Kategorie  || '':'') >0  or (:P105_SEL_KAtegorie is null and :P105_SHOW_ALL = 1)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2463498063770613)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>11773633304191534
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2463745642770615)
,p_db_column_name=>'Datum'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2463806183770616)
,p_db_column_name=>'Uhrzeit'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Uhrzeit'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2463917367770617)
,p_db_column_name=>'Zeitzone'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Zeitzone'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2463987053770618)
,p_db_column_name=>'Name'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464100887770619)
,p_db_column_name=>'Typ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464197732770620)
,p_db_column_name=>'Status'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464406292770622)
,p_db_column_name=>'Brutto'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Brutto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464605850770624)
,p_db_column_name=>'Netto'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Netto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464699725770625)
,p_db_column_name=>'Absender_Email'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Absender email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2464957094770627)
,p_db_column_name=>'Transaktionscode'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2465028258770628)
,p_db_column_name=>'Lieferadresse'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Lieferadresse'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2465068987770629)
,p_db_column_name=>'Adress-Status'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Adress-status'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476013609878080)
,p_db_column_name=>'Artikelbezeichnung'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Artikelbezeichnung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476145156878081)
,p_db_column_name=>'Artikelnummer'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Artikelnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476241771878082)
,p_db_column_name=>'Versand_Bearbeitungsgeb'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Versand bearbeitungsgeb'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476299447878083)
,p_db_column_name=>'Versicherungsbetrag'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Versicherungsbetrag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476386189878084)
,p_db_column_name=>'Umsatzsteuer'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Umsatzsteuer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476476189878085)
,p_db_column_name=>'Option 1 Name'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Option 1 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476619088878086)
,p_db_column_name=>'Option 1 Wert'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Option 1 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476701015878087)
,p_db_column_name=>'Option 2 Name'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Option 2 name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476810462878088)
,p_db_column_name=>'Option 2 Wert'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Option 2 wert'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2476992566878090)
,p_db_column_name=>'Rechnungsnummer'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Rechnungsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477110207878091)
,p_db_column_name=>'Zollnummer'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Zollnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477171797878092)
,p_db_column_name=>'Anzahl'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Anzahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477340765878093)
,p_db_column_name=>'Empfangsnummer'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Empfangsnummer'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477467628878095)
,p_db_column_name=>'Adresszeile 1'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Adresszeile 1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477647704878096)
,p_db_column_name=>'Adresszusatz'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Adresszusatz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477691945878097)
,p_db_column_name=>'Ort'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Ort'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477802504878098)
,p_db_column_name=>'Bundesland'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Bundesland'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2477872101878099)
,p_db_column_name=>'PLZ'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Plz'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2478033455878100)
,p_db_column_name=>'Land'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Land'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2478114220878101)
,p_db_column_name=>'Telefon'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Telefon'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2478215438878102)
,p_db_column_name=>'Betreff'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Betreff'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2478355637878103)
,p_db_column_name=>'Hinweis'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Hinweis'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2478563376878105)
,p_db_column_name=>'Auswirkung_Guthaben'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Auswirkung guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2479493197878115)
,p_db_column_name=>'SEL'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3745165900022213)
,p_db_column_name=>'ID'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3745711927022218)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3745981003022221)
,p_db_column_name=>'DATUM'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746122644022222)
,p_db_column_name=>'ARBEITSTAG'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746452549022225)
,p_db_column_name=>'FEIERTAG'
,p_display_order=>590
,p_column_identifier=>'BG'
,p_column_label=>'Feiertag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746525289022226)
,p_db_column_name=>'TAG'
,p_display_order=>600
,p_column_identifier=>'BH'
,p_column_label=>'Tag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746650951022227)
,p_db_column_name=>'MONAT'
,p_display_order=>610
,p_column_identifier=>'BI'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746683727022228)
,p_db_column_name=>'JAHR'
,p_display_order=>620
,p_column_identifier=>'BJ'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3746816387022229)
,p_db_column_name=>'WOCHENTAG'
,p_display_order=>630
,p_column_identifier=>'BK'
,p_column_label=>'Wochentag'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3783667006134181)
,p_db_column_name=>'VERWENDUNGSZWECK'
,p_display_order=>650
,p_column_identifier=>'BM'
,p_column_label=>'Verwendungszweck'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734533273910096)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>660
,p_column_identifier=>'BN'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734650169910097)
,p_db_column_name=>'GEBUEHR'
,p_display_order=>670
,p_column_identifier=>'BO'
,p_column_label=>'Gebuehr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734759483910098)
,p_db_column_name=>'EMPFAENGER_EMAIL'
,p_display_order=>680
,p_column_identifier=>'BP'
,p_column_label=>'Empfaenger Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734857853910099)
,p_db_column_name=>'ZUGEHOERIGER_TRANSAKTIONSCODE'
,p_display_order=>690
,p_column_identifier=>'BQ'
,p_column_label=>'Zugehoeriger Transaktionscode'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48734928217910100)
,p_db_column_name=>'Guthaben'
,p_display_order=>700
,p_column_identifier=>'BR'
,p_column_label=>'Guthaben'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735011046910101)
,p_db_column_name=>'LAENDERVORWAHL'
,p_display_order=>710
,p_column_identifier=>'BS'
,p_column_label=>'Laendervorwahl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735145664910102)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>720
,p_column_identifier=>'BT'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735269935910103)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>730
,p_column_identifier=>'BU'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735417237910105)
,p_db_column_name=>'FK_KTO_VORGANG'
,p_display_order=>750
,p_column_identifier=>'BW'
,p_column_label=>'Fk Kto Vorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735531231910106)
,p_db_column_name=>'FK_BAS_KAL_ARBEITSTAG'
,p_display_order=>760
,p_column_identifier=>'BX'
,p_column_label=>'Fk Bas Kal Arbeitstag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735680475910107)
,p_db_column_name=>'FK_ZUORD_ERL'
,p_display_order=>770
,p_column_identifier=>'BY'
,p_column_label=>'Fk Zuord Erl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735780453910108)
,p_db_column_name=>'FK_BEL_BELEG'
,p_display_order=>780
,p_column_identifier=>'BZ'
,p_column_label=>'Fk Bel Beleg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735879607910109)
,p_db_column_name=>'WIEDERHOLUNG'
,p_display_order=>790
,p_column_identifier=>'CA'
,p_column_label=>'Wiederholung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48735970705910110)
,p_db_column_name=>'NAECHSTE_ZAHLUNG'
,p_display_order=>800
,p_column_identifier=>'CB'
,p_column_label=>'Naechste Zahlung'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48782943391065761)
,p_db_column_name=>'FK_BUCHUNG_STEUER'
,p_display_order=>810
,p_column_identifier=>'CC'
,p_column_label=>'Fk Buchung Steuer'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783017687065762)
,p_db_column_name=>'FK_KTO_BANKKONTO'
,p_display_order=>820
,p_column_identifier=>'CD'
,p_column_label=>'Fk Kto Bankkonto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783180075065763)
,p_db_column_name=>'FK_CONTR_DUPL_STATUS'
,p_display_order=>830
,p_column_identifier=>'CE'
,p_column_label=>'Fk Contr Dupl Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783271318065764)
,p_db_column_name=>'DUPL_DATUM_OK'
,p_display_order=>840
,p_column_identifier=>'CF'
,p_column_label=>'Dupl Datum Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783335094065765)
,p_db_column_name=>'DUPL_BERMERKUNG'
,p_display_order=>850
,p_column_identifier=>'CG'
,p_column_label=>'Dupl Bermerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783383059065766)
,p_db_column_name=>'DATUM_LEX_BUCHUNG_OK'
,p_display_order=>860
,p_column_identifier=>'CH'
,p_column_label=>'Datum Lex Buchung Ok'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783482705065767)
,p_db_column_name=>'FK_EIN_AUS'
,p_display_order=>870
,p_column_identifier=>'CI'
,p_column_label=>'Fk Ein Aus'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783623224065768)
,p_db_column_name=>'PK_BAS_KAL_ARBEITSTAGE'
,p_display_order=>880
,p_column_identifier=>'CJ'
,p_column_label=>'Pk Bas Kal Arbeitstage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783774973065769)
,p_db_column_name=>'FK_STD_KAL_WOCHENENDE'
,p_display_order=>890
,p_column_identifier=>'CK'
,p_column_label=>'Fk Std Kal Wochenende'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783783154065770)
,p_db_column_name=>'FK_STD_KAL_FEIERTAG'
,p_display_order=>900
,p_column_identifier=>'CL'
,p_column_label=>'Fk Std Kal Feiertag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783952569065771)
,p_db_column_name=>'KAT_KATEGORIE'
,p_display_order=>910
,p_column_identifier=>'CM'
,p_column_label=>'Kat Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17974079012959713)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>920
,p_column_identifier=>'CN'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17974140939959714)
,p_db_column_name=>'FK_STD_CONTR_STATUS_KAT'
,p_display_order=>930
,p_column_identifier=>'CO'
,p_column_label=>'Fk Std Contr Status Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17974260798959715)
,p_db_column_name=>'FK_STD_CONTR_STATUS_VERW'
,p_display_order=>940
,p_column_identifier=>'CP'
,p_column_label=>'Fk Std Contr Status Verw'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18171231790850066)
,p_db_column_name=>'DATUM_STATUS_VERW'
,p_display_order=>950
,p_column_identifier=>'CQ'
,p_column_label=>'Datum Status Verw'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18171291966850067)
,p_db_column_name=>'DATUM_STATUS_KAT'
,p_display_order=>960
,p_column_identifier=>'CR'
,p_column_label=>'Datum Status Kat'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2496786947878946)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118070'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:Datum:Uhrzeit:Zeitzone:Name:Typ:Status:Brutto:Netto:Absender_Email:Transaktionscode:Lieferadresse:Adress-Status:Artikelbezeichnung:Artikelnummer:Versand_Bearbeitungsgeb:Versicherungsbetrag:Umsatzsteuer:Option 1 Name:Option 1 Wert:Option 2 Name:Op'
||'tion 2 Wert:Rechnungsnummer:Zollnummer:Anzahl:Empfangsnummer:Adresszeile 1:Adresszusatz:Ort:Bundesland:PLZ:Land:Telefon:Betreff:Hinweis:Auswirkung_:FK_MAIN_KEY:FK_PK_ARBEITSTAGE:DATUM:ARBEITSFK_WOCHENENDE:FK_FEIERFEIERTAG:TAG:MONAT:JAHR:WOCHENTAG:VER'
||'WENDUNGSZWECK:WAEHRUNG:GEBUEHR:EMPFAENGER_EMAIL:ZUGEHOERIGER_TRANSAKTIONSCODE:LAENDERVORWAHL:FK_BAS_FK_STD_VERW_VERWENDUNGSZWECK:FK_KTO_VORGANG:FK_BAS_KAL_ARBEITSTAG:FK_ZUORD_ERL:FK_BEL_BELEG:WIEDERHOLUNG:NAECHSTE_ZAHLUNG:FK_BUCHUNG_STEUER:FK_KTO_BAN'
||'KKONTO:FK_CONTR_DUPL_STATUS:DUPL_DATUM_OK:DUPL_BERMERKUNG:DATUM_LEX_BUCHUNG_OK:FK_EIN_AUS:PK_BAS_KAL_ARBEITSTAGE:FK_STD_KAL_WOCHENENDE:FK_STD_KAL_FEIERTAG:KAT_KATEGORIE:FK_STD_KTO_KONTOTYP:FK_STD_CONTR_STATUS_KAT:FK_STD_CONTR_STATUS_VERW:DATUM_STATUS'
||'_VERW:DATUM_STATUS_KAT'
,p_sort_column_1=>'JAHR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'KATEGORIE'
,p_break_enabled_on=>'KATEGORIE'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3804210644164018)
,p_report_id=>wwv_flow_api.id(2496786947878946)
,p_name=>'2017'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2017'
,p_condition_sql=>' (case when ("JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D4FFD4'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(3804653964164018)
,p_report_id=>wwv_flow_api.id(2496786947878946)
,p_name=>'2018'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'JAHR'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>' (case when ("JAHR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#D4D4D4'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8356431290137198)
,p_plug_name=>'Step 4'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8344149756137189)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8356536728137198)
,p_plug_name=>'Step 4'
,p_parent_plug_id=>wwv_flow_api.id(8356431290137198)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12748389376666712)
,p_plug_name=>'letzte_Buchung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto_zus.Kontotyp, max(kto_zus."Buchungstag") buchungstag, count(*) cnt, IBAN_Auftraggeberkonto',
'from v_kto_konten_zus kto_zus',
'  left join t_KTO_GIROKONTO gir on kto_zus.fk_main_key = gir.fk_main_key',
'group by  kto_zus.Kontotyp, IBAN_Auftraggeberkonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12748551595666713)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>22058686836087634
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12748674726666715)
,p_db_column_name=>'BUCHUNGSTAG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12748850168666716)
,p_db_column_name=>'CNT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48361877926732877)
,p_db_column_name=>'KONTOTYP'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Kontotyp'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48361923865732878)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12782784651926853)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'220930'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BUCHUNGSTAG:CNT:KONTOTYP:IBAN_AUFTRAGGEBERKONTO'
,p_sum_columns_on_break=>'CNT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(19532951644835637)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2223781148080634)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:111:P111_ID:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7621837043546514)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2192563515681109)
,p_button_name=>'Add_inventar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Add inventar'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2192806353681112)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(2192563515681109)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2193597633681120)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(2192563515681109)
,p_button_name=>'SET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Set filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2193884646681123)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(2192563515681109)
,p_button_name=>'RESET_FILTER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Reset filter'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8358246069137199)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8356431290137198)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8358523710137199)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8356431290137198)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8358431862137199)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8356431290137198)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8359987561137199)
,p_branch_action=>'f?p=&APP_ID.:106:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8358523710137199)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8359228284137199)
,p_branch_action=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8358431862137199)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2192657572681110)
,p_name=>'P105_KATEGORIE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2192563515681109)
,p_prompt=>'Kategorie'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie',
'ORDER BY Kategorie'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'0'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2192729282681111)
,p_name=>'P105_VERWENDUNGSZWECK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(2192563515681109)
,p_prompt=>'Verwendungszweck'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select std_name, std_value',
'from t_std',
'where fk_std_group = 9'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'0'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2193392091681118)
,p_name=>'P105_SEL_KATEGORIE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(2192563515681109)
,p_prompt=>'Sel kategorie'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select Kategorie, pk_bas_kat_kategorie',
'from t_bas_kat_kategorie',
'ORDER BY Kategorie'))
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2478875672878109)
,p_name=>'P105_SHOW_ALL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(2192563515681109)
,p_prompt=>'Show all'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select ''Show all'', 1 from dual'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Keine Angabe'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7621698293546513)
,p_name=>'P105_FK_INV_INVENTAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2192563515681109)
,p_prompt=>'Fk inventar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select inventar || '' '' || anschaffungsjahr, pk_INV_inventar',
'from t_INV_inventare'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8357911204137198)
,p_name=>'P105_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8356536728137198)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2194029495681124)
,p_name=>'SET_FILTER'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2193597633681120)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2194071194681125)
,p_event_id=>wwv_flow_api.id(2194029495681124)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P105_SEL_KATEGORIE,P105_SHOW_ALL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2194210611681126)
,p_event_id=>wwv_flow_api.id(2194029495681124)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(2194329123681127)
,p_name=>'RESET_FILTER'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(2193884646681123)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2194368999681128)
,p_event_id=>wwv_flow_api.id(2194329123681127)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P105_SEL_KATEGORIE := Null;'
,p_attribute_02=>'P105_SEL_KATEGORIE,P105_SHOW_ALL'
,p_attribute_03=>'P105_SEL_KATEGORIE,P105_SHOW_ALL'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(2194514030681129)
,p_event_id=>wwv_flow_api.id(2194329123681127)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(2193277409681117)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Kat_Ver'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'',
'    --Girokonto',
'    if apex_application.g_f01(i) is not null then',
'       update KTO_Girokonto set "FK_Kategorie" = :P105_KATEGORIE, ',
'        "FK_Verwendungszweck" = :P105_Verwendungszweck where id = apex_application.g_f01(i);',
'       commit;       ',
'    end if;',
'    ',
'',
'  ',
'  end loop;',
'  ',
'  for i in 1..apex_application.g_f02.count loop',
'    --Kreditkartenkonto',
'    if apex_application.g_f02(i) is not null then',
'       update KTO_Kreditkarte set "FK_Kategorie" = :P105_KATEGORIE, ',
'        "FK_Verwendungszweck" = :P105_Verwendungszweck where id = apex_application.g_f02(i);',
'       commit;       ',
'    end if;',
'    ',
'   end loop;',
'    ',
'   for i in 1..apex_application.g_f03.count loop',
'    --Tagesgeldkonto',
'    if apex_application.g_f03(i) is not null then',
'       update KTO_Tagesgeldkonto set "FK_Kategorie" = :P105_KATEGORIE, ',
'        "FK_Verwendungszweck" = :P105_Verwendungszweck where id = apex_application.g_f03(i);',
'       commit;       ',
'    end if;',
'    ',
'    end loop;',
'    ',
'   for i in 1..apex_application.g_f04.count loop',
'    --Paypal',
'    if apex_application.g_f04(i) is not null then',
'       update KTO_Paypal set "FK_Kategorie" = :P105_KATEGORIE, ',
'        "FK_Verwendungszweck" = :P105_Verwendungszweck where id = apex_application.g_f04(i);',
'       commit;       ',
'    end if;',
'   end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(2192806353681112)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7621964361546515)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_inventar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f05.count loop',
'  ',
'    if apex_application.g_f05(i) is not null then',
'      insert into t_rel_inventar_zahlung (',
'        fk_inventar,',
'        fk_main_key',
'      )',
'      select :P105_fk_inventar,',
'      apex_application.g_f05(i)',
'      from dual;',
'      commit;',
'    ',
'    end if;',
'  end loop;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7621837043546514)
);
wwv_flow_api.component_end;
end;
/
