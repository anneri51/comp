prompt --application/pages/page_00218
begin
--   Manifest
--     PAGE: 00218
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>218
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kontenplan_konten_Kat_zuord'
,p_alias=>'KONTENPLAN_KONTEN_KAT_ZUORD'
,p_step_title=>'Kontenplan_konten_Kat_zuord'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200925101655'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8300238239059281)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8308313281411400)
,p_plug_name=>'Kontenplan_konten_Kat_zuord'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'apex_item.checkbox2(1,kto.pk_lex_kontenplan_konten) sel,',
'kto.PK_lex_KONTENPLAN_KONTEN,',
'kto.KONTEN_NR_EXT,',
'kto.BEZEICHNUNG bez,',
'kto.FK_LEX_KONTENPLAN ktopl,',
'kto.FK_LEX_KONTENPLAN_KONTEN_GRP,',
'kto.FK_LEX_KONTENPLAN_KONTEN_GRP2,',
'kto.FK_LEX_KONTENPLAN_KONTEN_KL,',
'kto.FK_LEX_KONTENPLAN_KONTEN_TYP,',
'ktokat.*,',
'ktokatgrp.bezeichnung ktogrp_bez',
'from t_lex_kontenplan_konten kto',
' left join t_rel_lex_kontenplan_kto_kto_kat ktoktokat on ktoktokat.fk_lex_kontenplan_konten = kto.pk_lex_kontenplan_konten',
' left join t_lex_kontenplan_konten_kat ktokat on ktokat.pk_lex_kontenplan_konten_kat = ktoktokat.fk_lex_kontenplan_konten_kat',
' left JOIN T_lex_KONTENplan_konten_kat_grp ktokatgrp on ktokat.fk_lex_kontenplan_konten_kat_grp  = ktokatgrp.pk_lex_kontenplan_konten_kat_grp'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(8308443208411400)
,p_name=>'Kontenplan_konten_Kat_zuord'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>17618578448832321
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8308811759411416)
,p_db_column_name=>'SEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8309556530411425)
,p_db_column_name=>'KONTEN_NR_EXT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Konten Nr Ext'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8309906175411425)
,p_db_column_name=>'BEZEICHNUNG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Bezeichnung'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8300959514059288)
,p_db_column_name=>'BEZ'
,p_display_order=>19
,p_column_identifier=>'J'
,p_column_label=>'Bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301049068059289)
,p_db_column_name=>'KTOPL'
,p_display_order=>29
,p_column_identifier=>'K'
,p_column_label=>'Ktopl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8301286005059292)
,p_db_column_name=>'KTOGRP_BEZ'
,p_display_order=>59
,p_column_identifier=>'N'
,p_column_label=>'Ktogrp bez'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730862386515001)
,p_db_column_name=>'PK_LEX_KONTENPLAN_KONTEN'
,p_display_order=>69
,p_column_identifier=>'O'
,p_column_label=>'Pk Lex Kontenplan Konten'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730974020515002)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_GRP'
,p_display_order=>79
,p_column_identifier=>'P'
,p_column_label=>'Fk Lex Kontenplan Konten Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50730982210515003)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_GRP2'
,p_display_order=>89
,p_column_identifier=>'Q'
,p_column_label=>'Fk Lex Kontenplan Konten Grp2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50731091623515004)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_KL'
,p_display_order=>99
,p_column_identifier=>'R'
,p_column_label=>'Fk Lex Kontenplan Konten Kl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50731222385515005)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_TYP'
,p_display_order=>109
,p_column_identifier=>'S'
,p_column_label=>'Fk Lex Kontenplan Konten Typ'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50731324363515006)
,p_db_column_name=>'PK_LEX_KONTENPLAN_KONTEN_KAT'
,p_display_order=>119
,p_column_identifier=>'T'
,p_column_label=>'Pk Lex Kontenplan Konten Kat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50731390581515007)
,p_db_column_name=>'FK_LEX_KONTENPLANLEX_'
,p_display_order=>129
,p_column_identifier=>'U'
,p_column_label=>'Fk Lex Kontenplanlex'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(50731504579515008)
,p_db_column_name=>'FK_LEX_KONTENPLAN_KONTEN_KAT_GRP'
,p_display_order=>139
,p_column_identifier=>'V'
,p_column_label=>'Fk Lex Kontenplan Konten Kat Grp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8315748716496891)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'176259'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:BEZ:KTOPL:KONTEN_NR_EXT:BEZEICHNUNG:KTOGRP_BEZ::PK_LEX_KONTENPLAN_KONTEN:FK_LEX_KONTENPLAN_KONTEN_GRP:FK_LEX_KONTENPLAN_KONTEN_GRP2:FK_LEX_KONTENPLAN_KONTEN_KL:FK_LEX_KONTENPLAN_KONTEN_TYP:PK_LEX_KONTENPLAN_KONTEN_KAT:FK_LEX_KONTENPLANLEX_:FK_LEX'
||'_KONTENPLAN_KONTEN_KAT_GRP'
,p_break_on=>'0:0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0:0'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8319005135548894)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Konten'
,p_report_seq=>10
,p_report_alias=>'176292'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:BEZ:KTOPL:BEZEICHNUNG:KONTEN_NR_EXT::KTOGRP_BEZ'
,p_break_on=>'KONTEN_NR_EXT:BEZ:0:0:0:0'
,p_break_enabled_on=>'KONTEN_NR_EXT:BEZ:0:0:0:0'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8319481510555409)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'nach Kategorie'
,p_report_seq=>10
,p_report_alias=>'176297'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEL:KONTEN_NR_EXT:BEZ:KTOPL:BEZEICHNUNG::KTOGRP_BEZ'
,p_sort_column_1=>'KONTEN_NR_EXT'
,p_sort_direction_1=>'ASC'
,p_break_on=>'KTOGRP_BEZ:BEZEICHNUNG:0:0:0:0'
,p_break_enabled_on=>'KTOGRP_BEZ:BEZEICHNUNG:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(8322740529642869)
,p_report_id=>wwv_flow_api.id(8319481510555409)
,p_name=>'Row text contains ''6495'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'6495'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8300554640059284)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8300238239059281)
,p_button_name=>'Update_Kat_grp'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update kat grp'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8300616417059285)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8300238239059281)
,p_button_name=>'Update_kat'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Update_kat'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8300342675059282)
,p_name=>'P218_KAT_GRP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8300238239059281)
,p_prompt=>'Kat grp'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bezeichnung, pk_lex_kontenplan_konten_kat_grp',
'from t_lex_kontenplan_konten_kat_grp'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8300371293059283)
,p_name=>'P218_KAT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8300238239059281)
,p_prompt=>'New'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select kto.bezeichnung || '' ('' || ktogrp.bezeichnung || '')'', pk_lex_kontenplan_konten_kat',
'from t_lex_kontenplan_konten_kat kto',
' left join t_lex_kontenplan_konten_kat_grp ktogrp on ktogrp.pk_lex_kontenplan_konten_kat_grp = kto.fk_lex_kontenplan_konten_kat_grp'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8300738402059286)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update_kat'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' for i in 1..apex_application.g_f01.count loop',
'  if apex_application.g_f01(i) is not null then',
' merge into t_rel_lex_kontenplan_kto_kto_kat t1',
' using (',
' ',
' select',
'     null pk_rel_lex_kontenplan_kto_kto_kat,',
' apex_application.g_f01(i)  FK_lex_KONTENPLAN_KONTEN,',
' :P218_kat FK_lex_KONTENPLAN_KONTEN_KAT',
'',
' ',
' from dual',
' ',
' ',
' ',
' ) t2 on (t1.pk_rel_lex_kontenplan_kto_kto_kat = t2.pk_rel_lex_kontenplan_kto_kto_kat)',
' when not matched then',
' insert (',
't1.FK_lex_KONTENPLAN_KONTEN,',
't1.FK_lex_KONTENPLAN_KONTEN_KAT',
')',
'values (',
'',
't2.FK_lex_KONTENPLAN_KONTEN,',
't2.FK_lex_KONTENPLAN_KONTEN_KAT',
'',
');',
'end if;',
'end loop;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8300616417059285)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8300864425059287)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'upd_kat_grp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
' null;',
' end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(8300554640059284)
);
wwv_flow_api.component_end;
end;
/
