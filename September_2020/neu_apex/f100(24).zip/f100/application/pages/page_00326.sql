prompt --application/pages/page_00326
begin
--   Manifest
--     PAGE: 00326
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>326
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Verpflegungsmehraufwand'
,p_alias=>'VERPFLEGUNGSMEHRAUFWAND'
,p_step_title=>'Verpflegungsmehraufwand'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200905181548'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13408629292282113)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7201357693999300)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_STEU_STEUER_VERPFL_MEHRAUFWD,',
'       MONAT,',
'       JAHR,',
'       FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS,',
'       COMM,',
'       FK_INP_BELEGE_ALL,',
'       CREATION_DATE,',
'       FK_STEU_STEUER_MONAT,',
'       FK_MDT_MANDANT,',
'       FK_KON_PERSON,',
'       cnt',
'  from T_STEU_STEUER_VERPFL_MEHRAUFWD verpfl',
'   left join (select fk_STEU_STEUER_VERPFL_MEHRAUFWD, count(*) cnt from T_STEU_STEUER_VERPFL_MEHRAUFWD_det group by fk_STEU_STEUER_VERPFL_MEHRAUFWD)  verpfl_det on verpfl.pk_STEU_STEUER_VERPFL_MEHRAUFWD = verpfl_det.fk_STEU_STEUER_VERPFL_MEHRAUFWD '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(13408714448282114)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.::P327_PK_STEU_STEUER_VERPFL_MEHRAUFWD:#PK_STEU_STEUER_VERPFL_MEHRAUFWD#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>13408714448282114
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13408894034282115)
,p_db_column_name=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk Steu Steuer Verpfl Mehraufwd'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13408977500282116)
,p_db_column_name=>'MONAT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409031441282117)
,p_db_column_name=>'JAHR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Jahr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409117078282118)
,p_db_column_name=>'FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fk Std Steu Verpfl Mehraufwd Status'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409227700282119)
,p_db_column_name=>'COMM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409304464282120)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409411423282121)
,p_db_column_name=>'CREATION_DATE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(13409536191282122)
,p_db_column_name=>'FK_STEU_STEUER_MONAT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fk Steu Steuer Monat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14071781713269725)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14071835573269726)
,p_db_column_name=>'FK_KON_PERSON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk Kon Person'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(14072115030269729)
,p_db_column_name=>'CNT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Cnt'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(13449473426715475)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'134495'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_STEU_STEUER_VERPFL_MEHRAUFWD:MONAT:JAHR:FK_STD_STEU_VERPFL_MEHRAUFWD_STATUS:COMM:FK_INP_BELEGE_ALL:CREATION_DATE:FK_STEU_STEUER_MONAT:FK_MDT_MANDANT:FK_KON_PERSON:CNT'
,p_break_on=>'JAHR:FK_MDT_MANDANT'
,p_break_enabled_on=>'JAHR:FK_MDT_MANDANT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14137680323709502)
,p_plug_name=>'Verpfegungsmehraufwand'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_menu_id=>wwv_flow_api.id(7149260507999280)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7266704574999328)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13409626717282123)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13408629292282113)
,p_button_name=>'Create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Create'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:327:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.component_end;
end;
/
