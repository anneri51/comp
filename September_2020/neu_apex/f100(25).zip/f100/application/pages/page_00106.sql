prompt --application/pages/page_00106
begin
--   Manifest
--     PAGE: 00106
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>106
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Kreditkartenkonto'
,p_alias=>'KREDITKARTENKONTO'
,p_step_title=>'Kreditkartenkonto'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200924234818'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2239552615197084)
,p_plug_name=>'Kreditkartenkonto'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       "Buchungstag",',
'       "Beleg",',
'       "Unternehmen",',
'       round("Betrag",2) "Betrag",',
'       Waehrung,',
'       "Betrag Ursprung",',
'       Waehrung Ursprung,',
'       "Belastete Kreditkarte",',
'       Kategorie,',
'       "Wertstellungsmonat",',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       fk_main_key,',
'       apex_item.checkbox2(1,fk_main_key) sel1,',
'       apex_item.checkbox2(2,fk_main_key) sel2,',
'       case when pk_rel_kto_kont_buch_kont_buch is not null then 1 else 0 end zuord_ausl,',
'        round(("Betrag"*1.5/100),2) Betrag_15,',
'        round(("Betrag"*1.75/100),2) Betrag_175,',
'        relkto.pk_rel_kto_kont_buch_kont_buch',
'  from t_KTO_KREDITKARTE kto',
unistr('    left join t_rel_kto_kont_buch_kont_buch relkto on (kto.fk_main_key = relkto.fk_kto_konto_buch1 or kto.fk_main_key = relkto.fk_kto_konto_buch2) and instr(relkto.bemerkung, ''Zuordnung Auslandsgeb\00FChr'') >0')))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2239600106197084)
,p_name=>'Kreditkartenkonto'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP:P114_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>11549735346618005
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2240444315197087)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2240832812197087)
,p_db_column_name=>'Beleg'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Beleg'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2241182687197088)
,p_db_column_name=>'Unternehmen'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4000274583759500)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'N'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4000463451759501)
,p_db_column_name=>'Betrag'
,p_display_order=>30
,p_column_identifier=>'O'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4000560291759502)
,p_db_column_name=>'Betrag Ursprung'
,p_display_order=>40
,p_column_identifier=>'P'
,p_column_label=>'Betrag ursprung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4000567022759503)
,p_db_column_name=>'Belastete Kreditkarte'
,p_display_order=>50
,p_column_identifier=>'Q'
,p_column_label=>'Belastete kreditkarte'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(4000757368759504)
,p_db_column_name=>'Wertstellungsmonat'
,p_display_order=>60
,p_column_identifier=>'R'
,p_column_label=>'Wertstellungsmonat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5328114654655024)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>90
,p_column_identifier=>'U'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630942635819892)
,p_db_column_name=>'SEL1'
,p_display_order=>100
,p_column_identifier=>'V'
,p_column_label=>'Sel1'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6630990164819893)
,p_db_column_name=>'SEL2'
,p_display_order=>110
,p_column_identifier=>'W'
,p_column_label=>'Sel2'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6631304867819896)
,p_db_column_name=>'ZUORD_AUSL'
,p_display_order=>120
,p_column_identifier=>'X'
,p_column_label=>'Zuord ausl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6634176969819925)
,p_db_column_name=>'BETRAG_15'
,p_display_order=>130
,p_column_identifier=>'Y'
,p_column_label=>'Betrag 15'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6634318434819926)
,p_db_column_name=>'BETRAG_175'
,p_display_order=>140
,p_column_identifier=>'Z'
,p_column_label=>'Betrag 175'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784142713065773)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>150
,p_column_identifier=>'AB'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784182456065774)
,p_db_column_name=>'URSPRUNG'
,p_display_order=>160
,p_column_identifier=>'AC'
,p_column_label=>'Ursprung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784377717065775)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>170
,p_column_identifier=>'AD'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784410798065776)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>180
,p_column_identifier=>'AE'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784544572065777)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>190
,p_column_identifier=>'AF'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48784656769065778)
,p_db_column_name=>'PK_REL_KTO_KONT_BUCH_KONT_BUCH'
,p_display_order=>200
,p_column_identifier=>'AG'
,p_column_label=>'Pk Rel Kto Kont Buch Kont Buch'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2557479695762105)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'118677'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL1:SEL2:Buchungstag:Beleg:Betrag:Unternehmen:FK_MAIN_KEY:ZUORD_AUSL:Belastete Kreditkarte:Betrag Ursprung:ID:Wertstellungsmonat::BETRAG_15:BETRAG_175:WAEHRUNG:URSPRUNG:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:PK_REL_KTO_KONT_BUCH'
||'_KONT_BUCH'
,p_sort_column_1=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'Buchungstag'
,p_break_enabled_on=>'Buchungstag'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(6812852557855943)
,p_report_id=>wwv_flow_api.id(2557479695762105)
,p_name=>unistr('zuord_auslandsgeb\00FChr')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ZUORD_AUSL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("ZUORD_AUSL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2611902371885121)
,p_plug_name=>'Kreditkartenbuchungszuordnung'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ',
'       kred_zus.id id1, ',
'       kred_zus.fk_main_key main1, ',
'       kred_all.*,',
'       kred_zus."Unternehmen", ',
'       kred_zus.FK_bas_kat_Kategorie, ',
'       kred_zus."Buchungstag", ',
'       round(kred_zus."Betrag",2) kred_zus_Betrag,',
'       case when abs(round(kred_zus."Betrag",2) ) = abs(round(kred_all.wert,2)) then 1 else 0 end ausgegl, ',
'       substr(kred_zus."Buchungstag", length(kred_zus."Buchungstag")-1,2) jahr',
'    from (select * from t_KTO_KREDITKARTE where FK_bas_kat_Kategorie in (74,91) or instr("Unternehmen", ''Saldovortrag'') >0) kred_zus',
'    left join (',
'               select ',
'                  sum( round(kred."Betrag",2)) Wert,  ',
'                  kred_main.fk_main_key, ',
'                  round(kred_main."Betrag",2) Betrag, ',
'                  kred_main.id,',
'                  null fk_main_key2',
'               from t_KTO_KREDITKARTE kred',
'                   left Join t_rel_kto_kont_buch_kont_BUCH KTOB ON KTOB.fk_kto_konto_buch2 = kred.fk_main_key',
'                   left Join (',
'                               select ktoz.*  from t_KTO_KREDITKARTE ktoz',
'                               where FK_bas_kat_Kategorie in(91) or instr("Unternehmen", ''Saldovortrag'') >0',
'                               ) kred_main ON KTOB.fk_kto_konto_buch1 = kred_main.fk_main_key ',
'                --  where      --kred_main.id = :P114_id',
'               group by kred_main.fk_main_key, ',
'                        round(kred_main."Betrag",2), ',
'                        kred_main.id',
'                            union',
'    select ',
'                  sum( round(kred."Betrag",2)) Wert,  ',
'                  ktoz.fk_main_key, ',
'                  round(ktoz."Betrag",2) Betrag, ',
'                  ktoz.id,',
'                  kred.fk_main_key fk_main_key2',
'                  ',
'    from t_KTO_KREDITKARTE kred',
'      left Join t_rel_kto_kont_buch_kont_BUCH KTOB ON (KTOB.fk_kto_konto_buch2 = kred.fk_main_key or  KTOB.fk_kto_konto_buch1 = kred.fk_main_key)',
'      left join v_kto_konten_zus ktoz on ktoz.fk_main_key = ktob.fk_kto_konto_buch1 or ktoz.fk_main_key = ktob.fk_kto_konto_buch2',
'    where kred.FK_bas_kat_Kategorie in(74)',
'        and  (kred.FK_std_kto_Kontotyp <> ktoz.FK_std_kto_Kontotyp and abs(round(kred."Betrag",2)) = abs(round(ktoz."Betrag",2)))',
'    group by ktoz.fk_main_key, ',
'                        round(ktoz."Betrag",2), ',
'                        ktoz.id,',
'                        kred.fk_main_key',
'        ) kred_all on kred_zus.id=kred_all.id or kred_zus.fk_main_key = kred_all.fk_main_key2',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2611997894885122)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP:P114_ID:#ID1#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>11922133135306043
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612156054885123)
,p_db_column_name=>'WERT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Wert'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612221166885124)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk main key'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612557925885127)
,p_db_column_name=>'BETRAG'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2612712043885129)
,p_db_column_name=>'MAIN1'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Main1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2677337847205680)
,p_db_column_name=>'Unternehmen'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Unternehmen'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2677512768205682)
,p_db_column_name=>'Buchungstag'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2677620500205683)
,p_db_column_name=>'KRED_ZUS_BETRAG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Kred zus betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3876118251528507)
,p_db_column_name=>'ID1'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Id1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3876239573528508)
,p_db_column_name=>'ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3876406239528510)
,p_db_column_name=>'AUSGEGL'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Ausgegl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5068414824641309)
,p_db_column_name=>'JAHR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Jahr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5327279407655016)
,p_db_column_name=>'FK_MAIN_KEY2'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fk main key2'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(48783993698065772)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2672714981030529)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'119829'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'WERT:FK_MAIN_KEY:BETRAG:MAIN1:Unternehmen:Buchungstag:KRED_ZUS_BETRAG1:AUSGEGL:JAHR:FK_MAIN_KEY2:FK_BAS_KAT_KATEGORIE'
,p_sort_column_1=>'Buchungstag'
,p_sort_direction_1=>'ASC'
,p_break_on=>'JAHR:0:0:0:0:0'
,p_break_enabled_on=>'JAHR:0:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5723672127291530)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'ausgegl'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'AUSGEGL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("AUSGEGL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5724141977291531)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'neg_betr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'<'
,p_expr=>'0'
,p_condition_sql=>' (case when ("BETRAG" < to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# < #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5724499236291532)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'pos_betr'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BETRAG'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("BETRAG" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B1F5B1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5724920727291533)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'Lastschrifteinzug'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'Unternehmen'
,p_operator=>'='
,p_expr=>'LASTSCHRIFTEINZUG'
,p_condition_sql=>' (case when ("Unternehmen" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''LASTSCHRIFTEINZUG''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFFF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5725282586291534)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'Saldovortrag'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'Unternehmen'
,p_operator=>'='
,p_expr=>'Saldovortrag'
,p_condition_sql=>' (case when ("Unternehmen" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Saldovortrag''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#99CCFF'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5725665193291534)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'ZAHLUNG'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'Unternehmen'
,p_operator=>'contains'
,p_expr=>'ZAHLUNG'
,p_condition_sql=>' (case when (upper("Unternehmen") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''ZAHLUNG''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FFDD44'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5726127616291535)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'neg_wert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'<'
,p_expr=>'0'
,p_condition_sql=>' (case when ("WERT" < to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# < #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#FF7755'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(5726490334291536)
,p_report_id=>wwv_flow_api.id(2672714981030529)
,p_name=>'pos_wert'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'WERT'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("WERT" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#B1F5B1'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6631088833819894)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(2239552615197084)
,p_button_name=>unistr('Zuord_Auslandsgeb\00FChr')
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>unistr('Zuord auslandsgeb\00FChr')
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3975047845227121)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2239552615197084)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'New'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP:P114_ID:'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8364195350137201)
,p_branch_name=>'Go To Page 107'
,p_branch_action=>'f?p=&APP_ID.:107:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8363467678137201)
,p_branch_name=>'Go To Page 105'
,p_branch_action=>'f?p=&APP_ID.:105:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6631210772819895)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Zuord_Auslandsgeb\00FChr')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  for i in 1..apex_application.g_f01.count loop',
'  ',
'    for j in 1..apex_application.g_f02.count loop',
'    ',
'       insert into t_rel_kont_buch_kont_buch',
'       (',
'       fk_konto_buch1,',
'       fk_konto_buch2,',
'       bemerkung)',
'       select',
'        apex_application.g_f01(i),',
'        apex_application.g_f02(j),',
unistr('        ''Zuordnung Auslandsgeb\00FChr'''),
'        from dual;',
'        commit;',
'    end loop;',
'  ',
'  ',
'  end loop;',
'',
'',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
