prompt --application/pages/page_00324
begin
--   Manifest
--     PAGE: 00324
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>324
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Step 9'
,p_alias=>'STEP-913'
,p_step_title=>'Step 9'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20200824073514'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10542534276120485)
,p_plug_name=>'Create Form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6232786070135999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'T_REL_KONT_BUCH_KONT_BUCH'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22404261131383060)
,p_plug_name=>'Buchungszuordnung'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'',
'relkto.*, ',
'',
'zus1.fk_main_key fk_main_key1,',
'zus1."Kontotyp" kontotyp1,',
'zus1.fk_konto fk_konto1,',
'zus1."Betrag" betrag1,',
'bel1.fk_relation fk_relation1,',
'zus1.bucht_tag bucht_tag1,',
'zus1.bucht_monat bucht_monat1,',
'zus1.bucht_jahr bucht_jahr1,',
'zus1.buchungstext buchungstxt1,',
'll1.habenkto hbkto1,',
'll1.sollkto slkto1,',
'll1.buchdat buchdat1,',
'll1.betrag lexbetrag1,',
'',
'',
'zus2.fk_main_key fk_main_key2,',
'zus2."Kontotyp" kontotyp2,',
'zus2.fk_konto fk_konto2,',
'zus2."Betrag" betrag2,',
'bel2.fk_relation fk_relation2,',
'zus2.bucht_tag bucht_tag2,',
'zus2.bucht_monat bucht_monat2,',
'zus2.bucht_jahr bucht_jahr2,',
'zus2.buchungstext buchungstxt2,',
'll2.habenkto hbkto2,',
'll2.sollkto slkto2,',
'll2.buchdat buchdat2,',
'll2.betrag lexbetrag2,',
'',
'case when zus1."Betrag"= -zus2."Betrag" then 1 else 0 end vgl',
'',
'from t_rel_kont_buch_kont_buch     relkto         ',
' left join v_konten_zus zus1 on relkto.fk_konto_buch1 = zus1.fk_main_key',
' left join v_konten_zus zus2 on relkto.fk_konto_buch2 = zus2.fk_main_key',
' left join t_rel_lex_kto_bel bel1 on bel1.fk_main_key = zus1.fk_main_key',
' left join t_rel_lex_kto_bel bel2 on bel2.fk_main_key = zus2.fk_main_key',
' left join t_lex_long ll1 on ll1.relation = bel1.fk_relation',
' left join t_lex_long ll2 on ll2.relation = bel2.fk_relation',
'where (:P324_FK_main_key is null) or (fk_konto_buch1 = :P324_fk_main_key ) or (fk_konto_buch2 = :P324_fk_main_key)'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22404336734383060)
,p_name=>'Buchungszuordnung'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>23844656009774600
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10553614640124183)
,p_db_column_name=>'FK_KONTO_BUCH1'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Konto Buch1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10554078564124183)
,p_db_column_name=>'FK_KONTO_BUCH2'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Konto Buch2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10554429865124183)
,p_db_column_name=>'FK_MAIN_KEY1'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Main Key1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10554859604124185)
,p_db_column_name=>'KONTOTYP1'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Kontotyp1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10555199510124185)
,p_db_column_name=>'FK_KONTO1'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Konto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10555584728124185)
,p_db_column_name=>'BETRAG1'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Betrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10556057591124185)
,p_db_column_name=>'FK_RELATION1'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fk Relation1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10556448197124186)
,p_db_column_name=>'BUCHT_TAG1'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Bucht Tag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10556837295124186)
,p_db_column_name=>'BUCHT_MONAT1'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Bucht Monat1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10557223380124186)
,p_db_column_name=>'BUCHT_JAHR1'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Bucht Jahr1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10557675784124188)
,p_db_column_name=>'HBKTO1'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Hbkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10558071331124188)
,p_db_column_name=>'SLKTO1'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Slkto1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10558455071124188)
,p_db_column_name=>'BUCHDAT1'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Buchdat1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10558821878124189)
,p_db_column_name=>'LEXBETRAG1'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Lexbetrag1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10559200914124189)
,p_db_column_name=>'FK_MAIN_KEY2'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Fk Main Key2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10559605592124189)
,p_db_column_name=>'KONTOTYP2'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Kontotyp2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10559996957124191)
,p_db_column_name=>'FK_KONTO2'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fk Konto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10560464968124191)
,p_db_column_name=>'BETRAG2'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Betrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10560873803124191)
,p_db_column_name=>'FK_RELATION2'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Fk Relation2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10561186629124191)
,p_db_column_name=>'BUCHT_TAG2'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Bucht Tag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10561640091124192)
,p_db_column_name=>'BUCHT_MONAT2'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Bucht Monat2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10562055146124192)
,p_db_column_name=>'BUCHT_JAHR2'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Bucht Jahr2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10562454699124192)
,p_db_column_name=>'HBKTO2'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Hbkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10562797390124194)
,p_db_column_name=>'SLKTO2'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Slkto2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10563211620124194)
,p_db_column_name=>'BUCHDAT2'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Buchdat2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10563650029124194)
,p_db_column_name=>'LEXBETRAG2'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Lexbetrag2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10552834491124181)
,p_db_column_name=>'VGL'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'Vgl'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10553261085124183)
,p_db_column_name=>'FK_TYPE'
,p_display_order=>53
,p_column_identifier=>'AI'
,p_column_label=>'Fk Type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10568819544317592)
,p_db_column_name=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_display_order=>63
,p_column_identifier=>'AJ'
,p_column_label=>'Pk Rel Kont Buch Kont Buch'
,p_column_link=>'f?p=&APP_ID.:324:&SESSION.::&DEBUG.:RP:P324_PK_REL_KONT_BUCH_KONT_BUCH:#PK_REL_KONT_BUCH_KONT_BUCH#'
,p_column_linktext=>'#PK_REL_KONT_BUCH_KONT_BUCH#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10568973639317593)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>73
,p_column_identifier=>'AK'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569064994317594)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>83
,p_column_identifier=>'AL'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569140192317595)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>93
,p_column_identifier=>'AM'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569273981317596)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>103
,p_column_identifier=>'AN'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569358168317597)
,p_db_column_name=>'BEMERKUNG'
,p_display_order=>113
,p_column_identifier=>'AO'
,p_column_label=>'Bemerkung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569475312317598)
,p_db_column_name=>'FK_BUCHUNGSVORGANG'
,p_display_order=>123
,p_column_identifier=>'AP'
,p_column_label=>'Fk Buchungsvorgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10570188447317606)
,p_db_column_name=>'BUCHUNGSTXT1'
,p_display_order=>133
,p_column_identifier=>'AQ'
,p_column_label=>'Buchungstxt1'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10570304125317607)
,p_db_column_name=>'BUCHUNGSTXT2'
,p_display_order=>143
,p_column_identifier=>'AR'
,p_column_label=>'Buchungstxt2'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(22417933242386070)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120043'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_KONTO_BUCH1:FK_KONTO_BUCH2:FK_MAIN_KEY1:KONTOTYP1:FK_KONTO1:BETRAG1:FK_RELATION1:BUCHT_TAG1:BUCHT_MONAT1:BUCHT_JAHR1:HBKTO1:SLKTO1:BUCHDAT1:LEXBETRAG1:FK_MAIN_KEY2:KONTOTYP2:FK_KONTO2:BETRAG2:FK_RELATION2:BUCHT_TAG2:BUCHT_MONAT2:BUCHT_JAHR2:HBKTO2'
||':SLKTO2:BUCHDAT2:LEXBETRAG2:VGL:FK_TYPE:PK_REL_KONT_BUCH_KONT_BUCH:CREATED_BY:CREATED_AT:MODIFIED_BY:MODIFIED_AT:BEMERKUNG:FK_BUCHUNGSVORGANG:BUCHUNGSTXT1:BUCHUNGSTXT2'
,p_break_on=>'FK_KONTO_BUCH1'
,p_break_enabled_on=>'FK_KONTO_BUCH1'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10653377504254227)
,p_report_id=>wwv_flow_api.id(22417933242386070)
,p_name=>'ok'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VGL'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("VGL" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#99FF99'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10652566059254225)
,p_report_id=>wwv_flow_api.id(22417933242386070)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'BUCHT_JAHR1'
,p_operator=>'='
,p_expr=>'2018'
,p_condition_sql=>'"BUCHT_JAHR1" = to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(10652917518254225)
,p_report_id=>wwv_flow_api.id(22417933242386070)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'KONTOTYP1'
,p_operator=>'='
,p_expr=>'Tagesgeldkonto'
,p_condition_sql=>'"KONTOTYP1" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Tagesgeldkonto''  '
,p_enabled=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22535056426271346)
,p_plug_name=>'selection'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(6232285247135997)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PK_REL_LEX_KTO_BEL,',
'       FK_LEX_OLD,',
'       FK_RELATION,',
'       FK_MAIN_KEY,',
'       FK_IMP_BA_BEL,',
'       FK_INP_BELEGE_ALL,',
'       CREATED_AT,',
'       MODIFIED_AT,',
'       OK,',
'       OK_DATUM,',
'       COMM,',
'       FK_REL_LEX_KTO_BEL,',
'       FK_INP_BELEGE_POS_ALL,',
'       lex_sel.relation,',
'       lex.relation lex_relation',
'  from (',
'            select relation , belegnr , nr, jahr',
'            from t_lex_long ',
'            where relation = :P324_fk_relation',
'             union',
'            select jahr || ''/''  || buchungsnummer || ''/0'' relation , belegnummer,buchungsnummer, jahr',
'            from imp_kontenblatt_2018',
'            where jahr || ''/''  || buchungsnummer || ''/0''=  :P324_fk_relation ',
'        ) lex_sel',
'        left join (',
'                    select relation , belegnr, nr, jahr',
'                    from t_lex_long ',
'                --  where belegnr = 1032',
'                     union',
'                    select jahr || ''/''  || buchungsnummer || ''/0'' relation , belegnummer,  buchungsnummer, jahr',
'                    from imp_kontenblatt_2018',
'        ) lex on lex_sel.belegnr = lex.belegnr and lex.jahr = lex_sel.jahr',
' ',
'  ',
' left Join T_REL_LEX_KTO_BEL relbel on lex.relation = relbel.fk_relation'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(22535171596271346)
,p_name=>'ir_test'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:324:&SESSION.::&DEBUG.:RP:P324_FK_MAIN_KEY,P324_FK_KONTO_BUCH1,P324_NEW:#FK_MAIN_KEY#,,'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>23975490871662886
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10581278972335025)
,p_db_column_name=>'PK_REL_LEX_KTO_BEL'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'Pk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10581599010335025)
,p_db_column_name=>'FK_LEX_OLD'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'Fk Lex Old'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582007388335025)
,p_db_column_name=>'FK_RELATION'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Fk Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582393652335027)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Fk Main Key'
,p_column_link=>'f?p=&APP_ID.:324:&SESSION.::&DEBUG.:RP:P324_FK_MAIN_KEY,P324_FK_KONTO_BUCH1,P324_NEW:#FK_MAIN_KEY#,#FK_MAIN_KEY#,New'
,p_column_linktext=>'#FK_MAIN_KEY#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10582856783335027)
,p_db_column_name=>'FK_IMP_BA_BEL'
,p_display_order=>50
,p_column_identifier=>'L'
,p_column_label=>'Fk Imp Ba Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10583186718335027)
,p_db_column_name=>'FK_INP_BELEGE_ALL'
,p_display_order=>60
,p_column_identifier=>'M'
,p_column_label=>'Fk Inp Belege All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10583666678335027)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>70
,p_column_identifier=>'N'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10583991816335027)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>80
,p_column_identifier=>'O'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10584450760335028)
,p_db_column_name=>'OK'
,p_display_order=>90
,p_column_identifier=>'P'
,p_column_label=>'Ok'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10584847668335028)
,p_db_column_name=>'OK_DATUM'
,p_display_order=>100
,p_column_identifier=>'Q'
,p_column_label=>'Ok Datum'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585212401335028)
,p_db_column_name=>'COMM'
,p_display_order=>110
,p_column_identifier=>'R'
,p_column_label=>'Comm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585615878335028)
,p_db_column_name=>'FK_REL_LEX_KTO_BEL'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Fk Rel Lex Kto Bel'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10585996964335028)
,p_db_column_name=>'FK_INP_BELEGE_POS_ALL'
,p_display_order=>130
,p_column_identifier=>'T'
,p_column_label=>'Fk Inp Belege Pos All'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569545860317599)
,p_db_column_name=>'RELATION'
,p_display_order=>140
,p_column_identifier=>'U'
,p_column_label=>'Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10569750875317601)
,p_db_column_name=>'LEX_RELATION'
,p_display_order=>150
,p_column_identifier=>'V'
,p_column_label=>'Lex Relation'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10591553774485789)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120319'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_REL_LEX_KTO_BEL:FK_LEX_OLD:FK_IMP_BA_BEL:FK_INP_BELEGE_ALL:CREATED_AT:MODIFIED_AT:OK:OK_DATUM:COMM:FK_REL_LEX_KTO_BEL:FK_INP_BELEGE_POS_ALL:RELATION:LEX_RELATION:FK_MAIN_KEY:FK_RELATION:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10550978833120513)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(10542534276120485)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P324_PK_REL_KONT_BUCH_KONT_BUCH'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10549688540120506)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10542534276120485)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10551338096120513)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(10542534276120485)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P324_PK_REL_KONT_BUCH_KONT_BUCH'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10550579321120511)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10542534276120485)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P324_PK_REL_KONT_BUCH_KONT_BUCH'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10542862684120486)
,p_name=>'P324_PK_REL_KONT_BUCH_KONT_BUCH'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'New'
,p_source=>'PK_REL_KONT_BUCH_KONT_BUCH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10543241028120494)
,p_name=>'P324_FK_KONTO_BUCH1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Konto Buch1'
,p_source=>'FK_KONTO_BUCH1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10543592687120499)
,p_name=>'P324_FK_KONTO_BUCH2'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Konto Buch2'
,p_source=>'FK_KONTO_BUCH2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('  select  fk_main_key  || '' '' || "Buchungstag" || '' '' || round("Betrag",2) ||'' '' ||       "W\00E4hrung" || '' '' ||'),
unistr('        round("Fremdw\00E4hrungsbetrag",2) || '' '' ||'),
unistr('    "Fremdw\00E4hrung"  || '' '' || BUCHUNGSTEXT || '' '' || "FK_Kategorie" || '' '' || "FK_Verwendungszweck" || '' ''  || "Kontotyp" || '' '' || FK_BUCHUNGSTAG || '' '' || "FK_WERTSTELLUNG" || '' '' || Wertt_datum d,  FK_MAIN_KEY r'),
'  from v_konten_zus'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10544033654120499)
,p_name=>'P324_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10544421527120499)
,p_name=>'P324_CREATED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Created At'
,p_source=>'CREATED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10544826913120500)
,p_name=>'P324_MODIFIED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Modified By'
,p_source=>'MODIFIED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10545186598120500)
,p_name=>'P324_MODIFIED_AT'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Modified At'
,p_source=>'MODIFIED_AT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10545663662120500)
,p_name=>'P324_BEMERKUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Bemerkung'
,p_source=>'BEMERKUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10546068291120502)
,p_name=>'P324_FK_BUCHUNGSVORGANG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Buchungsvorgang'
,p_source=>'FK_BUCHUNGSVORGANG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10546435322120502)
,p_name=>'P324_FK_TYPE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_item_source_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Type'
,p_source=>'FK_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10568778153317591)
,p_name=>'P324_FK_RELATION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Relation'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10569597978317600)
,p_name=>'P324_FK_MAIN_KEY'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'Fk Main Key'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10569877024317602)
,p_name=>'P324_BUCH1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select 1 d, 1 r from dual where :P324_fk_MAIN_KEY = :P324_FK_KONTO_BUCH1'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10569886896317603)
,p_name=>'P324_BUCH1_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>' '
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select 1 d, 1 r  from dual where :P324_fk_MAIN_KEY = :P324_FK_KONTO_BUCH2'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(10570065577317604)
,p_name=>'P324_NEW'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(10542534276120485)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(6255059252136028)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10552169018120516)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(10542534276120485)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Create Form'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(10551697412120516)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(10542534276120485)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Create Form'
);
wwv_flow_api.component_end;
end;
/
