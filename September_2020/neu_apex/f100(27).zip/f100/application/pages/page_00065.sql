prompt --application/pages/page_00065
begin
--   Manifest
--     PAGE: 00065
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>65
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>unistr('L\00F6sungs\00FCbersicht')
,p_alias=>unistr('L\00D6SUNGS\00DCBERSICHT99')
,p_step_title=>unistr('L\00F6sungs\00FCbersicht')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20200926182658'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(844083561894704)
,p_plug_name=>unistr('L\00F6sungs\00FCbersicht')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PK_LEHR_LOESUNG",',
'       "LOES_NR",',
'       "LOESUNG",',
'       "LOESUNG_CLOB",',
'       KORR,',
'       EIG_ANTW,',
'pk_lehr_frage,',
'frage,',
'fk_lehr_lehrgang,',
'fk_lehr_einsendeaufgabe,',
'fragennr',
'  from "T_LEHR_LOESUNG"   tl',
' left join t_rel_lehr_frage_loesung trfl on tl.pk_lehr_loesung = trfl.fk_lehr_loesung',
'  left join t_lehr_frage tf on tf.pk_lehr_frage = trfl.fk_lehr_frage',
' left join t_lehr_einsendeaufgabe te on te.pk_lehr_einsendeaufgabe = tf.fk_lehr_einsendeaufgabe'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(844233086894704)
,p_name=>unistr('L\00F6sungs\00FCbersicht')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>10154368327315625
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(846186121894708)
,p_db_column_name=>'KORR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Korr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(846626666894708)
,p_db_column_name=>'EIG_ANTW'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Eig Antw'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(800092543505720)
,p_db_column_name=>'FRAGE'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Frage'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(800411001505723)
,p_db_column_name=>'FRAGENNR'
,p_display_order=>56
,p_column_identifier=>'K'
,p_column_label=>'Fragennr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47720594757098173)
,p_db_column_name=>'PK_LEHR_LOESUNG'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Pk Lehr Loesung'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47720704566098174)
,p_db_column_name=>'LOES_NR'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Loes Nr'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47720835769098175)
,p_db_column_name=>'LOESUNG'
,p_display_order=>86
,p_column_identifier=>'N'
,p_column_label=>'Loesung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47720939793098176)
,p_db_column_name=>'LOESUNG_CLOB'
,p_display_order=>96
,p_column_identifier=>'O'
,p_column_label=>'Loesung Clob'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721073303098177)
,p_db_column_name=>'PK_LEHR_FRAGE'
,p_display_order=>106
,p_column_identifier=>'P'
,p_column_label=>'Pk Lehr Frage'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721135596098178)
,p_db_column_name=>'FK_LEHR_LEHRGANG'
,p_display_order=>116
,p_column_identifier=>'Q'
,p_column_label=>'Fk Lehr Lehrgang'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(47721260728098179)
,p_db_column_name=>'FK_LEHR_EINSENDEAUFGABE'
,p_display_order=>126
,p_column_identifier=>'R'
,p_column_label=>'Fk Lehr Einsendeaufgabe'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(848381733912262)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'101586'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'KORR:EIG_ANTW:FRAGE:FRAGENNR:PK_LEHR_LOES_NR:LOESUNG:LOESUNG_CLOB:PK_LEHR_FRAGE:FK_LEHR_LEHRGANG:FK_LEHR_EINSENDEAUFGABE'
,p_sort_column_1=>unistr('PK_L\00D6SUNG')
,p_sort_direction_1=>'ASC'
,p_break_on=>'FRAGENNR:FRAGE:0:0:0'
,p_break_enabled_on=>'FRAGENNR:FRAGE:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47759258825209410)
,p_report_id=>wwv_flow_api.id(848381733912262)
,p_name=>'falsch'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KORR'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("KORR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F2A2B2'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(47759677689209410)
,p_report_id=>wwv_flow_api.id(848381733912262)
,p_name=>'richtig'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'KORR'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("KORR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B3E89C'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8043724086486787)
,p_plug_name=>'Step 9'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8010393263486757)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8043857770486787)
,p_plug_name=>'Step 9'
,p_parent_plug_id=>wwv_flow_api.id(8043724086486787)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8045556466486788)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8043724086486787)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8045653335486788)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(8043724086486787)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8045738044486788)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8043724086486787)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8046582117486788)
,p_branch_action=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8045738044486788)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8045216894486788)
,p_name=>'P65_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8043857770486787)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
