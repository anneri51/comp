prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_page(
 p_id=>117
,p_user_interface_id=>wwv_flow_api.id(7287887300999338)
,p_name=>'Girokonto_modal'
,p_alias=>'GIROKONTO_MODAL99'
,p_step_title=>'Girokonto_modal'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ZAHID'
,p_last_upd_yyyymmddhh24miss=>'20200927121648'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2760970000461185)
,p_plug_name=>'Girokonto_modal'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(7203257164999301)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       "Buchungstag",',
'       "Wertstellung",',
'       "Umsatzart",',
'       "Buchungstext",',
'       "Betrag",',
'       Waehrung,',
'       "Auftraggeberkonto",',
'       "Bankleitzahl Auftraggeberkonto",',
'       IBAN_Auftraggeberkonto,',
'       Kategorie,',
'       F12,',
'       F13,',
'       "alt_ID",',
'       FK_bas_kat_Kategorie,',
'       FK_std_verw_Verwendungszweck,',
'       FK_std_kto_Kontotyp,',
'       "Bemerkungen",',
'       FK_MAIN_KEY',
'  from t_KTO_Girokonto'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(2761099860461185)
,p_name=>'Girokonto_modal'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>12071235100882106
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2761875145461198)
,p_db_column_name=>'Buchungstag'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Buchungstag'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2762342276461199)
,p_db_column_name=>'Wertstellung'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Wertstellung'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2762668297461199)
,p_db_column_name=>'Umsatzart'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Umsatzart'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2765917620461202)
,p_db_column_name=>'F12'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'F12'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2766272621461202)
,p_db_column_name=>'F13'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'F13'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2766674698461203)
,p_db_column_name=>'alt_ID'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Alt Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2768268538461204)
,p_db_column_name=>'Bemerkungen'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Bemerkungen'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(2768763247461204)
,p_db_column_name=>'FK_MAIN_KEY'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Fk Main Key'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295431148371897)
,p_db_column_name=>'ID'
,p_display_order=>29
,p_column_identifier=>'T'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295535231371898)
,p_db_column_name=>'Buchungstext'
,p_display_order=>39
,p_column_identifier=>'U'
,p_column_label=>'Buchungstext'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295600019371899)
,p_db_column_name=>'Betrag'
,p_display_order=>49
,p_column_identifier=>'V'
,p_column_label=>'Betrag'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295727610371900)
,p_db_column_name=>'WAEHRUNG'
,p_display_order=>59
,p_column_identifier=>'W'
,p_column_label=>'Waehrung'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295814291371901)
,p_db_column_name=>'Auftraggeberkonto'
,p_display_order=>69
,p_column_identifier=>'X'
,p_column_label=>'Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295932271371902)
,p_db_column_name=>'Bankleitzahl Auftraggeberkonto'
,p_display_order=>79
,p_column_identifier=>'Y'
,p_column_label=>'Bankleitzahl Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49295986355371903)
,p_db_column_name=>'IBAN_AUFTRAGGEBERKONTO'
,p_display_order=>89
,p_column_identifier=>'Z'
,p_column_label=>'Iban Auftraggeberkonto'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49296174600371904)
,p_db_column_name=>'KATEGORIE'
,p_display_order=>99
,p_column_identifier=>'AA'
,p_column_label=>'Kategorie'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49296255550371905)
,p_db_column_name=>'FK_BAS_KAT_KATEGORIE'
,p_display_order=>109
,p_column_identifier=>'AB'
,p_column_label=>'Fk Bas Kat Kategorie'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49296301537371906)
,p_db_column_name=>'FK_STD_VERW_VERWENDUNGSZWECK'
,p_display_order=>119
,p_column_identifier=>'AC'
,p_column_label=>'Fk Std Verw Verwendungszweck'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(49296382768371907)
,p_db_column_name=>'FK_STD_KTO_KONTOTYP'
,p_display_order=>129
,p_column_identifier=>'AD'
,p_column_label=>'Fk Std Kto Kontotyp'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(2769423562474156)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120796'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FK_MAIN_KEY:Buchungstag:Wertstellung:Umsatzart:Bankleitzahl IBAN Kategorie:F12:F13:alt_FK_Kategorie:Bemerkungen::WAEHRUNG:IBAN_AUFTRAGGEBERKONTO:KATEGORIE:FK_BAS_KAT_KATEGORIE:FK_STD_VERW_VERWENDUNGSZWECK:FK_STD_KTO_KONTOTYP'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(2776935987659442)
,p_report_id=>wwv_flow_api.id(2769423562474156)
,p_name=>'Row text contains ''Steuer'''
,p_condition_type=>'SEARCH'
,p_allow_delete=>'Y'
,p_expr=>'Steuer'
,p_enabled=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8407547038264561)
,p_plug_name=>'Step 7'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(7213623759999305)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(8382599939264549)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7242538523999317)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8407642281264561)
,p_plug_name=>'Step 7'
,p_parent_plug_id=>wwv_flow_api.id(8407547038264561)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7175836689999290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8409307803264562)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8407547038264561)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7265378195999327)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8409650513264562)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8407547038264561)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(7265433530999327)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8409515549264562)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8407547038264561)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7264698405999327)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8411058411264562)
,p_branch_action=>'f?p=&APP_ID.:118:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8409650513264562)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8410323634264562)
,p_branch_action=>'f?p=&APP_ID.:116:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(8409515549264562)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8409004089264562)
,p_name=>'P117_ITEM1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8407642281264561)
,p_prompt=>'ITEM 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_api.id(7264230059999327)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.component_end;
end;
/
