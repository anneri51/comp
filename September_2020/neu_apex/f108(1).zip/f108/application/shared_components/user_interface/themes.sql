prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 108
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1500924175361506
,p_default_application_id=>108
,p_default_id_offset=>0
,p_default_owner=>'COMPANY'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(4291188568411497)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(4192603443411445)
,p_default_dialog_template=>wwv_flow_api.id(4176196053411438)
,p_error_template=>wwv_flow_api.id(4177626201411439)
,p_printer_friendly_template=>wwv_flow_api.id(4192603443411445)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(4177626201411439)
,p_default_button_template=>wwv_flow_api.id(4288325876411490)
,p_default_region_template=>wwv_flow_api.id(4226234630411459)
,p_default_chart_template=>wwv_flow_api.id(4226234630411459)
,p_default_form_template=>wwv_flow_api.id(4226234630411459)
,p_default_reportr_template=>wwv_flow_api.id(4226234630411459)
,p_default_tabform_template=>wwv_flow_api.id(4226234630411459)
,p_default_wizard_template=>wwv_flow_api.id(4226234630411459)
,p_default_menur_template=>wwv_flow_api.id(4235677530411463)
,p_default_listr_template=>wwv_flow_api.id(4226234630411459)
,p_default_irr_template=>wwv_flow_api.id(4224342741411458)
,p_default_report_template=>wwv_flow_api.id(4252588443411471)
,p_default_label_template=>wwv_flow_api.id(4287289410411489)
,p_default_menu_template=>wwv_flow_api.id(4289725617411491)
,p_default_calendar_template=>wwv_flow_api.id(4289821924411492)
,p_default_list_template=>wwv_flow_api.id(4285369430411487)
,p_default_nav_list_template=>wwv_flow_api.id(4276306625411484)
,p_default_top_nav_list_temp=>wwv_flow_api.id(4276306625411484)
,p_default_side_nav_list_temp=>wwv_flow_api.id(4274728529411483)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(4199813269411449)
,p_default_dialogr_template=>wwv_flow_api.id(4198869596411449)
,p_default_option_label=>wwv_flow_api.id(4287289410411489)
,p_default_required_label=>wwv_flow_api.id(4287513136411489)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(4277399155411484)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/1.5/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
