prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Maintenance_Programm'
,p_step_title=>'Maintenance_Programm'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190421113538'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7930868575026047)
,p_plug_name=>'Wartungsprogramm'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3947311668329074)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(7930868575026047)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'"PK_APL_MAINT_PROGR", ',
'"FK_MDT_MANDANT",',
'MAINT_PROGR Wartungsprogramm',
'from "#OWNER#"."APL_MAINT_PROGR" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3947764354329075)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:9:&APP_SESSION.::::P9_PK_APL_PLANE_MAINT_PROGR:#PK_APL_PLANE_MAINT_PROGR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>19701382867664760
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3948277550329095)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7930627673026045)
,p_db_column_name=>'PK_APL_MAINT_PROGR'
,p_display_order=>12
,p_column_identifier=>'E'
,p_column_label=>'Pk apl maint progr'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3940729866079305)
,p_db_column_name=>'WARTUNGSPROGRAMM'
,p_display_order=>22
,p_column_identifier=>'G'
,p_column_label=>'Wartungsprogramm'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3969610081363958)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'197233'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>':WARTUNGSPROGRAMM'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3949475467329100)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3947311668329074)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9'
);
wwv_flow_api.component_end;
end;
/
