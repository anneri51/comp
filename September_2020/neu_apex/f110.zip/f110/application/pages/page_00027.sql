prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>27
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Documents'
,p_step_title=>'Documents'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190412155600'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3877130231099466)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select doc."PK_DOC_DOCUMENT", ',
'doc."FK_MDT_MANDANT",',
'doc."FK_DOC_DOCUMENT_TYPE",',
'doc."FK_DOC_USAGE_TYPE",',
'doc."DOCUMENT_TITLE",',
'dbms_lob.getlength(doc."DOCUMENT") "DOCUMENT",',
'doc."VALID",',
'doc."VALID_UNTIL",',
'doc."DOCUMENT_NR",',
'doc."FK_CERT_TYPE",',
'doc."FK_LAN_PROF_LEVEL",',
'doc."LAN_PROF_LEVEL_VAL",',
'doc."DOC_EXISTS",',
'doc_document_type',
'from "#OWNER#"."DOC_DOCUMENT" doc',
' left join doc_document_type doc_type on doc.FK_DOC_DOCUMENT_TYPE = doc_type.pk_DOC_DOCUMENT_TYPE',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3877560693099466)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:28:&APP_SESSION.::::P28_PK_DOC_DOCUMENT:#PK_DOC_DOCUMENT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>1977234237063366
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3877701738099472)
,p_db_column_name=>'PK_DOC_DOCUMENT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Doc Document'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3878057261099474)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3878477368099474)
,p_db_column_name=>'FK_DOC_DOCUMENT_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Doc Document Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3878841488099476)
,p_db_column_name=>'FK_DOC_USAGE_TYPE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fk Doc Usage Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3879323897099477)
,p_db_column_name=>'DOCUMENT_TITLE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Document Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3879693845099479)
,p_db_column_name=>'DOCUMENT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Document'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:DOC_DOCUMENT:DOCUMENT:PK_DOC_DOCUMENT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880015387099480)
,p_db_column_name=>'VALID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Valid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3880774313099482)
,p_db_column_name=>'DOCUMENT_NR'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Document Nr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881151052099482)
,p_db_column_name=>'FK_CERT_TYPE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fk Cert Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881585763099483)
,p_db_column_name=>'FK_LAN_PROF_LEVEL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fk Lan Prof Level'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3881991180099484)
,p_db_column_name=>'LAN_PROF_LEVEL_VAL'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Lan Prof Level Val'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3882350489099484)
,p_db_column_name=>'DOC_EXISTS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Doc Exists'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3895683655434002)
,p_db_column_name=>'VALID_UNTIL'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Valid until'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3895726955434003)
,p_db_column_name=>'DOC_DOCUMENT_TYPE'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Doc document type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(3883807087110212)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'19835'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_DOC_DOCUMENT:FK_MDT_MANDANT:DOCUMENT_TITLE:DOCUMENT:VALID:DOCUMENT_NR:FK_CERT_TYPE:FK_LAN_PROF_LEVEL:LAN_PROF_LEVEL_VAL:DOC_EXISTS:DOC_DOCUMENT_TYPE:FK_DOC_DOCUMENT_TYPE:FK_DOC_USAGE_TYPE:VALID_UNTIL:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(3882800066099484)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(3877130231099466)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:28'
);
wwv_flow_api.component_end;
end;
/
