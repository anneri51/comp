prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>29
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Customer'
,p_step_title=>'Customer'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190416164724'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7203447379694101)
,p_plug_name=>'Customer'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7192095672605304)
,p_plug_name=>'Customer'
,p_parent_plug_id=>wwv_flow_api.id(7203447379694101)
,p_icon_css_classes=>'fa-user-secret'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    case when    vdocmisinv.LIST_DOC_MISS is null and',
'    vdocmisinv.LIST_DOC_INVALID is null then ''green'' else ''red'' end style_ok,',
'    ''ok'' Dokumenten_Status,',
'    org."PK_ORG_UNIT", ',
'    org."FK_MDT_MANDANT" org_fk_mandant,',
'    org."COMPANY_NAME" firma,',
'    org."ORG_UNIT_NAME" || '' ('' ||     con.TITLE ||'' '' || ',
'    con.LAST_NAME ||'' '' || ',
'    con.FIRST_NAME ||'') ''   Kunde,',
'    case when org.ACTIVE=0 then ''Nein'' else ''Ja'' end org_Active,',
'    org."ACTIVE_FROM" org_active_from,',
'    org."ACTIVE_TO" org_active_to,',
'    org."CREATED_AT" org_created_at,',
'    org."CREATED_BY" org_created_by,',
'    org."MODIFIED_AT" org_modified_at,',
'    org."MODIFIED_BY" org_modified_by,',
'    "FK_ORG_UNIT_TYPE",',
'    "FK_ORG_UNIT_REL_TYPE" org_fk_org_unit_rel_type,',
'    --FK_ORG_UNIT,',
'    ORG_UNIT_TYPE_REL_NAME_DE,',
'    ORG_UNIT_TYPE_REL_NAME_EN Typ,',
'    ORG_UNIT_TYPE_NAME_EN "Firma/Person",',
'    con.PK_CON_CONTACT,',
'    con.FK_MDT_MANDANT,',
'    con.FK_CON_CONTACT_TYPE,',
'    con.FK_ADR_ADDRESS, ',
'    con.TITLE,',
'    con.LAST_NAME,',
'    con.FIRST_NAME,',
'    con.EMAIL, ',
'    con.COUNTRY_PREFIX || '' '' ||     con.PHONE_NO phone_no, ',
'    con.BIRTH_DAY, ',
'    con.ACTIVE, ',
'    con.ACTIVE_FROM, ',
'    con.ACTIVE_TO, ',
'    con.CREATED_AT, ',
'    con.CREATED_BY, ',
'    con.MODIFIED_AT, ',
'    con.MODIFIED_BY, ',
'    case when con.CONTACT_MAIN=0 then ''Nein'' else ''Ja'' end  CONTACT_MAIN,',
'    v_adr.PK_ADR_ADDRESS, ',
'    v_adr.FK_MDT_MANDANT adr_fk_mandant, ',
'    v_adr.STREET, ',
'    v_adr.STREET_NO,',
'    v_adr.ZIP_CODE,',
'    v_adr.FK_ADR_CITY, ',
'    v_adr.PK_ADR_CITY, ',
'    v_adr.CITY, ',
'    v_adr.FK_ADR_COUNTRY,',
'    v_adr.PK_ADR_COUNTRY, ',
'    v_adr.COUNTRY,',
'    vdocmisinv.LIST_DOC_MISS, ',
'    vdocmisinv.LIST_DOC_INVALID,',
'    case when org.pk_org_unit = :P29_PK_ORG_UNIT and con.pk_con_contact = :P29_PK_CON_CONTACT then ''LightGrey'' end style_selection',
'from "ORG_UNIT" org',
'  left join org_unit_type org_type on org.fk_org_unit_type = org_type.pk_org_unit_type',
'  left join rel_org_unit_con rel_org_con on rel_org_con.fk_org_unit = org.pk_org_unit',
'  join rel_org_unit_con_org_rel_type org_unit_con_rel_type on org_unit_con_rel_type.fk_org_unit_contact =rel_org_con.pk_org_unit_con',
'  left join org_unit_rel_type org_rel_type on org_rel_type.pk_org_unit_rel_type = org_unit_con_rel_type.fk_org_unit_rel_type',
'  left join con_contact con on con.pk_con_contact = rel_org_con.fk_con_contact ',
'  left join v_adr on v_adr.pk_adr_address = con.fk_adr_address',
'--  left join rel_doc_contact relcondoc on relcondoc.fk_con_contact = con.pk_con_contact ',
'--  left join doc_document doc on doc.pk_doc_document = relcondoc.fk_doc_document',
'--  left join doc_document_type doc_type on doc.fk_doc_document_type = doc_type.pk_doc_document_type',
'--  left join "REL_DOC_TYPE_USAGE_TYPE" rel  on rel.fk_doc_document_type = doc_type.pk_doc_document_type',
'--  left join doc_usage_type doc_usage_type on rel.fk_doc_usage_type =doc_usage_type.pk_doc_usage_type',
' left join v_doc_miss_inval vdocmisinv on vdocmisinv.fk_org_unit = org.pk_org_unit and vdocmisinv.pk_con_contact = con.pk_con_contact',
'where org_unit_con_rel_type.FK_ORG_UNIT_REL_TYPE=2',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7192500164605313)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::P29_PK_ORG_UNIT,P29_PK_CON_CONTACT:#PK_ORG_UNIT#,#PK_CON_CONTACT#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>5292173708569213
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7192549248605413)
,p_db_column_name=>'PK_ORG_UNIT'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Org Unit'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7192836461605486)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Mdt Mandant'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7194448866605489)
,p_db_column_name=>'ACTIVE_FROM'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Active From'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7194827470605492)
,p_db_column_name=>'ACTIVE_TO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Active To'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7195252675605493)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Created At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7195673250605495)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7196124825605496)
,p_db_column_name=>'MODIFIED_AT'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Modified At'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7196482512605497)
,p_db_column_name=>'MODIFIED_BY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Modified By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7196915975605498)
,p_db_column_name=>'FK_ORG_UNIT_TYPE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fk Org Unit Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7203593934694102)
,p_db_column_name=>'FIRMA'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Firma'
,p_column_html_expression=>'<span style="background-color:#STYLE_SELECTION#">#FIRMA#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7203626847694103)
,p_db_column_name=>'KUNDE'
,p_display_order=>33
,p_column_identifier=>'O'
,p_column_label=>'Kunde'
,p_column_html_expression=>'<span style="background-color:#STYLE_SELECTION#">#KUNDE#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204064199694107)
,p_db_column_name=>'ORG_UNIT_TYPE_REL_NAME_DE'
,p_display_order=>73
,p_column_identifier=>'S'
,p_column_label=>'Org unit type rel name de'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204454694694111)
,p_db_column_name=>'TYP'
,p_display_order=>93
,p_column_identifier=>'W'
,p_column_label=>'Typ'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204609971694112)
,p_db_column_name=>'Firma/Person'
,p_display_order=>103
,p_column_identifier=>'X'
,p_column_label=>'Firma&#x2F;person'
,p_column_html_expression=>'<span style="background-color:#STYLE_SELECTION#">#Firma/Person#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204770249694114)
,p_db_column_name=>'ORG_FK_MANDANT'
,p_display_order=>113
,p_column_identifier=>'Z'
,p_column_label=>'Org fk mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204855705694115)
,p_db_column_name=>'ORG_ACTIVE'
,p_display_order=>123
,p_column_identifier=>'AA'
,p_column_label=>'Org active'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7204990233694116)
,p_db_column_name=>'ORG_ACTIVE_FROM'
,p_display_order=>133
,p_column_identifier=>'AB'
,p_column_label=>'Org active from'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205083380694117)
,p_db_column_name=>'ORG_ACTIVE_TO'
,p_display_order=>143
,p_column_identifier=>'AC'
,p_column_label=>'Org active to'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205225782694118)
,p_db_column_name=>'ORG_CREATED_AT'
,p_display_order=>153
,p_column_identifier=>'AD'
,p_column_label=>'Org created at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205266906694119)
,p_db_column_name=>'ORG_CREATED_BY'
,p_display_order=>163
,p_column_identifier=>'AE'
,p_column_label=>'Org created by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205326664694120)
,p_db_column_name=>'ORG_MODIFIED_AT'
,p_display_order=>173
,p_column_identifier=>'AF'
,p_column_label=>'Org modified at'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205525359694121)
,p_db_column_name=>'ORG_MODIFIED_BY'
,p_display_order=>183
,p_column_identifier=>'AG'
,p_column_label=>'Org modified by'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205573645694122)
,p_db_column_name=>'ORG_FK_ORG_UNIT_REL_TYPE'
,p_display_order=>193
,p_column_identifier=>'AH'
,p_column_label=>'Org fk org unit rel type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205721346694123)
,p_db_column_name=>'PK_CON_CONTACT'
,p_display_order=>203
,p_column_identifier=>'AI'
,p_column_label=>'Pk con contact'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205768239694124)
,p_db_column_name=>'FK_CON_CONTACT_TYPE'
,p_display_order=>213
,p_column_identifier=>'AJ'
,p_column_label=>'Fk con contact type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205877756694125)
,p_db_column_name=>'FK_ADR_ADDRESS'
,p_display_order=>223
,p_column_identifier=>'AK'
,p_column_label=>'Fk adr address'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7205986261694126)
,p_db_column_name=>'TITLE'
,p_display_order=>233
,p_column_identifier=>'AL'
,p_column_label=>'Title'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206090528694127)
,p_db_column_name=>'LAST_NAME'
,p_display_order=>243
,p_column_identifier=>'AM'
,p_column_label=>'Last name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206169610694128)
,p_db_column_name=>'FIRST_NAME'
,p_display_order=>253
,p_column_identifier=>'AN'
,p_column_label=>'First name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206302935694129)
,p_db_column_name=>'EMAIL'
,p_display_order=>263
,p_column_identifier=>'AO'
,p_column_label=>'Email'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206514382694131)
,p_db_column_name=>'PHONE_NO'
,p_display_order=>283
,p_column_identifier=>'AQ'
,p_column_label=>'Phone no'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206570822694132)
,p_db_column_name=>'BIRTH_DAY'
,p_display_order=>293
,p_column_identifier=>'AR'
,p_column_label=>'Birth day'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206675523694133)
,p_db_column_name=>'ACTIVE'
,p_display_order=>303
,p_column_identifier=>'AS'
,p_column_label=>'Active'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7206900841694135)
,p_db_column_name=>'PK_ADR_ADDRESS'
,p_display_order=>323
,p_column_identifier=>'AU'
,p_column_label=>'Pk adr address'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207020674694136)
,p_db_column_name=>'ADR_FK_MANDANT'
,p_display_order=>333
,p_column_identifier=>'AV'
,p_column_label=>'Adr fk mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207047048694137)
,p_db_column_name=>'STREET'
,p_display_order=>343
,p_column_identifier=>'AW'
,p_column_label=>'Street'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207165719694138)
,p_db_column_name=>'STREET_NO'
,p_display_order=>353
,p_column_identifier=>'AX'
,p_column_label=>'Street no'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207319749694139)
,p_db_column_name=>'ZIP_CODE'
,p_display_order=>363
,p_column_identifier=>'AY'
,p_column_label=>'Zip code'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207328386694140)
,p_db_column_name=>'FK_ADR_CITY'
,p_display_order=>373
,p_column_identifier=>'AZ'
,p_column_label=>'Fk adr city'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207466878694141)
,p_db_column_name=>'PK_ADR_CITY'
,p_display_order=>383
,p_column_identifier=>'BA'
,p_column_label=>'Pk adr city'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207541361694142)
,p_db_column_name=>'CITY'
,p_display_order=>393
,p_column_identifier=>'BB'
,p_column_label=>'City'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207709976694143)
,p_db_column_name=>'FK_ADR_COUNTRY'
,p_display_order=>403
,p_column_identifier=>'BC'
,p_column_label=>'Fk adr country'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207797570694144)
,p_db_column_name=>'PK_ADR_COUNTRY'
,p_display_order=>413
,p_column_identifier=>'BD'
,p_column_label=>'Pk adr country'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207900807694145)
,p_db_column_name=>'COUNTRY'
,p_display_order=>423
,p_column_identifier=>'BE'
,p_column_label=>'Country'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7207952074694146)
,p_db_column_name=>'CONTACT_MAIN'
,p_display_order=>433
,p_column_identifier=>'BF'
,p_column_label=>'Contact main'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369996065064738)
,p_db_column_name=>'LIST_DOC_MISS'
,p_display_order=>443
,p_column_identifier=>'BG'
,p_column_label=>'List doc miss'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7370067150064739)
,p_db_column_name=>'LIST_DOC_INVALID'
,p_display_order=>453
,p_column_identifier=>'BH'
,p_column_label=>'List doc invalid'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3898600352434031)
,p_db_column_name=>'STYLE_OK'
,p_display_order=>463
,p_column_identifier=>'BI'
,p_column_label=>'Style ok'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3899334915434039)
,p_db_column_name=>'DOKUMENTEN_STATUS'
,p_display_order=>473
,p_column_identifier=>'BQ'
,p_column_label=>'Dokumenten status'
,p_column_html_expression=>'<span style="background-color:#STYLE_OK#">#DOKUMENTEN_STATUS#</span>'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3899455986434040)
,p_db_column_name=>'STYLE_SELECTION'
,p_display_order=>483
,p_column_identifier=>'BR'
,p_column_label=>'Style selection'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7200612816661565)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'53003'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOKUMENTEN_STATUS:Firma/Person:FIRMA:KUNDE:CONTACT_MAIN:TITLE:LAST_NAME:FIRST_NAME:LIST_DOC_MISS:LIST_DOC_INVALID:PHONE_NO:BIRTH_DAY:TYP:STREET:STREET_NO:ZIP_CODE:CITY:COUNTRY:EMAIL:ORG_ACTIVE:ORG_ACTIVE_FROM:ORG_UNIT_TYPE_REL_NAME_DE:ORG_ACTIVE_TO:O'
||'RG_CREATED_AT:ORG_CREATED_BY:ORG_MODIFIED_AT:ORG_MODIFIED_BY:STYLE_OK:'
,p_sort_column_1=>'FK_ORG_UNIT_REL_TYPE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'FIRMA:0:0:0:0'
,p_break_enabled_on=>'FIRMA:0:0:0:0'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7677134757934472)
,p_report_id=>wwv_flow_api.id(7200612816661565)
,p_name=>'doc_not_valid'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LIST_DOC_INVALID'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LIST_DOC_INVALID" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#FF2643'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7677441880934476)
,p_report_id=>wwv_flow_api.id(7200612816661565)
,p_name=>'doc_missing'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'LIST_DOC_MISS'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("LIST_DOC_MISS" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_font_color=>'#F25C5C'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7296031563397417)
,p_plug_name=>'Documents'
,p_parent_plug_id=>wwv_flow_api.id(7203447379694101)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with con as ( ',
'                        select *',
'                        from (select * from rel_org_unit_con  where (fk_org_unit =:P29_PK_ORG_UNIT or :P29_PK_ORG_UNIT is null)) rel_org_con',
'                        left   join  (select * from con_contact  ) con  on rel_org_con.fk_con_contact = con.pk_con_contact',
'                        ',
'                        where  (pk_con_contact = :P29_PK_CON_CONTACT or :P29_PK_CON_CONTACT is null)',
'',
'),',
'doc_us_type as (',
'                            select *',
'                            from (',
'                            select * ',
'                            from  REL_DOC_TYPE_USAGE_TYPE where fk_doc_usage_type = 2',
'                  ',
'                            ) rel',
'                              left join  doc_usage_type doc_usage_type on rel.fk_doc_usage_type =doc_usage_type.pk_doc_usage_type',
'                              left join doc_document_type   doc_type  on rel.fk_doc_document_type = doc_type.pk_doc_document_type  ',
'),',
'doc_us_type1 as (',
'                                select *',
'                                from doc_us_type, con',
')',
'',
',',
'',
'doc_type_con as (',
'                    select *',
'                    from doc_us_type1',
'',
'                ',
'),',
'con_doc as (',
'                      select *',
'                      from con',
'                       join rel_doc_contact reldoccon on reldoccon.fk_con_contact = con.pk_con_contact',
'                       join doc_document doc on doc.pk_doc_document = reldoccon.fk_doc_document',
'                    )',
'',
'select ',
'',
'',
'   doc_type_con. "PK_REL_DOC_TYPE_USAGE_TYPE" , ',
'   doc_type_con."FK_DOC_DOCUMENT_TYPE",',
'   doc_type_con."FK_DOC_USAGE_TYPE",',
'    case when nvl(doc_type_con.Required,0)= 0 then ''<b>Nein</b>'' else ''<b>Ja</b>'' end  required,',
'    doc_type_con.USAGE_TYPE_EN Used_for,',
'    doc_type_con.DOC_DOCUMENT_TYPE,',
'    doc_type_con.pk_doc_document_type,',
'    con_doc.pk_doc_document,',
'    doc_bas.basic_name_de,',
'    con_doc.lan_prof_level_val,',
'    con_doc.valid_until,',
'    con_doc.document_title,',
'    case when con_doc.pk_con_contact is not null then ''vorhanden'' else ''nicht vorhanden'' end Doc_exists,',
'    case when (doc_type_con.required = 1 and con_doc.pk_con_contact is null) then ''missing'' else ''existing'' end doc_missing ,',
'    case when trunc(con_doc.valid_until) = trunc(sysdate) then ''red'' ',
'         when trunc(con_doc.valid_until) between trunc(sysdate)+1 and trunc(sysdate)+45 then ''orange''',
'         when trunc(con_doc.valid_until) between trunc(sysdate)+45 and trunc(sysdate)+46 then ''yellow'' end style_color_valid,',
'    case when doc_bas.basic_value = 1 then ''orange'' end style_color_lan_cl,',
'    case when con_doc.lan_prof_level_val between 1 and 3 then ''yellow'' ',
'         when con_doc.lan_prof_level_val = 5 then ''#90ee90'' ',
'         when con_doc.lan_prof_level_val = 6 then ''green'' end style_color_lan_lev',
'from doc_type_con',
' left join con_doc on doc_type_con.fk_doc_document_type = con_doc.fk_doc_document_type and con_doc.pk_con_contact = doc_type_con.pk_con_contact',
' left join (select * from bas_basic where fk_bas_basic_grp = 2) doc_bas  on doc_bas.basic_value = con_doc.FK_LAN_PROF_LEVEL'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7296153526397418)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>5395827070361318
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7367604146064714)
,p_db_column_name=>'PK_REL_DOC_TYPE_USAGE_TYPE'
,p_display_order=>460
,p_column_identifier=>'AT'
,p_column_label=>'Pk rel doc type usage type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7367719691064715)
,p_db_column_name=>'FK_DOC_DOCUMENT_TYPE'
,p_display_order=>470
,p_column_identifier=>'AU'
,p_column_label=>'Fk doc document type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7367801670064716)
,p_db_column_name=>'FK_DOC_USAGE_TYPE'
,p_display_order=>480
,p_column_identifier=>'AV'
,p_column_label=>'Fk doc usage type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368220965064720)
,p_db_column_name=>'REQUIRED'
,p_display_order=>520
,p_column_identifier=>'AZ'
,p_column_label=>'Required'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368307456064721)
,p_db_column_name=>'USED_FOR'
,p_display_order=>530
,p_column_identifier=>'BA'
,p_column_label=>'Used for'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368398384064722)
,p_db_column_name=>'DOC_DOCUMENT_TYPE'
,p_display_order=>540
,p_column_identifier=>'BB'
,p_column_label=>'Doc document type'
,p_column_html_expression=>'<span style="background-color:#STYLE_COLOR_VALID#">#DOC_DOCUMENT_TYPE#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368487284064723)
,p_db_column_name=>'PK_DOC_DOCUMENT_TYPE'
,p_display_order=>550
,p_column_identifier=>'BC'
,p_column_label=>'Pk doc document type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368754705064726)
,p_db_column_name=>'DOC_EXISTS'
,p_display_order=>560
,p_column_identifier=>'BD'
,p_column_label=>'Doc exists'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7368871344064727)
,p_db_column_name=>'DOC_MISSING'
,p_display_order=>570
,p_column_identifier=>'BE'
,p_column_label=>'Doc missing'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369214655064730)
,p_db_column_name=>'PK_DOC_DOCUMENT'
,p_display_order=>590
,p_column_identifier=>'BH'
,p_column_label=>'Pk doc document'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369261431064731)
,p_db_column_name=>'STYLE_COLOR_VALID'
,p_display_order=>600
,p_column_identifier=>'BI'
,p_column_label=>'Style color valid'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369396798064732)
,p_db_column_name=>'STYLE_COLOR_LAN_CL'
,p_display_order=>610
,p_column_identifier=>'BJ'
,p_column_label=>'Style color lan cl'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369483078064733)
,p_db_column_name=>'STYLE_COLOR_LAN_LEV'
,p_display_order=>620
,p_column_identifier=>'BK'
,p_column_label=>'Style color lan lev'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369617607064734)
,p_db_column_name=>'BASIC_NAME_DE'
,p_display_order=>630
,p_column_identifier=>'BL'
,p_column_label=>'Basic name de'
,p_column_html_expression=>'<span style="background-color:#STYLE_COLOR_LAN_CL#">#BASIC_NAME_DE#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369637718064735)
,p_db_column_name=>'LAN_PROF_LEVEL_VAL'
,p_display_order=>640
,p_column_identifier=>'BM'
,p_column_label=>'Lan prof level val'
,p_column_html_expression=>'<span style="background-color:#STYLE_COLOR_LAN_LEV#">#LAN_PROF_LEVEL_VAL#</span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369729781064736)
,p_db_column_name=>'VALID_UNTIL'
,p_display_order=>650
,p_column_identifier=>'BN'
,p_column_label=>'Valid until'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7369856610064737)
,p_db_column_name=>'DOCUMENT_TITLE'
,p_display_order=>660
,p_column_identifier=>'BO'
,p_column_label=>'Document title'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7386245780070535)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'54860'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REQUIRED:USED_FOR:DOC_DOCUMENT_TYPE:DOCUMENT_TITLE:BASIC_NAME_DE:LAN_PROF_LEVEL_VAL:VALID_UNTIL:'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7529510849204688)
,p_report_id=>wwv_flow_api.id(7386245780070535)
,p_name=>'Missing'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DOC_MISSING'
,p_operator=>'='
,p_expr=>'missing'
,p_condition_sql=>' (case when ("DOC_MISSING" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''missing''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#E69CB1'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7197696931605500)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7203447379694101)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7368585206064724)
,p_name=>'P29_PK_ORG_UNIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7203447379694101)
,p_prompt=>'Kunde:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select org_unit_name || '' ('' || ORG_UNIT_TYPE_NAME_EN || '')'' d, pk_org_unit r',
'from org_unit org',
' left join org_unit_type org_type on org.fk_org_unit_type = org_type.pk_org_unit_type'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7368702640064725)
,p_name=>'P29_PK_CON_CONTACT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7203447379694101)
,p_prompt=>'Person:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name || '' '' || first_name || '' ('' || contact_main || '')'' d , pk_con_contact r',
'from con_contact'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
