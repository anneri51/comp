prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>31
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Std: Document type - Document Usage type'
,p_step_title=>'Std: Document type - Document Usage type'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190413190902'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7294873901397405)
,p_plug_name=>'Assigment Doc Type - Usage Type'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7275535764043983)
,p_plug_name=>'Report 1'
,p_parent_plug_id=>wwv_flow_api.id(7294873901397405)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    "PK_REL_DOC_TYPE_USAGE_TYPE" , ',
'    "FK_DOC_DOCUMENT_TYPE",',
'    "FK_DOC_USAGE_TYPE",',
'    case when nvl(VALID,0)= 0 then ''Nein'' else ''Ja'' end "VALID",',
'    "VALID_FROM",',
'    "VALID_TO",',
'    case when nvl(Required,0)= 0 then ''<b>Nein</b>'' else ''<b>Ja</b>'' end  required,',
'    USAGE_TYPE_EN Used_for,',
'    DOC_DOCUMENT_TYPE,',
'    pk_doc_document_type',
'from doc_document_type doc_type',
' left join "REL_DOC_TYPE_USAGE_TYPE" rel  on rel.fk_doc_document_type = doc_type.pk_doc_document_type',
' left join doc_usage_type doc_usage_type on rel.fk_doc_usage_type =doc_usage_type.pk_doc_usage_type',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7276019179043984)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::P32_PK_REL_DOC_TYPE_USAGE_TYPE,P32_FK_DOC_DOCUMENT_TYPE:#PK_REL_DOC_TYPE_USAGE_TYPE#,#PK_DOC_DOCUMENT_TYPE#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="Edit">'
,p_owner=>'ANNE'
,p_internal_uid=>5375692723007884
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7276055725043987)
,p_db_column_name=>'PK_REL_DOC_TYPE_USAGE_TYPE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Pk Rel Doc Type Usage Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7276436856043989)
,p_db_column_name=>'FK_DOC_DOCUMENT_TYPE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fk Doc Document Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7276897453043990)
,p_db_column_name=>'FK_DOC_USAGE_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fk Doc Usage Type'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7277648039043991)
,p_db_column_name=>'VALID_FROM'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Valid From'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7278063293043991)
,p_db_column_name=>'VALID_TO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Valid To'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7294430194397401)
,p_db_column_name=>'DOC_DOCUMENT_TYPE'
,p_display_order=>36
,p_column_identifier=>'I'
,p_column_label=>'Doc document type'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7294533122397402)
,p_db_column_name=>'VALID'
,p_display_order=>46
,p_column_identifier=>'J'
,p_column_label=>'Valid'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7294653599397403)
,p_db_column_name=>'REQUIRED'
,p_display_order=>56
,p_column_identifier=>'K'
,p_column_label=>'Required'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7294774949397404)
,p_db_column_name=>'USED_FOR'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Used for'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7295000977397406)
,p_db_column_name=>'PK_DOC_DOCUMENT_TYPE'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Pk doc document type'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7279196776045720)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'53789'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOC_DOCUMENT_TYPE:REQUIRED:VALID:VALID_FROM:VALID_TO:USED_FOR:'
,p_break_on=>'0:0:0:0:0:USED_FOR'
,p_break_enabled_on=>'0:0:0:0:0:USED_FOR'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(7316983421602913)
,p_report_id=>wwv_flow_api.id(7279196776045720)
,p_name=>'required'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'REQUIRED'
,p_operator=>'='
,p_expr=>'<b>Ja</b>'
,p_condition_sql=>' (case when ("REQUIRED" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''<b>Ja</b>''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FAC5DB'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7278456317043992)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7294873901397405)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32'
);
wwv_flow_api.component_end;
end;
/
