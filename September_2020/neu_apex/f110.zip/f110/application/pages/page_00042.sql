prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>42
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Bordbuch anlegen'
,p_step_title=>'Bordbuch anlegen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190419121201'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7686320873266404)
,p_plug_name=>'Step 1'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(22877469489920979)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7685234047266396)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(22894217420921002)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7686368639266404)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(7686320873266404)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22862620701920968)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7716288689308302)
,p_plug_name=>'New Bord Log Book'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7985020230249417)
,p_plug_name=>unistr('Bordb\FFFDcher')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select bord_log, pk_bor_bord_log',
'from bor_bord_log',
'where fk_apl_plane = :P42_fK_APL_PLane'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7985028018249418)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>6084701562213318
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7985151918249419)
,p_db_column_name=>'BORD_LOG'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Bord log'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7985277453249420)
,p_db_column_name=>'PK_BOR_BORD_LOG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Pk bor bord log'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8088331657010259)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'61881'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BORD_LOG:PK_BOR_BORD_LOG'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7688056907266410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7686320873266404)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7688357261266410)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7686320873266404)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(22895535816921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7689128726266413)
,p_branch_name=>'Go To Page 44 (Next)'
,p_branch_action=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::P44_PK_FLI_FLIGHT,P44_FK_APL_PLANE:,&P42_FK_APL_PLANE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7688357261266410)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7984255872249410)
,p_branch_name=>'Go To Page 39 (Cancel)'
,p_branch_action=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7688056907266410)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7716464369308304)
,p_name=>'P42_PK_BOR_BORD_LOG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_source=>'PK_BOR_BORD_LOG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7716723557308306)
,p_name=>'P42_BORD_LOG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bord log'
,p_source=>'BORD_LOG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7716727078308307)
,p_name=>'P42_BORD_LOG_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bord log date'
,p_source=>'BORD_LOG_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Stichtag, ab dem das Bordbuch seine G\FFFDltigkeit erh\FFFD (erhalten hat)')
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7716952498308309)
,p_name=>'P42_FK_APL_PLANE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk apl plane'
,p_source=>'FK_APL_PLANE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select plane_no, pk_apl_plane',
'from apl_PLane'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717112353308310)
,p_name=>'P42_CNT_LANDINGS_BEGIN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Anzahl Landungen Beginn'
,p_source=>'CNT_LANDINGS_BEGIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Anzahl Landungen zu Beginn des Bordbuches (als \FFFDertrag aus einem vorherigen) zur Initialisierung der Summenbildung')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717173562308311)
,p_name=>'P42_CNT_FLIGHT_HOURS_BEGIN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Anzahl Flugstunden Beginn'
,p_source=>'CNT_FLIGHT_HOURS_BEGIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Anzahl Flugstunden zu Beginn des Bordbuches (als \FFFDertrag aus einem vorherigen) zur Initialisierung der Summenbildung')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717316491308312)
,p_name=>'P42_CNT_LANDINGS_END'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Anzahl Landungen Ende'
,p_source=>'CNT_LANDINGS_END'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Anzahl Landungen am Ende des Bordbuches (als \FFFDertrag aus einem vorherigen) Summe inclusive des Wertes zu Beginn')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717398161308313)
,p_name=>'P42_CNT_FLIGHT_HOURS_END'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Anzahl Flugstunden Ende'
,p_source=>'CNT_FLIGHT_HOURS_END'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Anzahl  Flugstunden am Ende des Bordbuches (als \FFFDertrag aus einem vorherigen) Summe inclusive des Wertes zu Beginn')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717487042308314)
,p_name=>'P42_BEGIN_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Begin date'
,p_source=>'BEGIN_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Erster Tag des Eintrages in das entsprechende Bordbuch'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7717596018308315)
,p_name=>'P42_END_DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(7716288689308302)
,p_use_cache_before_default=>'NO'
,p_prompt=>'End date'
,p_source=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Tag des letzten Eintrages in das entsprechende Bordbuch'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7371135727064750)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load_Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
' :P42_PK_BOR_BORD_LOG := :P0_PK_BOR_BORD_LOG ;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7716354660308303)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row'
,p_attribute_02=>'BOR_BORD_LOG'
,p_attribute_03=>'P42_PK_BOR_BORD_LOG'
,p_attribute_04=>'PK_BOR_BORD_LOG'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7928633409026025)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_bord_log_plsql'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_seq number;',
'begin',
'  v_seq := BOR_BORD_LOG_SEQ2.nextval;',
'  ',
'  insert into bor_bord_log (',
'                              pk_bor_bord_log,',
'                              fk_mdt_mandant, ',
'                              fk_apl_plane, ',
'                              bord_log_date,',
'                              BORD_LOG,                           ',
'                              CNT_LANDINGS_BEGIN,',
'                              CNT_FLIGHT_HOURS_BEGIN,',
'                              CNT_LANDINGS_END,',
'                              CNT_FLIGHT_HOURS_END,',
'                              BEGIN_DATE,',
'                              END_DATE,',
'                              created_at,',
'                              created_by,',
'                              modified_at,',
'                              modified_by',
'                          ) ',
'    values (    ',
'                v_seq,',
'                :P0_pk_mdt_mandant,',
'                :P42_pk_apl_plane,',
'                :P42_Bor_log_date,',
'                :P42_BORD_LOG,                           ',
'                :P42_CNT_LANDINGS_BEGIN,',
'                :P42_CNT_FLIGHT_HOURS_BEGIN,',
'                :P42_CNT_LANDINGS_END,',
'                :P42_CNT_FLIGHT_HOURS_END,',
'                :P42_BEGIN_DATE,',
'                :P42_END_DATE,',
'                sysdate,',
'                :APP_USER,',
'                sysdate,',
'                :APP_USER',
'           );',
'commit;',
'',
'  :P0_PK_BOR_BORD_LOG := v_seq;',
'  ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7688357261266410)
);
wwv_flow_api.component_end;
end;
/
