prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>43
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>unistr('Bordbuch ausw\FFFDen')
,p_step_title=>unistr('Bordbuch ausw\FFFDen')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190419184502'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7689886694266414)
,p_plug_name=>'Step 1'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(22877469489920979)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7685234047266396)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(22894217420921002)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7689988228266414)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(7689886694266414)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22862620701920968)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7717945151308319)
,p_plug_name=>'Bord Log'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7718108552308320)
,p_plug_name=>'Selection'
,p_parent_plug_id=>wwv_flow_api.id(7717945151308319)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7930348545026042)
,p_plug_name=>'Bordbuch'
,p_parent_plug_id=>wwv_flow_api.id(7718108552308320)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22867344451920972)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7718234263308322)
,p_plug_name=>'Report_Selection'
,p_parent_plug_id=>wwv_flow_api.id(7930348545026042)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from bor_bord_log'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7718416832308323)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP:P43_PK_BOR_BORD_LOG:#PK_BOR_BORD_LOG#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'ANNE'
,p_internal_uid=>5818090376272223
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7718564393308325)
,p_db_column_name=>'PK_BOR_BORD_LOG'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Pk bor bord log'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7718690879308326)
,p_db_column_name=>'BORD_LOG'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bord log'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7718755626308327)
,p_db_column_name=>'BORD_LOG_DATE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bord log date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7718885835308328)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fk mdt mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7719004287308329)
,p_db_column_name=>'FK_APL_PLANE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fk apl plane'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7721073799308350)
,p_db_column_name=>'CNT_LANDINGS_BEGIN'
,p_display_order=>70
,p_column_identifier=>'AA'
,p_column_label=>'Cnt landings begin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7758584108835201)
,p_db_column_name=>'CNT_FLIGHT_HOURS_BEGIN'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Cnt flight hours begin'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7758658659835202)
,p_db_column_name=>'CNT_LANDINGS_END'
,p_display_order=>90
,p_column_identifier=>'AC'
,p_column_label=>'Cnt landings end'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7758730778835203)
,p_db_column_name=>'CNT_FLIGHT_HOURS_END'
,p_display_order=>100
,p_column_identifier=>'AD'
,p_column_label=>'Cnt flight hours end'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7758852796835204)
,p_db_column_name=>'BEGIN_DATE'
,p_display_order=>110
,p_column_identifier=>'AE'
,p_column_label=>'Begin date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7759020324835205)
,p_db_column_name=>'END_DATE'
,p_display_order=>120
,p_column_identifier=>'AF'
,p_column_label=>'End date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7757999409832110)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'58577'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_BOR_BORD_LOG:BORD_LOG:BORD_LOG_DATE:FK_MDT_MANDANT:FK_APL_PLANE:CNT_LANDINGS_BEGIN:CNT_FLIGHT_HOURS_BEGIN:CNT_LANDINGS_END:CNT_FLIGHT_HOURS_END:BEGIN_DATE:END_DATE'
,p_break_on=>'BORD_LOG'
,p_break_enabled_on=>'BORD_LOG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7930524000026043)
,p_plug_name=>unistr('Existierende Fl\FFFDge')
,p_parent_plug_id=>wwv_flow_api.id(7718108552308320)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22867344451920972)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7929152374026030)
,p_plug_name=>'Flights'
,p_parent_plug_id=>wwv_flow_api.id(7930524000026043)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22872125467920975)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fli.* , bor.fk_bor_bord_log ',
'from fli_flight fli',
' left join bor_bord_log_entry  bor on bor.fk_fli_flight = fli.pk_fli_flight',
'where fk_apl_plane = :P43_FK_APL_PLANE',
' and (fk_bor_bord_log = :P0_pk_bor_bord_log or :P0_pk_bor_bord_log is null)',
' '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7929324156026031)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_owner=>'ANNE'
,p_internal_uid=>6028997699989931
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929336222026032)
,p_db_column_name=>'PK_FLI_FLIGHT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pk fli flight'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929480241026033)
,p_db_column_name=>'FK_MDT_MANDANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fk mdt mandant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929587789026034)
,p_db_column_name=>'DEPARTURE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Departure'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929661126026035)
,p_db_column_name=>'ARRIVAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Arrival'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929790656026036)
,p_db_column_name=>'DEPARTURE_TIME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Departure time'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929863893026037)
,p_db_column_name=>'ARRIVAL_TIME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Arrival time'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7929974022026038)
,p_db_column_name=>'DURATION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Duration'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7930123109026039)
,p_db_column_name=>'ADDITIONAL_TIMESLOTS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Additional timeslots'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7930219011026040)
,p_db_column_name=>'FK_ADDITIONAL_TIMESLOTTYPE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fk additional timeslottype'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7930312049026041)
,p_db_column_name=>'FK_APL_PLANE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fk apl plane'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7930541612026044)
,p_db_column_name=>'FK_BOR_BORD_LOG'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fk bor bord log'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(8144666429419676)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'62444'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PK_FLI_FLIGHT:FK_MDT_MANDANT:DEPARTURE:ARRIVAL:DEPARTURE_TIME:ARRIVAL_TIME:DURATION:ADDITIONAL_TIMESLOTS:FK_ADDITIONAL_TIMESLOTTYPE:FK_APL_PLANE:FK_BOR_BORD_LOG'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7718129175308321)
,p_plug_name=>'Change'
,p_parent_plug_id=>wwv_flow_api.id(7717945151308319)
,p_region_template_options=>'#DEFAULT#:t-Region--accent14:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7928329533026022)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7718129175308321)
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Delete'
,p_button_position=>'BOTTOM'
,p_button_condition=>'P43_PK_BOR_BORD_LOG'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7691713048266415)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7689886694266414)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7691941058266415)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7689886694266414)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(22895535816921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7691887587266415)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7689886694266414)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895336936921006)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7693515429266416)
,p_branch_name=>'Go To Page 44 (Next New)'
,p_branch_action=>'f?p=&APP_ID.:44:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7691941058266415)
,p_branch_sequence=>20
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P43_FLIGHT'
,p_branch_condition_text=>'44'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7929122228026029)
,p_branch_name=>'Go To Page 44 (Next Existing)'
,p_branch_action=>'f?p=&APP_ID.:44:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7691941058266415)
,p_branch_sequence=>30
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P43_FLIGHT'
,p_branch_condition_text=>'44'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7984363453249411)
,p_branch_name=>'Go To Page 39 (Cancel)'
,p_branch_action=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7691713048266415)
,p_branch_sequence=>40
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7692815526266415)
,p_branch_action=>'f?p=&APP_ID.:42:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7691887587266415)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7759189485835207)
,p_name=>'P43_FLIGHT'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_item_default=>'44'
,p_prompt=>' '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Neuen Flug anlegen;44,bestehenden Flug \FFFDern;45')
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7780646387855989)
,p_name=>'P43_PK_BOR_BORD_LOG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_source=>'PK_BOR_BORD_LOG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7781068740855994)
,p_name=>'P43_BORD_LOG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bord log'
,p_source=>'BORD_LOG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7781433757855994)
,p_name=>'P43_BORD_LOG_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Bord log date'
,p_source=>'BORD_LOG_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7781862229855995)
,p_name=>'P43_FK_MDT_MANDANT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk mdt mandant'
,p_source=>'FK_MDT_MANDANT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7782235330855995)
,p_name=>'P43_FK_APL_PLANE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk apl plane'
,p_source=>'FK_APL_PLANE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7782652083855995)
,p_name=>'P43_CNT_LANDINGS_BEGIN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cnt landings begin'
,p_source=>'CNT_LANDINGS_BEGIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7783052981855996)
,p_name=>'P43_CNT_FLIGHT_HOURS_BEGIN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cnt flight hours begin'
,p_source=>'CNT_FLIGHT_HOURS_BEGIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7783428921855996)
,p_name=>'P43_CNT_LANDINGS_END'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cnt landings end'
,p_source=>'CNT_LANDINGS_END'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7783890006855998)
,p_name=>'P43_CNT_FLIGHT_HOURS_END'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cnt flight hours end'
,p_source=>'CNT_FLIGHT_HOURS_END'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7784316072855998)
,p_name=>'P43_BEGIN_DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Begin date'
,p_source=>'BEGIN_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7784703263856000)
,p_name=>'P43_END_DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(7718129175308321)
,p_use_cache_before_default=>'NO'
,p_prompt=>'End date'
,p_source=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(7928868115026027)
,p_name=>'OnChange_Flight_Selection'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P43_FLIGHT'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(7929006280026028)
,p_event_id=>wwv_flow_api.id(7928868115026027)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P43_FLIGHT'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7928214042026020)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'SAVE_Bord_log'
,p_attribute_02=>'BOR_BORD_LOG'
,p_attribute_03=>'P43_PK_BOR_BORD_LOG'
,p_attribute_04=>'PK_BOR_BORD_LOG'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7928497485026023)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Delete Bord_log'
,p_attribute_02=>'BOR_BORD_LOG'
,p_attribute_03=>'P43_PK_BOR_BORD_LOG'
,p_attribute_04=>'BORD_LOG'
,p_attribute_11=>'D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8003281140497455)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add_bord_log_plsql'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'  v_seq number;',
'begin',
'  v_seq := BOR_BORD_LOG_SEQ2.nextval;',
'  ',
'  insert into bor_bord_log (',
'                              pk_bor_bord_log,',
'                              fk_mdt_mandant, ',
'                              fk_apl_plane, ',
'                              bord_log_date,',
'                              BORD_LOG,                           ',
'                              CNT_LANDINGS_BEGIN,',
'                              CNT_FLIGHT_HOURS_BEGIN,',
'                              CNT_LANDINGS_END,',
'                              CNT_FLIGHT_HOURS_END,',
'                              BEGIN_DATE,',
'                              END_DATE',
'                          ) ',
'    values (    ',
'                v_seq,',
'                :P0_fk_mdt_mandant,',
'                :P42_pk_apl_plane,',
'                :P42_Bor_log_date,',
'                :P42_BORD_LOG,                           ',
'                :P42_CNT_LANDINGS_BEGIN,',
'                :P42_CNT_FLIGHT_HOURS_BEGIN,',
'                :P42_CNT_LANDINGS_END,',
'                :P42_CNT_FLIGHT_HOURS_END,',
'                :P42_BEGIN_DATE,',
'                :P42_END_DATE',
'           );',
'commit;',
'',
'  :P0_PK_BOR_BORD_LOG := v_seq;',
'  ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7759093714835206)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'New'
,p_attribute_02=>'BOR_BORD_LOG'
,p_attribute_03=>'P43_PK_BOR_BORD_LOG'
,p_attribute_04=>'PK_BOR_BORD_LOG'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
