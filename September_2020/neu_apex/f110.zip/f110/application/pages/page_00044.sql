prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>44
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Flug anlegen'
,p_step_title=>'Flug anlegen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190418124955'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3900207624434047)
,p_plug_name=>'FLIGHTS'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7694130022266416)
,p_plug_name=>'Step 2'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(22877469489920979)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7685234047266396)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(22894217420921002)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7694304872266416)
,p_plug_name=>'Step 2'
,p_parent_plug_id=>wwv_flow_api.id(7694130022266416)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22862620701920968)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7695945022266417)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7694130022266416)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7696277895266417)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7694130022266416)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(22895535816921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7696179849266417)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7694130022266416)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895336936921006)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7370714434064745)
,p_branch_name=>'Go To Page 46'
,p_branch_action=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7696277895266417)
,p_branch_sequence=>30
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7370735441064746)
,p_branch_name=>'Go back to page 42'
,p_branch_action=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7696179849266417)
,p_branch_sequence=>40
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P44_PREVIOUS_PAGE'
,p_branch_condition_text=>'42'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7370836202064747)
,p_branch_name=>'Go back to page 43'
,p_branch_action=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7696179849266417)
,p_branch_sequence=>50
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P44_PREVIOUS_PAGE'
,p_branch_condition_text=>'43'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7927947309026018)
,p_branch_name=>'Go To Page 39'
,p_branch_action=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7695945022266417)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3900228459434048)
,p_name=>'P44_PK_FLI_FLIGHT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_source=>'PK_FLI_FLIGHT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3900520909434050)
,p_name=>'P44_DEPARTURE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Departure'
,p_source=>'DEPARTURE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7370456012064743)
,p_name=>'P44_NEXT_PAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7694130022266416)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7370546272064744)
,p_name=>'P44_PREVIOUS_PAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7694130022266416)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7859531159498301)
,p_name=>'P44_ARRIVAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Arrival'
,p_source=>'ARRIVAL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7859679856498302)
,p_name=>'P44_DEPARTURE_TIME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Departure time'
,p_source=>'DEPARTURE_TIME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7859794087498303)
,p_name=>'P44_ARRIVAL_TIME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Arrival time'
,p_source=>'ARRIVAL_TIME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7859923481498304)
,p_name=>'P44_DURATION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Duration'
,p_source=>'DURATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7859949031498305)
,p_name=>'P44_ADDITIONAL_TIMESLOTS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Additional timeslots'
,p_source=>'ADDITIONAL_TIMESLOTS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7860084578498306)
,p_name=>'P44_FK_ADDITIONAL_TIMESLOTTYPE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk additional timeslottype'
,p_source=>'FK_ADDITIONAL_TIMESLOTTYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select basic_name_de, basic_value',
'from bas_basic',
'where fk_bas_basic_grp = 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7860222403498307)
,p_name=>'P44_FK_APL_PLANE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(3900207624434047)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fk apl plane'
,p_source=>'FK_APL_PLANE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select plane_no, pk_apl_plane',
'from apl_plane'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3900029713434046)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row'
,p_attribute_02=>'FLI_FLIGHT'
,p_attribute_03=>'P44_PK_FLI_FLIGHT'
,p_attribute_04=>'PK_FLI_FLIGHT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P44_PK_FLI_FLIGHT'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7370940851064748)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_flug'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
' v_pk_fli_flight number;',
' ',
'',
'begin',
'',
'  v_pk_fli_flight := FLI_FLIGHT_SEQ2.nextval;',
'  ',
'  insert into fli_flight',
'    (  ',
'      PK_FLI_FLIGHT, ',
'      FK_MDT_MANDANT, ',
'      DEPARTURE, ',
'      ARRIVAL, ',
'      DEPARTURE_TIME, ',
'      ARRIVAL_TIME, ',
'      DURATION, ',
'      ADDITIONAL_TIMESLOTS, ',
'      FK_ADDITIONAL_TIMESLOTTYPE, ',
'      FK_APL_PLANE',
'',
'',
'    )',
'   values',
'   (',
'     v_pk_fli_flight ,',
'       :P0_PK_MDT_MANDANT, ',
'       :P44_DEPARTURE, ',
'       :P44_ARRIVAL, ',
'       :P44_DEPARTURE_TIME, ',
'       :P44_ARRIVAL_TIME, ',
'       :P44_DURATION, ',
'       :P44_ADDITIONAL_TIMESLOTS, ',
'       :P44_FK_ADDITIONAL_TIMESLOTTYPE, ',
'       :P44_FK_APL_PLANE',
'',
'   );',
'   commit;',
'   ',
'   :P44_PK_FLI_FLIGHT := v_pk_fli_flight;',
'   :P0_PK_FLI_FLIGHT :=  v_pk_fli_flight;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
