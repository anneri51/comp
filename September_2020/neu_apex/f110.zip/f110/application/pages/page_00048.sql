prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1881688158048951
,p_default_application_id=>111
,p_default_id_offset=>17461541271462625
,p_default_owner=>'FLIGHT_DEV'
);
wwv_flow_api.create_page(
 p_id=>48
,p_user_interface_id=>wwv_flow_api.id(22906206020921041)
,p_name=>'Bordbucheintrag'
,p_step_title=>'Bordbucheintrag'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ANNE'
,p_last_upd_yyyymmddhh24miss=>'20190418125516'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7711395709266426)
,p_plug_name=>'Step 4'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(22877469489920979)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(7685234047266396)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(22894217420921002)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7711429964266426)
,p_plug_name=>'Step 4'
,p_parent_plug_id=>wwv_flow_api.id(7711395709266426)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(22862620701920968)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7864440970498350)
,p_plug_name=>'Bord Log Entry'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(22872632320920976)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7713180674266427)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7711395709266426)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7713267316266427)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(7711395709266426)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895484989921008)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7713365971266427)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7711395709266426)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(22895336936921006)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7984145897249409)
,p_branch_name=>'go to page 39'
,p_branch_action=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:RP:P39_PK_APL_PLANE:&P44_PK_APL_PLANE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7714237953266428)
,p_branch_action=>'f?p=&APP_ID.:47:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7713365971266427)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926308651026001)
,p_name=>'P48_PK_BOR_BORD_LOG_ENTRY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926519251026003)
,p_name=>'P48_FK_FLI_FLIGHT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_item_default=>':P0_PK_FLI_FLIGHT'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fk fli flight'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select departure || '' '' || arrival, pk_fli_flight',
'from fli_flight '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926570640026004)
,p_name=>'P48_ENTRY_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Entry date'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926691420026005)
,p_name=>'P48_PIC'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Pic'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926731093026006)
,p_name=>'P48_T_O_TIME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'T o time'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926893819026007)
,p_name=>'P48_LDG_TIME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Ldg time'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7926993941026008)
,p_name=>'P48_CHARGES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Charges'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927075178026009)
,p_name=>'P48_EDMA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Edma'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927140170026010)
,p_name=>'P48_ARRIVAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Arrival'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927302444026011)
,p_name=>'P48_FK_BOR_BORD_LOG_ENTRY_GRP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Fk bor bord log entry grp'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select group_name, pk_bor_bord_log_entry_grp',
'from bor_bord_log_entry_grp'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927409507026012)
,p_name=>'P48_COMM'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Comm'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927506927026013)
,p_name=>'P48_COST_ADD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Cost add'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927593793026014)
,p_name=>'P48_CHARTER_NO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Charter no'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7927678900026015)
,p_name=>'P48_FK_BOR_BORD_LOG'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(7864440970498350)
,p_prompt=>'Fk bor bord log'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fk_apl_plane, pk_bor_bord_log',
'from bor_bord_log'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(22894947404921004)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7983712901249404)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add_bord_log_entry'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
' v_seq number;',
' ',
'begin',
' v_seq := BOR_BORD_LOG_ENTRY_SEQ1.nextval;',
'  insert into bor_bord_log_entry (',
'   PK_BOR_BORD_LOG_ENTRY,',
'    FK_MDT_MANDANT,',
'    FK_FLI_FLIGHT,',
'    ENTRY_DATE,',
'    PIC,',
'    T_O_TIME,',
'    LDG_TIME,',
'    CHARGES,',
'    EDMA,',
'    ARRIVAL,',
'    FK_BOR_BORD_LOG_ENTRY_GRP,',
'    COMM,',
'    COST_ADD,',
'    CHARTER_NO,',
'    FK_BOR_BORD_LOG',
'  )',
'  values',
'  (',
'        v_seq,',
'        :P0_FK_MDT_MANDANT,',
'        :P48_FK_FLI_FLIGHT,',
'        :P48_ENTRY_DATE,',
'        :P48_PIC,',
'        :P48_T_O_TIME,',
'        :P48_LDG_TIME,',
'        :P48_CHARGES,',
'        :P48_EDMA,',
'        :P48_ARRIVAL,',
'        :P48_FK_BOR_BORD_LOG_ENTRY_GRP,',
'        :P48_COMM,',
'        :P48_COST_ADD,',
'        :P48_CHARTER_NO,',
'        :P0_FK_BOR_BORD_LOG',
'  );',
'  commit;',
'',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7713267316266427)
);
wwv_flow_api.component_end;
end;
/
